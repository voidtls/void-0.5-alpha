# kit6 · новая версия набора kit/q130.py (корректирующее обновление 1.5.35); исторический файл не изменён. Отличия — kit6/DIFF.md.
# 1.0 QA: тесты на каждое исправление из батареи qa1000 (группа Q). Каждый тест падает на сборке до правки.
import asyncio,json,sys,os
from h import *

async def waitFor(P,cond,ms):
    # kit6: ожидание УСЛОВИЯ (опрос каждые 50 мс) вместо фиксированной паузы; возвращает мс до выполнения или None (не дождались)
    import time as _t
    t0=_t.time()
    while (_t.time()-t0)*1000<ms:
        if await P.js(cond):return round((_t.time()-t0)*1000)
        await P.wait(50)
    return None
QA_SRC=open(SP+'qa1000.py').read()
_i=QA_SRC.index('QA_JS=r"""')+10;QA_JS=QA_SRC[_i:QA_SRC.index('"""',_i)]
async def P0(b,**kw):
    P=await newpage(b,**kw);await P.js(QA_JS);return P
C49=open('@@KIT@@/home/void_code_49.txt').read().strip()
CMX=open('@@KIT@@/home/void_code_49_max.txt').read().strip()
# имитация базы артефакта: window.claude.use('db'|'user'); хранилище передаётся между «версиями» через Python
def FAKE(store):
    return "(()=>{const st="+json.dumps(json.dumps(store))+";const S=JSON.parse(st);window.__fake=S;window.__fakeLog=[];"+r"""
  const doc=path=>({path,id:path.split('/').pop(),async get(){await new Promise(r=>setTimeout(r,40));const d=S[path];return {id:path.split('/').pop(),exists:!!d,data:()=>d?JSON.parse(JSON.stringify(d)):undefined,metadata:{fromCache:false,hasPendingWrites:false}};},
    async set(d){await new Promise(r=>setTimeout(r,20));window.__fakeLog.push(path);S[path]=JSON.parse(JSON.stringify(d));},async update(d){S[path]=Object.assign(S[path]||{},d);},async delete(){delete S[path];},onSnapshot(){return ()=>{};}});
  const db={doc,collection:p=>({doc:id=>doc(p+'/'+id)})};const user={id:async()=>'u_test',isOwner:async()=>true,canEdit:async()=>true,can:async()=>true,me:async()=>({id:'u_test'})};
  window.claude={use:async n=>n==='db'?db:n==='user'?user:null};})();"""
LOADUI="(code)=>{toMenu();openSaveScreen();$('#saveIn').value=code;$('#bSaveLoad').click();return $('#saveMsg').textContent;}"
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
# (тесты добавляются по одному на каждую правку m22)
async def touch(cdp,typ,pts):await cdp.send('Input.dispatchTouchEvent',{'type':typ,'touchPoints':[{'x':x,'y':y,'id':i} for (i,x,y) in pts]})
@test('Q01')
async def q01(b):
    # телефон, альбом: касание по тексту карточки узла начинает стик и двигает корабль; кнопка карточки по-прежнему работает
    P=await P0(b,vw=844,vh=390,touch=True);cdp=await P.pg.context.new_cdp_session(P.pg)
    pt=await P.js("()=>{T.fresh();T.openAll();G.dev.god=true;const n=WORLD.nodes[4];enterWorldAt(n.x,n.y+60);for(let i=0;i<30;i++)worldUpdate(1/60);updateWorldHUD();touchMode=true;$('#touch').hidden=false;const c=$('#wcard');if(c.hidden)return null;const h=c.querySelector('h3').getBoundingClientRect();return [h.x+8,h.y+h.height/2,stickZone(h.x+8,h.y+h.height/2)];}")
    if not pt:rec('Q01 карточка узла пропускает касание к стику',False,'card hidden');return
    a=await P.js("()=>[G.player.x,G.player.y]")
    await touch(cdp,'touchStart',[(1,pt[0],pt[1])])
    for s in range(12):await touch(cdp,'touchMove',[(1,pt[0]+5*s,pt[1]-3*s)]);await P.wait(30)
    await P.wait(400)
    m=await P.js("()=>[joy.on,G.player.x,G.player.y]")
    await touch(cdp,'touchEnd',[]);await P.wait(100)
    import math
    moved=math.hypot(m[1]-a[0],m[2]-a[1])
    # кнопка «Войти» по-прежнему кликается
    btn=await P.js("()=>{const n=WORLD.nodes[4];enterWorldAt(n.x,n.y+60);for(let i=0;i<30;i++)worldUpdate(1/60);updateWorldHUD();const b=$('#wcard [data-act]');if(!b)return null;const r=b.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2,b.dataset.act];}")
    st=None
    if btn:
        await touch(cdp,'touchStart',[(2,btn[0],btn[1])]);await touch(cdp,'touchEnd',[]);await P.wait(200);st=await P.js("()=>G.state")
    rec('Q01 карточка узла пропускает касание к стику, кнопка карточки работает',pt[2] and m[0] and moved>60 and st in ('intro','play','levelup'),{'pt':pt,'joy':m[0],'moved':round(moved),'btn':btn,'st':st,'errs':P.errs[:2]})

@test('Q02')
async def q02(b):
    # новая версия = чистое хранилище браузера; прогресс возвращается из облачной копии (личная папка игрока)
    P=await P0(b,init=FAKE({}),alpha=False);await P.wait(400)
    m=await P.js(LOADUI,C49);await P.wait(600)
    st=await P.js("()=>({cloud:CLOUD.state,log:window.__fakeLog.length,store:window.__fake})")
    body=st['store'].get('data/users/u_test/save')
    await P.pg.context.close()
    P2=await P0(b,init=FAKE(st['store']),alpha=False);await P2.wait(700)
    r=await P2.js("()=>{const lab=$('#bWorld').textContent;$('#bWorld').click();return {lab,state:G.state,done:doneCount(),cleared:G.save.cleared,toast:$('#toast').textContent.slice(0,60),rec:$('#recLine').textContent};}")
    rec('Q02 новая версия с чистым браузером получает прогресс из облака',bool(body) and body.get('done')==49 and 'ПРОДОЛЖИТЬ' in r['lab'] and r['done']==49 and r['state'] in ('world','levelup'),{'msg':m[:60],'cloud':st['cloud'],'pushes':st['log'],'bodyDone':body and body.get('done'),**r,'errs':P2.errs[:2]})
@test('Q03')
async def q03(b):
    # браузер не даёт записывать (встроенное окно/приватный режим): загруженный код всё равно работает в этой вкладке
    P=await P0(b,init="(()=>{const f=function(){throw new DOMException('blocked','QuotaExceededError');};Storage.prototype.setItem=f;})();",alpha=False,clear=False);await P.wait(300)
    m=await P.js(LOADUI,C49)
    r=await P.js("()=>{toMenu();const lab=$('#bWorld').textContent;$('#bWorld').click();return {lab,state:G.state,done:doneCount(),rec:(toMenu(),$('#recLine').textContent)};}")
    rec('Q03 код работает, даже если браузер запрещает запись',('загружен' in m) and r['done']==49 and 'СОХРАНИТЕ КОД' in r['rec'],{'msg':m[:120],**r,'errs':P.errs[:2]})
@test('Q04')
async def q04(b):
    # вставка из чата/мессенджера: кавычки, неразрывный и невидимый пробел, текст вокруг, переносы, url-safe
    P=await P0(b,alpha=False);out={}
    c=C49
    V={'quoted':'"'+c+'"','nbsp':c[:100]+' '+c[100:],'zwsp':c[:50]+'​'+c[50:],'prefix':'Код загрузки: '+c+' — вставь в игру','newlines':'\n'.join(c[i:i+76] for i in range(0,len(c),76)),'backticks':'```\n'+c+'\n```','urlsafe':c.replace('+','-').replace('/','_')}
    for k,v in V.items():
        msg=await P.js(LOADUI,v);d=await P.js("()=>{const S=store('void_world');return S?worldDone(S):-1;}")
        out[k]=('загружен' in msg) and d==49
        await P.js("()=>{LS.removeItem('void_world');G.save=null;return 1;}")
    bad=await P.js(LOADUI,'не код вовсе')
    rec('Q04 код из чата загружается с кавычками, пробелами и текстом вокруг',all(out.values()) and 'не распознан' in bad,{**out,'bad':bad[:50],'errs':P.errs[:2]})
@test('Q05')
async def q05(b):
    # правила «облако или браузер»
    P=await P0(b,alpha=False)
    r=await P.js("""()=>{const now=Date.now();const WS={};for(const n of [0,3,5,10,20,49]){T.fresh();const S=G.save;S.cleared=Math.min(n,10);for(let m=1;m<=n;m++)S.medals[m]={clear:1};WS[n]=JSON.stringify(S);}
      const W=n=>WS[n];const body=(n,t,f)=>({t,force:f||0,done:n,keys:{void_world:W(n)}});const out={};
      {const B=body(49,now-1e6);LS.setItem('void_world',W(0));metaSet({t:now,force:0});out.freshVsCloud49=cloudWinner(B);}
      {const B=body(49,now-1000);LS.setItem('void_world',W(3));metaSet({t:now,force:now});out.newFlightVsCloud49=cloudWinner(B);}
      {const B=body(0,now,now);LS.setItem('void_world',W(20));metaSet({t:now-5000,force:0});out.cloudResetNewer=cloudWinner(B);}
      {const B=body(10,now+5000);LS.setItem('void_world',W(20));metaSet({t:now,force:0});out.localMore=cloudWinner(B);}
      {const B1=body(20,now+5000),B2=body(20,now-5000);LS.setItem('void_world',W(20));metaSet({t:now,force:0});out.sameNewerCloud=cloudWinner(B1);out.sameOlderCloud=cloudWinner(B2);}
      {const B=body(5,1);LS.removeItem('void_world');metaSet({t:0,force:0});out.emptyLocal=cloudWinner(B);}return out;}""")
    exp={'freshVsCloud49':'cloud','newFlightVsCloud49':'local','cloudResetNewer':'cloud','localMore':'local','sameNewerCloud':'cloud','sameOlderCloud':'local','emptyLocal':'cloud'}
    rec('Q05 правила синхронизации: больший прогресс и явные действия побеждают',r==exp,{'got':r,'errs':P.errs[:2]})
@test('Q06')
async def q06(b):
    # «новый полёт» перекрывает облако, старый прогресс не воскресает
    store={}
    P=await P0(b,init=FAKE(store),alpha=False);await P.wait(400);await P.js(LOADUI,C49);w1=await waitFor(P,"()=>{const b=(window.__fake||{})['data/users/u_test/save'];return !!b&&b.done===49;}",15000)  # kit6: облако получило 49
    st=await P.js("()=>window.__fake");await P.pg.context.close()
    P2=await P0(b,init=FAKE(st),alpha=False);await P2.wait(700);w2=await waitFor(P2,"()=>typeof CLOUD!=='undefined'&&CLOUD.state==='ready'&&!CLOUD.waiters.length",15000)  # kit6: начальная синхронизация облака завершена
    a=await P2.js("()=>doneCount()")
    await P2.js("()=>{toMenu();$('#bWorldNew').click();$('#bWorldNew').click();return G.state;}");w3=await waitFor(P2,"()=>{const b=(window.__fake||{})['data/users/u_test/save'];return !!b&&b.done===0;}",15000);await P2.wait(500)  # kit6: запись «новый полёт» дошла до облака, затем прежние 500 мс — ничего не воскресло
    st2=await P2.js("()=>window.__fake");await P2.pg.context.close()
    P3=await P0(b,init=FAKE(st2),alpha=False);await P3.wait(700);w4=await waitFor(P3,"()=>typeof CLOUD!=='undefined'&&CLOUD.state==='ready'&&!CLOUD.waiters.length",15000)
    c=await P3.js("()=>({done:G.save?doneCount():0,lab:$('#bWorld').textContent})")
    body=st2.get('data/users/u_test/save',{})
    rec('Q06 новый полёт перекрывает облако — прогресс 49 не воскресает',a==49 and body.get('done')==0 and c['done']==0,{'restored':a,'cloudDone':body.get('done'),'force':bool(body.get('force')),**c,'errs':P3.errs[:2],'kit6_wait_ms':[w1,w2,w3,w4]})
@test('Q07')
async def q07(b):
    # туман войны: цепочка миссий, стена на всю высоту мира, прыжки, карта
    P=await P0(b,alpha=False)
    r=await P.js("""()=>{T.fresh();const S=G.save,p=G.player;G.dev.god=true;const out={};
      const fly=(x,y,tx,ty,n)=>{p.x=x;p.y=y;p.px=x;p.py=y;camSnap();for(let i=0;i<n;i++){steer2(tx,ty);worldUpdate(1/60);}for(const k of KK)KEYS[k]=false;return Math.round(p.x);};
      out.chain0=[1,2,7,11,50].map(nodeState).join(',');
      out.topBypass=fly(4600,12500,6500,12500,420);              // сверху ворот II — стена держит
      S.cleared=6;out.seen6=fogSeeX();out.gateStill=fly(4600,12500,6500,12500,420);   // туман поднят, но ворота — замки
      S.gate=true;out.passII=fly(4600,17000,6500,17000,420);
      out.wallIII=fly(9700,15000,11500,15000,420);               // сектор III закрыт до миссии 10
      S.cleared=10;out.postWall=fly(9700,15000,11500,15000,420);out.chainPost=[10,11].map(nodeState).join(',');S.post={done:1,open3:0,best:0,freezes:0,logs:[]};FOGC.k=null;out.passIII=fly(9700,15000,11500,15000,420);   // 1.2.0: после 10 проход скован льдом до поста «Изморозь»
      out.wallIV=fly(13100,13000,14500,13000,420);
      const jp=jumpPoints().map(q=>q.label);out.jumpNoIV=!jp.includes('IV')&&jp.includes('III');
      out.revealBeyond=(revealAround(14500,11000,800),revealedAt(14500,11000));
      out.chain=[10,11,12].map(nodeState).join(',');
      for(let m=11;m<=48;m++)S.medals[m]={clear:1};out.xii=[48,49,50].map(nodeState).join(',')+'|'+zeroOpen110();
      renderWorld(performance.now());openMap('map');drawMap();closeMap();return out;}""")
    ok=(r['chain0']=='open,locked,locked,locked,locked' and r['topBypass']<5000 and r['seen6']==10000 and r['gateStill']<5000 and r['passII']>5600
        and 9000<r['wallIII']<10000 and 9000<r['postWall']<10000 and r['chainPost']=='done,locked' and r['passIII']>10500 and 12500<r['wallIV']<13400 and r['jumpNoIV'] and not r['revealBeyond'] and r['chain']=='done,open,locked' and r['xii'].startswith('done,open,locked|false'))
    rec('Q07 туман войны: миссии по цепочке, стена держит и сверху, проход в III — после поста, прыжки и карта',ok,{**r,'errs':P.errs[:2]})
@test('Q08')
async def q08(b):
    # сохранение альфы: ворота II не открыты, корабль в закрытом секторе — исправляется при входе
    P=await P0(b,alpha=False)
    r=await P.js("""()=>{T.fresh();const S=G.save;S.cleared=10;S.gate=false;for(let m=11;m<=30;m++)S.medals[m]={clear:1};S.pos={x:35000,y:10000};saveWorld();
      LS.setItem('void_world',JSON.stringify(Object.assign(JSON.parse(LS.getItem('void_world')),{pos:{x:35000,y:10000}})));toMenu();startWorld(false);
      return {gate:G.save.gate,x:Math.round(G.player.x),fx:fogX(),n31:nodeState(31),n32:nodeState(32),n29:nodeState(29)};}""")
    rec('Q08 сохранение альфы: ворота II открыты по прогрессу, корабль переносится из тумана',r['gate'] and r['x']<r['fx'] and r['n31']=='open' and r['n32']=='locked' and r['n29']=='done',{**r,'errs':P.errs[:2]})
@test('Q09')
async def q09(b):
    # закрытая миссия: нет карточки входа, колодец не подпускает к маяку (1.2.3: ≥170); открытая — карточка есть
    P=await P0(b,alpha=False)
    r=await P.js("""()=>{T.fresh();const S=G.save;S.cleared=1;const out={};const near=m=>{const n=WORLD.nodes[m-1];enterWorldAt(n.x,n.y+60);for(let i=0;i<20;i++)worldUpdate(1/60);updateWorldHUD();return {card:!$('#wcard').hidden&&$('#wcard').textContent.slice(0,40),d:Math.round(Math.hypot(G.player.x-n.x,G.player.y-n.y))};};
      out.m2=near(2);out.m3=near(3);return out;}""")
    rec('Q09 закрытая миссия без карточки и под помехами, открытая — с карточкой',bool(r['m2']['card']) and not r['m3']['card'] and r['m3']['d']>=170,{**r,'errs':P.errs[:2]})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'../kit6/out/q130.json'))
