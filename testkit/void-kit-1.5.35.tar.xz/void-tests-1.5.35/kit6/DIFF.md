# kit6 — отличия от исторических наборов kit/
Сгенерировано tools6/mkkit6.py. Исторические наборы в kit/ не изменены и остаются проверкой прежних сборок.

## q170.py
исходный kit/q170.py sha256 09e9a02cb48bb191 → kit6/q170.py sha256 0ce2bd1a9cb159ff
```diff
--- kit/q170.py
+++ kit6/q170.py
@@ -1 +1,2 @@
+# kit6 · новая версия набора kit/q170.py (корректирующее обновление 1.5.35); исторический файл не изменён. Отличия — kit6/DIFF.md.
 # 1.2.3 α «Без позывного»: курс тарана, колодец закрытой миссии, погоня патруля. Каждый тест падает на 1.2.2 (версия 23).
@@ -3,2 +4,3 @@
 from h import *
+SEED6="(()=>{let a=2;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};})();"
 TESTS=[]
@@ -120,3 +122,5 @@
     # после гибели двойника патруль разворачивается на игрока
-    P=await newpage(b)
+    # kit6: игровой Math.random засеян (seed 2) до загрузки страницы. Состав патруля выбирается случайно (chaseDev); на 10 семенах обе сборки
+    # дают побитно одинаковый исход, а 3 из 10 составов не проходят условие на обеих (out7/c03seed). Без семени тест был лотереей.
+    P=await newpage(b,init=SEED6)
     r=await P.js("""()=>{if(typeof chaseDev!=='function')return {ok:false};"""+CH0+NEAR+"""near();chaseTo(10,()=>c.ph==='fight');
@@ -153,2 +157,2 @@
     sel=sys.argv[1:]
-    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q170.json'))
+    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'../kit6/out/q170.json'))
```

## q130.py
исходный kit/q130.py sha256 8cb1030cb886323c → kit6/q130.py sha256 42b40b6e7db91fa4
```diff
--- kit/q130.py
+++ kit6/q130.py
@@ -1 +1,2 @@
+# kit6 · новая версия набора kit/q130.py (корректирующее обновление 1.5.35); исторический файл не изменён. Отличия — kit6/DIFF.md.
 # 1.0 QA: тесты на каждое исправление из батареи qa1000 (группа Q). Каждый тест падает на сборке до правки.
@@ -3,2 +4,11 @@
 from h import *
+
+async def waitFor(P,cond,ms):
+    # kit6: ожидание УСЛОВИЯ (опрос каждые 50 мс) вместо фиксированной паузы; возвращает мс до выполнения или None (не дождались)
+    import time as _t
+    t0=_t.time()
+    while (_t.time()-t0)*1000<ms:
+        if await P.js(cond):return round((_t.time()-t0)*1000)
+        await P.wait(50)
+    return None
 QA_SRC=open(SP+'qa1000.py').read()
@@ -92,12 +102,12 @@
     store={}
-    P=await P0(b,init=FAKE(store),alpha=False);await P.wait(400);await P.js(LOADUI,C49);await P.wait(500)
+    P=await P0(b,init=FAKE(store),alpha=False);await P.wait(400);await P.js(LOADUI,C49);w1=await waitFor(P,"()=>{const b=(window.__fake||{})['data/users/u_test/save'];return !!b&&b.done===49;}",15000)  # kit6: облако получило 49
     st=await P.js("()=>window.__fake");await P.pg.context.close()
-    P2=await P0(b,init=FAKE(st),alpha=False);await P2.wait(700)
+    P2=await P0(b,init=FAKE(st),alpha=False);await P2.wait(700);w2=await waitFor(P2,"()=>typeof CLOUD!=='undefined'&&CLOUD.state==='ready'&&!CLOUD.waiters.length",15000)  # kit6: начальная синхронизация облака завершена
     a=await P2.js("()=>doneCount()")
-    await P2.js("()=>{toMenu();$('#bWorldNew').click();$('#bWorldNew').click();return G.state;}");await P2.wait(500)
+    await P2.js("()=>{toMenu();$('#bWorldNew').click();$('#bWorldNew').click();return G.state;}");w3=await waitFor(P2,"()=>{const b=(window.__fake||{})['data/users/u_test/save'];return !!b&&b.done===0;}",15000);await P2.wait(500)  # kit6: запись «новый полёт» дошла до облака, затем прежние 500 мс — ничего не воскресло
     st2=await P2.js("()=>window.__fake");await P2.pg.context.close()
-    P3=await P0(b,init=FAKE(st2),alpha=False);await P3.wait(700)
+    P3=await P0(b,init=FAKE(st2),alpha=False);await P3.wait(700);w4=await waitFor(P3,"()=>typeof CLOUD!=='undefined'&&CLOUD.state==='ready'&&!CLOUD.waiters.length",15000)
     c=await P3.js("()=>({done:G.save?doneCount():0,lab:$('#bWorld').textContent})")
     body=st2.get('data/users/u_test/save',{})
-    rec('Q06 новый полёт перекрывает облако — прогресс 49 не воскресает',a==49 and body.get('done')==0 and c['done']==0,{'restored':a,'cloudDone':body.get('done'),'force':bool(body.get('force')),**c,'errs':P3.errs[:2]})
+    rec('Q06 новый полёт перекрывает облако — прогресс 49 не воскресает',a==49 and body.get('done')==0 and c['done']==0,{'restored':a,'cloudDone':body.get('done'),'force':bool(body.get('force')),**c,'errs':P3.errs[:2],'kit6_wait_ms':[w1,w2,w3,w4]})
 @test('Q07')
@@ -141,2 +151,2 @@
     sel=sys.argv[1:]
-    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q130.json'))
+    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'../kit6/out/q130.json'))
```

## q220.py
исходный kit/q220.py sha256 48268d43cd17844b → kit6/q220.py sha256 0d9d171f3f34f34d
```diff
--- kit/q220.py
+++ kit6/q220.py
@@ -1 +1,2 @@
+# kit6 · новая версия набора kit/q220.py (корректирующее обновление 1.5.35); исторический файл не изменён. Отличия — kit6/DIFF.md.
 # 1.2.8 α: музыка меню сразу, обучение 2.0 (калибровка, допуск пилота, показы), кнопки меню на телефоне, громкость звуков. Каждый тест падает на версии 29.
@@ -8,4 +9,6 @@
 NEW="""async(o)=>{o=o||{};window.w8=ms=>new Promise(r=>setTimeout(r,ms));if(typeof TUT==='undefined'||typeof TUT_SK==='undefined')return false;T.fresh();if(o.touch)setInput('touch');
-  for(let i=0;i<40&&(G.prologue||G.state!=='world');i++)await w8(100);TUT.hist=[];TUT.gap=0;TUT.log=[];
-  window.waitCur=async(k,ms)=>{const t0=performance.now();while(performance.now()-t0<(ms||4000)){if(TUT.cur&&TUT.cur.k===k)return true;await w8(50);}return false;};return true;}"""
+  for(let i=0;i<200&&(G.prologue||G.state!=='world');i++)await w8(100);TUT.hist=[];TUT.gap=0;TUT.log=[];
+  window.waitCur=async(k,ms)=>{const t0=performance.now();while(performance.now()-t0<(ms||4000)){if(TUT.cur&&TUT.cur.k===k&&(k!=='calib'||(TUT.cal&&TUT.cal.pts&&TUT.cal.pts.length))){window.__wc=performance.now()-t0;return true;}await w8(50);}return false;};
+  window.w8s=async ms=>{const n0=ARCH.steps74,need=Math.round(ms*60/1000),t0=performance.now();while(ARCH.steps74-n0<need&&performance.now()-t0<120000)await w8(10);};/* kit6: ожидание в ШАГАХ игры (ms·60/1000), а не в мс настоящего времени */
+  return true;}"""
 STRICT="""window.__gest=false;addEventListener('pointerdown',()=>{window.__gest=true;},true);addEventListener('keydown',()=>{window.__gest=true;},true);
@@ -52,5 +55,5 @@
     P=await newpage(b,1600,900,alpha=False);ok0=await P.js(NEW,{})
-    r=await P.js("""async()=>{const on=await waitCur('calib',4000);const K=TUT.cal,p=G.player,ii=[];for(let i=0;i<3;i++){p.x=K.pts[i].x;p.y=K.pts[i].y;await w8(150);ii.push(K.i);}
-      p.x=K.gate.x-K.dx*40;p.y=K.gate.y-K.dy*40;await w8(120);p.x=K.gate.x+K.dx*40;p.y=K.gate.y+K.dy*40;await w8(200);const fail=[K.gate.fails,!!G.save.tut.done.calib];
-      p.x=K.gate.x-K.dx*90;p.y=K.gate.y-K.dy*90;await w8(150);p.dashCd=0;tryDash([K.dx,K.dy]);await w8(500);const T=G.save.tut;
+    r=await P.js("""async()=>{const on=await waitCur('calib',20000);const K=TUT.cal,p=G.player,ii=[];for(let i=0;i<3;i++){p.x=K.pts[i].x;p.y=K.pts[i].y;await w8s(150);ii.push(K.i);}
+      p.x=K.gate.x-K.dx*40;p.y=K.gate.y-K.dy*40;await w8s(120);p.x=K.gate.x+K.dx*40;p.y=K.gate.y+K.dy*40;await w8s(200);const fail=[K.gate.fails,!!G.save.tut.done.calib];
+      p.x=K.gate.x-K.dx*90;p.y=K.gate.y-K.dy*90;await w8s(150);p.dashCd=0;tryDash([K.dx,K.dy]);await w8s(500);const T=G.save.tut;
       return {on,ii,fail,done:T.done,ok:T.ok,sk:!$('#tutSk').hidden&&$('#tutSk').textContent,cur:TUT.cur&&TUT.cur.k}}""") if ok0 else {}
@@ -62,3 +65,3 @@
     P=await newpage(b,390,844,alpha=False,touch=True);ok0=await P.js(NEW,{'touch':1})
-    r=await P.js("""async()=>{const on=await waitCur('calib',4000);await w8(300);const ch=document.querySelector('#tut .tut-chip').getBoundingClientRect(),I=$('#joyIdle').getBoundingClientRect();
+    r=await P.js("""async()=>{const on=await waitCur('calib',20000);await w8(300);const ch=document.querySelector('#tut .tut-chip').getBoundingClientRect(),I=$('#joyIdle').getBoundingClientRect();
       const K=TUT.cal,p=G.player;for(let i=0;i<3;i++){p.x=K.pts[i].x;p.y=K.pts[i].y;await w8(150);}await w8(300);const rg=document.querySelector('#tut .tut-ring.on'),d=$('#tDash').getBoundingClientRect();
@@ -71,3 +74,3 @@
     P=await newpage(b,1600,900,alpha=False);ok0=await P.js(NEW,{})
-    r=await P.js("""async()=>{await waitCur('calib',4000);const K=TUT.cal,p=G.player;p.x=K.pts[0].x-K.dx*2100;p.y=K.pts[0].y-K.dy*2100;const t0=performance.now();while(performance.now()-t0<14000&&!G.save.tut.done.calib){await w8(200);}
+    r=await P.js("""async()=>{await waitCur('calib',20000);const K=TUT.cal,p=G.player;p.x=K.pts[0].x-K.dx*2100;p.y=K.pts[0].y-K.dy*2100;const s0=ARCH.steps74,t0=performance.now();while(ARCH.steps74-s0<14*60&&performance.now()-t0<180000&&!G.save.tut.done.calib){await w8(50);}/* kit6: 14 с игры, не настоящего времени */
       const T=G.save.tut,K2=TUT.cal;return {calib:!!T.done.calib,okDash:!!(T.ok&&T.ok.dash),cur:TUT.cur&&TUT.cur.k,near:!!K2&&Math.hypot(K2.pts[0].x-G.player.x,K2.pts[0].y-G.player.y)<1500}}""") if ok0 else {}
@@ -87,3 +90,3 @@
         P=await newpage(b,vw,vh,alpha=False,touch=tch);await P.js(NEW,{'touch':1} if tch else {})
-        out[inp]=await P.js("""async(inp)=>{if(inp==='pad')setInput('pad');const C0=await waitCur('calib',4000);const x=document.querySelector('#tut .tut-x');x.dispatchEvent(new MouseEvent('click',{bubbles:true}));await w8(200);
+        out[inp]=await P.js("""async(inp)=>{if(inp==='pad')setInput('pad');const C0=await waitCur('calib',20000);const x=document.querySelector('#tut .tut-x');x.dispatchEvent(new MouseEvent('click',{bubbles:true}));await w8(200);
           const n=tutSkillN(),okc=!!(G.save.tut.ok&&G.save.tut.ok.calib);pause();await w8(200);const card=$('#tutCard');const row=[...card.querySelectorAll('.tcard-r')].find(r=>r.textContent.includes('РЫВОК'));
@@ -115,2 +118,2 @@
     sel=sys.argv[1:]
-    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q220.json'))
+    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'../kit6/out/q220.json'))
```

## q310.py
исходный kit/q310.py sha256 21af2a84aa62baf6 → kit6/q310.py sha256 d57c89e5ddf55249
```diff
--- kit/q310.py
+++ kit6/q310.py
@@ -1 +1,2 @@
+# kit6 · новая версия набора kit/q310.py (корректирующее обновление 1.5.35); исторический файл не изменён. Отличия — kit6/DIFF.md.
 # 1.4.1 α «Пульт»: настройки по вкладкам с пояснениями, пауза со сводкой. L01–L13 падают на v37 (1.4.0).
@@ -34,4 +35,6 @@
         out[w]=await P.js("async()=>{"+OPEN+"return ['zoom','quality','fps'].map(k=>!!document.querySelector(`#setBody [data-seg=\"${k}\"]`))}")
-    ok=out[1280]==[False,False,False] and out[390]==[True,True,True]
-    rec('L03 «Масштаб», «Качество», «Кадры» работают только на телефоне — на ПК их нет, на телефоне есть',ok,out)
+    # kit6: с ARCH·90b (1.5.32, решение владельца Р2) «Кадры» есть и на ПК; без него — прежнее ожидание (проверка 1.5.24 не меняется)
+    v90b='ARCH·90b' in open(GAME.replace('file://',''),encoding='utf8').read()
+    ok=out[1280]==[False,False,v90b] and out[390]==[True,True,True]
+    rec('L03 «Масштаб», «Качество» только на телефоне; «Кадры» — только на телефоне до ARCH·90b, с ARCH·90b и на ПК',ok,{**out,'ARCH·90b':v90b})
 
@@ -121,2 +124,2 @@
     if sel:TESTS=[t for t in TESTS if t[0] in sel]
-    asyncio.run(run(TESTS,'q310'))
+    asyncio.run(run(TESTS,'../kit6/out/q310'))
```

## q370.py
исходный kit/q370.py sha256 29c4d302619f81ba → kit6/q370.py sha256 72ab52e43edbacaf
```diff
--- kit/q370.py
+++ kit6/q370.py
@@ -1 +1,2 @@
+# kit6 · новая версия набора kit/q370.py (корректирующее обновление 1.5.35); исторический файл не изменён. Отличия — kit6/DIFF.md.
 # 1.5.9 α «Опора» · этап 0 (стенд доказательств) + этап 1 (дефекты). Сборки: эталон 1.5.8 (void_v46), новая «вкл», новая «выкл» (__archOff).
@@ -4,2 +5,24 @@
 from h import *
+
+# kit6: точный допуск ARCH·86 — только доказанное слияние 4 цепочек (tools6/archcheck6.py) и структурное доказательство (tools6/merge86.js
+# против 1.5.24 builds5/void_b164.html); мутанты tools6/mut86.py обязаны быть отвергнуты. Без метки ARCH·86 — прежняя проверка.
+R6=os.path.normpath(os.path.join(SP,'..'))
+def arch86(html,v2):
+    import tempfile
+    env=dict(os.environ,ARCHCHECK_V2='1') if v2 else {k:v for k,v in os.environ.items() if k!='ARCHCHECK_V2'}
+    base=SP+('arch_fp_v47v2.json' if v2 else 'arch_fp_v46.json');ex=os.path.join(R6,'kit6','data','arch_exact86v2.json' if v2 else 'arch_exact86.json')
+    al=SP+('arch_allow_70_74.json' if v2 else 'arch_allow_74.json');A6=[sys.executable,os.path.join(R6,'tools6','archcheck6.py'),'diff',base]
+    r=subprocess.run(A6+[html,al,'--exact',ex],capture_output=True,text=True,env=env)
+    mg=subprocess.run(['node',os.path.join(R6,'tools6','merge86.js'),os.path.join(R6,'builds5','void_b164.html'),html],capture_output=True,text=True)
+    td=tempfile.mkdtemp(prefix='mut86_');mk=subprocess.run([sys.executable,os.path.join(R6,'tools6','mut86.py'),html,td],capture_output=True,text=True)
+    mut={}
+    if mk.returncode==0:
+        for m,p in json.loads(mk.stdout).items():
+            a=subprocess.run(A6+[p,al,'--exact',ex],capture_output=True,text=True,env=env).returncode
+            g=subprocess.run(['node',os.path.join(R6,'tools6','merge86.js'),os.path.join(R6,'builds5','void_b164.html'),p],capture_output=True,text=True).returncode
+            mut[m]={'archcheck6':a,'merge86':g}
+    import shutil;shutil.rmtree(td,ignore_errors=True)
+    # archcheck видит только начало строки слоя: m86_post (перенос вызова внутри слоя) ловит merge86, не отпечаток — это ожидаемо
+    mok=mk.returncode==0 and set(mut)=={'m86_merged','m86_other','m86_post','m86_behav'} and all(mut[m]['archcheck6']==1 for m in ('m86_merged','m86_other','m86_behav')) and all(v['merge86']==1 for v in mut.values())
+    return {'archcheck6':r.returncode,'нарушения':r.stdout.strip()[:400],'merge86':mg.returncode,'merge86_err':mg.stdout[-300:] if mg.returncode else '','мутанты':mut,'мутанты_ok':mok},(r.returncode==0 and mg.returncode==0 and mok)
 TESTS=[]
@@ -57,2 +80,5 @@
     html=NEW.replace('file://','')
+    if 'ARCH·86' in open(html,encoding='utf8').read():
+        info,ok=arch86(html,False)
+        rec('A02 (kit6) отпечаток цепочек и владельцев G: изменены только 4 цепочки ARCH·86 и ровно доказанным слиянием (archcheck6 + merge86 против 1.5.24); мутанты слияния и посторонней цепочки отвергнуты',ok,info);return
     r=subprocess.run(['python3',SP+'archcheck.py','diff',SP+'arch_fp_v46.json',html,SP+(lambda s:'arch_allow_74.json' if 'ARCH·73' in s else 'arch_allow_69_70.json' if 'ARCH·70' in s else 'arch_allow_69.json')(open(html,encoding='utf8').read())],capture_output=True,text=True)
@@ -172,6 +198,6 @@
 async def a13(b):
-    code="""async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();G.save.tut.off=1;await w8(300);let n=0;const dm=drawMap;drawMap=function(){n++;return dm.apply(this,arguments);};
-      openMap('map');await w8(1000);const a=n;n=0;for(let i=0;i<4;i++)mapTab('map');await w8(1000);const b_=n;n=0;mapTab('jr');await w8(200);mapTab('map');await w8(1000);const c=n;closeMap&&closeMap();await w8(100);n=0;await w8(500);return {once:a,after4:b_,afterSwitch:c,afterClose:n};}"""
+    code="""async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();G.save.tut.off=1;await w8(300);let n=0,tk=0;const dm=drawMap;drawMap=function(){n++;return dm.apply(this,arguments);};const RAF=window.requestAnimationFrame;(function tick(){tk++;RAF(tick);})();/* kit6: тики rAF */
+      openMap('map');await w8(1000);const a=n,ta=tk;n=0;tk=0;for(let i=0;i<4;i++)mapTab('map');const s4=n;await w8(1000);const b_=n,tb=tk;n=0;mapTab('jr');await w8(200);mapTab('map');await w8(1000);const c=n;closeMap&&closeMap();await w8(100);n=0;await w8(500);return {once:a,after4:b_,afterSwitch:c,afterClose:n,perTickOnce:+(a/Math.max(1,ta)).toFixed(2),perTickAfter4:+((b_-s4)/Math.max(1,tb)).toFixed(2),syncDraws:s4};}"""
     o={k:(await run_in(b,u,code,i))[0] for k,u,i in VARIANTS}
-    good=lambda r:abs(r['after4']-r['once'])<=r['once']*.25+2 and r['afterClose']==0
+    good=lambda r:r['perTickAfter4']<=1.3 and r['afterClose']==0  # kit6: отрисовок карты на тик rAF после 4 нажатий (без синхронных отрисовок самих нажатий); второй цикл даёт ≈2 и больше
     rec('A13 карта (A-1): повторные нажатия вкладки «Карта» не запускают второй цикл отрисовки (1.5.8 и «выкл»: в ~3 раза чаще)',good(o['on']) and not good(o['base']) and not good(o['off']),o)
@@ -216,2 +242,2 @@
     sel=sys.argv[1:]
-    asyncio.run(run([t for t in TESTS if not sel or t[0] in sel],'res370.json'))
+    asyncio.run(run([t for t in TESTS if not sel or t[0] in sel],'../kit6/out/res370.json'))
```

## q380.py
исходный kit/q380.py sha256 d0207fa9e7dd24ab → kit6/q380.py sha256 870cd30e6a13a0e4
```diff
--- kit/q380.py
+++ kit6/q380.py
@@ -1 +1,2 @@
+# kit6 · новая версия набора kit/q380.py (корректирующее обновление 1.5.35); исторический файл не изменён. Отличия — kit6/DIFF.md.
 # 1.5.10 α «Ровно» · этап 2 (ARCH·70). Сборки: base = 1.5.9 (void_v47), on = кандидат, off = кандидат со всеми флагами A-5…A-13 выключенными.
@@ -4,2 +5,24 @@
 from h import *
+
+# kit6: точный допуск ARCH·86 — только доказанное слияние 4 цепочек (tools6/archcheck6.py) и структурное доказательство (tools6/merge86.js
+# против 1.5.24 builds5/void_b164.html); мутанты tools6/mut86.py обязаны быть отвергнуты. Без метки ARCH·86 — прежняя проверка.
+R6=os.path.normpath(os.path.join(SP,'..'))
+def arch86(html,v2):
+    import tempfile
+    env=dict(os.environ,ARCHCHECK_V2='1') if v2 else {k:v for k,v in os.environ.items() if k!='ARCHCHECK_V2'}
+    base=SP+('arch_fp_v47v2.json' if v2 else 'arch_fp_v46.json');ex=os.path.join(R6,'kit6','data','arch_exact86v2.json' if v2 else 'arch_exact86.json')
+    al=SP+('arch_allow_70_74.json' if v2 else 'arch_allow_74.json');A6=[sys.executable,os.path.join(R6,'tools6','archcheck6.py'),'diff',base]
+    r=subprocess.run(A6+[html,al,'--exact',ex],capture_output=True,text=True,env=env)
+    mg=subprocess.run(['node',os.path.join(R6,'tools6','merge86.js'),os.path.join(R6,'builds5','void_b164.html'),html],capture_output=True,text=True)
+    td=tempfile.mkdtemp(prefix='mut86_');mk=subprocess.run([sys.executable,os.path.join(R6,'tools6','mut86.py'),html,td],capture_output=True,text=True)
+    mut={}
+    if mk.returncode==0:
+        for m,p in json.loads(mk.stdout).items():
+            a=subprocess.run(A6+[p,al,'--exact',ex],capture_output=True,text=True,env=env).returncode
+            g=subprocess.run(['node',os.path.join(R6,'tools6','merge86.js'),os.path.join(R6,'builds5','void_b164.html'),p],capture_output=True,text=True).returncode
+            mut[m]={'archcheck6':a,'merge86':g}
+    import shutil;shutil.rmtree(td,ignore_errors=True)
+    # archcheck видит только начало строки слоя: m86_post (перенос вызова внутри слоя) ловит merge86, не отпечаток — это ожидаемо
+    mok=mk.returncode==0 and set(mut)=={'m86_merged','m86_other','m86_post','m86_behav'} and all(mut[m]['archcheck6']==1 for m in ('m86_merged','m86_other','m86_behav')) and all(v['merge86']==1 for v in mut.values())
+    return {'archcheck6':r.returncode,'нарушения':r.stdout.strip()[:400],'merge86':mg.returncode,'merge86_err':mg.stdout[-300:] if mg.returncode else '','мутанты':mut,'мутанты_ok':mok},(r.returncode==0 and mg.returncode==0 and mok)
 from q370 import mission_js,ZB_JS
@@ -296,2 +319,5 @@
     newgen=[n for n in ['xorshift','mulberry(','0x6D2B79F5'] if js.count(n)!=open(SP+'void_v47.html',encoding='utf8').read().count(n)]
+    if 'ARCH·86' in s:  # kit6: 4 цепочки ARCH·86 — только доказанное слияние; прежние 11 — как раньше
+        got=[g for g in got if g not in ('renderSettings','renderSetScreen','tutEmit','tutMapDraw')];info,ok86=arch86(html,True)
+        rec('B10 (kit6) T1: archcheck v2 — прежние ожидаемые цепочки и 4 цепочки ARCH·86 ровно доказанным слиянием, новых владельцев G нет, новых генераторов нет',got==want and not newgen and ok86,{'прежние':got,'новые генераторы':newgen,**info});return
     rec('B10 T1: archcheck — изменены ровно 8 ожидаемых цепочек (sfx, zbMapStatic, musSched, v12Retune, makeImpulse, три HUD), новых владельцев G нет, новых генераторов нет',r.returncode==0 and got==want and not newgen,{'нарушения':v,'новые генераторы':newgen})
@@ -314,2 +340,2 @@
     sel=sys.argv[1:]
-    asyncio.run(run([t for t in TESTS if not sel or t[0] in sel],'res380.json'))
+    asyncio.run(run([t for t in TESTS if not sel or t[0] in sel],'../kit6/out/res380.json'))
```
