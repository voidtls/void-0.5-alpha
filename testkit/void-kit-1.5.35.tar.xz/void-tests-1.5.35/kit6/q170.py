# kit6 · новая версия набора kit/q170.py (корректирующее обновление 1.5.35); исторический файл не изменён. Отличия — kit6/DIFF.md.
# 1.2.3 α «Без позывного»: курс тарана, колодец закрытой миссии, погоня патруля. Каждый тест падает на 1.2.2 (версия 23).
import asyncio,json,sys,os
from h import *
SEED6="(()=>{let a=2;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};})();"
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
CH0="""T.fresh();const S=G.save;S.cleared=10;for(let m=1;m<=10;m++)S.medals[m]={clear:1};S.gate=true;saveWorld();
 const p0=WORLD.nodes.find(n=>n.m===5);enterWorldAt(p0.x+900,p0.y);revealAround(p0.x,p0.y,6000);G.calm=30;const p=G.player;for(let i=0;i<30;i++)worldUpdate(1/60);
 let ok=false;for(let k=0;k<25&&!ok;k++)ok=chaseDev();const c=CHS;"""
NEAR="""const near=()=>{p.x=c.d.x-Math.cos(c.d.ang)*900+Math.sin(c.d.ang)*300;p.y=c.d.y-Math.sin(c.d.ang)*900-Math.cos(c.d.ang)*300;p.vx=p.vy=0;for(let i=0;i<5;i++)worldUpdate(1/60);};
 const chaseTo=(sec,stop)=>{for(let i=0;i<60*sec;i++){steer2(c.d.x,c.d.y);p.hp=p.maxHp;worldUpdate(1/60);if(stop&&stop())break;}for(const k of KK)KEYS[k]=false;};"""
WELL0="""T.fresh();const S=G.save;S.cleared=2;for(let m=1;m<=2;m++)S.medals[m]={clear:1};saveWorld();const n=WORLD.nodes.find(q=>nodeState(q.m)==='locked');
 enterWorldAt(n.x+700,n.y);const p=G.player;"""

# ---------- курс тарана ----------
@test('P01')
async def p01(b):
    # длина курса = настоящий путь тарана вместе с заносом (±6%) на всех сложностях
    P=await newpage(b);out={}
    for d in ['easy','mid','hard']:
        r=await P.js("""(d)=>{T.fresh();T.openAll();G.save.diff=d;T.go(3);G.waveHold=999;G.enemies=[];G.eb=[];G.rocks=[];const p=G.player;
          const e=spawnEnemy('rammer',W*.08,H*.5,{noAffix:true});e.spawnT=0;e.st='aim';e.timer=.85;e.aim=0;let x0=null,mx=0,L=typeof ramStop==='function'?ramStop():0;
          for(let i=0;i<200;i++){p.x=W*.95;p.y=H*.5;p.vx=p.vy=0;p.inv=1;G.enemies=G.enemies.filter(q=>q===e);update(1/60);if(e.st==='aim'&&typeof ramStop==='function')L=ramStop();if(e.st==='charge'&&x0===null)x0=[e.x-e.vx/60,e.y-e.vy/60];if(x0!==null){mx=Math.max(mx,Math.hypot(e.x-x0[0],e.y-x0[1]));if(e.st==='seek')break;}}
          return {L:Math.round(L),run:Math.round(mx),k:+(G.eSpd||1).toFixed(2)};}""",d)
        out[d]=r
    ok=all(v['L']>0 and abs(v['L']-v['run'])/v['run']<.06 for v in out.values())
    rec('P01 курс тарана: длина совпадает с настоящим путём (рывок + занос) на всех сложностях',ok,{**out,'errs':P.errs[:2]})

@test('P02')
async def p02(b):
    # замах рисуется рельсами-курсом (teleLane), красного прямоугольника больше нет; курс фиксируется за 0,22 с и вспыхивает
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();G.save.diff='mid';T.go(3);G.waveHold=999;G.enemies=[];G.eb=[];const p=G.player;
      if(typeof teleLane!=='function')return {tl:false};let calls=[];const _t=teleLane;teleLane=function(){calls.push([arguments[6],!!(arguments[8]&&arguments[8].flash>0)]);return _t.apply(this,arguments);};
      const e=spawnEnemy('rammer',W*.2,H*.5,{noAffix:true});e.spawnT=0;e.st='aim';e.timer=.85;e.aim=0;const fr=[];const _f=ctx.fillRect;let red=0;
      ctx.fillRect=function(x,y,w,h){if(/ff4f6e|255, ?79/.test(String(ctx.fillStyle))&&w>200)red++;return _f.apply(this,arguments);};
      for(let i=0;i<50;i++){p.x=W*.8;p.y=H*.2+i*4;p.inv=1;G.enemies=G.enemies.filter(q=>q===e);update(1/60);if(e.st==='aim')fr.push([+e.timer.toFixed(3),+e.aim.toFixed(4)]);render(performance.now());}
      ctx.fillRect=_f;teleLane=_t;const late=fr.filter(q=>q[0]<=.2);return {tl:true,n:calls.length,locked:calls.some(q=>q[0]),flash:calls.some(q=>q[1]),red,frozen:late.length>1&&Math.abs(late[0][1]-late[late.length-1][1])<1e-3};}""")
    rec('P02 замах: рисуется курсом из рельсов, без красного прямоугольника; в конце курс фиксируется и вспыхивает',r.get('tl') and r['n']>20 and r['locked'] and r['flash'] and r['red']==0 and r['frozen'],{**r,'errs':P.errs[:2]})

@test('P03')
async def p03(b):
    # рывки Стража-0 и Дефекта тоже предупреждают курсом и замирают перед рывком
    P=await newpage(b)
    r=await P.js("""()=>{const src=[...document.scripts].map(s=>s.text).join('');const n=(src.match(/teleLane\\(/g)||[]).length;
      return {n,boss:/teleLane\\(b\\.x,b\\.y,b\\.ang,400/.test(src),def:/teleLane\\(e\\.x,e\\.y,e\\.aim,420/.test(src),bossLock:src.includes('if(R_.t>.22)b.ang+='),defLock:src.includes('if(e.rt>.22)e.aim+=')};}""")
    rec('P03 Страж-0 и Дефект: курс вместо прямоугольника, наведение замирает за 0,22 с до рывка',r['n']>=4 and r['boss'] and r['def'] and r['bossLock'] and r['defLock'],{**r,'errs':P.errs[:2]})

@test('P04')
async def p04(b):
    # на телефоне и в режиме «меньше эффектов» курс рисуется без ошибок
    P=await newpage(b,vw=390,vh=844,touch=True)
    r=await P.js("""()=>{T.fresh();T.openAll();SET.fx=false;T.go(3);G.waveHold=999;G.enemies=[];const p=G.player;const e=spawnEnemy('rammer',W*.3,H*.3,{noAffix:true});e.spawnT=0;e.st='aim';e.timer=.85;
      let err=null;try{for(let i=0;i<70;i++){p.inv=1;update(1/60);render(performance.now());}}catch(x){err=String(x);}SET.fx=true;return {err,lane:!!e.lane};}""")
    await P.pg.wait_for_timeout(300)
    rec('P04 телефон, эффекты выключены: курс рисуется, ошибок нет',not r['err'] and r['lane'] and not P.errs,{**r,'errs':P.errs[:2]})

# ---------- колодец закрытой миссии ----------
@test('W01')
async def w01(b):
    # в кольцо пускает: внутри радиуса 420 можно провести секунды, но центр (маяк) недостижим с любой стороны
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{"""+WELL0+"""const out=[];for(const a of [0,1.57,3.14,4.71]){p.x=n.x+Math.cos(a)*700;p.y=n.y+Math.sin(a)*700;p.vx=p.vy=0;let mn=1e9,inT=0;
      for(let i=0;i<60*8;i++){steer2(n.x,n.y);p.hp=p.maxHp;worldUpdate(1/60);const d=Math.hypot(p.x-n.x,p.y-n.y);mn=Math.min(mn,d);if(d<420)inT+=1/60;}for(const k of KK)KEYS[k]=false;out.push([Math.round(mn),+inT.toFixed(1)]);}
      return {out,st:G.state};}""")
    ok=all(170<=m<=380 and t>=3 for m,t in r['out']) and r['st']=='world'
    rec('W01 колодец: внутрь кольца пускает (секунды внутри 420), до центра не добраться ни с одной стороны',ok,{**r,'errs':P.errs[:2]})

@test('W02')
async def w02(b):
    # вязко, но не рывками: шаг кадра не больше обычной скорости; наружу выходит быстро
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{"""+WELL0+"""let mx=0,back=0;for(let i=0;i<60*6;i++){const x0=p.x,y0=p.y;steer2(n.x,n.y);worldUpdate(1/60);mx=Math.max(mx,Math.hypot(p.x-x0,p.y-y0));}
      const sp=G.st.speed/60;for(const k of KK)KEYS[k]=false;let t=0;for(let i=0;i<60*4;i++){steer2(n.x+4000,n.y);worldUpdate(1/60);t+=1/60;if(Math.hypot(p.x-n.x,p.y-n.y)>560)break;}for(const k of KK)KEYS[k]=false;
      return {mx:+mx.toFixed(2),sp:+sp.toFixed(2),exit:+t.toFixed(2),depth:G.well?1:0};}""")
    rec('W02 колодец: без телепортов (шаг ≤ обычной скорости), выход наружу меньше 1,5 с',r['mx']<=r['sp']*1.15 and r['exit']<1.5 and r['depth'],{**r,'errs':P.errs[:2]})

@test('W03')
async def w03(b):
    # рывок к центру тоже не дотягивает до маяка
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{"""+WELL0+"""p.x=n.x+300;p.y=n.y;p.vx=p.vy=0;let mn=1e9;for(let i=0;i<60*3;i++){steer2(n.x,n.y);if(i%20===0){p.dashCd=0;tryDash();}worldUpdate(1/60);mn=Math.min(mn,Math.hypot(p.x-n.x,p.y-n.y));}
      for(const k of KK)KEYS[k]=false;return {mn:Math.round(mn),st:G.state};}""")
    rec('W03 колодец: серия рывков к центру не достаёт до маяка (≥170), миссия не запускается',r['mn']>=165 and r['st']=='world',{**r,'errs':P.errs[:2]})

@test('W04')
async def w04(b):
    # глубоко в колодце видно, что пройти сначала; рисуется без ошибок
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{"""+WELL0+"""if(typeof wellReq!=='function')return {ok:false};const labels=[];const _w=worldLabel;worldLabel=function(x,y,t){labels.push(String(t));return _w.apply(this,arguments);};
      p.x=n.x+250;p.y=n.y;p.vx=p.vy=0;for(let i=0;i<10;i++){worldUpdate(1/60);}camSnap&&camSnap();renderWorld(performance.now());worldLabel=_w;
      return {ok:true,req:wellReq(n.m),m:n.m,lab:labels.filter(q=>q.includes('СНАЧАЛА'))};}""")
    want='МИССИЯ %02d · СНАЧАЛА %02d'%(r.get('m',0),r.get('req',0))
    rec('W04 колодец: вблизи подпись «МИССИЯ NN · СНАЧАЛА MM» с первой непройденной',r.get('ok') and r['req']==3 and want in r['lab'],{**r,'errs':P.errs[:2]})

# ---------- погоня ----------
@test('C01')
async def c01(b):
    # вдали: на карте знак патруля идёт за оранжевым «?»; «?» летит к Разлому; патруль держится ~320 позади
    P=await newpage(b)
    r=await P.js("""()=>{if(typeof chaseDev!=='function')return {ok:false};"""+CH0+"""if(!ok)return {ok:false};const r0=Math.hypot(c.tx-c.d.x,c.ty-c.d.y);for(let i=0;i<60*4;i++)worldUpdate(1/60);
      const kinds=[];w58MapAdd((k,x,y,o,l)=>kinds.push(k),2,1);const mp=chaseMapPts();const gap=Math.hypot(c.pat.x-c.d.x,c.pat.y-c.d.y);
      return {ok:true,ph:c.ph,kinds:kinds.filter(k=>k.startsWith('chase')),gap:Math.round(gap),closer:Math.hypot(c.tx-c.d.x,c.ty-c.d.y)<r0-500,eta:Math.round(Math.hypot(c.tx-c.d.x,c.ty-c.d.y)/(chaseSpd()*CHASE.vFar)),hunters:G.enemies.filter(e=>e.hunt).length};}""")
    ok=r.get('ok') and r['ph']=='far' and 'chaseP' in r['kinds'] and 'chaseQ' in r['kinds'] and 250<=r['gap']<=380 and r['closer'] and 20<=r['eta']<=60 and r['hunters']==0
    rec('C01 вдали: на карте патруль идёт за «?», «?» летит к Разлому (до края 30–60 с), врагов ещё нет',ok,{**r,'errs':P.errs[:2]})

@test('C02')
async def c02(b):
    # вблизи: патруль из врагов сектора гонится за двойником VØID и не замечает игрока; двойника убивают за несколько секунд
    P=await newpage(b)
    r=await P.js("""()=>{if(typeof chaseDev!=='function')return {ok:false};"""+CH0+NEAR+"""near();const types=c.hunters.map(e=>e.type),n=c.hunters.length;
      let auto=0;const hp0=p.hp;let t=null;for(let i=0;i<60*10;i++){steer2(c.d.x,c.d.y);worldUpdate(1/60);const q=nearestEnemy(p.x,p.y,900);if(q&&q.hunt)auto++;if(c.d.dead&&t===null){t=i/60;break;}}for(const k of KK)KEYS[k]=false;
      return {ok:true,n,types,auto,t,hit:hp0-p.hp,seen:G.save.chase.seen,ph:c.ph};}""")
    ok=r.get('ok') and 4<=r['n']<=6 and r['auto']==0 and r['t'] is not None and r['t']<9 and r['hit']==0 and r['seen']==1
    rec('C02 вблизи: патруль 4–6 врагов гонится за двойником, игрока не трогает и автонаведением не выбирается; двойник гибнет',ok,{**r,'errs':P.errs[:2]})

@test('C03')
async def c03(b):
    # после гибели двойника патруль разворачивается на игрока
    # kit6: игровой Math.random засеян (seed 2) до загрузки страницы. Состав патруля выбирается случайно (chaseDev); на 10 семенах обе сборки
    # дают побитно одинаковый исход, а 3 из 10 составов не проходят условие на обеих (out7/c03seed). Без семени тест был лотереей.
    P=await newpage(b,init=SEED6)
    r=await P.js("""()=>{if(typeof chaseDev!=='function')return {ok:false};"""+CH0+NEAR+"""near();chaseTo(10,()=>c.ph==='fight');
      const al=c.hunters.filter(e=>e.alive);const d0=Math.min(...al.map(e=>Math.hypot(e.x-p.x,e.y-p.y)));for(let i=0;i<30;i++){p.hp=p.maxHp;worldUpdate(1/60);}
      const d1=Math.min(...al.filter(e=>e.alive).map(e=>Math.hypot(e.x-p.x,e.y-p.y)));return {ok:true,hp:al.map(e=>[e.type,Math.round(e.hp),e.alive]),ph:c.ph,hunt:al.filter(e=>e.hunt).length,d0:Math.round(d0),d1:Math.round(d1),dead:c.d.dead};}""")
    ok=r.get('ok') and r['ph'] in('fight',None) and r['dead'] and r['hunt']==0 and (r['d1']<r['d0'] or r['d1']<260 or all(not q[2] for q in r['hp']))
    rec('C03 развязка: двойник исчез, патруль переключился на игрока и идёт к нему',ok,{**r,'errs':P.errs[:2]})

@test('C04')
async def c04(b):
    # разбитый патруль: награда ломом ×1,5, запись «БЕЗ ПОЗЫВНОГО» в журналах; событие закрывается
    P=await newpage(b)
    r=await P.js("""()=>{if(typeof chaseDev!=='function')return {ok:false};"""+CH0+NEAR+"""near();chaseTo(10,()=>c.ph==='fight');const c0=G.save.carry||0;
      for(const e of c.hunters)if(e.alive)hurt(e,99999,'test');for(let i=0;i<30;i++)worldUpdate(1/60);const el=document.createElement('div');renderJournals(el,null);
      return {ok:true,chs:!!CHS,carry:(G.save.carry||0)-c0,j:el.innerHTML.includes('БЕЗ ПОЗЫВНОГО')};}""")
    rec('C04 патруль разбит: +лом, запись в журналах, событие закрыто',r.get('ok') and not r['chs'] and r['carry']>=30 and r['j'],{**r,'errs':P.errs[:2]})

@test('C05')
async def c05(b):
    # редкость и рамки: не раньше миссии 6, не чаще раз в 20 минут; вход в миссию гасит событие; сохранение чистится
    P=await newpage(b)
    r=await P.js("""()=>{if(typeof chaseSave!=='function')return {ok:false};T.fresh();const S=G.save;S.cleared=3;for(let m=1;m<=3;m++)S.medals[m]={clear:1};saveWorld();
      const n=WORLD.nodes.find(q=>q.m===3);enterWorldAt(n.x+900,n.y);G.calm=30;const R=Math.random;Math.random=()=>0;const cs=chaseSave();cs.wt=5000;cs.last=0;cs.ck=59.99;
      worldUpdate(1/60);const early=!!CHS;Math.random=R;
      S.cleared=10;for(let m=1;m<=10;m++)S.medals[m]={clear:1};S.gate=true;saveWorld();const n5=WORLD.nodes.find(q=>q.m===5);enterWorldAt(n5.x+900,n5.y);revealAround(n5.x,n5.y,6000);for(let i=0;i<30;i++)worldUpdate(1/60);G.calm=30;CHASE.p=CHASE.pLate=1;cs.wt=5000;cs.last=4500;cs.ck=59.99;worldUpdate(1/60);const tooSoon=!!CHS;
      cs.last=0;cs.ck=59.99;let late=false;for(let k=0;k<20&&!late;k++){cs.ck=59.99;cs.last=0;G.calm=30;worldUpdate(1/60);late=!!CHS;}
      const q=WORLD.nodes.find(x=>nodeState(x.m)==='open'||nodeState(x.m)==='done');let gone=null;try{G.card={kind:'node',n:q};enterNode(q);gone=!CHS;}catch(e){gone=!CHS;}
      const m=migrateSave({...G.save,chase:{seen:'x',wt:-5,last:'NaN',ck:1e9}});return {ok:true,early,tooSoon,late,gone,mig:m.chase};}""")
    m=r.get('mig') or {}
    ok=r.get('ok') and not r['early'] and not r['tooSoon'] and r['late'] and r['gone'] and m.get('seen')==0 and m.get('wt')==0 and m.get('ck')<=600
    rec('C05 рамки: до миссии 6 и чаще раза в 20 мин не бывает; вход в миссию гасит; сохранение чистится',ok,{**r,'errs':P.errs[:2]})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'../kit6/out/q170.json'))
