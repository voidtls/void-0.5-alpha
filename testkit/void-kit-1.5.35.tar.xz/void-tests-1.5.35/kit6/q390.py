# 1.5.31–1.5.34 α · FPS: настройка «КАДРЫ» 30 / 60 / БЕЗ ОГРАНИЧЕНИЯ на ПК и на телефоне (ARCH·90a/90b/91/92, флаг A-27).
# Новый набор этапа 6+7 (существующие наборы не менялись, кроме ожидания L03 в q310 по решению владельца Р2).
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
W8="const w8=ms=>new Promise(r=>setTimeout(r,ms));"
OPEN=W8+"T.fresh();G.save.tut.off=1;$('#toast').hidden=true;await w8(250);pause();await w8(150);$('#bPauseSet').click();await w8(250);"
SEG="()=>{const s=document.querySelector('#setBody [data-seg=\"fps\"]');if(!s)return null;return [...s.querySelectorAll('[data-v]')].map(b=>[b.dataset.v,b.textContent.trim(),b.classList.contains('on')]);}"
PICK=("async(v)=>{"+W8+"const b=document.querySelector(`#setBody [data-seg=\"fps\"] [data-v=\"${v}\"]`);if(!b)return null;b.click();await w8(120);"
      "const s=store('void_settings');return {v,cap:SET.fpsCap,capD:SET.fpsCapD,fps:SET.fps,sCap:s&&s.fpsCap,sCapD:s&&s.fpsCapD,sFps:s&&s.fps,"
      "on:[...document.querySelectorAll('#setBody [data-seg=\"fps\"] [data-v].on')].map(b=>b.dataset.v),gate:fpsCap27()};}")
async def three(P):
    out={'seg':await P.js("async()=>{"+OPEN+"return ("+SEG+")()}")}
    for v in ('30','60','0'):out[v]=await P.js(PICK,v)
    return out

@test('F01')
async def f01(b):
    # ПК: строка есть, три кнопки, каждая включает свой режим; ключ телефона и старый ключ fps не трогаются
    P=await newpage(b,1280,800,alpha=False)
    r=await three(P)
    ok=r['seg'] is not None and [x[0] for x in r['seg']]==['30','60','0'] and r['seg'][2][1]=='БЕЗ ОГРАНИЧЕНИЯ'
    for v,cap in (('30',30),('60',60),('0',0)):
        x=r[v];ok&=x is not None and x['capD']==cap and x['sCapD']==cap and x['cap']==0 and x['fps']==60 and x['on']==[v] and x['gate']==cap
    rec('F01 ПК: «КАДРЫ» 30 / 60 / БЕЗ ОГРАНИЧЕНИЯ — каждая кнопка включает свой предел и сохраняется; настройка телефона не меняется',ok,r)

@test('F02')
async def f02(b):
    P=await newpage(b,390,844,alpha=False,touch=True)
    r=await three(P)
    ok=r['seg'] is not None and [x[0] for x in r['seg']]==['30','60','0']
    for v,cap,fps in (('30',30,30),('60',60,60),('0',0,60)):
        x=r[v];ok&=x is not None and x['cap']==cap and x['sCap']==cap and x['capD']==0 and x['fps']==fps and x['on']==[v] and x['gate']==cap
    rec('F02 телефон: три режима, старый ключ fps повторяет выбор (30 → 30, иначе 60) для отката; настройка ПК не меняется',ok,r)

@test('F03')
async def f03(b):
    # настройки, сохранённые до 1.5.31: прежний «30» на телефоне — предел 30, прежний «60» — без ограничения (так и работало)
    out={}
    for w,h,t,fps in ((390,844,True,30),(390,844,True,60),(1280,800,False,30)):
        P=await newpage(b,w,h,alpha=False,touch=t,clear=False,init="try{localStorage.clear();localStorage.setItem('void_settings',JSON.stringify({fps:%d,amb:false}));}catch(e){}"%fps)
        await P.wait(300)
        out[f'{"тел" if t else "ПК"} fps={fps}']=await P.js("async()=>{"+OPEN+"const s=store('void_settings');return {cap:SET.fpsCap,capD:SET.fpsCapD,fps:SET.fps,stored:s&&('fpsCap' in s),seg:("+SEG+")()}}")
    a,b2,c=out['тел fps=30'],out['тел fps=60'],out['ПК fps=30']
    ok=a['cap']==30 and a['fps']==30 and [x[0] for x in a['seg'] if x[2]]==['30'] and b2['cap']==0 and [x[0] for x in b2['seg'] if x[2]]==['0'] and c['capD']==0 and [x[0] for x in c['seg'] if x[2]]==['0']
    rec('F03 старые настройки: «30» на телефоне → предел 30; «60» → без ограничения; на ПК прежний «30» ничего не ограничивал → без ограничения',ok,out)

@test('F04')
async def f04(b):
    # сброс настроек и облако
    P=await newpage(b,390,844,alpha=False,touch=True)
    r=await P.js("async()=>{"+OPEN+"SET.fpsCap=30;SET.fpsCapD=60;SET.fps=30;saveSet();renderSetScreen();await w8(60);const rs=()=>document.querySelector('#setBody [data-rset63]');rs().click();await w8(80);rs().click();await w8(150);"
                 "const a={cap:SET.fpsCap,capD:SET.fpsCapD,fps:SET.fps};localStorage.setItem('void_settings',JSON.stringify(Object.assign({},SET,{fpsCap:30,fpsCapD:60})));cloudReloadState();"
                 "const c={cap:SET.fpsCap,capD:SET.fpsCapD};localStorage.setItem('void_settings',JSON.stringify(Object.assign({},SET,{fpsCap:45})));cloudReloadState();return {reset:a,cloud:c,bad:SET.fpsCap}}")
    ok=r['reset']=={'cap':0,'capD':0,'fps':60} and r['cloud']=={'cap':30,'capD':60} and r['bad']==30
    rec('F04 «вернуть стандартные» даёт без ограничения на обоих классах; облако переносит оба ключа, недопустимое значение не принимается',ok,r)

@test('F05')
async def f05(b):
    # откат флагом A-27: прежние две кнопки, на ПК строки нет, планировщик — прежнее правило
    out={}
    for w,h,t in ((1280,800,False),(390,844,True)):
        P=await newpage(b,w,h,alpha=False,touch=t,init="window.__archOff=['A-27'];")
        out['ПК' if not t else 'тел']=await P.js("async()=>{"+OPEN+"return {fc27:ARCH.fc27,seg:("+SEG+")(),gate:fpsCap27()}}")
    ok=out['ПК']['fc27'] is False and out['ПК']['seg'] is None and [x[0] for x in out['тел']['seg']]==['60','30'] and out['тел']['gate']==0
    rec('F05 A-27 выкл.: на телефоне прежние «60» и «30», на ПК строки нет, новый предел не действует',ok,out)

@test('F06')
async def f06(b):
    # настоящий браузер (headless, rAF ≈ 60 Гц): частота обработанных кадров при каждом пределе; скорость игры — по шагам
    out={}
    for cap in (30,60,0):
        P=await newpage(b,1280,800,alpha=False)
        out[str(cap)]=await P.js("async(c)=>{"+W8+"T.fresh();G.save.tut.off=1;$('#toast').hidden=true;SET.fpsCapD=c;await w8(500);let n=0,l=last;const s0=ARCH.steps74,t0=performance.now();"
                                 "await new Promise(r=>{const f=()=>{if(last!==l){n++;l=last;}if(performance.now()-t0<3000)requestAnimationFrame(f);else r();};requestAnimationFrame(f);});"
                                 "const dt=(performance.now()-t0)/1000;return {fps:+(n/dt).toFixed(1),steps:+((ARCH.steps74-s0)/dt).toFixed(1),state:G.state}}",cap)
    f30,f60,f0=out['30']['fps'],out['60']['fps'],out['0']['fps']
    st=[out[k]['steps'] for k in out]
    ok=f30<=31.5 and f0>=f30*.95 and f60>=f30*.95 and max(st)<=62 and min(st)>=.85*max(st)
    rec('F06 браузер: при 30 — не больше 30 обработанных кадров/с, при 60 и без ограничения — не меньше; шагов игры за секунду одинаково (±15 %) при любом пределе (стенд headless, не реальное устройство)',ok,out)

@test('F07')
async def f07(b):
    # телефон: старый ключ fps записала прежняя версия (откат или облако) и он расходится с fpsCap по «30» — действует старый ключ
    out={}
    for raw in ({'fps':30,'fpsCap':60},{'fps':30,'fpsCap':0},{'fps':60,'fpsCap':30}):
        P=await newpage(b,390,844,alpha=False,touch=True,clear=False,init="try{localStorage.clear();localStorage.setItem('void_settings',JSON.stringify(%s));}catch(e){}"%json.dumps(dict(raw,amb=False)))
        await P.wait(300)
        r=await P.js("async()=>{"+OPEN+"return {gate:fpsCap27(),seg:("+SEG+")()}}")
        r['после выбора 60']=await P.js(PICK,'60')
        out[json.dumps(raw)]=r
    on=lambda r:[x[0] for x in r['seg'] if x[2]]
    a,c,d=out['{"fps": 30, "fpsCap": 60}'],out['{"fps": 30, "fpsCap": 0}'],out['{"fps": 60, "fpsCap": 30}']
    ok=(a['gate']==30 and on(a)==['30'] and c['gate']==30 and on(c)==['30'] and d['gate']==0 and on(d)==['0']
        and all(r['после выбора 60']['gate']==60 and r['после выбора 60']['cap']==60 and r['после выбора 60']['fps']==60 for r in out.values()))
    rec('F07 телефон: если прежняя версия записала «30» или «60» поверх нового выбора, действует её выбор (30 → 30, 60 → без ограничения); новый выбор снова действует',ok,out)

if __name__=='__main__':
    sel=sys.argv[1:]
    if sel:TESTS=[t for t in TESTS if t[0] in sel]
    asyncio.run(run(TESTS,'../kit6/out/q390'))
