#!/usr/bin/env python3
# Этап 5 · подготовка окружения из полученных архивов и проверка, что всё работает.
#   python3 setup5.py --from VOID-tests-….tar.xz [--from другой-архив.zip] --into <папка>     — распаковать и проверить
#   python3 setup5.py                                                                          — проверить уже распакованный комплект (эту папку)
# Шаги: 1) архивы есть и читаются; 2) безопасная распаковка в одну структуру (без абсолютных путей и «..»);
#        3) Python ≥ 3.10, playwright, Node ≥ 18, node_modules (acorn, acorn-walk, eslint-scope); 4) браузер открывает страницу;
#        5) setup_kit + verify_kit; 6) smoke: check5 и own5 на 1.5.20, st5 boot = эталону, набор q96 полностью;
#        7) ARCH·81: сборка из 1.5.20 даёт 3e497666…, снятие возвращает 6d71e77b…
#        8) ARCH·81–84: сборка даёт 1.5.24 (76753e33…), снятие — 6d71e77b…, accept5 принимает
# Итог — строка READY или FAILED: <первый невыполненный шаг>. Выход 0 / 1.
import sys,os,subprocess,tarfile,zipfile,json,hashlib,shutil,tempfile
SHA160='6d71e77b6c204b6b8247e1caa71a382a95b501caea81c426d4972797b03e7b69';SHA161='3e4976665db0c9de68144f7f0c230821b5767086076c6186a3ed88b175b8e79d';SHA164='76753e3338ab36eefe8e6e5f945428a341de27b8e0f29b4fd8235ef0ad897776'
def fail(step,msg):print(f'FAILED: шаг {step} — {msg}');sys.exit(1)
def ok(step,msg):print(f'  [{step}] {msg}',flush=True)
a=sys.argv[1:];srcs=[a[i+1] for i,x in enumerate(a) if x=='--from']
root=os.path.abspath(a[a.index('--into')+1]) if '--into' in a else os.path.dirname(os.path.abspath(__file__))
def safe_members(names,dest):
    for n in names:
        p=os.path.realpath(os.path.join(dest,n))
        if os.path.isabs(n) or '..' in n.replace('\\','/').split('/') or not p.startswith(os.path.realpath(dest)):fail(2,'небезопасный путь в архиве: '+n)
if srcs:
    for s in srcs:
        if not os.path.isfile(s):fail(1,'нет архива '+s)
    os.makedirs(root,exist_ok=True);tmp=tempfile.mkdtemp(prefix='void5_',dir=root)
    for s in srcs:
        try:
            if s.endswith(('.tar.xz','.tar','.tgz','.tar.gz')):
                with tarfile.open(s) as t:safe_members(t.getnames(),tmp);(t.extractall(tmp,filter='data') if hasattr(tarfile,'data_filter') else t.extractall(tmp))
            elif s.endswith('.zip'):
                with zipfile.ZipFile(s) as z:safe_members(z.namelist(),tmp);z.extractall(tmp)
            else:fail(1,'неизвестный формат '+s)
        except (tarfile.TarError,zipfile.BadZipFile) as e:fail(1,f'архив {s} не читается: {e}')
        ok(1,'распакован '+os.path.basename(s))
    # склейка: верхняя папка комплекта void-tests-1.5.20 + содержимое архива пилота (stage5, builds, results)
    for top in os.listdir(tmp):
        src=os.path.join(tmp,top)
        for dirpath,dirs,files in os.walk(src):
            rel=os.path.relpath(dirpath,src)
            # архив пилота: VOID-ARCH81-pilot/{stage5,builds,results} → stage5/, builds5/, out5/p81/
            if top.startswith('VOID-ARCH81-pilot'):rel=rel.replace('builds','builds5',1) if rel.startswith('builds') else (('out5/p81'+rel[7:]) if rel.startswith('results') else rel)
            d=os.path.join(root,rel);os.makedirs(d,exist_ok=True)
            for f in files:shutil.copy2(os.path.join(dirpath,f),os.path.join(d,f))
    shutil.rmtree(tmp);ok(2,'структура собрана в '+root)
    if top.startswith('VOID-ARCH81-pilot'):
        for f,g in (('VOID-1.5.21-test-ARCH81.html','void_b161.html'),('VOID-1.5.21-test-ARCH81-A24.html','void_b161_a24.html')):
            p=os.path.join(root,'builds5',f)
            if os.path.exists(p)and not os.path.exists(os.path.join(root,'builds5',g)):shutil.copy2(p,os.path.join(root,'builds5',g))
for need in ('kit/arch74.py','kit/h.py','tools5/check5.js','tools5/own5.js','stage5/s5.py','setup_kit.py'):
    if not os.path.exists(os.path.join(root,need)):fail(2,'нет '+need+' — не хватает архива?')
ok(2,'файлы на месте')
if sys.version_info<(3,10):fail(3,'нужен Python ≥ 3.10, сейчас '+sys.version.split()[0])
try:import playwright;from playwright.sync_api import sync_playwright
except ImportError:fail(3,'нет playwright: pip install playwright && python3 -m playwright install chromium')
try:nv=subprocess.run(['node','-v'],capture_output=True,text=True).stdout.strip()
except FileNotFoundError:fail(3,'нет Node.js ≥ 18')
if int(nv.lstrip('v').split('.')[0])<18:fail(3,'нужен Node ≥ 18, сейчас '+nv)
for m in ('acorn','acorn-walk','eslint-scope','esrecurse','estraverse'):
    if not os.path.isdir(os.path.join(root,'node_modules',m)):fail(3,'нет node_modules/'+m)
ok(3,f'Python {sys.version.split()[0]}, Node {nv}, playwright, node_modules')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
r=subprocess.run([sys.executable,os.path.join(root,'setup_kit.py')]+a[a.index('--chrome'):a.index('--chrome')+2] if '--chrome' in a else [sys.executable,os.path.join(root,'setup_kit.py')],capture_output=True,text=True,env=env)
if r.returncode:fail(5,'setup_kit: '+r.stdout+r.stderr)
chrome=json.load(open(os.path.join(root,'.kitpaths.json')))['chrome']
try:
    with sync_playwright() as p:
        b=p.chromium.launch(executable_path=chrome,args=['--no-sandbox']);pg=b.new_page();pg.set_content('<p id=x>ok</p>');assert pg.inner_text('#x')=='ok';b.close()
except Exception as e:fail(4,'браузер не запускается: '+str(e)[:200])
ok(4,'браузер: '+chrome)
r=subprocess.run([sys.executable,os.path.join(root,'tools5','verify_kit.py')],capture_output=True,text=True,env=env)
if r.returncode:fail(5,'verify_kit: '+r.stdout[-600:])
ok(5,'целостность: '+r.stdout.strip().splitlines()[0])
B0=os.path.join(root,'kit','home','void_b160.html')
if hashlib.sha256(open(B0,'rb').read()).hexdigest()!=SHA160:fail(6,'эталон 1.5.20 не совпадает по SHA')
for cmd,what in (([ 'node',os.path.join(root,'tools5','check5.js'),B0,os.path.join(root,'tools5','c5_baseline_1520.json')],'check5'),
                 (['node',os.path.join(root,'tools5','own5.js'),B0,'--json',os.devnull],'own5')):
    r=subprocess.run(cmd,capture_output=True,text=True,env=env)
    if r.returncode:fail(6,what+' на 1.5.20: выход '+str(r.returncode)+' '+r.stderr[-300:])
ok(6,'check5 и own5 на 1.5.20 — 0')
tmpo=tempfile.mkdtemp(prefix='smoke5_')
r=subprocess.run([sys.executable,os.path.join(root,'tools5','st5.py'),'boot',B0,os.path.join(tmpo,'boot.json')],capture_output=True,text=True,env=env)
c=subprocess.run([sys.executable,os.path.join(root,'tools5','compare5.py'),os.path.join(root,'baseline','stage5','boot_a.json'),os.path.join(tmpo,'boot.json'),'--aa'],capture_output=True,text=True)
if r.returncode or c.returncode:fail(6,'st5 boot ≠ эталону: '+c.stdout[-300:]+r.stderr[-300:])
ok(6,'st5 boot = эталону')
r=subprocess.run([sys.executable,os.path.join(root,'tools5','run5.py'),'reg',B0,os.path.join(tmpo,'reg'),'--suites','q96'],capture_output=True,text=True,env=env)
if 'STATUS COMPLETE' not in r.stdout:fail(6,'q96 не прошёл полностью: '+r.stdout[-400:])
ok(6,'q96: COMPLETE')
o=os.path.join(tmpo,'b161.html')
r=subprocess.run([sys.executable,os.path.join(root,'stage5','s5.py'),'apply',B0,o,'81'],capture_output=True,text=True,env=env)
if r.returncode or hashlib.sha256(open(o,'rb').read()).hexdigest()!=SHA161:fail(7,'сборка ARCH·81 не даёт 3e497666…: '+r.stdout+r.stderr)
r=subprocess.run([sys.executable,os.path.join(root,'stage5','s5.py'),'strip',o,B0,'81'],capture_output=True,text=True,env=env)
if r.returncode:fail(7,'снятие ARCH·81 не возвращает 1.5.20: '+r.stdout)
ok(7,'ARCH·81: сборка 3e497666…, снятие = 6d71e77b…')
o4=os.path.join(tmpo,'b164.html')
r=subprocess.run([sys.executable,os.path.join(root,'stage5','s5.py'),'apply',B0,o4,'81','82','83','84'],capture_output=True,text=True,env=env)
if r.returncode or hashlib.sha256(open(o4,'rb').read()).hexdigest()!=SHA164:fail(8,'сборка ARCH·81–84 не даёт 76753e33…: '+r.stdout+r.stderr)
r=subprocess.run([sys.executable,os.path.join(root,'stage5','s5.py'),'strip',o4,B0,'81','82','83','84'],capture_output=True,text=True,env=env)
if r.returncode:fail(8,'снятие ARCH·84…81 не возвращает 1.5.20: '+r.stdout)
r=subprocess.run([sys.executable,os.path.join(root,'tools5','accept5.py'),o4],capture_output=True,text=True,env=env)
if r.returncode:fail(8,'accept5 на 1.5.24: '+r.stdout[-500:])
ok(8,'ARCH·81–84: сборка 76753e33…, снятие = 6d71e77b…, accept5 — принято');shutil.rmtree(tmpo,ignore_errors=True)
print('READY')
