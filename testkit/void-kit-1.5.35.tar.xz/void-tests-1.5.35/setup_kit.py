#!/usr/bin/env python3
# Настройка комплекта тестов VØID 1.5.20 под текущую папку и браузер.
#   python3 setup_kit.py [--chrome /путь/к/chrome]
# Заменяет метки @@KIT@@ (папка kit/) и @@CHROME@@ (браузер) во всех текстовых файлах kit/.
# Можно запускать повторно (например, после переноса папки): старые значения берутся из .kitpaths.json.
import os,sys,json,shutil
ROOT=os.path.dirname(os.path.abspath(__file__));KIT=os.path.join(ROOT,'kit').replace('\\','/')
ST=os.path.join(ROOT,'.kitpaths.json')
def find_chrome():
    if '--chrome' in sys.argv:return sys.argv[sys.argv.index('--chrome')+1]
    if os.environ.get('CHROME'):return os.environ['CHROME']
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            x=p.chromium.executable_path
            if x and os.path.exists(x):return x
    except Exception as e:print('playwright:',e)
    for n in ('google-chrome','chromium','chromium-browser'):
        x=shutil.which(n)
        if x:return x
    sys.exit('Браузер не найден: установите `python3 -m playwright install chromium` или укажите --chrome')
chrome=find_chrome().replace('\\','/')
old=json.load(open(ST)) if os.path.exists(ST) else {'kit':'@@KIT@@','chrome':'@@CHROME@@'}
TXT=('.py','.js','.sh','.json','.txt','.md','.jsonl','.log');n=0
for r,ds,fs in os.walk(os.path.join(ROOT,'kit')):
    for f in fs:
        p=os.path.join(r,f)
        if not f.endswith(TXT) or os.path.getsize(p)>3_000_000:continue
        t=open(p,encoding='utf8',errors='surrogateescape').read()
        t2=t.replace(old['kit'],KIT).replace(old['chrome'],chrome)
        if t2!=t:open(p,'w',encoding='utf8',errors='surrogateescape').write(t2);n+=1
json.dump({'kit':KIT,'chrome':chrome},open(ST,'w'))
for d in ('reg','reg_kit','out5'):os.makedirs(os.path.join(ROOT,d),exist_ok=True)
print(f'Готово: kit = {KIT}\n        браузер = {chrome}\n        изменено файлов: {n}')
