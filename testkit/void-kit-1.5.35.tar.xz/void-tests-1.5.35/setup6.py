#!/usr/bin/env python3
# Настройка комплекта VØID 1.5.35 (корректирующее обновление) после распаковки в любую папку (пробелы и кириллица допустимы).
#   python3 setup6.py [--chrome /путь/к/chrome]
# 1) проверяет Python (≥ 3.10), Playwright для Python, Node (≥ 18), node_modules комплекта;
# 2) находит Chromium (--chrome, переменная CHROME, браузер Playwright, chromium в PATH);
# 3) заменяет метки @@KIT@@ (папка kit/) и @@CHROME@@ (браузер) в текстовых файлах kit/, kit6/, tools6/diag/ — можно повторять после
#    переноса папки (старые значения берутся из .kitpaths.json);
# 4) запускает браузер один раз (2+2) и печатает ГОТОВО или ОШИБКА с причиной. Полная проверка — python3 tools6/accept6.py.
# Код выхода 0 — готово; 2 — окружение не годится (причина напечатана).
import os,sys,json,shutil,subprocess
ROOT=os.path.dirname(os.path.abspath(__file__));KIT=os.path.join(ROOT,'kit').replace('\\','/');ST=os.path.join(ROOT,'.kitpaths.json')
def die(m):print('ОШИБКА:',m);sys.exit(2)
if sys.version_info<(3,10):die('нужен Python ≥ 3.10, сейчас '+sys.version.split()[0])
for bad in ("'",'"','\\'):
    if bad in ROOT:die(f'путь к комплекту содержит {bad!r} — тесты подставляют его в строковые литералы; распакуйте в другую папку')
try:import playwright  # noqa
except ImportError:die('нет Playwright для Python: pip install playwright==1.63.0 && python3 -m playwright install chromium')
if not shutil.which('node'):die('нет Node.js (нужен ≥ 18)')
nv=subprocess.run(['node','--version'],capture_output=True,text=True).stdout.strip()
if int(nv.lstrip('v').split('.')[0])<18:die('нужен Node ≥ 18, сейчас '+nv)
for m in ('acorn','acorn-walk','eslint-scope','esrecurse','estraverse'):
    if not os.path.exists(os.path.join(ROOT,'node_modules',m,'package.json')):die('нет node_modules/'+m+' (входит в архив — распакуйте целиком)')
def find_chrome():
    if '--chrome' in sys.argv:return sys.argv[sys.argv.index('--chrome')+1]
    if os.environ.get('CHROME'):return os.environ['CHROME']
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            x=p.chromium.executable_path
            if x and os.path.exists(x):return x
    except Exception as e:print('playwright:',str(e)[:200])
    for n in ('google-chrome','chromium','chromium-browser'):
        x=shutil.which(n)
        if x:return x
    die('браузер не найден: python3 -m playwright install chromium (или --chrome путь)')
chrome=find_chrome().replace('\\','/')
old=json.load(open(ST)) if os.path.exists(ST) else {'kit':'@@KIT@@','chrome':'@@CHROME@@'}
TXT=('.py','.js','.sh','.json','.txt','.md','.jsonl','.log');n=0
for top in ('kit','kit6',os.path.join('tools6','diag')):
    for r,ds,fs in os.walk(os.path.join(ROOT,top)):
        for f in fs:
            p=os.path.join(r,f)
            if not f.endswith(TXT) or os.path.getsize(p)>3_000_000:continue
            t=open(p,encoding='utf8',errors='surrogateescape').read()
            t2=t.replace(old['kit'],KIT).replace(old['chrome'],chrome)
            if t2!=t:open(p,'w',encoding='utf8',errors='surrogateescape').write(t2);n+=1
json.dump({'kit':KIT,'chrome':chrome},open(ST,'w'),ensure_ascii=False)
for d in ('reg','reg_kit','out5','out7',os.path.join('kit6','out')):os.makedirs(os.path.join(ROOT,d),exist_ok=True)  # kit6/out — выходы наборов kit6
p=subprocess.run([sys.executable,'-c',"import sys,asyncio\nfrom playwright.async_api import async_playwright\nasync def m():\n async with async_playwright() as p:\n  b=await p.chromium.launch(executable_path=sys.argv[1],args=['--no-sandbox']);pg=await b.new_page();print(await pg.evaluate('2+2'),b.version);await b.close()\nasyncio.run(m())",chrome],capture_output=True,text=True,timeout=120)
if p.returncode or not p.stdout.startswith('4'):die('браузер не запускается: '+(p.stderr or p.stdout)[-400:]+'\n  (Debian/Ubuntu: python3 -m playwright install-deps chromium)')
print(f'ГОТОВО: kit = {KIT}\n        браузер = {chrome} ({p.stdout.split()[1]})\n        Python {sys.version.split()[0]}, Node {nv}; изменено файлов: {n}')
print('Дальше: python3 tools6/accept6.py --selftest   затем   python3 tools6/accept6.py   (полная приёмка, ~3–4 ч на 2 ядрах)')
