# Воспроизведение испорченных копий для проверки чувствительности инструментов (группа 0):
#   C1 — обёртка sfx «эхо рывка» (_sx30) перенесена ниже установки iso63(sfx): должна ловиться порядком переустановок (check5),
#        отпечатком загрузки (sfx) и счётчиком ГСЧ в сценарии post (st5 trace);
#   C2 — живой aimPt поставлен выше мёртвой копии: должен ловиться сменой победителя (check5) и отпечатком загрузки (aimPt).
# python3 make_corrupt.py <void_b160.html> <папка>
import sys,os
L=open(sys.argv[1],encoding='utf8').read().split('\n');O=sys.argv[2]
i=next(k for k,l in enumerate(L) if l.startswith('{const _sx30=sfx;'));j=next(k for k,l in enumerate(L) if l.startswith("if(typeof sfx==='function')sfx=iso63(sfx)"))
open(os.path.join(O,'C1.html'),'w',encoding='utf8').write('\n'.join(L[:i]+L[i+1:j+1]+[L[i]]+L[j+1:]))
a=[k for k,l in enumerate(L) if l.startswith('function aimPt(')];b=next(k for k in range(a[-1],len(L)) if L[k].startswith('function nearestEnemy'))
open(os.path.join(O,'C2.html'),'w',encoding='utf8').write('\n'.join(L[:a[0]]+L[a[-1]:b]+L[a[0]:a[-1]]+L[b:]))
print('C1: строки',i+1,'→ после',j+1,'; C2: aimPt',a[-1]+1,'→ перед',a[0]+1)
