# Сравнение журналов регрессии с эталоном: python3 cmpreg5.py <эталон: kit/reg20> <новая папка> [--json out.json]
# Классы: НОВОЕ падение · УШЛО · ИЗМЕНЕНА подробность (то же падение, другой текст) · ошибки Python/страницы.
# --aa <папка>: второй прогон ЭТАЛОННОЙ сборки. Падения, у которых подробность различается между двумя прогонами эталона,
#   считаются нестабильными (A/A); их изменения в кандидате выводятся отдельной строкой и не считаются новыми расхождениями.
# Ничего не скрывает: подробности, отличающиеся только номером версии, помечаются «только версия», но показываются.
import re,glob,os,sys,json
def parse(f):
    if not os.path.exists(f):return None
    ok=set();fl={};errs=[]
    for l in open(f,encoding='utf8',errors='replace'):
        m=re.match(r'\s*(OK|FAIL)\s+(\S+)\s*(.*)',l)
        if m:(ok.add(m.group(2)) if m.group(1)=='OK' else fl.__setitem__(m.group(2),m.group(3).strip()[:300]))
        if 'Traceback' in l:errs.append('Traceback')
    return dict(n=len(ok)+len(fl),ok=ok,fail=fl,errs=errs)
VER=re.compile(r'1\.5\.\d+')
A,B=sys.argv[1],sys.argv[2];rep={};tot=dict(new=0,gone=0,det=0,detver=0,detaa=0,miss=0,base=0,cand=0)
AA=sys.argv[sys.argv.index('--aa')+1] if '--aa' in sys.argv else None;UNST=set()
if AA:
    for f in glob.glob(AA+'/q*.log'):
        a,c=parse(os.path.join(A,os.path.basename(f))),parse(f)
        if a and c:UNST|={(os.path.basename(f),k) for k in set(a['fail'])&set(c['fail']) if a['fail'][k]!=c['fail'][k]}|{(os.path.basename(f),k) for k in set(a['fail'])^set(c['fail'])}
    print('нестабильные по A/A:',sorted(f'{s[:-4]} {k}' for s,k in UNST))
names=sorted({os.path.basename(f) for f in glob.glob(A+'/q*.log')}|{os.path.basename(f) for f in glob.glob(B+'/q*.log')})
if '--only' in sys.argv:names=[n for n in names if n[:-4] in sys.argv[sys.argv.index('--only')+1].split(',')]
for t in names:
    a,b=parse(os.path.join(A,t)),parse(os.path.join(B,t))
    if b is None:print(f'{t:12s} НЕТ ЖУРНАЛА');tot['miss']+=1;continue
    if a is None:print(f'{t:12s} нет в эталоне: {b["n"]} проверок, падений {len(b["fail"])}');continue
    new=sorted(set(b['fail'])-set(a['fail']));gone=sorted(set(a['fail'])-set(b['fail']))
    det=[(k,a['fail'][k],b['fail'][k]) for k in sorted(set(a['fail'])&set(b['fail'])) if a['fail'][k]!=b['fail'][k]]
    tot['base']+=len(a['fail']);tot['cand']+=len(b['fail']);tot['new']+=len(new);tot['gone']+=len(gone)
    for k,x,y in det:tot['detver' if VER.sub('V',x)==VER.sub('V',y) else 'detaa' if (t,k) in UNST else 'det']+=1
    line=f'{t:12s} проверок {a["n"]}→{b["n"]}  падений {len(a["fail"])}→{len(b["fail"])}'
    if a['n']!=b['n']:line+='  (ЧИСЛО ПРОВЕРОК ИЗМЕНИЛОСЬ)'
    print(line)
    for k in new:print('    НОВОЕ   ',k,b['fail'][k][:160])
    for k in gone:print('    УШЛО    ',k,a['fail'][k][:160])
    for k,x,y in det:print('    ИЗМЕНЕНО' + (' (только версия)' if VER.sub('V',x)==VER.sub('V',y) else ' (нестабильна и в A/A эталона)' if (t,k) in UNST else ''),k,'\n       было:',x[:160],'\n      стало:',y[:160])
    if b['errs']:print('    ошибки Python:',len(b['errs']))
    rep[t]=dict(nA=a['n'],nB=b['n'],new=new,gone=gone,det=det)
print('\nИТОГ: эталонных падений',tot['base'],'· в кандидате',tot['cand'],'· новых',tot['new'],'· ушло',tot['gone'],
      '· изменены подробности',tot['det'],'· изменён только номер версии',tot['detver'],'· изменены нестабильные (A/A)',tot['detaa'],'· нет журналов',tot['miss'])
if '--json' in sys.argv:json.dump(dict(tot=tot,rep=rep),open(sys.argv[sys.argv.index('--json')+1],'w'),ensure_ascii=False,indent=1)
sys.exit(1 if tot['new'] or tot['det'] or tot['miss'] else 0)
