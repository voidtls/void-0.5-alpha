# Этап 5 · самопроверка own5.js на намеренно испорченных копиях сборки. Ничего не правит в самой сборке: копии — во временной папке.
#   python3 tools5/selftest5.py <сборка.html> [папка-для-копий]     выход 1, если хоть один случай дал не тот результат
# Каждая копия получает одну вставку после итогового объявления nearestEnemy (якорь по AST — последний 'function nearestEnemy(').
import sys,os,json,subprocess,tempfile,shutil
R=os.path.dirname(os.path.abspath(__file__));B=sys.argv[1];D=sys.argv[2] if len(sys.argv)>2 else tempfile.mkdtemp(prefix='st5_')
os.makedirs(D,exist_ok=True);SRC=open(B,encoding='utf8').read()
k=SRC.rindex('\nfunction nearestEnemy(');end=SRC.index('\n',SRC.index('{',k)+1)  # вставка — перед итоговым nearestEnemy
def ins(code,at=None):return SRC[:k]+'\n'+code+SRC[k:]
def repl(a,b):assert SRC.count(a)==1,a;return SRC.replace(a,b)
MAN=os.path.join(R,'ownership5.json')
def man_with(extra):
    m=json.load(open(MAN))
    if extra=='API_N2':  # реестр ждёт два вызова в месте startAnom — правило числа вызовов
        for a in m['apiSites']:
            if a['unit']=='startAnom':a['n']=2
    else:m['registry']=m['registry']+extra
    p=os.path.join(D,'man_%d.json'%len(os.listdir(D)));json.dump(m,open(p,'w'),ensure_ascii=False);return p
CASES=[ # (имя, html, ожидаемый код выхода, что должно быть в отчёте, манифест)
 ('S1 прямое присваивание',ins('function __s1(){G.prio=null;}'),1,'незарегистрированная запись G.prio',None),
 ('S2 вычисляемый ключ-строка',ins("function __s2(){G['prio']=null;}"),1,'незарегистрированная запись G.prio',None),
 ('S3 шаблон без вставок',ins('function __s3(){G[`aimLock`]=null;}'),1,'незарегистрированная запись G.aimLock',None),
 ('S4 псевдоним G',ins('function __s4(){const gg=G;gg.tg90=null;}'),1,'незарегистрированная запись G.tg90',None),
 ('S5 Object.assign',ins('function __s5(){Object.assign(G,{aimLock:null});}'),1,'незарегистрированная запись G.aimLock',None),
 ('S6 Reflect.set',ins("function __s6(){Reflect.set(G,'noTg75',1);}"),1,'незарегистрированная запись G.noTg75',None),
 ('S7 деструктуризация',ins('function __s7(){({a:G.aimWarn75}={a:1});}'),1,'незарегистрированная запись G.aimWarn75',None),
 ('S8a ++',ins('function __s8a(){G.noTg75++;}'),1,'незарегистрированная запись G.noTg75',None),
 ('S8b delete',ins('function __s8b(){delete G.prio;}'),1,'незарегистрированная запись G.prio',None),
 ('S8c ??=',ins('function __s8c(x){G.prio??=x;}'),1,'незарегистрированная запись G.prio',None),
 ('S9 динамический ключ',ins('function __s9(k,v){G[k]=v;}'),2,'вычисляемый ключ',None),
 ('S10 G через параметр',ins('function __s10(o){o.prio=1;}\nfunction __s10b(){__s10(G);}'),2,'утекает',None),
 ('S11 активная ветка вне владельца',ins('function __s11(){if(ARCH.a26){G.tg90=1;}}'),1,'незарегистрированная запись G.tg90',None),
 ('S12 зарегистрированная ветка отката',ins('function __s12(){if(!ARCH.a26){G.tg90=1;}}'),0,'"externalWritersFallbackOnly": [\n   "__s12"',
   [{'unit':'__s12','field':'tg90','kind':'=','site':None,'nth':1,'cls':'fallbackA26','branch':'fallback'}]),
 ('S13 составное условие флага',ins('function __s13(x){if(!ARCH.a26&&x){G.tg90=1;}}'),2,'составным условием',
   [{'unit':'__s13','field':'tg90','kind':'=','site':None,'nth':1,'cls':'fallbackA26','branch':'fallback'}]),
 ('S14 строки, шаблоны, комментарии',ins('function __s14(){const a="G.prio=3",b=`G.aimLock=1`;/* G.tg90=1 */\n// G.noTg75=1\nreturn a+b;}'),0,'',None),
 ('S15 поле у постороннего объекта',ins('function __s15(){const e={};e.prio=3;e.aimLock=1;return e;}'),0,'',None),
 ('S16 локальная G затеняет глобальную',ins('function __s16(){const G={};G.prio=1;return G;}'),0,'',None),
 ('S17 неизменённая сборка',SRC,0,'',None),
 ('S20 G в объектном литерале (скрытый псевдоним)',ins('function __s20(){const {G:gg}={G};gg.prio=1;}'),2,'утекает',None),
 ('S21 G через запятую',ins('function __s21(){(0,G).prio=1;}'),2,'утекает',None),
 ('S22 this через call(G)',ins('function __s22(){this.prio=1;}\nfunction __s22b(){__s22.call(G);}'),2,'утекает',None),
 ('S23 стрелка внутри чужой функции',repl('function storyRetreat(e){','function storyRetreat(e){(()=>{G.aimLock=null;})();'),1,'(=) в storyRetreat',None),
 ('S24 дубль функции-владельца',ins('function pickTarget(){G.prio=null;return null;}'),1,'функция-владелец pickTarget: объявлений 2',None),
 ('S25 новая обёртка kill',SRC.replace('\n</script>','\n{const _k25=kill;kill=function(e,s){G.prio=null;return _k25(e,s);};}\n</script>',1) if False else ins('{const _k25=kill;kill=function(e,s){G.prio=null;return _k25(e,s);};}'),1,'(обёртка kill)',None),
 ('S26 Object.assign с выражением',ins('function __s26(c){Object.assign(G,c?{prio:1}:{});}'),2,'нелитеральным аргументом',None),
 ('S27 логическое присваивание',ins('function __s27(x){G.aimLock&&=x;}'),1,'незарегистрированная запись G.aimLock',None),
 ('S28 опечатка во флаге',ins('function __s28(){if(!ARCH.a62){G.tg90=1;}}'),1,'незарегистрированная запись G.tg90',
   [{'unit':'__s28','field':'tg90','kind':'=','site':None,'nth':1,'cls':'fallbackA26','branch':'fallback'}]),
 ('S29 лишняя запись с тем же текстом в зарегистрированной функции',repl('function storyRetreat(e){','function storyRetreat(e){if(G.prio===e)G.prio=null;'),1,'storyRetreat',None),
 ('S30 звук пишет новое поле G',repl('{const _mt30=musTarget;musTarget=function(){','{const _mt30=musTarget;musTarget=function(){G.musX=1;'),1,'звук',None),
 ('S31 звук без finally',repl('try{r=_mt30();}finally{G.m=m;}','r=_mt30();G.m=m;'),1,'finally',None),
 ('S34 псевдоним через позднее присваивание',ins('function __s34(){let g;g=G;g.prio=1;}'),1,'незарегистрированная запись G.prio',None),
 ('S35 G в массиве',ins('function __s35(){[G][0].prio=1;}'),2,'утекает',None),
 ('S36 вычисляемый ключ-литерал в Object.assign',ins("function __s36(){Object.assign(G,{['prio']:1});}"),1,'незарегистрированная запись G.prio',None),
 ('S37 G в IIFE-параметр',ins('function __s37(){(function(g){g.prio=1;})(G);}'),2,'утекает',None),
 ('S38 eval',ins("function __s38(){eval('G.prio=1');}"),2,'строки как кода',None),
 ('S39 setTimeout со строкой',ins("function __s39(){setTimeout('G.prio=1',0);}"),2,'строки как кода',None),
 ('S40 склейка ключа',ins("function __s40(){G['pr'+'io']=1;}"),2,'вычисляемый ключ',None),
]
if 'function aimStep(' in SRC:  # случаи ARCH·82: близнец ветки отката
    i1=SRC.index('function aimStep(');fbk=SRC.index('else{/* ARCH·82 · откат A-26')
    def at(pos,a,b):j=SRC.index(a,pos);return SRC[:j]+b+SRC[j+len(a):]
    CASES+=[
     ('S18a токен ветки отката',at(fbk,'dt*14);}','dt*15);}'),1,'различаются',None),
     ('S18b токен aimStep',at(i1,'dt*14);\n  return tg;}','dt*15);\n  return tg;}'),1,'fallbackTwin',None),
     ('S18c обе копии одинаково',at(i1,'dt*14);\n  return tg;}','dt*15);\n  return tg;}').replace("dt*14);}\n  p.fireT-=dt;","dt*15);}\n  p.fireT-=dt;",1),1,'отличается от текста 1.5.21',None),
     ('S18d нет return tg',at(i1,'\n  return tg;}','\n  return null;}'),1,'return tg',None),
     ('S18e перевёрнутый флаг',SRC.replace('let tg;if(ARCH.a26)tg=aimStep(p,dt,man);','let tg;if(!ARCH.a26)tg=aimStep(p,dt,man);',1),1,'fallbackTwin',None),
     ('S18f автострельба отличается',SRC.replace('function autoFireWanted(man,tg){return man?(MOUSE.down||','function autoFireWanted(man,tg){return man?(MOUSE.down&&',1),1,'autoFireWanted',None),
     ('S19 новый внешний вызов prioSet',ins('function __s19(){prioSet(null);}\nfunction prioSet(e){G.prio=e;}'),1,'новое внешнее место вызова prioSet',None),
    ]
if 'function prioSet(' in SRC:  # случаи ARCH·83: учёт мест вызова API наведения
    CASES+=[
     ('S19b второй вызов в том же месте',SRC.replace('G.anom.target=e;prioSet(e);','G.anom.target=e;prioSet(e);prioSet(e);',1),1,'зарегистрированное место вызова API отсутствует',None),  # меняется текст объемлющего оператора → место другое; правило числа вызовов — запасное (S19i)
     ('S19c замена откатана к прямой записи',SRC.replace('G.anom.target=e;prioSet(e);','G.anom.target=e;G.prio=e;',1),1,'незарегистрированная запись G.prio',None),
     ('S19d API как значение',ins('function __s19d(a){a.forEach(prioClear);}'),1,'используется как значение',None),
     ('S19e другой аргумент в месте вызова',SRC.replace('G.anom.target=e;prioSet(e);','G.anom.target=e;prioSet(null);',1),1,'новое внешнее место вызова prioSet',None),
     ('S19f логика в prioSet',SRC.replace('function prioSet(e){G.prio=e;}','function prioSet(e){G.prio=e;G.noTg75=0;}',1),1,'тело функции API prioSet',None),
     ('S19h второе объявление prioClear',ins('function prioClear(e){if(G.prio===e)G.prio=null;}'),1,'объявлений верхнего уровня 2',None),
     ('S19i реестр ждёт 2 вызова, найден 1',SRC,1,'ожидалось 2, найдено 1','API_N2'),
     ('S19g псевдоним функции',ins('const __s19g=prioSet;'),1,'используется как значение',None),
    ]
fail=0;rows=[]
for i,(name,html,exp,needle,extra) in enumerate(CASES):
    f=os.path.join(D,'case%02d.html'%i);open(f,'w',encoding='utf8').write(html);man=MAN
    if extra=='API_N2':man=man_with(extra)
    elif extra:
        # site вычисляется самим инструментом: первый прогон с --emit, затем подстановка
        r0=subprocess.run(['node',os.path.join(R,'own5.js'),f,'--emit'],capture_output=True,text=True);em=json.loads(r0.stdout)['emitRegistry']
        for e in extra:
            m=[x for x in em if x['unit']==e['unit'] and x['field']==e['field']]
            if m:e['site']=m[0]['site']
        man=man_with(extra)
    r=subprocess.run(['node',os.path.join(R,'own5.js'),f,'--manifest',man],capture_output=True,text=True)
    ok=r.returncode==exp and (needle in r.stdout or needle in r.stderr)
    fail+=not ok;rows.append((name,exp,r.returncode,ok))
    print(('OK  ' if ok else 'FAIL')+f' {name}: ожидался выход {exp}, получен {r.returncode}'+('' if ok else ' · '+(r.stderr.strip().splitlines() or [''])[-1][:160]))
print(f'ИТОГ: {len(CASES)-fail} из {len(CASES)}');json.dump(rows,open(os.path.join(D,'selftest5.json'),'w'),ensure_ascii=False)
sys.exit(1 if fail else 0)
