# Сверка с историческими эталонами K-стенда: отчёт kit/t72/cmpk.py по «/ref + кандидат» должен побайтно совпасть с отчётом по «/ref + 1.5.20».
#   python3 tools5/khist5.py <кандидат.jsonl> [эталон k80.jsonl]   (выход 1 при отличии)
import sys,os,subprocess,tempfile,json
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));K=os.path.join(R,'kit','t72')
cand=sys.argv[1];base=sys.argv[2] if len(sys.argv)>2 else os.path.join(K,'k80.jsonl')
rows=[json.loads(l) for l in open(base)];refs=[r for r in rows if r['id'].endswith('/ref')];b20=[r for r in rows if not r['id'].endswith('/ref')]
c=[json.loads(l) for l in open(cand)]
def rep(xs):
    f=tempfile.NamedTemporaryFile('w',suffix='.jsonl',delete=False);[f.write(json.dumps(x)+'\n') for x in xs];f.close()
    return subprocess.run([sys.executable,os.path.join(K,'cmpk.py'),f.name],capture_output=True,text=True).stdout
a,b=rep(refs+b20),rep(refs+c)
print(f'/ref: {len(refs)} · 1.5.20: {len(b20)} · кандидат: {len(c)} · итог 1.5.20: {a.strip().splitlines()[-1]} · итог кандидата: {b.strip().splitlines()[-1]}')
print('ОТЧЁТЫ СОВПАДАЮТ ПОБАЙТНО' if a==b else 'ОТЧЁТЫ РАЗЛИЧАЮТСЯ')
sys.exit(0 if a==b else 1)
