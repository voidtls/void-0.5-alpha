# Копия стенда этапа 4 с другой сборкой вместо g160.html (сам стенд не меняется): python3 retarget5.py <стенд.py> <сборка.html> <копия.py>
import sys,os
t=open(sys.argv[1],encoding='utf8').read();B=os.path.abspath(sys.argv[2]);n=t.count("'file://'+D+'g160.html'")
t=t.replace("'file://'+D+'g160.html'","'file://"+B+"'")
if n==0:sys.exit('в стенде нет адреса g160.html')
open(sys.argv[3],'w',encoding='utf8').write(t);print('заменено адресов',n)
