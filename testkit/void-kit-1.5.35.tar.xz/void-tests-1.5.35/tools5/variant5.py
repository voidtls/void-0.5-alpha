# Вариант сборки с флагами, заданными до загрузки (структурно, без опоры на init-скрипт стенда):
#   python3 tools5/variant5.py <сборка.html> <вариант.html> [--a24] [--off A-26,A-25]
# Перед основным <script>\n"use strict"; вставляется <script>window.__a24on=true;window.__archOff=[…]</script>.
# Проверка доставки: python3 tools5/st5.py flags <вариант.html> out.json — флаги должны быть видны в ARCH.
import sys,json
s=open(sys.argv[1],encoding='utf8').read();k='<script>\n"use strict";'
if s.count(k)!=1:sys.exit('нет единственного основного <script>')
pre=''
if '--a24' in sys.argv:pre+='window.__a24on=true;'
if '--off' in sys.argv:pre+='window.__archOff='+json.dumps(sys.argv[sys.argv.index('--off')+1].split(','))+';'
if not pre:sys.exit('не заданы флаги')
open(sys.argv[2],'w',encoding='utf8').write(s.replace(k,'<script>'+pre+'\n</script>'+k))
print('ok',pre)
