# Динамика ⊆ статики: каждая пара (поле|функция), записавшая поле наведения во время прогона st5 guard,
# должна быть в статическом перечне own5 (--json) той же сборки. Выход 0 — подмножество; 1 — есть пары вне статики; 3 — ошибка.
#   python3 tools5/guardsub5.py <guard.json> <own5.json>
import json,sys
try:
    g=json.load(open(sys.argv[1]));o=json.load(open(sys.argv[2]))
    if g['sha'][:16]!=o['buildSha'][:16]:print('ОТКАЗ: guard и own5 сняты с разных сборок',g['sha'][:16],o['buildSha']);sys.exit(3)
    st={(w['field'],w['unit'].replace(' (обёртка)','').replace(' (инициализатор)','')) for w in o['writes']}
    dyn={};H=[]
    for run,r in g['runs'].items():
        for k,n in r['writers'].items():
            f,u=k.split('|',1)
            if u=='(стенд)':H.append((run,f,n));continue
            dyn.setdefault((f,u),[]).append(run)
except (KeyError,ValueError,OSError) as e:print('ошибка входных данных:',e);sys.exit(3)
out=sorted(k for k in dyn if k not in st)
cov=sorted(k for k in st if k not in dyn)
print(f'динамических пар {len(dyn)}, статических {len(st)}; вне статики {len(out)}; статических, не встреченных в прогонах: {len(cov)}')
print('записи самого стенда (подготовка проб, не игра):',H)
for k in out:print('  ВНЕ СТАТИКИ:',k,'прогоны',dyn[k][:3])
for k in cov:print('  не покрыто прогонами:',k)
sys.exit(1 if out else 0)
