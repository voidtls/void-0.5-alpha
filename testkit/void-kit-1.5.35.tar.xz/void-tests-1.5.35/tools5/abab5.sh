#!/bin/sh
# Отдельное расследование падений: чередование сборок A/B для выбранных проверок на тихой машине.
#   sh tools5/abab5.sh <A.html> <B.html> <папка> <повторов> "q170 C03" "q270 Y09" …
R=$(cd "$(dirname "$0")/.." && pwd); A=$(cd "$(dirname "$1")" && pwd)/$(basename "$1"); B=$(cd "$(dirname "$2")" && pwd)/$(basename "$2"); O=$(mkdir -p "$3" && cd "$3" && pwd); N=$4; shift 4
TL=""; for t in "$@"; do TL="$TL$(echo $t | tr " " ":") "; done
cd "$R/kit"
for i in $(seq 1 $N); do for t in $TL; do q=${t%%:*}; c=${t#*:}; for v in A B; do U=$A; [ $v = B ] && U=$B
  GAME_URL=file://$U TMO=1500 timeout 1800 python3 $q.py $c > "$O/${q}_${c}_${v}_$i.log" 2>&1
  echo "$i $v $q $c $(grep -o "^\s*\(OK\|FAIL\)\s*$c " "$O/${q}_${c}_${v}_$i.log" | tr -s ' ')" >> "$O/summary.txt"; done; done; done
echo ABABDONE >> "$O/summary.txt"
