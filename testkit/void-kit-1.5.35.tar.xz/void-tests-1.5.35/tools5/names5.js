// имена всех глобальных функций сборки (объявления верхнего уровня + имена, которым присваиваются функции) — для отпечатка загрузки
process.on('uncaughtException',e=>{console.error('names5.js: внутренняя ошибка инструмента: '+(e&&e.stack||e));process.exit(3);});
const path=require('path'),fs=require('fs');const NM=process.env.NODE_TOOLS||path.join(__dirname,'..','node_modules');
const acorn=require(path.join(NM,'acorn')),escope=require(path.join(NM,'eslint-scope'));
const html=fs.readFileSync(process.argv[2],'utf8');const i0=html.indexOf('<script>\n"use strict";');if(i0<0)throw new Error('нет основного <script> с "use strict"');const i=i0+8,j=html.indexOf('</script>',i);
const ast=acorn.parse(html.slice(i,j),{ecmaVersion:2022,sourceType:'script',ranges:true,locations:true});
const gs=escope.analyze(ast,{ecmaVersion:2022}).globalScope;
process.stdout.write(JSON.stringify(gs.variables.filter(v=>v.defs.some(d=>d.type==='FunctionName')).map(v=>v.name).sort()));
