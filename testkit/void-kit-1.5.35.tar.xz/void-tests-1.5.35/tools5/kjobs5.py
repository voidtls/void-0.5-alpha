# Перенацелить задания K-стенда (kit/t72/jobs_*.json) на другую сборку: python3 kjobs5.py <jobs.json> <сборка.html> <out.json>
# Заменяются только адреса g160.html (1.5.20) и g160a24.html (1.5.20 с A-24); прочие сборки в заданиях (эталоны старых версий) не трогаются.
import json,sys,os
J=json.load(open(sys.argv[1]));B='file://'+os.path.abspath(sys.argv[2]);n=0
for j in J:
    u=j.get('url','')
    if u.endswith('/t72/g160.html') or u.endswith('/t72/g160a24.html'):j['url']=B;n+=1
json.dump(J,open(sys.argv[3],'w'),ensure_ascii=False);print('заданий',len(J),'перенацелено',n)
