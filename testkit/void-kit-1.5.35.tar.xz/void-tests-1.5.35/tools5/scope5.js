// Проверки переноса объявлений (этап 5): для каждого имени — итоговое объявление на верхнем уровне программы (не в блоке, IIFE, функции),
process.on('uncaughtException',e=>{console.error('scope5.js: внутренняя ошибка инструмента: '+(e&&e.stack||e));process.exit(3);});
// внешние ссылки тела (имя → область, где оно разрешается) и локальные переменные совпадают с эталоном.
//   node tools5/scope5.js <эталон.html> <кандидат.html> имя1,имя2,…     (выход 1 при расхождении)
const path=require('path'),fs=require('fs');const NM=process.env.NODE_TOOLS||path.join(__dirname,'..','node_modules');
const acorn=require(path.join(NM,'acorn')),escope=require(path.join(NM,'eslint-scope'));
function load(f){const h=fs.readFileSync(f,'utf8');const i0=h.indexOf('<script>\n"use strict";');if(i0<0)throw new Error('нет основного <script>');const i=i0+8,j=h.indexOf('</script>',i);const src=h.slice(i,j);
  const ast=acorn.parse(src,{ecmaVersion:2022,sourceType:'script',ranges:true,locations:true});const sm=escope.analyze(ast,{ecmaVersion:2022});return {src,ast,sm};}
function info(L,name){const tops=L.ast.body.filter(s=>s.type==='FunctionDeclaration'&&s.id.name===name);if(!tops.length)return null;const d=tops.at(-1);
  let nested=0;(function w(n,inFn){if(!n||typeof n.type!=='string')return;if(n.type==='FunctionDeclaration'&&n.id&&n.id.name===name&&inFn)nested++;
    for(const k in n){const v=n[k];if(Array.isArray(v))v.forEach(x=>w(x,inFn||/Function/.test(n.type)));else if(v&&typeof v.type==='string')w(v,inFn||/Function/.test(n.type));}})(L.ast,false);
  const sc=L.sm.acquire(d);const ext={};const loc=new Set();
  (function walk(s){for(const r of s.references){const v=r.resolved;if(v&&isInside(v.scope,sc))continue;ext[r.identifier.name]=v?v.scope.type:'неразрешено (глобальное свойство)';}
    for(const v of s.variables)if(v.name!=='arguments')loc.add(v.name);s.childScopes.forEach(walk);})(sc);
  return {topLevel:true,line:d.loc.start.line,declCount:tops.length,nestedDecls:nested,params:d.params.length,ext:Object.keys(ext).sort().map(k=>k+':'+ext[k]),locals:[...loc].sort()};}
function isInside(s,root){while(s){if(s===root)return true;s=s.upper;}return false;}
const A=load(process.argv[2]),B=load(process.argv[3]);let bad=0;
for(const n of process.argv[4].split(',')){const a=info(A,n),b=info(B,n);
  if(!b){console.log(n,'НЕТ в кандидате');bad++;continue;}
  const dx=[...b.ext.filter(x=>!a.ext.includes(x)).map(x=>'+'+x),...a.ext.filter(x=>!b.ext.includes(x)).map(x=>'-'+x)];
  const dl=[...b.locals.filter(x=>!a.locals.includes(x)).map(x=>'+'+x),...a.locals.filter(x=>!b.locals.includes(x)).map(x=>'-'+x)];
  const ok=!dx.length&&!dl.length&&a.declCount===b.declCount&&b.nestedDecls===0&&a.params===b.params;if(!ok)bad++;
  console.log(`${ok?'OK  ':'DIFF'} ${n}: строка ${a.line}→${b.line}, объявлений на верхнем уровне ${a.declCount}→${b.declCount}, вложенных ${b.nestedDecls}, параметров ${a.params}→${b.params}, внешних ссылок ${a.ext.length}→${b.ext.length}`+(dx.length?' Δвнешние '+dx.join(' '):'')+(dl.length?' Δлокальные '+dl.join(' '):''));}
process.exitCode=bad?1:0;
