# Этап 5 · динамические стенды (Playwright). Не меняют сборку: всё подключается в копии страницы через init-скрипт и evaluate.
#   python3 st5.py boot   <build.html> <out.json>   — отпечаток загрузки: sha текста каждой глобальной функции после arch70Boot,
#                                                     длина (.length), число и типы addEventListener
#   python3 st5.py trace  <build.html> <out.json>   — по шагам: число вызовов игрового RNG, порядок вызовов отслеживаемых функций,
#                                                     хэш состояния; сценарии m10, world, post (с рывками)
#   (guard: прямые записи самого стенда в подготовке проб помечаются «(стенд)», неопознанные — «(?)»)
#   python3 st5.py gkeys <build.html> <out.json>    — ключи G в порядке перечисления до и после сценариев (сравнение — compare5)
#   python3 st5.py aimman <build.html> <out.json>   — ручной прицел с захватом G.aimLock, движение мыши, кнопка мыши
#   python3 st5.py prio   <build.html> <out.json>   — prioTap: отметка цели (ПК и телефон), убийство отмеченной, касание мимо
#   python3 st5.py probes <build.html> <out.json>   — прямые вызовы kill / storyRetreat / петли / двойника / startAnom / startEndless с отметкой цели
#   python3 st5.py guard  <build.html> <out.json>   — ловушки записи пяти полей G (кто пишет) и счётчики вызовов (покрытие A-26/API);
#                                                     форма G меняется, поэтому побитно с другими стендами не сравнивается
#   python3 st5.py audio  <build.html> <out.json>   — обёртка musTarget возвращает G.m и при обычном вызове, и при исключении
#   python3 st5.py flags  <build.html> <out.json>   — какие флаги реально дошли до страницы (проверка доставки VOID_OFF)
#   переменные: VOID_A24=1 — включить A-24 (__a24on); VOID_OFF='A-26,…' — выключить флаги; CHROME — путь к браузеру
import asyncio,json,sys,os,hashlib
KIT=os.environ.get('VOID_KIT') or os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','kit')
sys.path.insert(0,KIT)
from playwright.async_api import async_playwright
import h
_kp=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','.kitpaths.json')
CHROME=os.environ.get('CHROME') or (json.load(open(_kp))['chrome'] if os.path.exists(_kp) else None)
# имена, порядок вызовов которых сравнивается (существуют в 1.5.20; новые функции этапа 5 намеренно не отслеживаются)
TRACE=['aimLockable','aimManual','targetable','pickTarget','prioTap','aimFallback','aimPt','nearestEnemy','sbAutoTarget','updatePlayer','fire','fireCharged','kill','sfx','tryDash']
def init_js():
    off=[x for x in os.environ.get('VOID_OFF','').split(',') if x]
    return ("(()=>{let a=7;const R=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};"
     "window.__rn=0;window.__gameR=function(){window.__rn++;return R();};Math.random=window.__gameR;window.requestAnimationFrame=()=>0;"
     "window.__ael={};const o=EventTarget.prototype.addEventListener;EventTarget.prototype.addEventListener=function(t,f,x){const k=(this===window?'window':this===document?'document':(this&&this.nodeName)||'other')+':'+t;window.__ael[k]=(window.__ael[k]||0)+1;return o.call(this,t,f,x);};"
     +("window.__a24on=true;" if os.environ.get('VOID_A24')=='1' else "")
     +("window.__archOff="+json.dumps(off)+";" if off else "")+"})();")
async def page(b,url,vw=1280,vh=760,touch=False):
    P=await h.newpage(b,vw,vh,url='file://'+os.path.abspath(url),init=init_js(),touch=touch)
    return P.pg.context,P.pg,P.errs
COMMON=r"""
 window.__id=new WeakMap();window.__idn=0;
 window.oid=o=>{if(!o||typeof o!=='object')return -1;let v=__id.get(o);if(v===undefined){v=++__idn;__id.set(o,v);}return v;};
 window.fnv=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(36);};
 window.stH=()=>{const p=G.player;if(!p)return 'nop';const r=[G.state,ARCH.steps74,p.x,p.y,p.ang,p.hp,p.vx,p.vy,p.fireT,G.kills,G.enemies.length,G.pb.length,G.eb.length,oid(G.prio),oid(G.tg90),oid(G.aimLock),G.noTg75||0,G.aimWarn75?Object.keys(G.aimWarn75).sort().join('/'):'-'];
   for(const e of G.enemies)r.push(oid(e),e.x,e.y,e.hp);return fnv(r.map(v=>typeof v==='number'?v.toPrecision(15):String(v)).join(','));};
"""
SCEN=r"""(J)=>{audioWake();T.fresh();G.save.tut.off=1;SET.fx=true;const enc=J.enc;
 if(enc!=='world'){const S=G.save;S.cleared=Math.max(S.cleared,9);for(let k=1;k<10;k++)S.medals[k]={clear:1};}
 if(enc==='m10'){enterNode(10);if(G.state==='intro')startMission();}
 else if(enc==='post'){postEnter();if(G.state==='intro')startMission();}
 let now=50000;performance.now=()=>now;last=now;window.__now=()=>now;window.__tick=()=>{now+=1000/60;frame(now);};return G.state;}"""
TRACE_RUN=r"""(J)=>{
 const LOG=[];let cur=null;
 for(const nm of J.names){let f;try{f=eval(nm);}catch(e){continue;}if(typeof f!=='function')continue;const w=function(){if(cur)cur.push(nm);return f.apply(this,arguments);};try{eval(nm+'=w');}catch(e){}}
 {const s=step74;step74=function(){cur=[];const r0=__rn;const out=s.apply(this,arguments);LOG.push([__rn-r0,fnv(cur.join(',')),cur.length,stH(),__rn]);cur=null;return out;};}
 for(let i=0;i<J.n;i++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);const p=G.player;
   if(p){p.hp=Math.max(p.hp,G.st.maxHp*.5);const A=i/90;steer2(p.x+Math.cos(A)*300,p.y+Math.sin(A)*300);if(i%(J.dash||170)===0)tryDash();if(p.en>=100)tryPulse();
     if(J.spawn&&i%150===10&&G.state==='play'){const n=G.enemies.filter(e=>e.alive&&(e.type==='membrane'||e.type==='railshield')).length;
       if(n<4){spawnEnemy('membrane',p.x+260,p.y-40);spawnEnemy('railshield',p.x-260,p.y+40);}}}
   __tick();if(G.state!=='play'&&G.state!=='world'&&G.state!=='levelup')break;}
 return {steps:LOG.length,log:LOG,st:G.state,special:G.enemies.filter(e=>e.type==='membrane'||e.type==='railshield').length};}"""
AIMMAN_RUN=r"""(J)=>{SET.manual=true;touchMode=false;const LOG=[];
 for(let i=0;i<J.n;i++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);const p=G.player;
   if(p){p.hp=Math.max(p.hp,G.st.maxHp*.5);const A=i/120;steer2(p.x+Math.cos(A)*250,p.y+Math.sin(A)*250);
     MOUSE.moved=true;MOUSE.sx=CW*(.5+.4*Math.sin(i/37));MOUSE.sy=CH*(.5+.35*Math.cos(i/53));MOUSE.down=(i%240)<90;
     if(i%300===150&&G.enemies.length){const e=G.enemies.find(e=>aimLockable(e));if(e){MOUSE.sx=(e.x-CX)*SC;MOUSE.sy=(e.y-CY)*SC;}}}
   __tick();LOG.push([stH(),oid(G.aimLock),p?+p.ang.toFixed(12):0]);if(G.state!=='play'&&G.state!=='levelup')break;}
 return {steps:LOG.length,log:LOG,locks:new Set(LOG.map(r=>r[1]).filter(x=>x>0)).size,st:G.state};}"""
PRIO_RUN=r"""(J)=>{touchMode=!!J.touch;const LOG=[];let taps=0,kills=0,miss=0,twice=0;
 for(let i=0;i<J.n;i++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);const p=G.player;
   if(p){p.hp=Math.max(p.hp,G.st.maxHp*.5);const A=i/90;steer2(p.x+Math.cos(A)*220,p.y+Math.sin(A)*220);}
   if(i%90===45){const c=(i/90|0)%5;const es=G.enemies.filter(e=>targetable(e));
     if(c===4){prioTap(4,4);miss++;}
     else if(es.length){const e=es.at((i/90|0)%es.length);prioTap((e.x-CX)*SC,(e.y-CY)*SC);taps++;if(J.touch&&c===1){prioTap((e.x-CX)*SC,(e.y-CY)*SC);twice++;}
       if(c===2&&G.prio&&G.prio.alive){kill(G.prio);kills++;}}}
   __tick();LOG.push([stH(),oid(G.prio),oid(G.tg90)]);if(G.state!=='play'&&G.state!=='levelup')break;}
 return {steps:LOG.length,log:LOG,taps,kills,miss,twice,st:G.state};}"""
BOOT_RUN=r"""async(J)=>{const out={};const enc=new TextEncoder();
 for(const nm of J.names){let f;try{f=eval(nm);}catch(e){out[nm]='нет';continue;}if(typeof f!=='function'){out[nm]=typeof f;continue;}
   const s=String(f);const h=await crypto.subtle.digest('SHA-256',enc.encode(s));out[nm]=[Array.from(new Uint8Array(h)).slice(0,8).map(b=>b.toString(16).padStart(2,'0')).join(''),f.length];}
 return {fns:out,ael:window.__ael,ver:VER_TAG,flags:Object.keys(ARCH.off).filter(k=>ARCH.off[k]),a24:!!ARCH.a24,a25:!!ARCH.a25};}"""
GUARD_INSTALL=r"""(J)=>{const F=['prio','aimLock','tg90','noTg75','aimWarn75'];const names=new Set(J.names);window.__gw={};window.__cov={};window.__covBy={};
 const who=()=>{if(window.__gwH)return '(стенд)';const st=(new Error().stack||'').split('\n').slice(2);for(const l of st){const m=l.match(/at (?:Object\.|Function\.)?([\w$]+) \(/);if(m&&names.has(m[1])&&m[1]!=='assign')return m[1];}return '(?)';};
 for(const f of F){let v=G[f];Object.defineProperty(G,f,{configurable:true,enumerable:true,get(){return v;},set(x){const u=who();const k=f+'|'+u;__gw[k]=(__gw[k]||0)+1;v=x;}});}
 for(const nm of J.cov){let fn;try{fn=eval(nm);}catch(e){continue;}if(typeof fn!=='function')continue;const api=(J.api||[]).includes(nm);const w=function(){__cov[nm]=(__cov[nm]||0)+1;if(api){const k=nm+'<'+who();__covBy[k]=(__covBy[k]||0)+1;}return fn.apply(this,arguments);};try{eval(nm+'=w');}catch(e){}}
 return Object.keys(G).length;}"""
GUARD_COV=['updatePlayer','aimStep','autoFireWanted','prioSet','prioClear','aimLockClear','pickTarget','aimFallback','prioTap','kill','startAnom','storyRetreat','loopIntercept80','startEndless','setupMission0','enterWorldAt']
AUDIO_RUN=r"""()=>{const out={};if(typeof musTarget!=='function')return {err:'нет musTarget'};
 G.m=3;G.post=1;let r1;try{r1=musTarget();out.normal={ok:true,restored:G.m===3,id:r1&&r1.id};}catch(e){out.normal={ok:false,err:String(e),restored:G.m===3};}
 const d=Object.getOwnPropertyDescriptor(G,'state');let s=G.state;
 Object.defineProperty(G,'state',{configurable:true,get(){if(G.m===CORE)throw new Error('probe');return s;},set(x){s=x;}});
 try{musTarget();out.thrown={threw:false,restored:G.m===3};}catch(e){out.thrown={threw:String(e.message)==='probe',restored:G.m===3};}
 Object.defineProperty(G,'state',d);G.post=0;return out;}"""
FLAGS_RUN=r"""()=>({off:Object.keys(ARCH.off).filter(k=>ARCH.off[k]).sort(),a24:!!ARCH.a24,a25:!!ARCH.a25,a26:ARCH.a26===undefined?null:!!ARCH.a26,ver:VER_TAG})"""
PROBES_RUN=r"""(J)=>{const LOG=[];const L=(k)=>LOG.push([k,oid(G.prio),oid(G.aimLock),oid(G.tg90),G.noTg75||0,G.mc?G.mc.prioKills||0:-1,stH()]);
 const step=n=>{for(let i=0;i<n;i++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);const p=G.player;if(p)p.hp=Math.max(p.hp,G.st.maxHp*.6);__tick();}};
 const tap=e=>prioTap((e.x-CX)*SC,(e.y-CY)*SC);const alive=()=>G.enemies.filter(e=>targetable(e));
 step(90);L('start');
 {const p=G.player;for(let i=0;i<4;i++){const e=spawnEnemy('gunner',p.x+120+i*40,p.y-60+i*40,{noAffix:true});if(e)e.spawnT=0;}step(3);}
 let es=alive();if(es[0]){tap(es[0]);L('tap');kill(es[0]);L('kill-prio');step(5);}
 es=alive();if(es.length>1){tap(es[0]);kill(es[1]);L('kill-other');step(5);}
 es=alive();if(es[0]){tap(es[0]);storyRetreat(es[0]);L('retreat-prio');step(5);}
 es=alive();if(es.length>1){tap(es[0]);storyRetreat(es[1]);L('retreat-other');step(5);}
 {const p=G.player;const lp=spawnEnemy('loop',p.x+200,p.y);lp.spawnT=0;step(2);if(targetable(lp))tap(lp);else{window.__gwH=1;G.prio=lp;window.__gwH=0;}L('loop-prio');kill(lp);L('loop-kill');step(5);}
 {const p=G.player;const tw=spawnEnemy('twin',p.x-200,p.y,{pair:'p5'});const tw2=spawnEnemy('twin',p.x-240,p.y,{pair:'p5'});if(tw)tw.spawnT=0;if(tw2)tw2.spawnT=0;step(2);const m=tw.mate;L('twin-mate:'+(!!m));if(targetable(tw))tap(tw);else{window.__gwH=1;G.prio=tw;window.__gwH=0;}kill(tw);L('twin-kill');step(5);}
 {const p=G.player;startAnom({kind:'chase',x:p.x+300,y:p.y});L('anom');step(30);L('anom-30');}
 {const es2=alive();if(es2[0]){window.__gwH=1;G.aimLock=es2[0];window.__gwH=0;}L('pre-endless');startEndless();L('endless');step(60);L('endless-60');}
 return {steps:LOG.length,log:LOG,st:G.state};}"""
def gnames(build):
    import subprocess
    r=subprocess.run(['node',os.path.join(os.path.dirname(os.path.abspath(__file__)),'names5.js'),build],capture_output=True,text=True,check=True);return json.loads(r.stdout)
async def pf(pg,res):
    # флаги, фактически действующие на странице (ARCH.off, ARCH.a24/a25/a26); расхождение между прогонами — ошибка стенда
    f=await pg.evaluate(FLAGS_RUN);f.pop('ver',None)
    if res.get('pageFlags') is None:res['pageFlags']=f
    elif res['pageFlags']!=f:raise SystemExit('st5: флаги страницы различаются между прогонами: %r / %r'%(res['pageFlags'],f))
async def main():
    mode,build,out=sys.argv[1],sys.argv[2],sys.argv[3];res={'mode':mode,'build':os.path.basename(build),'sha':hashlib.sha256(open(build,'rb').read()).hexdigest()[:16],
      'a24':os.environ.get('VOID_A24')=='1','off':os.environ.get('VOID_OFF',''),'pageFlags':None}  # a24/off — заявка окружения; pageFlags — фактическое
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path=CHROME,args=['--no-sandbox']) if CHROME else await pw.chromium.launch(args=['--no-sandbox'])
        if mode in('audio','flags'):
            ctx,pg,errs=await page(b,build);await pg.wait_for_timeout(500)
            r=await pg.evaluate(AUDIO_RUN if mode=='audio' else FLAGS_RUN);r['errs']=errs[:3];res.update(r);await ctx.close()
            print(mode,json.dumps(r,ensure_ascii=False)[:400],flush=True)
        elif mode=='guard':
            names=gnames(build);res['runs']={}
            for enc,n,extra,touch,kind in [('m10',1200,{},False,'trace'),('m10',900,{'spawn':True},False,'trace'),('post',900,{'dash':45},False,'trace'),('world',900,{},False,'trace'),
                                           ('m10',1500,{},False,'aimman'),('m10',1800,{},False,'prio'),('m10',1800,{'touch':True},True,'prio'),('m10',0,{},False,'probes')]:
                ctx,pg,errs=await (page(b,build,390,844,True) if touch else page(b,build))
                await pf(pg,res);await pg.evaluate(COMMON);await pg.evaluate(GUARD_INSTALL,{'names':names,'cov':GUARD_COV,'api':['prioSet','prioClear','aimLockClear']});st=await pg.evaluate(SCEN,{'enc':enc})
                J=dict(n=n,names=TRACE,**extra);await pg.evaluate({'trace':TRACE_RUN,'aimman':AIMMAN_RUN,'prio':PRIO_RUN,'probes':PROBES_RUN}[kind],J)
                gw=await pg.evaluate("()=>({w:__gw,c:__cov,by:__covBy})");key=f"{kind}-{enc}"+('-spawn' if extra.get('spawn') else '')+('-touch' if touch else '')
                res['runs'][key]={'writers':gw['w'],'cov':gw['c'],'covBy':gw['by'],'start':st,'errs':errs[:3]};await ctx.close()
                print('guard',key,json.dumps(gw,ensure_ascii=False)[:300],flush=True)
        elif mode=='gkeys':
            # ключи G в порядке перечисления (его читает for-in, например ip76) — после сценариев trace m10 и probes
            res['runs']={}
            for enc,n,kind in [('m10',1200,'trace'),('world',900,'trace'),('m10',0,'probes')]:
                ctx,pg,errs=await page(b,build);await pf(pg,res);await pg.evaluate(COMMON);st=await pg.evaluate(SCEN,{'enc':enc})
                k0=await pg.evaluate("()=>Object.keys(G)")
                await pg.evaluate({'trace':TRACE_RUN,'probes':PROBES_RUN}[kind],dict(n=n,names=TRACE))
                k1=await pg.evaluate("()=>Object.keys(G)");res['runs'][kind+'-'+enc]={'log':[k0,k1],'errs':errs[:3]};await ctx.close()
                print('gkeys',kind,enc,len(k0),len(k1),flush=True)
        elif mode=='boot':
            ctx,pg,errs=await page(b,build);await pg.wait_for_timeout(800);await pf(pg,res)
            r=await pg.evaluate(BOOT_RUN,{'names':gnames(build)});r['errs']=errs;res.update(r);await ctx.close()
        else:
            jobs={'trace':[('m10',1200,{},False),('world',1200,{},False),('post',1200,{'dash':45},False),('m10s',900,{'spawn':True},False)],
                  'aimman':[('m10',1500,{},False)],
                  'probes':[('m10',0,{},False)],
                  'prio':[('m10',1800,{},False),('m10',1800,{'touch':True},True)]}[mode]
            res['runs']={}
            for enc,n,extra,touch in jobs:
                ctx,pg,errs=await (page(b,build,390,844,True) if touch else page(b,build))
                await pf(pg,res);await pg.evaluate(COMMON);st=await pg.evaluate(SCEN,{'enc':'m10' if enc=='m10s' else enc})
                J=dict(n=n,names=TRACE,**extra)
                r=await pg.evaluate({'trace':TRACE_RUN,'aimman':AIMMAN_RUN,'prio':PRIO_RUN,'probes':PROBES_RUN}[mode],J)
                r['start']=st;r['errs']=errs[:3];key=enc+('-touch' if touch else '');res['runs'][key]=r;await ctx.close()
                print(mode,key,'шагов',r['steps'],{k:v for k,v in r.items() if k not in('log','errs')},errs[:1],flush=True)
        await b.close()
    json.dump(res,open(out,'w'),ensure_ascii=False)
if __name__=='__main__':asyncio.run(main())
