// Этап 5 · own5 — анализ записей полей наведения и звука по AST (заменяет текстовые проверки check5 для этих правил).
//   node tools5/own5.js <сборка.html> [--manifest tools5/ownership5.json] [--stage N] [--emit] [--json out.json]
// Выход: 0 — нарушений нет и неопределённых записей в активной конфигурации нет;
//        1 — нарушение (незарегистрированная запись, новый вызов API, нарушение fallbackTwin, звука, чистоты запросов);
//        2 — нарушений нет, но есть неопределённые записи в активной конфигурации (вердикт «не доказано»);
//        3 — ошибка самого инструмента (не удалось разобрать сборку и т. п.).
// Что считается записью поля F объекта G: присваивание (=, +=, ||= …), ++/--, delete, цель деструктуризации, левая часть for-in/of,
//   Object.assign(G, {F:…}), Object.defineProperty(G,'F',…), Object.defineProperties(G,{F:…}), Reflect.set(G,'F',…), Reflect.deleteProperty(G,'F').
// Объект — это G, если выражение — идентификатор, разрешающийся (eslint-scope) в глобальную const G или в её псевдоним
//   (переменная, все записи которой — идентификатор G; переменные циклов for-in/of псевдонимами не считаются).
// Неопределённо: вычисляемый ключ записи в G; Object.assign(G, не-литерал) или ...spread; запись F в параметр функции или в
//   переменную неизвестного происхождения при «утечке» G (G передаётся куда-либо, кроме первого аргумента Object.assign/Reflect/defineProperty,
//   возвращается, кладётся в свойство, массив или объект); составное условие флага A-26 над записью.
const path=require('path'),fs=require('fs'),crypto=require('crypto');
process.on('uncaughtException',e=>{console.error('own5: внутренняя ошибка инструмента: '+(e&&e.stack||e));process.exit(3);});
const NM=process.env.NODE_TOOLS||path.join(__dirname,'..','node_modules');
const acorn=require(path.join(NM,'acorn')),walk=require(path.join(NM,'acorn-walk')),escope=require(path.join(NM,'eslint-scope'));
const argv=process.argv.slice(2);const opt=k=>{const i=argv.indexOf(k);return i<0?null:argv[i+1];};
const sha=s=>crypto.createHash('sha256').update(s).digest('hex').slice(0,16);
let html,src,ast,sm;
try{
  html=fs.readFileSync(argv[0],'utf8');
  // основной скрипт — тот, что начинается с "use strict" (в сборках с A-24 перед ним стоит маленький <script>)
  const k=html.indexOf('<script>\n"use strict";');if(k<0)throw new Error('не найден основной <script> с "use strict"');
  const j=html.indexOf('</script>',k);src=html.slice(k+8,j);
  ast=acorn.parse(src,{ecmaVersion:2022,sourceType:'script',ranges:true,locations:true});
  sm=escope.analyze(ast,{ecmaVersion:2022});
}catch(e){console.error('own5: ошибка разбора: '+e.message);process.exit(3);}
const M=JSON.parse(fs.readFileSync(opt('--manifest')||path.join(__dirname,'ownership5.json'),'utf8'));
const F=new Set(M.fields);
const verTag=(src.match(/const VER_TAG='(1\.5\.(\d+)) α'/)||[]);
const STAGE=opt('--stage')!=null?+opt('--stage'):(verTag[2]?60+ +verTag[2]:0); // 1.5.21 → 81, 1.5.22 → 82 …
const line=n=>n.loc.start.line, txt=n=>src.slice(n.range[0],n.range[1]);
// --- разрешение идентификаторов
const refOf=new Map();for(const s of sm.scopes)for(const r of s.references)refOf.set(r.identifier,r);
const gvar=sm.globalScope.set.get('G');if(!gvar){console.error('own5: нет глобальной G');process.exit(3);}
const forHead=new Set();walk.full(ast,n=>{if((n.type==='ForInStatement'||n.type==='ForOfStatement')&&n.left.type==='VariableDeclaration')for(const d of n.left.declarations)walk.full(d.id,x=>{if(x.type==='Identifier')forHead.add(x);});});
const isGref=id=>{const r=refOf.get(id);return !!(r&&r.resolved===gvar);};
const alias=new Set(),aliasMixed=new Set();
for(const s of sm.scopes)for(const v of s.variables){if(v===gvar)continue;if(v.defs.some(d=>forHead.has(d.name)))continue;
  const ws=v.references.filter(r=>r.isWrite());if(!ws.length)continue;
  const fromG=ws.filter(r=>r.writeExpr&&r.writeExpr.type==='Identifier'&&isGref(r.writeExpr));
  if(fromG.length===ws.length)alias.add(v);else if(fromG.length)aliasMixed.add(v);}
const objClass=o=>{ // 'G' | 'alias' | 'param' | 'mixed' | 'other'
  if(o.type!=='Identifier')return 'other';const r=refOf.get(o);if(!r||!r.resolved)return o.name==='G'?'G':'other';
  if(r.resolved===gvar)return 'G';if(alias.has(r.resolved))return 'alias';if(aliasMixed.has(r.resolved))return 'mixed';
  if(r.resolved.defs.some(d=>d.type==='Parameter'))return 'param';return 'other';};
const keyOf=m=>{if(!m.computed)return m.property.type==='Identifier'?m.property.name:undefined;const p=m.property;
  if(p.type==='Literal'&&typeof p.value==='string')return p.value;if(p.type==='TemplateLiteral'&&!p.expressions.length)return p.quasis[0].value.cooked;return undefined;};
// --- утечки G: всё, кроме чтения поля G.x / G['x'], сравнения и первого аргумента разрешённых функций
const SAFE_CALL=new Set(['Object.assign','Object.defineProperty','Object.defineProperties','Reflect.set','Reflect.deleteProperty','Object.keys','Object.entries','Object.values','JSON.stringify']);
const calleeName=c=>c.type==='MemberExpression'&&!c.computed&&c.object.type==='Identifier'?c.object.name+'.'+c.property.name:(c.type==='Identifier'?c.name:'');
// --- единица кода, ветка флага, оператор
const TOPFN=new Map();for(const s of ast.body)if(s.type==='FunctionDeclaration')TOPFN.set(s,s.id.name);
const globFnVars=new Set(sm.globalScope.variables.filter(v=>v.defs.some(d=>d.type==='FunctionName')));
const wrapNames=new Map(); // верхнеуровневый оператор → имена переустанавливаемых им глобальных функций
for(const s of ast.body){if(s.type==='FunctionDeclaration')continue;const names=new Set();
  walk.full(s,n=>{if(n.type==='AssignmentExpression'&&n.left.type==='Identifier'){const r=refOf.get(n.left);if(r&&r.resolved&&globFnVars.has(r.resolved))names.add(n.left.name);}});
  if(names.size)wrapNames.set(s,[...names].sort());}
function unitOf(st){const top=st[1];if(!top)return '(программа)';if(TOPFN.has(top))return TOPFN.get(top);
  if(wrapNames.has(top))return '(обёртка '+wrapNames.get(top).join(',')+')';return '(верхний уровень@'+line(top)+')';}
const escapes=[];
walk.ancestor(ast,{Identifier(n,st){if(!isGref(n))return;const p=st[st.length-2];if(!p)return;
  if(p.type==='MemberExpression'&&p.object===n)return;
  if((p.type==='BinaryExpression')||(p.type==='UnaryExpression'&&p.operator==='typeof'))return;
  if(p.type==='ForInStatement'&&p.right===n)return;
  if(p.type==='CallExpression'&&p.arguments[0]===n&&SAFE_CALL.has(calleeName(p.callee)))return;
  if(p.type==='VariableDeclarator'&&p.id===n)return;
  if(p.type==='VariableDeclarator'&&p.init===n&&p.id.type==='Identifier'){const r=[...refOf.values()].find(r=>r.identifier===p.id);if(r&&alias.has(r.resolved))return;}
  if(p.type==='AssignmentExpression'&&p.right===n&&p.left.type==='Identifier'){const r=refOf.get(p.left);if(r&&r.resolved&&alias.has(r.resolved))return;}
  escapes.push(`${unitOf(st)}@${line(n)}: ${txt(p).slice(0,80)}`);}});
const FLAG=M.flag; // {name:'A-26', prop:'a26'}
function pred(t){ // 'A' — истинно ⇔ активный путь; 'F' — истинно ⇔ откат; 'X' — выражение упоминает флаг сложнее; null — не про флаг
  const isProp=e=>e.type==='MemberExpression'&&!e.computed&&e.object.type==='Identifier'&&e.object.name==='ARCH'&&e.property.name===FLAG.prop;
  const isOff=e=>e.type==='MemberExpression'&&e.computed&&e.object.type==='MemberExpression'&&!e.object.computed&&e.object.object.type==='Identifier'&&e.object.object.name==='ARCH'&&e.object.property.name==='off'&&e.property.type==='Literal'&&e.property.value===FLAG.name;
  const neg=e=>e.type==='UnaryExpression'&&e.operator==='!'?e.argument:null;
  if(isProp(t))return 'A';if(isOff(t))return 'F';const a=neg(t);if(a&&isProp(a))return 'F';if(a&&isOff(a))return 'A';
  let m=false;walk.full(t,e=>{if(isProp(e)||isOff(e))m=true;});return m?'X':null;}
const opp=p=>p==='A'?'F':p==='F'?'A':p;
function branchOf(st){const seen=[];
  for(let k=st.length-1;k>0;k--){const x=st[k-1],ch=st[k];let p=null;
    if((x.type==='IfStatement'||x.type==='ConditionalExpression')&&ch!==x.test){p=pred(x.test);if(p&&ch===x.alternate)p=opp(p);}
    else if(x.type==='LogicalExpression'&&ch===x.right){p=pred(x.left);if(p&&x.operator==='||')p=opp(p);if(p&&x.operator==='??')p='X';}
    if(p)seen.push(p);}
  if(seen.includes('X'))return 'undetermined';if(seen.includes('F')&&seen.includes('A'))return 'dead';if(seen.includes('F'))return 'fallback';if(seen.includes('A'))return 'active';return 'always';}
const isStmt=(s,k)=>/Statement$|Declaration$/.test(s.type)&&s.type!=='BlockStatement'&&!(s.type==='FunctionDeclaration'&&k<=1);
const stmtOf=st=>{for(let k=st.length-1;k>=0;k--)if(isStmt(st[k],k))return st[k];return st[0];};
// место записи = sha(текст объемлющего оператора верхнего уровня внутри единицы + '|' + текст ближайшего оператора); плюс порядковый номер
// записи этого поля в единице — новая запись даже с тем же текстом меняет номера и не совпадает с реестром
const siteOf=st=>{let inner=null,outer=null;for(let k=st.length-1;k>=0;k--)if(isStmt(st[k],k)){if(!inner)inner=st[k];else{outer=st[k];break;}}
  return sha((outer&&outer.type!=='FunctionDeclaration'?txt(outer):'')+'|'+txt(inner||st[0]));};
// --- сбор записей
const W=[],UND=[],NESTED=[],viol0=[];
function rec(field,kind,objNode,st,via){const unit=unitOf(st),b=branchOf(st),s=stmtOf(st);
  W.push({unit,field,kind,via,pos:objNode.range[0],line:line(objNode),branch:b,site:siteOf(st),text:txt(s).slice(0,110).replace(/\s+/g,' ')});}
function target(m,st,kind){if(!m||m.type!=='MemberExpression')return;const oc=objClass(m.object),k=keyOf(m);
  if(m.object.type==='MemberExpression'){let b=m.object;while(b.type==='MemberExpression')b=b.object;
    if(b.type==='Identifier'&&isGref(b)){let first=m.object;while(first.object.type==='MemberExpression')first=first.object;const k0=keyOf(first);if(F.has(k0))NESTED.push(`${unitOf(st)}@${line(m)} ${txt(m).slice(0,60)}`);}return;}
  if(oc==='G'||oc==='alias'){if(k===undefined)UND.push({unit:unitOf(st),line:line(m),why:'вычисляемый ключ записи в G',text:txt(m).slice(0,80),branch:branchOf(st)});
    else if(F.has(k))rec(k,kind,m,st,oc);}
  else if(oc==='mixed'&&k!==undefined&&F.has(k))UND.push({unit:unitOf(st),line:line(m),why:'запись в переменную, иногда равную G',text:txt(m).slice(0,80),branch:branchOf(st)});
  else if(escapes.length&&(k===undefined||F.has(k)))UND.push({unit:unitOf(st),line:line(m),why:'G утекает из-под контроля анализатора, а здесь пишется поле наведения в объект неизвестного происхождения',text:txt(m).slice(0,80),branch:branchOf(st)});}
function pat(p,st,kind){if(!p)return;if(p.type==='MemberExpression')return target(p,st,kind);
  if(p.type==='ObjectPattern')p.properties.forEach(q=>pat(q.type==='RestElement'?q.argument:q.value,st,kind));
  else if(p.type==='ArrayPattern')p.elements.forEach(q=>pat(q,st,kind));else if(p.type==='AssignmentPattern')pat(p.left,st,kind);else if(p.type==='RestElement')pat(p.argument,st,kind);}
const litKeys=(o,st,kind,objNode)=>{if(o.type!=='ObjectExpression'){UND.push({unit:unitOf(st),line:line(objNode),why:kind+' с нелитеральным аргументом',text:txt(o).slice(0,60),branch:branchOf(st)});return;}
  for(const p of o.properties){if(p.type==='SpreadElement'){UND.push({unit:unitOf(st),line:line(p),why:kind+' со spread',text:txt(p).slice(0,60),branch:branchOf(st)});continue;}
    const k=p.computed?(p.key.type==='Literal'?String(p.key.value):undefined):(p.key.name!==undefined?p.key.name:String(p.key.value));
    if(k===undefined)UND.push({unit:unitOf(st),line:line(p),why:kind+' с вычисляемым ключом',text:txt(p).slice(0,60),branch:branchOf(st)});else if(F.has(k))rec(k,kind,p,st,'G');}};
const strKey=a=>a&&a.type==='Literal'&&typeof a.value==='string'?a.value:(a&&a.type==='TemplateLiteral'&&!a.expressions.length?a.quasis[0].value.cooked:undefined);
walk.ancestor(ast,{
  AssignmentExpression(n,st){pat(n.left,st,n.operator);},
  UpdateExpression(n,st){target(n.argument,st,n.operator);},
  UnaryExpression(n,st){if(n.operator==='delete')target(n.argument,st,'delete');},
  ForInStatement(n,st){if(n.left.type!=='VariableDeclaration')pat(n.left,st,'for-in');},
  ForOfStatement(n,st){if(n.left.type!=='VariableDeclaration')pat(n.left,st,'for-of');},
  CallExpression(n,st){const nm=calleeName(n.callee),a0=n.arguments[0];if(!a0)return;const oc=objClass(a0);if(oc!=='G'&&oc!=='alias')return;
    if(nm==='Object.assign')n.arguments.slice(1).forEach(a=>litKeys(a,st,'Object.assign',n));
    else if(nm==='Object.defineProperties')litKeys(n.arguments[1]||a0,st,'defineProperties',n);
    else if(nm==='Object.defineProperty'||nm==='Reflect.set'||nm==='Reflect.deleteProperty'){const k=strKey(n.arguments[1]);
      if(k===undefined)UND.push({unit:unitOf(st),line:line(n),why:nm+' с вычисляемым ключом',text:txt(n).slice(0,60),branch:branchOf(st)});else if(F.has(k))rec(k,nm,n,st,oc);}}});
// неопределённые конструкции
const DYN=[];walk.ancestor(ast,{CallExpression(n,st){if(n.callee.type==='Identifier'&&n.callee.name==='eval'&&!refOf.get(n.callee)?.resolved)DYN.push('eval@'+line(n));},
  NewExpression(n,st){if(n.callee.type==='Identifier'&&(n.callee.name==='Function'||n.callee.name==='Proxy'))DYN.push(n.callee.name+'@'+line(n));},
  WithStatement(n){DYN.push('with@'+line(n));}});
walk.ancestor(ast,{CallExpression(n){const c=n.callee;if(c.type==='Identifier'&&['setTimeout','setInterval'].includes(c.name)&&n.arguments[0]&&(n.arguments[0].type==='Literal'||n.arguments[0].type==='TemplateLiteral'||n.arguments[0].type==='BinaryExpression'))DYN.push(c.name+'(строка)@'+line(n));}});
for(const d of DYN)UND.push({unit:'(динамический код)',line:+d.split('@')[1],why:'исполнение строки как кода — запись в G невозможно проверить статически',text:d,branch:'always'});
for(const e of escapes)UND.push({unit:e.split('@')[0],line:+e.split('@')[1].split(':')[0],why:'G передаётся или сохраняется вне разрешённых форм (возможен скрытый псевдоним)',text:e,branch:'always'});
// объявления функций-владельцев: число на верхнем уровне должно совпадать с манифестом (подмена дублем владельца = попытка обхода)
for(const u of M.ownerUnits){const n=ast.body.filter(s=>s.type==='FunctionDeclaration'&&s.id.name===u).length,exp=(M.ownerDecls||{})[u];
  if(exp!=null&&n!==exp)viol0.push(`функция-владелец ${u}: объявлений ${n}, ожидалось ${exp}`);
  else if(exp==null&&n>1)viol0.push(`функция-владелец ${u}: объявлений ${n}, допускается одно`);}
W.sort((a,b)=>a.pos-b.pos);{const c={};for(const w of W){const k=w.unit+'|'+w.field;c[k]=(c[k]||0)+1;w.nth=c[k];}}
// --- классификация по реестру
const OWN=new Set(M.ownerUnits);const REG=M.registry;
const allowed=w=>{if(OWN.has(w.unit))return {cls:'owner'};
  for(const r of REG){if(r.unit!==w.unit||r.field!==w.field||r.site!==w.site||(r.nth!=null&&r.nth!==w.nth))continue;if(r.kind&&r.kind!==w.kind)continue;
    if(r.from!=null&&STAGE<r.from)continue;if(r.until!=null&&STAGE>=r.until)continue;if(r.branch&&r.branch!==w.branch)continue;return r;}return null;};
const viol=[...viol0];
const nearMiss=w=>REG.some(r=>r.unit===w.unit&&r.field===w.field&&r.site===w.site&&(r.nth==null||r.nth===w.nth)&&r.branch&&w.branch==='undetermined');
for(const w of W){const a=allowed(w);w.cls=a?a.cls:'НЕЗАРЕГИСТРИРОВАНА';
  if(!a&&nearMiss(w)){w.cls='НЕОПРЕДЕЛЕНА';UND.push({unit:w.unit,line:w.line,why:'зарегистрированная запись стоит под составным условием флага',text:w.text,branch:'undetermined'});continue;}
  if(!a)viol.push(`незарегистрированная запись G.${w.field} (${w.kind}) в ${w.unit}@${w.line} №${w.nth} [${w.branch}] site=${w.site}: ${w.text}`);}
const ext=W.filter(w=>w.cls!=='owner');const uniq=a=>[...new Set(a)].sort();
const isFb=w=>w.branch==='fallback'||w.branch==='dead';
const activeUND=UND.filter(u=>u.branch!=='fallback'&&u.branch!=='dead');
// --- API наведения: внешние места вызова
const API=new Set(M.api||[]);const apiSites=[];
walk.ancestor(ast,{CallExpression(n,st){if(n.callee.type!=='Identifier'||!API.has(n.callee.name))return;const r=refOf.get(n.callee);
  if(!(r&&r.resolved&&globFnVars.has(r.resolved)))return;const u=unitOf(st);if(OWN.has(u))return;apiSites.push({unit:u,fn:n.callee.name,site:siteOf(st),line:line(n)});}});
// сверка как мультимножеств: ключ место+функция, число вызовов в нём должно совпасть с реестром (n, по умолчанию 1);
// зарегистрированное место, которого нет в сборке, — тоже нарушение (замена пропала или изменилась)
const apiKey=a=>`${a.unit}|${a.fn}|${a.site}`;const apiExp=new Map();for(const a of (M.apiSites||[]).filter(a=>(a.from==null||STAGE>=a.from)))apiExp.set(apiKey(a),(apiExp.get(apiKey(a))||0)+(a.n||1));
const apiGot=new Map();for(const a of apiSites)apiGot.set(apiKey(a),(apiGot.get(apiKey(a))||0)+1);
for(const a of apiSites){const k=apiKey(a);if(!apiExp.has(k))viol.push(`новое внешнее место вызова ${a.fn} в ${a.unit}@${a.line} site=${a.site}`);}
for(const [k,n] of apiGot)if(apiExp.has(k)&&apiExp.get(k)!==n)viol.push(`число вызовов в зарегистрированном месте ${k}: ожидалось ${apiExp.get(k)}, найдено ${n}`);
for(const [k,n] of apiExp)if(!apiGot.has(k))viol.push(`зарегистрированное место вызова API отсутствует: ${k}`);
// тела функций API — ровно объявленный текст (никакой логики сверх присваивания), по одному объявлению верхнего уровня
if(M.apiBodies&&STAGE>=M.apiBodies.from)for(const [nm,txt] of Object.entries(M.apiBodies.text)){const ds=ast.body.filter(s=>s.type==='FunctionDeclaration'&&s.id.name===nm);
  if(ds.length!==1)viol.push(`функция API ${nm}: объявлений верхнего уровня ${ds.length}, ожидалось 1`);else if(src.slice(ds[0].range[0],ds[0].range[1])!==txt)viol.push(`тело функции API ${nm} отличается от объявленного: ${src.slice(ds[0].range[0],ds[0].range[1]).slice(0,120)}`);}
// API как значение (не прямой вызов): f=prioSet, arr.forEach(prioClear), setTimeout(prioSet) — запись уходит из-под учёта мест
walk.ancestor(ast,{Identifier(n,st){if(!API.has(n.name))return;const p=st[st.length-2];
  if(p&&p.type==='CallExpression'&&p.callee===n)return;if(p&&p.type==='FunctionDeclaration'&&p.id===n)return;
  if(p&&p.type==='MemberExpression'&&p.property===n&&!p.computed)return;if(p&&(p.type==='Property'&&p.key===n&&!p.computed&&!p.shorthand))return;
  const r=refOf.get(n);if(!(r&&r.resolved&&globFnVars.has(r.resolved)))return;
  viol.push(`функция API ${n.name} используется как значение, не прямым вызовом, в ${unitOf(st)}@${line(n)}`);}});
// --- чистота запросов: функции-запросы не пишут G вовсе
const QW=[];const Q=new Set(M.queries||[]);
walk.ancestor(ast,{AssignmentExpression(n,st){const u=unitOf(st);if(!Q.has(u))return;let b=n.left;while(b.type==='MemberExpression')b=b.object;if(b.type==='Identifier'&&(isGref(b)||objClass(b)==='alias'))QW.push(`${u}@${line(n)} ${txt(n.left).slice(0,40)}`);},
  UpdateExpression(n,st){const u=unitOf(st);if(!Q.has(u))return;let b=n.argument;while(b.type==='MemberExpression')b=b.object;if(b.type==='Identifier'&&isGref(b))QW.push(`${u}@${line(n)}`);}});
for(const q of QW)viol.push('функция-запрос пишет G: '+q);
// --- звук: записи G (любого поля) в функциях звука и в обёртках, переустанавливающих функции звука
const AUD=new Set(M.audio.functions);const isAudioUnit=u=>AUD.has(u)||(/^\(обёртка /.test(u)&&u.slice(9,-1).split(',').some(x=>AUD.has(x)));
const AW=[];walk.ancestor(ast,{AssignmentExpression(n,st){const u=unitOf(st);if(!isAudioUnit(u))return;let m=n.left;if(m.type!=='MemberExpression')return;let b=m;while(b.object.type==='MemberExpression')b=b.object;
  if(b.object.type==='Identifier'&&isGref(b.object))AW.push({unit:u,field:keyOf(b),line:line(n),inFinally:st.some((x,i)=>x.type==='TryStatement'&&st[i+1]===x.finalizer),text:txt(n).slice(0,40)});}});
const audioOk=(()=>{const al=M.audio.allowed;const bad=[];const groups={};for(const w of AW)(groups[w.unit+'|'+w.field]=groups[w.unit+'|'+w.field]||[]).push(w);
  for(const [k,ws] of Object.entries(groups)){const a=al.find(x=>x.unit+'|'+x.field===k);
    if(!a){bad.push('звук пишет G без разрешения: '+ws.map(w=>`${w.unit}@${w.line} ${w.text}`).join('; '));continue;}
    if(ws.length!==a.count)bad.push(`звук: ${k} — записей ${ws.length}, разрешено ${a.count}`);
    if(a.restoreInFinally&&ws.filter(w=>w.inFinally).length!==1)bad.push(`звук: ${k} — нет ровно одного восстановления в finally`);}
  for(const a of al)if(!groups[a.unit+'|'+a.field])bad.push(`звук: разрешённая запись ${a.unit}|${a.field} не найдена (изменилась обёртка?)`);
  return bad;})();
viol.push(...audioOk);
// --- fallbackTwin: тело aimStep (без return tg) == ветка отката A-26 в updatePlayer == эталонный текст 1.5.21
const toks=s=>{const out=[];for(const t of acorn.tokenizer(s,{ecmaVersion:2022}))out.push(t.type.label==='name'||t.type.label==='num'||t.type.label==='string'?String(t.value):t.type.label);return out.join(' ');};
let twin={present:false};
const aimStepDecl=ast.body.filter(s=>s.type==='FunctionDeclaration'&&s.id.name==='aimStep').at(-1);
if(aimStepDecl&&M.twin){twin.present=true;const body=aimStepDecl.body.body;const last=body.at(-1);
  const bodyTxt=body.slice(0,-1).map(txt).join('\n');const retOk=last&&last.type==='ReturnStatement'&&last.argument&&last.argument.type==='Identifier'&&last.argument.name==='tg';
  const up=ast.body.filter(s=>s.type==='FunctionDeclaration'&&s.id.name==='updatePlayer').at(-1);
  let fb=null;walk.full(up,n=>{if(n.type==='IfStatement'&&pred(n.test)==='A'&&n.alternate&&n.alternate.type==='BlockStatement')fb=n;});
  const fbTxt=fb?fb.alternate.body.map(txt).join('\n'):'';
  const tA=toks(bodyTxt),tF=toks(fbTxt);const ref=M.twin.refTokensSha;
  const norm=t=>t.replace(/^let tg = /,'tg = ');
  twin={present:true,returnTg:retOk,fallbackFound:!!fb,aimStepTokens:sha(norm(tA)),fallbackTokens:sha(norm(tF)),ref,
    equal:norm(tA)===norm(tF),equalsRef:sha(norm(tA))===ref};
  if(!retOk)viol.push('fallbackTwin: aimStep не заканчивается «return tg»');
  if(!fb)viol.push('fallbackTwin: в updatePlayer не найдена ветка отката (if(ARCH.a26){…}else{…})');
  else if(!twin.equal)viol.push('fallbackTwin: тело aimStep и ветка отката A-26 различаются');
  if(!twin.equalsRef)viol.push('fallbackTwin: тело aimStep отличается от текста 1.5.21');
  // вторая пара: выражение autoFireWanted == ветка отката в const shoot=ARCH.a26?autoFireWanted(man,tg):(…) == выражение shoot 1.5.21
  const af=ast.body.filter(s=>s.type==='FunctionDeclaration'&&s.id.name==='autoFireWanted').at(-1);
  let sh=null;walk.full(up,n=>{if(n.type==='VariableDeclarator'&&n.id.type==='Identifier'&&n.id.name==='shoot'&&n.init&&n.init.type==='ConditionalExpression'&&pred(n.init.test)==='A')sh=n.init;});
  const afRet=af&&af.body.body.length===1&&af.body.body[0].type==='ReturnStatement'?af.body.body[0].argument:null;
  const a2=afRet?toks(txt(afRet)):'',f2=sh?toks(txt(sh.alternate).replace(/^\(([\s\S]*)\)$/,'$1')):'';
  twin.shoot={found:!!(af&&sh),equal:a2===f2,equalsRef:sha(a2)===M.twin.refShootSha,callOk:!!(sh&&sh.consequent.type==='CallExpression'&&sh.consequent.callee.name==='autoFireWanted')};
  if(!af||!sh)viol.push('fallbackTwin: не найдены autoFireWanted или условие shoot с веткой отката');
  else{if(!twin.shoot.equal)viol.push('fallbackTwin: autoFireWanted и ветка отката shoot различаются');if(!twin.shoot.equalsRef)viol.push('fallbackTwin: autoFireWanted отличается от выражения shoot 1.5.21');if(!twin.shoot.callOk)viol.push('fallbackTwin: активная ветка shoot — не вызов autoFireWanted');}}
if(argv.includes('--twinref')){const T=JSON.parse(fs.readFileSync(opt('--twinref'),'utf8'));const norm=x=>x.replace(/^let tg = /,'tg = ');console.log(JSON.stringify({refTokensSha:sha(norm(toks(T.block))),refShootSha:sha(toks(T.shootExpr))}));process.exit(0);}
const R={tool:'own5',build:path.basename(argv[0]),buildSha:crypto.createHash('sha256').update(html).digest('hex').slice(0,16),stage:STAGE,
  metrics:{writesTotal:W.length,
    externalWritersInSource:uniq(ext.map(w=>w.unit)),
    externalWritersActive:uniq(ext.filter(w=>!isFb(w)).map(w=>w.unit)),
    externalWritersFallbackOnly:uniq(ext.filter(isFb).map(w=>w.unit)).filter(u=>!ext.some(w=>w.unit===u&&!isFb(w))),
    byClass:Object.fromEntries(['owner','transitional','fallbackA26','bulkReset','НЕЗАРЕГИСТРИРОВАНА'].map(c=>[c,W.filter(w=>w.cls===c).length])),
    undetermined:UND,undeterminedActive:activeUND.length,apiCallSites:apiSites,gEscapes:escapes,aliases:[...alias].map(v=>v.name+'@'+line(v.defs[0].name)),
    nestedWrites:NESTED,dynamicConstructs:DYN,audioWrites:AW,twin},
  writes:W,violations:viol};
if(argv.includes('--emit'))R.emitRegistry=W.filter(w=>!OWN.has(w.unit)).map(w=>({unit:w.unit,field:w.field,kind:w.kind,site:w.site,nth:w.nth,branch:w.branch,text:w.text}));
const out=JSON.stringify(R,null,1);if(opt('--json'))fs.writeFileSync(opt('--json'),out);else process.stdout.write(out+'\n');
const s=R.metrics;console.error(`own5 ${R.build} (этап ${STAGE}): записей ${W.length} [${Object.entries(s.byClass).map(([k,v])=>k+' '+v).join(', ')}]; `+
  `внешние: в исходнике ${s.externalWritersInSource.length}, активные ${s.externalWritersActive.length}, только откат ${s.externalWritersFallbackOnly.length}; `+
  `неопределённых ${UND.length} (активных ${activeUND.length}); API-вызовов ${apiSites.length}; утечек G ${escapes.length}; нарушений ${viol.length}`);
for(const v of viol)console.error('  НАРУШЕНИЕ: '+v);for(const u of activeUND)console.error('  НЕОПРЕДЕЛЕНО: '+u.unit+'@'+u.line+' '+u.why+': '+u.text);
process.exitCode=viol.length?1:(activeUND.length?2:0);
