# Сравнение двух прогонов K-стенда по одинаковым id (эталон 1.5.20 и кандидат): python3 cmpk5.py <base.jsonl> <cand.jsonl>
# Совпадение = тот же отпечаток состояния по шагам (fp), число шагов, вызовов ГСЧ, убийств и «глубокий» хэш.
import json,sys
A={r['id']:r for r in map(json.loads,open(sys.argv[1]))};B={r['id']:r for r in map(json.loads,open(sys.argv[2]))}
bad=[];same=0
for i in sorted(B):
    if i not in A:bad.append(i+': нет в эталоне');continue
    a,b=A[i],B[i]
    if b.get('err') or b.get('nerr'):bad.append(f"{i}: ошибка {b.get('err','')[:100]} {b.get('errs')}");continue
    ks=['fp','steps','rng','kills','deep']
    d=[k for k in ks if a.get(k)!=b.get(k)]
    if d:
        k=next((n for n,(x,y) in enumerate(zip(a.get('fp',[]),b.get('fp',[]))) if x!=y),None)
        bad.append(f"{i}: различаются {d}"+(f", первое расхождение fp на шаге ≈{(k+1)*60}" if k is not None else ''))
    else:same+=1
miss=sorted(set(A)-set(B));refs=[i for i in miss if i.endswith('/ref')];lost=[i for i in miss if not i.endswith('/ref')]
print(f'совпало побитно {same} из {len(B)}; расхождений {len(bad)}; в эталоне ещё {len(refs)} исторических /ref (1.5.11/13/16 — эталоны, а не задания)'+(f'; ЗАДАНИЙ ЭТАЛОНА НЕТ В КАНДИДАТЕ: {len(lost)}' if lost else ''))
if lost:bad+=[i+': нет в кандидате' for i in lost[:20]]
for x in bad[:40]:print('  -',x)
sys.exit(1 if bad else 0)
