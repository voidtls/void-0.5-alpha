# Проверка доставки флагов в K-стенде: копия st74.py во временной папке, в результат добавлено поле offFlags (ARCH.off);
# сам st74.py не меняется. Задание с flags:['A-99'] должно вернуть offFlags, содержащий A-99, а без flags — пустой список.
#   python3 tools5/kflags5.py <сборка.html>      (выход 1, если флаги не доходят)
import sys,os,json,subprocess,tempfile,shutil
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));K=os.path.join(R,'kit','t72')
b=os.path.abspath(sys.argv[1]);t=open(os.path.join(K,'st74.py'),encoding='utf8').read()
old='return {evS,deepS:'
if t.count(old)!=1:sys.exit('kflags5: не найдено место результата в st74.py')
d=tempfile.mkdtemp(prefix='kflags5_');
for f in os.listdir(K):
    if f.endswith('.py'):shutil.copy2(os.path.join(K,f),d)
open(os.path.join(d,'st74.py'),'w',encoding='utf8').write(t.replace(old,'return {offFlags:Object.keys(ARCH.off).filter(k=>ARCH.off[k]).sort(),evS,deepS:'))
J=json.load(open(os.path.join(K,'jobs_k80.json')))[0];J=dict(J,url='file://'+b,steps=60)
jobs=[dict(J,id='probe/none'),dict(J,id='probe/a99',flags=['A-99'])]
jf=os.path.join(d,'jobs.json');json.dump(jobs,open(jf,'w'));of=os.path.join(d,'out.jsonl')
p=subprocess.run([sys.executable,'st74.py',jf,of,'1'],cwd=d,capture_output=True,text=True,env=dict(os.environ,PYTHONPATH=K+os.pathsep+os.environ.get('PYTHONPATH','')))
rows={r['id']:r for r in map(json.loads,open(of))} if os.path.exists(of) else {}
a=rows.get('probe/none',{}).get('offFlags');c=rows.get('probe/a99',{}).get('offFlags')
ok=a==[] and c==['A-99']
print('без flags:',a,'· flags A-99:',c,'→','ФЛАГИ ДОХОДЯТ' if ok else 'ФЛАГИ НЕ ДОХОДЯТ');
if not ok:print(p.stdout[-500:],p.stderr[-500:])
shutil.rmtree(d,ignore_errors=True);sys.exit(0 if ok else 1)
