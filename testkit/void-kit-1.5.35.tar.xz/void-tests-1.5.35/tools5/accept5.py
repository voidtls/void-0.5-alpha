#!/usr/bin/env python3
# Этап 5 · статическая приёмка сборки по манифесту v2 (tools5/ownership5.json → stage5): одна команда вместо ручной сверки.
#   python3 tools5/accept5.py <сборка.html> [--json out.json]
# Проверяет: check5 против 1.5.20 (порядок операторов, 142 переустановки, победители повторов, 11 переназначений во время игры,
# объявления в блоках, хранилище) с объявленными правками; own5 (реестр, API, тела API, близнец A-26, звук, неопределённые);
# новые глобальные функции — ровно перечисленные и только внутри блока подсистемы; новых обёрток (переустановок) — 0.
# Выход 0 — всё выполнено; 1 — нарушение; 3 — ошибка инструмента.
import sys,os,json,subprocess
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));T=os.path.join(R,'tools5')
try:
    B=os.path.abspath(sys.argv[1]);M=json.load(open(os.path.join(T,'ownership5.json')));S=M['stage5']
    base=os.path.join(R,S['base']['build']);c5b=os.path.join(R,S['base']['check5'])
    def node(*a):
        p=subprocess.run(['node']+list(a),capture_output=True,text=True)
        if p.returncode==3:raise RuntimeError(p.stderr[-400:])
        return p
    res={};bad=[]
    c=node(os.path.join(T,'check5.js'),B,c5b,'--planned',','.join(S['planned']),'--allow-insert','|||'.join(S['allowInsert']));r=json.loads(c.stdout)
    res['check5']={'exit':c.returncode,'vsBaseline':r.get('vsBaseline'),'violations':r['violations'],'planned':r['planned'],'reinstallNames':r['reinstallNames'],'storageRawRefs':len(r['metrics']['storageRaw'])}
    if c.returncode:bad.append('check5: '+'; '.join((r.get('vsBaseline') or [])+r['violations'])[:600])
    rb=json.loads(node(os.path.join(T,'check5.js'),base).stdout)
    su=sorted({x.split('@')[0] for x in r['metrics']['storageRaw']});res['check5']['storageUnits']=su
    if len(su)!=S['storageRaw']:bad.append(f"сырой доступ к хранилищу: {len(su)} мест (функций) вместо {S['storageRaw']}: {su}")
    if len(r['metrics']['storageRaw'])!=len(rb['metrics']['storageRaw']):bad.append(f"число сырых обращений к хранилищу: {len(rb['metrics']['storageRaw'])} в 1.5.20 → {len(r['metrics']['storageRaw'])}")
    if r['reinstall']!=rb['reinstall']:bad.append('переустановки (обёртки) отличаются от 1.5.20')
    o=node(os.path.join(T,'own5.js'),B,'--json',os.devnull);res['own5']={'exit':o.returncode,'summary':o.stdout.strip().splitlines()[-1] if o.stdout.strip() else ''}
    if o.returncode:bad.append('own5: выход %d — %s'%(o.returncode,o.stdout[-400:]))
    n0=set(json.loads(node(os.path.join(T,'names5.js'),base).stdout));n1=set(json.loads(node(os.path.join(T,'names5.js'),B).stdout))
    new=sorted(n1-n0);gone=sorted(n0-n1);res['names']={'new':new,'gone':gone}
    if sorted(S['newFunctions'])!=new:bad.append(f'новые глобальные функции {new}, ожидались {sorted(S["newFunctions"])}')
    if gone:bad.append('исчезли функции: '+', '.join(gone))
    h=open(B,encoding='utf8').read();i=h.index('<script>\n"use strict";');src=h[i:];a=src.index(S['newFunctionsIn'][0]);z=src.index(S['newFunctionsIn'][1])
    for f in new:
        k=src.find('\nfunction '+f+'(');cnt=src.count('\nfunction '+f+'(')
        if cnt!=1 or not(a<k<z):bad.append(f'{f}: объявлений {cnt}, внутри блока подсистемы: {a<k<z}')
except (RuntimeError,KeyError,ValueError,OSError,IndexError) as e:print('accept5: ошибка инструмента:',e);sys.exit(3)
res['bad']=bad;print(json.dumps({k:v for k,v in res.items() if k!='bad'},ensure_ascii=False,indent=1)[:2500])
print('ИТОГ:','ПРИНЯТО (статика)' if not bad else 'НАРУШЕНИЯ');[print('  -',x) for x in bad]
if '--json' in sys.argv:json.dump(res,open(sys.argv[sys.argv.index('--json')+1],'w'),ensure_ascii=False,indent=1)
sys.exit(1 if bad else 0)
