# Побитное сравнение двух JSON-результатов стенда по ключам верхнего уровня: python3 cmpjson5.py a.json b.json [--ignore поле1,поле2]
import json,sys
A=json.load(open(sys.argv[1]));B=json.load(open(sys.argv[2]));ig=set(sys.argv[sys.argv.index('--ignore')+1].split(',')) if '--ignore' in sys.argv else set()
def strip(x):return {k:v for k,v in x.items() if k not in ig} if isinstance(x,dict) else x
bad=[k for k in sorted(set(A)|set(B)) if strip(A.get(k))!=strip(B.get(k))]
print(f'ключей {len(A)}/{len(B)}; совпало {len(set(A)&set(B))-len([k for k in bad if k in A and k in B])}; различается {len(bad)}');[print('  -',k) for k in bad[:30]];sys.exit(1 if bad else 0)
