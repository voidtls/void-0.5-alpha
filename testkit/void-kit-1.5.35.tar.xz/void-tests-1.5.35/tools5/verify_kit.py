# Проверка целостности комплекта (выходные файлы наборов kit/q*.json и kit/res*.json перезаписываются при каждом прогоне и считаются отдельно): каждый файл kit/ совпадает с упакованным (с точностью до путей, подставленных setup_kit.py).
#   python3 tools5/verify_kit.py        (выход 1, если какой-то файл изменён или отсутствует)
import json,hashlib,os,sys
R=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..');P=json.load(open(os.path.join(R,'.kitpaths.json'))) if os.path.exists(os.path.join(R,'.kitpaths.json')) else {'kit':'@@KIT@@','chrome':'@@CHROME@@'}
inv=json.load(open(os.path.join(R,'inventory.json')));bad=[];outs=set(inv.get('runOutputs',[]));outch=[]
for rel,size,sh in inv['files']:
    p=os.path.join(R,rel)
    if not os.path.exists(p):bad.append('нет '+rel);continue
    b=open(p,'rb').read()
    if rel.startswith('kit/') and rel.endswith(tuple(inv['textExt'])) and len(b)<3_000_000:b=b.decode('utf8','surrogateescape').replace(P['kit'],'@@KIT@@').replace(P['chrome'],'@@CHROME@@').encode('utf8','surrogateescape')
    if hashlib.sha256(b).hexdigest()!=sh:(outch if rel in outs else bad).append('изменён '+rel)
print('файлов',len(inv['files']),'· расхождений',len(bad),'· перезаписано прогонами наборов (kit/q*.json, kit/res*.json — это их выходные файлы, так и должно быть):',len(outch));[print('  -',x) for x in bad[:50]];sys.exit(1 if bad else 0)
