# Сравнение двух результатов st5.py (эталон и кандидат). Выход 1 при расхождении.
#   python3 compare5.py <эталон.json> <кандидат.json> [--allow fn1,fn2] [--same-flags]  (--same-flags: отказ, если фактические флаги страниц различаются)
#   (было)   (--allow: для boot — функции, текст которых меняется по плану)
import json,sys
A=json.load(open(sys.argv[1]));B=json.load(open(sys.argv[2]))
allow=set(sys.argv[sys.argv.index('--allow')+1].split(',')) if '--allow' in sys.argv else set()
bad=[]
if A['mode']!=B['mode']:sys.exit('разные режимы')
if A.get('pageFlags') is not None and B.get('pageFlags') is not None:print('флаги страницы: эталон',A['pageFlags'],'· кандидат',B['pageFlags'])
if '--same-flags' in sys.argv and A.get('pageFlags')!=B.get('pageFlags'):print('ОТКАЗ: --same-flags, а фактические флаги страниц различаются');sys.exit(3)
if A.get('sha')==B.get('sha') and A.get('a24')==B.get('a24') and A.get('off')==B.get('off') and A.get('pageFlags')==B.get('pageFlags') and '--aa' not in sys.argv:
    print('ОТКАЗ: сравнивается одна и та же сборка в одном режиме флагов — это A/A; укажите --aa, если так задумано');sys.exit(3)
if A['mode']=='boot':
    fa,fb=A['fns'],B['fns'];new=sorted(set(fb)-set(fa));gone=sorted(set(fa)-set(fb))
    ch=sorted(k for k in fa if k in fb and fa[k]!=fb[k])
    for k in ch:(print('  изменена по плану:',k) if k in allow else bad.append('изменилась функция '+k))
    for k in gone:bad.append('исчезла функция '+k)
    for k in new:(print('  новая по плану:',k) if k in allow else bad.append('новая функция '+k))
    if A['ael']!=B['ael']:bad.append('обработчики событий: '+json.dumps({k:(A['ael'].get(k),B['ael'].get(k)) for k in set(A['ael'])|set(B['ael']) if A['ael'].get(k)!=B['ael'].get(k)},ensure_ascii=False))
    if B.get('errs'):bad.append('ошибки страницы: '+'; '.join(B['errs'][:2]))
    print(f"функций: эталон {len(fa)}, кандидат {len(fb)}; изменено {len(ch)}, новых {len(new)}, исчезло {len(gone)}; обработчиков {sum(A['ael'].values())} / {sum(B['ael'].values())}")
else:
    for k,ra in A['runs'].items():
        rb=B['runs'].get(k)
        if not rb:bad.append('нет прогона '+k);continue
        la,lb=ra['log'],rb['log']
        if len(la)!=len(lb):bad.append(f'{k}: шагов {len(la)} → {len(lb)}')
        first=next((i for i,(x,y) in enumerate(zip(la,lb)) if x!=y),None)
        if first is not None:
            x,y=la[first],lb[first];fields=[n for n,(u,v) in enumerate(zip(x,y)) if u!=v]
            bad.append(f'{k}: первое расхождение на шаге {first}, поля {fields}: {x} → {y}')
        if rb.get('errs'):bad.append(f'{k}: ошибки страницы {rb["errs"][:2]}')
        print(f'{k}: шагов {len(la)}/{len(lb)}, ' + ('совпадает побитно' if first is None and len(la)==len(lb) else 'РАСХОЖДЕНИЕ'))
print('ИТОГ:', 'OK' if not bad else 'РАСХОЖДЕНИЯ'); [print('  -',b) for b in bad]
sys.exit(1 if bad else 0)
