# Сводка perf5.py: медиана мс/кадр A и B по (Гц, миссия), отношение B/A и разброс пар.  python3 perfsum5.py <perf.json>
import json,sys,statistics as S
R=json.load(open(sys.argv[1]));keys=sorted({(r['hz'],r['m']) for r in R})
for k in keys:
    a=[r['msFrame'] for r in R if (r['hz'],r['m'])==k and r['tag']=='A' and 'msFrame' in r];b=[r['msFrame'] for r in R if (r['hz'],r['m'])==k and r['tag']=='B' and 'msFrame' in r]
    pr=[y/x for x,y in zip(a,b)];print(f"{k[0]:4d} Гц  м{k[1]:<3d} A {S.median(a):6.3f}  B {S.median(b):6.3f}  B/A медиана {S.median(pr):.3f}  пары {min(pr):.3f}…{max(pr):.3f}  ошибок {sum(r.get('nerr',0) for r in R if (r['hz'],r['m'])==k)}")
ku=[r for r in R if 'msUp' in r]
if ku:
    for k in keys:
        a=[r['msUp'] for r in ku if (r['hz'],r['m'])==k and r['tag']=='A'];b=[r['msUp'] for r in ku if (r['hz'],r['m'])==k and r['tag']=='B']
        if a and b:pr=[y/x for x,y in zip(a,b)];print(f"  updatePlayer {k[0]:4d} Гц м{k[1]:<3d} A {S.median(a):.4f}  B {S.median(b):.4f} мс/вызов  B/A медиана {S.median(pr):.3f}  пары {min(pr):.3f}…{max(pr):.3f}  вызовов {min(r['upN'] for r in ku)}…{max(r['upN'] for r in ku)}")
