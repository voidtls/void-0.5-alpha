// Этап 5 · статические проверки по AST (acorn + eslint-scope).
process.on('uncaughtException',e=>{console.error('check5.js: внутренняя ошибка инструмента: '+(e&&e.stack||e));process.exit(3);});
// node check5.js <build.html> [baseline.json] > report.json ; код выхода 1 при нарушении правил или расхождении с эталоном
const path=require('path'),fs=require('fs'),crypto=require('crypto');
const NM=process.env.NODE_TOOLS||path.join(__dirname,'..','node_modules');
const acorn=require(path.join(NM,'acorn')),walk=require(path.join(NM,'acorn-walk')),escope=require(path.join(NM,'eslint-scope'));
const html=fs.readFileSync(process.argv[2],'utf8');const i0=html.indexOf('<script>\n"use strict";');if(i0<0)throw new Error('нет основного <script> с "use strict"');const i=i0+8,j=html.indexOf('</script>',i);const src=html.slice(i,j);
const M=JSON.parse(fs.readFileSync(path.join(__dirname,'subsystems5.json'),'utf8'));
const ast=acorn.parse(src,{ecmaVersion:2022,sourceType:'script',locations:true,ranges:true});
const sm=escope.analyze(ast,{ecmaVersion:2022});const gs=sm.globalScope;
const sha=s=>crypto.createHash('sha256').update(s).digest('hex').slice(0,16);
const line=n=>n.loc.start.line;
// единица кода, внутри которой стоит узел
function unitOf(st){for(let k=st.length-1;k>=0;k--){const x=st[k];
  if(x.type==='FunctionDeclaration')return x.id.name;
  if(x.type==='AssignmentExpression'&&x.left.type==='Identifier'&&/Function/.test(x.right.type)&&st[k+1]===x.right)return x.left.name+' (обёртка)';
  if(x.type==='VariableDeclarator'&&x.id.type==='Identifier'&&x.init&&st[k+1]===x.init&&/Function|Call/.test(x.init.type))return x.id.name+' (инициализатор)';}
  return '(верхний уровень)';}
const baseName=u=>u.replace(/ \((обёртка|инициализатор)\)$/,'');
// ветка отката по флагу: запись исполняется только при выключенном флаге
const FL=M.fallbackFlags||[];
function branchOf(st){for(let k=st.length-1;k>0;k--){const x=st[k-1],ch=st[k];
  if(x.type==='IfStatement'||x.type==='ConditionalExpression'){const t=src.slice(x.test.range[0],x.test.range[1]);
    for(const f of FL){const pr=(M.fallbackFlagProps||{})[f];
      const off=new RegExp("^\\(?\\s*ARCH\\.off\\[['\"]"+f+"['\"]\\]\\s*\\)?$").test(t)||(!!pr&&new RegExp("^!\\s*ARCH\\."+pr+"$").test(t)),
            on=new RegExp("^!\\s*ARCH\\.off\\[['\"]"+f+"['\"]\\]$").test(t)||(!!pr&&new RegExp("^ARCH\\."+pr+"$").test(t));
      if(off&&ch===x.consequent)return 'fallback:'+f;if(off&&ch===x.alternate)return 'active:'+f;
      if(on&&ch===x.alternate)return 'fallback:'+f;if(on&&ch===x.consequent)return 'active:'+f;}}}
  return 'always';}
// 1. объявления: повторы и победители
const decls={};for(const s of ast.body)if(s.type==='FunctionDeclaration')(decls[s.id.name]=decls[s.id.name]||[]).push(s);
const dups={};for(const [k,a] of Object.entries(decls))if(a.length>1){const w=a[a.length-1];dups[k]={n:a.length,winner:sha(src.slice(w.range[0],w.range[1])),lines:a.map(line)};}
const blockDecls=[];walk.ancestor(ast,{FunctionDeclaration(n,st){const p=st[st.length-2];if(p&&p.type==='BlockStatement'){const q=st[st.length-3];if(!q||!/Function/.test(q.type))blockDecls.push([n.id.name,line(n)]);}}});
// 2. переустановки глобальных функций при загрузке (верхний уровень и IIFE верхнего уровня)
const fnVars=gs.variables.filter(v=>v.defs.some(d=>d.type==='FunctionName'));
const iife=new Set();for(const s of ast.body){let e=s.type==='ExpressionStatement'?s.expression:null;if(e&&e.type==='UnaryExpression')e=e.argument;if(e&&e.type==='CallExpression'&&/Function/.test(e.callee.type))iife.add(e.callee);}
const reinstall={},runtimeW={},reOrder={};const topIdx=pos=>{let lo=0,hi=ast.body.length-1;while(lo<hi){const m=(lo+hi+1)>>1;if(ast.body[m].range[0]<=pos)lo=m;else hi=m-1;}return lo;};
for(const v of fnVars){for(const r of v.references){if(!r.isWrite())continue;let sc=r.from,run=false;while(sc&&sc.type!=='global'){if(sc.type==='function'&&!iife.has(sc.block))run=true;sc=sc.upper;}
  (run?runtimeW:reinstall)[v.name]=((run?runtimeW:reinstall)[v.name]||0)+1;
  if(!run){const i=topIdx(r.identifier.range[0]);(reOrder[v.name]=reOrder[v.name]||[]).push([i,sha(src.slice(ast.body[i].range[0],ast.body[i].range[1]))]);}}}
for(const k in reOrder)reOrder[k]=reOrder[k].sort((x,y)=>x[0]-y[0]).map(x=>x[1]);
// порядок всех верхнеуровневых операторов, кроме объявлений функций (перенос объявлений не должен его менять)
const topSeq=ast.body.filter(s=>s.type!=='FunctionDeclaration').map(s=>sha(src.slice(s.range[0],s.range[1])));
const VERX=/1\.5\.\d+ α/g;const topSeqV=ast.body.filter(s=>s.type!=='FunctionDeclaration').map(s=>sha(src.slice(s.range[0],s.range[1]).replace(VERX,'V')));
const topStmts=ast.body.filter(s=>s.type!=='FunctionDeclaration');
// 3. записи в G по единицам кода
const W=[];walk.ancestor(ast,{MemberExpression(m,st){
  let root=m;while(root.object&&root.object.type==='MemberExpression')root=root.object;
  if(!(root.object&&root.object.type==='Identifier'&&root.object.name==='G'&&!root.computed))return;
  const p=st[st.length-2];const isW=(p.type==='AssignmentExpression'&&p.left===m)||(p.type==='UpdateExpression'&&p.argument===m)||(p.type==='UnaryExpression'&&p.operator==='delete'&&p.argument===m);
  if(!isW)return;W.push({f:root.property.name,unit:unitOf(st),line:line(m),branch:branchOf(st)});}});
const report={file:path.basename(process.argv[2]),scriptSha:sha(src),lines:src.split('\n').length,fnDecls:Object.values(decls).reduce((a,b)=>a+b.length,0),
  dups,blockDecls,reinstallNames:Object.keys(reinstall).length,reinstall,reinstallOrder:reOrder,topLevelSeq:topSeq,topLevelSeqV:topSeqV,planned:[],runtimeWrites:runtimeW,violations:[],metrics:{}};
// 4. подсистема наведения
const T=M.subsystems.targeting,own=new Set(T.ownsG),inSet=u=>T.functions.includes(baseName(u));
const ow=W.filter(w=>own.has(w.f));
const ext=ow.filter(w=>!inSet(w.unit));
const uniq=a=>[...new Set(a.map(w=>baseName(w.unit)))].sort();
report.metrics.targeting={
  writersAll:uniq(ow),
  externalWritersInSource:uniq(ext),
  externalWritersActive:uniq(ext.filter(w=>!w.branch.startsWith('fallback'))),
  externalWritersFallbackOnly:uniq(ext.filter(w=>w.branch.startsWith('fallback'))).filter(n=>!uniq(ext.filter(w=>!w.branch.startsWith('fallback'))).includes(n)),
  writes:ow.map(w=>`${w.unit}@${w.line} G.${w.f} [${w.branch}]`)};
for(const q of T.queries){const bad=W.filter(w=>baseName(w.unit)===q);if(bad.length)report.violations.push(`запрос ${q} пишет G: `+bad.map(w=>'G.'+w.f+'@'+w.line).join(', '));}
// неявные писатели полей наведения не через G (псевдонимы)
const alias=[];const rx=new RegExp('([A-Za-z_$][\\w$]*)\\.('+T.ownsG.join('|')+')\\s*(=(?!=)|\\+=|-=|\\|\\|=)','g');let mm;while((mm=rx.exec(src))){if(mm[1]!=='G')alias.push(mm[0]+' @'+src.slice(0,mm.index).split('\n').length);}
report.metrics.targeting.aliasWrites=alias;if(alias.length)report.violations.push('запись полей наведения не через G: '+alias.join('; '));
// 5. звук: записи в G
const A=new Set(M.subsystems.audio.functions);report.metrics.audioGWrites=W.filter(w=>A.has(baseName(w.unit))).map(w=>`${w.unit}@${w.line} G.${w.f}`);
// 6. хранилище: сырые обращения
const raw=[];walk.ancestor(ast,{Identifier(n,st){if(n.name!=='localStorage'&&n.name!=='sessionStorage')return;const p=st[st.length-2];if(p.type==='MemberExpression'&&p.property===n&&!p.computed&&!(p.object.type==='Identifier'&&p.object.name==='window'))return;/* x.localStorage у чужого объекта — не хранилище; window.localStorage — сырое обращение */raw.push(unitOf(st)+'@'+line(n));},
  MemberExpression(m,st){if(!m.computed&&m.object.type==='Identifier'&&m.object.name==='window'&&/^(localStorage|sessionStorage)$/.test(m.property.name))raw.push(unitOf(st)+'@'+line(m));}});
report.metrics.storageRaw=raw;const allowed=new Set(M.subsystems.storage.allowedRaw);
for(const r of raw){const u=r.split('@')[0];if(!allowed.has(u))report.violations.push('сырое обращение к хранилищу вне разрешённых мест: '+r);}
// 7. сравнение с эталоном
const PLAN=new Set((process.argv.includes('--planned')?process.argv[process.argv.indexOf('--planned')+1]:'').split(',').filter(Boolean));
if(process.argv[3]&&!process.argv[3].startsWith('--')){const B=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));const d=[];
  for(const [k,v] of Object.entries(B.dups)){const c=dups[k];if(!c)d.push(`повтор ${k} исчез (было ${v.n})`);else if(c.winner!==v.winner)(PLAN.has(k)?report.planned:d).push(`победитель ${k} изменился`+(PLAN.has(k)?' (объявлено в --planned)':''));else if(c.n!==v.n)d.push(`число объявлений ${k}: ${v.n} → ${c.n}`);}
  for(const k of Object.keys(dups))if(!B.dups[k])d.push(`новый повтор ${k}`);
  const allN=new Set([...Object.keys(B.reinstall),...Object.keys(reinstall)]);for(const k of allN)if((B.reinstall[k]||0)!==(reinstall[k]||0))d.push(`переустановок ${k}: ${B.reinstall[k]||0} → ${reinstall[k]||0}`);
  for(const k of Object.keys(B.reinstallOrder||{}))if(reOrder[k]&&JSON.stringify(reOrder[k])!==JSON.stringify(B.reinstallOrder[k]))d.push(`порядок или текст переустановок ${k} изменился`);
  // --allow-insert "<точный текст оператора>[|||<ещё>]": объявленные вставки верхнеуровневых операторов; каждая — ровно одно вхождение
  const INS=(process.argv.includes('--allow-insert')?process.argv[process.argv.indexOf('--allow-insert')+1]:'').split('|||').filter(Boolean);
  let bS=topSeq.slice(),bV=topSeqV.slice(),bT=topStmts.slice();
  for(const txt of INS){const h=sha(txt);const idx=bS.map((x,i)=>x===h?i:-1).filter(i=>i>=0);
    if(B.topLevelSeq&&B.topLevelSeq.includes(h)){d.push('объявленная вставка уже есть в эталоне: '+txt);continue;}
    if(idx.length!==1){d.push(`объявленная вставка найдена ${idx.length} раз(а) вместо 1: `+txt);continue;}
    report.planned.push(`вставлен верхнеуровневый оператор (строка скрипта ${line(bT[idx[0]])}): ${txt}`);bS.splice(idx[0],1);bV.splice(idx[0],1);bT.splice(idx[0],1);}
  const TD=[];if(B.topLevelSeq){const a=B.topLevelSeq,b=bS,topSeqV_=bV,topStmts_=bT;if(a.length!==b.length)d.push(`число верхнеуровневых операторов (без объявлений функций): ${a.length} → ${b.length}`);
    else for(let i=0;i<a.length;i++)if(a[i]!==b[i]){const s=topStmts_[i],txt=src.slice(s.range[0],s.range[0]+70).replace(/\n/g,' ');
      if(B.topLevelSeqV&&B.topLevelSeqV[i]===topSeqV_[i])report.planned.push(`оператор № ${i} (строка скрипта ${line(s)}) отличается только номером версии: ${txt}`);
      else TD.push(`верхнеуровневый оператор № ${i} изменился (строка скрипта ${line(s)}): ${txt}`);}
    if(TD.length)d.push(...TD.slice(0,5),...(TD.length>5?[`… и ещё ${TD.length-5} изменённых верхнеуровневых операторов (сдвиг порядка)`]:[]));}
  if(JSON.stringify(B.runtimeWrites)!==JSON.stringify(runtimeW))d.push('изменились переназначения во время игры');
  if(blockDecls.length!==B.blockDecls.length)d.push(`объявлений функций в блоках: ${B.blockDecls.length} → ${blockDecls.length}`);
  if(report.metrics.audioGWrites.length>B.metrics.audioGWrites.length)d.push('звук стал писать G');
  report.vsBaseline=d;}
process.stdout.write(JSON.stringify(report,null,1));
process.exitCode=(report.violations.length||(report.vsBaseline&&report.vsBaseline.length))?1:0;
