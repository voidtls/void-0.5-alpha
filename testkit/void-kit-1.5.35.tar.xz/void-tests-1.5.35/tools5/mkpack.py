# Упаковка комплекта группы 0: inventory.json (хэши в форме с метками) + архив tar.xz с метками @@KIT@@/@@CHROME@@ вместо путей.
#   python3 mkpack.py <корень комплекта> <архив.tar.xz>
import os,sys,json,hashlib,shutil,subprocess,re
R=os.path.abspath(sys.argv[1]);OUT=os.path.abspath(sys.argv[2]) if len(sys.argv)>2 and not sys.argv[2].startswith('--') else os.path.join(R,'_none.tar.xz');P=json.load(open(os.path.join(R,'.kitpaths.json')))
TXT=('.py','.js','.sh','.json','.txt','.md','.jsonl','.log')
INCL=['README.md','setup_kit.py','setup5.py','runreg.sh','kit','tools5','node_modules','baseline','stage5','builds5']
def tmpl(rel,b):
    if rel.startswith('kit/') and rel.endswith(TXT) and len(b)<3_000_000:
        return b.decode('utf8','surrogateescape').replace(P['kit'],'@@KIT@@').replace(P['chrome'],'@@CHROME@@').encode('utf8','surrogateescape')
    return b
files=[]
for top in INCL:
    p=os.path.join(R,top)
    if not os.path.exists(p):continue
    if os.path.isfile(p):files.append(top);continue
    for r,ds,fs in os.walk(p):
        ds[:]=sorted(d for d in ds if d!='__pycache__')
        for f in sorted(fs):
            rel=os.path.relpath(os.path.join(r,f),R)
            # варианты сборок с флагами и выгрузки .js воспроизводятся (variant5.py, s5.py apply) — в комплект не входят
            if rel.startswith('builds5/') and re.search(r'(_a24v|_o26|_a24o26)\.html$|\.html\.js$',rel):continue
            if not f.endswith('.pyc'):files.append(rel)
inv=[];ST=os.path.join(os.path.dirname(OUT),'pack_stage');D=os.path.join(ST,'void-tests-1.5.20')
shutil.rmtree(ST,ignore_errors=True)
for rel in files:
    b=tmpl(rel,open(os.path.join(R,rel),'rb').read());inv.append([rel,len(b),hashlib.sha256(b).hexdigest()])
    if '--inventory-only' in sys.argv:continue
    d=os.path.join(D,rel);os.makedirs(os.path.dirname(d),exist_ok=True);open(d,'wb').write(b)
    if os.access(os.path.join(R,rel),os.X_OK):os.chmod(d,0o755)
import re
OUTS=[r for r,_,_ in inv if re.fullmatch(r'kit/(q\w+|res\d+)\.json',r)]
I=dict(textExt=list(TXT),files=inv,runOutputs=OUTS,note='SHA-256 файлов в упакованном виде (пути заменены метками). verify_kit.py сравнивает с ними текущие файлы.')
for d in ((R,) if '--inventory-only' in sys.argv else (R,D)):json.dump(I,open(os.path.join(d,'inventory.json'),'w'),ensure_ascii=False,indent=0)
if '--inventory-only' in sys.argv:print('инвентарь:',len(inv),'файлов');sys.exit(0)
env=dict(os.environ,XZ_OPT='-9e --lzma2=preset=9e,dict=192MiB -T1')
subprocess.run(['tar','-C',ST,'-cJf',OUT,'void-tests-1.5.20'],check=True,env=env)
print('файлов',len(inv),'· архив',round(os.path.getsize(OUT)/1e6,1),'МБ')
