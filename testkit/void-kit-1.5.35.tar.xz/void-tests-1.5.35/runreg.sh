#!/bin/sh
# Полная регрессия: ./runreg.sh <сборка.html> <папка-результатов> [список тестов]
# По умолчанию — все 30 наборов двумя параллельными цепочками (как при приёмке 1.5.20; ≈75 мин на 4 ядрах).
# Сравнение с эталоном 1.5.20: python3 tools5/cmpreg5.py kit/reg20 <папка-результатов>
R=$(cd "$(dirname "$0")" && pwd); B=$(cd "$(dirname "$1")" && pwd)/$(basename "$1"); O=$(mkdir -p "$2" && cd "$2" && pwd); shift 2
export GAME_URL=file://$B TMO=${TMO:-1500}
cd "$R/kit"
run(){ for t in $*; do s=$(date +%s); timeout 3600 python3 $t.py > "$O/$t.log" 2>&1; echo "$t exit $? $(( $(date +%s)-s ))s" >> "$O/done.txt"; done; }
if [ $# -gt 0 ]; then run $*; else
run q340s q210 q160 q190 q270 q130 q150 q110 q96 q290 q240 q370 q300 q320 &
run q350 q200 q180 q220 q330 q120 q95 q90 q280 q250 q260 q170 q140 q310 q360 q380 &
wait; fi
echo ALLDONE >> "$O/done.txt"
