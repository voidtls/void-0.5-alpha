# Этап 5 · загрузчик патчей ARCH·81–84 поверх модуля этапа 4 (kit/arch74.py; сам комплект не меняется).
#   python3 stage5/s5.py apply <in.html> <out.html> 81 [82 …]     — накладывает по порядку, печатает SHA, пишет <out>.js
#   python3 stage5/s5.py strip <cand.html> <ref.html> 81 [82 …]   — снимает в обратном порядке и сравнивает с эталоном байт в байт
#   --kit <папка kit> или VOID_KIT — где лежит arch74.py (по умолчанию ../kit или ./kit)
import sys,os,hashlib
R=os.path.dirname(os.path.abspath(__file__))
args=sys.argv[1:]
KIT=None
if '--kit' in args:i=args.index('--kit');KIT=args[i+1];del args[i:i+2]
KIT=KIT or os.environ.get('VOID_KIT') or next((c for c in (os.path.join(R,'..','kit'),os.path.join(os.getcwd(),'kit')) if os.path.exists(os.path.join(c,'arch74.py'))),None)
if not KIT or not os.path.exists(os.path.join(KIT,'arch74.py')):sys.exit('s5.py: не найден kit/arch74.py — укажите --kit <папка kit> или VOID_KIT (или соберите окружение: python3 setup5.py)')
sys.path.insert(0,os.path.abspath(KIT))
import arch74 as A
for n in (81,82,83,84,85):
    f=os.path.join(R,'arch74_%d.py'%n)
    if os.path.exists(f):exec(open(f,encoding='utf8').read(),A.__dict__)
_r0=A._r
A._r=lambda name:open(os.path.join(R,name),encoding='utf8').read() if os.path.exists(os.path.join(R,name)) else _r0(name)
cmd,a,b=args[0:3];ns=[int(x) for x in args[3:]]
s=open(a,encoding='utf8').read()
if cmd=='apply':
    for n in ns:s=A.apply(s,n)
    open(b,'w',encoding='utf8').write(s)
    i=s.index('<script>');j=s.index('</script>',i);open(b+'.js','w',encoding='utf8').write(s[i+8:j])
    print('ok',ns,hashlib.sha256(s.encode()).hexdigest(),len(s.encode()))
else:
    for n in reversed(ns):s=A.strip(s,n)
    ref=open(b,encoding='utf8').read()
    print('равно эталону:',s==ref,'sha:',hashlib.sha256(s.encode()).hexdigest()[:16],'остатки ARCH·8x:',[k for k in ('ARCH·81','ARCH·82','ARCH·83','ARCH·84') if k in s])
    sys.exit(0 if s==ref else 1)
