#!/bin/sh
# Пилот ARCH·81: динамические проверки (эталон 1.5.20 и кандидат 1.5.21 одинаковыми стендами). Результаты — out5/p81/.
R=$(cd "$(dirname "$0")/.." && pwd); cd "$R"; O=$R/out5/p81; mkdir -p $O
B0=kit/home/void_b160.html; B1=builds5/void_b161.html
log(){ echo "$(date +%H:%M:%S) $*" >> $O/progress.txt; }
log старт
for m in boot trace aimman prio; do python3 tools5/st5.py $m $B1 $O/${m}_161.json > $O/${m}_161.log 2>&1; log st5 $m $?; done
for m in trace aimman prio; do VOID_A24=1 python3 tools5/st5.py $m $B0 $O/${m}_160a24.json > $O/${m}_160a24.log 2>&1; VOID_A24=1 python3 tools5/st5.py $m $B1 $O/${m}_161a24.json > $O/${m}_161a24.log 2>&1; log st5-a24 $m; done
python3 tools5/retarget5.py kit/t72/a24route.py $B0 $O/a24route_160.py; python3 tools5/retarget5.py kit/t72/a24route.py $B1 $O/a24route_161.py
python3 $O/a24route_160.py $O/a24r_160.json > $O/a24r_160.log 2>&1; python3 $O/a24route_161.py $O/a24r_161.json > $O/a24r_161.log 2>&1; log a24route
python3 tools5/kjobs5.py kit/t72/jobs_e24.json builds5/void_b160_a24.html $O/jobs_e24_160.json; python3 tools5/kjobs5.py kit/t72/jobs_e24.json builds5/void_b161_a24.html $O/jobs_e24_161.json
python3 tools5/kjobs5.py kit/t72/jobs_k80.json $B0 $O/jobs_k80_160.json; python3 tools5/kjobs5.py kit/t72/jobs_k80.json $B1 $O/jobs_k80_161.json
cd kit/t72
python3 st74.py $R/$O/jobs_e24_160.json $R/$O/e24_160.jsonl 2 > $R/$O/e24_160.log 2>&1; python3 st74.py $R/$O/jobs_e24_161.json $R/$O/e24_161.jsonl 2 > $R/$O/e24_161.log 2>&1; log e24
python3 st74.py $R/$O/jobs_k80_161.json $R/$O/k80_161.jsonl 2 > $R/$O/k80_161.log 2>&1; log k80-161
python3 st74.py $R/$O/jobs_k80_160.json $R/$O/k80_160.jsonl 2 > $R/$O/k80_160.log 2>&1; log k80-160
log ALLDONE
