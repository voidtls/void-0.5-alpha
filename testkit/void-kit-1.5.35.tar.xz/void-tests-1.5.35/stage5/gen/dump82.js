// ARCH·82: тексты из AST 1.5.21 для генератора (операторы 22–29 тела updatePlayer, выражение shoot, маркер конца блока)
const fs=require('fs'),path=require('path');const NM=path.join(__dirname,'..','..','node_modules');const acorn=require(path.join(NM,'acorn'));
const h=fs.readFileSync(process.argv[2],'utf8');const i=h.indexOf('<script>\n"use strict";')+8,j=h.indexOf('</script>',i);const src=h.slice(i,j);
const ast=acorn.parse(src,{ecmaVersion:2022,ranges:true});const ups=ast.body.filter(s=>s.type==='FunctionDeclaration'&&s.id.name==='updatePlayer');
if(ups.length!==1)throw new Error('updatePlayer: объявлений '+ups.length);const B=ups[0].body.body;
const t=n=>src.slice(n.range[0],n.range[1]);
if(t(B[21])!=='const man=aimManual();')throw new Error('якорь: оператор 21 = '+t(B[21]));
if(!t(B[22]).startsWith('let tg=man?null:pickTarget();'))throw new Error('оператор 22');
if(!t(B[29]).startsWith('p.ang+='))throw new Error('оператор 29');if(t(B[30])!=='p.fireT-=dt;')throw new Error('оператор 30');
if(!t(B[31]).startsWith('const shoot='))throw new Error('оператор 31');
const block=src.slice(B[22].range[0],B[29].range[1]);const shootStmt=t(B[31]);const shootExpr=t(B[31].declarations[0].init);
fs.writeFileSync(process.argv[3],JSON.stringify({block,shootStmt,shootExpr,countBlock:src.split(block).length-1,countShoot:src.split(shootStmt).length-1}));
