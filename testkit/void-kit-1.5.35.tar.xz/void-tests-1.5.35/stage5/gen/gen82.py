# Генерирует stage5/arch74_82.py: тексты берутся из AST 1.5.21 (dump82.js), не набираются вручную.
import json,os
D=os.path.dirname(os.path.abspath(__file__));T=json.load(open(os.path.join(D,'t82.json')))
blk=T['block'];assert blk.startswith('let tg=')
fb=blk.replace('let tg=','tg=',1)   # единственное отличие ветки отката: tg объявлен выше, в updatePlayer
shoot_old=T['shootStmt'];expr=T['shootExpr'];assert shoot_old=='const shoot='+expr+';'
new_up=('let tg;if(ARCH.a26)tg=aimStep(p,dt,man);/* ARCH·82: шаги 4–12 — в подсистеме наведения */\n'
        '  else{/* ARCH·82 · откат A-26: исходный текст 1.5.21; единственное отличие — «let tg=» → «tg=» */\n  '+fb+'}')
new_shoot='const shoot=ARCH.a26?autoFireWanted(man,tg):('+expr+');/* ARCH·82 */'
END81='/* ▲▲▲ ARCH·81 · КОНЕЦ ПОДСИСТЕМЫ НАВЕДЕНИЯ ▲▲▲ */'
fns=('/* ARCH·82 · шаг наведения из updatePlayer (1.5.22). Тело — дословно операторы 1.5.21 от «let tg=» до поворота p.ang:\n'
     '   выбор цели → G.tg90 (в ручном режиме — захват прошлого шага) → noTg75/aimFallback → sp → ручной захват/want → A-24 → p.ang.\n'
     '   Возвращает tg (цель для выстрела). Вызывается из updatePlayer в том же месте; при window.__archOff=[\'A-26\'] работает прежний текст. */\n'
     'function aimStep(p,dt,man){\n  '+blk+'\n  return tg;}\n'
     '/* ARCH·82 · условие автострельбы (шаг 14), вызывается после p.fireT-=dt, как и раньше; запросная функция — G не пишет */\n'
     'function autoFireWanted(man,tg){return '+expr+';}\n')
PRE=('/* ▼▼▼ ARCH·82 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.22 α · этап 5: шаг наведения вынесен из updatePlayer)\n'
     '   A-26: window.__archOff=[\'A-26\'] до загрузки — updatePlayer исполняет прежний встроенный текст (ветка отката, до этапа 7). */\n'
     'ARCH.a26=!ARCH.off[\'A-26\'];\n')
sites=[(blk,new_up),(shoot_old,new_shoot),(END81,fns+END81)]
out=('# ---------- 82 · этап 5 · aimStep / autoFireWanted, флаг A-26 (вариант А) ----------\n'
     '# Сгенерировано stage5/gen/gen82.py из AST 1.5.21 (SHA 3e497666…).\n'
     'PRE82=%r+END%%82\nS82=%r\n'
     "STAGES[82]=dict(vf='1.5.21 α',vt='1.5.22 α',J='m82_journal.txt',pre=PRE82,after=81,sites=S82)\n")%(PRE,sites)
open(os.path.join(D,'..','arch74_82.py'),'w',encoding='utf8').write(out);print('ok',len(out))
