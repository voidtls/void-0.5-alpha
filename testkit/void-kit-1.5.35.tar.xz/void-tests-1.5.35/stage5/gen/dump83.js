// ARCH·83: места записи из AST 1.5.22 для генератора. Для каждой функции берётся ИТОГОВОЕ объявление верхнего уровня;
// в нём ищется ровно один оператор-образец (по AST, не по строке), затем строится якорь с контекстом,
// который встречается во всём файле ровно один раз и лежит внутри итогового объявления.
const fs=require('fs'),path=require('path');const NM=path.join(__dirname,'..','..','node_modules');const acorn=require(path.join(NM,'acorn')),walk=require(path.join(NM,'acorn-walk'));
const h=fs.readFileSync(process.argv[2],'utf8');const i=h.indexOf('<script>\n"use strict";')+8,j=h.indexOf('</script>',i);const src=h.slice(i,j);
const ast=acorn.parse(src,{ecmaVersion:2022,ranges:true});const t=n=>src.slice(n.range[0],n.range[1]);
const decl=n=>{const a=ast.body.filter(s=>s.type==='FunctionDeclaration'&&s.id.name===n);if(!a.length)throw new Error('нет '+n);return {fn:a[a.length-1],n:a.length};};
// все операторы-образцы внутри функции (не во вложенных функциях — их нет в этих местах, проверяется)
function find(fnName,pred,what){const {fn,n}=decl(fnName);const hits=[];
  walk.fullAncestor(fn.body,(node,anc)=>{if(pred(node)){const inner=anc.slice(0,-1).some(x=>x!==fn&&/Function/.test(x.type));hits.push({node,inner});}});
  if(hits.length!==1)throw new Error(`${fnName}: образец «${what}» найден ${hits.length} раз`);if(hits[0].inner)throw new Error(fnName+': образец во вложенной функции');
  return {fn,decls:n,node:hits[0].node};}
const isG=(m,f)=>m&&m.type==='MemberExpression'&&!m.computed&&m.object.type==='Identifier'&&m.object.name==='G'&&m.property.name===f;
const isClear=s=>s.type==='IfStatement'&&!s.alternate&&s.test.type==='BinaryExpression'&&s.test.operator==='==='&&isG(s.test.left,'prio')&&s.test.right.type==='Identifier'&&s.test.right.name==='e'
  &&s.consequent.type==='ExpressionStatement'&&s.consequent.expression.type==='AssignmentExpression'&&s.consequent.expression.operator==='='&&isG(s.consequent.expression.left,'prio')&&s.consequent.expression.right.type==='Literal'&&s.consequent.expression.right.value===null;
const isAsg=(s,f,rhs)=>s.type==='ExpressionStatement'&&s.expression.type==='AssignmentExpression'&&s.expression.operator==='='&&isG(s.expression.left,f)&&rhs(s.expression.right);
const out=[];
function site(name,fnName,pred,repl){const r=find(fnName,pred,name);const a=r.node.range[0],b=r.node.range[1];const old=src.slice(a,b),neu=repl(r.node);
  // контекст: расширяем вправо и влево, пока якорь не станет единственным в файле
  let L=0,R=0,anchor;for(let k=0;k<400;k++){anchor=src.slice(a-L,b+R);if(src.split(anchor).length-1===1&&h.split(anchor).length-1===1)break;if(k%2)L+=8;else R+=8;}
  if(h.split(anchor).length-1!==1)throw new Error(name+': не удалось получить единственный якорь');
  if(a-L<r.fn.range[0]||b+R>r.fn.range[1])throw new Error(name+': якорь выходит за итоговое объявление '+fnName);
  out.push({name,fn:fnName,decls:r.decls,old,neu,anchor,newAnchor:src.slice(a-L,a)+neu+src.slice(b,b+R),line:src.slice(0,a).split('\n').length});}
site('kill · ветка twin','kill',isClear,()=> 'prioClear(e);');
site('kill · основная','kill',s=>s.type==='IfStatement'&&s.consequent.type==='BlockStatement'&&s.test.type==='BinaryExpression'&&isG(s.test.left,'prio')&&s.test.right.name==='e'&&s.consequent.body.length===2&&isAsg(s.consequent.body[0],'prio',x=>x.type==='Literal'&&x.value===null),
  s=>{const b0=s.consequent.body[0];return src.slice(s.range[0],b0.range[0])+'prioSet(null);'+src.slice(b0.range[1],s.range[1]);});
site('storyRetreat','storyRetreat',isClear,()=>'prioClear(e);');
site('loopIntercept80','loopIntercept80',isClear,()=>'prioClear(e);');
site('startAnom','startAnom',s=>isAsg(s,'prio',x=>x.type==='Identifier'&&x.name==='e'),()=>'prioSet(e);');
site('startEndless','startEndless',s=>isAsg(s,'aimLock',x=>x.type==='Literal'&&x.value===null),()=>'aimLockClear();');
fs.writeFileSync(process.argv[3],JSON.stringify(out,null,1));for(const o of out)console.log(o.name,'| объявлений',o.decls,'| строка',o.line,'|',JSON.stringify(o.old),'→',JSON.stringify(o.neu),'| якорь',o.anchor.length);
