# Генерирует stage5/arch74_83.py: места и тексты берутся из AST 1.5.22 (dump83.js → t83.json), не набираются вручную.
import json,os
D=os.path.dirname(os.path.abspath(__file__));T=json.load(open(os.path.join(D,'t83.json')))
assert [t['name'] for t in T]==['kill · ветка twin','kill · основная','storyRetreat','loopIntercept80','startAnom','startEndless']
sites=[(t['anchor'],t['newAnchor']) for t in T]
for a,b in sites:assert a!=b
END81='/* ▲▲▲ ARCH·81 · КОНЕЦ ПОДСИСТЕМЫ НАВЕДЕНИЯ ▲▲▲ */'
fns=('/* ARCH·83 · контролируемые точки записи (1.5.23). Внешний код меняет G.prio и G.aimLock только через эти три функции\n'
     '   (или в зарегистрированных групповых сбросах Object.assign в setupMission0, startEndless, enterWorldAt). Логики сверх присваивания нет,\n'
     '   возвращаемое значение не используется. Вызовы: kill (prioClear — ветка twin; prioSet(null) — основная, условие и счётчик prioKills снаружи),\n'
     '   storyRetreat и loopIntercept80 (prioClear), startAnom (prioSet), startEndless (aimLockClear). Записи внутри подсистемы остаются прямыми. */\n'
     'function prioSet(e){G.prio=e;}\n'
     'function prioClear(e){if(G.prio===e)G.prio=null;}\n'
     'function aimLockClear(){G.aimLock=null;}\n')
sites.append((END81,fns+END81))
PRE=('/* ▼▼▼ ARCH·83 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.23 α · этап 5: контролируемые точки записи G.prio / G.aimLock)\n'
     '   Исполняемого кода в этом блоке нет и флага нет: шесть внешних присваиваний заменены вызовами prioSet / prioClear / aimLockClear\n'
     '   (объявлены в конце блока «ARCH·81 · ПОДСИСТЕМА НАВЕДЕНИЯ»). Откат — снятие патча 83. Это не инкапсуляция: G по-прежнему глобален. */\n')
out=('# ---------- 83 · этап 5 · prioSet / prioClear / aimLockClear (контролируемые точки записи) ----------\n'
     '# Сгенерировано stage5/gen/gen83.py из AST 1.5.22 (SHA adc7ae13…).\n'
     'PRE83=%r+END%%83\nS83=%r\n'
     "STAGES[83]=dict(vf='1.5.22 α',vt='1.5.23 α',J='m83_journal.txt',pre=PRE83,after=82,sites=S83)\n")%(PRE,sites)
open(os.path.join(D,'..','arch74_83.py'),'w',encoding='utf8').write(out);print('ok',len(out))
