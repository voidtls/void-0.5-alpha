import re,glob,os,sys
def parse(f):
    if not os.path.exists(f):return None
    n=0;fl=set();errs=0
    for l in open(f,encoding='utf8',errors='replace'):
        m=re.match(r'\s*(OK|FAIL)\s+(\S+)\s*(.*)',l)
        if m:
            n+=1
            if m.group(1)=='FAIL':fl.add(m.group(2)+' '+m.group(3).split(' · ')[0][:70])
        if l.startswith('ERRS') and l.strip()!='ERRS S []' and '[]' not in l:errs+=1
        if 'Traceback' in l:errs+=1
    return (n,len(fl),fl)
for f in sorted(glob.glob('reg20/q*.log')):
    t=os.path.basename(f);b='reg16/'+t.replace('q340s','q340')
    a=parse(b);n=parse(f)
    key=lambda S:{x.split(' ')[0] for x in S}
    new=sorted(x for x in n[2] if x.split(' ')[0] not in key(a[2] if a else set()));fixed=sorted(x for x in (a[2] if a else set()) if x.split(' ')[0] not in key(n[2]))
    print(f"{t:10s} 1.5.16: {a[0] if a else '-'}/{a[1] if a else '-'}  1.5.20: {n[0]}/{n[1]}  "+('НОВЫЕ: '+' | '.join(new) if new else '')+('  ушли: '+' | '.join(fixed) if fixed else ''))
