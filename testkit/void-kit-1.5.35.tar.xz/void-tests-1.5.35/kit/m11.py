# 0.6.2 «Полный экран» · часть 11: модуль FS, настройка fsMode/orient, кнопки ПК и телефона, клавиши, карточка подсказки
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m11: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)

# ---------- CSS ----------
CSS=r"""
/* --- 0.6.2: полный экран --- */
#fsCurtain{position:fixed;inset:0;background:#04060c;opacity:0;pointer-events:none;z-index:60;transition:opacity .2s}
#fsCurtain.show{opacity:1}
.fs-imm,.fs-imm body{background:var(--void)!important}
.fs-imm #wvNote{display:none!important}
#cv.fs-cursor{cursor:none!important}
#bFs.q::after{content:'?';position:absolute;top:1px;right:5px;font-size:10px;color:var(--amber);font-family:var(--f-mono)}
#fsCard{z-index:70}
#fsCard .wrap{width:min(460px,100%)}
#fsCard p{font-size:14px;line-height:1.55}
#fsCard p b{color:var(--ice)}
.fsdiag{font-family:var(--f-mono);font-size:11px;color:#4a5a6e;letter-spacing:.04em;word-break:break-word}
.mob #bFsPc{display:none!important}
body{margin:0}
"""
R("</style>",CSS+"</style>",1)

# ---------- разметка ----------
R('<title>VØID — Последний сигнал</title>','<meta charset="utf-8">\n<title>VØID — Последний сигнал</title>')
# кнопка в меню ПК после справочника
R('<button class="btn" id="bCodex">БОРТОВОЙ СПРАВОЧНИК <kbd>C</kbd></button>',
  '<button class="btn" id="bCodex">БОРТОВОЙ СПРАВОЧНИК <kbd>C</kbd></button>\n      <button class="btn" id="bFsPc" hidden>ВО ВЕСЬ ЭКРАН <kbd>F11</kbd></button>')
# пауза: вернуться во весь экран + разовая кнопка
R('<button class="btn primary" id="bResume">ПРОДОЛЖИТЬ <kbd>ESC</kbd></button>',
  '<button class="btn primary" id="bFsResume" hidden>ПРОДОЛЖИТЬ ВО ВЕСЬ ЭКРАН</button>\n      <button class="btn primary" id="bResume">ПРОДОЛЖИТЬ <kbd>ESC</kbd></button>')
R('<button class="btn" id="bPauseCodex">СПРАВОЧНИК</button>',
  '<button class="btn" id="bPauseCodex">СПРАВОЧНИК</button>\n      <button class="btn" id="bPauseFs" hidden>ВО ВЕСЬ ЭКРАН</button>')
# шторка и карточка подсказки
R('<div id="safeProbe"></div>',
  '<div id="safeProbe"></div>\n<div id="fsCurtain"></div>\n<section class="screen dim" id="fsCard" hidden role="dialog" aria-modal="true" aria-label="Полный экран"><div class="wrap panel"><div class="eyebrow">ПОЛНЫЙ ЭКРАН</div><p id="fsCardText"></p><div class="btns"><button class="btn primary" id="bFsCardOk">ПОНЯТНО</button></div></div></section>')

# ---------- настройки ----------
R("quality:'auto',fps:60,textScale:1,autoFs:true};",
  "quality:'auto',fps:60,textScale:1,fsMode:(window.matchMedia&&matchMedia('(pointer:coarse)').matches)?'auto':'off',orient:'auto',fsHintShown:false};")
R("const SET_OPT={zoom:[.85,1,1.15],","const SET_OPT={fsMode:['off','auto','always'],orient:['auto','land','port'],zoom:[.85,1,1.15],")
R("if(SET.ambVol<0||SET.ambVol>1)SET.ambVol=SET_DEF.ambVol;",
  "if(SET.ambVol<0||SET.ambVol>1)SET.ambVol=SET_DEF.ambVol;\n// 0.6.2: миграция autoFs (0.6.1) → fsMode\n{const raw=store('void_settings');if(raw&&typeof raw==='object'&&typeof raw.autoFs==='boolean'&&raw.fsMode===undefined)SET.fsMode=raw.autoFs?'auto':'off';delete SET.autoFs;}")
# сегменты
R("const SEGS={zoom:[['ЭКРАН · МАСШТАБ',","const SEGS={fsMode:[['ПОЛНЫЙ ЭКРАН',[['off','ВЫКЛ'],['auto','ПРИ ПОЛЁТЕ'],['always','ВСЕГДА']]]],orient:[['ОРИЕНТАЦИЯ · В ПОЛНОМ ЭКРАНЕ',[['auto','АВТО'],['land','АЛЬБОМ'],['port','КНИЖНАЯ']]]],zoom:[['ЭКРАН · МАСШТАБ',")
# мобильный экран настроек: группа ЭКРАН
R("""<div class="setgrp"><div class="cx-h2">ЭКРАН</div>${segHTML('zoom')}${segHTML('textScale')}${segHTML('quality')}${segHTML('fps')}${togHTML('fx','ЭФФЕКТЫ · частицы и тряска')}${fsCan()?togHTML('autoFs','ВО ВЕСЬ ЭКРАН ПРИ СТАРТЕ'):''}
      ${document.fullscreenEnabled?`<button class="tog" id="bFull"><span>НА ВЕСЬ ЭКРАН</span><span>${document.fullscreenElement?'ВКЛ':'ВЫКЛ'}</span></button>`:ios?'<p class="note">На весь экран: «Поделиться» → «На экран Домой» — игра откроется без адресной строки.</p>':''}</div>""",
  """<div class="setgrp"><div class="cx-h2">ЭКРАН</div>${segHTML('fsMode')}<p class="note" id="fsNote">${FS.noteText()}</p>${FS.hintKind()&&!FS.can()?'<div><button class="wbtn" data-fshint>КАК УБРАТЬ ПАНЕЛИ</button></div>':''}${FS.orientOK()?segHTML('orient'):''}
      ${segHTML('zoom')}${segHTML('textScale')}${segHTML('quality')}${segHTML('fps')}${togHTML('fx','ЭФФЕКТЫ · частицы и тряска')}<p class="fsdiag">${FS.diag()}</p></div>""")
# настройки ПК (меню и пауза): строка-переключатель по кругу + диагностика
R("""<button class="tog ${SET.radio?'on':''}" data-k="radio"><span>ПЕРЕХВАТЫ · радиоэфир</span><span>${SET.radio?'ВКЛ':'ВЫКЛ'}</span></button>`+(box.closest('#sMenu')?resetBlock():'');""",
  """<button class="tog ${SET.radio?'on':''}" data-k="radio"><span>ПЕРЕХВАТЫ · радиоэфир</span><span>${SET.radio?'ВКЛ':'ВЫКЛ'}</span></button>${FS.rowPC()}`+(box.closest('#sMenu')?resetBlock():'');""")

# ---------- модуль FS вместо разрозненных fs*-функций ----------
OLD_FS=s[s.find("function fsCan(){"):s.find("document.addEventListener('click',e=>{const b=e.target.closest('.tog[data-k]')")]
assert OLD_FS.count("fullscreenchange")==2 and "#bFull" in OLD_FS, 'блок fs не найден целиком'
NEW_FS=r"""// ===== 0.6.2: полный экран — один модуль =====
const FS={caps:null,state:'off',lastErr:'',wanted:false,tried:false,src:'',chgAt:0,_t:0,
  probe(){const d=document,el=d.documentElement,ua=navigator.userAgent||'';const ipad=/iPad/.test(ua)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1),iphone=/iPhone|iPod/.test(ua)&&!ipad;
    let iframe=false;try{iframe=window.self!==window.top;}catch(e){iframe=true;}
    const webview=/Telegram|FBAN|FBAV|Instagram|VKClient|WhatsApp|Line\/|; wv\)/i.test(ua);let standalone=false;try{standalone=(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true;}catch(e){}
    const api=!!(el.requestFullscreen||el.webkitRequestFullscreen),policy=!!(d.fullscreenEnabled||d.webkitFullscreenEnabled);
    this.caps={api,prefixed:!el.requestFullscreen&&!!el.webkitRequestFullscreen,iframe,policy,iphone,ipad,ios:iphone||ipad,android:/Android/i.test(ua),webview,standalone,mac:/Mac/.test(navigator.platform||'')&&!ipad};
    if(api&&!policy&&!iphone&&!standalone){this.lastErr='policy';this.state='denied';this.immersive(true);}
    if(!iframe||standalone)this.immersive(true);return this.caps;},
  c(){return this.caps||this.probe();},
  can(){const c=this.c();return c.api&&c.policy&&!c.iphone&&!c.standalone&&this.lastErr!=='policy';},
  is(){return !!(document.fullscreenElement||document.webkitFullscreenElement);},
  enter(src){const c=this.c();if(this.is())return true;if(!this.can()){this.state='denied';this.sync();return false;}
    let act=true;try{if(navigator.userActivation&&!navigator.userActivation.isActive)act=false;}catch(e){}
    if(!act){this.lastErr='gesture';this.sync();return false;}
    const el=document.documentElement;this.state='pending';this.wanted=true;this.tried=true;this.src=src||'';if(this.lastErr==='gesture')this.lastErr='';
    let p=null;try{p=el.requestFullscreen?el.requestFullscreen({navigationUI:'hide'}):el.webkitRequestFullscreen();}catch(err){this.fail(err);return false;}
    this.curtain(true);clearTimeout(this._t);this._t=setTimeout(()=>{if(this.state==='pending')this.fail({name:'Timeout'});},1500);
    if(p&&p.then)p.then(()=>{},err=>this.fail(err));return true;},
  fail(err){clearTimeout(this._t);if(this.is()){this.onChange();return;}const n=(err&&err.name)||'';this.lastErr=(n==='TypeError'||n==='NotAllowedError'||n==='Timeout'||n==='SecurityError')?'policy':'other';
    this.state='denied';this.wanted=false;this.curtain(false);this.immersive(true);
    if(this.src==='auto'&&isMob()){if(!SET.fsHintShown){SET.fsHintShown=true;saveSet();toast('ПОЛНЫЙ ЭКРАН НЕДОСТУПЕН','Игра расширится на всё доступное место. Как убрать панели браузера — кнопка ⛶ в меню.');}}
    else if(this.src&&this.src!=='always')this.card(true);this.sync();},
  exit(){this.wanted=false;try{const p=document.exitFullscreen?document.exitFullscreen():document.webkitExitFullscreen&&document.webkitExitFullscreen();if(p&&p.catch)p.catch(()=>{});}catch(err){}},
  toggle(src){if(this.is())this.exit();else if(this.can())this.enter(src);else this.card(true);},
  immersive(on){document.documentElement.classList.toggle('fs-imm',!!on);},
  curtain(on){const el=$('#fsCurtain');if(!el)return;if(!SET.fx){el.classList.remove('show');return;}el.classList.toggle('show',!!on);},
  onChange(){clearTimeout(this._t);const on=this.is();this.chgAt=performance.now();this.state=on?'native':'off';
    if(on){this.lastErr='';this.immersive(true);if((G.state==='play'||G.state==='world')&&this.src==='key')G.resumeK=Math.max(G.resumeK||0,.5);
      if(this.c().android&&SET.orient!=='auto'&&screen.orientation&&screen.orientation.lock){try{screen.orientation.lock(SET.orient==='land'?'landscape':'portrait').catch(()=>{});}catch(e){}}}
    else{if(screen.orientation&&screen.orientation.unlock){try{screen.orientation.unlock();}catch(e){}}if(G.state==='play'||G.state==='world')pause();}
    requestAnimationFrame(()=>requestAnimationFrame(()=>{try{resize();if(typeof readSafe==='function')readSafe();if(typeof layoutTouch==='function')layoutTouch();}catch(e){}this.curtain(false);this.sync();}));
    this.sync();},
  orientOK(){const c=this.c();return !!(c.android&&screen.orientation&&screen.orientation.lock&&this.can());},
  hintKind(){const c=this.c();if(c.standalone)return null;if(c.webview)return 'open-browser';if(c.iphone)return c.iframe?'safari-toolbar':'home-screen';if(!isMob())return 'f11';if(c.ipad)return 'safari-toolbar';return 'direct-link';},
  hintText(){const k=this.hintKind(),mac=this.c().mac;switch(k){
    case 'f11':return `Сайт не пускает игру во весь экран сам. Нажмите <b>${mac?'⌃⌘F':'F11'}</b>: браузер скроет вкладки и адресную строку. Выход — то же сочетание.`;
    case 'safari-toolbar':return 'На iPhone и iPad Safari не разрешает играм открываться во весь экран. Сделайте это вручную: нажмите значок меню страницы слева в адресной строке → <b>«Скрыть панель инструментов»</b>, и поверните телефон горизонтально. Вернуть панель — касание верхнего края.';
    case 'open-browser':return 'Внутри приложения игра не может занять весь экран. Откройте её в Safari или Chrome: меню <b>«…»</b> → <b>«Открыть в браузере»</b>. Прогресс перенесите кодом сохранения.';
    case 'home-screen':return 'Чтобы игра открывалась без адресной строки: <b>«Поделиться»</b> → <b>«На экран Домой»</b>. Запускайте её с иконки — как приложение.';
    case 'direct-link':return 'Сайт не разрешает игре открываться во весь экран. Откройте ссылку на игру напрямую в Chrome (меню <b>⋮</b> → <b>«Открыть в Chrome»</b>) или добавьте её на главный экран.';
    default:return 'Игра уже занимает весь экран.';}},
  noteText(){const c=this.c();if(c.standalone)return 'Игра запущена как приложение — панелей браузера нет.';if(this.can())return 'Доступно: настоящий полный экран'+(this.is()?' · сейчас включён':'')+'.';return 'Этот браузер не пускает игру во весь экран — игра расширится на всё доступное место.';},
  diag(){const c=this.c();return `СРЕДА ${c.iframe?'вложена':'своя'} · API ${c.api?'да':'нет'} · РАЗРЕШЕНИЕ ${c.policy?'да':'нет'} · ${c.iphone?'iPhone':c.ipad?'iPad':c.android?'Android':'ПК'}${c.webview?' · WebView':''}${c.standalone?' · standalone':''} · попытка: ${this.lastErr?'отказ ('+this.lastErr+')':this.state==='native'?'успех':this.tried?'успех':'не было'}`;},
  rowPC(){if(isMob())return '';const L={off:'ВЫКЛ',auto:'ПРИ ПОЛЁТЕ',always:'ВСЕГДА'};return `<button class="tog ${SET.fsMode!=='off'?'on':''}" data-fscycle><span>ПОЛНЫЙ ЭКРАН · ${this.is()?'СЕЙЧАС ВКЛ':this.can()?'F11':'НЕДОСТУПЕН'}</span><span>${L[SET.fsMode]||'ВЫКЛ'}</span></button><p class="fsdiag">${this.diag()}</p>`;},
  card(on){const el=$('#fsCard');if(!el)return;if(on){$('#fsCardText').innerHTML=this.hintText();el.hidden=false;const b=$('#bFsCardOk');if(b&&!touchMode)b.focus();}else el.hidden=true;},
  sync(){const c=this.c(),on=this.is(),can=this.can();
    const b=$('#bFs');if(b){b.hidden=!(isMob()&&!c.standalone);b.classList.toggle('on',on);b.classList.toggle('q',!on&&!can);b.textContent=on?'✕':'⛶';b.setAttribute('aria-pressed',on?'true':'false');b.title=on?'Оконный режим':can?'Во весь экран':'Как убрать панели браузера';}
    const pc=$('#bFsPc');if(pc){pc.hidden=isMob()||c.standalone;pc.innerHTML=on?'ОКОННЫЙ РЕЖИМ <kbd>F11</kbd>':can?'ВО ВЕСЬ ЭКРАН <kbd>F11</kbd>':'НА ВЕСЬ ЭКРАН: НАЖМИТЕ F11';pc.setAttribute('aria-pressed',on?'true':'false');}
    const fr=$('#bFsResume'),pf=$('#bPauseFs'),rs=$('#bResume');if(fr&&pf&&rs){fr.hidden=!(this.wanted&&can&&!on);pf.hidden=!(can&&!on&&!this.wanted);rs.classList.toggle('primary',fr.hidden);}
    if(G.state==='settings'&&typeof renderSetScreen==='function')renderSetScreen();
    if(!isMob()&&(G.state==='menu'||G.state==='pause')){document.querySelectorAll('[data-fscycle]').forEach(el=>{el.outerHTML=this.rowPC().replace(/<p class="fsdiag">.*<\/p>$/,'');});document.querySelectorAll('.fsdiag').forEach(el=>{el.textContent=this.diag();});}}
};
function fsCan(){return FS.can();}function fsIs(){return FS.is();}function fsEnter(){return FS.enter('btn');}function fsExit(){FS.exit();}function fsSync(){FS.sync();}
document.addEventListener('click',e=>{if(e.target.closest('#bFs,#bFsPc')){FS.toggle('btn');buzz('tap');return;}
  if(e.target.closest('#bFsResume')){FS.enter('resume');resume();return;}
  if(e.target.closest('#bPauseFs')){FS.enter('pause');return;}
  if(e.target.closest('[data-fshint]')){FS.card(true);return;}
  if(e.target.closest('#bFsCardOk')){FS.card(false);return;}
  const cy=e.target.closest('[data-fscycle]');if(cy){const o=SET_OPT.fsMode;SET.fsMode=o[(o.indexOf(SET.fsMode)+1)%o.length];saveSet();renderSettings();FS.sync();return;}});
// режим «при полёте»: вход по кнопкам старта и по «продолжить», если игрок хотел полный экран (жест ещё активен)
document.addEventListener('click',e=>{const b=e.target.closest('#bWorld,#bEndless,#bWorldNew,#bResume');if(!b||SET.fsMode==='off'||FS.is())return;if(b.id==='bResume'&&!FS.wanted)return;
  if(!FS.can()){if(isMob()&&b.id!=='bResume'&&!SET.fsHintShown){SET.fsHintShown=true;saveSet();toast('БОЛЬШЕ МЕСТА','Скройте панели браузера — кнопка ⛶ в меню подскажет, как.');}return;}FS.enter('auto');},true);
// режим «всегда»: первое касание в меню или на паузе
document.addEventListener('pointerup',e=>{if(SET.fsMode!=='always'||FS.is()||!FS.can())return;if(G.state==='play'||G.state==='world'||G.state==='settings')return;if(e.pointerType==='mouse'&&e.button!==0)return;if(e.target.closest('#bFs,#bFsPc,#fsCard,[data-fscycle],[data-seg]'))return;FS.enter('always');},true);
document.addEventListener('fullscreenchange',()=>FS.onChange());
document.addEventListener('webkitfullscreenchange',()=>FS.onChange());
"""
s=s.replace(OLD_FS,NEW_FS,1)

# ffUpdate: синхронизация кнопок (была setTimeout(fsSync,0))
R("function ffUpdate(){setTimeout(fsSync,0);","function ffUpdate(){setTimeout(()=>{try{FS.sync();}catch(e){}},0);")

# пауза: кнопки полного экрана
R("function pause(){if(G.state!=='play'&&G.state!=='world')return;G.pausedWorld=G.state==='world';G.state='pause';renderSettings();",
  "function pause(){if(G.state!=='play'&&G.state!=='world')return;G.pausedWorld=G.state==='world';G.state='pause';renderSettings();FS.sync();")

# клавиши: F11 / Alt+Enter / ⌃⌘F; карточка — Esc/Enter
R("  if(e.target&&e.target.tagName==='INPUT')return;if(!synthKey&&!e.repeat)setInput('kbm');\n  if(G.state==='settings'&&e.code==='Escape'){closeSettings();return;}",
  "  if(e.target&&e.target.tagName==='INPUT')return;if(!synthKey&&!e.repeat)setInput('kbm');\n  if(!$('#fsCard').hidden){if(e.code==='Escape'||e.code==='Enter'){e.preventDefault();FS.card(false);}return;}\n  if(e.code==='F11'||(e.code==='Enter'&&e.altKey)||(e.code==='KeyF'&&e.ctrlKey&&e.metaKey)){if(FS.is()||FS.can()){e.preventDefault();FS.toggle('key');return;}}\n  if(G.state==='settings'&&e.code==='Escape'){closeSettings();return;}")
# kh: прятать [F11] на касаниях
R("s.replace(/\\s*\\[(?:[A-ZЁ]|ESC|ENTER|TAB)\\]/g,'')","s.replace(/\\s*\\[(?:[A-ZЁ]|ESC|ENTER|TAB|F11)\\]/g,'')")
# «назад» сразу после смены полного экрана — только выход из него
R("addEventListener('popstate',()=>{histOn=false;if(G.state==='menu')return;escAction();histArm();});",
  "addEventListener('popstate',()=>{histOn=false;if(G.state==='menu')return;if(performance.now()-(FS.chgAt||0)<300){histArm();return;}escAction();histArm();});")
# курсор на ПК в полном экране: прячется через 2,5 с без движения
R("addEventListener('pointermove',e=>{if(e.pointerType!=='mouse')return;",
  "addEventListener('pointermove',e=>{if(e.pointerType!=='mouse')return;MOUSE.mvAt=performance.now();")
R("  touchTick(dt);qTick(dt,now);wakeSync(now);padTick(now);tutTick();}",
  "  touchTick(dt);qTick(dt,now);wakeSync(now);padTick(now);tutTick();\n  cv.classList.toggle('fs-cursor',!isMob()&&FS.state==='native'&&(G.state==='play'||G.state==='world')&&now-(MOUSE.mvAt||0)>2500);}")
# первая синхронизация при показе меню
R("G.state='menu';G.world=false;G.inRun=false;G.player=null;G.boss=null;G.jam=null;G.sb=null;G.bc=null;G.dark=false;CX=0;CY=0;$('#toast').hidden=true;renderMenu();show('sMenu');}",
  "G.state='menu';G.world=false;G.inRun=false;G.player=null;G.boss=null;G.jam=null;G.sb=null;G.bc=null;G.dark=false;CX=0;CY=0;$('#toast').hidden=true;renderMenu();show('sMenu');FS.sync();}")

# Wake Lock: не просить, если политика обёртки запрещает
R("if(want&&!wakeL&&navigator.wakeLock&&now-wakeTry>5000){wakeTry=now;","if(want&&!wakeL&&navigator.wakeLock&&now-wakeTry>5000&&!(document.featurePolicy&&document.featurePolicy.allowsFeature&&!document.featurePolicy.allowsFeature('screen-wake-lock'))){wakeTry=now;")
# справочник
R("<dt>ESC / P</dt><dd>Пауза</dd>","<dt>ESC / P</dt><dd>Пауза</dd><dt>F11 / ALT+ENTER</dt><dd>Во весь экран и обратно (на Mac также ⌃⌘F). Режим «при полёте» или «всегда» — в настройках</dd>")
R("<dt>НАЗАД</dt><dd>Системная кнопка или жест «назад» — пауза, закрыть карту или экран.</dd>",
  "<dt>НАЗАД</dt><dd>Системная кнопка или жест «назад» — пауза, закрыть карту или экран.</dd><dt>ВО ВЕСЬ ЭКРАН</dt><dd>Кнопка ⛶ в меню. Где браузер не пускает игру во весь экран (iPhone), она подскажет, как скрыть панели вручную.</dd>")

# версия и хроника
R('<div class="eyebrow">АЛЬФА 0.6.1 · МОБИЛЬНАЯ</div>','<div class="eyebrow">АЛЬФА 0.6.2 · МОБИЛЬНАЯ</div>')
R("if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.6.1 α</dt>",
  "if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.6.2 α</dt><dd>«Полный экран». Настройка ПОЛНЫЙ ЭКРАН: выкл / при полёте / всегда — на ПК и на телефоне. Кнопка в меню и на паузе, F11 и Alt+Enter. Выход из полного экрана посреди боя — пауза и возврат одним нажатием. Там, где браузер не пускает игру во весь экран (iPhone, встроенные браузеры), кнопка показывает один понятный шаг вместо молчания.</dd><dt>0.6.1 α</dt>")

open(P,'w',encoding='utf8').write(s)
print('m11 ok')
