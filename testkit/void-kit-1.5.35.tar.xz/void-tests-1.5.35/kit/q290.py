# 1.3.5 α «Один курс»: стрелки у края экрана. Каждый тест падает на v35 (1.3.4).
import asyncio,json,sys,os
from h import *
exec(open(SP+'q280.py').read().split("@test('Z01')")[0])
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
# одна сцена: пройдено 5 миссий, корабль у миссии 05, цель — миссия 06; на карте проложен курс к ней же
SCENE="""async(o)=>{const S=G.save;S.tut.off=1;S.cleared=5;for(let m=1;m<=5;m++)S.medals[m]={clear:1};saveWorld();const n5=WORLD.nodes[4],n6=WORLD.nodes[5],p=G.player;
  p.x=n5.x+(o.dx||0);p.y=n5.y+160+(o.dy||0);for(let i=0;i<30;i++)worldUpdate(1/60);$('#toast').hidden=true;
  if(o.course)G.course={x:n6.x,y:n6.y,label:'МИССИЯ 06'};if(o.lost)S.lost={x:n6.x+420,y:n6.y-60,v:40};await w8(400);
  /* перехват текста одного кадра */
  const F=[],St=[];const pf=CanvasRenderingContext2D.prototype.fillText,ps=CanvasRenderingContext2D.prototype.strokeText;
  const rec=(arr)=>function(t,x,y){if(this.canvas&&this.canvas.id==='cv'&&/а\\.е\\./.test(String(t))){const m=this.getTransform();arr.push({n:window.__fn,t:String(t),x:Math.round((m.a*x+m.e)/DPR),y:Math.round((m.d*y+m.f)/DPR),w:this.measureText(String(t)).width*m.a/DPR});}};
  CanvasRenderingContext2D.prototype.fillText=function(t,x,y){rec(F).call(this,t,x,y);return pf.apply(this,arguments);};
  CanvasRenderingContext2D.prototype.strokeText=function(t,x,y){rec(St).call(this,t,x,y);return ps.apply(this,arguments);};
  window.__fn=0;(function tick(){window.__fn++;if(window.__fnOn!==false)requestAnimationFrame(tick);})();delete ctx.fillText;delete ctx.strokeText;const f0=F.length;let n0=typeof F61!=='undefined'?F61.n:0;await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));F.length=0;St.length=0;await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
  /* берём только один кадр: первые записи до повтора текста */
  const n1=F.length?F[0].n:(St.length?St[0].n:-1);const one=a=>a.filter(q=>q.n===n1);
  CanvasRenderingContext2D.prototype.fillText=pf;CanvasRenderingContext2D.prototype.strokeText=ps;return {fill:one(F),stroke:one(St)};}"""
VPS=[(390,844,True),(844,390,True),(1280,720,False)]

@test('V01')
async def v01(b):
    out={}
    for (w,h,t) in VPS:
        P=await mk2(b,w,h,t)
        r=await P.js(SCENE,{'course':True})
        labs=[q['t'] for q in r['fill'] if 'МИССИЯ 06' in q['t']]
        out[f'{w}x{h}']={'labs':labs}
    ok=all(len(v['labs'])==1 and v['labs'][0].startswith('КУРС') for v in out.values())
    rec('V01 курс с карты к миссии 06 + обычная стрелка к ней же: у края одна стрелка и одна подпись «КУРС · МИССИЯ 06» (телефон книжный/альбомный, ПК)',ok,out)

@test('V02')
async def v02(b):
    out={}
    for (w,h,t) in VPS:
        P=await mk2(b,w,h,t)
        r=await P.js(SCENE,{'lost':True})
        L=r['fill'];ov=[]
        for i in range(len(L)):
            for j in range(i+1,len(L)):
                a,c=L[i],L[j]
                if abs(a['x']-c['x'])<(a['w']+c['w'])/2 and abs(a['y']-c['y'])<12:ov.append([a['t'],c['t']])
        out[f'{w}x{h}']={'labs':[q['t'] for q in L],'ov':ov}
    ok=all(len(v['labs'])>=2 and not v['ov'] for v in out.values())
    rec('V02 две разные цели в одну сторону (миссия 06 и потерянный лом): подписи не наслаиваются',ok,out)

@test('V03')
async def v03(b):
    out={}
    for (w,h,t) in [(390,844,True),(844,390,True)]:
        P=await mk2(b,w,h,t)
        r=await P.js(SCENE,{})
        bad=[s for s in r['stroke'] if not any(f['t']==s['t'] and abs(f['x']-s['x'])<=1 and abs(f['y']-s['y'])<=1 for f in r['fill'])]
        moved=[f for f in r['fill'] if not any(s['t']==f['t'] and abs(f['x']-s['x'])<=1 and abs(f['y']-s['y'])<=1 for s in r['stroke'])]
        out[f'{w}x{h}']={'stroke':r['stroke'],'fill':r['fill'],'bad':bad,'moved':moved}
        await P.pg.screenshot(path=SP+f'shots/v03_{w}x{h}.png')
    ok=all(v['stroke'] and not v['bad'] and not v['moved'] for v in out.values())
    rec('V03 телефон: подпись стрелки, отодвинутая от кнопки «ИМП», едет вместе со своей тёмной обводкой — чёрной кляксы на старом месте нет',ok,out)

@test('V04')
async def v04(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("()=>({ver:VER_TAG,tag:$('#verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.3.5 α</dt>')})")
    rec('V04 версия 1.3.5 α и запись в журнале',r['ver']=='1.3.5 α' and r['tag']=='1.3.5 α' and r['log'],r)

if __name__=='__main__':
    sel=sys.argv[1:]
    if sel:TESTS=[t for t in TESTS if t[0] in sel]
    asyncio.run(run(TESTS,'q290'))
