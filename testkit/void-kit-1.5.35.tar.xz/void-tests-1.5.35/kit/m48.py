import sys
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
css=open(D+'m48.css',encoding='utf8').read();i=s.find('</style>');s=s[:i]+css+'\n'+s[i:]
js=open(D+'m48.js',encoding='utf8').read();i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m48 ok')
