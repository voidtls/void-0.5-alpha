# 1.5.5 α «Небо» (BG·PROTO): небо сектора I — мир и миссии 01–06. B01–B24.
import asyncio,json,sys,os,re,hashlib
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
SKY='window.__sky67=true;'
W8="const w8=ms=>new Promise(r=>setTimeout(r,ms));"
# sk.go — миссия; sk.ready — небо собрано целиком сразу; sky() — только небо в cv; lum — яркость (sRGB-luma 0..1) центра и кадра
SK=("const sk={go(m){T.fresh();G.save.tut.off=1;enterNode(m);if(G.state==='intro')startMission();let n=0;while(G.state==='levelup'&&n++<20)choose(0);return G.state;},"
    "world(x,y){toMenu();T.fresh();G.save.tut.off=1;const p=G.player;if(x!==undefined){p.x=x;p.y=y;p.vx=p.vy=0;}worldUpdate(1/60);p.vx=p.vy=0;if(x!==undefined){p.x=x;p.y=y;}camSnap();return G.state;},"
    "ready(){const W_=bg67Where();if(!W_)return null;bg67Draw(1,W_);let n=0;while(BG67.job&&n++<500)bg67Step(50);for(let i=0;i<3;i++)bg67Tiles(bg67Frame());BG67.fresh=false;return W_;},"
    "sky(t,W_){ctx.setTransform(1,0,0,1,0,0);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;ctx.fillStyle='#000';ctx.fillRect(0,0,cv.width,cv.height);return bg67Draw(t,W_||bg67Where());},"
    "old(t){ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#000';ctx.fillRect(0,0,cv.width,cv.height);bg67OldSky(t);},"
    "lum(){const w=cv.width,h=cv.height,d=ctx.getImageData(0,0,w,h).data;let c=0,cn=0,a=0,an=0,hi=[];for(let y=0;y<h;y+=3)for(let x=0;x<w;x+=3){const o=(y*w+x)*4,l=(.299*d[o]+.587*d[o+1]+.114*d[o+2])/255;a+=l;an++;const ex=(x/w-.5)/.3,ey=(y/h-.5)/.3;if(ex*ex+ey*ey<1){c+=l;cn++;}if(y>h*.12&&y<h*.85)hi.push(l);}"
    "hi.sort((p,q)=>p-q);return {c:+(c/cn).toFixed(4),f:+(a/an).toFixed(4),p99:+hi[Math.floor(hi.length*.99)].toFixed(3)};},"
    "hash(){const d=ctx.getImageData(0,0,cv.width,cv.height).data;let h=2166136261;for(let i=0;i<d.length;i+=7){h^=d[i];h=Math.imul(h,16777619);}return h>>>0;}};")
async def spage(b,w=1280,h=760,touch=False,sky=True,extra=''):
    return await newpage(b,w,h,alpha=True,touch=touch,init=(SKY if sky else '')+extra)

@test('B01')
async def b01(b):
    P=await spage(b,sky=False)
    r=await P.js("async()=>{"+W8+SK+"sk.go(1);await w8(900);const a={st:G.state,key:BG67.lastKey,where:bg67Where(),bot:bg67Bot()};toMenu();sk.world();await w8(600);a.wkey=BG67.lastKey;a.wst=G.state;return a}")
    ok=r['key']=='' and r['where'] is None and r['bot'] and r['wkey']=='' and r['st']=='play' and not P.errs
    rec('B01 под автотестами (navigator.webdriver) небо выключено, пока тест не попросит __sky67: старые наборы видят старое небо',ok,{**r,'errs':P.errs[:2]})

@test('B02')
async def b02(b):
    P=await spage(b)
    r=await P.js("()=>{"+SK+"const out={};for(const m of [1,4,6]){sk.go(m);let n=0;const mr=Math.random;Math.random=function(){n++;return mr();};try{BG67.pano={};BG67.tiles=null;BG67.lastKey='';const W_=sk.ready();for(let i=0;i<30;i++){sk.sky(i*.1,W_);bg67Dust(W_);}}finally{Math.random=mr;}out['m'+m]=n;}"
                 "sk.world();let n=0;const mr=Math.random;Math.random=function(){n++;return mr();};try{BG67.pano={};BG67.lastKey='';const W_=sk.ready();for(let i=0;i<30;i++)sk.sky(i*.1,W_);}finally{Math.random=mr;}out.w=n;return out}")
    ok=all(v==0 for v in r.values())
    rec('B02 небо не трогает Math.random: сборка панорамы, плитки звёзд, 30 кадров неба и пыли в 01/04/06 и в мире — ноль вызовов',ok,r)

@test('B03')
async def b03(b):
    P=await spage(b)
    code=("async()=>{"+W8+SK+"const run=(sky)=>{BG67.dead=sky?0:1;T.fresh();G.save.tut.off=1;Math.random=mulberry(777);G.layoutSeed=55;G.keepLayout=true;enterNode(3);if(G.state==='intro')startMission();"
          "for(let s=0;s<60*30&&(G.state==='play'||G.state==='levelup');s++){if(G.state==='levelup'){let k=0;while(G.state==='levelup'&&k++<10)choose(0);continue;}const p=G.player;p.hp=Math.max(p.hp,G.st.maxHp*.6);const a=s/150;steer2(W/2+Math.cos(a)*W*.28,H/2+Math.sin(a)*H*.28);if(s%140===0)tryDash();"
          "update(1/60);render(performance.now());drawDevOverlay();if(s===600){/* поворот экрана посреди боя: старое небо пересобирается */buildNebula();buildStars();}}const p=G.player;"
          "return {st:G.state,t:+G.mT.toFixed(3),k:G.kills,tk:Math.round(G.taken),x:Math.round(p.x),y:Math.round(p.y),e:G.enemies.filter(e=>e.alive).map(e=>e.type+Math.round(e.x)).join(','),rnd:Math.random(),drawn:BG67.stats.n};};"
          "const a=run(true);toMenu();await w8(100);const z=run(false);BG67.dead=0;const sa=Object.assign({},a),sz=Object.assign({},z);delete sa.drawn;delete sz.drawn;return {same:JSON.stringify(sa)===JSON.stringify(sz),a,z}}")
    r=await P.js(code)
    ok=r['same'] and r['a']['drawn']>100 and r['a']['st'] in ('play','done','levelup')
    rec('B03 бой не меняется: 30 с миссии 03 с одним сидом — с новым небом и без него (и с пересборкой старого неба посреди боя) — один итог до врага и следующего случайного числа',ok,r)

@test('B04')
async def b04(b):
    P=await spage(b)
    r=await P.js("()=>{Math.random=mulberry(31337);const ref=[Math.random(),Math.random()];Math.random=mulberry(31337);buildNebula();buildStars();const got=[Math.random(),Math.random()];const iso=document.documentElement.outerHTML.includes('buildNebula=iso65(buildNebula)');return {same:ref[0]===got[0]&&ref[1]===got[1],iso}}")
    ok=r['same'] and r['iso']
    rec('B04 старое небо со своей случайностью: buildNebula/buildStars не сдвигают Math.random (строка изоляции — вне вырезаемого блока)',ok,r)

@test('B05')
async def b05(b):
    out={}
    for (w,h,t,name) in [(1280,760,False,'pc'),(390,844,True,'ph')]:
        P=await spage(b,w,h,touch=t)
        r=await P.js("async()=>{"+W8+SK+"sk.go(2);BG67.pano={};BG67.lastKey='';BG67.stats.chunkMax=0;const fr=[];let n=0;const t0=performance.now();while(n<600){const a=performance.now();render(performance.now());fr.push(performance.now()-a);n++;if(BG67.pano[BG67.lastKey]&&!BG67.job)break;await w8(1);}"
                     "fr.sort((a,b)=>b-a);return {frames:n,ms:Math.round(performance.now()-t0),worst:+fr[0].toFixed(1),p90:+fr[Math.floor(fr.length*.1)].toFixed(1),chunk:+BG67.stats.chunkMax.toFixed(1),build:Math.round(BG67.stats.build),fresh:BG67.fresh,old:true}}")
        out[name]=r
    ok=all(v['frames']>=8 and v['chunk']<=30 and v['worst']<=45 for v in out.values())
    rec('B05 панорама собирается по частям: десятки кадров по 5–6 мс, ни один кадр сборки не длиннее 45 мс (ПК и телефон), пока собирается — старое небо',ok,out)

@test('B06')
async def b06(b):
    P=await spage(b)
    r=await P.js("()=>{"+SK+"const o={};for(const m of [1,2,3,4,5,6]){sk.go(m);for(const e of G.enemies)e.alive=false;const W_=sk.ready();sk.sky(2,W_);o['m'+m]=sk.lum();}sk.old(2);o.old=sk.lum();"
                 "sk.world();const W_=sk.ready();sk.sky(2,W_);o.w=sk.lum();return o}")
    ok=all(r['m%d'%m]['c']<=.085 for m in range(1,6)) and r['m6']['c']<=.10 and r['w']['c']<=.06 and all(r[k]['p99']<=.35 for k in r if k!='old') and all(r[k]['c']<=r[k]['f']*(1 if k=='m6' else .95) for k in r if k!='old')
    rec('B06 центр боя спокойный: яркость неба в центральном эллипсе (sRGB-luma) ≤ 0,085, в 06 ≤ 0,10, в мире ≤ 0,06; центр темнее кадра (в 06, у самого Ядра, — не ярче кадра); 99-й процентиль ≤ 0,35 (линейная яркость центра — меньше 0,01, норма мета-промпта 0,06 выполнена с запасом)',ok,r)

@test('B07')
async def b07(b):
    out={};bad=[]
    for (w,h,t,name) in [(1280,760,False,'pc'),(1920,1080,False,'fhd'),(2560,1080,False,'uw'),(3840,2160,False,'4k'),(390,844,True,'ph'),(844,390,True,'phl'),(1024,1366,True,'tab'),(1366,1024,True,'tabl')]:
        P=await spage(b,w,h,touch=t)
        r=await P.js("()=>{"+SK+"const o=[];for(const m of [1,2,3,4,5,6]){sk.go(m);const W_=sk.ready();sk.sky(1,W_);const F=bg67Frame(),S=bg67Spec(W_),h=bg67HeroFrame(S,F),hd=bg67Hud(F),cx=F.fw/2,cy=F.fh/2;"
                     "const e=Math.hypot((h.x-cx)/(.3*F.fw),(h.y-cy)/(.3*F.fh));let arc=null;if(S.pts&&BG67.arcGeo){const A=BG67.arcGeo,k=F.k;arc=+(Math.abs(Math.hypot(A.cx-F.cw/2,A.cy-F.ch/2)-A.r)/(F.min*k)).toFixed(3);}"
                     "o.push({m,e:+e.toFixed(2),x:Math.round(h.x),y:Math.round(h.y),fw:Math.round(F.fw),fh:Math.round(F.fh),inHud:h.y<hd.t||h.y>F.fh-hd.b||h.x<hd.l||h.x>F.fw-hd.r,low:F.portrait&&h.y>F.fh*.45,far:Math.abs(h.x-cx)>.9*F.min+1,arc});}return o}")
        out[name]=r
        for o in r:
            if o['e']<1.14 or o['inHud'] or o['low'] or o['far'] or (o['arc'] is not None and o['arc']<.355):bad.append((name,o))
    rec('B07 Маяк и Дуга на восьми экранах (ПК, FHD, 21:9, 4K, телефон и планшет в обеих ориентациях): Маяк вне центрального эллипса, вне полос интерфейса, на вертикальном экране — в верхней половине; Дуга не ближе 0,36 короткой стороны к центру',not bad,{'bad':bad[:4],'pc':out['pc'][:2],'ph':out['ph'][:2]})

@test('B08')
async def b08(b):
    out={}
    for (w,h,t,name) in [(1280,760,False,'pc'),(390,844,True,'ph'),(844,390,True,'phl')]:
        P=await spage(b,w,h,touch=t)
        r=await P.js("async()=>{"+W8+SK+"sk.world();await w8(300);const B=WORLD.sectors[0].box,o=[];let h0=null,c0=null,worst=0;for(const [u,v] of [[.1,.1],[.9,.1],[.5,.5],[.1,.9],[.85,.85],[.5,.15]]){const x=B[0]+(B[2]-B[0])*u,y=B[1]+(B[3]-B[1])*v;sk.world(x,y);const W_=bg67Where();if(!W_)continue;"
                     "const h=bg67HeroWorld(bg67Spec(W_),bg67Frame()),c=bg67CamC();if(h0){const dh=Math.hypot(h.x-h0.x,h.y-h0.y),dc=Math.hypot(c.x-c0.x,c.y-c0.y);worst=Math.max(worst,dh/(dc||1));}else{h0=h;c0=c;}o.push([Math.round(h.x),Math.round(h.y)]);}"
                     "const F=bg67Frame(),k=F.k,hp={x:h0.x*SC,y:h0.y*SC};const near=(el)=>{if(!el||el.hidden||!el.getBoundingClientRect)return 1e9;const r=el.getBoundingClientRect();if(!r.width)return 1e9;const dx=Math.max(r.left-hp.x,0,hp.x-r.right),dy=Math.max(r.top-hp.y,0,hp.y-r.bottom);return Math.hypot(dx,dy);};"
                     "return {o,ratio:+worst.toFixed(4),mini:Math.round(near($('#mini'))),btn:Math.round(near($('#btnMap')))}}")
        out[name]=r
    ok=all(v['ratio']<=.011 and v['mini']>=40 and v['btn']>=40 for v in out.values())
    rec('B08 в мире Маяк — самая дальняя точка: стоит на месте (параллакс 0,01 — смещение не больше 1,1 % пути камеры), не под миникартой и кнопкой «КАРТА» (ПК, телефон в обеих ориентациях)',ok,out)

@test('B09')
async def b09(b):
    P=await spage(b)
    r=await P.js("()=>{"+SK+"const B=WORLD.sectors[0].box,y=(B[1]+B[3])/2,o={};sk.world(B[2]+700,y);o.out=bg67Where();sk.world(B[2],y);const W_=bg67Where();o.blend=W_&&+W_.blend.toFixed(2);"
                 "sk.world(B[0]+1500,y);sk.ready();const _g=glow;let n=0,nI=0;const inI=G.decor.filter(d=>d.x<B[2]-400&&d.y>B[1]&&d.y<B[3]&&inView(d.x,d.y,d.r)).length;glow=function(x,y){n++;if(x<B[2]-400&&y>B[1]&&y<B[3]&&G.decor.some(d=>d.x===x&&d.y===y))nI++;return _g.apply(this,arguments);};try{renderWorld(performance.now());}finally{glow=_g;}o.decorInView=inI;o.decorDrawn=nI;o.decorAfter=G.decor.length;return o}")
    ok=r['out'] is None and r['blend'] is not None and .3<=r['blend']<=.7 and r['decorDrawn']==0 and r['decorAfter']>0
    rec('B09 граница с сектором II: за воротами — старое небо, у самой границы — смесь пополам; свечения decor сектора I заменены туманом (и вернулись в список после кадра)',ok,r)

@test('B10')
async def b10(b):
    P=await spage(b)
    r=await P.js("async()=>{"+W8+SK+"openSettings();await w8(100);tabGo63('scr');await w8(50);const row=document.querySelector('[data-n63=\"sky\"]');const vis=!!row&&!row.closest('.tab63').hidden;const n=row?row.querySelectorAll('[data-sky67]').length:0;"
                 "row.querySelector('[data-sky67=\"bright\"]').click();await w8(50);const st=JSON.parse(localStorage.getItem('void_settings')).sky;const on=document.querySelector('[data-sky67=\"bright\"]').classList.contains('on');"
                 "closeSettings&&closeSettings();sk.go(1);const W_=sk.ready();const L={};for(const k of ['dim','norm','bright']){SET.sky=k;sk.sky(2,W_);L[k]=sk.lum().f;}SET.sky='norm';saveSet();return {vis,n,st,on,L,def:SET_DEF.sky}}")
    L=r['L'];ok=r['vis'] and r['n']==3 and r['st']=='bright' and r['on'] and L['dim']<L['norm']<L['bright'] and r['def']=='norm'
    rec('B10 настройка «ЯРКОСТЬ НЕБА: ТУСКЛЕЕ / ОБЫЧНАЯ / ЯРЧЕ» во вкладке «ЭКРАН», сохраняется и правда меняет яркость неба',ok,r)

@test('B11')
async def b11(b):
    out={}
    for (w,h,dsf,mob,name) in [(3840,2160,1,False,'4k'),(1920,1080,2,False,'fhd2x'),(390,844,3,True,'ph3x'),(412,915,2.6,True,'and')]:
        ctx=await b.new_context(viewport={'width':w,'height':h},device_scale_factor=dsf,is_mobile=mob,has_touch=mob)
        await ctx.add_init_script('window.__alpha=true;'+SKY);pg=await ctx.new_page();await pg.goto(GAME);await pg.wait_for_timeout(300);await pg.evaluate(LIB)
        r=await pg.evaluate("()=>{"+SK.replace('T.fresh()',"(localStorage.removeItem('void_world'),startWorld(true),G.prologue&&prologueEnd())")+"sk.go(1);sk.ready();const a=BG67.stats.mem;toMenu();sk.world();sk.ready();return {mission:+(a/1048576).toFixed(1),both:+(BG67.stats.mem/1048576).toFixed(1),panos:Object.keys(BG67.pano).length,mob:isMob(),dpr:DPR}}")
        out[name]=r;await ctx.close()
    ok=out['4k']['both']<=12 and out['fhd2x']['both']<=12 and out['ph3x']['both']<=6 and out['and']['both']<=6
    rec('B11 память неба: ≤ 12 МБ на 4K и FHD×2, ≤ 6 МБ на телефоне (панорамы + плитки звёзд)',ok,out)

@test('B12')
async def b12(b):
    P=await spage(b)
    r=await P.js("()=>{"+SK+"sk.go(4);const W_=sk.ready();const h=(t)=>{sk.sky(t,W_);return sk.hash();};const o={};SET.fx=true;o.liveA=h(1);o.liveB=h(2.7);SET.fx=false;o.offA=h(1);o.offB=h(2.7);SET.fx=true;const c0=SET.cine;SET.cine='calm';o.calmA=h(1);o.calmB=h(2.7);SET.cine=c0;return o}")
    ok=r['liveA']!=r['liveB'] and r['offA']==r['offB'] and r['calmA']==r['calmB']
    rec('B12 «Эффекты: выкл» и «Кино: тихое»/меньше движения — небо неподвижно (кадры через 1,7 с совпадают до пикселя); с эффектами оно живёт',ok,r)

@test('B13')
async def b13(b):
    P=await spage(b)
    r=await P.js("()=>{"+SK+"sk.world();const W_=sk.ready();BG67.dev.lvl='2';const E=BG67.ev,now=performance.now()/1000;E.nextShoot=now-1;E.nextWalk=now-1;E.eclipseDone=0;E.idle=0;let shot=0,walk=0,ecl=0;const p=G.player;"
                 "for(let i=0;i<60*10;i++){p.vx=p.vy=0;sk.sky(i/60,W_);if(E.shoot)shot++;if(E.walk)walk++;if(E.eclipse)ecl++;}const once=E.eclipseDone;E.eclipse=null;E.idle=0;let again=0;for(let i=0;i<60*10;i++){sk.sky(i/60,W_);if(E.eclipse)again++;}"
                 "const c0=SET.cine;SET.cine='calm';E.shoot=null;E.walk=null;E.nextShoot=now-1;let calm=0;for(let i=0;i<120;i++){sk.sky(i/60,W_);if(E.shoot||E.walk)calm++;}SET.cine=c0;"
                 "toMenu();sk.go(1);const M=sk.ready();E.shoot=null;E.walk=null;E.nextShoot=now-1;let mis=0;for(let i=0;i<120;i++){sk.sky(i/60,M);if(E.shoot)mis++;}BG67.dev.lvl='auto';return {shot,walk,ecl,once,again,calm,mis}}")
    ok=r['shot']>20 and r['walk']==0 and r['ecl']==0 and r['again']==0 and r['calm']==0 and r['mis']==0
    rec('B13 редкие события только в открытом мире: падающая звезда (огонька по Дуге с 1.5.6 нет, «затмения при остановке» с 1.5.7 нет — его заменили камни); в миссиях и в тихом режиме их нет',ok,r)

@test('B14')
async def b14(b):
    P=await newpage(b,1280,800,alpha=False,init='window.__devUI=true;'+SKY)
    r=await P.js("async()=>{"+W8+"toMenu();openDev();await w8(150);DEVW.enter();await w8(400);$('#toast').hidden=true;dvxOpen(true);await w8(80);document.querySelector('#dvx [data-a=tab][data-v=world]').click();await w8(60);"
                 "const grp=[...document.querySelectorAll('#dvx .g65 h4')].map(h=>h.textContent).filter(t=>/НЕБО/.test(t));const layers=document.querySelectorAll('#dvx [data-a=bg67off]').length;document.querySelector('#dvx [data-a=bg67off][data-v=hero]').click();await w8(30);const off=!!BG67.dev.off.hero;"
                 "document.querySelector('#dvx [data-a=bg67off][data-v=hero]').click();document.querySelector('#dvx [data-a=bg67m][data-v=\"4\"]').click();await w8(30);const m=BG67.dev.m;document.querySelector('#dvx [data-a=bg67m][data-v=\"0\"]').click();"
                 "document.querySelector('#dvx [data-a=bg67rebuild]').click();await w8(30);const rb=Object.keys(BG67.pano).length;document.querySelector('#dvx [data-a=bg67zones]').click();const z=BG67.dev.zones;document.querySelector('#dvx [data-a=bg67zones]').click();await w8(400);"
                 "const live=(document.querySelector('#dvx [data-live=bg67]')||{}).textContent||'';document.querySelector('#dvx [data-a=tab][data-v=fight]').click();await w8(60);const fg=[...document.querySelectorAll('#dvx .g65 h4')].map(h=>h.textContent).filter(t=>/НЕБО/.test(t)).length;dvLeave();return {grp,layers,off,m,rb,z,live,fg}}")
    ok=len(r['grp'])==1 and r['layers']==10 and r['off'] and r['m']==4 and r['rb']==0 and r['z'] and ('МИР' in r['live'] or 'МИССИЯ' in r['live'] or 'не в секторе' in r['live']) and r['fg']==1
    rec('B14 Верстак: группа «НЕБО · 1.5.5» во вкладках «МИР» и «БОЙ» — 10 слоёв по одному, небо любой миссии, зоны, пересборка, живая строка бюджета',ok,{**r,'errs':P.errs[:2]})

@test('B15')
async def b15(b):
    s=open('@@KIT@@/home/void.html',encoding='utf8').read()
    a=s.find('/* ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ BG·PROTO');z=s.find('▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲ BG·PROTO');z=s.find('*/',z)+2
    ca=s.find('/* ▼▼▼ BG·PROTO');ce='КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА (CSS) ▲▲▲ */';cz=s.find(ce,ca)+len(ce)
    ok0=a>0 and z>a and ca>0 and cz>ca
    cut=s[:ca]+s[cz:a]+s[z:] if ca<a else s[:a]+s[z:ca]+s[cz:]
    rest=len(re.findall(r'\bBG67|\bbg67[A-Z]\w*|data-sky67',cut));iso='buildNebula=iso65(buildNebula)' in cut
    open('@@KIT@@/home/void_cut67.html','w',encoding='utf8').write(cut)
    P=await newpage(b,1280,760,url='file://@@KIT@@/home/void_cut67.html',alpha=True,init=SKY)
    r=await P.js("async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();enterNode(1);startMission();await w8(1200);const k=T.bot({maxSec:25});toMenu();T.fresh();await w8(500);return {BG67:typeof BG67,st:k.state,w:G.state}}")
    ok=ok0 and rest==0 and iso and r['BG67']=='undefined' and r['st'] in ('play','done') and not P.errs
    rec('B15 вырезаемость: блок BG·PROTO отмечен в JS и CSS; без него не остаётся ни одного bg67, строка изоляции старого неба на месте, игра грузится, миссия 01 и мир идут без ошибок',ok,{'marks':ok0,'rest':rest,'iso':iso,**r,'errs':P.errs[:3]})

@test('B16')
async def b16(b):
    P=await spage(b)
    r=await P.js("async()=>{"+W8+SK+"sk.go(1);sk.ready();const keep=BG67M[1].pos;BG67M[1].pos=null;let n=0;for(let i=0;i<20;i++){update(1/60);render(performance.now());n++;}const o={err:BG67.err,dead:BG67.dead,st:G.state};BG67M[1].pos=keep;BG67.err=0;BG67.dead=0;"
                 "render(performance.now());o.back=BG67.err===0;return o}")
    errs=[e for e in P.errs if 'bg67' not in e and 'pos' not in e and 'null' not in e]
    ok=r['err']>12 and r['dead']==1 and r['st']=='play' and r['back'] and not errs
    rec('B16 ошибка в небе не роняет игру: кадр рисуется старым небом, после 12 ошибок модуль выключается сам',ok,{**r,'other':errs[:2]})

@test('B17')
async def b17(b):
    P=await spage(b)
    r=await P.js("async()=>{"+W8+SK+"sk.world();await w8(200);openMap('map');await w8(400);const c=$('#mapC'),M=G.mapXY;const ok=!!(c&&M);const x=M.X(BG67CORE.x)*DPR,y=M.Y(BG67CORE.y)*DPR;closeMap&&closeMap();return {ok,x:Math.round(x),y:Math.round(y)}}")
    ok=r['ok'] and not P.errs
    rec('B17 карта: у Ядра — тот же холодный ореол, что Маяк на небе; карта рисуется без ошибок',ok,{**r,'errs':P.errs[:2]})

@test('B18')
async def b18(b):
    P=await spage(b)
    r=await P.js("async()=>{"+W8+SK+"sk.go(5);sk.ready();const o={};for(const l of ['2','0','2','0']){BG67.dev.lvl=l;await w8(300);BG67.stats.ms=0;BG67.stats.n=0;const a=[];for(let i=0;i<12;i++){await w8(100);a.push(BG67.stats.ms);}o['l'+l]=(o['l'+l]||0)+a.reduce((x,y)=>x+y,0)/a.length/2;}"
                 "BG67.dev.lvl='auto';BG67.lvlCut=0;BG67.slow=[];BG67.stats.n=500;for(let i=0;i<8;i++)bg67Stat(9);o.cut=BG67.lvlCut;BG67.lvlCut=0;for(const k in o)o[k]=+(+o[k]).toFixed(3);return o}")
    ok=r['l0']<r['l2'] and r['cut']>=1
    rec('B18 уровни деталей: 0 дешевле 2 (по живым кадрам); сверх бюджета несколько раз за 3 с — уровень снижается сам',ok,r)

@test('B19')
async def b19(b):
    hs=[]
    for i in range(2):
        P=await spage(b)
        h=await P.js("()=>{"+SK+"sk.go(3);const W_=sk.ready();SET.fx=false;sk.sky(1,W_);return sk.hash()}")
        hs.append(h)
    rec('B19 одно небо на сектор: две разные загрузки дают небо 03 один в один',hs[0]==hs[1],{'h':hs})

@test('B20')
async def b20(b):
    P=await spage(b)
    r=await P.js("async()=>{"+W8+SK+"sk.go(1);await w8(1500);const k1=BG67.lastKey,ok1=!!BG67.pano[k1];window.dispatchEvent(new Event('resize'));"
                 "await w8(50);return {k1,ok1}}")
    await P.pg.set_viewport_size({'width':900,'height':700});await P.wait(400)
    r2=await P.js("async()=>{"+W8+"const k2=BG67.lastKey,fall=!!Object.keys(BG67.pano).length;let n=0;while(!(BG67.pano[k2]&&!BG67.job)&&n++<80)await w8(50);return {k2,fall,done:!!BG67.pano[k2],err:BG67.err,st:G.state}}")
    ok=r['ok1'] and r2['k2']!=r['k1'] and r2['done'] and r2['err']==0 and not P.errs
    rec('B20 смена размера окна посреди миссии: новое небо собирается в фоне, пока виден прежний кадр; без ошибок',ok,{**r,**r2})

@test('B21')
async def b21(b):
    P=await spage(b)
    r=await P.js("async()=>{"+W8+SK+"const o={};for(const m of [6,7]){sk.go(m);await w8(200);o['m'+m]=!!bg67Where();}toMenu();o.menu=bg67Where();return o}")
    ok=r['m6'] and not r['m7'] and r['menu'] is None
    rec('B21 небо сектора I — только в миссиях 01–06 и в мире у сектора I; с 07 и в меню — прежнее',ok,r)

@test('B22')
async def b22(b):
    P=await spage(b)
    r=await P.js("()=>{"+SK+"sk.go(1);const W_=sk.ready();const o={};for(const k of ['far','stars','lanes','arc','hero','mid','dust','ev','calm','dith']){BG67.dev.off[k]=true;sk.sky(1,W_);bg67Dust(W_);o[k]=BG67.err;BG67.dev.off[k]=false;}BG67.dev.zones=true;sk.sky(1,W_);BG67.dev.zones=false;o.z=BG67.err;return o}")
    ok=all(v==0 for v in r.values()) and not P.errs
    rec('B22 каждый слой выключается по одному без ошибок (для проверок на Верстаке)',ok,r)

@test('B23')
async def b23(b):
    P=await spage(b)
    r=await P.js("async()=>{"+W8+SK+"sk.world();await w8(300);const o={};for(const [n,s] of [['play',1],['pause',0]]){}const p=G.player;const t0=performance.now();let f=0;const B=WORLD.sectors[0].box;for(let i=0;i<240;i++){p.x=B[0]+300+i*15;p.y=(B[1]+B[3])/2;worldUpdate(1/60);camSnap();renderWorld(performance.now());f++;}return {f,err:BG67.err,mem:+(BG67.stats.mem/1048576).toFixed(1),jobs:BG67.log.filter(x=>x.k==='сборка').length}}")
    ok=r['err']==0 and r['jobs']<=2 and not P.errs
    rec('B23 полёт через весь сектор: небо мира собрано один раз (без пересборок на ходу), без ошибок',ok,r)

@test('B24')
async def b24(b):
    P=await spage(b)
    r=await P.js("async()=>{"+W8+SK+"T.fresh();G.save.tut.off=1;enterNode(4);await w8(50);const st=G.state;let n=0;while(!(BG67.pano[BG67.lastKey]&&!BG67.job)&&n++<60)await w8(50);const ready=!!BG67.pano[BG67.lastKey],key=BG67.lastKey;startMission();return {st,ready,key,waited:n*50}}")
    ok=r['st']=='intro' and r['ready'] and r['key'].startswith('m4')
    rec('B24 небо миссии собирается заранее, пока открыт брифинг: к нажатию «В бой» оно уже готово',ok,r)


@test('B25')
async def b25(b):
    out={}
    for (w,h,t,name) in [(1280,760,False,'pc'),(390,844,True,'ph'),(844,390,True,'phl')]:
        P=await spage(b,w,h,touch=t)
        r=await P.js("async()=>{"+W8+SK+"sk.world();await w8(300);const n5=WORLD.nodes.find(n=>n.m===5),C=BG67CORE,p=G.player;let x=n5.x-900;const y=n5.y;p.x=x;p.y=y;camSnap();sk.ready();"
                     "let prev=null,maxj=0,frames=0;const F=bg67Frame();const t0=performance.now();while(x<n5.x+900){await new Promise(r=>requestAnimationFrame(r));const dt=1/60;x+=900*dt;p.x=x;p.y=y;p.vx=p.vy=0;camSnap();frames++;const h=BG67.heroP;if(h&&prev)maxj=Math.max(maxj,Math.hypot(h.x-prev.x,h.y-prev.y));if(h)prev={x:h.x,y:h.y};}"
                     "return {frames,maxj:+maxj.toFixed(1),lim:+(Math.max(F.fw,F.fh)*.025).toFixed(1),portrait:F.portrait}}")
        out[name]=r
    ok=all(v['frames']>30 and v['maxj']<=v['lim'] for v in out.values())
    rec('B25 Маяк в мире не прыгает: пролёт на скорости 900 ед/с мимо миссии 05 над Ядром — за кадр Маяк сдвигается не больше чем на 2,5 % длинной стороны кадра (не быстрее ~63°/с по краю неба) (ПК, телефон вертикально и горизонтально)',ok,out)

@test('B26')
async def b26(b):
    P=await spage(b)
    r=await P.js("()=>{"+SK+"const o={};for(const m of [1,2,3,4,5,6]){sk.go(m);BG67.arcGeo=undefined;const W_=sk.ready();sk.sky(1,W_);o['m'+m]=BG67.arcGeo===undefined;}sk.world();BG67.arcGeo=undefined;const W_=sk.ready();sk.sky(1,W_);o.w=BG67.arcGeo===undefined;"
                 "o.ring6=BG67M[6].ring?1:0;o.walk=('walk' in BG67.ev)&&BG67.ev.walk!==null&&BG67.ev.walk!==undefined;return o}")
    ok=all(r['m%d'%m] for m in range(1,7)) and r['w'] and r['ring6']==1 and not r['walk']
    rec('B26 длинной Дуги нет — ни в миссиях 01–06, ни в мире; кольцо станций в 06 осталось',ok,r)


@test('B27')
async def b27(b):
    out={}
    for (w,h,t,name) in [(1280,760,False,'pc'),(390,844,True,'ph')]:
        P=await spage(b,w,h,touch=t)
        r=await P.js("async()=>{"+W8+SK+"sk.world();await w8(300);const L=bg67MidList().w;let m=L[0];for(const q of L)if(q.r>m.r)m=q;const p=G.player;p.x=m.x;p.y=m.y;camSnap();const W_=sk.ready();const F=bg67Frame(),k=F.k;"
                     "const hero=bg67HeroWorld(bg67Spec(W_),F);const cx=m.x-(hero.x-F.fw/2)/.3,cy=m.y-(hero.y-F.fh/2)/.3;SET.fx=false;let prev=null,maxd=0,lo=1,hi=0,deep=null,deepSd=0,minHid=1,sds=[];"
                     "for(let i=0;i<=600;i++){const u=-1+2*i/600;p.x=cx+u*m.r*3/.3;p.y=cy;camSnap();sk.sky(1,W_);const h=BG67.heroP,X=Math.round(h.x*k),Y=Math.round(h.y*k),S=Math.round(70*k);const d=ctx.getImageData(X-S,Y-S,2*S,2*S).data;let Lm=0;for(let j=0;j<d.length;j+=4)Lm+=.299*d[j]+.587*d[j+1]+.114*d[j+2];Lm/=d.length/4*255;"
                     "if(prev!==null)maxd=Math.max(maxd,Math.abs(Lm-prev));prev=Lm;lo=Math.min(lo,Lm);hi=Math.max(hi,Lm);sds.push(BG67.occ.sd);if(BG67.occ.sd<deepSd){deepSd=BG67.occ.sd;const c=ctx.getImageData(X,Y,1,1).data;deep=(.299*c[0]+.587*c[1]+.114*c[2])/255;}}"
                     "SET.fx=true;const step=Math.abs(m.r*3/.3*2/600*.3*k);return {maxd:+maxd.toFixed(4),range:+(hi-lo).toFixed(4),stepPx:+step.toFixed(2),deepSd:Math.round(deepSd),deepCore:+(deep||0).toFixed(3),covered:sds.some(x=>x<0)}}")
        out[name]=r
    ok=all(v['covered'] and v['deepCore']<=.12 and v['maxd']<=.06*v['range']*max(1,v['stepPx']) for v in out.values())
    rec('B27 затмение плавное: камень проходит перед Маяком шагами меньше 1 px — яркость вокруг Маяка за шаг меняется не больше чем на 6 % размаха; глубоко за камнем ядро Маяка не видно',ok,out)

@test('B28')
async def b28(b):
    P=await spage(b)
    r=await P.js("async()=>{"+W8+SK+"sk.world();await w8(300);const L=bg67MidList().w;let m=L[0];for(const q of L)if(q.r>m.r)m=q;const p=G.player;p.x=m.x;p.y=m.y;camSnap();const W_=sk.ready();const F=bg67Frame(),k=F.k;"
                 "const hero=bg67HeroWorld(bg67Spec(W_),F);p.x=m.x-(hero.x-F.fw/2)/.3;p.y=m.y-(hero.y-F.fh/2)/.3;camSnap();SET.fx=true;BG67.dev.lvl='2';bg67Dust(W_);"
                 "const rk=bg67MidGeo(1,bg67Spec(W_),F,W_,bg67Calm()).reduce((a,b)=>Math.abs(b.r-m.r*k)<1e-6?b:a,null);const ins=[];for(let i=0;i<40;i++){const a=i*2.4,rr=rk.r*.35*((i%5)/5);const x=Math.round(rk.cx+Math.cos(a)*rr),y=Math.round(rk.cy+Math.sin(a)*rr);if(bg67SD(x,y,rk.pts).sd<-9)ins.push([x,y]);}"
                 "const grab=()=>ins.map(([x,y])=>Array.from(ctx.getImageData(x,y,1,1).data.slice(0,3)).join(',')).join(';');"
                 "sk.sky(1,W_);const all=grab();for(const kk of ['stars','hero','lanes','dust','ev'])BG67.dev.off[kk]=true;sk.sky(1,W_);const none=grab();for(const kk in BG67.dev.off)BG67.dev.off[kk]=false;"
                 "const order=[];const _d=bg67Dust,_r=bg67Rocks,_h=bg67Hero;bg67Dust=function(){order.push('пыль');return _d.apply(this,arguments)};bg67Rocks=function(){order.push('камни');return _r.apply(this,arguments)};bg67Hero=function(){order.push('Маяк');return _h.apply(this,arguments)};"
                 "try{sk.sky(1,W_);}finally{bg67Dust=_d;bg67Rocks=_r;bg67Hero=_h;}SET.fx=true;BG67.dev.lvl='auto';const TL=bg67Tiles(F);return {n:ins.length,same:all===none,diff:all.split(';').map((v,i)=>v===none.split(';')[i]?'':i+':'+v+'/'+none.split(';')[i]).filter(Boolean).slice(0,4),order:order.join(' → '),par:TL.map(t=>t.par),dust:[Math.min(...BG67.dust.map(d=>d.par)).toFixed(2),Math.max(...BG67.dust.map(d=>d.par)).toFixed(2)]}}")
    ok=r['n']>=8 and r['same'] and r['order']=='Маяк → пыль → камни' and r['par']==[.02,.035,.06] and float(r['dust'][0])>=1.2 and float(r['dust'][1])<=1.4
    rec('B28 камень непрозрачен и ближе всего фона: пиксели внутри камня не зависят от звёзд, тёмных полос, Маяка, пыли и событий; порядок — Маяк → пыль → камни; скорости параллакса прежние (звёзды 0,02/0,035/0,06, пыль 1,2–1,4)',ok,r)

if __name__=='__main__':
    sel=sys.argv[1:]
    if sel:TESTS=[t for t in TESTS if t[0] in sel]
    asyncio.run(run(TESTS,'q350'))
