# 1.1.1 α «Стекло»: редизайн оболочки по мета-промпту (токены, компоненты, экраны, HUD, движение, доступность)
import sys,os
P='@@KIT@@/home/void.html'
D=os.path.dirname(os.path.abspath(__file__))
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m25 FAIL count',n,'!=',cnt,'for',a[:90]);sys.exit(1)
    s=s.replace(a,b)

# 1. стиль: блок 1.1.1 в конец единственного <style>
css=open(os.path.join(D,'m25.css'),encoding='utf8').read()
R('</style>',css+'\n</style>')

# 2. разметка: герой меню, боковая панель брифинга, основная кнопка кода, версия
HERO='''<div class="hero" aria-hidden="true"><svg viewBox="0 0 600 600">
  <defs><radialGradient id="heroG" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#8fe9ff" stop-opacity=".18"/><stop offset=".55" stop-color="#8fe9ff" stop-opacity=".04"/><stop offset="1" stop-color="#8fe9ff" stop-opacity="0"/></radialGradient></defs>
  <circle cx="300" cy="300" r="300" fill="url(#heroG)"/>
  <g fill="none" stroke="#8fe9ff">
    <circle cx="300" cy="300" r="78" stroke-opacity=".32"/>
    <circle cx="300" cy="300" r="150" stroke-opacity=".16" stroke-dasharray="2 7"/>
    <circle cx="300" cy="300" r="222" stroke-opacity=".11"/>
    <circle cx="300" cy="300" r="290" stroke-opacity=".06" stroke-dasharray="1 9"/>
    <circle class="pr" cx="300" cy="300" r="60" stroke-opacity=".55"/>
    <circle class="pr p2" cx="300" cy="300" r="60" stroke-opacity=".55"/>
    <path d="M300 4v28M300 568v28M4 300h28M568 300h28" stroke-opacity=".3"/>
  </g>
  <g class="orb"><circle cx="450" cy="300" r="14" fill="none" stroke="#8fe9ff" stroke-opacity=".25"/><path d="M462 300 445 292.5 449 300 445 307.5Z" fill="#e8f1fa"/></g>
  <g class="orb2"><circle cx="300" cy="78" r="3" fill="#ffb84d"/><circle cx="300" cy="78" r="9" fill="none" stroke="#ffb84d" stroke-opacity=".35"/></g>
  <circle cx="300" cy="300" r="22" fill="#8fe9ff" fill-opacity=".08"/><circle cx="300" cy="300" r="5" fill="#8fe9ff"/>
</svg></div>'''
R('<section class="screen" id="sMenu">\n','<section class="screen" id="sMenu">\n  '+HERO+'\n')
R('    <div class="diffbox" id="inDiffBox" hidden>','    <div class="brief-side"><div class="diffbox" id="inDiffBox" hidden>')
R('НАЗАД В СЕКТОР</button></div>','НАЗАД В СЕКТОР</button></div></div>')
R('<button class="btn" id="bSaveCopy">','<button class="btn primary" id="bSaveCopy">')
R('<div class="ver" id="verTag">1.1.0 α</div>','<div class="ver" id="verTag">1.1.1 α</div>')

# 2б. теги брифинга: цвет только у угрозы и у эха (модули); механики — нейтральные (V-10); тень потери у корпуса
R('<span class="tag" style="border-color:#8a3a3a;color:#ff8a7a">ОПАСНОСТЬ ','<span class="tag threat">ОПАСНОСТЬ ')
R('<span class="tag" style="border-color:#8a3a3a;color:#ff8a7a">БЕЗ РЕМОНТА</span>','<span class="tag threat">БЕЗ РЕМОНТА</span>')
R('<span class="tag" style="border-color:#5a3a8c;color:var(--violet)">ЭХО</span>','<span class="tag mod">ЭХО</span>')
R('<span class="tag" style="border-color:#3a6a8c;color:#9fd8ff">МАЯКИ АРХИВА СНЕСЕНЫ</span>','<span class="tag">МАЯКИ АРХИВА СНЕСЕНЫ</span>')
R('<span class="tag">НОВАЯ УГРОЗА · ','<span class="tag threat">НОВАЯ УГРОЗА · ')
R('<div class="bar hp"><i id="hpB"></i></div>','<div class="bar hp"><i class="gh" id="hpG"></i><i id="hpB"></i></div>')

# 3. журналы: пустой сектор — одна строка вместо карточки «ЗАПИСЕЙ НЕ НАЙДЕНО»
R('h+=`<div class="jsec">${roman(si+1)} · ${sc.name} <small>','h+=`<div class="jsec${got.length?\'\':\' empty\'}">${roman(si+1)} · ${sc.name} <small>')
R("h+=got.length?got.map(card).join(''):`<div class=\"jr lockd\"><h4>ЗАПИСЕЙ НЕ НАЙДЕНО</h4><p>В секторе ${all.length} ${all.length===1?'сигнал':all.length<5?'сигнала':'сигналов'}.</p></div>`;",
  "h+=got.map(card).join('');")

# 4. пауза: необратимые кнопки — через окно подтверждения на всех устройствах
R("['bRestart','bAbandon','bQuit'].forEach(id=>{const el=$('#'+id),f=el.onclick;el.onclick=confirm2(el,f);});",
  "['bRestart','bAbandon','bQuit'].forEach(id=>{const el=$('#'+id),f=el.onclick;el.onclick=confirmPause(el,f);});")

# 4б. окно подтверждения первым видит клавиши и в главном обработчике (синтетический Esc «Назад» на телефоне приходит прямо в window)
R("addEventListener('keydown',e=>{\n  if(e.target&&e.target.tagName==='INPUT')return;","addEventListener('keydown',e=>{\n  if(cfmKey(e))return;if(e.target&&e.target.tagName==='INPUT')return;")

# 5. версия и хроника
R("const VER_TAG='1.1.0 α';","const VER_TAG='1.1.1 α';")
R("toast('ЧТО НОВОГО · '+VER_TAG,'Интерфейс стал тише: меньше цифр и служебных надписей. Число корпуса осталось.');",
  "toast('ЧТО НОВОГО · '+VER_TAG,'Новый облик меню и окон: плотные экраны, крупнее текст, подтверждение перед выходом из миссии.');")
R('<dl class="kv"><dt>1.1.0 α</dt>','<dl class="kv"><dt>1.1.1 α</dt><dd>«Стекло». Новый облик меню и окон: экраны плотные — игра не просвечивает сквозь текст; единые кнопки, вкладки, переключатели и карточки; текст не мельче 12 пикселей; брифинг в две колонки; пауза разделена на «продолжить» и «выйти», а выход из миссии спрашивает подтверждение; уведомления сверху по центру с полоской времени; стрелки ходят по кнопкам меню; при «ЭФФЕКТЫ: МЕНЬШЕ» оболочка не анимируется.</dd><dt>1.1.0 α</dt>')

# 6. поведение оболочки
js=open(os.path.join(D,'m25.js'),encoding='utf8').read()
i=s.rindex('</script>')
s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s)
print('m25 ok')
