# ---------- 78 · A-23: исправление замирания снега/дождя + защита интерполяции от исключений ----------
PRE78="""/* ▼▼▼ ARCH·78 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.18 α · исправление A-23)
   1) Снег и дождь мира (G.w.snow, G.w.rain) двигает сама отрисовка (w58Screen), а не шаг игры. A-23 возвращала им после
      рисования значения шага, и на 90–144 Гц осадки стояли. Перепись отрисовки (стенд rcensus78: 13 сценариев, компьютер и телефон)
      нашла только эти два списка, поэтому они исключены из A-23 точечно. Других изменений в работе интерполяции нет.
   2) Ошибка внутри интерполяции больше не может остановить цикл или оставить объекты в промежуточном положении: всё уже
      сдвинутое возвращается на точные значения, A-23 выключается до перезагрузки, причина пишется в ARCH.d78 и в консоль. */
IP76SKIP.add('snow');IP76SKIP.add('rain');IP76.rp=0;
ARCH.d78={fail:0,where:'',msg:''};
function ip78Off(where,e){ARCH.vi=false;IP76.act=false;IP76.ok=0;ARCH.d78.fail++;ARCH.d78.where=where;ARCH.d78.msg=String(e&&e.message||e).slice(0,200);
  try{console.warn('ARCH·78: интерполяция A-23 выключена до перезагрузки ('+where+')',e);}catch(_){}}
function ip78Back(n){const C=IP76.B;for(let i=Math.min(n,C.n)-1;i>=0;i--){try{const o=C.o[i];if(!o)continue;o.x=IP76.rx[i];o.y=IP76.ry[i];const a=IP76.ra[i];if(a===a)o.ang=a;}catch(e){}}CX=IP76.rcx;CY=IP76.rcy;}
function ip78Apply(dt0){IP76.rp=0;IP76.rcx=CX;IP76.rcy=CY;try{return ip76Apply(dt0);}catch(e){ip78Back(IP76.rp);ip78Off('перед отрисовкой',e);return false;}}
function ip78Restore(){try{ip76Restore();}catch(e){ip78Back(IP76.rn);ip78Off('после отрисовки',e);}}
function ip78Post(){try{ip76Post();}catch(e){ip78Off('запись после шага',e);}}
"""+END%78
S78=[
 ("IP76.rx[i]=ox;IP76.ry[i]=oy;IP76.ra[i]=typeof oa==='number'?oa:NaN;\n",
  "IP76.rx[i]=ox;IP76.ry[i]=oy;IP76.ra[i]=typeof oa==='number'?oa:NaN;IP76.rp=i+1;/* ARCH·78 */\n"),
 ("step74();if(ARCH.vi&&IP76.act)ip76Post();",
  "step74();if(ARCH.vi&&IP76.act)ip78Post();"),
 ("const ip76=ARCH.vi&&ip76Apply(dt0);/* ARCH·76 A-23 */",
  "const ip76=ARCH.vi&&ip78Apply(dt0);/* ARCH·76 A-23 · ARCH·78 защита */"),
 ("if(ip76)ip76Restore();/* ARCH·76 A-23 */",
  "if(ip76)ip78Restore();/* ARCH·76 A-23 · ARCH·78 защита */"),
]
STAGES[78]=dict(vf='1.5.17 α',vt='1.5.18 α',J='m78_journal.txt',pre=PRE78,after=77,sites=S78)
