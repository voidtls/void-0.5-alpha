# K9 · совместимость сохранений 1.5.11 ↔ 1.5.13 (A-20): середина цепочки идёт через сам frame() с виртуальными часами (один профиль браузера, общий localStorage file://)
import asyncio,json,sys
from h import *
D=SP
import os
OLD='file://'+D+'frozen/void_1511_55daefa4.html';NEW='file://'+D+os.environ.get('K9NEW','void_c153.html')
SNAP="""()=>{const o={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);o[k]=localStorage.getItem(k);}return o;}"""
STATE="""()=>{const S=G.save;return S?{v:S.v,wv:S.wv,cleared:S.cleared,lom:S.lom,carry:S.carry,cycle:S.cycle,medals:Object.keys(S.medals||{}).length,lvl:S.pilot&&S.pilot.lvl,perks:JSON.stringify(S.perks),skins:JSON.stringify(S.skins),
  run:JSON.stringify(S.run),story:S.story?JSON.stringify(S.story).length:0,keys:Object.keys(S).sort().join(','),ver:VER_TAG,state:G.state}:{none:1,ver:VER_TAG,state:G.state};}"""
async def seq(b,mid):
    ctx=await b.new_context(viewport={'width':1280,'height':760});await ctx.add_init_script('window.__alpha=true;window.requestAnimationFrame=()=>0;Date.now=()=>1794480000000;')
    pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    await pg.goto(OLD);await pg.wait_for_timeout(400);await pg.evaluate("()=>localStorage.clear()");await pg.reload();await pg.wait_for_timeout(400)
    await pg.evaluate("""()=>{Math.random=mulberry(5);localStorage.removeItem('void_world');startWorld(true);if(G.prologue)prologueEnd();const S=G.save;S.tut.off=1;S.cleared=12;for(let k=1;k<=12;k++)S.medals[k]={clear:1};S.lom=345;S.carry=12;
      S.pilot.lvl=7;S.perks={hull:2};S.skins=['base'];for(let i=0;i<600;i++)worldUpdate(1/60);saveWorld();}""")
    A=await pg.evaluate(STATE);LA=await pg.evaluate(SNAP)
    await pg.goto(mid);await pg.wait_for_timeout(800)
    B=await pg.evaluate(STATE)
    await pg.evaluate("()=>{Math.random=mulberry(6);startWorld();if(G.prologue)prologueEnd();{let t=50000;performance.now=()=>t;last=t;for(let i=0;i<300;i++){t+=1000/60;frame(t);}}saveWorld();}");B2=await pg.evaluate(STATE);LB=await pg.evaluate(SNAP)
    await pg.goto(OLD);await pg.wait_for_timeout(800)
    C=await pg.evaluate(STATE);LC=await pg.evaluate(SNAP)
    await ctx.close()
    def st(x):return {k:v for k,v in x.items() if k not in ('ver',)}
    return dict(A=st(A),B=st(B),B2=st(B2),C=st(C),LA=LA,LB={k:v for k,v in LB.items() if k!='void_ver_seen'},LC={k:v for k,v in LC.items() if k!='void_ver_seen'},keysB=sorted(LB),errs=errs,ver=(A['ver'],B['ver'],C['ver']))
async def main():
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
        K=await seq(b,OLD);N=await seq(b,NEW);await b.close()
    chk={'загрузка в середине цепочки (1.5.13 против контроля 1.5.11)':N['B']==K['B'],
         'состояние после игры и сохранения в 1.5.13 = в 1.5.11':N['B2']==K['B2'],
         'обратная загрузка в 1.5.11 = контроль':N['C']==K['C'],
         'содержимое хранилища после сохранения в 1.5.13 = в 1.5.11 (без void_ver_seen)':N['LB']==K['LB'],
         'содержимое хранилища после возврата = контроль':N['LC']==K['LC'],
         'ошибок страницы нет':not N['errs'] and not K['errs']}
    import json as _j
    def ap(x,y):
        if isinstance(x,str) and isinstance(y,str):
            try:return ap(_j.loads(x),_j.loads(y))
            except Exception:return x==y
        if isinstance(x,bool) or isinstance(y,bool):return x==y
        if isinstance(x,(int,float)) and isinstance(y,(int,float)):return abs(x-y)<=1e-9*max(1,abs(x),abs(y))
        if isinstance(x,dict) and isinstance(y,dict):return set(x)==set(y) and all(ap(x[k],y[k]) for k in x)
        if isinstance(x,list) and isinstance(y,list):return len(x)==len(y) and all(ap(u,v) for u,v in zip(x,y))
        return x==y
    chk['то же с допуском 1e-9 на дробные числа: состояние после игры']=ap(N['B2'],K['B2'])
    chk['то же с допуском: обратная загрузка']=ap(N['C'],K['C'])
    chk['то же с допуском: хранилище после сохранения (ключи и структура совпадают)']=ap(N['LB'],K['LB'])
    chk['то же с допуском: хранилище после возврата']=ap(N['LC'],K['LC'])
    for k,v in chk.items():print(('OK  ' if v else 'FAIL')+' '+k)
    print('версии:',N['ver'],'ключи нового:',N['keysB'],'контроль:',sorted(K['LB'].keys()))
    if not all(chk.values()):
        for k in ['B','B2','C']:
            if N[k]!=K[k]:print(k,{x:(K[k].get(x),N[k].get(x)) for x in set(K[k])|set(N[k]) if K[k].get(x)!=N[k].get(x)})
        for k in ['LB','LC']:
            for x in set(K[k])|set(N[k]):
                if K[k].get(x)!=N[k].get(x):
                    import json as js
                    try:
                        a=js.loads(K[k].get(x) or '{}');c=js.loads(N[k].get(x) or '{}');print(k,x,{f:(str(a.get(f))[:80],str(c.get(f))[:80]) for f in set(a)|set(c) if a.get(f)!=c.get(f)})
                    except Exception as e:print(k,x,'raw differs')
asyncio.run(main())
