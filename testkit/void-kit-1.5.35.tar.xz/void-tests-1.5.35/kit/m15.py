# 0.8.0 · часть 15: сектора VII «Предел» и VIII «Исток»
import sys
SP='@@KIT@@/'
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m15: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
D80=open(SP+'d80.js',encoding='utf8').read();B80=open(SP+'b80.js',encoding='utf8').read()
R('(function genMissions(){',D80+'\n(function genMissions(){')
R('// ---------- Главный цикл ----------',B80+'\n// ---------- Главный цикл ----------')
# ИИ, урон, гибель, снаряды
R("function s74Update0(e,dt,c){const p=G.player,{ux,uy,d,sm,T,pd}=c,pdx=p.x-e.x,pdy=p.y-e.y;","function s74Update0(e,dt,c){const p=G.player,{ux,uy,d,sm,T,pd}=c,pdx=p.x-e.x,pdy=p.y-e.y;if(G.world&&(e.alarm80||e.convoy80||e.audit80)&&s80Pre(e,dt))return true;if(S80T.has(e.type))return s80Update(e,dt,c);")
R("e.type!=='lastkind'&&e.type!=='linkor'&&!e.retreat&&G.latch74!==e)edge74(e,dt)","e.type!=='lastkind'&&e.type!=='linkor'&&e.type!=='pilgrim'&&!e.retreat&&G.latch74!==e)edge74(e,dt)")
R("function s74Hurt(e,dmg,src){","function s74Hurt(e,dmg,src){if(S80T.has(e.type))return s80Hurt(e,dmg,src);",2)
R("s74Killed(e,silent);s75Killed(e,silent);","s74Killed(e,silent);s75Killed(e,silent);s80Killed(e,silent);")
R("function kill(e,silent){\n  if(!e.alive)return;if(e.rebuilt)silent=true;","function kill(e,silent){\n  if(!e.alive)return;if(e.rebuilt)silent=true;if(e.type==='loop'&&!silent&&loopIntercept80(e))return;")
R("function b74Hit(b){if(!G.world&&!inMission())return false;","function b74Hit(b){if(!G.world&&!inMission())return false;if(b80Hit(b))return true;",2)
R("X_.spores=X_.spores.filter(s=>Math.hypot(s.x-p.x,s.y-p.y)>R+s.r*.5);}","X_.spores=X_.spores.filter(s=>Math.hypot(s.x-p.x,s.y-p.y)>R+s.r*.5);pulse80(p,R);}")
# тики
R("secReset();computeStats();t74Init(M);","secReset();computeStats();t74Init(M);t80Init(M);")
R("updatePlayer(dt);t75Tick(dt);secTick(dt);","updatePlayer(dt);t75Tick(dt);t80Tick(dt);secTick(dt);")
R("secTick(dt);secWorldTick(dt);w74WorldTick(dt);updateZones(dt);","secTick(dt);secWorldTick(dt);w74WorldTick(dt);w80WorldTick(dt);updateZones(dt);")
# отрисовка миссии
R("  if(inMission())d74Under(t);\n","  if(inMission())d74Under(t);\n  if(inMission())d80Under(t);\n")
R("secDraw(t);secDraw2(t);if(inMission())d74Draw(t);","secDraw(t);secDraw2(t);if(inMission())d74Draw(t);if(inMission())d80Draw(t);")
R("  if(G.dark){drawDark(G.arena?sx-CX:sx,G.arena?sy-CY:sy);","  if(inMission())w80Mask(G.arena?sx-CX:sx,G.arena?sy-CY:sy);\n  if(G.dark){drawDark(G.arena?sx-CX:sx,G.arena?sy-CY:sy);")
# отрисовка мира
R("storyDrawWorld(t);w58Draw(t);w74Draw(t);d74Under(t);","storyDrawWorld(t);w58Draw(t);w74Draw(t);d74Under(t);w80Draw(t);d80Under(t);")
R("  w58DrawTop(t);w74DrawTop(t);\n","  w58DrawTop(t);w74DrawTop(t);d80Draw(t);w80Mask(sx-CX,sy-CY);\n")
R("w58MapAdd(add,lod,S);w74MapAdd(add,lod,S);","w58MapAdd(add,lod,S);w74MapAdd(add,lod,S);w80MapAdd(add,lod,S);")
R("if(w58MapIcon(g,kind,o,t)||w74MapIcon(g,kind,o,t)){","if(w58MapIcon(g,kind,o,t)||w74MapIcon(g,kind,o,t)||w80MapIcon(g,kind,o,t)){")
R("function drawE74(e,t,icon,col,face,alpha,P){const r=e.r;","function drawE74(e,t,icon,col,face,alpha,P){const r=e.r;if(drawE80(e,t,icon,col,face,alpha,P))return;")
# патрули
R("function w74ZoneSpawn(z){","function w74ZoneSpawn(z){if(z.k80)return w80ZoneSpawn(z);")
R("function w74ZoneDone(z){","function w74ZoneDone(z){if(z.k80)return w80ZoneDone(z);")
R("function w74ZoneRadio(z){","function w74ZoneRadio(z){if(z.k80)return w80ZoneRadio(z);")
R("const rk=z.k74?'radioZ'+z.k74:z.sec===2?'radioZ3':'radioZ4';if(!ws[rk]){ws[rk]=1;if(z.k74)w74ZoneRadio(z);else radioLine(",
  "const rk=z.k80?'radioZ'+z.k80:z.k74?'radioZ'+z.k74:z.z80g?'radioZg'+z.sec:z.sec===2?'radioZ3':'radioZ4';if(!ws[rk]){ws[rk]=1;if(z.k74)w74ZoneRadio(z);else if(z.z80g)w80ZoneRadio(z);else radioLine(")
R("const mul=z.sec===2?1.5:2;","const mul=z.sec>=6?3:z.sec===2?1.5:2;")
# темнота: автоприцел видит рядом
R("  if(G.dark&&!visibleAt(e.x,e.y)&&!(e.reveal>0))return false;\n","  if(G.dark&&!visibleAt(e.x,e.y)&&!(e.reveal>0))return false;\n  if(G.bo80>=.5&&(G.world||inMission())&&G.player&&!(e.reveal>0)&&Math.hypot(e.x-G.player.x,e.y-G.player.y)>380)return false;\n")
# Инспектор: +20% урона по кораблю
R("  if(inMission())d*=curDiff().dmg||1;\n","  if(inMission())d*=curDiff().dmg||1;\n  if(G.insp80>0&&(G.world||inMission()))d*=1.2;\n")
# Изнанка: инверсия движения, мягкий режим
R("  const l=Math.hypot(x,y);if(l>1){x/=l;y/=l;}return[x,y];\n}","  const l=Math.hypot(x,y);if(l>1){x/=l;y/=l;}const k80=inputK80();return[x*k80,y*k80];\n}")
R("(G.box74c?.85:1));}","(G.box74c?.85:1)*(G.slow80>0?.5:1));}")
R("function toMenu(){unlockArena();","function toMenu(){unlockArena();G.inv80=0;G.slow80=0;G.bo80=0;G.insp80=0;G.stamp80=null;document.body.classList.remove('stamp80');G.res80=null;if(typeof W80!=='undefined'){W80.alarm=null;W80.dummy=null;W80.rlog=[];for(const q of W80.pults)q.ch=0;}")
R("haptics:true,","haptics:true,softInv:false,")
R("${togHTML('radio','ПЕРЕХВАТЫ · радиоэфир')}","${togHTML('radio','ПЕРЕХВАТЫ · радиоэфир')}${togHTML('softInv','МЯГКАЯ ИЗНАНКА · ЗАМЕДЛЕНИЕ ВМЕСТО ИНВЕРСИИ')}")
# утечка охлаждения
R("    b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;\n","    {const k_=leakK80(b.x,b.y);b.x+=b.vx*dt*k_;b.y+=b.vy*dt*k_;b.life-=dt*k_;}\n")
R("const k=A&&A.a.kind==='coldcore'&&Math.hypot(b.x-A.a.x,b.y-A.a.y)<420?.5:1;","const k=(A&&A.a.kind==='coldcore'&&Math.hypot(b.x-A.a.x,b.y-A.a.y)<420?.5:1)*leakK80(b.x,b.y);")
# мишень и мирные не мешают крейсерской скорости и музыке
R("const hostile=G.enemies.some(e=>e.alive&&e.type!=='mine'&&e.type!=='lock'&&Math.hypot(e.x-p.x,e.y-p.y)<750);","const hostile=G.enemies.some(e=>e.alive&&e.type!=='mine'&&e.type!=='lock'&&e.type!=='rangedummy'&&!e.peace&&Math.hypot(e.x-p.x,e.y-p.y)<750);")
R("const hostile=G.enemies.some(e=>e.alive&&e.type!=='mine'&&e.type!=='lock'&&Math.hypot(e.x-p.x,e.y-p.y)<900);","const hostile=G.enemies.some(e=>e.alive&&e.type!=='mine'&&e.type!=='lock'&&e.type!=='rangedummy'&&!e.peace&&Math.hypot(e.x-p.x,e.y-p.y)<900);")
# кодекс
R("act===1?'АКТ I · ПУТЬ К СТРАЖУ':act===2?'АКТ II · МАЯК':'СЕКТОРА III–IV · АРХИВ И ХРОНИКИ'","act===1?'АКТ I · ПУТЬ К СТРАЖУ':act===2?'АКТ II · МАЯК':act===4?'СЕКТОРА VII–VIII · ПРЕДЕЛ И ИСТОК':'СЕКТОРА III–VI · АРХИВ, ХРОНИКИ, КОЛЫБЕЛИ, ФЛОТ'")
# музыка
R("  return {id,I,calm,semi,ext,low,duck,lp};","  return mus80({id,I,calm,semi,ext,low,duck,lp});")
R("    musSwitch(T.id,fade,T.semi);}","    musSwitch(T.id,fade80(cur,T.id,fade),T.semi);}")
R("if(S.swarm&&st%2===0&&Math.random()<.5)evNoise(t,.12,.012,P.L.fx,'bandpass',rnd(900,2400),6);","if(S.swarm&&st%2===0&&Math.random()<.5)evNoise(t,.12,.012,P.L.fx,'bandpass',rnd(900,2400),6);\n  step80(P,t,st,bar);")
R("P.L.pulse.gain.value=0;P.L.toms.gain.value=0;","scape80(P,c,t);P.L.pulse.gain.value=0;P.L.toms.gain.value=0;")
# виньетка секторов
R("SS.mercy?'rgba(120,135,160,.2)':","SS.mercy?'rgba(120,135,160,.2)':SS.bureau?`rgba(232,210,122,${.1+.05*(G.bo80||0)})`:SS.source?`rgba(107,140,255,${.12+.03*Math.sin(G.t*TAU/3)})`:")
# контракты
R("ev:'patrolLeader',n:[2,2],after:11,sec:3}","""ev:'patrolLeader',n:[2,2],after:11,sec:3},
  {id:'c_convoy80',s:'VII · Списание отменено',t:()=>'Разбить контейнер конвоя «Утилизация»',ev:'convoyBreak',n:[1,1],after:28,sec:6},
  {id:'c_rescue80',s:'VII · Без номера',t:n=>`Спасти ${n} ${n===1?'копию':'копии'} с переплавки`,ev:'rescue80',n:[1,2],after:28,sec:6},
  {id:'c_audit80',s:'VII · Вне ревизии',t:()=>'Пройти мимо Ревизии незамеченным и разбить её',ev:'auditStealth',n:[1,1],after:28,sec:6},
  {id:'c_recycler80',s:'VII · Вторсырьё',t:n=>`Уничтожить ${n} Утилизатора с полным бункером (от 8)`,ev:'recyclerFull',n:[2,3],after:30,sec:6},
  {id:'c_stamp80',s:'VII · Без подписи',t:n=>`Сбросить ${n} штампов Печати`,ev:'stampOff',n:[3,5],after:29,sec:6},
  {id:'c_alarm80',s:'VII · Всем постам',t:n=>`Уничтожить ${n} врагов у пульта во время тревоги`,ev:'alarmKill',n:[8,12],after:28,sec:6,alive:()=>{const w=w80S();return w.alarmAt.some(a=>a-(w.clk||0)<600);}},
  {id:'c_range80',s:'VII · Выше нормы',t:()=>`Набрать на стенде ${rangeGoal80()} урона в секунду`,ev:'rangeDps',n:[1,1],after:28,sec:6},
  {id:'c_dark80',s:'VII–VIII · Без света',t:n=>`Уничтожить ${n} врагов в темноте`,ev:'darkKill',n:[10,15],after:28,sec:6},
  {id:'c_pilgrims80',s:'VIII · Попутчики',t:()=>'Проводить Паломников, не задев ни одного',ev:'pilgrimsSafe',n:[1,1],after:32,sec:7},
  {id:'c_loop80',s:'VIII · Конец петли',t:n=>`Разорвать ${n} Петель с первого возвращения`,ev:'loopBreak',n:[3,5],after:33,sec:7},
  {id:'c_echo80',s:'VIII · Тишина в ответ',t:n=>`Уничтожить ${n} ${n===1?'Отзвука':'Отзвуков'}, не получив своих же снарядов`,ev:'echoClean',n:[1,2],after:32,sec:7},
  {id:'c_inverse80',s:'VIII · Лицевая сторона',t:()=>'Уничтожить Изнанку до её первой волны',ev:'inverseFast',n:[1,1],after:34,sec:7}""")
R("(T.sec===3?2:T.sec===2?1.5:1)","(T.sec>=6?3:T.sec===3?2:T.sec===2?1.5:1)")
# сохранение
R("  if(S.w74!==undefined){","  if(S.w80!==undefined){const w=S.w80=obj(S.w80);w.clk=num(w.clk,0,0,1e9);w.alarmAt=arr(w.alarmAt).slice(0,3).map(v=>num(v,0,0,1e9));while(w.alarmAt.length<3)w.alarmAt.push(0);w.rangeBest=num(w.rangeBest,0,0,1e6,true);if(w.rangeGoal!==undefined)w.rangeGoal=num(w.rangeGoal,60,0,1e6,true);w.seen=obj(w.seen);w.zd=obj(w.zd);w.voices=num(w.voices,0,0,12,true);if(w.karr!==undefined)w.karr=1;}\n  if(S.w74!==undefined){")
R("if(st.lastKind!==undefined)st.lastKind=num(st.lastKind,0,0,1e4,true);","if(st.lastKind!==undefined)st.lastKind=num(st.lastKind,0,0,1e4,true);if(st.pilgrimsKilled!==undefined)st.pilgrimsKilled=num(st.pilgrimsKilled,0,0,1e6,true);")
# телефон: кнопка рывка пульсирует, пока висит штамп
R("</style>","/* 0.8.0: штамп Печати — кнопка рывка пульсирует */\n.stamp80 #tDash{animation:st80 .45s infinite alternate}@keyframes st80{from{box-shadow:0 0 0 0 rgba(255,122,61,0)}to{box-shadow:0 0 0 9px rgba(255,122,61,.6)}}\n</style>",1)
# версия и хроника
R('<div class="eyebrow">АЛЬФА 0.7.5 · ВСЕ ЦЕЛИ ВИДНЫ</div>','<div class="eyebrow">АЛЬФА 0.8.0 · ПРЕДЕЛ И ИСТОК</div>')
R("<dl class=\"kv\"><dt>0.7.5 α</dt>","<dl class=\"kv\"><dt>0.8.0 α</dt><dd>«Предел и Исток». Сектор VII «Предел» (миссии 28–30, комната босса 31 — в доработке): брошенные цеха бюро, где собирали копии VØID. Новые враги: Лаборант (чинит раненых лучом), Брак (каждые 3 с меняет поведение), Конвейерный щит (ловит обычные снаряды на рельсе), Печать (штамп с взрывом через 4 с — сбросьте рывком), Инспектор (конус скана: 0,8 с в нём — враги бьют на 20% сильнее), Утилизатор (собирает лом и опыт павших и стреляет ими в вас). Сектор VIII «Исток» (миссии 32–37, комната босса 38 — в доработке): Отзвук (возвращает ваши выстрелы любым оружием через секунду), Петля (возвращается через 5 с — добейте за 2 с), Изнанка (редкая, волна зеркалит управление на 2 с), Паломники (мирные копии — не стреляйте). В открытом мире — отключения света по циклу сектора, утечки охлаждения (снаряды втрое медленнее), пульты тревоги (срабатывают через 10 с, перезарядка 20–30 мин), стенд испытаний с мишенью и цифрами урона (автоприцел бьёт по ней), патрули «Утилизация», «Ревизия», «Паломники» и ещё четыре, 12 новых контрактов, «Голоса Истока». Своя музыка секторов с плавной сменой: механический ритм бюро и хор Истока, тёмные варианты при отключении света. В настройках — «мягкая Изнанка».</dd><dt>0.7.5 α</dt>")
open(P,'w',encoding='utf8').write(s)
print('m15 ok')
