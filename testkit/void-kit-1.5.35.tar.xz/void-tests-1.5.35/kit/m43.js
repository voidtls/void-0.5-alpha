/* ===== 1.2.6 α: записанная музыка меню, миссий 1–10 и боссов; общая пауза −90 % ===== */
/* MZ_DEF вставляется сборкой из au/seg2/manifest.json: {key:{segs:[[name,dur],…],intro:n,loop:n}} */
const MZ_TR={
  menu:{name:'Последний сигнал',gain:.47,root:39,penta:[554.37,622.25,739.99,830.61,932.33]},
  m10: {name:'Вахта',gain:.52,root:41,penta:[523.25,622.25,698.46,830.61,932.33]},
  s0:  {name:'Страж-0',gain:.55,root:41,penta:[523.25,622.25,698.46,830.61,932.33]},
  s10: {name:'Глушитель',gain:.58,root:36,penta:[523.25,622.25,698.46,783.99,932.33]}};
const MZ={pl:{},bus:null,lp:null,duck:null,want:null,prev:null,pre:.1,tail:.25,xf:.02,fail:0,bossDeadT:-99,lastBoss:false,menuIntro:false,anyLive:false};
for(const k in MZ_DEF)Object.assign(MZ_TR[k],MZ_DEF[k]);
function mzRaw(n){const el=document.getElementById('mz-'+n);return el?el.textContent.trim():'';}
function mzP(k){return MZ.pl[k]||(MZ.pl[k]={k,buf:{},dec:{},cur:null,nxt:null,pos:null,gen:0,on:false,fade:null,lvlG:null,fail:0,lvl:1});}
function mzNodes(){if(MZ.bus||!AU.ctx)return MZ.bus;const c=AU.ctx;
  MZ.bus=c.createGain();MZ.lp=c.createBiquadFilter();MZ.lp.type='lowpass';MZ.lp.frequency.value=18000;MZ.lp.Q.value=.5;MZ.duck=c.createGain();
  MZ.bus.connect(MZ.lp);MZ.lp.connect(MZ.duck);MZ.duck.connect(AU.amb);return MZ.bus;}
function mzPlayerNodes(P){if(P.fade)return;const c=AU.ctx;mzNodes();P.fade=c.createGain();P.fade.gain.value=0;P.lvlG=c.createGain();P.lvlG.gain.value=1;P.fade.connect(P.lvlG);P.lvlG.connect(MZ.bus);}
function mzDecode(P,i){const T=MZ_TR[P.k],n=T.segs[i][0];if(P.buf[i])return Promise.resolve(P.buf[i]);if(P.dec[i])return P.dec[i];
  const b64=mzRaw(n);if(!b64||!AU.ctx)return Promise.reject(new Error('no '+n));
  const bin=atob(b64),u=new Uint8Array(bin.length);for(let j=0;j<bin.length;j++)u[j]=bin.charCodeAt(j);
  const p=new Promise((res,rej)=>{try{const r=AU.ctx.decodeAudioData(u.buffer,res,rej);if(r&&r.then)r.then(res,rej);}catch(e){rej(e);}})
    .then(b=>{P.buf[i]=b;delete P.dec[i];return b;}).catch(e=>{delete P.dec[i];P.fail++;MZ.fail++;throw e;});
  P.dec[i]=p;return p;}
function mzNext(P,i){const T=MZ_TR[P.k];return i+1<T.segs.length?i+1:T.intro;}
function mzKeep(P){const keep=new Set();if(P.cur){keep.add(P.cur.i);keep.add(mzNext(P,P.cur.i));}if(P.nxt)keep.add(P.nxt.i);for(const k in P.buf)if(!keep.has(+k))delete P.buf[k];}
function mzStart(P,i,off){const c=AU.ctx,b=P.buf[i];if(!b)return false;mzPlayerNodes(P);const when=c.currentTime+.05;
  const s=c.createBufferSource();s.buffer=b;const g=c.createGain();s.connect(g);g.connect(P.fade);s.start(when,MZ.pre+off);P.cur={i,src:s,g,t0:when-off,d:MZ_TR[P.k].segs[i][1]};return true;}
function mzChain(P){const c=AU.ctx,C=P.cur;if(!C)return;const now=c.currentTime,end=C.t0+C.d,ni=mzNext(P,C.i);
  if(!P.nxt&&end-now<8&&!P.buf[ni])mzDecode(P,ni).catch(()=>{});
  if(!P.nxt&&end-now<2){const b=P.buf[ni];
    if(b){const s=c.createBufferSource();s.buffer=b;const g=c.createGain();g.gain.setValueAtTime(0,end-MZ.xf/2);g.gain.linearRampToValueAtTime(1,end+MZ.xf/2);s.connect(g);g.connect(P.fade);
      s.start(end-MZ.xf/2,MZ.pre-MZ.xf/2);C.g.gain.setValueAtTime(1,end-MZ.xf/2);C.g.gain.linearRampToValueAtTime(0,end+MZ.xf/2);try{C.src.stop(end+MZ.tail);}catch(e){}
      P.nxt={i:ni,src:s,g,t0:end,d:MZ_TR[P.k].segs[ni][1]};}
    else if(now>end-.05){try{C.g.gain.setTargetAtTime(0,end,.08);C.src.stop(end+MZ.tail);}catch(e){}P.cur=null;const gen=P.gen;
      mzDecode(P,ni).then(()=>{if(P.on&&!P.cur&&gen===P.gen)mzStart(P,ni,0);}).catch(()=>{});return;}}
  if(P.nxt&&now>=P.nxt.t0){P.cur=P.nxt;P.nxt=null;mzKeep(P);}}
/* плавные равномощные кривые: из текущего значения, без щелчков */
function mzCurve(param,to,dur){const c=AU.ctx,t=c.currentTime+.01,v=param.value,N=64,a=new Float32Array(N);
  for(let j=0;j<N;j++){const x=j/(N-1);a[j]=to>v?v+(to-v)*Math.sin(x*Math.PI/2):to+(v-to)*Math.cos(x*Math.PI/2);}
  param.cancelScheduledValues(t-.01);param.setValueAtTime(v,t-.005);try{param.setValueCurveAtTime(a,t,Math.max(.05,dur));}catch(e){param.setTargetAtTime(to,t,dur/3);}}
function mzOn(P,i,off,fi){P.on=true;const gen=++P.gen;mzDecode(P,i).then(()=>{if(!P.on||gen!==P.gen)return;if(!P.cur)mzStart(P,i,off);mzCurve(P.fade.gain,1,fi);}).catch(()=>{});}
function mzOff(P,fo){if(!P.on)return;P.on=false;P.gen++;const c=AU.ctx;const C=P.cur;
  if(C){P.pos={i:C.i,off:clamp(c.currentTime-C.t0,0,C.d-.01),t:performance.now()};}
  if(P.fade){mzCurve(P.fade.gain,0,fo);const stopAt=c.currentTime+fo+.1;for(const X of [P.cur,P.nxt])if(X)try{X.src.stop(stopAt);}catch(e){}}P.cur=P.nxt=null;}
/* что должно звучать */
function mzWant(){if(!SET.amb||!AU.ctx||MZ.fail>6)return null;const st=G.state;
  if(G.mode!=='endless'&&!G.world&&G.m>=1&&G.m<=10&&!G.post&&(G.mode==='world'||G.mode==='dev')&&['intro','play','levelup','pause','codex'].includes(st)){
    const bossOn=G.m===6&&G.boss&&G.boss.alive,jamOn=G.m===10&&G.jam&&G.jam.alive;
    if(st==='intro')MZ.lastBoss=false;
    if(bossOn||jamOn){MZ.lastBoss=G.m===6?'s0':'s10';MZ.since=0;}
    /* после гибели босса трек держится ещё 3 с — финальный удар не обрывается */
    if(MZ.lastBoss&&MZ.since<3&&MZ.lastBoss===(G.m===6?'s0':G.m===10?'s10':''))return MZ.lastBoss;
    return 'm10';}
  MZ.lastBoss=false;
  let id=null;try{id=musTarget().id;}catch(e){}
  if(id==='menu'&&!G.world&&!(G.m&&['play','levelup','intro'].includes(st)))return 'menu';
  return null;}
const MZ_FADE={'m10>s0':[2.5,2],'m10>s10':[2.5,2],'s0>m10':[4,4],'s10>m10':[4,4],'menu>m10':[2,3],'m10>menu':[2.5,3.5],'s0>menu':[2.5,3.5],'s10>menu':[2.5,3.5],'>menu':[0,3.5],'menu>':[3,0],'m10>':[3,0],'s0>':[3,0],'s10>':[3,0],'>m10':[0,3]};
function mzEntry(k){const P=mzP(k),T=MZ_TR[k],pos=P.pos;
  if(k==='menu'){if(pos&&performance.now()-pos.t<120000)return {i:pos.i,off:pos.off};if(!MZ.menuIntro){MZ.menuIntro=true;return {i:0,off:0};}return {i:T.intro,off:0};}
  if(k==='m10'&&MZ.prev&&MZ.prev[0]==='s'&&pos&&performance.now()-pos.t<60000)return {i:pos.i,off:pos.off};
  return {i:0,off:0};}
function mzTick(dt){if(!AU.ctx||AU.ctx.state!=='running')return;{const now=performance.now();if(G.state==='play'&&MZ.lastNow)MZ.since=(MZ.since||0)+Math.min(.25,(now-MZ.lastNow)/1000);MZ.lastNow=now;}let w=mzWant();
  /* конец миссии и гибель: музыка уходит плавно, стингеры звучат сами */
  const ending=w&&!G.world&&(G.state==='done'||G.state==='over');if(ending)w=null;
  if(w!==MZ.want){const from=MZ.want||'',to=w||'',f=MZ_FADE[from+'>'+to]||[3,3.5];
    if(from)mzOff(mzP(from),G.state==='over'?2.5:G.state==='done'?4:f[0]);
    if(to){const E=mzEntry(to);mzOn(mzP(to),E.i,E.off,f[1]);}
    MZ.prev=MZ.want;MZ.want=w;}
  let any=false;for(const k in MZ.pl){const P=MZ.pl[k];if(P.on&&P.cur)mzChain(P);if(P.on||P.cur||P.nxt)any=any||!!P.cur;}
  MZ.anyLive=!!(MZ.want&&mzP(MZ.want).cur);
  if(MZ.bus){const t=AU.ctx.currentTime;
    /* уровень по состоянию: брифинг −3 дБ, выбор улучшения −5 дБ и глуше */
    for(const k in MZ.pl){const P=MZ.pl[k];if(!P.lvlG)continue;let db=0;if(G.state==='intro')db=-3;else if(G.state==='levelup')db=-5;
      const g=MZ_TR[k].gain*(G.ff==='phone'?1.12:1)*Math.pow(10,db/20);if(Math.abs(g-P.lvl)>.002){P.lvl=g;P.lvlG.gain.setTargetAtTime(g,t,.6);}}
    let lp=AU.musLP?AU.musLP.frequency.value:18000;if(G.state==='levelup')lp=Math.min(lp,2600);if(G.state==='over')lp=Math.min(lp,350);
    if(Math.abs(lp-(MZ.lpv||0))>30){MZ.lpv=lp;MZ.lp.frequency.setTargetAtTime(lp,t,G.state==='over'?.8:.25);}
    const dk=AU.duckG?AU.duckG.gain.value:1;if(Math.abs(dk-(MZ.dk||1))>.01){MZ.dk=dk;MZ.duck.gain.setTargetAtTime(dk,t,.05);}}
  /* процедурная музыка молчит, пока звучит запись */
  if(AU.mus){const tg=MZ.anyLive?0:1;if(tg!==MZ.musT){MZ.musT=tg;AU.mus.gain.setTargetAtTime(tg,AU.ctx.currentTime,tg?1.0:.6);}}
  if(MZ.anyLive)MUS.lastName=MZ_TR[MZ.want].name;}
/* стингеры и звук убийства — в тональности звучащего трека */
{const _as=ambSting;ambSting=function(kind){const P=MUS.cur;if(MZ.anyLive&&P){const T=MZ_TR[MZ.want],s0=P.semi;let d=((T.root-P.sc.root)%12+12)%12;if(d>6)d-=12;P.semi=d;try{return _as(kind);}finally{P.semi=s0;}}return _as(kind);};}
function mzPenta(){const src=MZ.anyLive?MZ_TR[MZ.want].penta:(typeof V12!=='undefined'&&V12.live?PENTA_F:PENTA0);if(PENTA[0]!==src[0]||PENTA[1]!==src[1]||PENTA[2]!==src[2])PENTA.splice(0,5,...src);}
/* пауза: вся музыка плавно −90 % (≈ −20 дБ), обратно — быстрее */
function pauseMusTick(){if(!AU.ctx||!AU.amb)return;
  if(!AU.pauseG){try{const c=AU.ctx;AU.pauseG=c.createGain();AU.pauseG.gain.value=1;AU.pauseG.connect(c.destination);AU.amb.connect(AU.pauseG);AU.amb.disconnect(c.destination);}catch(e){}}const p=G.state==='pause',t=AU.ctx.currentTime;if(p!==MZ.paused){MZ.paused=p;const g=AU.pauseG.gain;g.cancelScheduledValues(t);g.setValueAtTime(g.value,t);g.setTargetAtTime(p?.1:1,t,p?.9:.3);}}
{const _mt2=musicTick;musicTick=function(dt){_mt2(dt);try{mzTick(dt);mzPenta();pauseMusTick();}catch(e){console.error(e);}};}
