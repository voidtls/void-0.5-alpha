# 0.9.9 R3: хаос-прогоны босса 50 — случайные события поверх бота: пауза, карта, справочник и настройки из паузы, рывки dt, эффекты,
# поворот/размер окна, гибель, выход в меню и новый заход, перезагрузка мира, прыжки по стадиям, дикий ввод, выбор у кнопки
import asyncio,json,sys,os,random
from h import *
from h120 import H120
from bots120 import ZBOT
src=open(SP+'q74.py').read();HELP=src[src.index('HELP="""')+8:src.index('"""',src.index('HELP="""')+8)]
FL="{cradle22:'keep',fleet27:'engine',line31:'write',well38:'answer'}"
SETUP=r"""()=>{window.CH120={
  inv(){const bad=[],Z=G.zb,p=G.player;const st=G.state;if(!['world','levelup','pause','map','codex','set','menu','settings'].includes(st))bad.push('state:'+st);
    if(p&&(!isFinite(p.x)||!isFinite(p.y)||!isFinite(p.hp)))bad.push('pNaN');
    const zbE=G.enemies.filter(e=>e.alive&&(e.zb||e.zbEsc)).length;
    if(!Z||Z.k==='idle'){if(zbE)bad.push('zbEnemiesWithoutFight:'+zbE);return bad;}
    if(Z.save!==G.save)return bad;
    for(const k of ['t','T','hp','segMax','shrink','beatT','out','outT','vig','flash']){if(!isFinite(Z[k]))bad.push('ZNaN:'+k);}
    if(Z.seg.some(v=>!(v>=-.001&&v<=1.001)))bad.push('seg:'+Z.seg.map(v=>+v.toFixed(2)).join(','));
    if(Z.hp>Z.segMax+1)bad.push('hpOver');if(!(Z.stage>=0&&Z.stage<=4))bad.push('stage:'+Z.stage);for(const k of ['count','stg','stun','cool','stance','wind','lunge','novaT']){if(!isFinite(Z[k]))bad.push('ZNaN:'+k);}
    if(Z.stg<0||Z.stg>100.001)bad.push('stg:'+Z.stg);if(Z.boss&&Z.boss.alive){const m=zbMult(Z,Z.boss);if(!(m>=0&&m<=3.0001))bad.push('mult:'+m);if(!isFinite(Z.boss.x)||!isFinite(Z.boss.y))bad.push('bossNaN');if(Z.boss.contact&&Z.lunge<=0)bad.push('contactIdle:'+Z.boss.contact);}
    if(Z.hands&&Z.hands.a.some(a=>!isFinite(a)))bad.push('handNaN');if((Z.mines||[]).length>6)bad.push('mines:'+Z.mines.length);if((Z.frags||[]).length>6)bad.push('frags:'+Z.frags.length);if(Z.clones.filter(e=>e.alive).length>2)bad.push('clones:'+Z.clones.length);
    if(Z.sing&&(!isFinite(Z.sing.x)||Z.sing.t>3.6))bad.push('sing');{const ec=G.enemies.filter(e=>e.alive&&e.zbEsc).length;if(ec>zbEchoCap()+1)bad.push('echo:'+ec);}if((Z.sats||[]).length>2)bad.push('sats:'+Z.sats.length);if((Z.fx||[]).length>90)bad.push('fx:'+Z.fx.length);if(Z.chain<0||Z.chain>2)bad.push('chain:'+Z.chain);if(Z.chainLock&&!(Z.lunge>0)&&!(G.wtg95||[]).some(o=>o.nm==='tridash'))bad.push('chainStuck');if((Z.sats||[]).some(s=>!isFinite(s.x)))bad.push('satNaN');if(Z.neg&&!['norm','tg','neg','back'].includes(Z.neg.m))bad.push('neg:'+Z.neg.m);if(Z.stage!==3&&Z.neg&&Z.neg.m!=='norm')bad.push('negLeak');
    if(!['silence','walls','expand','pick','spawn','fight','seg','race','choice','end'].includes(Z.k))bad.push('k:'+Z.k);
    const S=Z.shape;if(!isFinite(S.s)||!isFinite(S.c.x)||!isFinite(S.c.y)||!isFinite(S.morph))bad.push('shapeNaN');
    if(Z.k==='fight'||Z.k==='race'||Z.k==='seg'){const b=zbBox();if(p&&(p.x<b[0]-3||p.x>b[2]+3||p.y<b[1]-3||p.y>b[3]+3)&&!(Z.leaveT>0)){CH120.outN=(CH120.outN||0)+1;if(CH120.outN>=3)bad.push('pOutNoLeave');}else CH120.outN=0;
      const P=zbPoly(Z);for(const q of P)if(q[0]<b[0]-3||q[0]>b[2]+3||q[1]<b[1]-3||q[1]>b[3]+3){const S=Z.shape,c=zbCen(Z);bad.push('polyOut:'+[Z.stage,S.kind,S.prev&&S.prev.kind,+S.morph.toFixed(2),Math.round(c.x-b[0]),Math.round(b[2]-c.x),Math.round(c.y-b[1]),Math.round(b[3]-c.y),Math.round(S.s*Z.shrink),Math.round(q[0]-b[0]),Math.round(b[2]-q[0]),Math.round(q[1]-b[1]),Math.round(b[3]-q[1])].join('/'));break;}
      if(!Z.boss||!Z.boss.alive)bad.push('noBoss');{const cl=G.enemies.filter(e=>e.alive&&e.zb===2).length;if(cl>2)bad.push('copies:'+cl);if(cl&&Z.stage!==1&&Z.stage!==4)bad.push('copiesStage:'+Z.stage);}
      if(Z.k==='fight'&&Z.shape.s*Z.shrink<ZB_FLOOR-1&&!Z.shape.prev&&!Z.shape.next)bad.push('radius:'+Math.round(Z.shape.s));if(zbBossTg()>zbDiffK().budget+2&&!(G.t-(CH120.atkT||-99)<4))bad.push('tg:'+zbBossTg());
      if(G.enemies.filter(e=>e.alive).length>40)bad.push('alive:'+G.enemies.filter(e=>e.alive).length);
      if(Z.nShape>200)bad.push('nShape');if(Z.shrink<.39||Z.shrink>1.001)bad.push('shrink:'+Z.shrink);}
    if(Z.k==='choice'&&G.state==='levelup'&&pickMode!=='zbChoice')bad.push('choicePick');
    return bad;},
  ev(e,out){const p=G.player,Z=G.zb;out.ev.push(e);
    switch(e){
      case 'pause':if(G.state==='world'){pause();for(let k=0;k<2;k++)renderWorld(performance.now());resume();}break;
      case 'map':if(G.state==='world'){openMap('map');drawMap();const q=(G.mapPts||[])[0];if(q)mapJumpAt(q.px,q.py);closeMap();}break;
      case 'codex':if(G.state==='world'){pause();openCodex('pause');renderCodex&&renderCodex();closeCodex();if(G.state==='pause')resume();}break;
      case 'settings':if(G.state==='world'){pause();openSettings('pause');closeSettings();if(G.state==='pause')resume();}break;
      case 'spike':for(let k=0;k<3&&G.state==='world';k++)worldUpdate(.25);break;
      case 'fx':SET.fx=!SET.fx;break;
      case 'lowfx':G.lowFx=!G.lowFx;break;
      case 'lessfx':SET.lessFx=!SET.lessFx;break;
      case 'resize':{const w=[1280,844,390,1024][Math.random()*4|0],h=[760,390,844,768][Math.random()*4|0];try{resizeTo&&0;}catch(_){ }if(typeof applyWH==='function'){W=w;H=h;VW=w;VH=h;applyWH();}break;}
      case 'die':if(p&&G.state==='world'&&Z&&Z.k==='fight'){p.inv=0;p.shieldUp=false;p.hp=1;damagePlayer(9999);for(let k=0;k<120&&G.state==='world';k++)worldUpdate(1/60);}break;
      case 'menu':{toMenu();const m=[];if(document.getElementById('x90G')&&!document.getElementById('x90G').hidden)m.push('menu:x90G');out.bad.push(...m);T.zWorld({flags:"""+FL+"""});T.zgo();T.ztick(9);let n=0;while(G.zb&&G.zb.k!=='fight'&&n++<40)T.ztick(.5);CH120.nres++;break;}
      case 'reload':{saveWorld();startWorld(false);if(G.prologue)prologueEnd();$('#toast').hidden=true;const n=WORLD.nodes[49];T.zpos(n.x,n.y+100);T.wtick(.3);T.zgo();T.ztick(9);let k=0;while(G.zb&&G.zb.k!=='fight'&&k++<40)T.ztick(.5);CH120.nres++;break;}
      case 'stage':if(Z&&(Z.k==='fight'||Z.k==='race')){T.zstage(1+(Math.random()*4|0));}break;
      case 'segdone':if(Z&&Z.k==='fight'&&Z.stage<4){zbSegDone(Z);}break;
      case 'race':if(Z&&Z.k==='fight'&&Z.stage===4){Z.hp=Z.segMax*.15;}break;
      case 'cycle':if(Z&&Z.k==='race'){const n=zbNode();Z.boss.x=n.x+10;Z.boss.y=n.y;}break;
      case 'win':if(Z&&Z.k==='race'){const n=zbNode();Z.boss.x=n.x+900;T.zpos(n.x+5,n.y);}break;
      case 'pulse':if(p){p.en=100;tryPulse();}break;
      case 'dash':for(let k=0;k<3;k++){tryDash([Math.random()-.5,Math.random()-.5]);if(G.state==='world')worldUpdate(1/60);}break;
      case 'wild':CH120.wild=!CH120.wild;break;
      case 'tele':if(Z&&Z.k==='fight'){const b=zbBox();T.zpos(rnd(b[0]-200,b[2]+200),rnd(b[1]-200,b[3]+200));}break;
      case 'kill':for(const q of G.enemies)if(q.alive&&q.zbEsc){q.hp=0;kill(q);}break;
      case 'ram':if(Z&&Z.k==='fight'&&Z.boss){Z.ramCd=0;T.zpos(Z.boss.x+Z.boss.r,Z.boss.y);p.dashT=.15;G.dashId++;}break;
      case 'zero':if(Z&&Z.k==='fight'&&Z.stage===2){Z.count=.01;}break;
      case 'stun':if(Z&&Z.k==='fight'){Z.stgLock=0;zbStg(Z,100);}break;
      case 'neg':if(Z&&Z.k==='fight'&&Z.stage===3){Z.neg={m:'norm',t:7.95};}break;
      case 'clones':if(Z&&Z.k==='fight'&&(Z.stage===1||Z.stage===4)){Z.cloneDone=0;Z.hp=Math.min(Z.hp,Z.segMax*.45);}break;
      case 'mines':if(Z&&Z.k==='fight'){for(let k=0;k<3;k++)zbAtk(Z,'mines');}break;
      case 'sing':if(Z&&Z.k==='fight'){zbSingStart(Z);}break;
      case 'breath':if(Z&&Z.k==='fight'){zbNextShape(Z);Z.shape.tg=.05;}break;
      case 'atk':if(Z&&Z.k==='fight'&&Z.boss){CH120.atkT=G.t;for(const k of ['dashfan','star','burst','beam','repeat'])zbAtk(Z,k);}break;
      case 'r4':if(Z&&Z.k==='fight'&&Z.boss){CH120.atkT=G.t;for(const k of ['tridash','blink','grid'])zbAtk(Z,k);}break;
      case 'echo':if(Z&&Z.k==='fight'){zbEchoWave(Z,5);}break;
      case 'leave':if(Z&&Z.k!=='idle'&&Z.k!=='end'&&Z.k!=='choice'&&G.state==='world'){const b=zbBox();T.zpos(b[2]+500,(b[1]+b[3])/2);worldUpdate(1/60);if(G.zb&&G.zb.k!=='idle'&&p.x>b[2]+1)out.bad.push('wallLeak');}break;
      case 'rage':if(Z&&Z.k==='fight'){Z.hp=Math.min(Z.hp,Z.segMax*.25);}break;
      case 'burst':for(let i=0;i<12;i++)G.pb.push({x:p.x,y:p.y,px:p.x,py:p.y,vx:rnd(-900,900),vy:rnd(-900,900),dmg:1,pierce:0,rico:0,life:.7,hit:[]});break;}},
  nres:0,wild:false};return 1;}"""
RUN=r"""(o)=>{const out={ev:[],bad:[],err:null,frames:0};const evs=(o.ev||[]).map(e=>({e,at:Math.random()*o.n|0}));const p=G.player;let s=0;
  const bot=__BOT__;
  try{for(let i=0;i<o.n;i++){for(const q of evs)if(q.at===i)CH120.ev(q.e,out);
      if(G.state==='levelup'){if(pickMode==='zbChoice'){zbChoose(Math.random()<.5?0:1);}else choose(Math.random()*choices.length|0);}
      if(G.state==='world'){if(G.zb&&G.zb.k==='idle'&&!(G.zbCool>G.t)){const n=WORLD.nodes[49];T.zpos(n.x,n.y+100);worldUpdate(1/60);T.zgo();}
        if(!G.zb&&!(G.zbCool>G.t)){const n=WORLD.nodes[49];T.zpos(n.x,n.y+100);worldUpdate(1/60);T.zgo();}
        if(CH120.wild){const b=zbBox();steer2(rnd(b[0],b[2]),rnd(b[1],b[3]));if(Math.random()<.02)tryDash();worldUpdate(1/60);}
        else{bot({maxSec:1/60,floor:0});}}
      else if(G.state!=='world'){/* пауза/меню — пропускаем кадр */}
      if(i%15===0){const b=CH120.inv();if(b.length){for(const x of b)if(!out.bad.includes(x))out.bad.push(x);}}
      out.frames++;}}
  catch(e){out.err=String(e.stack||e).slice(0,400);}
  for(const k of KK)KEYS[k]=false;out.k=G.zb?G.zb.k:'none';out.stage=G.zb?G.zb.stage:0;out.st=G.state;out.nres=CH120.nres;return out;}"""
# бот на один кадр: ZBOT с maxSec 1/60 делает ровно один шаг
BOT1=ZBOT.replace("while(s<60*o.maxSec){","while(s<Math.max(1,Math.round(60*o.maxSec))){")
EVS=['pause','map','codex','settings','spike','fx','lowfx','lessfx','resize','die','menu','reload','stage','segdone','race','cycle','win','pulse','dash','wild','tele','kill','ram','zero','stun','neg','clones','mines','sing','breath','atk','burst','r4','echo','leave','rage']
async def t(b):
    P=await newpage(b);await P.js(HELP);await P.js(H120);await P.js(SETUP)
    random.seed(int(os.environ.get('SEED','7')))
    N=int(os.environ.get('N','40'));bugs=0
    await P.js("()=>{T.zstart({diff:'mid',flags:"+FL+"});return 1;}")
    for i in range(N):
        ev=random.sample(EVS,random.randint(2,6))
        d=random.choice(['easy','mid','hard'])
        await P.js("(d)=>{if(!G.zb||G.zb.k==='idle'){G.save.diff=d;}return 1;}",d)
        r=await P.js(RUN.replace('__BOT__',BOT1),{'n':random.randint(600,2400),'ev':ev})
        bad=r['bad'];err=r['err'];pe=P.errs[:3];P.errs.clear()
        flag='BUG' if (bad or err or pe) else 'ok '
        if bad or err or pe:bugs+=1
        print('%s run%02d %s n=%d ev=%s k=%s stage=%s st=%s bad=%s err=%s pe=%s'%(flag,i,d,r['frames'],','.join(ev),r['k'],r['stage'],r['st'],bad,err,pe),flush=True)
    print('BUGS',bugs,'of',N)
    rec('chaos120',bugs==0,{'bugs':bugs,'N':N})
asyncio.run(run([('chaos120',t)],'chaos120.json'))
