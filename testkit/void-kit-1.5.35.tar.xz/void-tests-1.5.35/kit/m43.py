# 1.2.6 α · записанная музыка меню/миссий/боссов, пауза −90 %
import json,sys
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m43 FAIL',n,a[:80]);sys.exit(1)
    s=s.replace(a,b)
man=json.load(open(D+'au/seg2/manifest.json'))
md={k:{'segs':[[x[0],x[1]] for x in v['segs']],'intro':v['intro'],'loop':v['loop']} for k,v in man.items()}
js='const MZ_DEF='+json.dumps(md,ensure_ascii=False)+';\n'+open(D+'m43.js',encoding='utf8').read()
# у Пустоты-12 пауза теперь общая: свою −8 дБ оставляем только карте и журналам
R("if(['map','pause','codex'].includes(G.state)){db-=8;lp=Math.min(lp,900);}","if(['map','codex'].includes(G.state)){db-=8;lp=Math.min(lp,900);}")
# плавнее: стоп подложки по равномощной кривой
R("N.g.gain.cancelScheduledValues(t);N.g.gain.setValueAtTime(N.g.gain.value,t);N.g.gain.linearRampToValueAtTime(0,t+fade);","{const v=N.g.gain.value,K=48,a=new Float32Array(K);for(let j=0;j<K;j++)a[j]=v*Math.cos(j/(K-1)*Math.PI/2);N.g.gain.cancelScheduledValues(t);N.g.gain.setValueAtTime(v,t);try{N.g.gain.setValueCurveAtTime(a,t+.005,Math.max(.05,fade));}catch(e){N.g.gain.linearRampToValueAtTime(0,t+fade);}}")
R("const AMB_CFG={fadeCalm:3.5,fadeFight:1.5,fadeOut:5,","const AMB_CFG={fadeCalm:4,fadeFight:2,fadeOut:6,")
i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m43 ok')
