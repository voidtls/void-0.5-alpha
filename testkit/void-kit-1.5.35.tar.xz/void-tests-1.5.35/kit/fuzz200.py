# 100 итераций хаос-прогона всей игры: случайные цепочки действий + инварианты после каждого шага
import asyncio,json,sys,random,time
from playwright.async_api import async_playwright
SP='@@KIT@@/'
GAME='file://@@KIT@@/home/void.html'
LIB=open(SP+'lib.js').read()
HELP=r"""()=>{window.F={
 real(){return JSON.stringify([localStorage.getItem('void_world'),localStorage.getItem('void_record'),localStorage.getItem('void_endless')]);},
 inv(){const S=G.save;const p=G.player;if(p&&(!Number.isFinite(p.x)||!Number.isFinite(p.y)||!Number.isFinite(p.hp)))return 'nanP';
   if(S){for(const k of ['lom','carry','cleared','cycle'])if(!Number.isFinite(+S[k]))return 'nan:'+k;if(S.lom<0)return 'neglom';}
   const vis=[...document.querySelectorAll('section.screen')].filter(e=>!e.hidden).map(e=>e.id);if(vis.length>1)return 'screens:'+vis.join(',');
   const map={menu:'sMenu',codex:'sCodex',intro:'sIntro',levelup:'sLevel',done:'sDone',pause:'sPause',over:'sOver',map:'sMap',shop:'sShop',save:'sSave',dev:'sDev',hangar:'sHangar',cycle:'sCycle',report:'sReport'};
   const want=map[G.state];if(want&&!(vis.length===1&&vis[0]===want))return 'screenMismatch:'+G.state+'/'+vis.join(',');
   if((G.state==='world'||G.state==='play')&&vis.length)return 'screenOverPlay:'+G.state+'/'+vis.join(',');
   if(window.DEVW&&DEVW.on()&&G.save&&G.save!==null&&G.mode==='world'&&saveKey()!=='void_devworld')return 'key';
   if(window.DEVW&&DEVW.stats().warn.length)return 'warn:'+DEVW.stats().warn[0];
   return 'ok';},
 openNodes(){return WORLD.nodes.filter(n=>nodeState(n.m)!=='locked').map(n=>n.m);},
 step(n){for(let i=0;i<n;i++){if(G.state==='world')worldUpdate(1/60);else if(G.state==='play')update(1/60);else if(G.state==='levelup'){let k=0;while(G.state==='levelup'&&k++<10)choose(Math.random()*choices.length|0);}else break;}},
};}"""
# действия: (имя, вес, js)
A=[
 ('sandboxEnter',6,"()=>{if(G.prologue)prologueEnd();toMenu();openDev();DEVW.enter();}"),
 ('sandboxExitEsc',4,"async()=>{if(!(DEVW.on()&&G.state==='world'))return 'skip';pause();}"),
 ('menu',4,"()=>{toMenu();}"),
 ('stripBack',3,"()=>{if(G.state!=='menu')return 'skip';const b=document.getElementById('dwBack');if(!b||b.offsetParent===null)return 'skip';b.click();}"),
 ('stripOff',2,"()=>{if(G.state!=='menu')return 'skip';const b=document.getElementById('dwOff');if(!b||b.offsetParent===null)return 'skip';b.click();}"),
 ('realWorld',5,"()=>{toMenu();startWorld(false);if(G.prologue)prologueEnd();}"),
 ('fly',8,"()=>{if(G.state!=='world')return 'skip';G.dev.wspeed=[.5,1,2,4,8][Math.random()*5|0];const k=KK[Math.random()*4|0];KEYS[k]=true;F.step(60+(Math.random()*240|0));KEYS[k]=false;G.dev.wspeed=1;}"),
 ('panelJump',4,"()=>{if(!(DEVW.on()&&G.state==='world'))return 'skip';DEVW.panel(true);const s=document.getElementById('dwNode');s.value=Math.random()*50|0;document.querySelector('#dwPanel [data-dw=node]').click();DEVW.panel(false);}"),
 ('panelMisc',4,"()=>{if(!(DEVW.on()&&G.state==='world'))return 'skip';DEVW.panel(true);const bs=[...document.querySelectorAll('#dwPanel [data-dw]')].filter(b=>b.dataset.dw!=='exit');bs[Math.random()*bs.length|0].click();}"),
 ('mission',8,"()=>{if(G.state!=='world')return 'skip';const o=F.openNodes();if(!o.length)return 'skip';const m=o[Math.random()*o.length|0];enterNode(m,Math.random()<.15);if(G.state==='intro')startMission();let k=0;while(G.state==='levelup'&&k++<40)choose(0);F.step(60*(5+Math.random()*40|0));return 'm'+m;}"),
 ('win',5,"()=>{if(G.state!=='play')return 'skip';missionComplete();}"),
 ('lose',4,"()=>{if(G.state!=='play')return 'skip';const p=G.player;G.dev.god=false;let n=0;while(G.state==='play'&&n++<400){p.inv=0;p.dashT=0;p.shieldUp=false;damagePlayer(9999);update(1/60);}}"),
 ('abandon',3,"()=>{if(G.state!=='play')return 'skip';pause();const b=$('#bAbandon');if(b.hidden)return 'skip';b.click();}"),
 ('nextBtn',3,"()=>{if(G.state==='done')$('#bNext').click();else if(G.state==='over')$(Math.random()<.5?'#bToWorld':'#bRetry').click();else return 'skip';}"),
 ('waitAuto',4,"WAIT"),
 ('map',3,"()=>{if(G.state!=='world')return 'skip';openMap();mapZoom(1.4);mapTab(Math.random()<.5?'jr':'map');closeMap();}"),
 ('shop',3,"()=>{if(G.state!=='world')return 'skip';const s=WORLD.shops[Math.random()*2|0];if(!s||!revealedAt(s.x,s.y)&&!DEVW.on())return 'skip';enterWorldAt(s.x,s.y+100);openShop(s);const b=[...document.querySelectorAll('#shopPerks [data-perk]')].find(b=>!b.disabled);if(b)b.click();closeShop();}"),
 ('hangar',2,"()=>{if(G.state!=='world')return 'skip';const h=WORLD.hangar;enterWorldAt(h.x,h.y+100);openHangar();const b=document.querySelector('#skinGrid [data-buy]:not([disabled]),#skinGrid [data-pick]');if(b)b.click();closeHangar();}"),
 ('codex',2,"()=>{const from=G.state==='pause'?'pause':'menu';if(from==='menu')toMenu();openCodex(from);const t=document.querySelectorAll('#cxTabs .tab');t[Math.random()*t.length|0].click();closeCodex();}"),
 ('abyss',2,"()=>{if(G.state!=='world'||!G.save.gate)return 'skip';const a=WORLD.abyss;enterWorldAt(a.x,a.y+150);enterAbyss();F.step(60*10);}"),
 ('endlessOverBack',2,"()=>{if(G.mode!=='endless'||G.state!=='play')return 'skip';const p=G.player;let n=0;G.dev.god=false;while(G.state==='play'&&n++<400){p.inv=0;p.dashT=0;p.shieldUp=false;damagePlayer(9999);update(1/60);}const b=$('#bToWorld');if(!b.hidden)b.click();else toMenu();}"),
 ('cycle',2,"()=>{if(G.state!=='world')return 'skip';G.save.cleared=10;openReport();const b=$('#bRepGo');if(b)b.click();if(G.prologue)prologueEnd();}"),
 ('reload',3,"RELOAD"),
 ('devMission',3,"()=>{toMenu();openDev();devStart(1+(Math.random()*50|0));startMission();let k=0;while(G.state==='levelup'&&k++<40)choose(0);for(const a of ['lom','plvl','kill','lvl','boss','charge']){if(Math.random()<.4)devAct(a);}F.step(120);}"),
 ('endlessDev',1,"()=>{toMenu();openDev();startEndless(true,1+(Math.random()*10|0));F.step(300);}"),
 ('saveScreen',1,"()=>{toMenu();openSaveScreen();toMenu();}"),
 ('keys',5,"KEYS"),
 ('worldDeath',2,"()=>{if(G.state!=='world')return 'skip';const p=G.player;p.inv=0;G.dev.god=false;damagePlayer(9999);for(let i=0;i<60*3;i++)worldUpdate(1/60);}"),
  ('w58dev',4,"()=>{if(G.state!=='world'||!G.w)return 'skip';W58DEV(['storm','tug','wander','pack'][Math.random()*4|0]);F.step(60*(5+Math.random()*20|0));}"),
 ('alphaJump',4,"()=>{if(G.state!=='world'||typeof alphaJump!=='function')return 'skip';openMap('map');drawMap();const L=['∞','01','05','09','12','14','17','18','25','50'];alphaJump(L[Math.random()*L.length|0]);if(G.state==='map')closeMap();F.step(60);}"),
 ('anom',3,"()=>{if(G.state!=='world'||G.anom)return 'skip';const a=WORLD.anomalies[Math.random()*WORLD.anomalies.length|0];if(!a)return 'skip';enterWorldAt(a.x-100,a.y);try{startAnom(a);}catch(e){return 'skip';}F.step(60*(3+Math.random()*30|0));}"),
 ('conv',2,"()=>{if(G.state!=='world'||G.anom||typeof w58ConvStart!=='function'||!W58.depot)return 'skip';enterWorldAt(W58.depot.x,W58.depot.y);w58ConvStart();F.step(60*(5+Math.random()*30|0));}"),
 ('buyPerk',2,"()=>{if(G.state!=='world')return 'skip';G.save.lom+=400;openShop(WORLD.shops[0]);const bs=[...document.querySelectorAll('#shopPerks button[data-perk]:not([disabled])')];if(bs.length)bs[Math.random()*bs.length|0].click();closeShop();}"),
 ('badCode',2,"()=>{toMenu();openSaveScreen();const S=JSON.parse(JSON.stringify(G.save||newSave()));const ks=['lom','carry','cleared','cycle','pilot','contracts','w58','perks','skins','pos'];const k=ks[Math.random()*ks.length|0];S[k]=[null,'x',-5,1e300,[],{}][Math.random()*6|0];$('#saveIn').value=btoa(unescape(encodeURIComponent(JSON.stringify(S))));$('#bSaveLoad').click();toMenu();startWorld(false);if(G.prologue)prologueEnd();F.step(30);}"),
 ('pauseResume',3,"()=>{if(G.state!=='world'&&G.state!=='play')return 'skip';pause();F.step(5);resume();F.step(5);}"),
 ('rift',2,"()=>{if(G.state!=='world')return 'skip';const b=WORLD.sectors[Math.random()*11|0].box;G.player.x=b[0]+300;G.player.y=b[3]+600;camSnap();F.step(240);}"),
]
W=[a[1] for a in A]
KEYPOOL=['Escape','Escape','Enter','Space','KeyM','KeyJ','KeyP','KeyF','KeyR','Backquote','BracketLeft','BracketRight','Digit1','KeyA','KeyE','Tab']
async def iteration(b,it):
    rnd=random.Random(it*7919+13)
    ctx=await b.new_context(viewport={'width':1280,'height':760});pg=await ctx.new_page();errs=[]
    pg.on('pageerror',lambda e:errs.append('PAGE '+str(e)[:240]))
    pg.on('console',lambda m:(m.type=='error' and 'ERR_TUNNEL' not in m.text and 'Failed to load' not in m.text) and errs.append('CON '+m.text[:240]))
    await pg.goto(GAME);await pg.wait_for_timeout(200)
    async def prep():
        await pg.evaluate(LIB);await pg.evaluate(HELP)
    await pg.evaluate("()=>localStorage.clear()");await pg.reload();await pg.wait_for_timeout(200);await prep()
    # настоящая игра с прогрессом
    await pg.evaluate("(c)=>{startWorld(true);if(G.prologue)prologueEnd();const S=G.save;S.cleared=c;S.lom=333;S.medals[1]={clear:1};saveWorld();REC.best=42;saveRec();toMenu();}",rnd.choice([1,4,7,10]))
    prevDev=False;viol=[];log=[];real=await pg.evaluate("()=>F.real()");sandboxSnap=None
    for step in range(40):
        name,_,js=rnd.choices(A,weights=W)[0]
        try:
            if js=='WAIT':
                await pg.wait_for_timeout(2700);r='w'
            elif js=='RELOAD':
                await pg.reload();await pg.wait_for_timeout(250);await prep();r='r'
            elif js=='KEYS':
                for _ in range(4):await pg.keyboard.press(rnd.choice(KEYPOOL));await pg.wait_for_timeout(30)
                r='k'
            else:
                await pg.evaluate("(s)=>{Math.random=(function(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};})(s);}",it*1000+step)
                r=await pg.evaluate(js)
                if name=='sandboxExitEsc' and r!='skip':
                    await pg.keyboard.press('Escape');await pg.wait_for_timeout(50)
            await pg.wait_for_timeout(20)
            st=await pg.evaluate("()=>[G.state,!!(window.DEVW&&DEVW.on()),!!(window.DEVW&&DEVW.flag()),F.inv(),F.real(),G.mode]")
        except Exception as e:
            viol.append([step,name,'EXC '+str(e)[:200]]);break
        log.append(name+':'+st[0]+(':S' if st[1] else '')+('' if r in (None,'skip') else ''))
        if st[3]!='ok':viol.append([step,name,st[0],st[3]])
        if (st[1] or st[2]) and prevDev:
            # пока режим включён (или флаг стоит) настоящее сохранение не меняется
            if st[4]!=real:viol.append([step,name,'REAL CHANGED while dev',st[0]]);real=st[4]
        else:
            real=st[4]
        prevDev=st[1] or st[2]
        if errs:viol.append([step,name,'ERRS',errs[:2]]);errs.clear()
    await ctx.close()
    return viol,log
async def main():
    n0,n1=int(sys.argv[1]),int(sys.argv[2])
    out={}
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for it in range(n0,n1):
            t0=time.time()
            try:viol,log=await asyncio.wait_for(iteration(b,it),timeout=300)
            except Exception as e:viol,log=[['TIMEOUT/EXC',str(e)[:200]]],[]
            out[it]={'viol':viol,'log':log}
            print('IT',it,'viol',len(viol),round(time.time()-t0,1),'s',json.dumps(viol,ensure_ascii=False)[:600],flush=True)
            for c in list(b.contexts):
                try:await c.close()
                except Exception:pass
        await b.close()
    json.dump(out,open(SP+'fuzz_%d_%d.json'%(n0,n1),'w'),ensure_ascii=False,indent=1)
asyncio.run(main())
