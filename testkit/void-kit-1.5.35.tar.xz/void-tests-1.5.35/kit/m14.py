# 0.7.5 · часть 14: автоприцел (Мембрана, Устье, страховка), Кормилица 2.0, «Последний довод» 2.0
import sys
SP='@@KIT@@/'
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m14: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
B75=open(SP+'b75.js',encoding='utf8').read()
R('// ---------- Главный цикл ----------',B75+'\n// ---------- Главный цикл ----------')
# автоприцел: страховка и точка прицеливания
R("  const tg=man?null:pickTarget();","  let tg=man?null:pickTarget();if(!man){if(tg)G.noTg75=0;else tg=aimFallback(dt);}/* 0.7.5 */")
R("want=tg?Math.atan2(tg.y-p.y,tg.x-p.x):sp>20","want=tg?Math.atan2(aimPt(tg).y-p.y,aimPt(tg).x-p.x):sp>20")
R("let base=ang!==undefined?ang:Math.atan2(tg.y-p.y,tg.x-p.x);","let base;if(ang!==undefined)base=ang;else{const q=aimPt(tg);base=Math.atan2(q.y-p.y,q.x-p.x);}")
# молоко: +20% темп стрельбы на 5 с
R("p.fireT=st.rate*(G.bc&&G.bc.inRing?st.sync:1)*(G.lockGun>0?3:1);","p.fireT=st.rate*(G.bc&&G.bc.inRing?st.sync:1)*(G.lockGun>0?3:1)*(G.milk75>0?.83:1);")
R("p.hp=Math.min(G.st.maxHp,p.hp+h);floater(p.x,p.y-26,'+'+h+' · МОЛОКО'","p.hp=Math.min(G.st.maxHp,p.hp+h);G.milk75=5;floater(p.x,p.y-26,'+'+h+' · МОЛОКО · ТЕМП +20%'")
# корпуса-укрытия считают попадания залпов флагмана
R("for(const h of X.hulls)if(hullIn(h,b.x,b.y,0)){b.life=0;break;}","for(const h of X.hulls)if(hullIn(h,b.x,b.y,0)){b.life=0;if(b.boss&&h.boss75)h.hits=(h.hits||0)+1;break;}")
# автоприцел по боссам V–VI
R("function sbAutoTarget(p){const b=G.sb;if(!b||!b.alive||b.st!=='fight')return null;","function sbAutoTarget(p){const b=G.sb;if(!b||!b.alive||b.st!=='fight')return null;if(b.sbk==='nurse'||b.sbk==='flag')return sb75Auto(p,b);")
# коконы во время боя с Кормилицей вылупляют только Нерождённых (а не гвардию сектора)
R("const pool=!G.world&&G.coPool74&&G.coPool74.length?G.coPool74:","const pool=G.sb&&G.sb.alive&&G.sb.sbk==='nurse'?['unborn']:!G.world&&G.coPool74&&G.coPool74.length?G.coPool74:")
# смерть врага
R("  s74Killed(e,silent);\n","  s74Killed(e,silent);s75Killed(e,silent);\n")
# тик
R("updatePlayer(dt);secTick(dt);","updatePlayer(dt);t75Tick(dt);secTick(dt);")
# фазы: старый баннер заменён в sb74Phase (переопределена)
# версия
R('<div class="eyebrow">АЛЬФА 0.7.4 · КОЛЫБЕЛИ И ФЛОТ</div>','<div class="eyebrow">АЛЬФА 0.7.5 · ВСЕ ЦЕЛИ ВИДНЫ</div>')
R("<dl class=\"kv\"><dt>0.7.4 α</dt>","<dl class=\"kv\"><dt>0.7.5 α</dt><dd>«Все цели видны». Автоприцел (основной режим на телефоне) теперь бьёт Мембрану — в ближайшую точку стены, 35% урона обычным огнём, заряд ×1,5 — и Устье (600 прочности, обычный огонь ранит); Поглотитель выбирается последним и «устаёт» после двух веёров; страховка: если 3 с нет цели при живых врагах, прицел берёт ближайшего. Ренегат с борта получает 45% и подсказывает зайти с носа. <b>Кормилица 2.0</b>: у утроб полоски прочности (обычный огонь рвёт, заряд ×4, «Разрыв» ×2, импульс 40%), тело ранимо всегда (−20% за каждую целую пуповину); кормление нитью — порвите её и Кормилица откроется; плач и молоко (+10% прочности, темп +20%); пуповина может отрасти; во 2-й фазе тело дрейфует, край вспыхивает перед сжатием, на вдохе урон ×1,5, Зародыш рядом с ней вызывает вдох, со стены падают коконы; в 3-й — лепестки, отражающие снаряды, кольца с узким окном и сплошные (рывок), последняя колыбельная на 15%. <b>«Последний довод» 2.0</b>: 12 500 прочности; автоприцел выбивает секции, каждая снимает с рубки 15% брони; полоски секций, видимый ремонт (стреляйте в искры); рубка без батарей отвечает очередями; два корпуса-укрытия; звено на выходе; прожектор и прицельный залп; таран; абордажный шлюз; перекличка мёртвого флота; заряд оглушает рубку; Тео, эхо Стража и доклад «мы живы» помогают; третий удар залпа — полоса. Общее: метка 10% на полосе босса, подсказки в строке босса, финальные доки выше кнопок, предупреждение за 5 с, при повторе — «ВЫ УЖЕ ВЫБРАЛИ».</dd><dt>0.7.4 α</dt>")
open(P,'w',encoding='utf8').write(s)
print('m14 ok')
