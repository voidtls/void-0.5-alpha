# общий раннер тестов 0.5.4
import asyncio,json,sys,time,traceback
from playwright.async_api import async_playwright
SP='@@KIT@@/'
import os
GAME=os.environ.get('GAME_URL','file://@@KIT@@/home/void.html')
LIB=open(SP+'lib.js').read()
RES={}
class Page:
    def __init__(s,pg,errs):s.pg=pg;s.errs=errs
    async def js(s,code,arg=None):
        return await (s.pg.evaluate(code,arg) if arg is not None else s.pg.evaluate(code))
    async def wait(s,ms):await s.pg.wait_for_timeout(ms)
async def newpage(b,vw=1280,vh=760,url=GAME,init=None,touch=False,clear=True,alpha=True,dsf=None):
    ctx=await (b.new_context(viewport={'width':vw,'height':vh},has_touch=touch,is_mobile=touch,device_scale_factor=dsf) if dsf else b.new_context(viewport={'width':vw,'height':vh},has_touch=touch,is_mobile=touch))
    # 1.0.0 α: мир по умолчанию закрыт туманом войны; старые наборы проверяют прежний «всё открыто» (window.__alpha=true до загрузки)
    if alpha and os.environ.get('ALPHA')!='0':await ctx.add_init_script('window.__alpha=true;')
    if init:await ctx.add_init_script(init)
    pg=await ctx.new_page();errs=[]
    pg.on('pageerror',lambda e:errs.append('PAGE '+str(e)[:300]))
    pg.on('console',lambda m:(m.type=='error' and 'ERR_TUNNEL' not in m.text and 'Failed to load resource' not in m.text) and errs.append('CON '+m.text[:300]))
    await pg.goto(url);await pg.wait_for_timeout(250)
    if clear:
        await pg.evaluate("()=>{localStorage.clear();}");await pg.reload();await pg.wait_for_timeout(250)
    await pg.evaluate(LIB)
    await pg.evaluate("""()=>{window.T={
      go(m,echo){enterNode(m,echo);if(G.state==='intro')startMission();let n=0;while(G.state==='levelup'&&n++<40)choose(0);return G.state;},
      fresh(){localStorage.removeItem('void_world');startWorld(true);if(G.prologue)prologueEnd();$('#toast').hidden=true;return G.state;},
      inv(){const S=G.save;if(!S)return 'nosave';for(const k of ['lom','carry','cleared','cycle'])if(!Number.isFinite(+S[k]))return 'nan:'+k;const p=G.player;if(p&&(!Number.isFinite(p.x)||!Number.isFinite(p.y)||!Number.isFinite(p.hp)))return 'nanP';
        const vis=[...document.querySelectorAll('section.screen')].filter(e=>!e.hidden).map(e=>e.id);if(vis.length>1)return 'screens:'+vis.join(',');if(S.lom<0)return 'neglom';return 'ok';},
      bot(o){o=Object.assign({maxSec:1200,floor:40,bcFloor:.6},o||{});const t0=G.taken,m=G.m;let s=0;
        for(;s<60*o.maxSec&&(G.state==='play'||G.state==='levelup'||G.state==='intro');s++){if(G.state==='intro'){startMission();continue;}
          if(G.state==='levelup'){let n=0;while(G.state==='levelup'&&n++<10)choose(Math.random()*choices.length|0);continue;}
          const p=G.player;if(o.floor)p.hp=Math.max(p.hp,o.floor);if(G.bc&&o.bcFloor)G.bc.hp=Math.max(G.bc.hp,G.bc.maxHp*o.bcFloor);
          if(o.full)p.hp=G.st.maxHp;const bc=G.bc,tg=G.boss||G.jam||bc;let tx,ty;
          if(bc&&!G.jam){const cut=G.relays.find(r=>r.cut);if(cut&&(s%1200)<300){tx=(cut.x+bc.x)/2;ty=(cut.y+bc.y)/2;}else{const a=s/90;tx=bc.x+Math.cos(a)*75;ty=bc.y+Math.sin(a)*75;}
            const cell=G.pick.find(k=>k.k==='cell'&&!(k.stab>0));if(cell&&p.cargo<G.st.cargo&&(s%600)<300){tx=cell.x;ty=cell.y;}}
          else{const a=s/90;tx=(tg?tg.x:W/2)+Math.cos(a)*160;ty=(tg?tg.y:H/2)+Math.sin(a)*160;}steer2(tx,ty);if(s%170===0)tryDash();if(p.en>=100)tryPulse();
          if(s%200===0){const t=G.enemies.find(e=>targetable(e)&&['pylon','jam','leech','antenna','decoy'].includes(e.type));if(t)G.prio=t;}
          update(1/60);}
        for(const k of KK)KEYS[k]=false;const B=G.boss;return {m,state:G.state,sec:Math.round(s/60),taken:Math.round(G.taken-t0),lvl:G.lvl,bc:G.bc?Math.round(G.bc.hp/G.bc.maxHp*100):null,boss:B?[B.st,B.phase,Math.round(B.hp),bossShielded(B),G.enemies.filter(e=>e.alive&&e.type==='pylon').length]:null};},
      openAll(){const S=G.save;S.cleared=10;S.gate=true;for(let m=1;m<=50;m++)S.medals[m]=S.medals[m]||{};saveWorld();}
    };}""")
    return Page(pg,errs)
def rec(k,cond,info):
    RES[k]={'ok':bool(cond),'info':info}
    print(('OK   ' if cond else 'FAIL ')+k+' · '+json.dumps(info,ensure_ascii=False)[:400],flush=True)
async def run(tests,out):
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
        for name,fn in tests:
            t0=time.time()
            try:
                await asyncio.wait_for(fn(b),timeout=int(os.environ.get("TMO","600")))
            except Exception as e:
                rec(name,False,'EXC '+str(e)[:400])
            for c in list(b.contexts):
                try:await c.close()
                except Exception:pass
            print('   ⏱',name,round(time.time()-t0,1),'s',flush=True)
        await b.close()
    old={}
    try:old=json.load(open(SP+out))
    except Exception:pass
    old.update(RES);json.dump(old,open(SP+out,'w'),ensure_ascii=False,indent=1)
