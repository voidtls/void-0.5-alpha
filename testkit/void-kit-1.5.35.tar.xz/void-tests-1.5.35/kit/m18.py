# 0.9.5 · часть 18: мега-улучшение секторов IX–X — язык угроз, враги, уровни, боссы 2.0, открытый мир
import sys
SP='@@KIT@@/'
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m18: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
D95=open(SP+'d95.js',encoding='utf8').read()
B95=''.join(open(SP+f,encoding='utf8').read() for f in ['b95a.js','b95b.js','b95c.js','b95d.js','b95e.js','b95f.js','b95g.js'])
R('(function genMissions(){',D95+'\n(function genMissions(){')
R('// ---------- Главный цикл ----------',B95+'\n// ---------- Главный цикл ----------')
# последний шанс и контактный урон только через 0,6 с после появления
R("if(p.hp<=0){p.hp=0;explode(p.x,p.y,'#8fe9ff',60,1.6);","if(p.hp<=0&&!lc95(p)){p.hp=0;explode(p.x,p.y,'#8fe9ff',60,1.6);")
R("else if(p.dashT<=0&&e.contact>0){","else if(p.dashT<=0&&e.contact>0&&!cg95(e)){")
R("  G.enemies.push(e);\n  if(type==='cruiser')","  if(G.x90&&inMission()&&(G.x90.sec===8||G.x90.sec===9))e.cg95=G.t+(e.spawnT||0)+.6;\n  G.enemies.push(e);\n  if(type==='cruiser')")
# свои снаряды (слова, огни, иглы, тельца, чернила, символы) и тёмная обводка 1,5 px в секторах IX–X
R("for(const b of G.eb){if(b.copy){","for(const b of G.eb){if(b.k95){eb95Draw(b,t);continue;}if(b.copy){",2)
R("if(BMIN){ctx.strokeStyle='#04060c';ctx.lineWidth=1/SC;ctx.stroke();}}","if(BMIN||G.ol95){ctx.strokeStyle='#04060c';ctx.lineWidth=(G.ol95?1.5:1)/SC;ctx.stroke();}}",2)
# «Пульс»: усиленный снаряд — с золотым следом (X18)
R("ctx.strokeStyle=b.drone?'#c9b6ff':BC;ctx.lineWidth=3;","ctx.strokeStyle=b.pk90?'#ffd36b':b.drone?'#c9b6ff':BC;ctx.lineWidth=b.pk90?4.5:3;")
# иглы Смотрителя замедляют
R("damagePlayer(b.dmg);if(b.frost)addIce(1);b.life=0;}}","damagePlayer(b.dmg);if(b.frost)addIce(1);if(b.slow95)G.slowP95=Math.max(G.slowP95||0,b.slow95);b.life=0;}}")
# удар «в такт» считается по времени выстрела (X02)
R("hurt(e,b.dmg,{charged:!!b.charged,drone:!!(b.drone||b.turret)});","hurt(e,b.dmg,{charged:!!b.charged,drone:!!(b.drone||b.turret),bt95:b.bt95});")
# окно ✦ у Перерождённых любых типов
R("  if(G.x90&&inMission()){if(G.x90.pud.length)dmg*=pud90K(e);","  if(G.x90&&inMission()){if(G.x90.pud.length)dmg*=pud90K(e);if(e.weak95>0&&!S90T.has(e.type))dmg*=weakK95(e);")
# поры появления и кульминация
R("const e=spawnEnemy(w.type,w.x,w.y,o2);const a=Math.atan2(H/2-w.y,W/2-w.x);e.vx=Math.cos(a)*e.spd;e.vy=Math.sin(a)*e.spd;}","const e=spawnEnemy(w.type,w.x,w.y,o2);const a=Math.atan2(H/2-w.y,W/2-w.x);e.vx=Math.cos(a)*e.spd;e.vy=Math.sin(a)*e.spd;spawned95(e,w);}")
R("function edgeSpawn(type,o={}){\n  const p=G.player;","function edgeSpawn(type,o={}){if(spawn95(type,o))return;\n  const p=G.player;")
R("else if(typeof ty==='string'&&ty.startsWith('mem:'))mem100Spawn(ty.slice(4));else edgeSpawn(ty);","else if(typeof ty==='string'&&ty.startsWith('mem:'))mem100Spawn(ty.slice(4));else if(typeof ty==='string'&&ty.startsWith('e95:'))edgeSpawn(EDEF[ty.slice(4)]?ty.slice(4):'gunner',{e95:1});else edgeSpawn(ty);")
# «Меньше эффектов»: тряска и частицы ×0,5, без хроматики
R("v*=(SET.shake===undefined?1:SET.shake);","v*=(SET.shake===undefined?1:SET.shake)*(SET.lessFx?.5:1);")
R("function part(x,y,vx,vy,life,col,size){if(G.parts.length>=PMAX||(G.lowFx&&Math.random()<.5))return;","function part(x,y,vx,vy,life,col,size){if(G.parts.length>=PMAX||(G.lowFx&&Math.random()<.5)||(SET.lessFx&&Math.random()<.5))return;")
R("shake:1,noErase:false}","shake:1,noErase:false,lessFx:false}")
R("${togHTML('fx','ЭФФЕКТЫ · частицы и тряска')}","${togHTML('fx','ЭФФЕКТЫ · частицы и тряска')}${togHTML('lessFx','МЕНЬШЕ ЭФФЕКТОВ · БЕЗ ХРОМАТИКИ, ТРЯСКА И ЧАСТИЦЫ ×0,5')}")
# мини-карта: патрули, события, безопасные зоны
R("  for(const e of G.enemies){if(!e.alive||e.type==='mine')continue;const [x,y]=P(e.x,e.y);g.fillStyle=e.type==='lock'?'#b48cff':'#ff4f6e';g.fillRect(x-2,y-2,4,4);}","  mini95(g,P,s);\n  for(const e of G.enemies){if(!e.alive||e.type==='mine')continue;const [x,y]=P(e.x,e.y);g.fillStyle=e.type==='lock'?'#b48cff':'#ff4f6e';g.fillRect(x-2,y-2,4,4);}")
# фон секторов IX–X (параллакс) и лёгкий зум сердцебиения в секторе IX
R("  ctx.globalAlpha=1;\n  ctx.setTransform(k,0,0,k,(sx-CX)*k,(sy-CY)*k);\n  if(SET.fx)for(const n of G.decor)","  ctx.globalAlpha=1;\n  wbg95(t,k,sx,sy);{const Z=G.wz95||1;ctx.setTransform(k*Z,0,0,k*Z,((sx-CX)*Z+W/2*(1-Z))*k,((sy-CY)*Z+H/2*(1-Z))*k);}\n  if(SET.fx)for(const n of G.decor)")
# справочник: свой заголовок для IX–X
R("act===4?'СЕКТОРА VII–VIII · ПРЕДЕЛ И ИСТОК'","act===5?'СЕКТОРА IX–X · СЕРДЦЕ КОВЧЕГА И СТЁРТЫЕ БЕРЕГА':act===4?'СЕКТОРА VII–VIII · ПРЕДЕЛ И ИСТОК'")
# справочник: у «фальшивого» врага для иконки есть seed/uid — иначе рисунки с e.seed (Тромб, Лейкоцит…) пусты
R("const fake={type:k,x:0,y:0,vx:1,vy:0,r:d.r,t:1,","const fake={type:k,seed:1,uid:1,x:0,y:0,vx:1,vy:0,r:d.r,t:1,")
# кульминационная элита — всегда одна, на любой сложности
R("const out=[];for(const t in c){const n=Math.max(1,Math.round(c[t]*mul));","const out=[];for(const t in c){const n=String(t).startsWith('e95:')?1:Math.max(1,Math.round(c[t]*mul));")
# X20: «Хардкор» — без множителя 0,85 у боссов 0.9 (взамен атаки чаще на 15%)
R("*cycHp()*(rk85()>=2?.85:1));","*cycHp()*(rk85()>=2&&!XX?.85:1));")
# версия и хроника версий
R('<div class="eyebrow">АЛЬФА 0.9 · СЕРДЦЕ КОВЧЕГА И СТЁРТЫЕ БЕРЕГА</div>','<div class="eyebrow">АЛЬФА 0.9.5 · СЕРДЦЕ И БЕРЕГ 2.0</div>')
R('<dl class="kv"><dt>0.9 α</dt>','<dl class="kv"><dt>0.9.5 α</dt><dd>«Сердце и Берег 2.0» — мега-улучшение секторов IX и X. Единый язык угроз: у каждой атаки есть телеграф не короче 0,45 секунды — линии утолщаются, зоны заливаются от центра, рывки показывают стрелкой, уязвимое окно — белым ромбом ✦. Восемь новых враждебных врагов: Лейкоциты-охотники стаей чертят треугольник, Спазм сжимает ленты кровотока, Тельца-бомбы, Иммунный страж с мембраной, Клякса, Переписчик со строками снарядов, Отливник с языком пустоты и Стёртый пилот, который летает по вашим правилам. Все четырнадцать старых врагов получили вторую атаку и окно уязвимости. У каждой миссии 39–46 своя арена: воронка лент, отсеки, кольцо вокруг ганглия, косы стирания, страница со строками-стенами, диагональный берег; укрытия, которые рушатся от огня; событие арены на третьей волне, передышка с сундуком, кульминация с элитой и тайник. Сердце 2.0: бич аорты, кровяной дождь в такт, толчок, лента тактов, комбо, стреляющие клапаны, фибрилляция, затопление камеры и два запуска. Берег 2.0: Смотритель горизонта с глазами-мишенями, слезами стирания, вздохом и словами-снарядами; маяки стали слабыми, но злыми — лучи-прожекторы, самонаводящиеся огни, перезапись соседа; тени прошлых боссов — мини-боссы, а в тишине Смотритель спускается и прочёсывает арену руками. Открытый мир: патрули Кровотока и Правки, Иммунный ответ, Потерянные, события Аритмия, Тромбоз, Отлив, Опечатка в мире и Последний сигнал, безопасные зоны у станций, фон из сосудов и «недорисованный» берег. Последний шанс, очередь надписей, стрелки угроз за краем экрана, табличка первой встречи с замедлением, настройка «Меньше эффектов». Двадцать исправлений. После сборки — три круга самокритики: враги обходят укрытия и строки-стены, сквозь стену не проскочить ни рывком, ни отбросом, на любой сложности одна элита кульминации, удар обычного врага — не больше 16 единиц, буквы «стёртой подписи» читаются, у Смотрителя настоящие руки, тени прошлых боссов обрели тело, фон мира стал бесшовным, а на телефоне подсказки боя больше не лезут под пальцы.</dd><dt>0.9 α</dt>')
open(P,'w',encoding='utf8').write(s)
print('m18 ok')
