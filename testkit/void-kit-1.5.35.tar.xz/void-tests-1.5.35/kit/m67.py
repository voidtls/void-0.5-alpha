# 1.5.5–1.5.6 α «Небо» — BG·PROTO: небо сектора I (вырезаемый блок) + изоляция ГСЧ старого неба (вне блока)
import sys
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m67 FAIL',n,a[:80]);sys.exit(1)
    s=s.replace(a,b)
R('<div class="ver" id="verTag">1.5.1 α</div>','<div class="ver" id="verTag">1.5.7 α</div>')
R("const VER_TAG='1.5.1 α';","const VER_TAG='1.5.7 α';")
R("upd:'миссии 01–04 стали кинематографичнее: камера, цвет, звук с залом и панорамой; заголовки больше не печатаются по букве.'",
  "upd:'небо первого сектора: Маяк Ядра стоит на месте, а камни заднего плана закрывают его — с затмением и светом по краю.'")
JOUR=open(D+'m67_journal.txt',encoding='utf8').read().strip()
J156=open(D+'m67_journal156.txt',encoding='utf8').read().strip()
J157=open(D+'m67_journal157.txt',encoding='utf8').read().strip()
R('<dl class="kv"><dt>1.5.1 α</dt>','<dl class="kv"><dt>1.5.7 α</dt><dd>'+J157+'</dd><dt>1.5.6 α</dt><dd>'+J156+'</dd><dt>1.5.5 α</dt><dd>'+JOUR+'</dd><dt>1.5.1 α</dt>')
css=open(D+'m67.css',encoding='utf8').read();i=s.find('</style>');s=s[:i]+css+'\n'+s[i:]
js=open(D+'m67.js',encoding='utf8').read();i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m67 ok')
