# 0.9.7 · часть 20: сектор XI «Нулевая точка» (47–49) и сектор XII — заготовка комнаты босса (50)
import sys
SP='@@KIT@@/'
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m20: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
B=open(SP+'b110.js',encoding='utf8').read()
R('// ---------- Главный цикл ----------',B+'\n// ---------- Главный цикл ----------')

# --- сектора: XI = 47–49, XII = 50 (до генерации миссий) ---
R("const secOfLevel=m=>{for(let i=0;i<SECTORS_NEW.length;i++){const q=SECTORS_NEW[i];if(m>=q.lv[0]&&m<=q.lv[1])return i+2;}return m<=6?0:1;};",
  "const secOfLevel=m=>{for(let i=0;i<SECTORS_NEW.length;i++){const q=SECTORS_NEW[i];if(m>=q.lv[0]&&m<=q.lv[1])return i+2;}return m<=6?0:1;};\nSECTORS_NEW[8].lv=[47,49];SECTORS_NEW.push({name:'???',lv:[50,50],col:'#ff9fe0',xii:1});")
R("'СЕКТОР '+['I','II','III','IV','V','VI','VII','VIII','IX','X','XI'][si]+' · '+S.name","'СЕКТОР '+['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'][si]+' · '+S.name")
R("SEC_SCALE[9]={hp:7.5,spd:1.16,arm:.29,dmg:3.05,rew:4.4,col:'#7affc9',shore:1,pace:.22,spd2:.12};",
  "SEC_SCALE[9]={hp:7.5,spd:1.16,arm:.29,dmg:3.05,rew:4.4,col:'#7affc9',shore:1,pace:.22,spd2:.12};\nSEC_SCALE[10]={hp:8,spd:1.18,arm:.30,dmg:3.2,rew:4.8,col:'#ff9fe0',zero:1,pace:.22,spd2:.12};SEC_MECH[10]='НУЛЕВАЯ ТОЧКА · ПАМЯТЬ';")
# мир: цикл секторов только для 9 полос, XI уже, XII — вручную
R("SEC_W=[3400,3200,3500,3300,3200,3700,3300,3400,3200];","SEC_W=[3400,3200,3500,3300,3200,3700,3300,3400,3000];")
R("{let xs=10000;SECTORS_NEW.forEach((q,k)=>{const x0=xs,x1=x0+SEC_W[k]","{let xs=10000;SECTORS_NEW.forEach((q,k)=>{if(k>=9)return;const x0=xs,x1=x0+SEC_W[k]")
R("for(let i=0;i<2;i++)WORLD.fields2.push({x:x0+800+R()*(x1-x0-1600),y:y0+1200+R()*(y1-y0-2400),r:350+R()*200,n:12+Math.floor(R()*8)});});}",
  "for(let i=0;i<2;i++)WORLD.fields2.push({x:x0+800+R()*(x1-x0-1600),y:y0+1200+R()*(y1-y0-2400),r:350+R()*200,n:12+Math.floor(R()*8)});});}\nworld110Setup();")
R("SECTORS_NEW.forEach((q,i)=>{const modes=['dor','mix','phr','dor','lyd','phr','mix','lyd','dor'],","SECTORS_NEW.forEach((q,i)=>{if(i>=9)return;const modes=['dor','mix','phr','dor','lyd','phr','mix','lyd','dor'],")
# ворота XI/XII в мире, запрет прыжка за ворота, маркер
R("hintOnce('gate',S.cleared>=6?'ВОРОТА ЗАПЕРТЫ · УНИЧТОЖЬТЕ ДВА ЗАМКА':'ВОРОТА СЕКТОРА · СНАЧАЛА ЯДРО СТРАЖА','#b48cff');}",
  "hintOnce('gate',S.cleared>=6?'ВОРОТА ЗАПЕРТЫ · УНИЧТОЖЬТЕ ДВА ЗАМКА':'ВОРОТА СЕКТОРА · СНАЧАЛА ЯДРО СТРАЖА','#b48cff');}\n  gate110(p,S);")
R("if(G.anom){deny('ПРЫЖОК НЕВОЗМОЖЕН · ИДЁТ АНОМАЛИЯ');return true;}","if(G.anom){deny('ПРЫЖОК НЕВОЗМОЖЕН · ИДЁТ АНОМАЛИЯ');return true;}\n  if(zeroJumpDeny110(best)){deny('ПРЫЖОК НЕВОЗМОЖЕН · ВОРОТА НУЛЕВОЙ ТОЧКИ');return true;}")
R("W90.zero={x:(b[0]+b[2])/2,y:(b[1]+b[3])/2};","W90.zero={x:(b[0]+b[2])/2,y:b[3]};")
R("if(storyFlag('shore46')==='record'&&W90.zero)add('zero100',W90.zero.x,W90.zero.y,{},lod===2?{t:'НУЛЕВАЯ ТОЧКА · СКОРО',p:6,c:'#ff9fe0'}:null);",
  "if(W90.zero&&revealedAt(W90.zero.x,W90.zero.y))add('zero100',W90.zero.x,W90.zero.y,{},lod===2?{t:zeroOpen110()?'ВОРОТА ОТКРЫТЫ · XII':'ВОРОТА · ПРОЙДИТЕ «МИГ»',p:6,c:'#ff9fe0'}:null);")
R("  if(storyFlag('shore46')==='record'&&W90.zero&&inView(W90.zero.x,W90.zero.y,300)){const q=W90.zero;glow(q.x,q.y,140,'#ff9fe0',.22+.08*Math.sin(t*1.5));ctx.strokeStyle='#ff9fe0';ctx.setLineDash([12,10]);ctx.lineDashOffset=-t*12;ctx.beginPath();ctx.arc(q.x,q.y,100,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;worldLabel(q.x,q.y-120,'НУЛЕВАЯ ТОЧКА','#ff9fe0');worldLabel(q.x,q.y+122,'СКОРО','#9fb0c4');}\n  w95Draw(t);",
  "  gate110Draw(t);\n  w95Draw(t);")
# карточка узла 50 закрыта (кроме режима разработчика)
R("if(card.kind==='node'){const m=card.n.m,M=MISSIONS[m-1],md=S.medals[m]||{},done=nodeState(m)==='done';\n    h=`<div class=\"eyebrow\">МИССИЯ ${",
  "if(card.kind==='node'&&card.n.m===50&&!devAny()){h=`<div class=\"eyebrow\">МИССИЯ 50/${pad2(NM)} · СЕКТОР XII</div><h3>Комната босса <span class=\"badge\" style=\"color:#ff9fe0\">СКОРО</span></h3><p class=\"note\">Комната подготовлена. Босс Нулевой точки будет описан в следующем обновлении.</p><div class=\"wc-row\"><button class=\"wbtn\" disabled style=\"opacity:.45\">ВХОД ЗАКРЫТ</button></div>`;}\n  else if(card.kind==='node'){const m=card.n.m,M=MISSIONS[m-1],md=S.medals[m]||{},done=nodeState(m)==='done';\n    h=`<div class=\"eyebrow\">МИССИЯ ${")
R("if(c.kind==='node'){if(act==='echo'){if(nodeState(c.n.m)==='done')enterNode(c.n.m,true);}else enterNode(c.n.m,false);}",
  "if(c.kind==='node'){if(act==='echo'){if(nodeState(c.n.m)==='done')enterNode(c.n.m,true);}else{if(c.n.m===50&&!devAny()){hintOnce('n50','КОМНАТА БОССА · СКОРО','#ff9fe0');return;}enterNode(c.n.m,false);}}")
R("function bossLab90(m){const si=secOfLevel(m);","function bossLab90(m){if(m===50)return 'БОСС · СКОРО';const si=secOfLevel(m);")
R("if(st.sec95!==undefined)st.sec95=num(st.sec95,0,0,255,true);","if(st.sec95!==undefined)st.sec95=num(st.sec95,0,0,255,true);\n    if(st.zero49!==undefined)st.zero49=num(st.zero49,0,0,1,true);if(st.zero50!==undefined)st.zero50=num(st.zero50,0,0,9,true);")
R("<small>${M.gen?(M.bossRoom?'БОСС · ':'')+'СЕКТОР '+roman(M.sec+1):i<6?'АКТ I':'АКТ II'}</small>","<small>${M.gen?(M.bossRoom?(i===49?'ЗАГОТОВКА · ':'БОСС · '):'')+'СЕКТОР '+roman(M.sec+1):i<6?'АКТ I':'АКТ II'}</small>")
# --- каркас миссий сектора XI ---
R("function on95(){const X=G.x90;return !!X&&inMission()&&(X.sec===8||X.sec===9)&&G.mode!=='endless';}","function on95(){const X=G.x90;return !!X&&inMission()&&X.sec>=8&&X.sec<=11&&G.mode!=='endless';}")
R("function t90Init(M){const sec=M&&M.gen?M.sec:-1;","function t90Init(M){G.x110=null;const sec=M&&M.gen?M.sec:-1;")
R("if(sec===9&&typeof t100Init==='function')t100Init(M,X);\n  if(typeof t95Init==='function')t95Init(M,X);}","if(sec===9&&typeof t100Init==='function')t100Init(M,X);\n  if(typeof t95Init==='function')t95Init(M,X);if(typeof t110Init==='function')t110Init(M,X);}")
R("if(X.sec===8)ark90Tick(X,dt);else if(X.sec===9&&typeof t100Tick==='function')t100Tick(X,dt);","if(X.sec===8)ark90Tick(X,dt);else if(X.sec===9&&typeof t100Tick==='function')t100Tick(X,dt);else if(X.sec>=10&&typeof t110Tick==='function')t110Tick(X,dt);")
R("if(M.sec===9&&typeof done100==='function')done100(M,X);","if(M.sec===9&&typeof done100==='function')done100(M,X);if(M.sec>=10&&typeof done110==='function')done110(M,X);")
R("function r90Reset(){G.x90=null;","function r90Reset(){G.x90=null;G.x110=null;")
R("else if(!M.boss&&!M.sboss&&alive===0&&G.endT<=0){G.endT=1.6;","else if(!M.boss&&!M.sboss&&alive===0&&G.endT<=0&&!x110Block()){G.endT=1.6;")
R("function edgeSpawn(type,o={}){if(spawn95(type,o))return;","function edgeSpawn(type,o={}){if(spawn95(type,o))return;if(spawn110(type,o))return;")
R("if(G.arena)drawArenaEdge(p,t);\n  const bc=G.bc;","if(G.arena)drawArenaEdge(p,t);bg110(t);\n  const bc=G.bc;")
R("function d80Under(t){sb85Under(t);under90(t);","function d80Under(t){sb85Under(t);under90(t);under110(t);")
R("function d80Draw(t){draw90(t);","function d80Draw(t){draw90(t);draw110(t);")
R("if(inMission()){sb85Top(t);top90(t);}","if(inMission()){sb85Top(t);top90(t);top110(t);}")
R("function hud90(){const X=G.x90;let I=null;","function hud90(){const X=G.x90;let I=typeof hud110==='function'?hud110():null;")
R("SS.shore?['122,255,201',.08]:","SS.zero?(G.x110&&G.x110.k==='launch'?['159,216,255',.07]:['255,159,224',.07+.08*(G.x110&&G.x110.vig||0)]):SS.shore?['122,255,201',.08]:")
R("if(G.x90.sec===9)dl100(e,dmg);","if(G.x90.sec>=9)dl100(e,dmg);")
R("if(X.sec===9&&typeof pulse100==='function')pulse100(X,p,R);","if(X.sec>=9&&typeof pulse100==='function')pulse100(X,p,R);")
R("{const k_=leakK80(b.x,b.y);b.x+=b.vx*dt*k_;","{const k_=leakK80(b.x,b.y)*bK110(b);b.x+=b.vx*dt*k_;")
R("const k=(A&&A.a.kind==='coldcore'&&Math.hypot(b.x-A.a.x,b.y-A.a.y)<420?.5:1)*leakK80(b.x,b.y);b.x+=b.vx*dt*k;","const k=(A&&A.a.kind==='coldcore'&&Math.hypot(b.x-A.a.x,b.y-A.a.y)<420?.5:1)*leakK80(b.x,b.y)*bK110(b);b.x+=b.vx*dt*k;")
R("if(sec===9)glyph95(e.x,e.y,6,e.mem100?'#a8b4b0':d.col);","if(sec===9)glyph95(e.x,e.y,6,e.mem100?'#a8b4b0':d.col);if(sec>=10)spark110(e);")
R("function step90(P,t,st,bar){const S=P.sc,X=P.ext||{},root=S.root+(P.semi||0);if(!AU.ctx)return;","function step90(P,t,st,bar){const S=P.sc,X=P.ext||{},root=S.root+(P.semi||0);if(!AU.ctx)return;step110(P,t,st,bar);")
R("function mus90(T){const X=G.x90;","function mus90(T){T=mus110(T);const X=G.x90;")
R("function cap90(e){if(e.cap90||e.zone||G.world||e.elite95||e.host85||e.pack95||e.noCap95||e.net90)return;e.cap90=1;const L=CAP90[e.type];","function cap90(e){if(e.cap90||e.zone||G.world||e.elite95||e.host85||e.pack95||e.noCap95||e.net90)return;e.cap90=1;const L=G.x110&&inMission()&&CAP110[e.type]!==undefined?CAP110[e.type]:CAP90[e.type];")
R("for(const t of shuffle(FB.slice())){if(t===e.type)continue;const c=CAP90[t];","for(const t of shuffle(FB.slice())){if(t===e.type)continue;const c=G.x110&&inMission()&&CAP110[t]!==undefined?CAP110[t]:CAP90[t];")
# --- хроника ---
R('<div class="eyebrow">АЛЬФА 0.9.6 · СЕРДЦЕ И БЕРЕГ 2.0</div>','<div class="eyebrow">АЛЬФА 0.9.7 · НУЛЕВАЯ ТОЧКА</div>')
R('<dl class="kv"><dt>0.9.6 α</dt>','<dl class="kv"><dt>0.9.7 α</dt><dd>Сектор XI «Нулевая точка» наполнен: три миссии, где врагов не придумали заново — их собрали из лучших связок прежних секторов. 47 «Созвездие»: пять погибших пилотов лежат созвездием; прочитать каждого — 3 секунды в кольце, и память отвечает теми, кто их убил: копейщики со стаей, Изморозь с таранами, Смотрители со стрелками, минёры с Охотником, Командир с Тромбами. 48 «Пуск»: стартовый стол с тремя контактами — Связист с расчётом, Гвардия с Лаборантом и Отражением, Певчий с Нерождёнными; когда все подняты — 10 секунд в круге «ПУСК» под последним расчётом, и пуск стирает всё. 49 «Миг»: существует только полоса, которая ползёт, поворачивает и сжимается к точке выхода; снаружи стирание и незаряжающийся рывок, зато враги вязнут; четыре засечки от Охотников до Стёртого пилота с Корректором, а у точки выхода за вас отвечает память — двое и те, кого вы пощадили. Миссия 50 вынесена в отдельный сектор XII за воротами Нулевой точки: ворота открывает победа в «Миге», комната подготовлена, босс будет описан отдельно. У сектора свой свет (созвездие, чертёж, негатив), свой звук (хор, метроном, тиканье) и свои мастерства.</dd><dt>0.9.6 α</dt>')

open(P,'w',encoding='utf8').write(s)
print('m20 ok')
