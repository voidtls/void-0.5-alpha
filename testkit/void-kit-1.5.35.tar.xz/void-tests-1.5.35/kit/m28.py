# 1.2.0 α · m28: прибавки по миссиям поверх сложности — миссия 6: темп атак и прочность ×1,25; миссии 8–10: скорость, урон, прочность ×1,25
import sys,os,re
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m28 FAIL count',n,'!=',cnt,'for',a[:100]);sys.exit(1)
    s=s.replace(a,b)
DATA="""
// ===== 1.2.0: прибавки по миссиям (умножаются на множители выбранной сложности, не заменяют их) =====
const MISSION_K={
  6: {rate:1.25,hp:1.25,lom:1.25},
  8: {spd:1.25,dmg:1.25,hp:1.25,lom:1.25},
  9: {spd:1.25,dmg:1.25,hp:1.25,lom:1.25},
  10:{spd:1.25,dmg:1.25,hp:1.25,lom:1.25}
};
function missionK(k){if(!inMission())return 1;const t=MISSION_K[G.m];return t&&t[k]||1;}
"""
R("function inMission(){return(G.mode==='world'||G.mode==='dev')&&!G.world;}",
  "function inMission(){return(G.mode==='world'||G.mode==='dev')&&!G.world;}"+DATA)
# прочность — всем врагам миссии, включая босса и его заряды (до расчёта порогов фаз)
R("  if(inMission()&&!d.passive&&!d.sb&&!d.fixed&&MISSIONS[G.m-1]&&MISSIONS[G.m-1].hpMul){e.hp*=MISSIONS[G.m-1].hpMul;e.maxHp=e.hp;}",
  "  if(inMission()&&!d.passive&&!d.sb&&!d.fixed&&MISSIONS[G.m-1]&&MISSIONS[G.m-1].hpMul){e.hp*=MISSIONS[G.m-1].hpMul;e.maxHp=e.hp;}\n  if(inMission()&&!d.passive){const hk=missionK('hp');if(hk!==1){e.hp*=hk;e.maxHp=e.hp;}}")
# скорость движения и темп атак (G.atkK < 1 сжимает каждую новую перезарядку врага)
R("G.eSpd=inMission()?(curDiff().spd||1):1;G.atkK=atkK();",
  "G.eSpd=inMission()?(curDiff().spd||1)*missionK('spd'):1;G.atkK=atkK()/missionK('rate');")
# Страж: паузы между атаками короче
R("if(!b.atk){b.atkT-=dt;if(b.atkT<=0){const list=PATTERNS[b.phase-1];","if(!b.atk){b.atkT-=dt*missionK('rate');if(b.atkT<=0){const list=PATTERNS[b.phase-1];")
# урон по кораблю и по маяку
R("  if(inMission())d*=curDiff().dmg||1;","  if(inMission())d*=(curDiff().dmg||1)*missionK('dmg');")
R("if(bc.cool>0)d*=1.5;d*=curDiff().bcDmg||1;","if(bc.cool>0)d*=1.5;d*=(curDiff().bcDmg||1)*missionK('dmg');")
# награда: за усиленную миссию лома и опыта пилота больше
R("p=G.player,node=WORLD.nodes[m-1],D=curDiff(),mul=D.lom*cycLom();","p=G.player,node=WORLD.nodes[m-1],D=curDiff(),mul=D.lom*cycLom()*(MISSION_K[m]&&MISSION_K[m].lom||1);")
# брифинг: один тег без чисел
R("$('#inThreat').innerHTML=dangerTag(M)","$('#inThreat').innerHTML=(MISSION_K[i+1]?'<span class=\"tag threat\">УСИЛЕНА</span>':'')+dangerTag(M)")
open(P,'w',encoding='utf8').write(s)
print('m28 ok')
