# 1.4.2 α: одна кнопка «Готово», вкладки настроек на телефоне без прокрутки. M01, M02, M04, M06 падают на v38 (1.4.1); M03 и M05 — страховка (альбомная строка, касания по плитке).
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
W8="const w8=ms=>new Promise(r=>setTimeout(r,ms));"
OPEN=W8+"T.fresh();G.save.tut.off=1;$('#toast').hidden=true;await w8(250);pause();await w8(150);$('#bPauseSet').click();await w8(300);"
BIG="SET.textScale=SET_OPT.textScale[SET_OPT.textScale.length-1];saveSet();applySettings();"

@test('M01')
async def m01(b):
    out={}
    for (w,h,t) in [(1280,800,False),(390,844,True)]:
        P=await newpage(b,w,h,alpha=False,touch=t)
        out[w]=await P.js("async()=>{"+OPEN+"const ps=[...document.querySelectorAll('#sSet button')].filter(x=>x.offsetParent&&/ГОТОВО/.test(x.textContent));const k=$('#bSetBack kbd');return {n:ps.length,id:ps[0]&&ps[0].id,esc:!!k&&!!k.offsetParent}}")
    ok=out[1280]=={'n':1,'id':'bSetBack','esc':True} and out[390]=={'n':1,'id':'bSetBack','esc':False}
    rec('M01 в настройках одна кнопка «Готово» — нижняя; на ПК с подсказкой ESC, на телефоне без',ok,out)

@test('M02')
async def m02(b):
    out={}
    for (w,h,big) in [(360,740,False),(390,844,False),(430,932,False),(360,740,True),(390,844,True)]:
        P=await newpage(b,w,h,alpha=False,touch=True)
        out[f'{w}{"big" if big else ""}']=await P.js("async(big)=>{"+W8+"if(big){"+BIG+"}"+OPEN[len(W8):]+"const tb=document.querySelector('#sSet .settabs63');const bs=[...tb.querySelectorAll('button')];const R=bs.map(x=>x.getBoundingClientRect());"
            "return {scroll:tb.scrollWidth>tb.clientWidth+1,inside:R.every(r=>r.left>=0&&r.right<=innerWidth),clip:bs.filter(x=>x.scrollWidth>x.clientWidth+1||x.querySelector('span').scrollWidth>x.querySelector('span').clientWidth+1).map(x=>x.dataset.tab63),rows:new Set(R.map(r=>Math.round(r.top))).size,ico:bs.every(x=>x.querySelector('svg.tic64')),h:Math.min(...R.map(r=>r.height))}}",big)
    ok=all((not o['scroll']) and o['inside'] and not o['clip'] and o['rows']==2 and o['ico'] and o['h']>=44 for o in out.values())
    rec('M02 телефон 360–430, обычный и очень крупный текст: все пять вкладок видны сразу (3 + 2, со значками), без прокрутки вбок и без обрезанных подписей',ok,out)

@test('M03')
async def m03(b):
    P=await newpage(b,844,390,alpha=False,touch=True)
    r=await P.js("async()=>{"+OPEN+"const tb=document.querySelector('#sSet .settabs63');const R=[...tb.querySelectorAll('button')].map(x=>x.getBoundingClientRect());return {scroll:tb.scrollWidth>tb.clientWidth+1,rows:new Set(R.map(r=>Math.round(r.top))).size,h:Math.round(tb.getBoundingClientRect().height)}}")
    rec('M03 телефон в альбомной: вкладки одной строкой, без прокрутки, плитка не выше 50 px',not r['scroll'] and r['rows']==1 and r['h']<=50,r)

@test('M04')
async def m04(b):
    P=await newpage(b,1280,600,alpha=False)
    r=await P.js("async()=>{"+OPEN+"document.querySelector('#sSet button[data-tab63=\"ctl\"]').click();await w8(100);const d=$('#bSetBack'),S=$('#sSet');const b1=Math.round(d.getBoundingClientRect().bottom);S.scrollTop=9999;await w8(60);const b2=Math.round(d.getBoundingClientRect().bottom);"
        "S.scrollTop=0;await w8(60);document.dispatchEvent(new KeyboardEvent('keydown',{code:'Escape',key:'Escape',bubbles:true}));await w8(250);return {b1,b2,vh:innerHeight,state:G.state}}")
    rec('M04 ПК: на самой длинной вкладке «Готово» видна без прокрутки и после неё; Esc закрывает настройки в паузу',r['b1']<=r['vh'] and r['b2']<=r['vh'] and r['state']=='pause',r)

@test('M05')
async def m05(b):
    P=await newpage(b,390,844,alpha=False,touch=True)
    await P.js("async()=>{"+OPEN+"return 1}")
    seen={}
    for k in ['ctl','scr','acc','game','snd']:
        await P.pg.tap(f'#sSet button[data-tab63="{k}"]');await P.pg.wait_for_timeout(150)
        seen[k]=await P.js("()=>[[...document.querySelectorAll('#setBody .tab63')].filter(g=>!g.hidden).map(g=>g.dataset.tab63).join(),document.querySelector('#sSet button.on[data-tab63]').dataset.tab63,$('#sSet').scrollTop]")
    ok=all(v[0]==k and v[1]==k and v[2]==0 for k,v in seen.items()) and not P.errs
    rec('M05 телефон: касание по плитке переключает вкладку, подсвечена выбранная, страница наверху',ok,{'seen':seen,'pe':P.errs[:2]})

@test('M06')
async def m06(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("()=>({ver:VER_TAG,tag:$('#verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.4.2 α</dt>')})")
    rec('M06 версия 1.4.2 α и запись в журнале',r['ver']=='1.4.2 α' and r['tag']=='1.4.2 α' and r['log'],r)

if __name__=='__main__':
    sel=sys.argv[1:]
    if sel:TESTS=[t for t in TESTS if t[0] in sel]
    asyncio.run(run(TESTS,'q320'))
