# 0.6.1 · часть 10: встраивание в обёртку артефакта (вырезы, прокрутка страницы), полный экран, компактное меню в низком ландшафте
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m10: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
CSS=r"""
/* --- 0.6.1: страница-обёртка (padding корня под вырез) не должна двигать и прокручивать игру --- */
html{padding:0!important;margin:0!important;box-sizing:border-box}
html,body{height:100dvh!important;max-height:100dvh;overflow:hidden!important}
.mob body{position:fixed;inset:0;margin:0}
.mob .screen{-webkit-overflow-scrolling:touch}
/* кнопка «во весь экран» в меню */
#bFs{position:fixed;top:calc(var(--sat) + 10px);right:calc(max(14px,var(--sar)) + 0px);z-index:3;width:44px;height:44px;border:1px solid var(--line);background:var(--panel);color:var(--ice);font-size:20px;line-height:1;display:flex;align-items:center;justify-content:center;pointer-events:auto}
#bFs.on{border-color:var(--ice)}
.ff-phone-l #bFs{top:auto;right:auto;bottom:calc(var(--sab) + 10px);left:max(14px,var(--sal))}
/* низкий ландшафт: меню помещается без прокрутки */
@media (max-height:440px){
.ff-phone-l #sMenu .logo{font-size:44px}
.ff-phone-l #sMenu .genre,.ff-phone-l #sMenu .log,.ff-phone-l #sMenu #recLine{display:none}
.ff-phone-l #sMenu .wrap{gap:8px;column-gap:24px}
.ff-phone-l #sMenu .wrap>.btns{gap:6px}
.ff-phone-l #sMenu .btn{padding:9px 14px;min-height:44px}
.ff-phone-l #sMenu .sub{font-size:13px}
.ff-phone-l .screen{padding-block:calc(10px + var(--sat)) calc(10px + var(--sab))}
}
"""
R("</style>",CSS+"</style>",1)
# кнопка в меню (только мобильный, только если браузер умеет полный экран)
R('<section class="screen" id="sMenu">\n  <div class="wrap">',
  '<section class="screen" id="sMenu">\n  <button id="bFs" class="mobonly" hidden aria-label="Во весь экран" title="Во весь экран">⛶</button>\n  <div class="wrap">')
# настройка: полный экран при старте
R("quality:'auto',fps:60,textScale:1};","quality:'auto',fps:60,textScale:1,autoFs:true};")
R("${togHTML('fx','ЭФФЕКТЫ · частицы и тряска')}\n      ${document.fullscreenEnabled?",
  "${togHTML('fx','ЭФФЕКТЫ · частицы и тряска')}${fsCan()?togHTML('autoFs','ВО ВЕСЬ ЭКРАН ПРИ СТАРТЕ'):''}\n      ${document.fullscreenEnabled?")
# логика полного экрана
R("document.addEventListener('click',e=>{if(!e.target.closest('#bFull'))return;",
  """function fsCan(){const d=document,el=d.documentElement;return !!((d.fullscreenEnabled||d.webkitFullscreenEnabled)&&(el.requestFullscreen||el.webkitRequestFullscreen));}
function fsIs(){return !!(document.fullscreenElement||document.webkitFullscreenElement);}
function fsEnter(){const el=document.documentElement;try{const p=el.requestFullscreen?el.requestFullscreen({navigationUI:'hide'}):el.webkitRequestFullscreen();if(p&&p.catch)p.catch(()=>{});}catch(err){}}
function fsExit(){try{const p=document.exitFullscreen?document.exitFullscreen():document.webkitExitFullscreen();if(p&&p.catch)p.catch(()=>{});}catch(err){}}
function fsSync(){const b=$('#bFs');if(!b)return;b.hidden=!(isMob()&&fsCan());b.classList.toggle('on',fsIs());b.textContent=fsIs()?'✕':'⛶';}
document.addEventListener('click',e=>{if(!e.target.closest('#bFs'))return;if(fsIs())fsExit();else fsEnter();buzz('tap');setTimeout(fsSync,300);});
// первый тап по «в полёт» на телефоне — сразу во весь экран (жест пользователя ещё активен)
document.addEventListener('click',e=>{const b=e.target.closest('#bWorld,#bEndless,#bWorldNew');if(!b||!isMob()||!SET.autoFs||fsIs()||!fsCan())return;fsEnter();},true);
document.addEventListener('webkitfullscreenchange',()=>{fsSync();if(!fsIs()&&(G.state==='play'||G.state==='world')&&isMob())pause();});
document.addEventListener('click',e=>{if(!e.target.closest('#bFull'))return;""")
R("document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&","document.addEventListener('fullscreenchange',()=>{fsSync();if(!document.fullscreenElement&&")
# синхронизация кнопки при показе меню и смене форм-фактора
R("function ffUpdate(){","function ffUpdate(){setTimeout(fsSync,0);")
open(P,'w',encoding='utf8').write(s)
print('m10 ok')
