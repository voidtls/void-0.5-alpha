# 0.6.0 · часть 3: масштаб, арена миссии, камера, стрелки за краем, читаемость (ПК: VIEW 760, арена = экран, CX=0 — без изменений)
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m3: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)

# ---------- масштаб и арена ----------
R("let BW=900,BH=600,CX=0,CY=0;","let BW=900,BH=600,CX=0,CY=0,VW=900,VH=600,BMIN=0;")
R("""function resize(){
  ffUpdate();DPR=Math.min(2,window.devicePixelRatio||1);CW=window.innerWidth;CH=window.innerHeight;
  cv.width=Math.round(CW*DPR);cv.height=Math.round(CH*DPR);
  SC=Math.max(.42,Math.min(CW,CH)/760);W=CW/SC;H=CH/SC;
  buildNebula();buildStars();
  if(G.player&&!G.world){G.player.x=clamp(G.player.x,20,W-20);G.player.y=clamp(G.player.y,20,H-20);}
  if(G.bc)layoutBeacon();
  if(G.world&&G.player)camSnap();
}""",
r"""// 0.6.0: видимый мир и разрешение рендера разделены. ПК — 760 единиц на короткую сторону (как раньше), телефон — 560, планшет — 680.
function viewS(){return G.ff==='desk'?760:G.ff==='tablet'?680:560;}
function zoomK(){return isMob()?(SET.zoom||1)*(G.camZ||1):1;}
function applyWH(){if(G.arena&&!G.world){W=G.arena.w;H=G.arena.h;}else{W=VW;H=VH;}}
function setScale(){SC=Math.max(.42,Math.min(CW,CH)/(viewS()*zoomK()));VW=CW/SC;VH=CH/SC;applyWH();BMIN=isMob()?2.2/SC:0;}
function dprCap(){const q=G.q,cap=q>=2?2:q===1?1.5:1;return Math.min(cap,Math.sqrt(2.2e6/Math.max(1,CW*CH)));}
let rsW=0,rsH=0;
function resize(){
  ffUpdate();CW=window.innerWidth;CH=window.innerHeight;DPR=Math.min(isMob()?dprCap():2,window.devicePixelRatio||1);
  cv.width=Math.round(CW*DPR);cv.height=Math.round(CH*DPR);
  setScale();
  // туманность и звёзды — только при заметной смене размера (адресная строка дёргает resize десятки раз), на ПК — как раньше
  if(!isMob()||Math.abs(CW-rsW)>64||Math.abs(CH-rsH)>64||!nebula||(CW>CH)!==(rsW>rsH)){rsW=CW;rsH=CH;buildNebula();buildStars();}
  if(G.player&&!G.world&&!G.arena){G.player.x=clamp(G.player.x,20,W-20);G.player.y=clamp(G.player.y,20,H-20);}
  if(G.bc&&!G.arena)layoutBeacon();
  if(G.world&&G.player)camSnap();
  if(G.arena&&!G.world&&G.player){G.camSnap=1;missionCam(0);}
  if(typeof layoutTouch==='function')layoutTouch();
}
// арена миссии на телефоне и планшете: 1280×760, длинной стороной вдоль длинной стороны экрана; на ПК арена = экран
function lockArena(){if(!isMob()){G.arena=null;applyWH();return;}G.arena=CW>=CH?{w:1280,h:760}:{w:760,h:1280};applyWH();}
function unlockArena(){G.arena=null;applyWH();}
function missionCam(dt){
  if(!G.arena){CX=0;CY=0;return;}
  const p=G.player;if(!p){CX=(W-VW)/2;CY=(H-VH)/2;return;}
  const off=isPortrait()?.12:.06;let tx=p.x+(p.vx||0)*.35-VW/2,ty=p.y+(p.vy||0)*.35-VH/2+VH*off;
  if(G.bc){tx=tx*.7+(G.bc.x-VW/2)*.3;ty=ty*.7+(G.bc.y-VH/2)*.3;}
  const fx=W>VW?clamp(tx,0,W-VW):(W-VW)/2,fy=H>VH?clamp(ty,0,H-VH):(H-VH)/2;
  const k=G.camSnap||!(dt>0)?1:Math.min(1,dt*6);G.camSnap=0;CX+=(fx-CX)*k;CY+=(fy-CY)*k;}""")

# миссия: арена фиксируется до раскладки, камера — сразу на корабль
R("  G.state='intro';setupMission(i);snapshotRun();const M=MISSIONS[i];",
  "  G.state='intro';lockArena();setupMission(i);snapshotRun();if(G.arena){G.camSnap=1;missionCam(0);}const M=MISSIONS[i];")
R("  G.mode='endless';G.devRun=!!dev;G.devStep=step0||1;G.echo=false;G.world=false;G.mods={};computeStats();G.player=newPlayer();G.player.hp=G.st.maxHp;",
  "  G.mode='endless';G.devRun=!!dev;G.devStep=step0||1;G.echo=false;G.world=false;lockArena();G.mods={};computeStats();G.player=newPlayer();G.player.hp=G.st.maxHp;")
R("  const p=G.player;p.x=W/2;p.y=H/2;p.px=p.x;p.py=p.y;p.inv=1.5;\n  const rec=bestEndless();",
  "  const p=G.player;p.x=W/2;p.y=H/2;p.px=p.x;p.py=p.y;p.inv=1.5;if(G.arena){G.camSnap=1;missionCam(0);}\n  const rec=bestEndless();")
R("function enterWorldAt(x,y){\n  secReset();","function enterWorldAt(x,y){\n  unlockArena();secReset();")
R("function toMenu(){riftReset();","function toMenu(){unlockArena();riftReset();")

# кадр миссии: арена и камера вместо CX=0
R("function update(dt){\n  BW=W;BH=H;CX=0;CY=0;","function update(dt){\n  applyWH();BW=W;BH=H;missionCam(dt);")
R("function worldUpdate(dt){\n  G.t+=dt;BW=WW;BH=WH;","function worldUpdate(dt){\n  applyWH();G.t+=dt;BW=WW;BH=WH;")

# отрисовка миссии: звёзды по экрану, мир — со сдвигом камеры, тьма — тоже
R("  for(const s of stars){const x=((s.x-ox*s.k-t*6*s.k*10)%(W*1.2)+W*1.2)%(W*1.2)-W*.1,y=((s.y-oy*s.k)%(H*1.2)+H*1.2)%(H*1.2)-H*.1;",
  "  for(const s of stars){const x=((s.x-ox*s.k-t*6*s.k*10)%(VW*1.2)+VW*1.2)%(VW*1.2)-VW*.1,y=((s.y-oy*s.k)%(VH*1.2)+VH*1.2)%(VH*1.2)-VH*.1;")
R("  ctx.globalAlpha=1;\n  if(!p||G.state==='menu'||G.state==='codex'&&!G.inRun)return;\n  const bc=G.bc;",
  "  ctx.globalAlpha=1;\n  if(!p||G.state==='menu'||G.state==='codex'&&!G.inRun)return;\n  if(G.arena)ctx.setTransform(DPR*SC,0,0,DPR*SC,(sx-CX)*DPR*SC,(sy-CY)*DPR*SC);\n  if(G.arena)drawArenaEdge(p,t);\n  const bc=G.bc;")
R("  if(G.dark){drawDark(sx,sy);","  if(G.dark){drawDark(G.arena?sx-CX:sx,G.arena?sy-CY:sy);")

# ---------- читаемость: минимальные экранные размеры ----------
R("ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(b.x,b.y,b.r*.55,0,TAU);ctx.fill();}",
  "ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(b.x,b.y,Math.max(b.r*.55,BMIN),0,TAU);ctx.fill();if(BMIN){ctx.strokeStyle='#04060c';ctx.lineWidth=1/SC;ctx.stroke();}}",2)
R("for(const b of G.eb){if(b.rift)continue;glow(b.x,b.y,b.r*3.2,b.col,.8);}",
  "for(const b of G.eb){if(b.rift)continue;glow(b.x,b.y,Math.max(b.r*3.2,BMIN*4.5),b.col,.8);}",2)
R("ctx.textAlign='center';ctx.font='700 12px \"JetBrains Mono\",monospace';",
  "ctx.textAlign='center';ctx.font='700 '+fpx(12)+'px \"JetBrains Mono\",monospace';",2)
R("function worldLabel(x,y,text,col){ctx.font='700 11px \"JetBrains Mono\",monospace';",
  "function fpx(n){return isMob()?Math.max(n,11.5/SC):n;}\nfunction worldLabel(x,y,text,col){ctx.font='700 '+fpx(11)+'px \"JetBrains Mono\",monospace';")
R("ctx.font='700 10px \"JetBrains Mono\",monospace';ctx.fillStyle='#ffffff';ctx.textAlign='center';ctx.fillText('ЦЕЛЬ',e.x,e.y-r-6);",
  "ctx.font='700 '+fpx(10)+'px \"JetBrains Mono\",monospace';ctx.fillStyle='#ffffff';ctx.textAlign='center';ctx.fillText('ЦЕЛЬ',e.x,e.y-r-6);")

# виньетки сектора на телефоне мягче (снежная маска видимости — механика, её не трогаем)
R("  ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);}\n\n// ===== 0.5.6",
  "  ctx.globalAlpha=isMob()?.67:1;ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);ctx.globalAlpha=1;}\n\n// ===== 0.5.6")
R("g.addColorStop(1,`rgba(200,230,255,${.22*ch*COLD_A})`);ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);}",
  "g.addColorStop(1,`rgba(200,230,255,${.22*ch*COLD_A*(isMob()?.67:1)})`);ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);}")
R("g.addColorStop(1,`rgba(138,58,18,${w.inRust?.10:.08*inRain})`);ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);}",
  "g.addColorStop(1,`rgba(138,58,18,${(w.inRust?.10:.08*inRain)*(isMob()?.67:1)})`);ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);}")

# ---------- экранный слой телефона: граница арены, стрелки за краем, ореол корабля, комбо, отсчёт ----------
OV=r"""
// ===== 0.6.0: экранный слой для телефона =====
function drawArenaEdge(p,t){const m=120,near=Math.min(p.x,p.y,W-p.x,H-p.y);if(near>m*2.2)return;const a=clamp(1-(near-m*.4)/(m*1.8),0,1)*.55;
  ctx.save();ctx.strokeStyle='#8fe9ff';ctx.globalAlpha=a;ctx.lineWidth=2/SC;ctx.setLineDash([10/SC,8/SC]);ctx.strokeRect(2,2,W-4,H-4);ctx.setLineDash([]);ctx.restore();}
function edgePt(X,Y,x0,y0,x1,y1){const cx=(x0+x1)/2,cy=(y0+y1)/2,dx=X-cx,dy=Y-cy;let k=1e9;
  if(dx)k=Math.min(k,((dx>0?x1:x0)-cx)/dx);if(dy)k=Math.min(k,((dy>0?y1:y0)-cy)/dy);k=Math.min(1,k);return [cx+dx*k,cy+dy*k,Math.atan2(dy,dx)];}
function edgeArrow(x,y,col,size,label){const X=(x-CX)*SC,Y=(y-CY)*SC;if(X>=-4&&X<=CW+4&&Y>=-4&&Y<=CH+4)return false;
  const [ex,ey,a]=edgePt(X,Y,SAFE.l+26,SAFE.t+74,CW-SAFE.r-26,CH-SAFE.b-26);
  ctx.save();ctx.translate(ex,ey);ctx.rotate(a);ctx.fillStyle=col;ctx.strokeStyle='#04060c';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(size,0);ctx.lineTo(-size*.6,-size*.7);ctx.lineTo(-size*.25,0);ctx.lineTo(-size*.6,size*.7);ctx.closePath();ctx.stroke();ctx.fill();ctx.restore();
  if(label){ctx.font='700 12px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#04060c';const lx=clamp(ex-Math.cos(a)*30,48,CW-48),ly=clamp(ey-Math.sin(a)*22+4,SAFE.t+70,CH-SAFE.b-10);ctx.fillText(label,lx+1,ly+1);ctx.fillStyle=col;ctx.fillText(label,lx,ly);}
  return true;}
function mobOverlay(now){if(!isMob())return;const p=G.player;if(!p||!(G.state==='play'||G.state==='world'||G.state==='pause'||G.state==='levelup'))return;
  const t=now/1000;ctx.setTransform(DPR,0,0,DPR,0,0);ctx.globalAlpha=1;
  const PX=(p.x-CX)*SC,PY=(p.y-CY)*SC;
  if(!G.world&&G.arena){// угрозы и цели за кадром
    const list=[];for(const e of G.enemies){if(!e.alive||e.spawnT>0||e.ghost||e.type==='mine'||EDEF[e.type]&&EDEF[e.type].passive)continue;
      const d=Math.hypot(e.x-p.x,e.y-p.y);if(d>VW*.95)continue;const X=(e.x-CX)*SC,Y=(e.y-CY)*SC;if(X>=0&&X<=CW&&Y>=0&&Y<=CH)continue;
      const v=(e.vx||0)*(p.x-e.x)+(e.vy||0)*(p.y-e.y);if(v<0&&d>VW*.5)continue;list.push([d,e]);}
    list.sort((a,b)=>a[0]-b[0]);for(const [d,e] of list.slice(0,6))edgeArrow(e.x,e.y,EDEF[e.type].col||'#ff4f6e',8+6*(1-d/VW),'');
    const B=G.sb&&G.sb.alive?G.sb:G.boss&&G.boss.alive?G.boss:G.jam&&G.jam.alive?G.jam:null;if(B)edgeArrow(B.x,B.y,'#ff6b8a',14,'БОСС');
    if(G.bc)edgeArrow(G.bc.x,G.bc.y,'#ffb84d',13,'МАЯК');}
  if(p.hp>0&&touchMode){// ореол корабля: где я и когда рывок
    const R=22;ctx.globalAlpha=.22;ctx.strokeStyle='#cfeeff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(PX,PY,R,0,TAU);ctx.stroke();
    if(p.dashCd>0){const f=1-p.dashCd/(p.dashCdMax||G.st.dashCd||1);ctx.globalAlpha=.6;ctx.strokeStyle='#8fe9ff';ctx.lineWidth=2.5;ctx.beginPath();ctx.arc(PX,PY,R,-Math.PI/2,-Math.PI/2+TAU*f);ctx.stroke();}
    ctx.globalAlpha=1;
    const C=G.combo;if(typeof comboOn==='function'&&comboOn()&&C&&C.n>1){ctx.font='700 14px "JetBrains Mono",monospace';ctx.textAlign='center';const s_='×'+C.mul.toFixed(2).replace('.',',');ctx.fillStyle='#04060c';ctx.fillText(s_,PX+1,PY-R-9);ctx.fillStyle='#ffb84d';ctx.fillText(s_,PX,PY-R-10);}}
  if(G.resumeK>0){const k=G.resumeK/1.2,b=Math.floor(G.resumeK/.4);ctx.globalAlpha=(b%2?.45:.9);ctx.strokeStyle='#8fe9ff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(PX,PY,30+k*30,0,TAU);ctx.stroke();
    ctx.font='700 16px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#8fe9ff';ctx.fillText(String(Math.ceil(G.resumeK/.4)),PX,PY-48);ctx.globalAlpha=1;}
}
"""
R("// ---- вход в мир / выход в миссию ----",OV+"// ---- вход в мир / выход в миссию ----")

open(P,'w',encoding='utf8').write(s)
print('m3 ok')
