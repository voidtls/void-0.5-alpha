# 1.2.4 α · интерфейс от телефона до 4K, переключатели, закрываемые сообщения. Каждый тест падает на версии 25.
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
W0="""T.fresh();const S=G.save;S.cleared=10;for(let m=1;m<=10;m++)S.medals[m]={clear:1};S.gate=true;saveWorld();const n=WORLD.nodes.find(q=>q.m===5);enterWorldAt(n.x+300,n.y+200);for(let i=0;i<10;i++)worldUpdate(1/60);"""
RECT="""const R=s=>{const e=typeof s==='string'?document.querySelector(s):s;if(!e)return null;const r=e.getBoundingClientRect();return [r.left,r.top,r.width,r.height].map(v=>+v.toFixed(1));};"""
VPS={'lap':(1366,768),'fhd':(1920,1080),'qhd':(2560,1440),'uhd':(3840,2160),'uw':(3440,1440),'sw':(5120,1440)}

@test('U01')
async def u01(b):
    out={}
    for k,(w,h) in VPS.items():
        P=await newpage(b,vw=w,vh=h,alpha=False);out[k]=await P.js("()=>typeof UI==='number'?UI:null");await P.pg.context.close()
    P=await newpage(b,vw=390,vh=844,touch=True,alpha=False);out['pp']=await P.js("()=>typeof UI==='number'?UI:null");await P.pg.context.close()
    want={'lap':1,'fhd':1,'qhd':1.35,'uhd':2,'uw':1.35,'sw':1.35,'pp':1}
    rec('U01 число UI: 1366/1080p 1,0 · 1440p 1,35 · 4K 2,0 · 21:9 и 32:9 1,35 · телефон 1,0',out==want,out)

@test('U02')
async def u02(b):
    res={}
    for k in ['fhd','uhd']:
        w,h=VPS[k];P=await newpage(b,vw=w,vh=h,alpha=False)
        res[k]=await P.js("()=>{"+W0+RECT+"toast('А','б');return {pause:R('#btnPause'),hp:R('.hud-tl'),toast:R('#toast'),radio:null}}");await P.pg.context.close()
    k2=lambda a,bb,i:bb[i]/a[i] if a and bb and a[i] else 0
    r=[k2(res['fhd'][x],res['uhd'][x],2) for x in ['pause','hp','toast']]+[k2(res['fhd']['pause'],res['uhd']['pause'],3)]
    rec('U02 4K: кнопка паузы, полоса корпуса и тост ровно вдвое крупнее, чем на 1080p (±3%)',all(abs(x-2)<.06 for x in r),{'k':[round(x,3) for x in r],**res})

@test('U03')
async def u03(b):
    res={}
    for k in ['fhd','uhd']:
        w,h=VPS[k];P=await newpage(b,vw=w,vh=h,alpha=False)
        res[k]=await P.js("()=>{"+W0+"""const fonts=[];const f=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,'font');const g=ctx;
          const ft=g.fillText;g.fillText=function(t,x,y){if(/МИССИЯ|а\\.е\\./.test(String(t)))fonts.push(parseFloat(this.font.match(/(\\d+(?:\\.\\d+)?)px/)[1]));return ft.apply(this,arguments);};
          renderWorld(performance.now());g.fillText=ft;const m=document.getElementById('mini').getBoundingClientRect();return {arrowFont:fonts[0]||0,mini:Math.round(m.width)};}""");await P.pg.context.close()
    ok=res['fhd']['arrowFont']>0 and abs(res['uhd']['arrowFont']/res['fhd']['arrowFont']-2)<.05 and abs(res['uhd']['mini']/res['fhd']['mini']-2)<.05
    rec('U03 канвас-HUD: подпись стрелки у края и мини-карта растут с UI',ok,res)

@test('U04')
async def u04(b):
    w,h=VPS['sw'];P=await newpage(b,vw=w,vh=h,alpha=False)
    r=await P.js("()=>{"+W0+RECT+"""const hud=R('#hud');const st=Math.min(CW,Math.round(CH*21/9));T.go(3);for(let i=0;i<20;i++)update(1/60);return {hud,stage:st,arena:G.arena&&[G.arena.w,G.arena.h],VW:Math.round(VW),VH:Math.round(VH)}}""")
    await P.pg.context.close()
    w2,h2=VPS['fhd'];P=await newpage(b,vw=w2,vh=h2,alpha=False);r2=await P.js("()=>{T.fresh();T.openAll();T.go(3);return {arena:G.arena,W:Math.round(W),VW:Math.round(VW)}}");await P.pg.context.close()
    ok=abs(r['hud'][2]-r['stage'])<2 and abs(r['hud'][0]-(w-r['stage'])/2)<2 and r['arena'] and abs(r['arena'][0]/r['arena'][1]-21/9)<.02 and r2['arena'] is None and r2['W']==r2['VW']
    rec('U04 32:9: HUD в сцене 21:9 по центру, арена миссии 21:9; на 16:9 всё по-старому',ok,{'sw':r,'fhd':r2})

@test('U05')
async def u05(b):
    P=await newpage(b,vw=1920,vh=1080,alpha=False)
    r=await P.js("()=>{const a=[Math.round(VW),Math.round(VH)];return a}")
    await P.pg.set_viewport_size({'width':3840,'height':2160});await P.pg.wait_for_timeout(400)
    r2=await P.js("()=>[Math.round(VW),Math.round(VH),UI,getComputedStyle(document.documentElement).getPropertyValue('--ui').trim()]")
    ok=r==r2[:2] and r2[2]==2 and r2[3]=='2'
    rec('U05 игровое поле на 16:9 одинаково; смена размера окна пересчитывает UI без перезагрузки',ok,{'fhd':r,'uhd':r2})

@test('U06')
async def u06(b):
    P=await newpage(b,vw=2560,vh=1440,alpha=False)
    r=await P.js("()=>{toMenu();openSettings('menu');const seg=document.querySelector('[data-seg=\"uiSize\"]');if(!seg)return {seg:false};seg.querySelector('[data-v=\"1.25\"]').click();const u=UI;const v=store('void_settings');return {seg:true,u,saved:v&&v.uiSize}}")
    pt=await P.js("()=>{toMenu();openSettings('menu');if(typeof tabGo63==='function')tabGo63('scr');const b=document.querySelector('[data-seg=\"uiSize\"] [data-v=\"1\"]');const r=b.getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]}") if r.get('seg') else [0,0]
    if r.get('seg'):await P.pg.mouse.click(pt[0],pt[1]);await P.pg.wait_for_timeout(100)
    u2=await P.js("()=>typeof UI==='number'?UI:null")
    rec('U06 настройка «Интерфейс 90/АВТО/110/125%»: меняет UI, сохраняется; клик по кнопке попадает при UI≠1',r.get('seg') and abs(r['u']-1.65)<.03 and r['saved']==1.25 and u2==1.35,{**r,'u2':u2})

@test('U07')
async def u07(b):
    P=await newpage(b,vw=1024,vh=1366,touch=True,alpha=False)
    r=await P.js("()=>{G.input='touch';ffUpdate();resize();"+W0+"""const chips=document.querySelector('.hud-b .chips');return {ff:G.ff,chips:chips?getComputedStyle(chips).display!=='none'&&chips.offsetParent!==null:false,tbr:Object.keys(TBR).length,mob:document.documentElement.classList.contains('mob')}}""")
    rec('U07 планшет 1024×1366: планшетная раскладка, только тач-кнопки',r['ff']=='tablet' and r['mob'] and r['tbr']>0,r)

@test('S01')
async def s01(b):
    out=[]
    for vp in [(1280,800,False),(390,844,True)]:
        P=await newpage(b,vw=vp[0],vh=vp[1],touch=vp[2],alpha=False)
        for where in ['menu','pause']:
            r=await P.js("(w)=>{if(w==='pause'){T.fresh();T.openAll();T.go(3);G.state='pause';openSettings('pause');}else{toMenu();openSettings('menu');}"+"""
              return [...document.querySelectorAll('.tog[data-k]')].filter(b=>b.offsetParent).map(b=>{const s=b.querySelector('.sw').getBoundingClientRect(),k=getComputedStyle(b.querySelector('.sw'),'::after');const m=new DOMMatrix(k.transform);const L=s.left+1+parseFloat(k.left)+m.m41,R=L+parseFloat(k.width);
                return [b.dataset.k,b.classList.contains('on'),+(L-s.left).toFixed(1),+(s.right-R).toFixed(1)]})}""",where)
            out.append([vp[0],where,r])
        await P.pg.context.close()
    bad=[(a,w,x) for a,w,rr in out for x in rr if (x[3] if x[1] else x[2])>4 or (x[3] if x[1] else x[2])<2]
    rec('S01 все переключатели (меню и пауза, ПК и телефон): бегунок у своего края, 3±1 px',bool(out) and all(rr for _,_,rr in out) and not bad,{'bad':bad[:4],'n':sum(len(rr) for _,_,rr in out)})

@test('S02')
async def s02(b):
    # 1.5.10: детерминированный замер. Раньше тест ждал 90 мс по настенным часам и попадал в случайную точку перехода
    # (0 / 17,5–19,8 / 20,8 px — 6 падений из 12). Теперь клик и остановка перехода — в одной задаче, время ставится ровно 90 мс.
    # Ожидаемое положение считается по самой кривой cubic-bezier(.3,1.4,.5,1) и длине хода 20 px: у кривой есть перелёт, поэтому 20,98 px.
    def bz(a,c,t):return 3*(1-t)**2*t*a+3*(1-t)*t*t*c+t**3
    lo,hi=0.0,1.0
    for _ in range(60):
        m_=(lo+hi)/2
        if bz(.3,.5,m_)<.5:lo=m_
        else:hi=m_
    want=20*bz(1.4,1,lo)
    P=await newpage(b,alpha=False)
    await P.js("()=>{SET.sfx=false;saveSet();toMenu();openSettings('menu');return 1}")
    mid=await P.js("""()=>{document.querySelector('.tog[data-k="sfx"]').click();const b=document.querySelector('.tog[data-k="sfx"]'),sw=b.querySelector('.sw');getComputedStyle(sw,'::after').transform;
      const an=document.getAnimations().filter(a=>a.effect&&a.effect.target===sw&&a.effect.pseudoElement==='::after'&&a.transitionProperty==='transform');
      if(!an.length)return {n:0,aria:b.getAttribute('aria-checked')};const a=an[0];a.pause();const T=a.effect.getComputedTiming().duration;
      a.currentTime=90;const m=new DOMMatrix(getComputedStyle(sw,'::after').transform).m41;a.currentTime=T;const end=new DOMMatrix(getComputedStyle(sw,'::after').transform).m41;a.finish();
      return {n:an.length,T,m:+m.toFixed(3),end,aria:b.getAttribute('aria-checked')};}""")
    await P.pg.wait_for_timeout(300)
    await P.pg.focus('.tog[data-k="sfx"]');await P.pg.keyboard.press('ArrowLeft');await P.pg.wait_for_timeout(300)
    kb=await P.js("()=>{const b=document.querySelector('.tog[data-k=\"sfx\"]');return [SET.sfx,b.getAttribute('aria-checked'),document.activeElement===b]}")
    rec('S02 бегунок едет: переход 180 мс, на 90 мс — точка кривой (с перелётом), в конце — у края, aria-checked верный; стрелка влево выключает, фокус остаётся',mid.get('n')==1 and mid['T']==180 and abs(mid['m']-want)<=.5 and abs(mid['end']-20)<=.01 and mid['aria']=='true' and kb==[False,'false',True],{'mid':mid,'ожидание':round(want,3),'kb':kb})

DX0="()=>{"+W0+"return 1}"
@test('D01')
async def d01(b):
    P=await newpage(b,alpha=False);await P.js(DX0)
    res={}
    await P.js("()=>{toast('А','б');return 1}");await P.pg.wait_for_timeout(300)
    r=await P.js("()=>{const r=document.getElementById('toast').getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]}");await P.pg.mouse.click(r[0],r[1]);await P.pg.wait_for_timeout(260);res['toast']=await P.js("()=>document.getElementById('toast').hidden")
    await P.js("()=>{fragShow('цитата',2);return 1}");await P.pg.wait_for_timeout(400)
    r=await P.js("()=>{const e=document.querySelector('#fragTxt .fbox');if(!e)return [0,0];const r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]}");await P.pg.mouse.click(r[0],r[1]);await P.pg.wait_for_timeout(260);res['frag']=await P.js("()=>!document.getElementById('fragTxt').classList.contains('on')")
    await P.js("()=>{const st=radioState();radioSayTxt({txt:'раз',tag:'Т',col:'#8fe9ff'});st.q.push({txt:'два',tag:'Т',col:'#8fe9ff',d:.3});return 1}");await P.pg.wait_for_timeout(400)
    r=await P.js("()=>{const r=radioEl().getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]}");await P.pg.mouse.click(r[0],r[1]);await P.pg.wait_for_timeout(260)
    res['radio1']=await P.js("()=>radioEl().hidden");await P.js("()=>{for(let i=0;i<40;i++)worldUpdate(1/60);return 1}");res['radio2']=await P.js("()=>!radioEl().hidden&&radioEl().textContent.includes('Т')")
    rec('D01 нажатие скрывает тост, фрагмент и строку радио ≤ 250 мс; очередь радио идёт дальше',all(res.values()),res)

@test('D02')
async def d02(b):
    P=await newpage(b,alpha=False);await P.js(DX0)
    await P.js("()=>{toast('А','б');return 1}");await P.pg.wait_for_timeout(300)
    r=await P.js("()=>{const r=document.getElementById('toast').getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]}")
    await P.pg.mouse.move(r[0],r[1]);await P.pg.mouse.down();md=await P.js("()=>[MOUSE.down,G.state]");await P.pg.mouse.up()
    rec('D02 клик по сообщению не стреляет и не ставит паузу',md==[False,'world'],{'md':md})

@test('D03')
async def d03(b):
    P=await newpage(b,alpha=False)
    r=await P.js("()=>{T.fresh();T.openAll();SET.manual=true;T.go(3);G.waveHold=999;const e=spawnEnemy('gunner',G.player.x+160,G.player.y,{noAffix:true});e.spawnT=0;e.hp=e.maxHp=1e7;for(let i=0;i<20;i++)update(1/60);toast('А','б');return 1}")
    await P.pg.wait_for_timeout(500)
    q=await P.js("()=>{const t=document.getElementById('toast'),r=t.getBoundingClientRect(),x=t.querySelector('.dx');const xr=x?x.getBoundingClientRect():null;return {aim:document.documentElement.classList.contains('dxaim'),c:[r.x+r.width/2,r.y+r.height/2],x:xr&&[xr.x+xr.width/2,xr.y+xr.height/2]}}")
    await P.pg.mouse.move(q['c'][0],q['c'][1]);await P.pg.mouse.down();await P.pg.wait_for_timeout(30);shot=await P.js("()=>[MOUSE.down,!document.getElementById('toast').hidden]");await P.pg.mouse.up()
    closed=None
    if q['x']:await P.pg.mouse.click(q['x'][0],q['x'][1]);await P.pg.wait_for_timeout(260);closed=await P.js("()=>document.getElementById('toast').hidden")
    rec('D03 прицел мышью + враги: клик по телу тоста — выстрел, крестик закрывает',q['aim'] and shot==[True,True] and closed,{**q,'shot':shot,'closed':closed})

@test('D04')
async def d04(b):
    P=await newpage(b,alpha=False);await P.js(DX0)
    await P.js("()=>{toast('А','б');return 1}")
    r=await P.js("()=>{const r=document.getElementById('toast').getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]}")
    await P.pg.wait_for_timeout(60);await P.pg.mouse.click(r[0],r[1]);await P.pg.wait_for_timeout(200);early=await P.js("()=>!document.getElementById('toast').hidden")
    await P.pg.mouse.move(r[0],r[1]);await P.pg.wait_for_timeout(8500);held=await P.js("()=>!document.getElementById('toast').hidden")
    await P.pg.mouse.move(3,3)
    await P.js("()=>{fragShow('ц',1);return 1}");await P.pg.wait_for_timeout(5200);ev=await P.js("()=>{const e=document.querySelector('#fragTxt .fbox');return [document.getElementById('fragTxt').classList.contains('on'),e?getComputedStyle(e).pointerEvents:'?']}")
    rec('D04 первые 250 мс не закрывается; наведение держит тост дольше 8 с; отыгравший фрагмент не ловит клики',early and held and ev[0]==False and ev[1]=='none',{'early':early,'held':held,'frag':ev})

@test('D05')
async def d05(b):
    P=await newpage(b,vw=390,vh=844,touch=True,alpha=False);await P.js(DX0)
    cdp=await P.pg.context.new_cdp_session(P.pg)
    async def swipe(x,y,dx,steps=6):
        await cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
        for i in range(1,steps+1):
            await cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x+dx*i/steps,'y':y}]});await P.pg.wait_for_timeout(20)
        await cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
    await P.js("()=>{toast('А','б');return 1}");await P.pg.wait_for_timeout(400)
    r=await P.js("()=>{const r=document.getElementById('toast').getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]}")
    await swipe(r[0],r[1],-20,10);await P.pg.wait_for_timeout(400);back=await P.js("()=>!document.getElementById('toast').hidden")
    await swipe(r[0],r[1],-60);await P.pg.wait_for_timeout(400);gone=await P.js("()=>document.getElementById('toast').hidden")
    rec('D05 телефон: свайп 60 px уносит тост, 20 px — возвращает на место',back and gone,{'back':back,'gone':gone})

@test('M01')
async def m01(b):
    P=await newpage(b,vw=844,vh=390,touch=True,alpha=False)
    r=await P.js("()=>{"+W0+"""const labs=[];const ft=ctx.fillText;ctx.fillText=function(t,x,y){if(/а\\.е\\./.test(String(t)))labs.push([String(t),x,y,this.measureText(t).width]);return ft.apply(this,arguments);};
      renderWorld(performance.now());ctx.fillText=ft;const rs=hudRects?hudRects():[];
      const bad=labs.filter(([t,x,y,w])=>rs.some(q=>x+w/2>q[0]&&x-w/2<q[2]&&y+3>q[1]&&y-9<q[3]));
      const wl=[];const f2=ctx.fillText;return {labs:labs.length,bad:bad.length}}""")
    P2=await newpage(b,vw=390,vh=844,touch=True,alpha=False)
    r2=await P2.js("()=>{"+W0+"""const out=[];const ft=ctx.fillText;ctx.fillText=function(t,x,y){const m=ctx.getTransform();if(/·/.test(String(t))&&m.a!==DPR){const w=this.measureText(t).width;const X=m.a*x+m.e,Xl=(m.a*(x-w/2)+m.e)/DPR,Xr=(m.a*(x+w/2)+m.e)/DPR;out.push([String(t).slice(0,20),+Xl.toFixed(0),+Xr.toFixed(0)]);}return ft.apply(this,arguments);};
      for(const dx of [-420,-300,300,420]){G.player.x+=dx;camSnap();renderWorld(performance.now());G.player.x-=dx;}ctx.fillText=ft;return out.filter(q=>q[2]>0&&q[1]<CW&&(q[1]<0||q[2]>CW)).slice(0,4)}""")
    rec('M01 телефон: подпись стрелки не ложится на кнопки; подписи мира не обрезаются краем',r['labs']>0 and r['bad']==0 and not r2,{**r,'clip':r2})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q180.json'))
