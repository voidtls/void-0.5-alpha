
// ===== 0.9.5: новые враги сектора X — Клякса, Переписчик, Отливник, Стёртый пилот =====
// --- Клякса: три прыжка, круг приземления, чернильные пятна, брызги после третьего ---
function blotAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;if(e.bs95===undefined){e.bs95='idle';e.bt95=rnd(1,1.8);e.bj95=0;}
  if(e.bs95==='idle'){const m=clamp((pd-220)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.5*e.dir,pdy/pd*m+pdx/pd*.5*e.dir,e.spd*.6*c.sm,dt,2);e.bt95-=dt;if(e.bt95<=0&&pd<560&&p.hp>0){e.bj95=0;blotJump95(e);}return;}
  if(e.bs95==='squat'){e.vx*=.8;e.vy*=.8;e.bt95-=dt;if(e.bt95<=0){e.bs95='air';e.at95=0;e.ax0=e.x;e.ay0=e.y;snd95('hop',e.x);}return;}
  if(e.bs95==='air'){e.at95+=dt;const u=clamp(e.at95/.5,0,1);e.x=e.ax0+(e.lx-e.ax0)*u;e.y=e.ay0+(e.ly-e.ay0)*u;e.hz95=Math.sin(u*Math.PI)*44;e.vx=e.vy=0;
    if(u>=1){e.hz95=0;e.bj95++;snd95('splat',e.x);const Z=ez100();if(Z.filter(z=>z.by&&z.by.type==='blot95').length<6)Z.push({x:e.x,y:e.y,r:50,tele:0,t:4,by:e,ink95:1});
      if(e.bj95>=3){if(G.world||onScreen(e))for(let i=0;i<8;i++)eb95(e.x,e.y,i/8*TAU+e.seed,210,8*first90(e),C95.blot,6,'ink');snd95('splat',e.x);e.bs95='idle';e.bt95=2.6;}
      else blotJump95(e);}}}
function blotJump95(e){const p=G.player;let tx=p.x+p.vx*.35+rnd(-40,40),ty=p.y+p.vy*.35+rnd(-40,40);const d=Math.hypot(tx-e.x,ty-e.y),mx=230;if(d>mx){tx=e.x+(tx-e.x)/d*mx;ty=e.y+(ty-e.y)/d*mx;}
  if(!G.world){tx=clamp(tx,40,W-40);ty=clamp(ty,40,H-40);}e.lx=tx;e.ly=ty;e.bs95='squat';e.bt95=.3;
  tg95({k:'zone',x:tx,y:ty,r:50,T:.8,dmg:12,col:C95.blot,src:e,key:'blot95',snd:e.bj95?false:'tlZone',fx:false});}
// --- Переписчик: строка символов висит 1,2 с, потом летит веером; импульс стирает строку целиком ---
let LID95=0;
function scribeAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;if(e.wr95===undefined)e.wr95=rnd(2,3.5);
  if(e.wq95){const Q=e.wq95;e.vx*=.85;e.vy*=.85;Q.t-=dt;while(Q.t<=0&&Q.i<Q.n){Q.t+=.09;const u=Q.n>1?Q.i/(Q.n-1)-.5:0,x=Q.cx+Q.px*u*Q.L,y=Q.cy+Q.py*u*Q.L;
      const b=eb95(x,y,0,.001,8*first90(e),C95.scribe,6,'sym',{ch:GLYPH95[Math.random()*GLYPH95.length|0],line95:e.line95,hold95:1.2+(Q.n-1-Q.i)*.09,go95:scribeGo95});if(b)b.life=12;Q.i++;if(Q.i===1)snd95('write',e.x);}
    if(Q.i>=Q.n)e.wq95=null;return;}
  const m=clamp((pd-300)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.6*e.dir,pdy/pd*m+pdx/pd*.6*e.dir,e.spd*c.sm,dt,2.5);if(Math.random()<dt*.25)e.dir*=-1;
  e.wr95-=dt;e.charging=e.wr95<.4;if(e.wr95<=0&&pd<640&&p.hp>0){e.wr95=5.2;e.line95=++LID95;const a=Math.atan2(pdy,pdx),L=150,cx=e.x+Math.cos(a)*50,cy=e.y+Math.sin(a)*50;e.wq95={n:7,i:0,t:0,cx,cy,px:-Math.sin(a),py:Math.cos(a),L};tlog95('scribe95',1.2);tel90use('scribe95');}}
function scribeGo95(b){const p=G.player;if(!p)return;const a=Math.atan2(p.y-b.y,p.x-b.x)+rnd(-.06,.06);b.vx=Math.cos(a)*260;b.vy=Math.sin(a)*260;b.frz95=0;if(Math.random()<.2)snd95('fling',b.x);}
function scribeErase95(p,R){const ids=new Set();for(const b of G.eb)if(b.line95&&b.hold95>0&&Math.hypot(b.x-p.x,b.y-p.y)<R+40)ids.add(b.line95);if(!ids.size)return;let n=0;
  for(const b of G.eb)if(b.line95&&ids.has(b.line95)&&b.life>0){b.life=0;n++;glyph95(b.x,b.y,1,C95.scribe);}if(n){floater(p.x,p.y-50,'СТРОКА СТЁРТА · '+n,C95.scribe);snd95('fade95',p.x);}}
// --- Отливник: язык пустоты от края, стрельба с кончика; гибель очищает края на 6 с ---
function ebbEdge95(e){const ds=[e.x,W-e.x,e.y,H-e.y];let k=0;for(let i=1;i<4;i++)if(ds[i]<ds[k])k=i;return k;}
function ebbAI95(e,dt,c){const p=G.player;if(e.eg95===undefined){e.eg95=G.world?-1:ebbEdge95(e);e.sh95=rnd(1.5,2.5);}
  let ex=e.x,ey=e.y,nx=0,ny=0;if(e.eg95>=0){const k=e.eg95;if(k===0){ex=0;ey=e.y;nx=1;}else if(k===1){ex=W;ey=e.y;nx=-1;}else if(k===2){ex=e.x;ey=0;ny=1;}else{ex=e.x;ey=H;ny=-1;}
    const along=k<2?clamp(p.y,80,H-80):clamp(p.x,80,W-80),depth=200+30*Math.sin(G.t*.8+e.seed),tx=k<2?ex+nx*depth:along,ty=k<2?along:ey+ny*depth;
    steer(e,(k<2?tx:along)-e.x,(k<2?along:ty)-e.y,e.spd*c.sm,dt,2);if(k<2)e.x=clamp(e.x,Math.min(ex,ex+nx*260),Math.max(ex,ex+nx*260));else e.y=clamp(e.y,Math.min(ey,ey+ny*260),Math.max(ey,ey+ny*260));e.tg95={x1:k<2?ex:e.x,y1:k<2?e.y:ey,x2:e.x,y2:e.y};}
  else{const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,m=clamp((pd-300)/120,-1,1);steer(e,pdx/pd*m,pdy/pd*m,e.spd*c.sm,dt,2);e.tg95={x1:e.x-pdx/pd*200,y1:e.y-pdy/pd*200,x2:e.x,y2:e.y};}
  e.sh95-=dt;e.charging=e.sh95<.45;if(e.sh95<=0&&p.hp>0){e.sh95=2.6;const a=Math.atan2(p.y-e.y,p.x-e.x);if(G.world||onScreen(e))for(let i=-1;i<=1;i++)eb95(e.x,e.y,a+i*.16,250,8*first90(e),C95.ebb,6,'ink');snd95('spit',e.x);}}
function tongueBuild95(){const X=G.x90;const L=[];for(const e of G.enemies)if(e.alive&&e.type==='ebb95'&&e.tg95&&e.spawnT<=0)L.push({x1:e.tg95.x1,y1:e.tg95.y1,x2:e.tg95.x2,y2:e.tg95.y2,w:70,e});if(X&&inMission())X.tongue95=L;else G.wtongue95=L;}
function ebbGone95(e,silent){const X=G.x90;if(e.tg95&&!silent){const s=e.tg95;for(let i=0;i<=8;i++){const u=i/8;glyph95(s.x1+(s.x2-s.x1)*u,s.y1+(s.y2-s.y1)*u,1,C95.ebb);}}
  if(!silent&&X&&inMission()&&X.er){X.er.clrT95=6;X.er.clr95=1;floater(e.x,e.y-30,'ЯЗЫК СХЛОПНУЛСЯ · КРАЯ ЧИСТЫ 6 С',C95.ebb);snd95('fade95',e.x);}}
// --- Стёртый пилот: летает по вашим правилам — рывок (откат 1,5 с), импульс, заряд; роняет жетон ---
const LOSTN95=['ЛЕВ','ИРА','ТИМУР','ВАРЯ','ОЛЕГ','НИКА','ДАН','ЕВА','РОМАН','СОНЯ','ГЛЕБ','ЯНА'];
function lostSkin95(){const S=G.save,own=(S&&S.ownSkins||[]).filter(k=>SKINS[k]&&k!==curSkin());return own.length?own[Math.random()*own.length|0]:'base';}
function lostAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;
  if(!e.lp95){e.lp95=1;e.skin95=lostSkin95();e.nm95=LOSTN95[Math.random()*LOSTN95.length|0]+' · '+String(100+Math.random()*899|0);e.dcd95=1.5;e.pcd95=5;e.ccd95=4;e.fcd95=1;e.elite95=1;e.face=Math.atan2(pdy,pdx);}
  if(e.dcd95>0)e.dcd95-=dt;if(e.pcd95>0)e.pcd95-=dt;if(e.ccd95>0)e.ccd95-=dt;
  e.face=Math.atan2(pdy,pdx);
  if(e.dsh95){const D=e.dsh95;D.t-=dt;if(D.st==='aim'){e.vx*=.8;e.vy*=.8;if(D.t<=0){D.st='go';D.t=.16;e.vx=Math.cos(D.a)*1450;e.vy=Math.sin(D.a)*1450;e.inv95=.16;snd95('pilotDash',e.x);}}else{if(SET.fx)part(e.x,e.y,-e.vx*.1,-e.vy*.1,.3,C95.lost,2.2);if(D.t<=0){e.dsh95=null;e.dcd95=1.5;e.vx*=.2;e.vy*=.2;}}return;}
  if(e.chg95){const C=e.chg95;C.t-=dt;e.vx*=.9;e.vy*=.9;C.a+=clamp(angDiff(Math.atan2(pdy,pdx),C.a),-.8*dt,.8*dt);if(C.t<=0){e.chg95=null;e.ccd95=5;const b=shootE(e.x+Math.cos(C.a)*16,e.y+Math.sin(C.a)*16,C.a,900,18*first90(e),'#ffffff',7);snd95('beamFire',e.x);trauma90(.12);}return;}
  if(e.pls95){const P=e.pls95;P.t-=dt;e.vx*=.85;e.vy*=.85;if(P.t<=0){e.pls95=null;e.pcd95=7;wv95({x:e.x,y:e.y,v:620,w:12,dmg:12*first90(e),col:C95.lost,R:170});snd95('pilotPulse',e.x);trauma90(.15);for(const b of G.pb)if(Math.hypot(b.x-e.x,b.y-e.y)<170)b.life=0;}return;}
  // решения
  if(e.dcd95<=0&&(pd<160||Math.random()<dt*.5)&&p.hp>0){const side=Math.random()<.5?-1:1,a=Math.atan2(pdy,pdx)+side*1.1;e.dsh95={st:'aim',t:.45*tel90('lost95'),a};e.tl95=e.dsh95.t;snd95('tlDash',e.x);tlog95('lostDash',e.dsh95.t);return;}
  if(e.pcd95<=0&&pd<175&&p.hp>0){e.pls95={t:.6};e.tl95=.6;snd95('tlRing',e.x);tlog95('lostPulse',.6);return;}
  if(e.ccd95<=0&&pd<620&&pd>180&&p.hp>0){e.chg95={t:1.2,a:Math.atan2(pdy,pdx)};e.tl95=1.2;tlog95('lostCharge',1.2);return;}
  const m=clamp((pd-260)/100,-1,1);steer(e,pdx/pd*m-pdy/pd*.7*e.dir,pdy/pd*m+pdx/pd*.7*e.dir,e.spd*c.sm,dt,3);if(Math.random()<dt*.35)e.dir*=-1;
  e.fcd95-=dt;e.charging=e.fcd95<.3;if(e.fcd95<=0){e.fcd95=1.4;e.fb95=3;e.fbT95=0;}
  if(e.fb95>0){e.fbT95-=dt;if(e.fbT95<=0){e.fb95--;e.fbT95=.12;shootE(e.x,e.y,Math.atan2(pdy,pdx)+rnd(-.05,.05),480,6*first90(e),C95.lost,4);}}}
function lostDrop95(e){const X=G.x90;const L=X&&inMission()?(X.loot95||(X.loot95=[])):(G.wloot95||(G.wloot95=[]));L.push({k:'tag',x:e.x,y:e.y,t:0,nm:e.nm95||'ПИЛОТ'});floater(e.x,e.y-30,'ЖЕТОН · '+(e.nm95||''),C95.lost);}
