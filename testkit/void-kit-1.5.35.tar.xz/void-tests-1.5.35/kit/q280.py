# 1.3.4 α «Дорога домой». Каждый тест падает на v34 (1.3.3).
import asyncio,json,sys,os
from h import *
exec(open(SP+'q270.py').read().split("@test('Y01')")[0].split("TESTS=[]")[1].replace("def test(name):","def _unused(name):"))
NEW=open(SP+'q210.py').read().split('NEW="""')[1].split('"""')[0]
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
# настоящая дорога: миссия → экран победы → кнопка «дальше» → сектор
REAL="""()=>{window.WIN1=async(m)=>{T.go(m);missionComplete();await w8(700);$('#bNext').click();for(let i=0;i<30&&G.state!=='world';i++)await w8(50);};
window.arrowLab=()=>{if(TUT.cur&&TUT.cur.k==='stash')return 'СКЛАД';const a=tut133HoldNext()?tut134Home():nextTarget();return a?a.label:null;};
window.killPatrol=()=>{for(const z of (G.zones||[]).concat(typeof W58!=='undefined'&&W58.zones||[])){if(z){z.active=false;z.cool=1e6;}}G.enemies.forEach(e=>{if(e.zone)e.alive=false;});G.save.tut.done.patrol=1;if(TUT.cur&&TUT.cur.k==='patrol')tutEnd('abort');TUT.gap=0;};return 1;}"""
async def mk2(b,w=1280,h=720,touch=False):
    P=await mk(b,w,h,touch=touch);await P.js(REAL);return P

@test('Z01')
async def z01(b):
    out={}
    for (w,h,t) in [(1280,720,False),(390,844,True)]:
        P=await mk2(b,w,h,t)
        out[f'{w}x{h}']=await P.js("""async()=>{done('move','act','patrol');await WIN1(1);killPatrol();const t0=performance.now();let on=false;while(performance.now()-t0<2500){if(curK()==='stash'){on=true;break;}await w8(30);}const lat=Math.round(performance.now()-t0);
          await w8(300);const txt=chipTxt(),ringLom=ringOn($('#wLom')),arrow=arrowLab();
          radioLine('ПЕРЕХВАТ','#8fe9ff','Пилот, проверка связи. Склад рядом — загляните, там ваша награда. Повторяю, склад рядом.');await w8(1500);const inRadio=curK();
          if(TUT.cur)TUT.cur.t=120;await w8(400);const after120=curK();
          const s=tutShopPt();await flyTo(s.x,s.y,200,45000);await w8(500);const T=G.save.tut;
          return {on,lat,txt,ringLom,arrow,inRadio,after120,done:!!T.done.stash,ok:!!(T.ok&&T.ok.stash),lomDone:!!T.done.lom,arrow2:arrowLab()}}""")
    ok=all(v['on'] and v['lat']<1800 and 'НАГРАДА' in v['txt'] and v['ringLom'] and v['arrow']=='СКЛАД' and v['inRadio']=='stash' and v['after120']=='stash' and v['done'] and v['ok'] and v['arrow2']=='МИССИЯ 02' for v in out.values())
    rec('Z01 после миссии 01 (через экран победы): ≤1,8 с — «НАГРАДА — НА СКЛАДЕ», кольцо на счётчике, стрелка «СКЛАД»; радио и 2 минуты не гасят; долетел — стрелка «МИССИЯ 02» (ПК и телефон)',ok,out)

@test('Z02')
async def z02(b):
    P=await mk2(b)
    r=await P.js("""async()=>{done('move','act');await WIN1(1);const seen=[];const t0=performance.now();while(performance.now()-t0<3000){const k=curK();if(k&&seen[seen.length-1]!==k)seen.push(k);await w8(50);}
      const arrowDuring=arrowLab();killPatrol();const back=await waitCur('stash',4000);return {seen,arrowDuring,back}}""")
    ok=r['back'] and r['arrowDuring']=='СКЛАД'
    rec('Z02 патруль у миссии 01 ненадолго перебивает дорогу домой; стрелка всё это время — «СКЛАД», после боя дорожка возвращается',ok,r)

@test('Z03')
async def z03(b):
    P=await mk2(b)
    r=await P.js("""async()=>{done('move','act','patrol');await WIN1(1);killPatrol();await waitCur('stash',2500);const a1=arrowLab();
      await WIN1(2);killPatrol();await w8(2500);const seen=curK();return {a1,seen,done:!!G.save.tut.done.stash,ok:!!(G.save.tut.ok&&G.save.tut.ok.stash),a2:arrowLab()}}""")
    ok=r['a1']=='СКЛАД' and r['seen']!='stash' and r['done'] and not r['ok'] and r['a2']=='МИССИЯ 03'
    rec('Z03 не заехал на склад и прошёл миссию 02 — дорога домой закрыта без галочки, стрелка ведёт к миссии 03',ok,r)

@test('Z04')
async def z04(b):
    P=await mk2(b)
    r=await P.js("""async()=>{done('move','act','patrol','lom','stash','calib');const p=G.player;p.en=100;const s=tutShopPt();p.x=s.x+120;p.y=s.y+120;const w=[];let t0=performance.now();while(performance.now()-t0<3000){if(curK())w.push(curK());await w8(50);}
      T.go(1);const m1=[];t0=performance.now();while(performance.now()-t0<3000){const p=G.player;p.en=100;p.hp=G.st.maxHp;if(!G.enemies.some(e=>e.alive&&Math.hypot(e.x-p.x,e.y-p.y)<300)){spawnEnemy('scout',p.x+200,p.y,{});}if(curK())m1.push(curK());await w8(50);}
      restoreRun();returnToWorld();await w8(300);G.save.cleared=1;T.go(2);const m2=[];t0=performance.now();while(performance.now()-t0<4000){const p=G.player;p.en=100;p.hp=G.st.maxHp;if(!G.enemies.some(e=>e.alive&&Math.hypot(e.x-p.x,e.y-p.y)<300)){spawnEnemy('scout',p.x+200,p.y,{});spawnEnemy('scout',p.x-150,p.y,{});}if(curK())m2.push(curK());await w8(50);}
      return {world:[...new Set(w)],m1:[...new Set(m1)],m2:[...new Set(m2)]}}""")
    ok=not any(k in r['world'] for k in ['energy','pulse']) and not any(k in r['m1'] for k in ['energy','pulse']) and any(k in r['m2'] for k in ['energy','pulse'])
    rec('Z04 импульс: у склада и в миссии 01 подсказки нет; в бою миссии 02 с врагами рядом — есть',ok,r)

@test('Z05')
async def z05(b):
    out={}
    for (w,h,t) in [(1280,720,False),(390,844,True)]:
        P=await mk2(b,w,h,t)
        out[f'{w}x{h}']=await P.js("""async()=>{const S=G.save;openMap();await w8(900);const lab=jumpPoints().map(q=>q.label);const hg=WORLD.hangar,sh=WORLD.shops[0];
          G.mapView.cx=sh.x;G.mapView.cy=sh.y;await w8(400);return {rev:[revealedAt(sh.x,sh.y),revealedAt(hg.x,hg.y)],M:lab.includes('М'),A:lab.includes('А')}}""")
        await P.pg.screenshot(path=SP+f'shots/z05_{w}x{h}.png')
    ok=all(v['M'] and v['A'] and not all(v['rev']) for v in out.values())
    rec('Z05 новый пилот, туман: склад «М» и «Хранилище корпусов» «А» уже на карте и доступны для прыжка',ok,out)

@test('Z06')
async def z06(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("()=>({ver:VER_TAG,tag:$('#verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.3.4 α</dt>')})")
    rec('Z06 версия 1.3.4 α и запись в журнале',r['ver']=='1.3.4 α' and r['tag']=='1.3.4 α' and r['log'],r)

if __name__=='__main__':
    sel=sys.argv[1:]
    if sel:TESTS=[t for t in TESTS if t[0] in sel]
    asyncio.run(run(TESTS,'q280'))
