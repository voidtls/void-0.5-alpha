# 0.9.6 · часть 19: доводка «до идеала» — часы Сердца, кульминация фазы 4, тревога без спирали
import sys
SP='@@KIT@@/'
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m19: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
B96=open(SP+'b96.js',encoding='utf8').read()
R('// ---------- Главный цикл ----------',B96+'\n// ---------- Главный цикл ----------')

# --- 1. Часы Сердца: реальное время делится на подшаги (телефон 30 к/с бил вдвое чаще), без кадра — обычный dt ---
R("const dt=hsK90(G.resumeK>0&&(G.state==='play'||G.state==='world')?dt0*.3:dt0,dt0),sub=isMob()&&SET.fps===30&&dt>.025?2:1;",
  "const dt=hsK90(G.resumeK>0&&(G.state==='play'||G.state==='world')?dt0*.3:dt0,dt0),sub=isMob()&&SET.fps===30&&dt>.025?2:1;G.rdtU96=(devOn('speed')?2:1)*sub;G.rdt90=(G.rdt90||dt)/sub;")
R("update(b,dt){heartGeo(b);const p=G.player;const rdt=G.rdt90||dt,A=atk95(b);",
  "update(b,dt){heartGeo(b);const p=G.player;const rdt=G.rdtU96>0?(G.rdtU96--,G.rdt90||dt):dt,A=atk95(b);")

# --- 2. Сердце: пул +20%, фаза 4 — три круга ключей (Лёгкая — два), квоты, гарантированный финал ---
R("SBX.heart={K:1.08,th:[.7,.4,.15],mc:'heart90',","SBX.heart={K:1.3,th:[.7,.4,.15],mc:'heart90',")
R("radioLine('КОВЧЕГ',C90.ark,'Остановка. Затопление камеры. Ручной запуск: ключи по порядку, в такт.',.4);",
  "b.lN96=rk90()<=0?2:3;b.keyA96=0;b.rot96=0;b.fin96=0;radioLine('КОВЧЕГ',C90.ark,'Остановка. Затопление камеры. Ручной запуск: ключи по порядку, в такт. Запусков нужно '+b.lN96+'.',.4);")
R("if(e===b){if(b.phase>=4){const L=b.launch>0;pool85(b,dmg*(L?(b.autoK?1.4:2.5):.15),L?0:.03,e);",
  "if(e===b){if(b.phase>=4){const L=b.launch>0;if(L&&b.fin96)return 0;pool85(b,dmg*(L?(b.autoK?1.4:2.5):.15),L?heartQuota96(b,Math.max(1,b.launches)):heartQuota96(b,b.launches+1)+.01,e);if(L&&!b.fin96&&b.hp<=b.maxHp*heartQuota96(b,Math.max(1,b.launches))+1&&b.launch>.7)b.launch=.7;")
R("if(b.launch>0){b.launch-=dt;b.openK=Math.min(1,b.openK+dt*4);if(b.launch<=0){b.launch=0;b.autoK=0;floater(b.cx,b.cy-b.r-30,'СЕРДЦЕ ЗАКРЫЛОСЬ','#ffffff');}}",
  "if(b.launch>0){heartFinTick96(b,dt);if(b.st!=='fight')return;b.launch-=dt;b.openK=Math.min(1,b.openK+dt*4);if(b.launch<=0){b.launch=0;b.autoK=0;heartSeq96(b);}}")
R("if(b.phase>=4){heartKeyTouch(b);heartKeyCheck(b);b.p4T+=dt;\n      if(b.launch<=0){b.dry=Math.max(220*b.k,b.dry-(b.R-220*b.k)/40*dt);",
  "if(b.phase>=4){if(b.rot96&&b.launch<=0){b.keyA96=(b.keyA96||0)+b.rot96*dt;heartKeyPos96(b);}heartKeyTouch(b);heartKeyCheck(b);b.p4T+=dt;\n      if(b.launch<=0){b.dry=Math.max(220*b.k,b.dry-(b.R-220*b.k)/Math.max(18,40-9*b.launches)*dt);")
R("if(!auto){const chunk=b.maxHp*b.th[2]*.25;b.chunkN++;const h0=b.hp;pool85(b,chunk,0,b);floater(b.cx,b.cy+b.r+30,'ЗАПУСК · −'+Math.round(h0-b.hp),'#ffffff');}\n  banner(auto?'СЕРДЦЕ СДАЁТСЯ':'ЗАПУСК '+b.launches,auto?'СЕРДЦЕ ОТКРЫТО · 4 С · УРОН ×1,4':'СЕРДЦЕ ОТКРЫТО · 4 С · УРОН ×2,5');",
  "const fin=b.launches>=(b.lN96||2);b.fin96=fin?1:0;\n  if(!auto&&!fin){const lq=heartQuota96(b,b.launches),chunk=Math.min(b.maxHp*.03,Math.max(0,b.hp-b.maxHp*lq));b.chunkN++;const h0=b.hp;pool85(b,chunk,lq,b);floater(b.cx,b.cy+b.r+30,'ЗАПУСК · −'+Math.round(h0-b.hp),'#ffffff');}else if(!auto)b.chunkN++;\n  if(fin){banner('ПОСЛЕДНИЙ ЗАПУСК','СЕРДЦЕ РВЁТ РИТМ · 4 СЕКУНДЫ');radioLine('КОВЧЕГ',C90.ark,'Ритм… восстановлен? Нет. Он больше не мой.',.1);}\n  else banner(auto?'СЕРДЦЕ СДАЁТСЯ':'ЗАПУСК '+b.launches+' ИЗ '+(b.lN96||2),auto?'СЕРДЦЕ ОТКРЫТО · 4 С · УРОН ×1,4':'СЕРДЦЕ ОТКРЫТО · 4 С · УРОН ×2,5');")
R("'КЛЮЧИ РИТМА · ЗАПУСКОВ '+b.launches+'/2'","'КЛЮЧИ · ЗАПУСКИ '+b.launches+'/'+(b.lN96||2)")
R("r:'ЗАПУСКИ '+b.launches+'/2'","r:'ЗАПУСКИ '+b.launches+'/'+(b.lN96||2)")
R("if(q.type==='hkey90'){const a=-Math.PI/2+q.ki*TAU/b.keyN;","if(q.type==='hkey90'){const a=-Math.PI/2+q.ki*TAU/b.keyN+(b.keyA96||0);")
R("floorTxt(b){return b.phase>=4?'СЕРДЦЕ СТОИТ · ЗАПУСТИТЕ КЛЮЧАМИ':null;}","floorTxt(b){return b.phase>=4&&!(b.launch>0)?'СЕРДЦЕ СТОИТ · ЗАПУСТИТЕ КЛЮЧАМИ':null;}")

# --- 3. Тревога: переходы 30/60 ловятся и от постоянного роста; рост в бою 0,5/с, спад в тишине 2,5/с, в затишье 5/с;
#        облава — 3 Фагоцита раз в 30 с, тревога падает до 55; сбитый Фагоцит облавы −4; облава не держит волну ---
R("function alarm90(v,why,x,y){const X=G.x90;if(!X||!X.alarmOn||G.endT>0||!inMission())return;const a0=X.alarm;",
  "function alarm90(v,why,x,y,aP){const X=G.x90;if(!X||!X.alarmOn||G.endT>0||!inMission())return;const a0=aP!==undefined?aP:X.alarm;")
R("if(X.alarmOn&&G.endT<=0&&p&&p.hp>0){const quiet=G.t-(G.lastFire90||-9)>2;X.alarm=clamp(X.alarm+(quiet?-1:1.0*X.alarmK)*dt,0,100);if(X.al90T>0)X.al90T-=dt;alarm90(0);",
  "if(X.alarmOn&&G.endT<=0&&p&&p.hp>0){const quiet=G.t-(G.lastFire90||-9)>1.5,calm=quiet&&!G.enemies.some(e=>e.alive&&!EDEF[e.type].passive&&targetable(e));const aP=X.alarm;X.alarm=clamp(X.alarm+(calm?-5:quiet?-2.5:.5*X.alarmK)*dt,0,100);if(X.al90T>0)X.al90T-=dt;alarm90(0,0,undefined,undefined,aP);")
R("if(X.alarm>=90&&!(X.al90T>0)){X.al90T=20;X.alarm=70;","if(X.alarm>=90&&!(X.al90T>0)){X.al90T=30;X.alarm=55;")
R("const n=Math.max(0,Math.min(4,6-G.enemies.filter(o=>o.alive&&o.type==='phago90').length));for(let i=0;i<n;i++)edgeSpawn('phago90',{delay:i*.25});",
  "const n=Math.max(0,Math.min(3,6-G.enemies.filter(o=>o.alive&&o.type==='phago90').length));for(let i=0;i<n;i++)edgeSpawn('phago90',{delay:i*.25,ob96:1});")
R("banner('ТРЕВОГА 90','ОБЛАВА · ФАГОЦИТЫ');","banner('ТРЕВОГА 90','ОБЛАВА · СБЕЙТЕ ИХ — СТАНЕТ ТИШЕ');")
# табличка первой встречи ждёт, пока сойдёт баннер (не больше 2,8 с): текст не ложится на текст
R("if(X.plq){X.plq.t+=dt;if(X.plq.t>4.4)X.plq=null;}}","if(X.plq){if(!(banT>0&&X.plq.t<.01&&(X.plq.w96=(X.plq.w96||0)+dt)<2.8))X.plq.t+=dt;if(X.plq.t>4.4)X.plq=null;}}")
R("glDraw95();markPlayerDraw95(t);}","glDraw95();markPlayerDraw95(t);ob96Draw(t);}")
R("const k=b.keys[b.keyI];if(k){worldLabel(b.cx,b.cy+b.r+30,'КЛЮЧ '+['I','II','III','IV'][b.keyI]+' · ПРОЛЕТИТЕ В ТАКТ','#ffffff');",
  "const k=b.keys[b.keyI];if(k){worldLabel(b.cx,b.cy+b.r+30,'КЛЮЧ '+['I','II','III','IV'][k.ki]+(b.rot96?' · ЛОВИТЕ НА ХОДУ':b.launches===1?' · ОБРАТНЫЙ ПОРЯДОК':' · ПРОЛЕТИТЕ В ТАКТ'),'#ffffff');")
# лимит видов — сразу при появлении и для волн без особых опций (раньше такие ждали первого хода ИИ)
R("function spawned95(e,w){if(!w||!w.o)return;","function spawned95(e,w){if(!w||!w.o){if(e&&typeof cap90==='function')cap90(e);return;}if(w.o.ob96)e.ob96=1;")
R("function s90Killed(e,silent){const X=G.x90;","function s90Killed(e,silent){const X=G.x90;if(e.ob96&&!silent&&X&&X.alarmOn&&inMission()){alarm90(-4);floater(e.x,e.y-26,'ТИШЕ · −4',C90.warm);}")
R("const alive=G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive).length+G.warns.length;","const alive=G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive).length+G.warns.length,aliveW=alive-(G.x90&&G.x90.alarmOn?ob96N():0);")
R("if(G.spawnT<=0&&alive<G.waveCap){","if(G.spawnT<=0&&aliveW<G.waveCap){")
R("alive<=Math.max(SSw?2:1,Math.floor(G.waveSize*.3))","aliveW<=Math.max(SSw?2:1,Math.floor(G.waveSize*.3))")
R("Тревога растёт сама и от того, что вас видят: на 30 — больше Фагоцитов, на 60 — враги быстрее, на 90 — облава.",
  "Тревога растёт в бою и от того, что вас видят, а в затишье быстро спадает: на 30 — больше Фагоцитов, на 60 — враги быстрее, на 90 — облава. Сбейте Фагоцитов облавы — станет тише.")
R("На третьей волне — «Разряд»: ганглий 15 секунд бьёт четырьмя вращающимися лучами.'",
  "На третьей волне — «Разряд»: ганглий 15 секунд бьёт четырьмя вращающимися лучами. Тревога здесь та же: в бою растёт, в затишье спадает, облаву гасите, сбивая её Фагоцитов.'")

# --- 4. Иммунный страж: после удара щитом мембрана опущена 1,2 с и открыто окно ✦; поворот 1,6 рад/с — обойти можно;
#        элита-страж ×1,5 прочности (мембрана и так удваивает время боя) ---
R("if(e.bash95){const B=e.bash95;B.t-=dt;e.vx*=.8;e.vy*=.8;if(B.t<=0){e.bash95=null;e.vx=Math.cos(e.fa95)*360;e.vy=Math.sin(e.fa95)*360;}return;}",
  "if(e.bash95){const B=e.bash95;B.t-=dt;e.vx*=.8;e.vy*=.8;if(B.t<=0){e.bash95=null;e.vx=Math.cos(e.fa95)*360;e.vy=Math.sin(e.fa95)*360;e.mb95=Math.max(e.mb95||0,1.2);weak95(e,1.2,1.5);if(!e.gw96){e.gw96=1;floater(e.x,e.y-e.r-14,'ПОСЛЕ УДАРА МЕМБРАНА ОПУЩЕНА ✦','#ffffff');}}return;}")
R("e.fa95+=clamp(angDiff(Math.atan2(pdy,pdx),e.fa95),-2.1*dt,2.1*dt);","e.fa95+=clamp(angDiff(Math.atan2(pdy,pdx),e.fa95),-1.6*dt,1.6*dt);")
R("if(w.o.e95){e.elite95=1;e.hp*=2;","if(w.o.e95){e.elite95=1;e.hp*=e.type==='guard95'?1.5:2;")

R("EDEF.valve90.hp=90;EDEF.neuron90.hp=34;EDEF.embryo90.hp=19;","EDEF.valve90.hp=90;EDEF.neuron90.hp=34;EDEF.embryo90.hp=19;EDEF.guard95.hp=130;")

# миссия 41: старый «Охотник» уступает место новым Лейкоцитам-охотникам (две роли «охотника» в одной миссии дублировали друг друга
# и давали миссии на треть больше прочности, чем соседним)
R("(function genMissions(){","if(SEC_WAVES[41])SEC_WAVES[41].old=SEC_WAVES[41].old.map(t=>t==='hunter'?'mite':t);\n(function genMissions(){")

# --- 5. Звук по замеру (K-взвешенная громкость, au96): удар сердца давал 77% громкости звуков боя и равнялся музыке —
#        −3 дБ и короткий «щелчок» 1,25 кГц, чтобы удар слышали и динамики телефона; «чирк» Ластика −4 дБ; слёзы Смотрителя −2,5 дБ ---
R("case 'beat':{const k=v===undefined?1:v;tone(58,40,.32,'sine',.42*k);noise(.18,.22*k,300);tone(52,38,.26,'sine',.28*k,.2);noise(.12,.12*k,260,'lowpass',.2);break;}",
  "case 'beat':{const k=(v===undefined?1:v)*.7;tone(58,40,.32,'sine',.42*k);noise(.18,.22*k,300);tone(52,38,.26,'sine',.28*k,.2);noise(.12,.12*k,260,'lowpass',.2);tone(1250,700,.035,'triangle',.03*k);break;}")
R("case 'streak':noise(.5,.18,3000,'highpass',0,800);tone(1200,300,.4,'sawtooth',.025);break;","case 'streak':noise(.5,.11,3000,'highpass',0,800);tone(1200,300,.4,'sawtooth',.018);break;")
R("case 'tears':noise(1,.12,5000,'highpass',0,1200);tone(880,440,1,'sine',.03);break;","case 'tears':noise(1,.09,5000,'highpass',0,1200);tone(880,440,1,'sine',.026);break;")

# --- 6. Виньетка сектора из кэша (см. secVigSpr96 в b96.js) ---
R("function secVignette(){const SS=secScale();if(!SS||!G.player||G.state==='menu')return;ctx.setTransform(1,0,0,1,0,0);const k=SS.ice?Math.min(1,.35+.3*(G.ice||0)+(G.frozen>0?.6:0)):.35,CW_=cv.width,CH_=cv.height;\n  const g=ctx.createRadialGradient(CW_/2,CH_/2,Math.min(CW_,CH_)*.45,CW_/2,CH_/2,Math.max(CW_,CH_)*.72);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,SS.ice?`rgba(191,232,255,${.22*k*COLD_A})`:SS.brood?`rgba(255,107,138,${.14+.04*Math.sin(G.t*TAU/1.2)})`:SS.mercy?'rgba(120,135,160,.2)':SS.bureau?`rgba(232,210,122,${.1+.05*(G.bo80||0)})`:SS.ark?`rgba(216,54,74,${.12+.08*beat90(G.t)})`:SS.shore?'rgba(122,255,201,.08)':SS.source?`rgba(107,140,255,${.12+.03*Math.sin(G.t*TAU/3)})`:`rgba(138,58,18,${.18+.015*wearPct()})`);\n  ctx.globalAlpha=isMob()?.67:1;ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);ctx.globalAlpha=1;}",
  "function secVignette(){const SS=secScale();if(!SS||!G.player||G.state==='menu')return;ctx.setTransform(1,0,0,1,0,0);const k=SS.ice?Math.min(1,.35+.3*(G.ice||0)+(G.frozen>0?.6:0)):.35,CW_=cv.width,CH_=cv.height;\n  const V=SS.ice?['191,232,255',.22*k*COLD_A]:SS.brood?['255,107,138',.14+.04*Math.sin(G.t*TAU/1.2)]:SS.mercy?['120,135,160',.2]:SS.bureau?['232,210,122',.1+.05*(G.bo80||0)]:SS.ark?['216,54,74',.12+.08*beat90(G.t)]:SS.shore?['122,255,201',.08]:SS.source?['107,140,255',.12+.03*Math.sin(G.t*TAU/3)]:['138,58,18',.18+.015*wearPct()];\n  const a=clamp(V[1],0,1)*(isMob()?.67:1);if(a<=.002)return;ctx.globalAlpha=a;ctx.drawImage(secVigSpr96(V[0],CW_,CH_),0,0,CW_,CH_);ctx.globalAlpha=1;}")

# телефон в альбомной: баннер ниже полосы босса и чуть мельче — не ложится на строку HUD
R(".ff-phone-p #banner{top:calc(var(--sat) + 224px)}",".ff-phone-p #banner{top:calc(var(--sat) + 224px)}\n.ff-phone-l #banner{top:calc(var(--sat) + 78px)}\n.ff-phone-l #banner b{font-size:22px}")

# подпись тени прошлого босса не ложится на баннер «ТЕНЬ · …» (тот же текст, на телефоне — в одной строке у горизонта)
R("    worldLabel(s.x,s.y-s.r-30,'ТЕНЬ · '+s.name95+' · '+Math.ceil(s.life95),c);ctx.globalAlpha=1;}","    if(!(banT>0))worldLabel(s.x,s.y-s.r-30,'ТЕНЬ · '+s.name95+' · '+Math.ceil(s.life95),c);ctx.globalAlpha=1;}")

# версия и хроника версий
R('<div class="eyebrow">АЛЬФА 0.9.5 · СЕРДЦЕ И БЕРЕГ 2.0</div>','<div class="eyebrow">АЛЬФА 0.9.6 · СЕРДЦЕ И БЕРЕГ 2.0</div>')
R('<dl class="kv"><dt>0.9.5 α</dt>','<dl class="kv"><dt>0.9.6 α</dt><dd>Доводка «до идеала». Сердце стало проходимым: кольцевая волна без проходов шла на каждый удар, а рывок перезаряжается дольше такта — теперь у каждой волны есть проход: в первой фазе вдоль сосудов, во второй он плывёт, в третьей безопасно там, где совпадают проходы двух колец; фибрилляция идёт без обычных ударов, проход — по оранжевой стрелке. Часы Сердца идут по реальному времени и на телефоне с 30 кадрами — раньше оно билось там вдвое чаще. Кульминация «Остановки»: три круга ключей — по порядку, наоборот и плывущие, — а последний запуск разрывает ритм за 4 секунды при любом оружии. Тревога больше не раскручивается в спираль: облава — три Фагоцита раз в 30 секунд, каждый сбитый снимает 4, в затишье шкала быстро спадает, а переходы на 30 и 60 срабатывают всегда. Иммунный страж после удара щитом на 1,2 секунды опускает мембрану (✦), миссия 41 стала вдвое короче, а последние враги больше не прячутся: шлюзы на финальной зачистке открываются насовсем, а вошедший в арену враг уже не уйдёт за её край. Корректор в миссии 44 доводит ремонт: обход строк ведёт его к цели, а не к вам. Звук сведён по замеру громкости: удар сердца тише и теперь слышен в динамике телефона, «чирк» Ластика и слёзы Смотрителя тише. Виньетка сектора берётся из кэша, а ядро ганглия снова рисуется векторами — миссия 41 на слабом телефоне на четверть легче. Табличка новой встречи не ложится на баннер, баннер в альбомной — ниже полосы босса.</dd><dt>0.9.5 α</dt>')

# --- 7. Сердце: у каждой волны есть проход (см. heartGaps в b96.js; прежняя функция удаляется) ---
R("function heartGaps(b){const n=2,w=(rk90()>=2?30:40)*Math.PI/180,g=[];const a0=rnd(0,TAU);for(let i=0;i<n;i++)g.push({a:a0+i*Math.PI+rnd(-.5,.5),w});return g;}","")
R("if(b.phase===3){b.curGaps=b.nextGaps||heartGaps(b);b.nextGaps=heartGaps(b);const gd=(Math.random()<.5?-1:1)*15*Math.PI/180;b.waves.push({r:b.r,v:sp,gaps:b.curGaps.map(g=>({a:g.a,w:g.w})),hit:false,dmg:10,gd});b.dbl=.25;b.dblGd=-gd;}",
  "if(b.phase===3){b.curGaps=heartGaps(b,0);b.nextGaps=heartGaps(b,1);b.waves.push({r:b.r,v:sp,gaps:b.curGaps.map(g=>({a:g.a,w:g.w})),hit:false,dmg:10,gd:0});b.dbl=.25;}")
R("  else b.waves.push({r:b.r,v:sp,gaps:null,hit:false,dmg:10});","  else{b.curGaps=heartGaps(b,0);b.nextGaps=heartGaps(b,1);b.waves.push({r:b.r,v:sp,gaps:b.curGaps.map(g=>({a:g.a,w:g.w})),hit:false,dmg:10});}")
R("if(b.dbl>0){b.dbl-=dt;if(b.dbl<=0&&b.phase===3){const g=(b.curGaps||[]).map(q=>({a:q.a+Math.PI/2,w:q.w}));b.waves.push({r:b.r,v:300*b.k,gaps:g,hit:false,dmg:10,gd:b.dblGd||0});snd90('beat',.7);}}",
  "if(b.dbl>0){b.dbl-=dt;if(b.dbl<=0&&b.phase===3){const g=(b.curGaps||[]).map(q=>({a:q.a+(b.gdir96||1)*heartOff96(),w:q.w}));b.waves.push({r:b.r,v:300*b.k,gaps:g,hit:false,dmg:10,gd:0});snd90('beat',.7);}}")
R("b.fibT=20;b.fib=3;b.fibI=0;banner('ФИБРИЛЛЯЦИЯ','3 СЕКУНДЫ · МЕЛКИЕ ВОЛНЫ');","b.fibT=20;b.fib=3;b.fibI=0;b.fibA96=rnd(0,TAU);banner('ФИБРИЛЛЯЦИЯ','3 СЕКУНДЫ · ПРОХОД — ПО ОРАНЖЕВОЙ СТРЕЛКЕ');")
R("if(b.fibI<=0){b.fibI=.3;const a=rnd(0,TAU);b.waves.push({r:b.r,v:400*b.k,gaps:[{a,w:70*Math.PI/180}],hit:false,dmg:6,thin:1,gd:0});}",
  "if(b.fibI<=0){b.fibI=.3;const a=(b.fibA96!==undefined?b.fibA96:rnd(0,TAU))+rnd(-.1,.1);b.waves.push({r:b.r,v:400*b.k,gaps:[{a,w:70*Math.PI/180}],hit:false,dmg:6,thin:1,gd:0});}")
R("b.waves.push({r:b.r,v:340*b.k,gaps:null,hit:false,dmg:14});trauma90(.15);","b.waves.push({r:b.r,v:340*b.k,gaps:heartGaps(b,0),hit:false,dmg:14});trauma90(.15);")
R("if(b.phase===3){b.thrT-=dt*A;","if(b.phase===3){heartDrift96(b,dt);b.thrT-=dt*A;")
R("b.thrT=5;b.fibT=16;b.nextGaps=heartGaps(b);","b.thrT=5;b.fibT=16;b.gth96=b.ves[0].a;b.gdir96=1;b.gfl96=8;b.nextGaps=heartGaps(b,1);")
R("banner('СЕРДЦЕ · ФАЗА 2','АРИТМИЯ · КЛАПАНЫ СТРЕЛЯЮТ');","banner('СЕРДЦЕ · ФАЗА 2','АРИТМИЯ · КЛАПАНЫ СТРЕЛЯЮТ · ПРОХОДЫ ПЛЫВУТ');b.gth96=b.ves[0].a;b.gdir96=1;b.gfl96=8;")
R("if(b.phase===2){b.arrT-=dt*A;","if(b.phase===2){heartDrift96(b,dt);b.arrT-=dt*A;")
R("if(b.phase===3&&b.nextGaps&&b.st==='fight'){const k=clamp(b.bt/b.btN,0,1);gapArrows95(b.cx,b.cy,b.R-18,b.nextGaps,k,'#ffffff');gapArrows95(b.cx,b.cy,b.R-18,b.nextGaps.map(g=>({a:g.a+Math.PI/2,w:g.w})),k*.5,'#ffe9b0');}",
  "if(b.phase>=2&&b.phase<=3&&b.nextGaps&&b.st==='fight'){const k=clamp(b.bt/b.btN,0,1),R0=b.r+40*b.k;gapArrows95(b.cx,b.cy,R0,b.nextGaps,k,'#ffffff');if(b.phase===3)gapArrows95(b.cx,b.cy,R0,b.nextGaps.map(g=>({a:g.a+(b.gdir96||1)*heartOff96(),w:g.w})),k*.5,'#ffe9b0');}\n  if(b.fib>0&&b.fibA96!==undefined&&b.st==='fight')gapArrows95(b.cx,b.cy,b.r+40*b.k,[{a:b.fibA96,w:70*Math.PI/180}],1,'#ff9a4d');")
R("Сердце бьётся: на сжатии закрыто и гонит волну (рывок сквозь — без урона), на расслаблении открыто.","Сердце бьётся: на сжатии закрыто и гонит волну, на расслаблении открыто. Волна обходит сосуды: в первой фазе держитесь прохода вдоль них, дальше проходы плывут — стрелки у сердца показывают, где они будут. Рывок сквозь волну — без урона.")
R("Бьётся тактами: на систоле закрыто и гонит волну, на диастоле открыто,","Бьётся тактами: на систоле закрыто и гонит волну — проходы в ней вдоль сосудов (в фазе 2 два прохода плывут, в фазе 3 плывут быстрее, а второй удар сдвинут — стойте там, где проходы совпадают), на диастоле открыто,")

# фибрилляция — это не удары: пока она идёт (3 с), обычные кольца, бич, дождь и тельца молчат, есть только мелкие волны с проходом по оранжевой стрелке
R("if(b.st!=='fight')return;const A=atk95(b),p=G.player;","if(b.st!=='fight'||b.fib>0)return;const A=atk95(b),p=G.player;")
R("if(b.dbl>0){b.dbl-=dt;if(b.dbl<=0&&b.phase===3){","if(b.dbl>0){b.dbl-=dt;if(b.dbl<=0&&b.phase===3&&!(b.fib>0)){")

# враги за краем арены (все миссии, кроме уходящих по замыслу) возвращаются внутрь и больше не выходят (см. rescue96)
R("function t90Tick(dt){const X=G.x90;if(!X||!inMission())return;const p=G.player;X.t+=dt;feel90(dt);mod90Tick(dt);","function t90Tick(dt){const X=G.x90;if(!X||!inMission())return;const p=G.player;X.t+=dt;feel90(dt);mod90Tick(dt);rescue96(dt);")

# финальная зачистка: шлюзы открыты насовсем, последние враги обведены (см. fin96Tick/fin96Draw)
R("function lockCyc90(L){const E=G.x90&&G.x90.ev95;if(E&&E.k==='quar'&&E.t>0)return 'closed';","function lockCyc90(L){const E=G.x90&&G.x90.ev95;if(G.x90&&G.x90.fin96)return 'open';if(E&&E.k==='quar'&&E.t>0)return 'closed';")
R("feel90(dt);mod90Tick(dt);rescue96(dt);","feel90(dt);mod90Tick(dt);capEarly96();rescue96(dt);fin96Tick(X);")
R("glDraw95();markPlayerDraw95(t);ob96Draw(t);}","glDraw95();markPlayerDraw95(t);ob96Draw(t);fin96Draw(t);}")

# Корректор чинит союзника, а не летит к вам: обход строк-стен (nav95) вёл его к игроку со скоростью 130 px/с,
# и ремонт в миссии 44 срывался в трети случаев — теперь обход строится к цели ремонта
R("if(e.spawnT<=0&&!e.passive95)nav95(e,X,dt,p);}","if(e.spawnT<=0&&!e.passive95)nav95(e,X,dt,e.type==='fixer100'&&e.fx&&e.fx.alive?e.fx:p);}")

# ядро ганглия — векторами вместо поворота больших спрайтов (см. coreVec96)
R("const A=coreSpr95(q,0),R=q.r*1.15,z=1+.04*pk;ctx.save();ctx.rotate(t*.2);ctx.drawImage(A,-R*z,-R*z,R*2*z,R*2*z);ctx.restore();","const z=1+.04*pk;ctx.save();ctx.rotate(t*.2);ctx.scale(z,z);coreVec96(q,0);ctx.restore();")
R("const B=coreSpr95(q,1);ctx.save();ctx.rotate(t*.4);ctx.drawImage(B,-R,-R,R*2,R*2);ctx.restore();","ctx.save();ctx.rotate(t*.4);coreVec96(q,1);ctx.restore();")

R("// ядро ганглия — два слоя-спрайта (диск с красными жилами и жёлтые нервы), вращаются и пульсируют без перерисовки путей","// ядро ганглия — два слоя векторами (диск с красными жилами и жёлтые нервы): на слабом телефоне поворот больших спрайтов стоил втрое дороже путей (0.9.6)")

# события уровня (ev95) и Сердце порождают врагов уже после первого прохода лимита — второй проход в конце тика миссии
R("  if(typeof t95Tick==='function')t95Tick(dt);\n  seen90Tick(dt);hud90();}","  if(typeof t95Tick==='function')t95Tick(dt);capEarly96();\n  seen90Tick(dt);hud90();}")

open(P,'w',encoding='utf8').write(s)
print('m19 ok')
