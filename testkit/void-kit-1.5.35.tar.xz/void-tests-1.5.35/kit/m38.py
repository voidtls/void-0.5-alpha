# 1.2.4 α · переключатели и закрываемые сообщения
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
a="const t=e.target;if(t&&t.tagName&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))return;"
assert s.count(a)==1
s=s.replace(a,a+"if(t&&t.matches&&t.matches('.tog[data-k]')&&(e.code==='ArrowLeft'||e.code==='ArrowRight'))return;")
css=open(D+'m38.css',encoding='utf8').read();i=s.rindex('</style>');s=s[:i]+css+s[i:]
js=open(D+'m38.js',encoding='utf8').read();i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m38 ok')
