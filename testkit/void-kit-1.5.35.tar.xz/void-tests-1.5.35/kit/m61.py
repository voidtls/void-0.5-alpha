# 1.3.5 α «Один курс» — стрелки у края экрана: одна цель — одна стрелка, подписи не наслаиваются, обводка не отстаёт от текста
import sys
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m61 FAIL',n,a[:80]);sys.exit(1)
    s=s.replace(a,b)
R('<div class="ver" id="verTag">1.3.4 α</div>','<div class="ver" id="verTag">1.3.5 α</div>')
R("const VER_TAG='1.3.4 α';","const VER_TAG='1.3.5 α';")
R("upd:'после первой миссии дорога сначала ведёт домой, на склад; импульс — в бою второй миссии; склад и хранилище всегда на карте.'",
  "upd:'одна цель — одна стрелка: курс с карты и стрелка к миссии больше не двоятся, подписи у края экрана не слипаются.'")
R('<dl class="kv"><dt>1.3.4 α</dt>','<dl class="kv"><dt>1.3.5 α</dt><dd>«Один курс». Если проложить на карте курс к той же цели, куда и так ведёт стрелка (например, к следующей миссии), у края экрана рисовались две стрелки и две подписи друг на друге — «КУРС · МИССИЯ 06» и «МИССИЯ 06» сливались в кашу. Теперь одна цель — одна стрелка: курс с карты главнее, повторная стрелка не рисуется (то же для лома, аномалии и подсказок обучения). Подписи разных стрелок, указывающих в одну сторону, встают одна под другой. На телефоне, когда подпись отодвигается от кнопок «ИМП» и «РЫВОК», её тёмная обводка раньше оставалась на старом месте и выглядела чёрной размытой надписью — теперь обводка переезжает вместе с текстом.</dd><dt>1.3.4 α</dt>')
# порядок: курс игрока первым — он главнее; повтор той же цели отбрасывается
R("const arrow=(x,y,col,label)=>{if(isMob()){","const arrow=(x,y,col,label)=>{if(arw61Dup(x,y))return;if(isMob()){")
R("  const nt=zbOn()?null:tut133HoldNext()?tut134Home():nextTarget();if(nt)arrow(nt.x,nt.y,nt.col,nt.label);\n  if(S.lost)arrow(S.lost.x,S.lost.y,'#ff4f6e','ЛОМ');\n  if(G.course){if(Math.hypot(G.course.x-p.x,G.course.y-p.y)<240){G.course=null;floater(p.x,p.y-44,'ВЫ НА МЕСТЕ','#8fe9ff');}else arrow(G.course.x,G.course.y,'#8fe9ff','КУРС · '+G.course.label);}",
  "  if(G.course){if(Math.hypot(G.course.x-p.x,G.course.y-p.y)<240){G.course=null;floater(p.x,p.y-44,'ВЫ НА МЕСТЕ','#8fe9ff');}else arrow(G.course.x,G.course.y,'#8fe9ff','КУРС · '+G.course.label);}\n  const nt=zbOn()?null:tut133HoldNext()?tut134Home():nextTarget();if(nt)arrow(nt.x,nt.y,nt.col,nt.label);\n  if(S.lost)arrow(S.lost.x,S.lost.y,'#ff4f6e','ЛОМ');")
# ПК: подпись стрелки встаёт под соседнюю, а не на неё
R("{const tx=clamp(ex-Math.cos(a)*34*UI,stageL()+70*UI,CW-stageL()-70*UI),ty=ey-(Math.sin(a)*22-4)*UI;ctx.lineJoin='round';ctx.lineWidth=4*UI;ctx.strokeStyle='rgba(4,6,12,.92)';ctx.strokeText(label+' · '+dd,tx,ty);ctx.fillText(label+' · '+dd,tx,ty);}",
  "{const tl=label+' · '+dd,tx=clamp(ex-Math.cos(a)*34*UI,stageL()+70*UI,CW-stageL()-70*UI),ty=lab61Place(tx,ey-(Math.sin(a)*22-4)*UI,ctx.measureText(tl).width/2+4,10*UI);ctx.lineJoin='round';ctx.lineWidth=4*UI;ctx.strokeStyle='rgba(4,6,12,.92)';ctx.strokeText(tl,tx,ty);ctx.fillText(tl,tx,ty);}")
# подсказки обучения: та же цель уже со стрелкой — свою не рисуют; подпись — в свободное место
R("const edge=(x,y,col,lab)=>{const [X,Y]=tutSP(x,y);if(onScr(X,Y,20))return false;","const edge=(x,y,col,lab)=>{const [X,Y]=tutSP(x,y);if(onScr(X,Y,20))return false;if(arw61Dup(x,y))return true;")
R("ty=ey-(Math.sin(a)*22-4)*u;c.lineJoin='round'","ty=lab61Place(tx,ey-(Math.sin(a)*22-4)*u,c.measureText(tl).width/2+4,10*u);c.lineJoin='round'")
# телефон: подпись, отодвинутая от кнопок, переезжает вместе с обводкой; соседние подписи учитываются; места нет — остаётся на месте, а не пропадает
R("""{const _ea2=edgeArrow;edgeArrow=function(x,y,col,size,label){if(!isMob()||!label)return _ea2(x,y,col,size,label);
  const calls=[],ft=ctx.fillText;ctx.fillText=function(t,a,b){calls.push([t,a,b,this.fillStyle]);};let r;try{r=_ea2(x,y,col,size,label);}finally{ctx.fillText=ft;}
  if(!calls.length)return r;const [t0,a0,b0]=calls[calls.length-1],w=ctx.measureText(t0).width/2+4,h=9,rs=hudRects();
  const hit=(cx,cy)=>cx-w<SAFE.l+4||cx+w>CW-SAFE.r-4||rs.some(q=>cx+w>q[0]&&cx-w<q[2]&&cy+3>q[1]&&cy-h<q[3]);
  let best=null;if(!hit(a0,b0))best=[a0,b0];else for(const d of [16,-16,30,-30,44,-44,60,-60,80,-80,100,-100]){if(!hit(a0,b0+d)){best=[a0,b0+d];break;}if(!hit(a0+d*1.5,b0)){best=[a0+d*1.5,b0];break;}}
  if(best){const dx=best[0]-a0,dy=best[1]-b0;for(const c of calls){const fs=ctx.fillStyle;ctx.fillStyle=c[3];ft.call(ctx,c[0],c[1]+dx,c[2]+dy);ctx.fillStyle=fs;}}
  return r;};}""",
"""{const _ea2=edgeArrow;edgeArrow=function(x,y,col,size,label){if(!isMob()||!label)return _ea2(x,y,col,size,label);
  const calls=[],ft=ctx.fillText,st=ctx.strokeText;ctx.fillText=function(t,a,b){calls.push(['f',t,a,b,this.fillStyle]);};ctx.strokeText=function(t,a,b){calls.push(['s',t,a,b,this.strokeStyle,this.lineWidth,this.lineJoin]);};
  const ownF=Object.prototype.hasOwnProperty.call(ctx,'fillText'),ownS=Object.prototype.hasOwnProperty.call(ctx,'strokeText'),ownT=Object.prototype.hasOwnProperty.call(ctx,'translate'),tr=ctx.translate;let A=null;ctx.translate=function(a,b){if(!A)A=[a,b];return tr.apply(this,arguments);};
  let r;try{r=_ea2(x,y,col,size,label);}finally{if(ownF)ctx.fillText=ft;else delete ctx.fillText;if(ownS)ctx.strokeText=st;else delete ctx.strokeText;if(ownT)ctx.translate=tr;else delete ctx.translate;}
  const F=calls.filter(c=>c[0]==='f').pop();if(!F)return r;const t0=F[1],a0=F[2],b0=F[3];ctx.font='700 12px "JetBrains Mono",monospace';const w=ctx.measureText(t0).width/2+4,h=9,rs=hudRects();const AR=A?[A[0]-size-3,A[1]-size-3,A[0]+size+3,A[1]+size+3]:null;/* сама стрелка — препятствие для отодвинутой подписи */
  const hit=(cx,cy)=>cx-w<SAFE.l+4||cx+w>CW-SAFE.r-4||cy+4>CH-SAFE.b||cy-h<SAFE.t+2||rs.some(q=>cx+w>q[0]&&cx-w<q[2]&&cy+3>q[1]&&cy-h<q[3])||!lab61Free(cx,cy,w,h);
  const hitA=(cx,cy)=>hit(cx,cy)||!!AR&&cx+w>AR[0]&&cx-w<AR[2]&&cy+3>AR[1]&&cy-h<AR[3];
  let best=null;if(!hit(a0,b0))best=[a0,b0];else for(const d of [16,-16,30,-30,44,-44,60,-60,80,-80,100,-100]){if(!hitA(a0,b0+d)){best=[a0,b0+d];break;}if(!hitA(a0+d*1.5,b0)){best=[a0+d*1.5,b0];break;}}
  if(!best)outer:for(const dy of [-16,-32,-48,16,-64,-80]){for(const dx of [40,-40,80,-80,120,-120,160,-160,200,-200]){if(!hitA(a0+dx,b0+dy)){best=[a0+dx,b0+dy];break outer;}}}
  if(!best)return r;/* места нет — подпись не рисуем, как и раньше: лучше без неё, чем поверх кнопки */
  const dx=best[0]-a0,dy=best[1]-b0,fs=ctx.fillStyle,ss=ctx.strokeStyle,lw=ctx.lineWidth,lj=ctx.lineJoin;
  for(const c of calls){if(c[0]==='s'){ctx.strokeStyle=c[4];ctx.lineWidth=c[5];ctx.lineJoin=c[6];st.call(ctx,c[1],c[2]+dx,c[3]+dy);}else{ctx.fillStyle=c[4];ft.call(ctx,c[1],c[2]+dx,c[3]+dy);}}
  ctx.fillStyle=fs;ctx.strokeStyle=ss;ctx.lineWidth=lw;ctx.lineJoin=lj;lab61Add(best[0],best[1],w,h);
  return r;};}""")
# хелперы должны существовать до первого кадра — ставим их перед кодом игры
i=s.find('<script>');i=s.find('\n',i)+1
js=open(D+'m61.js',encoding='utf8').read()
# frame-обёртка — в конец (frame объявлена в игре); остальное — в начало, чтобы renderWorld их видел (они function — подъём работает и так)
s2=s.rindex('</script>');s=s[:s2]+js+'\n'+s[s2:]
open(P,'w',encoding='utf8').write(s);print('m61 ok')
