// ===== 0.9.6 · доводка «до идеала» =====
// --- Сердце: кульминация фазы 4 — три круга ключей (на Лёгкой два), каждый со своим рисунком ---
// доля пула, ниже которой Сердце не опустится, пока не сделано j запусков
function heartQuota96(b,j){const n=b.lN96||2;return .15*Math.max(0,1-j/n);}
// следующий круг ключей после очередного запуска: обратный порядок, затем «плывущие» ключи
function heartSeq96(b){const n=b.lN96||2,j=b.launches;if(j>=n||b.st!=='fight')return;
  for(const k of b.keys)k.lit90=0;b.keyI=0;
  if(j===1){b.keys.sort((a,c)=>c.ki-a.ki);b.rot96=0;banner('КЛЮЧИ НАОБОРОТ','СЕРДЦЕ СОПРОТИВЛЯЕТСЯ · ОБРАТНЫЙ ПОРЯДОК');radioLine('КОВЧЕГ',C90.ark,'Ритм идёт вспять. Ключи — в обратном порядке.',.2);}
  else if(j>=2){b.keys.sort((a,c)=>a.ki-c.ki);b.rot96=.28*(rk90()>=2?1.2:1);banner('КЛЮЧИ ПЛЫВУТ','ПОСЛЕДНИЙ КРУГ · ЛОВИТЕ В ТАКТ');radioLine('КОВЧЕГ',C90.ark,'Последний круг. Ключи уходят — догоняйте.',.2);}
  snd95('phase95');trauma90(.2);}
// положение ключей: по кругу 150·k, с поворотом в последнем круге
function heartKeyPos96(b){for(const q of b.keys){if(!q.alive)continue;const a=-Math.PI/2+q.ki*TAU/b.keyN+(b.keyA96||0);q.x=b.cx+Math.cos(a)*150*b.k;q.y=b.cy+Math.sin(a)*150*b.k;}}
// последний запуск: Сердце гаснет за 4 секунды при любом уроне — финал не зависит от сборки
function heartFinTick96(b,dt){if(!(b.fin96&&b.launch>0)||b.st!=='fight')return;if(!(b.fin96H>1)){b.fin96H=b.hp;b.fin96L=b.launch;}
  const f=clamp((b.launch-.4)/Math.max(.1,b.fin96L-.4),0,1);b.hp=Math.max(1,1+(b.fin96H-1)*f);b.dmgT=G.t;b.flash=.05;
  if(SET.fx&&Math.random()<.5){const a=rnd(0,TAU),v=rnd(80,240);part(b.cx+Math.cos(a)*b.r*.6,b.cy+Math.sin(a)*b.r*.6,Math.cos(a)*v,Math.sin(a)*v,rnd(.4,.9),Math.random()<.5?'#ffffff':C90.ark,rnd(2,3.5));}
  if(f<=0){b.hp=1;sb85CheckTh(b);}}
// --- Тревога 0.9.6: облава гасится, а не раскручивается ---
function ob96N(){let n=0;for(const e of G.enemies)if(e.alive&&e.ob96)n++;for(const w of G.warns)if(w.o&&w.o.ob96)n++;return n;}
// --- виньетка сектора: градиент по экрану каждый кадр стоил 4–17 мс на слабом телефоне (программный растр, ЦП ×4);
//     теперь кэш-спрайт цвета (до 2,3 Мп — в точный размер, крупнее — 640 px с растяжением) и прозрачность кадра ---
const SVIG96=new Map();
function secVigSpr96(rgb,w,h){const big=w*h>2.3e6,sw=big?640:w,sh=big?Math.max(1,Math.round(640*h/w)):h,key=rgb+'|'+sw+'x'+sh;let c=SVIG96.get(key);
  if(!c){c=document.createElement('canvas');c.width=sw;c.height=sh;const g=c.getContext('2d'),gr=g.createRadialGradient(sw/2,sh/2,Math.min(sw,sh)*.45,sw/2,sh/2,Math.max(sw,sh)*.72);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba('+rgb+',1)');g.fillStyle=gr;g.fillRect(0,0,sw,sh);
    if(SVIG96.size>=3)SVIG96.delete(SVIG96.keys().next().value);SVIG96.set(key,c);}return c;}
// фагоциты облавы помечены пунктирным кольцом: видно, кого сбить, чтобы стало тише
function ob96Draw(t){const X=G.x90;if(!X||!X.alarmOn)return;let any=false;for(const e of G.enemies){if(!e.alive||!e.ob96||e.spawnT>0)continue;if(!any){any=true;ctx.save();ctx.lineWidth=1.5;ctx.setLineDash([4,5]);ctx.lineDashOffset=-t*18;}
  ctx.strokeStyle=rgba90(C90.red,.55+.25*Math.sin(t*5+e.uid));ctx.beginPath();ctx.arc(e.x,e.y,e.r+9,0,TAU);ctx.stroke();}if(any)ctx.restore();}
// --- Сердце: волна обходит сосуды. Раньше кольцо без проходов шло на каждый удар фаз 1–2, а двойной удар фазы 3
//     ставил проходы двух колец под 90° — увернуться можно было только рывком, а он перезаряжается 1,5–2,4 с.
//     Идеальный «рывковый» бот погибал за 14–20 с. Теперь у каждой волны есть проход, до которого можно долететь:
//     фаза 1 — вдоль всех четырёх сосудов (учимся); фаза 2 — два прохода плывут по 12°/с (следуем);
//     фаза 3 — два прохода плывут по 15°/с, второй удар сдвинут на 12/16/20° (Лёгкая/Нормальная/Тяжёлая):
//     безопасно там, где проходы совпадают (точность). Направление дрейфа меняется раз в 8 с, стрелки у сердца ---
const HGW96={1:[54,44,38],2:[48,40,34],3:[46,40,34]},HGO96=[12,16,20];
function heartOff96(){return HGO96[Math.max(0,Math.min(2,rk90()))]*Math.PI/180;}
function heartRate96(b){return (b.phase===2?12:15)*Math.PI/180;}
function heartGaps(b,ahead){ahead=ahead||0;const ph=b.phase>=1&&b.phase<=3?b.phase:1,rk=Math.max(0,Math.min(2,rk90())),w=HGW96[ph][rk]*Math.PI/180;
  if(ph===1||!b.ves||!b.ves.length)return (b.ves||[]).map(v=>({a:v.a,w}));
  const th=(b.gth96!==undefined?b.gth96:b.ves[0].a)+(b.gdir96||1)*heartRate96(b)*(b.btN||.67)*ahead;return [{a:th,w},{a:th+Math.PI,w}];}
function heartDrift96(b,dt){if(b.gth96===undefined){b.gth96=b.ves[0].a;b.gdir96=1;b.gfl96=8;}b.gth96+=b.gdir96*heartRate96(b)*dt;b.gfl96-=dt;if(b.gfl96<=0){b.gfl96=8;b.gdir96*=-1;}}
// --- враг «за краем» (держатель дистанции отступал вдоль стены или шлюза за кромку арены): за ним нельзя
//     прицелиться, и миссия вставала минутами. Кто однажды вошёл в арену, из неё больше не выходит;
//     кто застрял снаружи сразу после появления — через 2,5 с возвращается внутрь с мерцанием.
//     Не трогаем тех, кто уходит за край по замыслу: беглец с грузом, Последний из рода, линкор, паломники,
//     пассажиры и свидетели, корабли-эхо, ледяная копия, снаряды и мины, классические боссы и части боссов ---
const OUT96=new Set(['witness100','pass90','lastkind','linkor','pilgrim','echoship','echoguard','icecopy','crate','shell','mine','hull','decoy','convoybox','rangedummy','boss','jam']);
function rescue96(dt){if(G.sb&&G.sb.alive)return;for(const e of G.enemies){if(!e.alive||e.spawnT>0||e.retreat||e.flee||e.leave90||e.tailT>0||e.dummy||e.sbk||e.host85||e.host74||G.latch74===e||STATIC.has(e.type)||EDEF[e.type].passive||EDEF[e.type].sbp||OUT96.has(e.type))continue;
  const r=e.r||12,inside=e.x>=r&&e.x<=W-r&&e.y>=r&&e.y<=H-r;if(inside){e.in96=1;e.off96=0;continue;}
  if(e.in96){const x=clamp(e.x,r,W-r),y=clamp(e.y,r,H-r);if(x!==e.x)e.vx=0;if(y!==e.y)e.vy=0;e.x=x;e.y=y;continue;}
  const out=e.x<-10||e.x>W+10||e.y<-10||e.y>H+10;if(!out){e.off96=0;continue;}e.off96=(e.off96||0)+dt;
  if(e.off96>2.5){e.off96=0;e.in96=1;e.x=clamp(e.x,50,W-50);e.y=clamp(e.y,50,H-50);e.vx=e.vy=0;e.spawnT=.4;if(typeof pushOut95==='function')pushOut95(e,4);if(typeof lockPush90==='function')lockPush90(e);}}}
// --- финальная зачистка в отсеках со шлюзами: волны кончились, врагов ≤ 5 — шлюзы открываются насовсем,
//     а последних врагов видно сквозь стены: никто не прячется за закрытой дверью минутами ---
function fin96Tick(X){if(X.fin96||!X.locks||!X.locks.length||(G.sb&&G.sb.alive))return;if(G.waveIdx<G.waves.length||(G.spawnQ&&G.spawnQ.length))return;
  let n=0;for(const e of G.enemies)if(e.alive&&!EDEF[e.type].passive&&!STATIC.has(e.type))n++;if(n>5)return;X.fin96=1;const p=G.player;if(p&&n>0){floater(p.x,p.y-60,'ШЛЮЗЫ ОТКРЫТЫ · ДОБЕЙТЕ ОСТАВШИХСЯ',C90.warm);snd90('locko');}}
function fin96Draw(t){const X=G.x90;if(!X||!X.fin96)return;let any=false;for(const e of G.enemies){if(!e.alive||EDEF[e.type].passive||STATIC.has(e.type)||e.spawnT>0)continue;if(!any){any=true;ctx.save();ctx.lineWidth=1.5;ctx.setLineDash([2,6]);ctx.lineDashOffset=t*14;}
  ctx.strokeStyle=rgba90('#ffffff',.35+.2*Math.sin(t*3+e.uid));ctx.beginPath();ctx.arc(e.x,e.y,e.r+14,0,TAU);ctx.stroke();}if(any)ctx.restore();}
// --- ядро ганглия (39–41) — снова векторами: поворот спрайта 552×552 стоил 1,5–1,7 мс на слой на слабом телефоне
//     (программный растр, ЦП ×4), те же пути векторами — 0,24–0,48 мс; рисунок тот же, поворот и пульс — трансформом ---
function coreVec96(q,layer){const r=q.r;ctx.lineCap='butt';
  if(layer===0){ctx.fillStyle='#2a0810';ctx.strokeStyle=C90.ark;ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();
    ctx.strokeStyle=rgba90(C90.red,.6);ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;ctx.moveTo(Math.cos(a)*r*.3,Math.sin(a)*r*.3);ctx.quadraticCurveTo(Math.cos(a+.4)*r*.7,Math.sin(a+.4)*r*.7,Math.cos(a+.2)*r*.95,Math.sin(a+.2)*r*.95);}ctx.stroke();}
  else{ctx.strokeStyle=rgba90('#ffe47a',.6);ctx.lineWidth=1.5;ctx.beginPath();for(let i=0;i<7;i++){const a=i/7*TAU;ctx.moveTo(Math.cos(a)*r*.22,Math.sin(a)*r*.22);ctx.quadraticCurveTo(Math.cos(a+.5)*r*.5,Math.sin(a+.5)*r*.5,Math.cos(a+.25)*r*.92,Math.sin(a+.25)*r*.92);}ctx.stroke();}}
// --- лимит видов IX–X — в момент появления: раньше проверка ждала первого хода ИИ (после анимации появления),
//     и на полсекунды на арене бывало на 2–3 Спазма больше лимита, а появившийся враг на глазах менял вид ---
function capEarly96(){for(const e of G.enemies)if(e.alive&&!e.cap90&&S90T.has(e.type))cap90(e);}
