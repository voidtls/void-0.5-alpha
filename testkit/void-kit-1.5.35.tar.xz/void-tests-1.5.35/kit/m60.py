# 1.3.4 α «Дорога домой» — склад сразу после миссии 01, импульс только в бою миссии 02+, склад и хранилище всегда на карте
import sys
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m60 FAIL',n,a[:80]);sys.exit(1)
    s=s.replace(a,b)
R('<div class="ver" id="verTag">1.3.3 α</div>','<div class="ver" id="verTag">1.3.4 α</div>')
R("const VER_TAG='1.3.3 α';","const VER_TAG='1.3.4 α';")
R("upd:'обучение без тупиков: ворота рывка ждут до победы, склад — сразу после первой миссии, карта — после второй.'",
  "upd:'после первой миссии дорога сначала ведёт домой, на склад; импульс — в бою второй миссии; склад и хранилище всегда на карте.'")
R('<dl class="kv"><dt>1.3.3 α</dt>','<dl class="kv"><dt>1.3.4 α</dt><dd>«Дорога домой». Через секунду после возвращения из миссии 01 загораются счётчик лома и сам склад: «НАГРАДА — НА СКЛАДЕ», дорожка от корабля и кольцо на мастерской, а стрелка у края экрана показывает «СКЛАД» вместо «МИССИЯ 02». Подсказка держится, пока вы не долетите до склада, — радио, баннеры и тосты её больше не гасят, патруль лишь ненадолго её прерывает. Только после визита на склад путь ведёт ко второй миссии. Подсказка про импульс больше не появляется в секторе и у склада: её покажут в бою второй миссии, когда враги рядом. Склад и «Хранилище корпусов» теперь всегда отмечены на карте, даже под туманом войны, и к ним можно прыгнуть, если сектор открыт.</dd><dt>1.3.3 α</dt>')
# стрелка у края: пока склад не посещён — «СКЛАД» вместо «МИССИЯ 02»
R("const nt=zbOn()||tut133HoldNext()?null:nextTarget();if(nt)arrow(nt.x,nt.y,nt.col,nt.label);","const nt=zbOn()?null:tut133HoldNext()?tut134Home():nextTarget();if(nt)arrow(nt.x,nt.y,nt.col,nt.label);")
# карта: склад и хранилище всегда видны
R("if(kind!=='lost'&&kind!=='unk'&&!openAllNow()&&fogClosedAt(x,y))return;","if(kind!=='lost'&&kind!=='unk'&&kind!=='shop'&&kind!=='hangar'&&!openAllNow()&&fogClosedAt(x,y))return;")
R("WORLD.shops.forEach(q=>{if(revealedAt(q.x,q.y))add('shop',","WORLD.shops.forEach(q=>{add('shop',")
R("{const hg=WORLD.hangar;if(revealedAt(hg.x,hg.y))add('hangar',","{const hg=WORLD.hangar;add('hangar',")
R("WORLD.shops.forEach(s=>{if(revealedAt(s.x,s.y))pts.push({x:s.x,y:s.y+150,label:'М'});});","WORLD.shops.forEach(s=>{pts.push({x:s.x,y:s.y+150,label:'М'});});")
R("if(revealedAt(WORLD.hangar.x,WORLD.hangar.y))pts.push({x:WORLD.hangar.x,","pts.push({x:WORLD.hangar.x,")
# лом, сданный при входе в миссию, — это не визит на склад: зачёт «СКЛАД» только в секторе или в мастерской
R("if(TUT.carry!==null&&TUT.carry>0&&(S.carry||0)===0&&(S.lom||0)>=TUT.lom+TUT.carry-1){","if(TUT.carry!==null&&TUT.carry>0&&(S.carry||0)===0&&(S.lom||0)>=TUT.lom+TUT.carry-1&&(G.state==='world'||G.state==='shop')){")
js=open(D+'m60.js',encoding='utf8').read();i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m60 ok')
