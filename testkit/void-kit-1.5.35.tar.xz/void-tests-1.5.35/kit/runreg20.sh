cd @@KIT@@
while ! grep -q E24END t72/q80.txt 2>/dev/null; do sleep 30; done
export GAME_URL=file://@@KIT@@/void_c160.html TMO=1500
run(){ for t in $*; do s=$(date +%s); timeout 3600 python3 $t.py > reg20/$t.log 2>&1; echo "$t exit $? $(( $(date +%s)-s ))s" >> reg20/done.txt; done; }
run q340s q210 q160 q190 q270 q130 q150 q110 q96 q290 q240 q370 q300 q320 &
run q350 q200 q180 q220 q330 q120 q95 q90 q280 q250 q260 q170 q140 q310 q360 q380 &
wait; echo ALLDONE >> reg20/done.txt
cd t72 && python3 perf80.py perf160.json 8 > perf160.log 2>&1; echo PERF80END >> q80.txt
