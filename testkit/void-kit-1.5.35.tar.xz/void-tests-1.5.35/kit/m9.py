# 0.6.1 · часть 9: карта на телефоне вокруг игрока; стрелки врагов только на лёгкой
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m9: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
# --- карта: стартовый масштаб и центр на мобильном
R("function mapViewInit(){const p=G.player,cw=($('#mapC')&&$('#mapC').clientWidth)||1000,sp=cw<520?6500:11000;",
  "function mapSpanDef(){return isMob()?(G.ff==='tablet'?7000:innerWidth>innerHeight?6000:4000):(($('#mapC')&&$('#mapC').clientWidth)||1000)<520?6500:11000;}\nfunction mapSpanMin(){return isMob()?2200:3500;}\nfunction mapViewInit(){const p=G.player,sp=mapSpanDef();")
R("function mapClamp(w,h){const V_=G.mapView,mx=mapSpanMax(w,h);V_.span=clamp(V_.span,3500,mx);V_.tspan=clamp(V_.tspan,3500,mx);const vh=V_.span*h/w;\n  V_.cx=V_.span>=WW?WW/2:clamp(V_.cx,V_.span/2,WW-V_.span/2);V_.cy=vh>=WH?WH/2:clamp(V_.cy,vh/2,WH-vh/2);}",
  "function mapClamp(w,h){const V_=G.mapView,mx=mapSpanMax(w,h),mn=mapSpanMin();V_.span=clamp(V_.span,mn,mx);V_.tspan=clamp(V_.tspan,mn,mx);const vh=V_.span*h/w;\n  if(isMob()){V_.cx=clamp(V_.cx,0,WW);V_.cy=clamp(V_.cy,0,WH);return;}\n  V_.cx=V_.span>=WW?WW/2:clamp(V_.cx,V_.span/2,WW-V_.span/2);V_.cy=vh>=WH?WH/2:clamp(V_.cy,vh/2,WH-vh/2);}")
R("V_.tspan=clamp(V_.tspan*f,3500,mapSpanMax(M.w,M.h));","V_.tspan=clamp(V_.tspan*f,mapSpanMin(),mapSpanMax(M.w,M.h));")
R("V_.tspan=V_.span=clamp(V_.span*MP.pinch/d,3500,mapSpanMax(G.mapXY.w,G.mapXY.h));","V_.tspan=V_.span=clamp(V_.span*MP.pinch/d,mapSpanMin(),mapSpanMax(G.mapXY.w,G.mapXY.h));")
# граница мира, когда вид выходит за её пределы (только мобильный)
R("g.drawImage(mapFog(),X(0),Y(0),WW*k,WH*k);",
  "g.drawImage(mapFog(),X(0),Y(0),WW*k,WH*k);if(isMob()){g.strokeStyle='rgba(127,154,181,.35)';g.lineWidth=1;g.setLineDash([6,6]);g.strokeRect(X(0),Y(0),WW*k,WH*k);g.setLineDash([]);}")
# кнопка «ко мне»: на телефоне возвращает и масштаб
R("$('#mapZme').onclick=()=>{const p=G.player;G.mapView.cx=p.x;G.mapView.cy=p.y;};",
  "$('#mapZme').onclick=()=>{const p=G.player;G.mapView.cx=p.x;G.mapView.cy=p.y;if(isMob()){G.mapView.zx=undefined;G.mapView.tspan=mapSpanDef();}};")
# --- стрелки врагов за кадром: только на лёгкой сложности
R("list.sort((a,b)=>a[0]-b[0]);for(const [d,e] of list.slice(0,6))edgeArrow(",
  "list.sort((a,b)=>a[0]-b[0]);if((curDiff().rank||0)===0)for(const [d,e] of list.slice(0,6))edgeArrow(")
open(P,'w',encoding='utf8').write(s)
print('m9 ok')
# версия и хроника
s=open(P,encoding='utf8').read()
R('<div class="eyebrow">АЛЬФА 0.6.0 · МОБИЛЬНАЯ</div>','<div class="eyebrow">АЛЬФА 0.6.1 · МОБИЛЬНАЯ</div>')
R("if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.6.0 α</dt>",
  "if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.6.1 α</dt><dd>Карта на телефоне открывается вокруг корабля и близко: 2–4 точки на экран, пинч приближает ещё, кнопка «ко мне» возвращает масштаб. Стрелки врагов за кадром остались только на лёгкой сложности.</dd><dt>0.6.0 α</dt>")
open(P,'w',encoding='utf8').write(s)
print('m9 ver ok')
