# 0.9.7: проверки сектора XI «Нулевая точка» (47–49), сектора XII (комната 50), мира, звука, кадра
import asyncio,json,sys,os
from h import *
src=open(SP+'q74.py').read();HELP=src[src.index('HELP="""')+8:src.index('"""',src.index('HELP="""')+8)]
q9=open(SP+'q90.py').read();H90=q9[q9.index('H90="""')+7:q9.index('"""',q9.index('H90="""')+7)]
q5=open(SP+'q95.py').read();H95=q5[q5.index('H95="""')+7:q5.index('"""',q5.index('H95="""')+7)]
H110="""()=>{T.m110=(m,o)=>{o=o||{};T.mis(m,Object.assign({diff:'mid',clear:false},o));if(o.flags)Object.assign(G.save.story,o.flags);t90Init(MISSIONS[m-1]);G.player.inv=0;return G.x110;};
 T.at=(u,v)=>{const q=P110(u,v);const p=G.player;p.x=q.x;p.y=q.y;p.px=p.x;p.py=p.y;p.vx=p.vy=0;return q;};
 T.killAll=()=>{for(const e of G.enemies)if(e.alive){e.hp=0;kill(e,true);}G.warns=[];G.spawnQ=[];};
 T.alive=()=>G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive).length;
 T.hold=(sec,f)=>{T.tick(sec,i=>{const p=G.player;p.vx=p.vy=0;p.x=p.px;p.y=p.py;if(f)f(i);T.god();});};
 return 1;}"""
def ok(name,cond,info=None):rec(name,cond,info)
async def page(b,**k):
    P=await newpage(b,**k);await P.js(HELP);await P.js(H90);await P.js(H95);await P.js(H110);return P
# ---------- L: мир, сектора, ворота, карта, карточки ----------
async def L(b):
    P=await page(b)
    r=await P.js("""()=>{const S_=WORLD.sectors,N=WORLD.nodes;return {n:S_.length,xi:S_[10].box,xii:S_[11].box,xiiName:S_[11].name,nodes:[47,48,49,50].map(m=>[N[m-1].x,N[m-1].y,N[m-1].sec,!!N[m-1].boss]),so:[46,47,49,50].map(secOfLevel),
      ms:[47,48,49,50].map(m=>[MISSIONS[m-1].sec,MISSIONS[m-1].sector,MISSIONS[m-1].bossRoom,MISSIONS[m-1].sboss]),lv:SECTORS_NEW[8].lv,nN:N.length,NM};}""")
    ok('L01 12 секторов: XI = 47–49 (37000–40000 × 8000–13500), XII = комната 50 (13500–19000)',r['n']==12 and r['xi']==[37000,8000,40000,13500] and r['xii']==[37000,13500,40000,19000] and r['lv']==[47,49] and r['so']==[9,10,10,11] and r['nN']==50 and r['NM']==50 and r['ms'][3][0]==11 and 'XII' in r['ms'][3][1] and r['ms'][3][3] is None,r)
    d=lambda a,b_:((a[0]-b_[0])**2+(a[1]-b_[1])**2)**.5
    n=r['nodes']
    ok('L02 узлы 47–49 далеко друг от друга (≥1500) внутри XI; 50 — внутри XII, босс',min(d(n[0],n[1]),d(n[1],n[2]),d(n[0],n[2]))>=1500 and all(37000<q[0]<40000 and 8000<q[1]<13500 for q in n[:3]) and 13500<n[3][1]<19000 and n[3][2]==11 and n[3][3],n)
    r=await P.js("""()=>{window.__alpha=false;T.fresh();T.openAll();const p=G.player,S=G.save;const go=(open)=>{if(open)S.story.zero49=1;else delete S.story.zero49;p.x=38500;p.y=13380;p.px=p.x;p.py=p.y;p.vx=p.vy=0;KEYS.KeyS=true;T.wtick(2.5);KEYS.KeyS=false;return Math.round(p.y);};
      const a=go(false),b=go(true);return [a,b,inXII110(38500,13600),inXII110(38500,13400)];}""")
    await P.js("()=>{window.__alpha=undefined;return 1;}")
    ok('L03 ворота XI/XII (релиз): без флага zero49 корабль не проходит вниз, с флагом — проходит',r[0]<13520 and r[1]>13700 and r[2] and not r[3],r)
    r=await P.js("""()=>{window.__alpha=false;T.fresh();T.openAll();const p=G.player,S=G.save;delete S.story.zero49;p.x=38200;p.y=12900;p.px=p.x;p.py=p.y;G.mapAnimJump=false;openMap('map');drawMap();
      const q=(G.mapPts||[]).find(q=>q.label==='XII');if(!q)return ['noPt',(G.mapPts||[]).map(q=>q.label).join(',')];const r1=mapJumpAt(q.px,q.py);const y1=Math.round(p.y);const m1=($('#mapMsg')&&$('#mapMsg').textContent)||'';
      S.story.zero49=1;drawMap();const q2=(G.mapPts||[]).find(q=>q.label==='XII');const r2=mapJumpAt(q2.px,q2.py);return [r1,y1,m1,r2,Math.round(p.y),G.state];}""")
    await P.js("()=>{window.__alpha=undefined;return 1;}")
    ok('L04 (релиз) прыжок к маяку XII запрещён, пока ворота закрыты; с флагом — прыжок проходит',r[0] is True and r[1]==12900 and ('ВОРОТА' in str(r[2]) or r[2]=='') and r[3] is True and r[4]>13600,r)
    r=await P.js("""()=>{T.fresh();T.openAll();const n=WORLD.nodes[49],p=G.player;p.x=n.x;p.y=n.y+100;p.vx=p.vy=0;T.wtick(1);const h=$('#wcard').innerHTML;const st0=G.state;G.save.story.zero49=1;cardAct('main');const k=G.zb&&G.zb.k;T.wtick(.2);const st1=G.state;
      return [G.card&&G.card.key,h.includes('ВОЙТИ В КОМНАТУ'),h.includes('VØID-000'),h.includes('ЭХО'),st0,st1,k];}""")
    ok('L05 карточка узла 50 (0.9.9): «ВОЙТИ В КОМНАТУ», вход запускает выход босса в сектор (тишина 2 с)',r[0] in ('n50',None) and r[1] and r[2] and not r[3] and r[4]=='world' and r[5]=='world' and r[6]=='silence',r)
    r=await P.js("""()=>{window.__alpha=false;T.fresh();T.openAll();const S=G.save;delete S.story.zero49;w90Gen();revealAround(38500,13500,3000);const items=[];const add=(k,x,y,o,lab)=>items.push([k,x,y,lab&&lab.t]);w90MapAdd(add,2,S);const a=items.find(q=>q[0]==='zero100');
      S.story.zero49=1;items.length=0;w90MapAdd(add,2,S);const b=items.find(q=>q[0]==='zero100');return [a&&[a[1],a[2],a[3]],b&&b[3],W90.zero];}""")
    await P.js("()=>{window.__alpha=undefined;return 1;}")
    ok('L06 маркер ворот на карте: у границы XI/XII, подпись меняется с открытием',r[0] and r[0][0]==38500 and r[0][1]==13500 and 'МИГ' in r[0][2] and r[1] and 'ОТКРЫТЫ' in r[1],r)
    r=await P.js("""()=>{T.fresh();T.openAll();const S=G.save;delete S.story.zero49;enterNode(49,false);if(G.state==='intro')startMission();const M=MISSIONS[48];done90(M);const a=S.story.zero49;
      S.story.zero49=5;S.story.zero50=-3;sanitize90(S,(v,d,lo,hi,int)=>{v=+v;if(!Number.isFinite(v))return d;v=Math.max(lo,Math.min(hi,v));return int?Math.round(v):v;},o=>o&&typeof o==='object'?o:{});return [a,S.story.zero49,S.story.zero50];}""")
    ok('L07 победа в 49 ставит флаг zero49; sanitize90 держит zero49 в 0..1, zero50 — в 0..9',r[0]==1 and r[1]==1 and r[2]==0,r)
    r=await P.js("""()=>{return [['s10','mx10','s11','mx11','m47','m48','m49'].every(k=>!!SC_[k]),SC_.m47.zero110,SC_.m48.bpm,SC_.m49.bpm,SECTOR_NAMES.length,roman(12),bossLab90(50),RADIO_SEC[10]];}""")
    ok('L08 сцены музыки сектора XI/XII и подписи: m47/m48/m49, s11, босс 50 — «СКОРО»',r[0] and r[1]=='const' and r[2]==60 and r[3]==104 and r[4]==12 and r[5]=='XII' and r[6]=='VØID-000' and r[7]=='Н',r)
    r=await P.js("""()=>{T.fresh();T.openAll();const p=G.player;p.x=38500;p.y=14300;p.px=p.x;p.py=p.y;G.save.story.zero49=1;T.wtick(.5);const T_=musTarget();const si=sectorIdx(p.x,p.y);return [T_.id,si,sectorName(p.x,p.y)];}""")
    ok('L09 в секторе XII — своя сцена мира s11',r[0]=='s11' and r[1]==11,r)
    r=await P.js("""()=>{openDev&&openDev();const b=document.querySelector('#devGrid .devm[data-m="50"]');const t=b?b.innerText:'';const b47=document.querySelector('#devGrid .devm[data-m="47"]');return [t.replace(/\\s+/g,' '),b47?b47.innerText.replace(/\\s+/g,' '):''];}""")
    ok('L10 меню разработчика: 50 — «БОСС · СЕКТОР XII», 47 — сектор XI',('БОСС' in r[0] and 'XII' in r[0]) and ('XI' in r[1]),r)
    print('ERRS L',P.errs[:4])
# ---------- A: 47 «Созвездие» ----------
async def A(b):
    P=await page(b)
    r=await P.js("""()=>{const X=T.m110(47);geo47(X);const k=k110();const out={n:X.st.length,r:X.r,k,m:Math.min(...X.st.map(s=>Math.min(s.x,s.y,W-s.x,H-s.y))),dmin:1e9,p:[G.player.x,G.player.y],pd:1e9,hold:G.waveHold,wi:G.waveIdx,ph:X.phase};
      for(let i=0;i<5;i++)for(let j=i+1;j<5;j++)out.dmin=Math.min(out.dmin,Math.hypot(X.st[i].x-X.st[j].x,X.st[i].y-X.st[j].y));for(const s of X.st)out.pd=Math.min(out.pd,Math.hypot(s.x-G.player.x,s.y-G.player.y));return out;}""")
    ok('A01 пять пилотов созвездием: не ближе 60 к краю, не ближе 2,4 r друг к другу, корабль стартует вне колец, волны держатся',r['n']==5 and r['m']>=60 and r['dmin']>=2.4*r['r'] and r['pd']>r['r']*1.5 and r['hold']>990 and r['wi']==0 and r['ph']=='read',r)
    r=await P.js("""()=>{const X=T.m110(47);const s=X.st[0];T.at(s.u,s.v);const rd=[];T.hold(3.2,i=>{if(i%30===0)rd.push(+s.read.toFixed(2));});T.hold(1.2);const w=G.warns[0]||{mx:W/2,my:H-22};
      return {done:s.done,lit:X.lit,ph:X.phase,rd,wi:G.waveIdx,q:G.spawnQ.length+G.warns.length,hold:G.waveHold,mc:G.mc.read110,sp:X.spawnAt&&[Math.round(X.spawnAt.x-s.x),Math.round(X.spawnAt.y-s.y)],wm:w&&[Math.round(w.mx),Math.round(w.my)],wb:G.waveBase[0],wv:G.waves[0].slice().sort().join(',')};}""")
    ok('A02 чтение: 3 с в кольце → прочитан, память отвечает — волна VØID-002 (копейщики со стаей)',r['done']==1 and r['lit']==1 and r['ph']=='fight' and r['wi']==1 and r['q']>=1 and r['wm'] is not None and r['mc']==1 and r['sp']==[0,0] and set(r['wv'].split(','))=={'lancer','scout'} and r['wb']==7,r)
    r=await P.js("""()=>{const X=T.m110(47);const s=X.st[0];T.at(s.u,s.v);T.hold(1.5);const a=s.read;T.at(.5,.5);T.hold(1);const b=s.read;T.hold(8);return [+a.toFixed(2),+b.toFixed(2),+s.read.toFixed(2),s.done,G.mc.readBreak110];}""")
    ok('A03 прерванное чтение тает 0,2/с и считается прерванным (мастерство)',abs(r[0]-1.5)<.05 and abs(r[1]-1.3)<.06 and r[2]==0 and not r[3] and r[4]==1,r)
    r=await P.js("""()=>{const X=T.m110(47);const s0=X.st[0];const s3=X.st[3];T.at(s3.u,s3.v);T.hold(2);const r0=+s3.read.toFixed(2);T.at(s0.u,s0.v);T.hold(3.2);T.hold(3);const cur1=!!X.cur,ph1=X.phase;const s2=X.st[1];T.at(s2.u,s2.v);T.hold(2);const r2=+s2.read.toFixed(2);
      T.killAll();T.hold(.5);const ph2=X.phase;T.hold(2.2);const ph3=X.phase;T.hold(3.2);return [cur1,ph1,r2,ph2,ph3,s2.done,X.lit,r0];}""")
    ok('A04 читается только следующая звезда по порядку; пока память отвечает — не читается; стихла (2 с после боя) — читается следующий',r[0] is False and r[1]=='fight' and r[2]==0 and r[3]=='cool' and r[4]=='read' and r[5]==1 and r[6]==2 and r[7]==0,r)
    r=await P.js("""()=>{const X=T.m110(47);let steps=[];for(let i=0;i<5;i++){const s=X.st.find(q=>!q.done);T.at(s.u,s.v);T.hold(3.3);T.hold(1.5);T.killAll();T.hold(2.3);steps.push([X.lit,G.waveIdx,X.phase]);}
      const blk=x110Block();T.hold(3);return {steps,blk,st:G.state,wi:G.waveIdx,wl:G.waves.length,end:G.endT};}""")
    ok('A05 все пять прочитаны и память добита → «ЗОНА ЧИСТА», миссия завершена; до этого конец заблокирован',r['steps'][4][0]==5 and r['steps'][4][1]==5 and r['blk'] is False and r['st']=='done' and r['steps'][0][1]==1,r)
    r=await P.js("""()=>{const W_=WAVES47;return [W_.map(w=>w.length),W_.flat().every(t=>!!EDEF[t]),W_.flat().length,MISSIONS[46].wavesT.length,MISSIONS[46].hint.join(' ').includes('{SPD}')];}""")
    ok('A06 волны созвездия: 7/5/5/5/7 = 29 врагов, все типы существуют, подсказка подставляет цифры сектора',r[0]==[7,5,5,5,7] and r[1] and r[2]==29 and r[3]==5,r)
    r=await P.js("""()=>{const X=T.m110(47);const s=X.st[0];T.at(s.u,s.v);T.hold(1);const I=hud110();const el=document.getElementById('x90G');hud90();return [I.l,I.k>0,I.r,el&&!el.hidden,el&&el.querySelector('.l').textContent];}""")
    ok('A07 интерфейс: строка «СОЗВЕЗДИЕ · ПРОЧИТАНО n/5» с ходом чтения',r[0].startswith('СОЗВЕЗДИЕ · ПРОЧИТАНО 0/5') and r[1] and r[2]=='ЧИТАЙТЕ VØID-002' and r[3] and r[4].startswith('СОЗВЕЗДИЕ'),r)
    r=await P.js("""()=>{const X=T.m110(47);for(let i=0;i<2;i++){const q=X.st[i];T.at(q.u,q.v);T.hold(3.3);T.hold(1.5);T.killAll();T.hold(2.3);}const s=X.st[2];T.at(s.u,s.v);T.hold(3.3);const n0=G.enemies.filter(e=>e.alive).length;T.hold(12);const types=G.enemies.filter(e=>e.alive).map(e=>e.type);const cap=types.filter(t=>t==='keeper90').length;
      return [n0,types.length,cap,X.phase,G.mc.read110,G.x90.alarmOn,types.filter(t=>t==='keeper90').length];}""")
    ok('A08 память VØID-003: Смотрители со стрелками приходят без Тревоги (alarmOn выкл.), не больше 2 Смотрителей',r[1]>=3 and r[2]<=2 and r[5] is False,r)
    r=await P.js("""()=>{const X=T.m110(47);const out=[];const R0=radioLine;let rc=0;radioLine=function(...a){rc++;return R0.apply(this,a);};for(let i=0;i<5;i++){const s=X.st.find(q=>!q.done);T.at(s.u,s.v);T.hold(3.3);out.push(rc);rc=0;T.hold(1.5);T.killAll();T.hold(2.3);}radioLine=R0;return [out,X.order.length,new Set(X.order).size];}""")
    ok('A09 каждый прочитанный пилот говорит по радио; порядок чтения записан без повторов',all((x or 0)>=1 for x in r[0]) and r[1]==5 and r[2]==5,r)
    print('ERRS A',P.errs[:4])
# ---------- B: 48 «Пуск» ----------
async def B(b):
    P=await page(b)
    r=await P.js("""()=>{const X=T.m110(48);geo48(X);T.hold(3);const p=G.player;return {on:X.on,c:X.con.map(c=>[+c.u,+c.v,Math.round(Math.hypot(c.x-p.x,c.y-p.y))]),btn:[Math.round(X.btn.x-W/2),Math.round(X.btn.y-H/2),X.btn.r],armed:X.btn.armed,wi:G.waveIdx,hold:G.waveHold};}""")
    ok('B01 стол: три контакта на расстоянии > 300 от старта, кнопка в центре r=220, контакты спят, волны держатся',r['on']==0 and all(c[2]>250 for c in r['c']) and r['btn'][0]==0 and r['btn'][1]==0 and r['btn'][2]==220 and r['armed']==0 and r['wi']==0 and r['hold']>990,r)
    r=await P.js("""()=>{const X=T.m110(48);const c=X.con[0];T.at(c.u,c.v);T.hold(.3);const on1=c.on,wi1=G.waveIdx;T.at(.5,.5);T.hold(1.5);const wi2=G.waveIdx,w=G.waveBase[0],typ=G.waves[0].slice().sort().join(',');
      const c2=X.con[1];G.pb.push({x:c2.x-60,y:c2.y,px:c2.x-60,py:c2.y,vx:980,vy:0,dmg:10,pierce:0,rico:0,life:.5,hit:[]});T.hold(.4);const onBusy=c2.on;T.killAll();G.waveIdx=X.rel;T.hold(.3);G.pb.push({x:c2.x-60,y:c2.y,px:c2.x-60,py:c2.y,vx:980,vy:0,dmg:10,pierce:0,rico:0,life:.5,hit:[]});T.hold(.4);return [on1,wi1,wi2,w,typ,c2.on,X.on,G.waveIdx<=X.rel,onBusy];}""")
    ok('B02 контакт поднимается подходом (A) и выстрелом в затишье (B), не выстрелом в бою; расчёт Отсчёта — Связист, 3 стрелка, Щитоносец',r[0]==1 and r[2]>=1 and r[3]==5 and r[4]=='gunner,gunner,gunner,shielder,signaller' and r[5]==1 and r[6]==2 and r[7] and r[8]==0,r)
    r=await P.js("""()=>{const X=T.m110(48);for(const c of X.con)contact48(X,c);T.hold(2);const a0=X.btn.armed,n0=T.alive()+G.warns.length+G.spawnQ.length;T.killAll();G.waveIdx=X.rel;T.hold(.5);const a1=X.btn.armed;
      T.at(.5,.5);T.hold(1);const fin=X.btn.fin,wi=G.waveIdx,rel=X.rel,wl=G.waves.length,last=G.waves[3].slice().sort().join(',');return [a0,n0>2,a1,fin,wi,rel,wl,last];}""")
    ok('B03 кнопка доступна, когда все три подняты и стол почти чист; первый шаг в круг зовёт последний расчёт',r[0]==0 and r[1] and r[2]==1 and r[3]==1 and r[5]==4 and r[6]==4 and r[7]=='autopilot,autopilot,commander,fireship,stamp,stamp',r)
    r=await P.js("""()=>{const X=T.m110(48);for(const c of X.con)contact48(X,c);T.killAll();G.waveIdx=X.rel;T.hold(.5);T.at(.5,.5);T.hold(1);const B=X.btn;T.killAll();G.waveIdx=X.rel;
      const e=T.sp('gunner',B.x+100,B.y);e.cd=999;T.hold(2,()=>{e.x=B.x+100;e.y=B.y;e.vx=e.vy=0;});const h1=+B.hold.toFixed(2),pad=!!B.onPad;e.alive=false;T.killAll();G.waveIdx=X.rel;T.hold(2);const h2=+B.hold.toFixed(2);T.at(.5,.1);T.hold(2);const h3=+B.hold.toFixed(2),drop=G.mc.puskDrop110;
      T.at(.5,.5);T.killAll();G.waveIdx=X.rel;T.hold(11.5);return [h1,pad,h2,h3,drop,B.fired,G.state,X.flashT>0];}""")
    ok('B04 отсчёт ждёт, пока враг на столе; идёт при чистом столе; выход из круга — течёт назад 0,5/с; 10 с → ПУСК',abs(r[0]-1.5)<.1 and r[1] and abs(r[2]-3.5)<.1 and abs(r[3]-2.5)<.12 and r[4]==1 and r[5]==1 and r[6]=='done',r)
    r=await P.js("""()=>{const X=T.m110(48);for(const c of X.con)contact48(X,c);T.hold(1.5);T.killAll();G.waveIdx=X.rel;T.hold(.5);T.at(.5,.5);T.hold(1.2);for(let i=0;i<6;i++)T.sp(['commander','stamp','autopilot','gunner','scout','fireship'][i],W*.1+i*40,H*.1);G.spawnQ.push('scout');
      const n0=T.alive();X.btn.hold=9.9;T.killAll();G.waveIdx=X.rel;for(let i=0;i<4;i++){const e=T.sp('gunner',W*.1+i*40,H*.1);e.cd=999;}T.hold(.4);const fired=X.btn.fired,n1=T.alive(),q=G.spawnQ.length+G.warns.length,eb=G.eb.length;T.hold(3);return [n0>=6,fired,n1,q,eb,G.state,G.kills-G.missionKills>=4];}""")
    ok('B05 ПУСК стирает всё на столе: враги, очередь, снаряды; зона чиста — миссия завершена, убийства засчитаны',r[0] and r[1]==1 and r[2]==0 and r[3]==0 and r[4]==0 and r[5]=='done' and r[6],r)
    r=await P.js("""()=>{const X=T.m110(48);const p=G.player;for(let i=0;i<4;i++){const e=T.sp('shielder',W*.2+i*60,H*.2);cap90(e);}const n=T.cnt('shielder');const types=G.enemies.filter(e=>e.alive).map(e=>e.type).sort().join(',');
      for(let i=0;i<3;i++){const e=T.sp('signaller',W*.2+i*60,H*.3);cap90(e);}return [n,types,T.cnt('signaller'),CAP90.shielder,FB95[10].join(',')];}""")
    ok('B06 лимиты сектора XI: один Щитоносец и один Связист одновременно, лишние становятся рядовыми; общий CAP90 не тронут',r[0]==1 and r[2]==1 and r[3] is None and all(t in ['shielder','scout','gunner','rammer','lancer','signaller'] for t in r[1].split(',')),r)
    r=await P.js("""()=>{const X=T.m110(48);const c=X.con[2];T.at(c.u,c.v);T.hold(.3);T.at(.5,.5);T.hold(14);const t=G.enemies.filter(e=>e.alive).map(e=>e.type);return [t.filter(x=>x==='unborn').length,t.includes('singer')||G.kills>G.missionKills,t.includes('fireship')||t.length<3,X.on];}""")
    ok('B07 Хор: Певчий, Нерождённые и Брандер приходят с нижнего края и живут в арене',r[0]<=5 and r[1] and r[3]==1,r)
    r=await P.js("""()=>{const X=T.m110(48);T.hold(1);const I=hud110();const a=I.l;for(const c of X.con)contact48(X,c);T.hold(.2);const b=hud110().l;T.killAll();G.waveIdx=X.rel;T.hold(.5);const c_=hud110().l;return [a,b,c_,bg48.toString().includes('ОЧИСТИТЕ СТОЛ')];}""")
    ok('B08 интерфейс пуска: контакты n/3 → «ОЧИСТИТЕ СТОЛ» → «ПУСК · 10 С»',r[0]=='КОНТАКТЫ 0/3' and r[1]=='ПУСК · ОЧИСТИТЕ СТОЛ' and r[2].startswith('ПУСК · 10') and r[3],r)
    print('ERRS B',P.errs[:4])
# ---------- C: 49 «Миг» ----------
async def C(b):
    P=await page(b)
    r=await P.js("""()=>{const X=T.m110(49);const B=X.band,p=G.player;const out={ph0:B.ph,ax:B.ax,c0:+B.c.toFixed(2),inP:X.in,px:+(p.x/W).toFixed(2)};T.hold(40.5);out.ph1=B.ph;out.turn=+B.turn.toFixed(1);out.c1=+B.c.toFixed(2);T.hold(3.1);out.ph2=B.ph;out.ax2=B.ax;out.c2=+B.c.toFixed(2);
      T.hold(32.2);out.ph3=B.ph;T.hold(3.1);out.ax3=B.ax;out.c3=+B.c.toFixed(2);T.hold(32.2);T.hold(3.1);out.ph4=B.ph;out.ax4=B.ax;out.R0=Math.round(B.R);T.hold(20.2);out.ph5=B.ph;out.R1=Math.round(B.R);out.blk=x110Block();T.hold(2.1);out.blk2=x110Block();return out;}""")
    ok('C01 полоса: 40 с вправо → поворот 3 с → 32 с вниз → поворот → 32 с влево → сжатие 20 с к точке выхода (r=180) → финал',r['ph0']==0 and r['ax']=='v' and r['c0']==.23 and r['inP'] and r['ph1']==0 and r['turn']>0 and r['c1']==.77 and r['ph2']==1 and r['ax2']=='h' and r['ph3']==1 and r['ax3']=='v' and abs(r['c3']-.77)<.02 and r['ph4']==3 and r['ax4']=='c' and r['R0']>250 and r['ph5']==4 and r['R1']==180 and r['blk'] and r['blk2'] is False,r)
    r=await P.js("""()=>{const X=T.m110(49);const p=G.player;X.notch=4;X.band.ph=0;G.waveHold=999;X.rel=5;G.waveIdx=5;T.at(.23,.5);T.hold(2);const hp0=p.hp,in0=X.in;T.at(.8,.5);G.player.hp=100;p.inv=0;let hp1=0;T.tick(1.1,()=>{p.vx=p.vy=0;});hp1=+p.hp.toFixed(2);T.tick(2,()=>{p.vx=p.vy=0;});const hp2=+p.hp.toFixed(2);
      p.dashCd=1;p.dashCdMax=1;T.tick(1,()=>{p.vx=p.vy=0;p.hp=100;});const cd=+p.dashCd.toFixed(2);T.at(.23,.5);T.tick(1,()=>{p.vx=p.vy=0;});const cd2=+p.dashCd.toFixed(2);return [in0,hp0,hp1,hp2,cd,cd2,Math.round(G.mc.out110*10)/10,X.vig>0];}""")
    ok('C02 вне полосы: 1,2 с тишины, потом стирание 2%/с, рывок не заряжается; внутри — рывок заряжается, корпус цел',r[0] and r[1]==100 and r[2]==100 and r[3]<=96.2 and r[3]>=95.5 and abs(r[4]-1)<.05 and r[5]<=0.05 and r[6]>=4,r)
    r=await P.js("""()=>{const X=T.m110(49);G.waveHold=999;X.rel=0;const a=T.sp('gunner',W*.23,H*.3),b_=T.sp('gunner',W*.85,H*.3);a.cd=b_.cd=999;T.hold(.2);const ka=a.tK,kb=b_.tK;T.hold(1.6);const hb0=b_.hp;T.hold(2);const hb1=b_.hp,ha=a.hp;
      const bl={x:W*.85,y:H*.6,vx:100,vy:0,rift:false},bi={x:W*.23,y:H*.6,vx:100,vy:0};return [ka,kb,hb0===b_.maxHp||hb0<b_.maxHp,hb1<hb0,ha===a.maxHp,+bK110(bl).toFixed(2),bK110(bi)];}""")
    ok('C03 враги вне полосы вязнут (×0,6) и через 1,5 с стираются 3%/с; внутри — целы; снаряды снаружи ×0,6',r[0]==1 and r[1]==.6 and r[3] and r[4] and r[5]==.6 and r[6]==1,r)
    r=await P.js("""()=>{const X=T.m110(49);const B=X.band;const seen=[];T.hold(1.5);seen.push([X.notch,G.waveIdx]);T.killAll();T.hold(21);seen.push([X.notch,G.waveIdx]);T.killAll();T.hold(22);T.killAll();T.hold(14);seen.push([X.notch,G.waveIdx]);T.killAll();T.hold(18);seen.push([X.notch,G.waveIdx,B.ph]);
      T.killAll();T.hold(20);T.hold(16);T.hold(3.2);seen.push([X.notch,X.rel,B.ph,X.allies.length]);return seen;}""")
    ok('C04 четыре засечки идут по ходу полосы (и раньше — когда затишье), финал у сжатия: оставшиеся + 2 Эхо-призрака и союзники',r[0][0]==1 and r[1][0]>=2 and r[2][0]>=3 and r[3][0]==4 and r[4][1]==5 and r[4][2]==3 and r[4][3]>=2,r)
    r=await P.js("""()=>{const X=T.m110(49,{flags:{cradle22:'keep',fleet27:'engine',line31:'write',well38:'third',heart42:'wake',shore46:'record'}});allies49(X);const n=X.allies.length,names=X.allies.map(a=>a.name).join(',');
      const Y=T.m110(49,{flags:{cradle22:'leave',heart42:'wake'}});delete G.save.story.fleet27;delete G.save.story.line31;delete G.save.story.well38;delete G.save.story.shore46;allies49(Y);return [n,names,Y.allies.length,Y.allies.map(a=>a.name).join(',')];}""")
    ok('C05 союзники: двое + милосердные выборы (не больше 6), имена — по выборам',r[0]==6 and r[1].startswith('УЧЕНИК,ПАССАЖИР,КОЛЫБЕЛЬ,ФЛОТ') and r[2]==3 and r[3]=='УЧЕНИК,ПАССАЖИР,СЕРДЦЕ',r)
    r=await P.js("""()=>{const X=T.m110(49);allies49(X);T.at(.23,.5);G.waveHold=999;const e=T.sp('gunner',G.player.x+200,G.player.y);e.cd=999;const ex=e.x,ey=e.y;let shots=0;T.hold(3,()=>{e.x=ex;e.y=ey;e.vx=e.vy=0;shots+=G.pb.filter(b=>b.a85).length;});const A=X.allies[0];A.hp=1;G.eb.push({x:A.x,y:A.y,vx:0,vy:0,dmg:5,col:'#fff',r:4,life:1});T.hold(.2);
      return [shots>0,X.allies.length,G.mc.allyLost110,e.hp<e.maxHp];}""")
    ok('C06 союзники стреляют по врагам рядом и гибнут от вражеских снарядов (потеря считается)',r[0] and r[1]==1 and r[2]==1 and r[3],r)
    r=await P.js("""()=>{const X=T.m110(49);const B=X.band;B.ph=4;B.t=3;X.rel=5;G.waveIdx=5;T.killAll();T.hold(2.5);return [G.state,G.endT<=0];}""")
    ok('C07 у точки выхода без врагов — «ЗОНА ЧИСТА», миссия завершена',r[0]=='done',r)
    r=await P.js("""()=>{const X=T.m110(49);const B=X.band;B.t=37.2;T.at(.75,.5);T.hold(1);const w1=B.warn,ext=mus110({ext:{},I:0,lp:18000}).ext;const I1=hud110();T.at(.08,.5);T.hold(2);const I2=hud110();const ex2=mus110({ext:{},I:0,lp:18000});return [w1,!!ext.turn110,I1.l,I1.r,I2.r,I2.col,ex2.lp,!!ex2.ext.out110];}""")
    ok('C08 предупреждение о повороте за 3 с (музыка — сирена), снаружи — «ВНЕ МИГА», музыка глушится',r[0]==1 and r[1] and 'МИГ' in r[2] and r[3].startswith('ЗАСЕЧКИ') and r[4]=='ВНЕ МИГА' and r[6]<=1500 and r[7],r)
    r=await P.js("""()=>{const X=T.m110(49);const p=G.player;T.at(.23,.5);const in1=bandIn49(X,p.x,p.y);const B=X.band;B.ax='h';B.c=.5;const q=P110(.5,.5),q2=P110(.5,.1);const a=bandIn49(X,q.x,q.y),b_=bandIn49(X,q2.x,q2.y);B.ax='c';B.R=100;B.cx=.5;B.cy=.5;const c_=bandIn49(X,q.x,q.y),d=bandIn49(X,q.x+200,q.y);return [in1,a,b_,c_,d];}""")
    ok('C09 геометрия полосы (альбом): вертикальная, горизонтальная, круг выхода',r==[True,True,False,True,False],r)
    P2=await page(b,vw=390,vh=844,touch=True)
    r=await P2.js("""()=>{const X=T.m110(49);const p=G.player;T.at(.23,.5);const in1=bandIn49(X,p.x,p.y),geo=[W,H,Math.round(p.x),Math.round(p.y)];const B=X.band;const far=P110(.9,.5);const in2=bandIn49(X,far.x,far.y);B.ax='h';B.c=.5;const q=P110(.5,.5),q2=P110(.5,.1);const a=bandIn49(X,q.x,q.y),b_=bandIn49(X,q2.x,q2.y);
      B.ax='v';B.c=.23;T.hold(1);G.state='play';render(performance.now());return [in1,in2,a,b_,geo,X.in];}""")
    ok('C10 геометрия полосы (телефон, портрет): полоса поворачивается вместе с ареной',r[0] and not r[1] and r[2] and not r[3] and r[4][0]==760 and r[5],r)
    print('ERRS C',P.errs[:4],P2.errs[:4])
# ---------- X: комната 50 и враги в XI ----------
async def Xr(b):
    P=await page(b)
    # 1.4.5: плитка 50 в режиме разработчика — уже не пустая комната, а настоящий бой через песочницу (просьба игрока)
    r=await P.js("""async()=>{G.dev=G.dev||{};devStart(50);await new Promise(r=>setTimeout(r,300));return [G.zb&&G.zb.k,G.mode,!!(window.DEVW&&DEVW.on()),G.state];}""")
    ok('X01 комната 50 из режима разработчика (1.4.5): настоящий бой с боссом 50 в песочнице открытого мира',r[0]=='silence' and r[1]=='world' and r[2] and r[3]=='world',r)
    r=await P.js("""async()=>{DEVW.exit();await new Promise(r=>setTimeout(r,200));return [G.state,!!G.zb,DEVW.on()];}""")
    ok('X02 из боя песочницы — обратно к выбору миссий, бой сброшен',r==['dev',False,False],r)
    r=await P.js("""()=>{const X=T.m110(47);geo47(X);const k=k110();const out={n:X.st.length,r:X.r,k,m:Math.min(...X.st.map(s=>Math.min(s.x,s.y,W-s.x,H-s.y))),dmin:1e9,p:[G.player.x,G.player.y],pd:1e9,hold:G.waveHold,wi:G.waveIdx,ph:X.phase};
      for(let i=0;i<5;i++)for(let j=i+1;j<5;j++)out.dmin=Math.min(out.dmin,Math.hypot(X.st[i].x-X.st[j].x,X.st[i].y-X.st[j].y));for(const s of X.st)out.pd=Math.min(out.pd,Math.hypot(s.x-G.player.x,s.y-G.player.y));return out;}""")
    ok('A01 пять пилотов созвездием: не ближе 60 к краю, не ближе 2,4 r друг к другу, корабль стартует вне колец, волны держатся',r['n']==5 and r['m']>=60 and r['dmin']>=2.4*r['r'] and r['pd']>r['r']*1.5 and r['hold']>990 and r['wi']==0 and r['ph']=='read',r)
    r=await P.js("""()=>{const X=T.m110(47);const s=X.st[0];T.at(s.u,s.v);const rd=[];T.hold(3.2,i=>{if(i%30===0)rd.push(+s.read.toFixed(2));});T.hold(1.2);const w=G.warns[0]||{mx:W/2,my:H-22};
      return {done:s.done,lit:X.lit,ph:X.phase,rd,wi:G.waveIdx,q:G.spawnQ.length+G.warns.length,hold:G.waveHold,mc:G.mc.read110,sp:X.spawnAt&&[Math.round(X.spawnAt.x-s.x),Math.round(X.spawnAt.y-s.y)],wm:w&&[Math.round(w.mx),Math.round(w.my)],wb:G.waveBase[0],wv:G.waves[0].slice().sort().join(',')};}""")
    ok('A02 чтение: 3 с в кольце → прочитан, память отвечает — волна VØID-002 (копейщики со стаей)',r['done']==1 and r['lit']==1 and r['ph']=='fight' and r['wi']==1 and r['q']>=1 and r['wm'] is not None and r['mc']==1 and r['sp']==[0,0] and set(r['wv'].split(','))=={'lancer','scout'} and r['wb']==7,r)
    r=await P.js("""()=>{const X=T.m110(47);const s=X.st[0];T.at(s.u,s.v);T.hold(1.5);const a=s.read;T.at(.5,.5);T.hold(1);const b=s.read;T.hold(8);return [+a.toFixed(2),+b.toFixed(2),+s.read.toFixed(2),s.done,G.mc.readBreak110];}""")
    ok('A03 прерванное чтение тает 0,2/с и считается прерванным (мастерство)',abs(r[0]-1.5)<.05 and abs(r[1]-1.3)<.06 and r[2]==0 and not r[3] and r[4]==1,r)
    r=await P.js("""()=>{const X=T.m110(47);const s0=X.st[0];const s3=X.st[3];T.at(s3.u,s3.v);T.hold(2);const r0=+s3.read.toFixed(2);T.at(s0.u,s0.v);T.hold(3.2);T.hold(3);const cur1=!!X.cur,ph1=X.phase;const s2=X.st[1];T.at(s2.u,s2.v);T.hold(2);const r2=+s2.read.toFixed(2);
      T.killAll();T.hold(.5);const ph2=X.phase;T.hold(2.2);const ph3=X.phase;T.hold(3.2);return [cur1,ph1,r2,ph2,ph3,s2.done,X.lit,r0];}""")
    ok('A04 читается только следующая звезда по порядку; пока память отвечает — не читается; стихла (2 с после боя) — читается следующий',r[0] is False and r[1]=='fight' and r[2]==0 and r[3]=='cool' and r[4]=='read' and r[5]==1 and r[6]==2 and r[7]==0,r)
    r=await P.js("""()=>{const X=T.m110(47);let steps=[];for(let i=0;i<5;i++){const s=X.st.find(q=>!q.done);T.at(s.u,s.v);T.hold(3.3);T.hold(1.5);T.killAll();T.hold(2.3);steps.push([X.lit,G.waveIdx,X.phase]);}
      const blk=x110Block();T.hold(3);return {steps,blk,st:G.state,wi:G.waveIdx,wl:G.waves.length,end:G.endT};}""")
    ok('A05 все пять прочитаны и память добита → «ЗОНА ЧИСТА», миссия завершена; до этого конец заблокирован',r['steps'][4][0]==5 and r['steps'][4][1]==5 and r['blk'] is False and r['st']=='done' and r['steps'][0][1]==1,r)
    r=await P.js("""()=>{const W_=WAVES47;return [W_.map(w=>w.length),W_.flat().every(t=>!!EDEF[t]),W_.flat().length,MISSIONS[46].wavesT.length,MISSIONS[46].hint.join(' ').includes('{SPD}')];}""")
    ok('A06 волны созвездия: 7/5/5/5/7 = 29 врагов, все типы существуют, подсказка подставляет цифры сектора',r[0]==[7,5,5,5,7] and r[1] and r[2]==29 and r[3]==5,r)
    r=await P.js("""()=>{const X=T.m110(47);const s=X.st[0];T.at(s.u,s.v);T.hold(1);const I=hud110();const el=document.getElementById('x90G');hud90();return [I.l,I.k>0,I.r,el&&!el.hidden,el&&el.querySelector('.l').textContent];}""")
    ok('A07 интерфейс: строка «СОЗВЕЗДИЕ · ПРОЧИТАНО n/5» с ходом чтения',r[0].startswith('СОЗВЕЗДИЕ · ПРОЧИТАНО 0/5') and r[1] and r[2]=='ЧИТАЙТЕ VØID-002' and r[3] and r[4].startswith('СОЗВЕЗДИЕ'),r)
    r=await P.js("""()=>{const X=T.m110(47);for(let i=0;i<2;i++){const q=X.st[i];T.at(q.u,q.v);T.hold(3.3);T.hold(1.5);T.killAll();T.hold(2.3);}const s=X.st[2];T.at(s.u,s.v);T.hold(3.3);const n0=G.enemies.filter(e=>e.alive).length;T.hold(12);const types=G.enemies.filter(e=>e.alive).map(e=>e.type);const cap=types.filter(t=>t==='keeper90').length;
      return [n0,types.length,cap,X.phase,G.mc.read110,G.x90.alarmOn,types.filter(t=>t==='keeper90').length];}""")
    ok('A08 память VØID-003: Смотрители со стрелками приходят без Тревоги (alarmOn выкл.), не больше 2 Смотрителей',r[1]>=3 and r[2]<=2 and r[5] is False,r)
    r=await P.js("""()=>{const X=T.m110(47);const out=[];const R0=radioLine;let rc=0;radioLine=function(...a){rc++;return R0.apply(this,a);};for(let i=0;i<5;i++){const s=X.st.find(q=>!q.done);T.at(s.u,s.v);T.hold(3.3);out.push(rc);rc=0;T.hold(1.5);T.killAll();T.hold(2.3);}radioLine=R0;return [out,X.order.length,new Set(X.order).size];}""")
    ok('A09 каждый прочитанный пилот говорит по радио; порядок чтения записан без повторов',all((x or 0)>=1 for x in r[0]) and r[1]==5 and r[2]==5,r)
    print('ERRS A',P.errs[:4])
# ---------- B: 48 «Пуск» ----------
async def B(b):
    P=await page(b)
    r=await P.js("""()=>{const X=T.m110(48);geo48(X);T.hold(3);const p=G.player;return {on:X.on,c:X.con.map(c=>[+c.u,+c.v,Math.round(Math.hypot(c.x-p.x,c.y-p.y))]),btn:[Math.round(X.btn.x-W/2),Math.round(X.btn.y-H/2),X.btn.r],armed:X.btn.armed,wi:G.waveIdx,hold:G.waveHold};}""")
    ok('B01 стол: три контакта на расстоянии > 300 от старта, кнопка в центре r=220, контакты спят, волны держатся',r['on']==0 and all(c[2]>250 for c in r['c']) and r['btn'][0]==0 and r['btn'][1]==0 and r['btn'][2]==220 and r['armed']==0 and r['wi']==0 and r['hold']>990,r)
    r=await P.js("""()=>{const X=T.m110(48);const c=X.con[0];T.at(c.u,c.v);T.hold(.3);const on1=c.on,wi1=G.waveIdx;T.at(.5,.5);T.hold(1.5);const wi2=G.waveIdx,w=G.waveBase[0],typ=G.waves[0].slice().sort().join(',');
      const c2=X.con[1];G.pb.push({x:c2.x-60,y:c2.y,px:c2.x-60,py:c2.y,vx:980,vy:0,dmg:10,pierce:0,rico:0,life:.5,hit:[]});T.hold(.4);const onBusy=c2.on;T.killAll();G.waveIdx=X.rel;T.hold(.3);G.pb.push({x:c2.x-60,y:c2.y,px:c2.x-60,py:c2.y,vx:980,vy:0,dmg:10,pierce:0,rico:0,life:.5,hit:[]});T.hold(.4);return [on1,wi1,wi2,w,typ,c2.on,X.on,G.waveIdx<=X.rel,onBusy];}""")
    ok('B02 контакт поднимается подходом (A) и выстрелом в затишье (B), не выстрелом в бою; расчёт Отсчёта — Связист, 3 стрелка, Щитоносец',r[0]==1 and r[2]>=1 and r[3]==5 and r[4]=='gunner,gunner,gunner,shielder,signaller' and r[5]==1 and r[6]==2 and r[7] and r[8]==0,r)
    r=await P.js("""()=>{const X=T.m110(48);for(const c of X.con)contact48(X,c);T.hold(2);const a0=X.btn.armed,n0=T.alive()+G.warns.length+G.spawnQ.length;T.killAll();G.waveIdx=X.rel;T.hold(.5);const a1=X.btn.armed;
      T.at(.5,.5);T.hold(1);const fin=X.btn.fin,wi=G.waveIdx,rel=X.rel,wl=G.waves.length,last=G.waves[3].slice().sort().join(',');return [a0,n0>2,a1,fin,wi,rel,wl,last];}""")
    ok('B03 кнопка доступна, когда все три подняты и стол почти чист; первый шаг в круг зовёт последний расчёт',r[0]==0 and r[1] and r[2]==1 and r[3]==1 and r[5]==4 and r[6]==4 and r[7]=='autopilot,autopilot,commander,fireship,stamp,stamp',r)
    r=await P.js("""()=>{const X=T.m110(48);for(const c of X.con)contact48(X,c);T.killAll();G.waveIdx=X.rel;T.hold(.5);T.at(.5,.5);T.hold(1);const B=X.btn;T.killAll();G.waveIdx=X.rel;
      const e=T.sp('gunner',B.x+100,B.y);e.cd=999;T.hold(2,()=>{e.x=B.x+100;e.y=B.y;e.vx=e.vy=0;});const h1=+B.hold.toFixed(2),pad=!!B.onPad;e.alive=false;T.killAll();G.waveIdx=X.rel;T.hold(2);const h2=+B.hold.toFixed(2);T.at(.5,.1);T.hold(2);const h3=+B.hold.toFixed(2),drop=G.mc.puskDrop110;
      T.at(.5,.5);T.killAll();G.waveIdx=X.rel;T.hold(11.5);return [h1,pad,h2,h3,drop,B.fired,G.state,X.flashT>0];}""")
    ok('B04 отсчёт ждёт, пока враг на столе; идёт при чистом столе; выход из круга — течёт назад 0,5/с; 10 с → ПУСК',abs(r[0]-1.5)<.1 and r[1] and abs(r[2]-3.5)<.1 and abs(r[3]-2.5)<.12 and r[4]==1 and r[5]==1 and r[6]=='done',r)
    r=await P.js("""()=>{const X=T.m110(48);for(const c of X.con)contact48(X,c);T.hold(1.5);T.killAll();G.waveIdx=X.rel;T.hold(.5);T.at(.5,.5);T.hold(1.2);for(let i=0;i<6;i++)T.sp(['commander','stamp','autopilot','gunner','scout','fireship'][i],W*.1+i*40,H*.1);G.spawnQ.push('scout');
      const n0=T.alive();X.btn.hold=9.9;T.killAll();G.waveIdx=X.rel;for(let i=0;i<4;i++){const e=T.sp('gunner',W*.1+i*40,H*.1);e.cd=999;}T.hold(.4);const fired=X.btn.fired,n1=T.alive(),q=G.spawnQ.length+G.warns.length,eb=G.eb.length;T.hold(3);return [n0>=6,fired,n1,q,eb,G.state,G.kills-G.missionKills>=4];}""")
    ok('B05 ПУСК стирает всё на столе: враги, очередь, снаряды; зона чиста — миссия завершена, убийства засчитаны',r[0] and r[1]==1 and r[2]==0 and r[3]==0 and r[4]==0 and r[5]=='done' and r[6],r)
    r=await P.js("""()=>{const X=T.m110(48);const p=G.player;for(let i=0;i<4;i++){const e=T.sp('shielder',W*.2+i*60,H*.2);cap90(e);}const n=T.cnt('shielder');const types=G.enemies.filter(e=>e.alive).map(e=>e.type).sort().join(',');
      for(let i=0;i<3;i++){const e=T.sp('signaller',W*.2+i*60,H*.3);cap90(e);}return [n,types,T.cnt('signaller'),CAP90.shielder,FB95[10].join(',')];}""")
    ok('B06 лимиты сектора XI: один Щитоносец и один Связист одновременно, лишние становятся рядовыми; общий CAP90 не тронут',r[0]==1 and r[2]==1 and r[3] is None and all(t in ['shielder','scout','gunner','rammer','lancer','signaller'] for t in r[1].split(',')),r)
    r=await P.js("""()=>{const X=T.m110(48);const c=X.con[2];T.at(c.u,c.v);T.hold(.3);T.at(.5,.5);T.hold(14);const t=G.enemies.filter(e=>e.alive).map(e=>e.type);return [t.filter(x=>x==='unborn').length,t.includes('singer')||G.kills>G.missionKills,t.includes('fireship')||t.length<3,X.on];}""")
    ok('B07 Хор: Певчий, Нерождённые и Брандер приходят с нижнего края и живут в арене',r[0]<=5 and r[1] and r[3]==1,r)
    r=await P.js("""()=>{const X=T.m110(48);T.hold(1);const I=hud110();const a=I.l;for(const c of X.con)contact48(X,c);T.hold(.2);const b=hud110().l;T.killAll();G.waveIdx=X.rel;T.hold(.5);const c_=hud110().l;return [a,b,c_,bg48.toString().includes('ОЧИСТИТЕ СТОЛ')];}""")
    ok('B08 интерфейс пуска: контакты n/3 → «ОЧИСТИТЕ СТОЛ» → «ПУСК · 10 С»',r[0]=='КОНТАКТЫ 0/3' and r[1]=='ПУСК · ОЧИСТИТЕ СТОЛ' and r[2].startswith('ПУСК · 10') and r[3],r)
    print('ERRS B',P.errs[:4])
# ---------- C: 49 «Миг» ----------
async def C(b):
    P=await page(b)
    r=await P.js("""()=>{const X=T.m110(49);const B=X.band,p=G.player;const out={ph0:B.ph,ax:B.ax,c0:+B.c.toFixed(2),inP:X.in,px:+(p.x/W).toFixed(2)};T.hold(40.5);out.ph1=B.ph;out.turn=+B.turn.toFixed(1);out.c1=+B.c.toFixed(2);T.hold(3.1);out.ph2=B.ph;out.ax2=B.ax;out.c2=+B.c.toFixed(2);
      T.hold(32.2);out.ph3=B.ph;T.hold(3.1);out.ax3=B.ax;out.c3=+B.c.toFixed(2);T.hold(32.2);T.hold(3.1);out.ph4=B.ph;out.ax4=B.ax;out.R0=Math.round(B.R);T.hold(20.2);out.ph5=B.ph;out.R1=Math.round(B.R);out.blk=x110Block();T.hold(2.1);out.blk2=x110Block();return out;}""")
    ok('C01 полоса: 40 с вправо → поворот 3 с → 32 с вниз → поворот → 32 с влево → сжатие 20 с к точке выхода (r=180) → финал',r['ph0']==0 and r['ax']=='v' and r['c0']==.23 and r['inP'] and r['ph1']==0 and r['turn']>0 and r['c1']==.77 and r['ph2']==1 and r['ax2']=='h' and r['ph3']==1 and r['ax3']=='v' and abs(r['c3']-.77)<.02 and r['ph4']==3 and r['ax4']=='c' and r['R0']>250 and r['ph5']==4 and r['R1']==180 and r['blk'] and r['blk2'] is False,r)
    r=await P.js("""()=>{const X=T.m110(49);const p=G.player;X.notch=4;X.band.ph=0;G.waveHold=999;X.rel=5;G.waveIdx=5;T.at(.23,.5);T.hold(2);const hp0=p.hp,in0=X.in;T.at(.8,.5);G.player.hp=100;p.inv=0;let hp1=0;T.tick(1.1,()=>{p.vx=p.vy=0;});hp1=+p.hp.toFixed(2);T.tick(2,()=>{p.vx=p.vy=0;});const hp2=+p.hp.toFixed(2);
      p.dashCd=1;p.dashCdMax=1;T.tick(1,()=>{p.vx=p.vy=0;p.hp=100;});const cd=+p.dashCd.toFixed(2);T.at(.23,.5);T.tick(1,()=>{p.vx=p.vy=0;});const cd2=+p.dashCd.toFixed(2);return [in0,hp0,hp1,hp2,cd,cd2,Math.round(G.mc.out110*10)/10,X.vig>0];}""")
    ok('C02 вне полосы: 1,2 с тишины, потом стирание 2%/с, рывок не заряжается; внутри — рывок заряжается, корпус цел',r[0] and r[1]==100 and r[2]==100 and r[3]<=96.2 and r[3]>=95.5 and abs(r[4]-1)<.05 and r[5]<=0.05 and r[6]>=4,r)
    r=await P.js("""()=>{const X=T.m110(49);G.waveHold=999;X.rel=0;const a=T.sp('gunner',W*.23,H*.3),b_=T.sp('gunner',W*.85,H*.3);a.cd=b_.cd=999;T.hold(.2);const ka=a.tK,kb=b_.tK;T.hold(1.6);const hb0=b_.hp;T.hold(2);const hb1=b_.hp,ha=a.hp;
      const bl={x:W*.85,y:H*.6,vx:100,vy:0,rift:false},bi={x:W*.23,y:H*.6,vx:100,vy:0};return [ka,kb,hb0===b_.maxHp||hb0<b_.maxHp,hb1<hb0,ha===a.maxHp,+bK110(bl).toFixed(2),bK110(bi)];}""")
    ok('C03 враги вне полосы вязнут (×0,6) и через 1,5 с стираются 3%/с; внутри — целы; снаряды снаружи ×0,6',r[0]==1 and r[1]==.6 and r[3] and r[4] and r[5]==.6 and r[6]==1,r)
    r=await P.js("""()=>{const X=T.m110(49);const B=X.band;const seen=[];T.hold(1.5);seen.push([X.notch,G.waveIdx]);T.killAll();T.hold(21);seen.push([X.notch,G.waveIdx]);T.killAll();T.hold(22);T.killAll();T.hold(14);seen.push([X.notch,G.waveIdx]);T.killAll();T.hold(18);seen.push([X.notch,G.waveIdx,B.ph]);
      T.killAll();T.hold(20);T.hold(16);T.hold(3.2);seen.push([X.notch,X.rel,B.ph,X.allies.length]);return seen;}""")
    ok('C04 четыре засечки идут по ходу полосы (и раньше — когда затишье), финал у сжатия: оставшиеся + 2 Эхо-призрака и союзники',r[0][0]==1 and r[1][0]>=2 and r[2][0]>=3 and r[3][0]==4 and r[4][1]==5 and r[4][2]==3 and r[4][3]>=2,r)
    r=await P.js("""()=>{const X=T.m110(49,{flags:{cradle22:'keep',fleet27:'engine',line31:'write',well38:'third',heart42:'wake',shore46:'record'}});allies49(X);const n=X.allies.length,names=X.allies.map(a=>a.name).join(',');
      const Y=T.m110(49,{flags:{cradle22:'leave',heart42:'wake'}});delete G.save.story.fleet27;delete G.save.story.line31;delete G.save.story.well38;delete G.save.story.shore46;allies49(Y);return [n,names,Y.allies.length,Y.allies.map(a=>a.name).join(',')];}""")
    ok('C05 союзники: двое + милосердные выборы (не больше 6), имена — по выборам',r[0]==6 and r[1].startswith('УЧЕНИК,ПАССАЖИР,КОЛЫБЕЛЬ,ФЛОТ') and r[2]==3 and r[3]=='УЧЕНИК,ПАССАЖИР,СЕРДЦЕ',r)
    r=await P.js("""()=>{const X=T.m110(49);allies49(X);T.at(.23,.5);G.waveHold=999;const e=T.sp('gunner',G.player.x+200,G.player.y);e.cd=999;const ex=e.x,ey=e.y;let shots=0;T.hold(3,()=>{e.x=ex;e.y=ey;e.vx=e.vy=0;shots+=G.pb.filter(b=>b.a85).length;});const A=X.allies[0];A.hp=1;G.eb.push({x:A.x,y:A.y,vx:0,vy:0,dmg:5,col:'#fff',r:4,life:1});T.hold(.2);
      return [shots>0,X.allies.length,G.mc.allyLost110,e.hp<e.maxHp];}""")
    ok('C06 союзники стреляют по врагам рядом и гибнут от вражеских снарядов (потеря считается)',r[0] and r[1]==1 and r[2]==1 and r[3],r)
    r=await P.js("""()=>{const X=T.m110(49);const B=X.band;B.ph=4;B.t=3;X.rel=5;G.waveIdx=5;T.killAll();T.hold(2.5);return [G.state,G.endT<=0];}""")
    ok('C07 у точки выхода без врагов — «ЗОНА ЧИСТА», миссия завершена',r[0]=='done',r)
    r=await P.js("""()=>{const X=T.m110(49);const B=X.band;B.t=37.2;T.at(.75,.5);T.hold(1);const w1=B.warn,ext=mus110({ext:{},I:0,lp:18000}).ext;const I1=hud110();T.at(.08,.5);T.hold(2);const I2=hud110();const ex2=mus110({ext:{},I:0,lp:18000});return [w1,!!ext.turn110,I1.l,I1.r,I2.r,I2.col,ex2.lp,!!ex2.ext.out110];}""")
    ok('C08 предупреждение о повороте за 3 с (музыка — сирена), снаружи — «ВНЕ МИГА», музыка глушится',r[0]==1 and r[1] and 'МИГ' in r[2] and r[3].startswith('ЗАСЕЧКИ') and r[4]=='ВНЕ МИГА' and r[6]<=1500 and r[7],r)
    r=await P.js("""()=>{const X=T.m110(49);const p=G.player;T.at(.23,.5);const in1=bandIn49(X,p.x,p.y);const B=X.band;B.ax='h';B.c=.5;const q=P110(.5,.5),q2=P110(.5,.1);const a=bandIn49(X,q.x,q.y),b_=bandIn49(X,q2.x,q2.y);B.ax='c';B.R=100;B.cx=.5;B.cy=.5;const c_=bandIn49(X,q.x,q.y),d=bandIn49(X,q.x+200,q.y);return [in1,a,b_,c_,d];}""")
    ok('C09 геометрия полосы (альбом): вертикальная, горизонтальная, круг выхода',r==[True,True,False,True,False],r)
    P2=await page(b,vw=390,vh=844,touch=True)
    r=await P2.js("""()=>{const X=T.m110(49);const p=G.player;T.at(.23,.5);const in1=bandIn49(X,p.x,p.y),geo=[W,H,Math.round(p.x),Math.round(p.y)];const B=X.band;const far=P110(.9,.5);const in2=bandIn49(X,far.x,far.y);B.ax='h';B.c=.5;const q=P110(.5,.5),q2=P110(.5,.1);const a=bandIn49(X,q.x,q.y),b_=bandIn49(X,q2.x,q2.y);
      B.ax='v';B.c=.23;T.hold(1);G.state='play';render(performance.now());return [in1,in2,a,b_,geo,X.in];}""")
    ok('C10 геометрия полосы (телефон, портрет): полоса поворачивается вместе с ареной',r[0] and not r[1] and r[2] and not r[3] and r[4][0]==760 and r[5],r)
    print('ERRS C',P.errs[:4],P2.errs[:4])
# ---------- X: комната 50 и враги в XI ----------
async def Xr(b):
    P=await page(b)
    # 1.4.5: плитка 50 в режиме разработчика — уже не пустая комната, а настоящий бой через песочницу (просьба игрока)
    r=await P.js("""async()=>{G.dev=G.dev||{};devStart(50);await new Promise(r=>setTimeout(r,300));return [G.zb&&G.zb.k,G.mode,!!(window.DEVW&&DEVW.on()),G.state];}""")
    ok('X01 комната 50 из режима разработчика (1.4.5): настоящий бой с боссом 50 в песочнице открытого мира',r[0]=='silence' and r[1]=='world' and r[2] and r[3]=='world',r)
    r=await P.js("""async()=>{DEVW.exit();await new Promise(r=>setTimeout(r,200));return [G.state,!!G.zb,DEVW.on()];}""")
    ok('X02 из боя песочницы — обратно к выбору миссий, бой сброшен',r==['dev',False,False],r)
    r=await P.js("""()=>{const X=T.m110(47);G.waveHold=999;X.rel=0;const TY=['scout','lancer','frost','rammer','keeper90','gunner','miner','hunter','commander','clot90','signaller','shielder','guard','labrat','singer','unborn','fireship','stamp','autopilot','echo80','loop','echo100','hollow100','eraser100','lost95','fixer100','inverse'];
      const bad=[];for(const t of TY){const e=T.sp(t,W*.3+Math.random()*W*.4,H*.3+Math.random()*H*.4);}T.hold(4);for(const e of G.enemies){if(!Number.isFinite(e.x)||!Number.isFinite(e.y)||!Number.isFinite(e.hp))bad.push(e.type);}
      return [bad,G.enemies.filter(e=>e.alive).length>10,G.x90.echoP.length>100,G.eb.length];}""")
    ok('X03 все 27 типов врагов сектора живут в арене XI без NaN и ошибок; след для Эхо пишется',r[0]==[] and r[1] and r[2],r)
    r=await P.js("""()=>{const X=T.m110(47);G.waveHold=999;X.rel=0;const v=T.sp('gunner',W*.5,H*.3);v.cd=999;hurt(v,v.maxHp*.5,{});const hp0=v.hp;const f=T.sp('fixer100',W*.5+60,H*.3);const dl=!!(v.dl&&v.dl.length);T.hold(2.2);return [hp0<v.maxHp,v.hp>hp0,dl];}""")
    ok('X04 Корректор в XI чинит раненого (журнал урона dl100 ведётся и в секторе XI)',r[0] and r[1] and r[2],r)
    r=await P.js("""()=>{const X=T.m110(47);G.waveHold=999;X.rel=0;const p=G.player;T.at(.5,.5);const c=T.sp('clot90',p.x+120,p.y);c.lp=0;T.hold(3);c.alive=false;const n=G.x90.pud.length;const q=G.x90.pud[0];let slow=null;if(q){T.at(.15,.15);KEYS.KeyD=true;const x0=p.x;T.tick(.5,()=>{});const d1=p.x-x0;T.at(q.x/W,q.y/H);T.tick(.5,()=>{});KEYS.KeyD=false;const d2=p.x-q.x;slow=[Math.round(d1),Math.round(d2),inPud90(q.x,q.y)];}
      T.hold(11);return [n>=1,slow,G.x90.pud.length];}""")
    ok('X05 Тромб в XI растекается лужей: лужа вяжет корабль и тает через 10 с',r[0] and r[1] is not None and r[1][1]<r[1][0]*.8 and r[1][2] and r[2]==0,r)
    r=await P.js("""()=>{const X=T.m110(47);G.waveHold=999;X.rel=0;const p=G.player;T.at(.5,.5);const e=T.sp('eraser100',p.x+300,p.y);e.zt=0;e.skT95=999;T.hold(6);const n=G.x90.ez.length;T.hold(8);return [n>=1,G.x90.ez.length,typeof ezDraw100];}""")
    ok('X06 Ластик в XI кладёт зоны стирания, зоны живут и тают (tick и draw в XI)',r[0] and r[1]<=1 and r[2]=='function',r)
    r=await P.js("""()=>{const X=T.m110(47);const p=G.player;T.at(.5,.5);X.spawnAt={x:W*.1,y:H*.5};const o1=spawn110('scout',{});const w1=G.warns[G.warns.length-1];X.spawnAt={x:p.x+10,y:p.y};const o2=spawn110('scout',{});const w2=G.warns[G.warns.length-1];
      return [o1,w1&&[Math.round(w1.mx),Math.round(w1.my/H*100)/100],o2,w2&&Math.round(Math.hypot(w2.mx-p.x,w2.my-p.y))];}""")
    ok('X07 появление от ближайшего к точке события края; не ближе 240 к кораблю',r[0] is True and r[1][0]==22 and abs(r[1][1]-.5)<.12 and r[2] is True and r[3]>=240,r)
    print('ERRS X',P.errs[:4])
# ---------- P: звук, музыка, кадр, тексты ----------
async def Pz(b):
    P=await page(b)
    r=await P.js("""()=>{audioInit();if(!AU.ctx)return ['noctx'];SET.sfx=true;const ks=['read','readOk','wake','calm','contact','tick','tock','armed','pusk','erode','edge','warn','turn','ally'];const bad=[];for(const k of ks){try{SND110[k]=0;snd110(k,W/2);}catch(e){bad.push(k+':'+e.message);}}return [bad,ks.length];}""")
    ok('P01 все 14 звуков сектора XI играют без ошибок',r[0]==[] and r[1]==14,r)
    r=await P.js("""()=>{audioInit();if(!AU.ctx)return ['noctx'];const out=[];for(const m of [47,48,49]){const X=T.m110(m);T.hold(.5);G.state='play';const T_=musTarget();out.push(T_.id);MUS.cur=null;musicTick(.3);musicTick(.3);const Pc=MUS.cur;if(!Pc)out.push('nocur');else{try{Pc.ext=T_.ext;scapeRun(Pc,AU.ctx.currentTime,AU.ctx.currentTime+6);out.push(Pc.id);}catch(e){out.push('ERR '+e.message);}}}
      const X=T.m110(48);for(const c of X.con)contact48(X,c);T.killAll();G.waveIdx=X.rel;T.hold(.5);T.at(.5,.5);T.hold(1);T.killAll();G.waveIdx=X.rel;T.hold(2);const T2=musTarget();return [out,T2.ext.pusk110>0,T2.I];}""")
    ok('P02 музыка: m47/m48/m49 и бой XII играют свои шаги (хор, метроном, тиканье); отсчёт пуска ведёт интенсивность',r[0]==['m47','m47','m48','m48','m49','m49'] and r[1] and r[2]>=.5,r)
    r=await P.js("""()=>{const out={};for(const m of [47,48,49]){const X=T.m110(m);if(m===48){for(const c of X.con)contact48(X,c);}if(m===49){X.band.ph=3;X.band.t=10;allies49(X);}T.hold(3);G.state='play';const ts=[];for(let i=0;i<40;i++){const t0=performance.now();render(performance.now());secVignette();ts.push(performance.now()-t0);}ts.sort((a,b)=>a-b);out[m]=+ts[20].toFixed(2);}return out;}""")
    ok('P03 кадр ПК: медиана отрисовки каждой миссии XI < 12 мс',all(v<12 for v in r.values()),r)
    P2=await page(b,vw=390,vh=844,touch=True)
    r=await P2.js("""()=>{const out={};for(const m of [47,48,49]){const X=T.m110(m);if(m===48){for(const c of X.con)contact48(X,c);}if(m===49){X.band.ph=1;X.band.t=10;}T.hold(3);G.state='play';const ts=[];for(let i=0;i<30;i++){const t0=performance.now();render(performance.now());secVignette();mobOverlay(performance.now());ts.push(performance.now()-t0);}ts.sort((a,b)=>a-b);out[m]=+ts[15].toFixed(2);}return [out,P2errs=0];}""")
    ok('P04 кадр телефона (портрет): медиана отрисовки < 16 мс, без ошибок',all(v<16 for v in r[0].values()) and not P2.errs,[r,P2.errs[:2]])
    r=await P.js("""()=>{const h=document.body.innerHTML;return [h.includes('<div class="ver" id="verTag">1.5.10 α</div>'),(()=>{cxTab='log';openCodex('menu');return $('#cxBody')?$('#cxBody').innerText.includes('0.9.7'):document.body.innerText.includes('0.9.7 α');})(),MASTERY[46].t,MASTERY[47].t,MASTERY[48].t,SEC_MECH[10],SEC_SCALE[10].zero];}""")
    ok('P05 тексты: эмблема 0.9.9, хроника 0.9.7, мастерства 47–49, механика сектора',r[0] and r[1] and 'прервав' in r[2] and 'ПУСК' in r[3] and 'Мига' in r[4] and r[5]=='НУЛЕВАЯ ТОЧКА · ПАМЯТЬ' and r[6]==1,r)
    r=await P.js("""()=>{const X=T.m110(49);const B=X.band;B.ph=3;B.t=19;T.hold(1.3);const sv=secVignette.toString().includes('SS.zero');T.at(.9,.5);T.hold(3);const v=X.vig;G.state='play';render(performance.now());top110(performance.now()/1000);return [sv,v>0,X.flashT];}""")
    ok('P06 виньетка сектора XI розовая и усиливается вне Мига; вспышка пуска поверх всего',r[0] and r[1],r)
    print('ERRS P',P.errs[:4])
# ---------- S: сохранение и совместимость ----------
async def S(b):
    P=await page(b)
    r=await P.js("""()=>{T.fresh();const S=G.save;S.cleared=46;for(let m=1;m<=49;m++)S.medals[m]={clear:1};saveWorld();startWorld(false);const S2=G.save;const st=[47,48,49,50].map(nodeState);const nt=nextTarget();return [st,nt&&nt.label,S2.story&&S2.story.zero49];}""")
    ok('S01 старое сохранение (46 пройдено) загружается: 47–49 пройдены, 50 открыт по карте, но закрыт карточкой, цель — миссия 50',r[0]==['done','done','done','open'] and r[1]=='БОСС 50' and r[2] is None,r)
    r=await P.js("""()=>{T.fresh();T.openAll();const S=G.save;S.story.zero49=1;saveWorld();const raw=JSON.parse(localStorage.getItem('void_world'));return [raw.story.zero49,inSectors(38500,16000),riftInfo(38500,16000).d<0,sectorName(38500,16000)];}""")
    ok('S02 флаг zero49 сохраняется; XII — настоящий сектор без Разлома внутри',r[0]==1 and r[1] and r[2] and r[3]=='???',r)
    r=await P.js("""()=>{T.fresh();T.openAll();openMap('journals');const h=$('#mapJ')?$('#mapJ').innerHTML:document.body.innerHTML;const n=WORLD.journals.filter(j=>j.sec===10).length;return [G.state,n>=1,document.body.innerText.includes('XII')];}""")
    ok('S03 вкладка журналов строится с 12 секторами (записи XI на месте)',r[0]=='map' and r[1],r)
    r=await P.js("""()=>{T.fresh();T.openAll();const out=[];for(const m of [45,46]){enterNode(m,false);if(G.state==='intro')startMission();let n=0;while(G.state==='levelup'&&n++<40)choose(0);T.hold(3);out.push([G.x90&&G.x90.sec,G.x110,on95(),T.alive()>=0]);returnToWorld();}return out;}""")
    ok('S04 сектор X (45–46) работает как раньше: x110 там нет, on95 включён',all(q[0]==9 and q[1] is None and q[2] for q in r),r)
    print('ERRS S',P.errs[:4])
import os as _o
_G=_o.environ.get('GROUPS')
_all=[('L',L),('A',A),('B',B),('C',C),('X',Xr),('P',Pz),('S',S)]
asyncio.run(run([g for g in _all if not _G or g[0] in _G.split(',')],'q110.json'))
