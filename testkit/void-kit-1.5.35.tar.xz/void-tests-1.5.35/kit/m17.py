# 0.9 · часть 17: «Сердце Ковчега и Стёртые берега» — сектора IX–X
import sys
SP='@@KIT@@/'
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m17: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
D90=open(SP+'d90.js',encoding='utf8').read()
B90=''.join(open(SP+f,encoding='utf8').read() for f in ['b90a.js','b90b.js','b100a.js','b90c.js','b100b.js','b90d.js','b90e.js'])
R('(function genMissions(){',D90+'\n(function genMissions(){')
R('// ---------- Главный цикл ----------',B90+'\n// ---------- Главный цикл ----------')
R("function spawnSB(kind){if(kind==='lek'||kind==='well')return sb85Spawn(kind);","function spawnSB(kind){if(SBX[kind]||kind==='lek'||kind==='well')return sb85Spawn(kind);")
# ИИ, урон, гибель
R("e.type!=='pilgrim'&&!e.retreat&&G.latch74!==e)edge74","e.type!=='pilgrim'&&e.type!=='witness100'&&!e.leave90&&!e.retreat&&G.latch74!==e)edge74")
R("if(SB85T.has(e.type))return s85Update(e,dt,c);if(S80T.has(e.type))return s80Update(e,dt,c);","if(S90T.has(e.type))return s90Update(e,dt,c);if(SB85T.has(e.type))return s85Update(e,dt,c);if(S80T.has(e.type))return s80Update(e,dt,c);")
R("function s74Hurt(e,dmg,src){if(SB85T.has(e.type))return s85Hurt(e,dmg,src);","function s74Hurt(e,dmg,src){if(S90T.has(e.type))return s90Hurt(e,dmg,src);if(SB85T.has(e.type))return s85Hurt(e,dmg,src);",2)
R("s80Killed(e,silent);s85Killed(e,silent);","s80Killed(e,silent);s85Killed(e,silent);s90Killed(e,silent);")
R("function b80Hit(b){if(b85Hit(b))return true;","function b80Hit(b){if(b85Hit(b))return true;if(b90Hit(b))return true;")
R("function pulse80(p,R){pulse85(p,R);","function pulse80(p,R){pulse85(p,R);pulse90(p,R);mod90Pulse(p);")
R("BH-p.r);drift85(p,dt);","BH-p.r);drift85(p,dt);drift90(p,dt);")
R("  e.hp-=dmg;e.flash=.07;sfx('hit');","  if(G.x90&&inMission()){if(G.x90.pud.length)dmg*=pud90K(e);if(G.x90.sec===9)dl100(e,dmg);}\n  e.hp-=dmg;e.flash=.07;sfx('hit');")
R("  if(G.world&&(e.peace||e.dig!==undefined||w58Hidden(e)))return false;\n  return true;","  if(G.world&&(e.peace||e.dig!==undefined||w58Hidden(e)))return false;\n  if(!targ90(e))return false;\n  return true;")
R("else if(e.type==='labrat'&&e.beam)d*=.7;else if(e.type==='echo80')d*=.8;","else if(e.type==='labrat'&&e.beam)d*=.7;else if(e.type==='echo80')d*=.8;d*=aw90(e);")
R("o.buff=1.25;}s74Buffs();","o.buff=1.25;}s74Buffs();buffs90();")
R("    const cd0=e.cd;","    const cd0=e.cd;G.curE=e;")
R("  // разведение","  G.curE=null;\n  // разведение")
R("spd*=ebK();const b={x,y,vx:Math.cos(a)*spd,vy:Math.sin(a)*spd,dmg,col,r,life:9,bc};","spd*=ebK();if(G.curE&&G.curE.dmgK90)dmg*=G.curE.dmgK90;const b={x,y,vx:Math.cos(a)*spd,vy:Math.sin(a)*spd,dmg,col,r,life:9,bc};")
R("function enemyTarget(e){","function enemyTarget(e){{const q90=cloak90(e)||witT100(e)||door90(e);if(q90)return q90;}")
R("let tg=man?null:pickTarget();","let tg=man?null:pickTarget();G.tg90=man?G.aimLock:tg;")
# волны: воспоминания
R("if(typeof ty==='string'&&ty.startsWith('pack:'))packSpawn(ty.slice(5));else edgeSpawn(ty);","if(typeof ty==='string'&&ty.startsWith('pack:'))packSpawn(ty.slice(5));else if(typeof ty==='string'&&ty.startsWith('mem:'))mem100Spawn(ty.slice(4));else edgeSpawn(ty);")
R("if(w.o){if(w.o.pair)o2.pair=w.o.pair;if(w.o.elite)o2.elite=true;}","if(w.o){if(w.o.pair)o2.pair=w.o.pair;if(w.o.elite)o2.elite=true;if(w.o.mem100)o2.mem100=1;}")
# отрисовка
R("function d80Under(t){sb85Under(t);","function d80Under(t){sb85Under(t);under90(t);")
R("function d80Draw(t){const p=G.player;if(!p)return;","function d80Draw(t){draw90(t);const p=G.player;if(!p)return;")
R("if(inMission())sb85Top(t);","if(inMission()){sb85Top(t);top90(t);}")
R("function drawE80(e,t,icon,col,face,alpha,P){if(SB85T.has(e.type))return drawE85(","function drawE80(e,t,icon,col,face,alpha,P){if(D90T.has(e.type))return drawE90(e,t,icon,col,face,alpha,P);if(SB85T.has(e.type))return drawE85(")
R("if(!icon&&e.type!=='mine'&&e.type!=='shell'&&e.type!=='obseg'&&!e.ghost)glow(","if(!icon&&e.type!=='mine'&&e.type!=='shell'&&e.type!=='obseg'&&!e.ghost&&!e.hid90)glow(")
R("&&!e.sbk&&e.maxHp>=30)","&&!e.sbk&&e.maxHp>=30&&!e.noBar90&&!e.hid90)")
R("const d=EDEF[e.type],col=e.flash>0?'#ffffff':e.rebuilt?'#b5652e':d.col;","const d=EDEF[e.type],col=e.flash>0?'#ffffff':e.rebuilt?'#b5652e':e.mem100?'#a8b4b0':d.col;")
R("||w85DrawSkin(id,t,sp,o,A,fl,edge))","||w85DrawSkin(id,t,sp,o,A,fl,edge)||w90DrawSkin(id,t,sp,o,A,fl,edge))")
R("SS.source?`rgba(107,140,255,${.12+.03*Math.sin(G.t*TAU/3)})`:","SS.ark?`rgba(216,54,74,${.12+.08*beat90(G.t)})`:SS.shore?'rgba(122,255,201,.08)':SS.source?`rgba(107,140,255,${.12+.03*Math.sin(G.t*TAU/3)})`:")
# миссия: инициализация, тик, выход, итог
R("function t80Init(M){t85Init(M);","function t80Init(M){t85Init(M);t90Init(M);")
R("function t80Tick(dt){t85Tick(dt);","function t80Tick(dt){t85Tick(dt);t90Tick(dt);")
R("function toMenu(){unlockArena();r85Reset();G.ally85w=null;","function toMenu(){unlockArena();r85Reset();G.ally85w=null;r90Reset();G.ally90w=null;")
R("if(M&&M.gen&&M.sec===6&&G.mc&&!G.mc.seen80)conEvent('clean85');}","if(M&&M.gen&&M.sec===6&&G.mc&&!G.mc.seen80)conEvent('clean85');done90(M);}")
R("try{musicTick(dt);}catch(err){console.error(err);}","try{musicTick(dt);if(G.state!=='play'&&G.x90&&(G.x90.hudAll||G.x90.hud&&G.x90.hud.cur))clearHud100();}catch(err){console.error(err);}")
# стоп-кадр
R("const dt=G.resumeK>0&&(G.state==='play'||G.state==='world')?dt0*.3:dt0,sub=","const dt=hsK90(G.resumeK>0&&(G.state==='play'||G.state==='world')?dt0*.3:dt0,dt0),sub=")
# настройки: тряска и мягкое стирание интерфейса
R("function shake(v){if(SET.fx){","function shake(v){if(SET.fx){v*=(SET.shake===undefined?1:SET.shake);")
R("orient:'auto',fsHintShown:false};","orient:'auto',fsHintShown:false,shake:1,noErase:false};")
R("textScale:[1,1.15,1.3]};","textScale:[1,1.15,1.3],shake:[0,.5,1]};")
R("[30,'30 · ЭКОНОМИЯ БАТАРЕИ']]]],","[30,'30 · ЭКОНОМИЯ БАТАРЕИ']]]],shake:[['ЭКРАН · ТРЯСКА',[[0,'НЕТ'],[.5,'СЛАБАЯ'],[1,'ПОЛНАЯ']]]],")
R("${segHTML('fps')}","${segHTML('fps')}${segHTML('shake')}")
R("${togHTML('softInv','МЯГКАЯ ИЗНАНКА · ЗАМЕДЛЕНИЕ ВМЕСТО ИНВЕРСИИ')}","${togHTML('softInv','МЯГКАЯ ИЗНАНКА · ЗАМЕДЛЕНИЕ ВМЕСТО ИНВЕРСИИ')}${togHTML('noErase','НЕ СТИРАТЬ ИНТЕРФЕЙС · ЗАТЕМНЯТЬ ВМЕСТО')}")
# модули и награды
R("G.st.dmg*=playerDmgK();","G.st.dmg*=playerDmgK()*memK90();")
R("if(M&&M.gen&&SEC_SCALE[M.sec])return SEC_SCALE[M.sec].rew;","if(M&&M.gen&&SEC_SCALE[M.sec])return SEC_SCALE[M.sec].rew*(storyFlag('shore46')==='carry'?1.1:1);")
# сохранение
R("  if(S.w85!==undefined){","  sanitize90(S,num,obj);\n  if(S.w85!==undefined){")
# открытый мир
R("if(!W80.gen)return;w85WorldTick(dt);","if(!W80.gen)return;w85WorldTick(dt);w90WorldTick(dt);")
R("const ws=w80S(),p=G.player;w85Draw(t);","const ws=w80S(),p=G.player;w85Draw(t);w90Draw(t);")
R("function w80MapAdd(add,lod,S){w80Gen();if(!W80.gen)return;","function w80MapAdd(add,lod,S){w80Gen();if(!W80.gen)return;w90MapAdd(add,lod,S);")
R("function w80MapIcon(g,kind,o,t){if(kind==='sig85')","function w80MapIcon(g,kind,o,t){if(w90MapIcon(g,kind,o,t))return true;if(kind==='sig85')")
R("m===38?'#6b8cff':'#c96a2a'","m===38?'#6b8cff':m===42?'#ffd36b':m===46?'#7affc9':'#c96a2a'")
R("  return h+chron85(s)+'</dl>';}","  return h+chron85(s)+chron90(s)+'</dl>';}")
# музыка
R("function step80(P,t,st,bar){const S=P.sc,X=P.ext||{},root=S.root+(P.semi||0);step85(P,t,st,bar);","function step80(P,t,st,bar){const S=P.sc,X=P.ext||{},root=S.root+(P.semi||0);step85(P,t,st,bar);step90(P,t,st,bar);")
R("  return mus85(T);}\nfunction fade80","  return mus90(mus85(T));}\nfunction fade80")
R("for(const id of ['hpB','sigB','bcB','biB','jamB','bossB','enB','b85G'])","for(const id of ['hpB','sigB','bcB','biB','jamB','bossB','enB','b85G','x90G'])")
# метки комнат боссов в мире: имя босса вместо «доработки», если бой уже есть
R("worldLabel(n.x,n.y+140,'БОСС · ДОРАБОТКА','#ff6b8a');","worldLabel(n.x,n.y+140,bossLab90(n.m),'#ff6b8a');")
R("(n.boss&&lod===2?' · БОСС · ДОРАБОТКА':'')","(n.boss&&lod===2?' · '+bossLab90(n.m):'')")
# версия и хроника версий
R('<div class="eyebrow">АЛЬФА 0.8.5 · ЛЕКАЛО И КОЛОДЕЦ</div>','<div class="eyebrow">АЛЬФА 0.9 · СЕРДЦЕ КОВЧЕГА И СТЁРТЫЕ БЕРЕГА</div>')
R('<dl class="kv"><dt>0.8.5 α</dt>','<dl class="kv"><dt>0.9 α</dt><dd>«Сердце Ковчега и Стёртые берега». Сектора IX и X больше не в разработке. Сектор IX: ленты кровотока сносят корабль и удлиняют рывок по течению, шкала Тревоги зовёт облаву Фагоцитов, шлюзы делят арену и держат снаряды, в капсулах спят пассажиры — будите их, пока Смотрители не разбудили силой. Сектор X: стирание наползает с краёв, пропадают шкалы интерфейса, во второй половине приходят воспоминания прошлых секторов, Свидетели несут двенадцать обрывков памяти, по арене проходит Прилив, а тени прошлых боссов возвращаются слабее, чем были. Пятнадцать новых врагов — от Тромба и Смотрителя до Опечатки, Корректора, Эха-призрака и Безымянного. Босс «Сердце» (42): бой в ритме удара — точные попадания в такт, аритмия, двойные удары с проходами и ручной запуск четырьмя ключами. Босс «Берег» (46): горизонт пустоты опускается, держат его маяки памяти, а в конце остаётся только ваше эхо. У обоих по скрытому третьему исходу. Стоп-кадр на точных ударах, мягкая тряска (настраивается), таблички первой встречи, своя музыка секторов и боёв. Мастерство 39–46, пять скинов, четыре модуля, шесть контрактов.</dd><dt>0.8.5 α</dt>')
open(P,'w',encoding='utf8').write(s)
print('m17 ok')
