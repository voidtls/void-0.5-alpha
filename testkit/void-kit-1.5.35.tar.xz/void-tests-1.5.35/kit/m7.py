# 0.6.0 · часть 7: правки по геометрическим тестам
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m7: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
CSS=r"""
/* --- 0.6.0: правки по геометрическим тестам --- */
.mob .btn kbd,.mob #score small,.mob .jsec,.mob .jsec small,.mob .sc-h .free,.mob .sc-h .need,.mob .skincard p{font-size:calc(12px*var(--fs))}
.mob .jsec small{color:#7a8ea5}
.mob input[type=range]{height:44px}
.mob .alphaJump select,.mob .alphaJump .wbtn,.mob .alphaJump button{min-height:44px}
.mob .mapleg summary{min-height:44px;display:flex;align-items:center;font-size:calc(12px*var(--fs))}
.ff-phone-l #mini{width:84px;height:84px;top:calc(56px + var(--sat))}
.ff-phone-l #hud .hud-w{top:calc(60px + var(--sat));right:calc(max(12px,var(--sar)) + 94px)}
@media (max-height:360px){.ff-phone-l #mini{width:70px;height:70px}.ff-phone-l #hud .hud-w{right:calc(max(12px,var(--sar)) + 80px)}}
"""
R("</style>",CSS+"</style>",1)
# раскладка кнопок поджимается по высоте: дуга не залезает на миникарту и HUD
R("  for(const [id,key] of [['tDash','dash'],['tPulse','pulse'],['tCharge','charge'],['tAct','act']]){const el=$('#'+id);if(!el)continue;\n    if(!mob){el.style.cssText='';continue;}\n    const L=TBL[key],d=L.d*k,cx=left?SAFE.l+L.dx*k:CW-SAFE.r-L.dx*k,cy=CH-SAFE.b-L.dy*k;",
  "  const topLim=G.world&&G.state!=='menu'?SAFE.t+(G.ff==='phone-l'?(CH<=360?136:150):148):SAFE.t+64,need=Math.max(...Object.values(TBL).map(L=>(L.dy+L.d/2)*k)),f=Math.min(1,(CH-SAFE.b-topLim)/need);\n  for(const [id,key] of [['tDash','dash'],['tPulse','pulse'],['tCharge','charge'],['tAct','act']]){const el=$('#'+id);if(!el)continue;\n    if(!mob){el.style.cssText='';continue;}\n    const L=TBL[key],d=L.d*k*(f<.85?Math.max(.8,f/.85):1),cx=left?SAFE.l+L.dx*k:CW-SAFE.r-L.dx*k,cy=CH-SAFE.b-L.dy*k*f;")
open(P,'w').write(s)
print('m7 ok')
