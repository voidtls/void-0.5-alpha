# Этап 0 · A0-2: отпечаток цепочек обёрток и таблица писателей G (статический разбор собранного HTML)
# python3 archcheck.py build <html> <out.json>        — снять отпечаток
# python3 archcheck.py diff <base.json> <html> [allow.json] — сравнить; код возврата 1 при нарушении
import re,sys,json,hashlib,collections
def main_script(html):
    i=html.index('<script>\n"use strict";');j=html.index('</script>',i);return html[i+8:j]
def fingerprint(js):
    L=js.split('\n')
    decl=set(re.findall(r'(?<![\w.$])function\s+([A-Za-z_$][\w$]*)\s*\(',js))
    rew=re.compile(r'(?<![\w.$])([A-Za-z_$][\w$]*)\s*=\s*(function\b|iso65\(|\(\)\s*=>|async\s+function)')
    import os
    if os.environ.get('ARCHCHECK_V2'):rew=re.compile(r'(?<![\w.$])([A-Za-z_$][\w$]*)\s*=\s*(function\b|[A-Za-z_$][\w$]*\(\1\b|\(\)\s*=>|async\s+function)')  # v2 (этап 2): любая обёртка вида f=wrap(f)
    chains=collections.defaultdict(list)
    for l in L:
        for m in rew.finditer(l):
            n=m.group(1)
            if n in decl:
                body=re.sub(r'\s+','',l[m.end():m.end()+160])
                chains[n].append(hashlib.sha1(body.encode()).hexdigest()[:10])
    # писатели ключей G: зона = имя ближайшей объявленной функции выше (её суффикс версии/префикс подсистемы)
    cur='(top)';owners=collections.defaultdict(set)
    def zone(f):
        if f.startswith('bg67'):return 'BG67'
        if f.startswith('c66'):return 'C66'
        if f.startswith('arch69'):return 'ARCH69'
        m=re.search(r'(\d{2,3})$',f);return 'v'+m.group(1) if m else 'core'
    for l in L:
        m=re.search(r'^\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)',l)
        if m:cur=m.group(1)
        for w in re.finditer(r'(?<![\w.$])G\.([A-Za-z_$][\w$]*)\s*(?:=(?!=)|\+=|-=|\*=|\|\|=|\+\+|--)',l):
            owners[w.group(1)].add(zone(cur))
    return {'chains':{k:v for k,v in sorted(chains.items())},'owners':{k:sorted(v) for k,v in sorted(owners.items())},
            'n_chain_sites':sum(len(v) for v in chains.values()),'n_keys':len(owners)}
def diff(base,cur,allow):
    out=[]
    for n in sorted(set(base['chains'])|set(cur['chains'])):
        a,b=base['chains'].get(n,[]),cur['chains'].get(n,[])
        if a!=b and n not in allow.get('chains',[]):out.append(('chain',n,len(a),len(b),'порядок' if sorted(a)==sorted(b) else 'состав'))
    for k,zs in cur['owners'].items():
        old=set(base['owners'].get(k,[]));new=set(zs)-old
        for z in new:
            if [k,z] not in allow.get('owners',[]):out.append(('owner',k,z,'новый ключ' if not old else 'чужая зона'))
    return out
if __name__=='__main__':
    cmd=sys.argv[1]
    if cmd=='build':
        fp=fingerprint(main_script(open(sys.argv[2],encoding='utf8').read()));json.dump(fp,open(sys.argv[3],'w'),indent=0);print('цепочек',len(fp['chains']),'мест',fp['n_chain_sites'],'ключей G',fp['n_keys'])
    else:
        base=json.load(open(sys.argv[2]));cur=fingerprint(main_script(open(sys.argv[3],encoding='utf8').read()))
        allow=json.load(open(sys.argv[4])) if len(sys.argv)>4 else {}
        d=diff(base,cur,allow);print(json.dumps({'violations':d[:40],'n':len(d)},ensure_ascii=False));sys.exit(1 if d else 0)
