# 1.5.8 α «Тише» (PERF·OPT): поведение и вид не меняются. G01–G08.
# Сравниваются три сборки: эталон 1.5.7 (void_v45.html), 1.5.8 со всеми оптимизациями, 1.5.8 со всеми выключенными (__perfOff).
import asyncio,json,sys,os,hashlib
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
NEW=os.environ.get('GAME_URL','file://@@KIT@@/home/void_t.html')
BASE='file://'+SP+'void_v45.html'
ALLOFF="window.__perfOff=['O-2','O-3','O-4','O-6'];"
VARIANTS=[('base',BASE,None),('on',NEW,None),('off',NEW,ALLOFF)]
VAR4=VARIANTS+[('base2',BASE,None)]
PILOT=("const pilot=(s)=>{const p=G.player;if(!p)return;p.hp=Math.max(p.hp,G.st.maxHp*.6);if(G.bc)G.bc.hp=Math.max(G.bc.hp,G.bc.maxHp*.6);const a=s/150;"
       "const tg=G.boss||null;let tx=(tg?tg.x:W/2)+Math.cos(a)*(tg?220:W*.28),ty=(tg?tg.y:H/2)+Math.sin(a)*(tg?220:H*.28);steer2(tx,ty);if(s%140===0)tryDash();if(p.en>=100)tryPulse();};")
SIG=("const sig=()=>{const p=G.player;let ph=0;for(const q of G.parts)ph=(ph*31+Math.round(q.x*8)+Math.round(q.y*8)*7+Math.round(q.life*1000))%1000000007;"
     "return {st:G.state,t:G.mT!=null?+(+G.mT).toFixed(3):null,k:G.kills,tk:Math.round(G.taken||0),x:p?+p.x.toFixed(4):null,y:p?+p.y.toFixed(4):null,hp:p?+p.hp.toFixed(4):null,lvl:G.lvl,lom:G.save&&G.save.lom,"
     "e:G.enemies.filter(e=>e.alive).map(e=>e.type+':'+e.x.toFixed(3)+':'+e.y.toFixed(3)+':'+Math.round(e.hp)+':'+(e.buff||1)+':'+(e.shieldK||1)).join(','),"
     "boss:G.boss?[G.boss.st,G.boss.phase,Math.round(G.boss.hp)]:null,np:G.parts.length,ph,rnd:Math.random()};};")
# в игре реверберация музыки (makeImpulse в musInit) берёт 352 800 чисел из ИГРОВОГО Math.random в момент первой инициализации звука;
# когда это попадает внутрь прогона, повтор «расходится» даже у эталона с самим собой. В тесте импульс получает свой ГСЧ.
ISO="{if(!window.__iso360){window.__iso360=1;const mi=makeImpulse;makeImpulse=function(){const mr=Math.random;Math.random=mulberry(4096);try{return mi.apply(this,arguments);}finally{Math.random=mr;}};}}"
STEP=("const step=(s)=>{if(G.state==='levelup'){let k=0;while(G.state==='levelup'&&k++<60)choose(0);}if(G.state!=='play')return false;pilot(s);update(1/60);if(s%4===0)render(1000+s*16.667);return true;};")
def mission_js(m,sec,mass=False):
    spawn=("const p=G.player;for(let i=0;i<120;i++){const a=i/120*6.283;spawnEnemy(['scout','gunner','rammer','shielder','commander','scout','gunner','shielder'][i%8],p.x+Math.cos(a)*(200+i*3),p.y+Math.sin(a)*(200+i*3),{});}" if mass else "")
    return ("async()=>{"+ISO+PILOT+SIG+STEP+"Math.random=mulberry(777);G.layoutSeed=55;G.keepLayout=true;T.fresh();G.save.tut.off=1;"
            "{const S=G.save;S.cleared=Math.max(S.cleared,%d-1);for(let k=1;k<%d;k++)S.medals[k]={clear:1};}"%(m,m)+
            "enterNode(%d);if(G.state==='intro')startMission();"%m+spawn+
            "const mid=[];for(let s=0;s<60*%d;s++){if(!step(s))break;if(s===60*%d)mid.push(sig());}return {mid:mid[0]||null,end:sig()};}"%(sec,sec//2))
async def runv(b,code,url,init,w=1280,h=760):
    P=await newpage(b,w,h,url=url,init=init)
    r=await P.js(code);errs=P.errs[:3];await P.pg.context.close();return r,errs
async def triple(b,code,w=1280,h=760):
    out={}
    for name,url,init in VARIANTS:out[name]=await runv(b,code,url,init,w,h)
    return out
def same(o):
    a=json.dumps(o['base'][0],sort_keys=True);return a==json.dumps(o['on'][0],sort_keys=True)==json.dumps(o['off'][0],sort_keys=True)
def diffk(o):
    a,b_=o['base'][0],o['on'][0]
    def flat(x,p=''):
        if isinstance(x,dict):
            r={}
            for k,v in x.items():r.update(flat(v,p+'.'+k))
            return r
        return {p:x}
    fa,fb=flat(a),flat(b_);return [k for k in fa if fa.get(k)!=fb.get(k)][:6]

@test('G01')
async def g01(b):
    res={};ok=True
    for m in [1,2,6,10,14,18,22,27,31,38,42,46,50]:
        o=await triple(b,mission_js(m,30))
        s=same(o);ok&=s and not any(o[k][1] for k in o)
        res[m]=('=' if s else 'DIFF '+str(diffk(o)))+(' '+o['on'][0]['end']['st']+' k'+str(o['on'][0]['end']['k'])+' e'+str(len(o['on'][0]['end']['e'].split(',')) if o['on'][0]['end']['e'] else 0))
        print('   ',m,res[m],[o[k][1] for k in o if o[k][1]],flush=True)
    rec('G01 золотой повтор: 12 миссий (01, 02, боссы 06–46; 50 из стенда не запускается) по 30 с с одним сидом — эталон 1.5.7, 1.5.8 «вкл» и «выкл» дают одно состояние до бита: враги, позиции, ХП, частицы, следующее случайное число',ok,res)

@test('G02')
async def g02(b):
    o=await triple(b,mission_js(2,25,mass=True))
    e=o['on'][0]['end'];mid=o['on'][0]['mid']
    rec('G02 массовый бой: 120 врагов, из них 45 щитоносцев и 15 командиров, 25 с — три сборки совпадают до бита (разведение, щиты, усиления)',same(o) and not any(o[k][1] for k in o),{'same':same(o),'diff':diffk(o),'alive_mid':len(mid['e'].split(',')) if mid else 0,'alive_end':len(e['e'].split(',')) if e['e'] else 0,'np':e['np'],'errs':[o[k][1] for k in o]})

@test('G03')
async def g03(b):
    code=("async()=>{"+ISO+"Math.random=mulberry(91);T.fresh();G.save.tut.off=1;const p=G.player;const tr=[];"
          "for(let s=0;s<60*40;s++){const a=s/300;KEYS.KeyW=false;p.vx=Math.cos(a)*380;p.vy=Math.sin(a*1.3)*260;update(1/60);if(s%4===0)render(1000+s*16.667);if(s%600===0)tr.push([+p.x.toFixed(3),+p.y.toFixed(3),G.enemies.length]);}"
          "return {st:G.state,x:+p.x.toFixed(4),y:+p.y.toFixed(4),tr,fog:G.fogVer,e:G.enemies.filter(e=>e.alive).map(e=>e.type+':'+e.x.toFixed(2)).join(','),hud:document.querySelector('#hudLom,#lom,.lom')?document.querySelector('#hudLom,#lom,.lom').textContent:'',rnd:Math.random()};}")
    o=await triple(b,code)
    rec('G03 открытый мир: 40 с полёта с одним сидом — три сборки совпадают (позиция, туман, враги мира, текст HUD)',same(o) and not any(o[k][1] for k in o),{'same':same(o),'diff':diffk(o),'on':{k:o['on'][0][k] for k in ['st','x','y','fog']}})

# кадр: время подменено, отрисовка детерминирована — сравниваем пиксели
PIX0=("const hsh=(cv)=>{const g=cv.getContext('2d'),d=g.getImageData(0,0,cv.width,cv.height).data;let h1=0,h2=0;for(let i=0;i<d.length;i+=4){h1=(h1*31+d[i]+d[i+1]*3+d[i+2]*7)>>>0;h2=(h2+d[i]+d[i+1]+d[i+2])>>>0;}return h1+':'+h2;};")
PIX=("const hsh=(cv)=>{const g=cv.getContext('2d'),d=g.getImageData(0,0,cv.width,cv.height).data,o=[];for(let y=0;y<cv.height;y+=4)for(let x=0;x<cv.width;x+=4){const i=(y*cv.width+x)*4;o.push(d[i]+d[i+1]+d[i+2]);}return o;};")
def pdiff(a,b):
    n=min(len(a),len(b));dd=[abs(a[i]-b[i]) for i in range(n)]
    return {'mad':round(sum(dd)/max(1,n)/3,2),'frac':round(sum(1 for x in dd if x>24)/max(1,n),4)}
CLOCK="window.__tt=1000;performance.now=()=>window.__tt;window.requestAnimationFrame=function(){return 0;};Date.now=()=>1.7e12+window.__tt;"
@test('G04')
async def g04(b):
    # аудит разницы: 1.5.8 минус блок PERF·OPT и точечные места (в старый вид) = 1.5.7 байт в байт, кроме версии и журнала.
    # Пиксельное сравнение кадров между страницами непригодно: фон строится в простое (requestIdleCallback) и зависит от времени —
    # эталон сам с собой расходится на 20–80 % пикселей. Поэтому вид доказывается так: состояние совпадает (G01–G03, G08),
    # тексты совпадают (G06), а код отрисовки не тронут (этот тест).
    import re
    new=open(NEW.replace('file://',''),encoding='utf8').read();base=open(BASE.replace('file://',''),encoding='utf8').read()
    import arch74 as _A74
    for _n in (75,74,73,72):
        if 'ARCH·%d'%_n in new:new=_A74.strip(new,_n)   # этап 4: сначала снимаются ARCH·72…75
    if 'ARCH·71' in new:
        from strip71 import strip71;new=strip71(new)   # 1.5.11: сначала снимается этап 3 (его аудит — orc71/strip71)
    if 'ARCH·70' in new:
        from strip70 import strip70;new=strip70(new)   # 1.5.10: сначала снимается этап 2
    # 1.5.9: сначала снимаем ARCH·69 (как в q370 A16), затем PERF·OPT
    j9=open(SP+'m69.js',encoding='utf8').read();J9=open(SP+'m69_journal159.txt',encoding='utf8').read().strip()
    new=new.replace('<script>\n"use strict";\n'+j9+'\n','<script>\n"use strict";\n',1).replace('<dt>1.5.9 α</dt><dd>'+J9+'</dd>','',1)
    new=new.replace('id="verTag">1.5.9 α<','id="verTag">1.5.8 α<',1).replace("const VER_TAG='1.5.9 α';","const VER_TAG='1.5.8 α';",1)
    new=new.replace("else{ARCH.mapGen++;mapLoop();}/* ARCH·69 A-1 */}","else mapLoop();}",1).replace("drawMap();arch69MapNext();/* ARCH·69 A-1 */}","drawMap();requestAnimationFrame(mapLoop);}",1)
    new=new.replace("arsDemoTick(now);arch69Ok();}catch(err){console.error(err);arch69Fault(err);/* ARCH·69 A-4 */}","arsDemoTick(now);}catch(err){console.error(err);}",1).replace("/* ARCH·69 A-2 · A-3 */arch69Boot();\n","",1)
    js=open(SP+'m68.js',encoding='utf8').read();J=open(SP+'m68_journal158.txt',encoding='utf8').read().strip()
    t=new.replace('<script>\n"use strict";\n'+js+'\n','<script>\n"use strict";\n',1)
    t=t.replace('<dt>1.5.8 α</dt><dd>'+J+'</dd>','',1).replace('id="verTag">1.5.8 α<','id="verTag">1.5.7 α<',1).replace("const VER_TAG='1.5.8 α';","const VER_TAG='1.5.7 α';",1)
    t=t.replace("const fmt=n=>ru68(Math.round(n));/* PERF·OPT O-6 */","const fmt=n=>Math.round(n).toLocaleString('ru-RU');",1)
    t=t.replace("const fmtN=n=>typeof n==='number'?ru68(Math.round(n)):n;/* PERF·OPT O-6 */","const fmtN=n=>typeof n==='number'?Math.round(n).toLocaleString('ru-RU'):n;",1)
    t=re.sub(r"const c=PERF\.off\['O-3'\]\?(G\.enemies\.filter\(.*?\.slice\(0,3\)):o3Near\(s\);/\* PERF·OPT O-3 \*/",lambda m:'const c='+m.group(1)+';',t,count=1)
    t=t.replace("{const f3=!PERF.off['O-3'],cx=c.x,cy=c.y;for(const o of G.enemies){if(f3){const dx=o.x-cx,dy=o.y-cy;if(dx>=220||dx<=-220||dy>=220||dy<=-220)continue;}if(o!==c&&o.alive&&!HEAVY.has(o.type)&&Math.hypot(o.x-c.x,o.y-c.y)<220)o.buff=1.25;}}/* PERF·OPT O-3 */",
                "for(const o of G.enemies)if(o!==c&&o.alive&&!HEAVY.has(o.type)&&Math.hypot(o.x-c.x,o.y-c.y)<220)o.buff=1.25;",1)
    t=re.sub(r"  if\(!PERF\.off\['O-3'\]\)o3Sep\(es,sep\);else\{/\* PERF·OPT O-3: старый путь \*/\n(.*?)  \}\n",lambda m:m.group(1),t,count=1,flags=re.S)
    left=[k for k in ['PERF.off','ru68(','o3Near(','o3Sep(','NF68'] if t.count(k)!=base.count(k)]
    eq=(t==base)
    first=None
    if not eq:
        n=min(len(t),len(base));first=next((i for i in range(n) if t[i]!=base[i]),n);first=[t[first-80:first+80],base[first-80:first+80]]
    rec('G04 аудит разницы: если убрать из 1.5.8 блок PERF·OPT, точечные места O-3/O-6, версию и запись журнала, получается 1.5.7 байт в байт — код отрисовки, звука, сохранений и боссов не тронут',eq and not left,{'equal':eq,'left':left,'len':[len(new),len(base)],'first_diff':first})

@test('G05')
async def g05(b):
    code=("async()=>{"+PIX+"const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=9;for(let k=1;k<=9;k++)S.medals[k]={clear:1};G.save.story.absorbed=EROSION_FULL*.4;MAPC.rift=null;"
          "const t=performance.now();const rc=mapRift();const ms=performance.now()-t;const r=hsh(rc);"
          "openMap('map');__tt+=16;drawMap();__tt+=16;drawMap();const m=hsh($('#mapC'));closeMap&&closeMap();return {rift:r,map:m,ms:+ms.toFixed(1)};}")
    o={}
    for name,url,init in VARIANTS:o[name]=await runv(b,code,url,(init or '')+CLOCK)
    a=[o[k][0] for k in o]
    ok=a[0]['rift']==a[1]['rift']==a[2]['rift'] and a[0]['map']==a[1]['map']==a[2]['map'] and not any(o[k][1] for k in o)
    rec('G05 карта: «Разлом» и кадр карты (9 секторов пройдено, эрозия 40 %) совпадают попиксельно; время сборки «Разлома» — эталон / вкл / выкл',ok,{k:o[k][0] for k in o}|{'errs':[o[k][1] for k in o if o[k][1]]})

@test('G06')
async def g06(b):
    code=("()=>{const vals=[0,-0,1,-1,999,1000,-1000,1e6,1e15,NaN,Infinity,-Infinity,.5,-.5,2.5,-2.5,123456789.49];for(let i=0;i<20000;i++)vals.push((i%2?-1:1)*Math.pow(10,i%13)*((i*7919)%1000)/997);"
          "let bad=0;for(const v of vals){const a=Math.round(v).toLocaleString('ru-RU');if(fmt(v)!==a||fmtN(v)!==a)bad++;}"
          "PERF.off['O-6']=1;let bad2=0;for(const v of vals.slice(0,500)){if(fmt(v)!==Math.round(v).toLocaleString('ru-RU'))bad2++;}delete PERF.off['O-6'];"
          "return {n:vals.length,bad,bad2,fmtNstr:fmtN('abc'),lomH:lomH(12345)};}")
    P=await newpage(b,1280,760,url=NEW);r=await P.js(code)
    rec('G06 числа: fmt и fmtN дают тот же текст, что toLocaleString(\'ru-RU\'), на 20 017 значениях (0, −0, NaN, ∞, половинки, 10¹⁵); с выключенным флагом — старый путь',r['bad']==0 and r['bad2']==0 and r['fmtNstr']=='abc' and '12' in r['lomH'],r)

@test('G07')
async def g07(b):
    # вырезаемость/откат: флаги переключаются на лету в одном бою — состояние совпадает с прогоном без флагов
    code=("async()=>{"+ISO+PILOT+SIG+STEP+"const run=(flip)=>{Math.random=mulberry(31);G.layoutSeed=3;G.keepLayout=true;T.fresh();G.save.tut.off=1;enterNode(2);if(G.state==='intro')startMission();"
          "const p=G.player;for(let i=0;i<60;i++){const a=i/60*6.283;spawnEnemy(['scout','shielder','commander'][i%3],p.x+Math.cos(a)*(200+i*3),p.y+Math.sin(a)*(200+i*3),{});}"
          "for(let s=0;s<60*15;s++){if(flip&&s%97===0){for(const k of ['O-2','O-3','O-4','O-6'])if((s/97|0)%2)PERF.off[k]=1;else delete PERF.off[k];}if(!step(s))break;}for(const k in PERF.off)delete PERF.off[k];return sig();};"
          "const a=run(false);toMenu();const a2=run(false);toMenu();const c=run(true);toMenu();const c2=run(true);return {same:JSON.stringify(a2)===JSON.stringify(c),ctl:JSON.stringify(a)===JSON.stringify(a2),ctl2:JSON.stringify(c)===JSON.stringify(c2),a:a.e.length,np:a.np};}")
    P=await newpage(b,1280,760,url=NEW);r=await P.js(code);e=P.errs[:3]
    rec('G07 откат на лету: флаги O-2…O-6 переключаются каждые 97 кадров посреди массового боя — итог тот же, что без переключений (первый прогон на странице — прогрев, сравниваются 2-й…4-й)',r['same'] and r['ctl2'] and not e,r|{'errs':e})

@test('G08')
async def g08(b):
    # телефон: тот же повтор в узком окне и с касанием
    code=mission_js(10,20)
    o={}
    for name,url,init in VARIANTS:
        P=await newpage(b,390,844,url=url,init=init,touch=True);o[name]=(await P.js(code),P.errs[:3]);await P.pg.context.close()
    rec('G08 телефон 390×844: миссия 10, 20 с с одним сидом — три сборки совпадают',same(o) and not any(o[k][1] for k in o),{'same':same(o),'diff':diffk(o)})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or t[0] in sel],'res360.json'))
