
// ===== 0.8.0: сектора VII «Предел» и VIII «Исток» — поведение, мир, звук =====
const S80T=new Set(['labrat','defect','inspector','railshield','stamp','recycler','echo80','loop','inverse','pilgrim','rangedummy','convoybox']);
S80T.forEach(k=>H74.add(k));S80T.forEach(k=>STORY_NORETREAT.add(k));['pilgrim','rangedummy','convoybox'].forEach(k=>AIM_SKIP75.add(k));
const DEF_MODES80=['shoot','ram','mine','guard'],DEF_COL80={shoot:'#ffd36b',ram:'#ff4f6e',mine:'#ff9a3d',guard:'#9fb0c4'},DEF_TXT80={shoot:'СТРЕЛОК',ram:'ТАРАН',mine:'МИНЁР',guard:'СТОРОЖ'};
const VOICES80=['«…вы тоже слышали? Не ответ. Вопрос…»','«…мы не первые. Мы не последние. Мы — те, кто дошёл…»','«…Стражи спрашивали то же самое. Им ответили. Им не понравилось…»','«…номер не важен. Важно, что сигнал повторяется…»',
  '«…я помнил небо. Потом помнил только курс…»','«…Исток не зовёт. Он просто не перестаёт звучать…»','«…если ты слышишь это — ты уже копия. Не бойся. Мы тоже…»','«…бюро считало нас изделиями. Изделия не уходят сами…»',
  '«…сто двадцать седьмой цикл. Или первый. Здесь это одно и то же…»','«…Карр тоже летит сюда. Он ещё не знает зачем…»','«…они назвали это «Пределом». Предел — это где кончается бюро. Не мы…»','«…последний голос. Дальше — только сигнал…»'];
function sec80(){const s=sec74();return s===6||s===7?s:-1;}
function d80H(k,txt,col){const H=G.h80||(G.h80={});if(H[k])return;H[k]=1;const p=G.player;if(p)floater(p.x,p.y-44,txt,col||'#e8d27a');}
function w80S(){const S=G.save;if(!S)return {clk:0,alarmAt:[0,0,0],rangeBest:0,seen:{},voices:0};const w=S.w80||(S.w80={clk:0,alarmAt:[0,0,0],rangeBest:0,seen:{},voices:0});w.alarmAt=w.alarmAt||[0,0,0];w.seen=w.seen||{};return w;}
function rankD80(){return curDiff().rank||0;}
// --- инициализация миссии ---
function t80Init(M){const sec=M&&M.gen?M.sec:-1;G.x80={sec,leaks:[],bo:null,pil:null,born:G.t};G.bo80=0;G.insp80=0;G.insp80By=null;G.inv80=0;G.slow80=0;G.stamp80=null;G.rcDrop80=0;G.rcLost80=0;G.echoQ80=[];G.echoSeq80=0;G.echoHitT80=-99;G.dmgN80=[];G.rcB80=[];G.echoBl80=[];G.res80=null;document.body.classList.remove('stamp80');
  if(G.mode==='endless'||!inMission()||(sec!==6&&sec!==7))return;const m=G.m,X=G.x80;
  if(!M.bossRoom&&m!==28&&m!==32&&m!==34&&m!==36)X.bo={st:'wait',t:0};
  if(m===29||m===30){const n=m===29?1:2;for(let i=0;i<n;i++)X.leaks.push({x:n===1?W*.5:(i?W*.72:W*.3),y:n===1?H*.52:(i?H*.62:H*.4),r:Math.min(W,H)*(n===1?.22:.18)});}
  if(m===36||m===37)X.pil={at:m===36?20:30,done:false,hostile:false,tol:(G.save&&G.save.story&&G.save.story.spared||0)>=5?1:0};}
// --- ИИ (из s74Update0; true = обработан) ---
const CAP80={labrat:2,railshield:2,recycler:1,inspector:2,echo80:2,loop:4,stamp:3,inverse:1};
function cap80(e){if(e.cap80||G.world||e.zone)return;e.cap80=1;const lim=CAP80[e.type];if(lim===undefined)return;const M=MISSIONS[G.m-1],L=e.type==='recycler'&&M&&M.bossRoom?2:lim;
  const n=G.enemies.filter(o=>o!==e&&o.alive&&o.type===e.type).length;if(n<L)return;const sec=M&&M.sec;let nt=sec===7?(e.type==='loop'?'phantom':'loop'):'defect';if(nt===e.type)nt='gunner';if(nt==='defect'&&G.enemies.filter(o=>o.alive&&o.type==='defect').length>=3)nt='gunner';
  if(CAP80[nt]!==undefined&&G.enemies.filter(o=>o!==e&&o.alive&&o.type===nt).length>=CAP80[nt])nt='gunner';const k=e.maxHp/EDEF[e.type].hp;e.type=nt;e.maxHp=e.hp=EDEF[nt].hp*k;e.r=EDEF[nt].r;e.contact=EDEF[nt].contact;e.cap80=1;}
function s80Update(e,dt,c){cap80(e);if(!S80T.has(e.type))return false;const p=G.player,{ux,uy,d,sm,T,pd}=c,pdx=p.x-e.x,pdy=p.y-e.y,dark=G.bo80>=.5;
  switch(e.type){
    case 'labrat':{let cx=0,cy=0,n=0;for(const o of G.enemies){if(o===e||!o.alive||o.type==='labrat'||EDEF[o.type].passive||STATIC.has(o.type)||Math.hypot(o.x-e.x,o.y-e.y)>600)continue;cx+=o.x;cy+=o.y;n++;}
      let tx,ty;if(n){cx/=n;cy/=n;const dx=cx-p.x,dy=cy-p.y,l=Math.hypot(dx,dy)||1;tx=cx+dx/l*120;ty=cy+dy/l*120;}else{const a=G.t*.5+e.seed;tx=p.x+Math.cos(a)*300;ty=p.y+Math.sin(a)*300;}
      const q=Math.hypot(tx-p.x,ty-p.y);if(q<260){tx=p.x+(tx-p.x)/(q||1)*280;ty=p.y+(ty-p.y)/(q||1)*280;}
      steer(e,tx-e.x,ty-e.y,e.spd*sm,dt,2.5);if(e.bcut>0)e.bcut-=dt;
      e.ht=(e.ht===undefined?.3:e.ht)-dt;if(e.hot>0)e.hot-=dt;if(e.ht<=0&&!(e.hot>0)){e.ht=.5;let best=e.beam&&e.beam.alive&&e.beam.healBy===e?e.beam:null,bk=best?best.hp/best.maxHp:1;if(!best)for(const o of G.enemies){if(o===e||!o.alive||o.spawnT>0||o.type==='labrat'||EDEF[o.type].passive||EDEF[o.type].sbp||STATIC.has(o.type)||o.type==='boss'||o.type==='loop'&&o.tr80>0||(o.healBy&&o.healBy!==e&&o.healBy.alive&&o.healBy.beam===o))continue;const k=o.hp/o.maxHp;if(k<bk&&Math.hypot(o.x-e.x,o.y-e.y)<300){bk=k;best=o;}}if(best!==e.beam)e.bt80=0;e.beam=best;if(best)best.healBy=e;}
      const b=e.beam;if(b&&(!b.alive||b.hp>=b.maxHp||Math.hypot(b.x-e.x,b.y-e.y)>340||e.bcut>0))e.beam=null;
      if(e.beam&&p.hp>0&&p.dashT>0&&segInter(p.px,p.py,p.x,p.y,e.x,e.y,e.beam.x,e.beam.y)){floater((e.x+e.beam.x)/2,(e.y+e.beam.y)/2-14,'ЛУЧ ПОРВАН','#7affc9');e.beam=null;e.bcut=1;if(G.mc)G.mc.beam80=1;}
      if(e.beam){const o=e.beam;e.bt80=(e.bt80||0)+dt;if(e.bt80>4){e.beam=null;e.hot=2;e.bt80=0;}else o.hp=Math.min(o.maxHp,o.hp+o.maxHp*(HEAVY.has(o.type)?.04:.06)*(rankD80()>=2?.6:1)*dt);}if(e.beam){d80H('labrat','ЛАБОРАНТ ЧИНИТ РАНЕНЫХ · СНАЧАЛА ЕГО','#7affc9');}return true;}
    case 'defect':{if(!e.mode){e.mode=DEF_MODES80[Math.floor(Math.random()*4)];e.mT=3;}e.mT-=dt;
      if(e.mT<=0){let nm;do{nm=DEF_MODES80[Math.floor(Math.random()*4)];}while(nm===e.mode);e.mode=nm;e.mT=3;e.rst=null;e.mined=0;e.bn=0;}
      const m_=e.mode;
      if(m_==='shoot'){const k=clamp((pd-300)/120,-1,1);steer(e,pdx/pd*k-pdy/pd*.6*e.dir,pdy/pd*k+pdx/pd*.6*e.dir,e.spd*sm,dt,3);
        if(e.bn>0){e.bt-=dt;if(e.bt<=0){e.bn--;e.bt=.15;shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x)+rnd(-.06,.06),280,8,'#ffd36b',4,!!T.isBc);}}
        else{e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0&&(!dark||pd<520)){e.cd=1.6;e.bn=3;e.bt=0;}}}
      else if(m_==='ram'){if(!e.rst){e.rst='aim';e.rt=G.noTele?.5:.8;e.aim=Math.atan2(pdy,pdx);}
        if(e.rst==='aim'){e.vx*=.85;e.vy*=.85;e.aim+=clamp(angDiff(Math.atan2(pdy,pdx),e.aim),-1.5*dt,1.5*dt);e.rt-=dt;if(e.rt<=0){e.rst='go';e.rt=.6;}}
        else if(e.rst==='go'){e.vx=Math.cos(e.aim)*420;e.vy=Math.sin(e.aim)*420;e.rt-=dt;if(e.rt<=0)e.rst='rest';}
        else{e.vx*=.9;e.vy*=.9;}}
      else if(m_==='mine'){steer(e,-pdx/pd*.3-pdy/pd*e.dir,-pdy/pd*.3+pdx/pd*e.dir,e.spd*sm*.8,dt,2);
        if(!e.mined&&e.mT<2.4){e.mined=1;if(G.enemies.filter(o=>o.alive&&o.type==='mine'&&o.def80).length<4){const mn=spawnEnemy('mine',e.x,e.y,{arm:.95,fuse:0,life:12,noAffix:true,noLoot:true,def80:true});}}}
      else{e.vx*=.9;e.vy*=.9;}
      return true;}
    case 'inspector':{const k=clamp((pd-380)/120,-1,1);steer(e,pdx/pd*k-pdy/pd*.5*e.dir,pdy/pd*k+pdx/pd*.5*e.dir,e.spd*sm,dt,2);
      if(e.ca===undefined)e.ca=Math.atan2(pdy,pdx)+rnd(-1,1);if(!e.cdir)e.cdir=Math.random()<.5?-1:1;if(e.ct===undefined)e.ct=rnd(4,7);
      e.ct-=dt;if(e.ct<=0){e.ct=rnd(4,7);e.cdir*=-1;}e.ca+=.6*e.cdir*dt;if(e.cool80>0)e.cool80-=dt;
      const len=dark?260:420;e.clen=len;let see=false;
      if(p.hp>0&&pd<len&&Math.abs(angDiff(Math.atan2(pdy,pdx),e.ca))<.436&&e.spawnT<=0){see=true;const X=x74();if(X.hulls.length&&typeof hullBlocks75==='function'&&hullBlocks75(e.x,e.y,p.x,p.y))see=false;}
      const need=rankD80()===0?1.2:sbHard()?.5:.8;
      if(see)e.seeT=(e.seeT||0)+dt;else e.seeT=Math.max(0,(e.seeT||0)-dt*2);
      if(e.seeT>=need&&!(e.cool80>0)){e.seeT=0;e.cool80=5;insAlarm80(e);}
      e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0&&(!dark||pd<520)){e.cd=2.8;shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x),240,8,'#ffd36b',4,!!T.isBc);}return true;}
    case 'railshield':{let cx=0,cy=0,n=0;for(const o of G.enemies){if(o===e||!o.alive||o.type==='railshield'||EDEF[o.type].passive||STATIC.has(o.type)||Math.hypot(o.x-p.x,o.y-p.y)>900)continue;cx+=o.x;cy+=o.y;n++;}
      if(!n){cx=e.x;cy=e.y;}else{cx/=n;cy/=n;}let dx=cx-p.x,dy=cy-p.y,l=Math.hypot(dx,dy);if(l<1){dx=e.x-p.x;dy=e.y-p.y;l=Math.hypot(dx,dy)||1;}
      const dist=clamp(l*.45,200,400),tx=p.x+dx/l*dist,ty=p.y+dy/l*dist;e.rail={x:tx,y:ty,ux:-dy/l,uy:dx/l};
      const q=Math.hypot(tx-e.x,ty-e.y);if(q>6)steer(e,tx-e.x,ty-e.y,Math.min(e.spd*sm,q*3),dt,3);else{e.vx*=.8;e.vy*=.8;}
      const fa=Math.atan2(p.y-e.y,p.x-e.x);e.fa=e.fa===undefined?fa:e.fa+clamp(angDiff(fa,e.fa),-2*dt,2*dt);return true;}
    case 'stamp':{if(e.sc>0)e.sc-=dt;const away=e.sc>0;
      if(away){const k=clamp((pd-220)/100,-1,1);steer(e,pdx/pd*k-pdy/pd*.7*e.dir,pdy/pd*k+pdx/pd*.7*e.dir,e.spd*sm,dt,3);}
      else{const w=Math.sin(e.t*5+e.seed)*.8;steer(e,pdx/pd-pdy/pd*w,pdy/pd+pdx/pd*w,e.spd*sm,dt,3);
        if(pd<e.r+p.r+4&&p.hp>0&&p.dashT<=0&&e.spawnT<=0){if(!G.stamp80&&p.inv<=0){G.stamp80={t:rankD80()===0?5:4,max:rankD80()===0?5:4};floater(p.x,p.y-34,'ПРОВЕРЕНО · СБРОСЬТЕ РЫВКОМ','#ff7a3d');buzz('hit');sfx('block');document.body.classList.add('stamp80');d80H('stamp','ШТАМП: РЫВОК ИЛИ ИМПУЛЬС СБРАСЫВАЮТ','#ff7a3d');}
          e.sc=G.stamp80?8:2;e.vx=-pdx/pd*320;e.vy=-pdy/pd*320;}}return true;}
    case 'recycler':{const k=clamp((pd-300)/90,-1,1);steer(e,pdx/pd*k-pdy/pd*.4*e.dir,pdy/pd*k+pdx/pd*.4*e.dir,e.spd*sm,dt,1.5);
      e.hopper=e.hopper||[];e.pt=(e.pt||0)-dt;
      if(e.pt<=0){e.pt=.25;const lim=G.rcLost80>=.3*Math.max(10,G.rcDrop80);if(!lim&&e.hopper.length<12){const mag=G.st?G.st.mag:0;let n=0;
          for(const k_ of G.pick){if(n>=6)break;if(k_.rc80||k_.anom||k_.story||k_.quest||k_.life<=0||(k_.k!=='xp'&&k_.k!=='lom'&&k_.k!=='cell'&&k_.k!=='part80'))continue;
            if(Math.hypot(k_.x-e.x,k_.y-e.y)>320)continue;if(p.hp>0&&Math.hypot(k_.x-p.x,k_.y-p.y)<mag+10)continue;k_.rc80=e;k_.noMag=true;n++;}}}
      if(e.fire80){e.fire80-=dt;if(e.fire80<=0){e.fire80=0;const n=Math.min(4,e.hopper.length);const a0=Math.atan2(T.y-e.y,T.x-e.x);
          for(let i=0;i<n;i++){const it=e.hopper.shift();const dmg=it.k==='lom'?Math.min(14,8+Math.floor((it.v||1)/10)):it.k==='part80'?12:6;const col=it.k==='lom'?'#ffb84d':it.k==='xp'?'#d9c8ff':it.k==='cell'?'#ffb84d':'#c9d2de';
            const b=shootE(e.x,e.y,a0+(i-(n-1)/2)*.14,260,dmg,col,it.k==='part80'?7:5,!!T.isBc);if(b){b.rc80=it;G.rcB80.push(b);}}sfx('shot');e.fT=2.4;if(G.mc&&n)G.mc.rcFired80=1;}}
      else{e.fT=(e.fT===undefined?2:e.fT)-dt;if(e.fT<=0&&e.hopper.length&&p.hp>0&&onScreen(e)&&(!dark||pd<520)){e.fire80=G.noTele?.5:.8;sfx('warn');}}return true;}
    case 'echo80':{const k=clamp((pd-420)/80,-1,1);let tx=null;const L=G.posLog;if(L&&L.length){for(let i=L.length-1;i>=0;i--){if(G.t-L[i].t>=3){tx=L[i];break;}}}
      if(tx&&pd>380){steer(e,(tx.x-e.x)*.6+pdx/pd*k*120,(tx.y-e.y)*.6+pdy/pd*k*120,e.spd*sm,dt,1.6);}else steer(e,pdx/pd*k-pdy/pd*.5*e.dir,pdy/pd*k+pdx/pd*.5*e.dir,e.spd*sm,dt,2);
      if(Math.random()<dt*.2)e.dir*=-1;e.born80=e.born80||G.t;return true;}
    case 'loop':{if(e.tr80>0){e.tr80-=dt;e.vx=e.vy=0;e.ghost=true;if(e.tr80<=0){e.tr80=0;e.ghost=false;e.hp=e.maxHp*(rankD80()>=2?.4:.5);e.lr80=(e.lr80||0)+1;e.win80=2.6;e.spawnT=.6;e.contact=e.contact0||10;if(e.lr80>=2&&G.mc)G.mc.loopBad80=1;sfx('warn');}return true;}
      if(e.win80>0)e.win80-=dt;
      if(pd>320){steer(e,pdx,pdy,e.spd*sm,dt,3);}else{steer(e,-pdy/pd*e.dir+pdx/pd*.2,pdx/pd*e.dir+pdy/pd*.2,e.spd*sm,dt,3);if(Math.random()<dt*.3)e.dir*=-1;}
      if(e.bn>0){e.bt-=dt;if(e.bt<=0){e.bn--;e.bt=.12;shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x),300,8,'#6b8cff',4,!!T.isBc);}}
      else{e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0&&pd<520){e.cd=1.6;e.bn=2;e.bt=0;}}return true;}
    case 'inverse':{const k=clamp((pd-300)/80,-1,1);steer(e,pdx/pd*k-pdy/pd*.6*e.dir,pdy/pd*k+pdx/pd*.6*e.dir,e.spd*sm,dt,2.5);if(Math.random()<dt*.25)e.dir*=-1;
      if(e.it===undefined)e.it=4;
      if(e.iw){const w=e.iw;w.r+=500*dt;if(!w.hit&&p.hp>0&&Math.abs(Math.hypot(p.x-w.x,p.y-w.y)-w.r)<22){w.hit=true;if(p.dashT<=0){invHit80();}}if(w.r>=380)e.iw=null;}
      else if(e.itel>0){e.itel-=dt;e.vx*=.9;e.vy*=.9;if(e.itel<=0){e.itel=0;e.iw={x:e.x,y:e.y,r:e.r,hit:false};e.pulsed80=1;sfx('pulse');G.shock.push({x:e.x,y:e.y,r:e.r,R:380,t:0,col:'#e86bff',thin:true});}}
      else{e.it-=dt;if(e.it<=0&&onScreen(e)&&p.hp>0){e.it=7*(G.atkK||1);e.itel=sbHard()?.6:1.0;sfx('warn');}}return true;}
    case 'pilgrim':return pilgrimAI80(e,dt),true;
    case 'rangedummy':case 'convoybox':e.vx=e.vy=0;return true;}
  return false;}
function s80Pre(e,dt){if(e.alarm80&&alarmAI80(e,dt))return true;if(e.convoy80&&convoyAI80(e,dt))return true;if(e.audit80&&auditAI80(e,dt))return true;return false;}
function insAlarm80(e){G.insp80=5;G.insp80By=e;const p=G.player;for(const o of G.enemies)if(o.alive&&o!==e&&Math.hypot(o.x-e.x,o.y-e.y)<500)o.insB80=5;
  floater(p.x,p.y-38,'НАРУШЕНИЕ РЕГЛАМЕНТА · ВРАГИ +20% УРОНА','#ffd36b');buzz('ready');sfx('warn');if(G.mc)G.mc.seen80=1;
  if(e.audit80&&e.zone&&!e.zone.alarm){const z=e.zone;z.alarm=1;if(!z.stealth){radioLine('БЮРО','#e8d27a','Изделие вне партии. Квадрат '+(1+Math.floor(Math.abs(z.x+z.y)/700)%9)+'.',.1);const s=w74Sp(z,'stamp',e.x+rnd(-40,40),e.y+rnd(-40,40));}}}
function invHit80(){const p=G.player;if(G.inv80>0||G.slow80>0)return;if(SET.softInv){G.slow80=2;floater(p.x,p.y-34,'ИЗНАНКА · ЗАМЕДЛЕНИЕ','#e86bff');}else{G.inv80=2;if(!(G.h80&&G.h80.inv))floater(p.x,p.y-34,'ИЗНАНКА · УПРАВЛЕНИЕ НАОБОРОТ','#e86bff');G.h80=G.h80||{};G.h80.inv=1;}buzz('hit2');sfx('block');if(G.mc)G.mc.inv80=1;}
function inputK80(){return G.inv80>0&&!SET.softInv?-1:1;}
// --- урон ---
function s80Hurt(e,dmg,src){src=src||{};
  switch(e.type){
    case 'rangedummy':{rangeHit80(e,dmg,src);return 0;}
    case 'defect':return e.mode==='guard'?dmg*.6:dmg;
    case 'labrat':e.bcut=1;e.beam=null;return dmg;
    case 'pilgrim':pilgrimHit80(e);return dmg;
    case 'convoybox':if(e.zone)e.zone.prov80=1;return dmg;}
  return dmg;}
function s80Killed(e,silent){const p=G.player;if(!e)return;const hop=e.hopper?e.hopper.length:0;
  if(e.type==='inspector'&&G.insp80By===e){G.insp80=0;G.insp80By=null;}
  if(e.type==='recycler')rcRelease80(e,silent);
  if(silent)return;
  if(G.bo80>=.5&&(inMission()||(G.world&&sec80()>=0))&&!EDEF[e.type].passive){conEvent('darkKill');if(G.mc)G.mc.dark80=(G.mc.dark80||0)+1;}
  if(G.world&&W80.alarm&&W80.alarm.st==='on'){const q=W80.pults[W80.alarm.i];if(q&&Math.hypot(e.x-q.x,e.y-q.y)<600&&!EDEF[e.type].passive){G.save.carry+=5;floater(e.x,e.y-20,'+5 · ТРЕВОГА','#ff7a3d');conEvent('alarmKill');}}
  switch(e.type){
    case 'defect':if(Math.random()<.25){if(G.world)G.pick.push({k:'lom',x:e.x,y:e.y,vx:rnd(-60,60),vy:rnd(-60,60),r:5,t:0,life:30,v:2});else for(let i=0;i<EDEF.defect.xp;i++)G.pick.push({k:'xp',x:e.x+rnd(-8,8),y:e.y+rnd(-8,8),vx:rnd(-90,90),vy:rnd(-90,90),r:5,t:0,life:22});floater(e.x,e.y-20,'ДЕТАЛЬ С БРАКОМ','#e8d27a');}break;
    case 'railshield':for(let i=0;i<3;i++)G.pick.push({k:'part80',x:e.x+rnd(-14,14),y:e.y+rnd(-14,14),vx:rnd(-80,80),vy:rnd(-80,80),r:6,t:0,life:12,noMag:true});break;
    case 'echo80':if(!(G.echoHitT80>(e.born80||0)))conEvent('echoClean');break;
    case 'loop':if(G.mc)G.mc.loopK80=(G.mc.loopK80||0)+1;if(e.lb80){if(!G.world)for(let i=0;i<Math.ceil(EDEF.loop.xp*.5);i++)G.pick.push({k:'xp',x:e.x+rnd(-8,8),y:e.y+rnd(-8,8),vx:rnd(-90,90),vy:rnd(-90,90),r:5,t:0,life:22});else G.save.carry+=3;floater(e.x,e.y-22,'ПЕТЛЯ РАЗОРВАНА','#6b8cff');if((e.lr80||0)<=1)conEvent('loopBreak');}else if(G.mc)G.mc.loopBad80=1;break;
    case 'inverse':if(!e.pulsed80)conEvent('inverseFast');break;
    case 'recycler':if(hop>=8)conEvent('recyclerFull');break;
    case 'pilgrim':{const S=G.save;if(S&&S.story)S.story.pilgrimsKilled=(S.story.pilgrimsKilled||0)+1;break;}}}
// перехват смерти Петли: след на 5 с
function loopIntercept80(e){if(e.tr80>0)return true;if(e.win80>0&&e.spawnT<=0){e.lb80=1;return false;}if((e.lr80||0)>=(rankD80()>=2?1:2))return false;
  e.tr80=5;e.ghost=true;e.hp=1;e.vx=e.vy=0;e.contact0=e.contact||10;e.contact=0;if(G.prio===e)G.prio=null;explode(e.x,e.y,'#6b8cff',10,.6);
  if(!(G.h80&&G.h80.loop)){G.h80=G.h80||{};G.h80.loop=1;floater(e.x,e.y-24,'ПЕТЛЯ ВЕРНЁТСЯ · ДОБЕЙТЕ ЗА 2 С','#6b8cff');}return true;}
function loopBreak80(e){if(!e.alive||!(e.tr80>0))return;e.tr80=0;e.ghost=false;e.win80=99;e.spawnT=0;e.hp=0;kill(e);}
// --- снаряды игрока (до общих попаданий; true = поглощён) ---
function b80Hit(b){
  for(const e of G.enemies){if(!e.alive)continue;
    if(e.type==='railshield'&&e.spawnT<=0&&e.fa!==undefined){const ux=Math.cos(e.fa+Math.PI/2)*30,uy=Math.sin(e.fa+Math.PI/2)*30;
      if(segInter(b.px,b.py,b.x,b.y,e.x-ux,e.y-uy,e.x+ux,e.y+uy)){if(b.charged||b.blast){if(!b.hit.includes(e)){b.hit.push(e);hurt(e,b.dmg*1.5,{charged:!!b.charged,blast:!!b.blast});}continue;}
        hurt(e,b.dmg,{rail:true});b.life=0;e.shieldFlash=.08;if(SET.fx)part(b.x,b.y,rnd(-40,40),rnd(-40,40),.25,'#c9d2de',2);return true;}}
    if(e.type==='loop'&&e.tr80>0&&b.charged&&segDist(b.px,b.py,b.x,b.y,e.x,e.y)<e.r+10){loopBreak80(e);}}
  return false;}
// импульс: следы Петель, память Отзвуков, штамп
function pulse80(p,R){for(const e of G.enemies.slice()){if(e.type==='loop'&&e.tr80>0&&Math.hypot(e.x-p.x,e.y-p.y)<R+e.r)loopBreak80(e);}
  if(G.echoQ80&&G.echoQ80.length&&G.enemies.some(e=>e.alive&&e.type==='echo80'&&Math.hypot(e.x-p.x,e.y-p.y)<R+e.r)){G.echoQ80.length=0;if(G.mc)G.mc.echoWipe80=1;floater(p.x,p.y-30,'ПАМЯТЬ ОТЗВУКА СТЁРТА','#b48cff');}
  if(G.stamp80)stampOff80('ИМПУЛЬС');}
function stampOff80(how){G.stamp80=null;document.body.classList.remove('stamp80');const p=G.player;if(p)floater(p.x,p.y-30,'ШТАМП СБРОШЕН','#ff7a3d');conEvent('stampOff');}
// --- автоприцел (замена 0.7.5): веса новых целей, мишень полигона, радиус в темноте ---
function aimPt(e){const p=G.player;if(e&&e.alive&&p){if(e.type==='membrane'&&e.wa!==undefined){const s=memSeg(e),dx=s[2]-s[0],dy=s[3]-s[1],L2=dx*dx+dy*dy||1,k=clamp(((p.x-s[0])*dx+(p.y-s[1])*dy)/L2,.12,.88);return {x:s[0]+dx*k,y:s[1]+dy*k};}
    if(e.type==='railshield'&&e.fa!==undefined){const ux=Math.cos(e.fa+Math.PI/2),uy=Math.sin(e.fa+Math.PI/2),k=clamp((p.x-e.x)*ux+(p.y-e.y)*uy,-24,24);return {x:e.x+ux*k,y:e.y+uy*k};}}return e;}
function nearestEnemy(x,y,R,ignoreDecoy){
  if(!ignoreDecoy&&G.jam&&G.jam.phase===2){const dc=G.enemies.find(e=>e.type==='decoy'&&targetable(e));if(dc)return dc;}
  if(G.bo80>=.5)R=Math.min(R,380);
  let best=null,bd=R,ab=null,abd=R,dm=null;for(const e of G.enemies){if(e.type==='rangedummy'){if(e.alive)dm=e;continue;}
    if(!targetable(e)||(NOAUTO.has(e.type)&&!(e.type==='pilgrim'&&e.hostile80))||e.retreat||e.n74)continue;let d=Math.hypot(e.x-x,e.y-y)-e.r;
    if(e.type==='absorber'&&!e.tired){if(d<abd){abd=d;ab=e;}continue;}
    if(e.type==='membrane'){const q=aimPt(e);d=Math.hypot(q.x-x,q.y-y)*1.5;}
    else if(e.type==='railshield'){const q=aimPt(e);d=Math.hypot(q.x-x,q.y-y)*1.3;}
    else if(e.type==='labrat'&&e.beam)d*=.7;else if(e.type==='echo80')d*=.8;
    if(d<bd){bd=d;best=e;}}
  if(!best&&ab)best=ab;
  if(!best&&dm&&G.world&&W80.range&&inRange80(x,y,200)&&dm.spawnT<=0&&Math.hypot(dm.x-x,dm.y-y)<R)best=dm;
  if(!best){for(const e of G.enemies){if((e.type==='mine'||e.type==='shell')&&targetable(e)){const d=Math.hypot(e.x-x,e.y-y);if(d<Math.min(bd,260)){bd=d;best=e;}}}}return best;}
// --- утечка охлаждения: снаряды втрое медленнее ---
function leakK80(x,y){if(!G.world&&!inMission())return 1;const L=G.world?W80.near:(G.x80&&G.x80.leaks);if(!L||!L.length)return 1;for(const q of L)if((x-q.x)*(x-q.x)+(y-q.y)*(y-q.y)<q.r*q.r)return 1/3;return 1;}
// --- общий тик (миссия и мир) ---
function ens80(){if(!G.rcB80)G.rcB80=[];if(!G.echoBl80)G.echoBl80=[];if(!G.echoB80)G.echoB80=[];if(!G.echoQ80)G.echoQ80=[];if(!G.dmgN80)G.dmgN80=[];if(G.echoSeq80===undefined)G.echoSeq80=0;if(G.echoHitT80===undefined)G.echoHitT80=-99;if(G.rcDrop80===undefined){G.rcDrop80=0;G.rcLost80=0;}}
function c80Tick(dt){const p=G.player;if(!p)return;ens80();const S=G.save;if(S)w80S().clk+=dt;
  if(G.insp80>0){G.insp80-=dt;if(G.insp80By&&!G.insp80By.alive)G.insp80=0;}for(const e of G.enemies)if(e.insB80>0)e.insB80-=dt;
  if(G.inv80>0)G.inv80-=dt;if(G.slow80>0)G.slow80-=dt;if(p.hp<=0){G.inv80=0;G.slow80=0;}
  if(G.stamp80){const s=G.stamp80;if(p.hp<=0){G.stamp80=null;document.body.classList.remove('stamp80');}else if(p.dashT>0)stampOff80('РЫВОК');else{s.t-=dt;if(s.t<=0){G.stamp80=null;document.body.classList.remove('stamp80');if(G.mc)G.mc.stampBoom80=1;explode(p.x,p.y,'#ff7a3d',30,1);G.shock.push({x:p.x,y:p.y,r:10,R:90,t:0,col:'#ff7a3d'});sfx('boom');shake(6);
        damagePlayer(22);for(const o of G.enemies){if(!o.alive||o.spawnT>0||STATIC.has(o.type)||EDEF[o.type].sbp||EDEF[o.type].passive)continue;if(Math.hypot(o.x-p.x,o.y-p.y)<90+o.r)hurt(o,40,{force:true});}}}}
  // Утилизатор: подбираемое тянется спиралью
  for(const k of G.pick){if(!k.c80){k.c80=1;if(k.k==='xp'||k.k==='lom')G.rcDrop80=(G.rcDrop80||0)+1;}const e=k.rc80;if(!e)continue;if(!e.alive||e.hopper&&e.hopper.length>=12){k.rc80=null;k.noMag=k.k==='part80';continue;}
    if(p.hp>0&&Math.hypot(k.x-p.x,k.y-p.y)<(G.st.mag||0)*.6){k.rc80=null;k.noMag=k.k==='part80';continue;}
    const dx=e.x-k.x,dy=e.y-k.y,d=Math.hypot(dx,dy)||1;k.vx=dx/d*160-dy/d*60;k.vy=dy/d*160+dx/d*60;if(d<e.r){k.life=0;e.hopper.push({k:k.k,v:k.v||1});e.hopper0=Math.max(e.hopper0||0,e.hopper.length);}}
  // снаряды Утилизатора: промах — снова на пол
  const live=(G.rcB80.length||G.echoB80.length||G.echoBl80.length)?new Set(G.eb):null;G.live80=live;
  if(G.rcB80.length){for(const b of G.rcB80){if(b.life>0&&live.has(b))continue;const hitP=p.hp>0&&Math.hypot(b.x-p.x,b.y-p.y)<b.r+14;const it=b.rc80;b.rc80=null;
      if(hitP){if(it&&(it.k==='xp'||it.k==='lom'))G.rcLost80++;}else if(it){G.pick.push({k:it.k,x:clamp(b.x,10,BW-10),y:clamp(b.y,10,BH-10),vx:0,vy:0,r:it.k==='part80'?6:it.k==='cell'?9:5,t:0,life:it.k==='part80'?10:20,v:it.v||1,stab:it.k==='cell'?0:undefined,noMag:it.k==='part80'});}}
    G.rcB80=G.rcB80.filter(b=>b.rc80&&b.life>0&&live.has(b));}
  echoTick80(dt);
  for(const n of G.dmgN80){n.t-=dt;n.y-=30*dt;}G.dmgN80=G.dmgN80.filter(n=>n.t>0);
  if(G.res80)res80Tick(dt);}
// --- Отзвук: запись и ответ ---
function echoTick80(dt){const p=G.player,E=G.enemies.filter(e=>e.alive&&e.type==='echo80'&&e.spawnT<=0);
  if(!E.length){if(G.echoQ80&&G.echoQ80.length)G.echoQ80.length=0;for(const b of G.pb)b.e80=1;return;}
  const Q=G.echoQ80||(G.echoQ80=[]);
  for(const b of G.pb){if(b.e80)continue;b.e80=1;if(b.drone||b.turret||b.jr||b.test||(b.age||0)>.08||Math.hypot(b.x-p.x,b.y-p.y)>60)continue;
    if(Q.length>=90)Q.shift();Q.push({t:G.t,seq:G.echoSeq80++,off:angDiff(Math.atan2(b.vy,b.vx),p.ang),spd:Math.hypot(b.vx,b.vy),dmg:b.dmg,blast:b.blast?(b.R||110):0,charged:!!b.charged});}
  E.sort((a,c)=>a.uid-c.uid);const cap=[12,18,22][rankD80()];
  while(Q.length&&G.t-Q[0].t>=1){const r=Q.shift();const e=E[r.seq%E.length];e.rl=Math.min(12,(e.rl===undefined?12:e.rl));if(e.rl<1)continue;e.rl-=1;
    if(p.hp<=0)continue;const a=Math.atan2(p.y-e.y,p.x-e.x)+r.off;const b=shootE(e.x,e.y,a,Math.min(700,r.spd*.7),clamp(r.dmg*.4,2,cap),'#c9b6ff',r.charged?7:r.blast?6:4);
    if(b){b.ech80=1;G.echoB80.push(b);if(r.blast){b.bl80=r.blast*.6;G.echoBl80.push(b);}}}
  for(const e of E)e.rl=Math.min(12,(e.rl===undefined?12:e.rl)+12*dt);
  // попадания по игроку и взрывы «Разрыва»-копии
  const live=G.live80||new Set(G.eb);
  if(G.echoB80.length){for(const b of G.echoB80){if(b.life>0&&live.has(b))continue;if(p.hp>0&&Math.hypot(b.x-p.x,b.y-p.y)<b.r+14){b.e80h=1;G.echoHitT80=G.t;G.echoDmg80=(G.echoDmg80||0)+b.dmg;if(G.mc)G.mc.echoHit80=1;}b.e80d=1;}G.echoB80=G.echoB80.filter(b=>!b.e80d);}
  if(G.echoBl80.length){for(const b of G.echoBl80){if(b.life>0&&live.has(b))continue;if(b.bx80)continue;b.bx80=1;const R=b.bl80||60;explode(b.x,b.y,'#c9b6ff',14,.6);G.shock.push({x:b.x,y:b.y,r:6,R,t:0,col:'#c9b6ff',thin:true});
      if(p.hp>0&&p.dashT<=0&&Math.hypot(b.x-p.x,b.y-p.y)<R&&!b.e80h){damagePlayer(b.dmg*.5);G.echoHitT80=G.t;}}G.echoBl80=G.echoBl80.filter(b=>!b.bx80);}}
// --- Утилизатор: высыпать бункер ---
function rcRelease80(e,silent){const H_=e.hopper||[];if(!H_.length&&silent)return;const extra=silent?0:Math.ceil(H_.length*.15);
  for(const it of H_)G.pick.push({k:it.k,x:e.x+rnd(-16,16),y:e.y+rnd(-16,16),vx:rnd(-120,120),vy:rnd(-120,120),r:it.k==='part80'?6:it.k==='cell'?9:5,t:0,life:it.k==='part80'?10:22,v:it.v||1,noMag:it.k==='part80'});
  for(let i=0;i<extra;i++)G.pick.push(G.world?{k:'lom',x:e.x+rnd(-16,16),y:e.y+rnd(-16,16),vx:rnd(-120,120),vy:rnd(-120,120),r:5,t:0,life:30,v:1}:{k:'xp',x:e.x+rnd(-16,16),y:e.y+rnd(-16,16),vx:rnd(-120,120),vy:rnd(-120,120),r:5,t:0,life:22});
  if(!silent&&H_.length)floater(e.x,e.y-30,'УТИЛИЗАТОР ВСКРЫТ · +'+extra,'#ffb84d');e.hopper=[];}
// --- мишень полигона ---
function rangeHit80(e,dmg,src){const col=src.pulse||src.blast?'#e86bff':src.charged?'#8fe9ff':'#ffffff',now=G.t;e.flash=.07;sfx('hit');const R=W80.rlog||(W80.rlog=[]);R.push({t:now,v:dmg});W80.last=dmg;
  const N=G.dmgN80,mx=isMob()?12:40;const rec=N.filter(n=>now-n.at<.2&&n.r80===e);
  if(rec.length>=8){const n=rec[rec.length-1];n.v+=dmg;n.t=1;}else{if(N.length>=mx)N.shift();N.push({x:e.x+rnd(-14,14),y:e.y-e.r-8,v:dmg,col,t:1,at:now,r80:e});}}
// --- мирные/враждебные Паломники ---
function pilgrimHit80(e){const g=e.pg80;if(G.mc)G.mc.pilHit80=1;if(!g||g.hostile)return;if(g.tol>0){g.tol--;floater(e.x,e.y-24,'ОНИ СЧИТАЮТ ЭТО ОШИБКОЙ','#dfe8ff');return;}
  g.hostile=true;g.hostT=300;g.hitByP=1;for(const o of g.ships)if(o.alive){o.peace=false;o.hostile80=true;}floater(e.x,e.y-24,'ПАЛОМНИКИ: ТЫ НЕ ИЗ НАС','#ff4f6e');radioLine('ИСТОК','#6b8cff','…ты не из нас…',.1);sfx('warn');}
function pilgrimAI80(e,dt){const p=G.player,g=e.pg80;if(!g)return;if(e.hostile80&&g.hostile){const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,k=clamp((pd-300)/100,-1,1);steer(e,pdx/pd*k-pdy/pd*.5*e.dir,pdy/pd*k+pdx/pd*.5*e.dir,e.spd*1.4,dt,2);
    e.cd-=dt;if(e.cd<=0&&p.hp>0&&pd<700){e.cd=1.2;const a=Math.atan2(pdy,pdx);if(G.st&&G.st.weapon==='blast'){const b=shootE(e.x,e.y,a,380,7,'#dfe8ff',6);if(b){b.ech80=1;b.bl80=60;G.echoBl80.push(b);}}else{const n=Math.min(3,(G.st&&G.st.shots)||1);for(let i=0;i<n;i++)shootE(e.x,e.y,a+(i-(n-1)/2)*.12,590,6,'#dfe8ff',4);}}return;}
  const tx=g.dest.x+(e.fo||0)*.0,ty=g.dest.y;const dx=tx-e.x+(e.fx||0),dy=ty-e.y+(e.fy||0),d=Math.hypot(dx,dy)||1;steer(e,dx,dy,Math.min(60,d),dt,1.5);}
// --- спасённая копия (конвой) ---
function res80Tick(dt){const R=G.res80,p=G.player;if(!R)return;R.t-=dt;if(!G.world||sec80()!==6||p.hp<=0||R.t<=0){if(R.t<=0&&G.world)radioLine('КОПИЯ','#dfe8ff','Номера нет. Спасибо.',.2);G.res80=null;return;}
  R.a+=dt*1.4;const tx=p.x+Math.cos(R.a)*70,ty=p.y+Math.sin(R.a)*70;R.x+=(tx-R.x)*Math.min(1,dt*3);R.y+=(ty-R.y)*Math.min(1,dt*3);R.cd-=dt;
  if(R.cd<=0){const t_=nearestEnemy(R.x,R.y,460);if(t_&&t_.type!=='rangedummy'){R.cd=.6;const an=Math.atan2(t_.y-R.y,t_.x-R.x);G.pb.push({x:R.x,y:R.y,px:R.x,py:R.y,vx:Math.cos(an)*760,vy:Math.sin(an)*760,dmg:6*Math.max(1,playerDmgK()),pierce:0,rico:0,life:.7,hit:[],drone:true,jr:true});}else R.cd=.25;}}
// --- тик миссии ---
function t80Tick(dt){if(!inMission()||!G.x80)return;const X=G.x80,p=G.player;c80Tick(dt);const M=MISSIONS[G.m-1];if(G.endT>0||G.deadT>0){G.bo80=Math.max(0,G.bo80-dt);if(G.stamp80){G.stamp80=null;document.body.classList.remove('stamp80');}G.inv80=0;G.slow80=0;return;}
  // отключение света
  if(X.bo){const B=X.bo;if(B.st==='wait'){if(G.waveIdx>=2&&!G.sb){B.t+=dt;if(B.t>=(B.at||(B.at=rnd(6,18)))){B.st='warn';B.t=5;radioLine(X.sec===6?'БЮРО':'ИСТОК',X.sec===6?'#e8d27a':'#6b8cff',X.sec===6?'Смена окончена. Свет — по регламенту.':'…тише… слушай…',0);buzz('ready');}}}
    else if(B.st==='warn'){B.t-=dt;G.bo80=Math.sin(G.t*22)>.3?.45:0;if(B.t<=0){B.st='dark';B.t=20;}}
    else if(B.st==='dark'){B.t-=dt;G.bo80=1;d80H('dark','ТЕМНОТА · АВТОПРИЦЕЛ ВИДИТ ТОЛЬКО РЯДОМ','#e8d27a');if(B.t<=0){B.st='back';B.t=3;}}
    else if(B.st==='back'){B.t-=dt;G.bo80=clamp(B.t/3,0,1);if(B.t<=0){B.st='done';G.bo80=0;}}}
  if(X.leaks.length&&p.hp>0&&X.leaks.some(q=>Math.hypot(p.x-q.x,p.y-q.y)<q.r))d80H('leak','УТЕЧКА ОХЛАЖДЕНИЯ · СНАРЯДЫ ×3 МЕДЛЕННЕЕ','#bfe8ff');
  // Паломники через арену
  if(X.pil&&!X.pil.done&&G.mT>=X.pil.at&&!G.sb){X.pil.done=true;const g={hostile:false,tol:X.pil.tol,ships:[],dest:{x:W+120,y:H*.5}};X.pg=g;const y0=H*rnd(.3,.7);
    for(let i=0;i<3;i++){const e=spawnEnemy('pilgrim',-40-i*50,y0+(i-1)*46,{noAffix:true,noLoot:true,spawnT:.5});e.peace=true;e.pg80=g;e.fx=0;e.fy=(i-1)*46;g.ships.push(e);}
    floater(p.x,p.y-40,'ПАЛОМНИКИ · НЕ СТРЕЛЯТЬ','#dfe8ff');radioLine('ИСТОК','#6b8cff','…мы мимо. Мы не к тебе…',.3);}
  if(X.pg){for(const e of X.pg.ships)if(e.alive&&!e.hostile80&&e.x>W+60){e.alive=false;}}}
// ===== открытый мир секторов VII–VIII =====
const W80={gen:false,zones:[],pults:[],range:null,melt:null,leaks:[],near:[],nearT:0,alarm:null,dummy:null,rlog:[],last:0,radioT:0,boPh:-1};
function w80Gen(){if(W80.gen||!WORLD.sectors[7]||!G.save)return;W80.gen=true;const N=WORLD.nodes,ex=[...WORLD.shops,WORLD.hangar,WORLD.arsenal].filter(Boolean);
  const okAt=(x,y,dn,dp)=>w58Far(x,y,N,dn)&&w58Far(x,y,W80.zones,dp)&&w58Far(x,y,W80.pults,dp)&&w58Far(x,y,ex,800)&&inSectors(x,y)&&WORLD.sectors.every(sc=>!sc.bx||Math.hypot(x-sc.bx,y-sc.by)>900);
  const ZS=[[6,'КОНВОЙ «УТИЛИЗАЦИЯ»','convoy',28],[6,'РЕВИЗИЯ','audit',28],[7,'ПАЛОМНИКИ','pilgrims',32]];
  const pick=(sec,seed)=>{for(const [dn,dz] of [[1300,1700],[1300,1400],[1300,1150],[1150,1000]]){const R=mulberry(seed);const q=w58Pt(sec,R,(x,y)=>okAt(x,y,dn,dz),500);if(w58Far(q.x,q.y,N,dn)&&w58Far(q.x,q.y,W80.zones,dz))return q;}return pt80(sec,seed,(x,y,k)=>okAt(x,y,900*k,900*k),500);};
  ZS.forEach(([sec,name,k,after],i)=>{const q=pick(sec,8000+i*41);const z={x:q.x,y:q.y,home:{x:q.x,y:q.y},req:0,set:[],w58:1,sec,after,name,lead:null,reinf:{},idx:1200+i,k74:'x80',k80:k,cool:0};W80.zones.push(z);WORLD.zones.push(z);W58.zones.push(z);});
  const GZ=[[6,'СМЕНА',['labrat','defect','gunner'],['hunter',['armor']],28],[6,'БРАКОВКА',['defect','stamp','phantom'],['shade',['fast']],28],[7,'ОТРАЖЕНИЯ',['echo80','phantom','shocker'],['hunter',['armor']],32],[7,'ПЕТЛИ',['loop','gunner','mirror'],['shade',['boom']],32]];
  GZ.forEach(([sec,name,set,lead,after],i)=>{const q=pick(sec,8100+i*43);const z={x:q.x,y:q.y,req:0,set,w58:1,sec,after,name,lead,reinf:{},idx:1210+i,z80g:1};W80.zones.push(z);WORLD.zones.push(z);W58.zones.push(z);});
  for(let i=0;i<3;i++){const q=pt80(6,8200+i*17,(x,y,k)=>okAt(x,y,700*k,1500*k)&&w58Far(x,y,W80.pults,Math.max(900,1500*k)),400);W80.pults.push({x:q.x,y:q.y,i,ch:0});}
  {const q=pt80(6,8301,(x,y,k)=>okAt(x,y,900*k,1200*k)&&W80.zones.every(z=>Math.abs(x-z.x)>1500*k||Math.abs(y-z.y)>1100*k)&&W80.pults.every(p_=>Math.abs(p_.x-x)>560||Math.abs(p_.y-y)>460),600);W80.range={x:q.x,y:q.y,w:600,h:400};}
  {const cz=W80.zones[0];const q=pt80(6,8302,(x,y,k)=>okAt(x,y,800*k,900*k)&&Math.hypot(x-cz.x,y-cz.y)>1600*k&&!inRange80(x,y,250),500);W80.melt={x:q.x,y:q.y};}
  for(let i=0;i<7;i++){const q=pt80(6,8400+i*13,(x,y,k)=>w58Far(x,y,N,600*k)&&w58Far(x,y,W80.leaks,Math.max(450,700*k))&&inSectors(x,y)&&!inRange80(x,y,Math.max(250,400*k))&&w58Far(x,y,W80.pults,350),300);W80.leaks.push({x:q.x,y:q.y,r:220+Math.round(mulberry(8450+i)()*100)});}
  {const n38=N.find(n=>n.m===38),b=WORLD.sectors[7].box;W80.dest=n38?{x:n38.x,y:n38.y}:{x:(b[0]+b[2])/2,y:(b[1]+b[3])/2};}}
// размещение с постепенным ослаблением дистанций; в худшем случае — самая свободная точка (не центр сектора)
function pt80(sec,seed,fn,m){m=m||300;for(const k of [1,.8,.65,.5,.38,.27]){const q=w58Pt(sec,mulberry(seed),(x,y)=>fn(x,y,k),m);if(fn(q.x,q.y,k))return q;}
  const b=WORLD.sectors[sec].box,R=mulberry(seed+1),occ=[...WORLD.nodes,...W80.zones,...W80.pults,...W80.leaks,...(W80.range?[W80.range]:[]),...(W80.melt?[W80.melt]:[])];let best=null,bd=-1;
  for(let i=0;i<300;i++){const x=b[0]+m+R()*(b[2]-b[0]-2*m),y=b[1]+m+R()*(b[3]-b[1]-2*m);if(W80.range&&inRange80(x,y,200))continue;let d=1e9;for(const q of occ)d=Math.min(d,Math.hypot(q.x-x,q.y-y));if(d>bd){bd=d;best={x:Math.round(x),y:Math.round(y)};}}
  return best||{x:(b[0]+b[2])/2,y:(b[1]+b[3])/2};}
function inRange80(x,y,pad){const r=W80.range;if(!r)return false;return Math.abs(x-r.x)<r.w/2+pad&&Math.abs(y-r.y)<r.h/2+pad;}
function rangeGoal80(){const ws=w80S();return ws.rangeGoal||(ws.rangeGoal=Math.round(Math.max(60,(ws.rangeBest||0)*1.1)));}
function convoyRoute80(z){const b=WORLD.sectors[6].box,m=W80.melt,h=z.home,R=mulberry(8500+Math.floor((w80S().clk||0)/60));const pts=[];for(let i=1;i<=3;i++){const f=i/4;pts.push({x:clamp(h.x+(m.x-h.x)*f+(R()-.5)*900,b[0]+300,b[2]-300),y:clamp(h.y+(m.y-h.y)*f+(R()-.5)*900,b[1]+300,b[3]-300)});}pts.push({x:m.x,y:m.y});return pts;}
function w80ZoneSpawn(z){const p=G.player,R=(r)=>[z.x+rnd(-r,r),z.y+rnd(-r,r)];z.t80=0;z.out80=null;z.prov80=0;z.alarm=0;z.stealth=0;z.n=0;
  switch(z.k80){
    case 'convoy':{z.tug={x:z.home.x,y:z.home.y,i:0,route:convoyRoute80(z),ang:0};const bx=spawnEnemy('convoybox',z.home.x-46,z.home.y,{zone:z,noSec:true,noAffix:true,noLoot:true,spawnT:.6});bx.hp=bx.maxHp=600;z.box=bx;z.n++;
      for(const t of ['labrat','labrat','recycler','gunner','gunner'])w74Sp(z,t,...R(160),{convoy80:z});break;}
    case 'audit':{z.ap={x:z.home.x-800,y:z.home.y-500};z.wp=0;z.path=[];for(let r=0;r<5;r++){const y=z.home.y-500+r*250;z.path.push(r%2?{x:z.home.x+800,y}:{x:z.home.x-800,y},r%2?{x:z.home.x-800,y}:{x:z.home.x+800,y});}z.dir={x:1,y:0};
      for(let i=0;i<3;i++)w74Sp(z,'inspector',z.ap.x,z.ap.y+(i-1)*260,{audit80:z,ai80:i});break;}
    case 'pilgrims':{const g={hostile:false,tol:(G.save.story&&G.save.story.spared||0)>=5?1:0,ships:[],dest:W80.dest,hitByP:0};z.pg=g;z.esc=0;z.atkT=12;const n=4+Math.floor(Math.random()*3);
      for(let i=0;i<n;i++){const fx=((i%3)-1)*50,fy=(Math.floor(i/3)-.5)*50;const e=w74Sp(z,'pilgrim',z.home.x+fx,z.home.y+fy,{full:true,noSec:true});e.hp=e.maxHp=80;e.peace=true;e.pg80=g;e.fx=fx;e.fy=fy;g.ships.push(e);}break;}}}
function w80ZoneRadio(z){const L={convoy:['БЮРО','#e8d27a','Партия на переплавку. Сопровождение — по регламенту.'],audit:['БЮРО','#e8d27a','Плановая ревизия квадрата. Изделия — на места.'],pilgrims:['ИСТОК','#6b8cff','…мы идём. Ты тоже идёшь. Не мешай…']}[z.k80];
  if(z.z80g)radioLine(z.sec===6?'БЮРО':'ИСТОК',z.sec===6?'#e8d27a':'#6b8cff',z.sec===6?'Линия работает. Посторонним — покинуть цех.':'…повтори… повтори… повтори…',.4);else if(L)radioLine(L[0],L[1],L[2],.4);}
function convoyAI80(e,dt){const z=e.convoy80;if(!z||!z.active||z.prov80||!z.box||!z.box.alive)return false;const p=G.player;if(Math.hypot(p.x-z.box.x,p.y-z.box.y)<450)return false;
  const tx=z.box.x+Math.cos(e.seed)*90,ty=z.box.y+Math.sin(e.seed)*90;steer(e,tx-e.x,ty-e.y,Math.min(e.spd,140),dt,2);return true;}
function auditAI80(e,dt){const z=e.audit80;if(!z||!z.active||z.alarm)return false;const p=G.player,dx=z.dir.x,dy=z.dir.y,i=e.ai80||0;
  const tx=z.ap.x-dy*(i-1)*260,ty=z.ap.y+dx*(i-1)*260;steer(e,tx-e.x,ty-e.y,Math.min(Math.max(e.spd*1.6,90),Math.hypot(tx-e.x,ty-e.y)*3+40),dt,3);
  e.ca=Math.atan2(dy,dx)+Math.sin(G.t*.8+i)*.44;const dark=G.bo80>=.5,len=dark?260:420;e.clen=len;const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy);
  const see=p.hp>0&&pd<len&&Math.abs(angDiff(Math.atan2(pdy,pdx),e.ca))<.436&&e.spawnT<=0;const need=rankD80()===0?1.2:sbHard()?.5:.8;
  if(see)e.seeT=(e.seeT||0)+dt;else e.seeT=Math.max(0,(e.seeT||0)-dt*2);if(e.seeT>=need){e.seeT=0;e.cool80=5;insAlarm80(e);}return true;}
function alarmAI80(e,dt){const q=e.alarm80;if(!q||!W80.alarm||W80.alarm.st!=='on'){e.alarm80=null;return false;}const d=Math.hypot(q.x-e.x,q.y-e.y);if(d<180)return false;steer(e,q.x-e.x,q.y-e.y,e.spd,dt,2);return true;}
function w80ZoneTick(dt){const p=G.player;for(const z of W80.zones){if(!z.k80)continue;
    if(!z.active){if(z.home&&(z.x!==z.home.x||z.y!==z.home.y)){z.x=z.home.x;z.y=z.home.y;}z.tug=null;z.box=null;continue;}
    z.t80=(z.t80||0)+dt;const mine=G.enemies.filter(e=>e.alive&&e.zone===z);
    if(z.k80==='convoy'&&z.tug){const T=z.tug,B=z.box;if(!z.prov80&&mine.some(e=>e.hp<e.maxHp-.5))z.prov80=1;
      const halt=W80.alarm&&W80.alarm.st==='on'&&W80.pults[W80.alarm.i]&&Math.hypot(T.x-W80.pults[W80.alarm.i].x,T.y-W80.pults[W80.alarm.i].y)<2000;
      if(B&&B.alive&&!halt&&!z.out80){const q=T.route[T.i];if(q){const dx=q.x-T.x,dy=q.y-T.y,d=Math.hypot(dx,dy);if(d<20)T.i++;else{T.x+=dx/d*55*dt;T.y+=dy/d*55*dt;T.ang=Math.atan2(dy,dx);}}
        else{z.out80='melted';for(const e of mine)e.alive=false;radioLine('БЮРО','#e8d27a','Партия списана.',.1);floater(p.x,p.y-40,'КОНТЕЙНЕР НА ПЕРЕПЛАВКЕ','#ff7a3d');}}
      if(B&&B.alive){B.x=T.x-Math.cos(T.ang)*46;B.y=T.y-Math.sin(T.ang)*46;B.vx=B.vy=0;}
      else if(B&&!B.alive&&!z.out80)convoyBroken80(z,B);
      z.x=T.x;z.y=T.y;}
    if(z.k80==='audit'&&z.ap){if(!z.alarm&&mine.some(e=>e.hp<e.maxHp-.5)){z.alarm=1;z.stealth=1;}
      if(!z.alarm){const q=z.path[z.wp%z.path.length],dx=q.x-z.ap.x,dy=q.y-z.ap.y,d=Math.hypot(dx,dy);if(d<20)z.wp++;else{z.ap.x+=dx/d*70*dt;z.ap.y+=dy/d*70*dt;z.dir={x:dx/d,y:dy/d};}}
      z.x=z.ap.x;z.y=z.ap.y;}
    if(z.k80==='pilgrims'&&z.pg){const g=z.pg,live=g.ships.filter(e=>e.alive);
      if(live.length){const cx=live.reduce((a,e)=>a+e.x,0)/live.length,cy=live.reduce((a,e)=>a+e.y,0)/live.length;z.x=cx;z.y=cy;
        if(!g.hostile){if(p.hp>0&&Math.hypot(p.x-cx,p.y-cy)<500)z.esc+=dt;z.atkT-=dt;
          if(z.atkT<=0&&z.t80<120){z.atkT=20;for(let i=0;i<2;i++){const a=rnd(0,TAU);w74Sp(z,Math.random()<.5?'echo80':'loop',cx+Math.cos(a)*420,cy+Math.sin(a)*420,{pilgAtk:z});}floater(cx,cy-40,'НА ПАЛОМНИКОВ НАПАЛИ','#ff4f6e');}
          for(const e of mine){if(!e.pilgAtk||e.tr80>0)continue;e.pat80=(e.pat80===undefined?1:e.pat80)-dt;if(e.pat80<=0){let t_=null,td=320;for(const o of live){const q=Math.hypot(o.x-e.x,o.y-e.y);if(q<td){td=q;t_=o;}}if(t_){e.pat80=1.4;x74().tracers.push({x1:e.x,y1:e.y,x2:t_.x,y2:t_.y,t:.18,c:EDEF[e.type].col});t_.hp-=12;t_.flash=.1;if(t_.hp<=0){t_.alive=false;explode(t_.x,t_.y,'#dfe8ff',12,.6);g.lost=(g.lost||0)+1;}}else e.pat80=.3;}}
          if(Math.hypot(cx-g.dest.x,cy-g.dest.y)<160){const atk=mine.filter(e=>e.pilgAtk&&e.alive).length;z.out80=z.esc>=40&&!atk?'escorted':'passed';for(const e of mine)e.alive=false;}}
        else if(!live.some(e=>e.hostile80))z.out80='killed';}
      else if(!z.out80)z.out80=g.hostile?'killed':'lost';}}}
function convoyBroken80(z,B){z.out80='broken';G.res80={x:B.x,y:B.y,a:0,cd:.5,t:120};floater(B.x,B.y-30,'КОПИЯ СПАСЕНА · ЛЕТИТ С ВАМИ 2 МИН','#dfe8ff');radioLine('КОПИЯ','#dfe8ff','…я с тобой. Недолго.',.3);conEvent('convoyBreak');conEvent('rescue80');sfx('level');}
function w80ZoneDone(z){if(z.k80==='convoy'&&!z.out80&&z.box)convoyBroken80(z,z.box);if(z.k80==='pilgrims'&&!z.out80)z.out80=z.pg&&z.pg.hostile?'killed':'lost';const S=G.save,p=G.player,ws=w80S(),zd=ws.zd||(ws.zd={}),first=!zd[z.k80];zd[z.k80]=1;z.active=false;z.cool=240;let v=Math.round((first?10+z.n*3:3)*3),msg='ПАТРУЛЬ РАЗБИТ';
  if(z.k80==='convoy'){if(z.out80==='melted'){v=0;msg='ПАРТИЯ СПИСАНА · НАГРАДЫ НЕТ';}else{v+=60;msg='КОНВОЙ РАЗБИТ · КОПИЯ СПАСЕНА';}}
  if(z.k80==='audit'&&z.stealth){v+=30;msg='РЕВИЗИЯ НЕ ЗАМЕТИЛА';conEvent('auditStealth');}
  if(z.k80==='pilgrims'){const g=z.pg||{};if(z.out80==='escorted'){v=30;msg='ПАЛОМНИКИ ДОШЛИ · ГОЛОС ИСТОКА';const k=ws.voices||0;if(k<VOICES80.length){toast('ГОЛОС ИСТОКА '+(k+1)+'/'+VOICES80.length,VOICES80[k]);ws.voices=k+1;}else radioLine('ИСТОК','#6b8cff',VOICES80[Math.floor(Math.random()*VOICES80.length)],.2);if(!g.hitByP)conEvent('pilgrimsSafe');}
    else if(z.out80==='killed'){v=0;msg='ЗВЕНО УНИЧТОЖЕНО';}else{v=0;msg=z.out80==='lost'?'ПАЛОМНИКИ ПОГИБЛИ':'ПАЛОМНИКИ ПРОШЛИ';}
    if(storyFlag('fleet27')==='engine'&&!ws.karr&&z.out80==='escorted'){ws.karr=1;radioLine('ПАЛОМНИК','#dfe8ff','Карр жив. Он тоже летит сюда.',2);}}
  if(z.home){z.x=z.home.x;z.y=z.home.y;}z.tug=null;z.box=null;z.pg=null;
  if(v>0){S.carry+=v;if(first)addPilotXP(25);}floater(p.x,p.y-40,msg+(v>0?' · +'+v+' ЛОМА'+(first?'':' · ПОВТОР'):''),'#c9d2de');sfx('level');if(v>0){conEvent('patrol');conEvent('patrol');}if(G.event==='zone')G.event=null;saveWorld();return true;}
// --- мировой тик ---
function w80WorldTick(dt){const S=G.save,p=G.player;if(!S||!p)return;w80Gen();if(!W80.gen)return;const ws=w80S();c80Tick(dt);w80ZoneTick(dt);
  const sec=sec80();
  if(sec>=0&&!ws.seen[sec]){ws.seen[sec]=1;if(sec===6)radioLine('БЮРО','#e8d27a','Цех «Предел». Изделие вне партии обнаружено. Вернуть на линию.',1);else radioLine('ИСТОК','#6b8cff','…ты дошёл. Все доходят. Не все возвращаются…',1);}
  // свет по циклу сектора
  if(sec>=0){const cyc=sec===6?[150,5,40,3]:[120,5,45,3],L=cyc[0]+cyc[1]+cyc[2]+cyc[3],ph=((ws.clk||0)+(sec===6?0:90))%L;let st,k;
    if(ph<cyc[0]){st=0;k=0;}else if(ph<cyc[0]+cyc[1]){st=1;k=Math.sin(G.t*22)>.3?.45:0;}else if(ph<cyc[0]+cyc[1]+cyc[2]){st=2;k=1;}else{st=3;k=clamp(1-(ph-cyc[0]-cyc[1]-cyc[2])/cyc[3],0,1);}
    if(st===1&&W80.boPh!==1){radioLine(sec===6?'БЮРО':'ИСТОК',sec===6?'#e8d27a':'#6b8cff',sec===6?'Смена окончена. Свет — по регламенту.':'…тише… слушай…',0);buzz('ready');}W80.boPh=st;G.bo80=k;}
  else{G.bo80=Math.max(0,G.bo80-dt*2);W80.boPh=-1;}
  // утечки рядом
  W80.nearT-=dt;if(W80.nearT<=0){W80.nearT=.5;W80.near=W80.leaks.filter(q=>Math.hypot(q.x-p.x,q.y-p.y)<1700);}
  if(p.hp>0&&W80.near.some(q=>Math.hypot(p.x-q.x,p.y-q.y)<q.r))d80H('leak','УТЕЧКА ОХЛАЖДЕНИЯ · СНАРЯДЫ ×3 МЕДЛЕННЕЕ','#bfe8ff');
  // пульты тревоги
  for(const q of W80.pults){const ready=(ws.clk||0)>=(ws.alarmAt[q.i]||0);if(ready&&!W80.alarm&&p.hp>0&&Math.hypot(p.x-q.x,p.y-q.y)<44){q.ch+=dt;if(q.ch>=.6){q.ch=0;W80.alarm={i:q.i,st:'count',t:10,sec:10};floater(q.x,q.y-40,'ТРЕВОГА ЧЕРЕЗ 10 С','#ff4f6e');sfx('warn');buzz('ready');}}else q.ch=0;}
  if(W80.alarm){const A=W80.alarm,q=W80.pults[A.i];A.t-=dt;
    if(A.st==='count'){const s=Math.ceil(A.t);if(s!==A.sec){A.sec=s;if(Math.hypot(p.x-q.x,p.y-q.y)<2200){floater(q.x,q.y-40,'ТРЕВОГА · '+s,'#ff4f6e');if(s<=5)buzz('tap');}}
      if(A.t<=0){A.st='on';A.t=60;radioLine('БЮРО','#e8d27a','Изделие вне партии. Всем постам.',0);sfx('bigboom');shake(6);}}
    else if(A.st==='on'){for(const e of G.enemies){if(!e.alive||EDEF[e.type].passive||STATIC.has(e.type)||e.alarm80)continue;if(sectorIdx(e.x,e.y)===6&&Math.hypot(e.x-q.x,e.y-q.y)<2000)e.alarm80=q;}
      if(A.t<=0){for(const e of G.enemies)e.alarm80=null;ws.alarmAt[A.i]=(ws.clk||0)+rnd(1200,1800);W80.alarm=null;saveWorld();}}}
  // полигон
  const r=W80.range;if(r){const d=Math.hypot(p.x-r.x,p.y-r.y);const dm=W80.dummy;
    if(d<900&&(!dm||!dm.alive)){W80.dummy=spawnEnemy('rangedummy',r.x,r.y,{noSec:true,noAffix:true,noLoot:true,spawnT:.3});W80.dummy.hp=W80.dummy.maxHp=1000;}
    else if(d>1400&&dm&&dm.alive){dm.alive=false;W80.dummy=null;}
    for(const e of G.enemies){if(!e.alive||e.type==='rangedummy'||STATIC.has(e.type))continue;if(inRange80(e.x,e.y,e.r)){const dx=e.x-r.x,dy=e.y-r.y,ox=r.w/2+e.r-Math.abs(dx),oy=r.h/2+e.r-Math.abs(dy);if(ox<oy)e.x+=Math.sign(dx||1)*ox;else e.y+=Math.sign(dy||1)*oy;}}
    const now=G.t;W80.rlog=W80.rlog.filter(q=>now-q.t<5);if(W80.rlog.length){const t0=Math.max(1,Math.min(5,now-W80.rlog[0].t+.25));const dps=Math.round(W80.rlog.reduce((a,q)=>a+q.v,0)/t0);W80.dps=dps;
      if(now-W80.rlog[0].t>=2&&dps>(ws.rangeBest||0)){ws.rangeBest=dps;W80.rec=1;}if(now-W80.rlog[0].t>=2&&S.contracts&&S.contracts.list.some(c=>c.tid==='c_range80')&&dps>=rangeGoal80()){conEvent('rangeDps');delete ws.rangeGoal;}
      W80.radioT-=dt;if(W80.radioT<=0&&now-W80.rlog[0].t>=3){W80.radioT=30;radioLine('СТЕНД','#e8d27a','Урон в секунду: '+dps+'. '+(W80.rec?'Выше нормы.':'Норма.'),0);W80.rec=0;}}else W80.dps=0;
    if(inRange80(p.x,p.y,0))d80H('range','СТЕНД ИСПЫТАНИЙ · БЕЙТЕ ПО МИШЕНИ','#e8d27a');}}
// ===== отрисовка =====
function leakDraw80(q,t){const g=ctx.createRadialGradient(q.x,q.y,q.r*.2,q.x,q.y,q.r);g.addColorStop(0,'rgba(191,232,255,.16)');g.addColorStop(1,'rgba(191,232,255,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(q.x,q.y,q.r,0,TAU);ctx.fill();
  ctx.strokeStyle='#dff6ff';ctx.globalAlpha=.35;ctx.lineWidth=1.5;ctx.setLineDash([3,7]);ctx.lineDashOffset=t*8;ctx.beginPath();for(let i=0;i<=28;i++){const a=i/28*TAU,rr=q.r*(1+.04*Math.sin(a*6+t*1.5));ctx.lineTo(q.x+Math.cos(a)*rr,q.y+Math.sin(a)*rr);}ctx.closePath();ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.globalAlpha=1;}
// под врагами: утечки, рельсы
function d80Under(t){const L=G.world?W80.near:(G.x80&&G.x80.leaks);if(L)for(const q of L)if(!G.world||inView(q.x,q.y,q.r))leakDraw80(q,t);
  for(const e of G.enemies){if(!e.alive||e.type!=='railshield'||!e.rail)continue;const R_=e.rail;ctx.strokeStyle='#c9d2de';ctx.globalAlpha=.3;ctx.lineWidth=2;ctx.setLineDash([10,8]);ctx.beginPath();ctx.moveTo(R_.x-R_.ux*220,R_.y-R_.uy*220);ctx.lineTo(R_.x+R_.ux*220,R_.y+R_.uy*220);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}}
// над врагами
function d80Draw(t){const p=G.player;if(!p)return;
  for(const k of G.pick){if(k.k!=='part80')continue;ctx.save();ctx.translate(k.x,k.y);ctx.rotate(k.t*2);ctx.globalAlpha=k.life<3?(Math.sin(k.life*14)>0?1:.3):1;ctx.fillStyle='#1a2030';ctx.strokeStyle='#c9d2de';ctx.lineWidth=1.5;ctx.fillRect(-5,-3,10,6);ctx.strokeRect(-5,-3,10,6);ctx.restore();ctx.globalAlpha=1;}
  for(const k of G.pick){if(!k.rc80||!k.rc80.alive)continue;ctx.strokeStyle='#9fb0c4';ctx.globalAlpha=.35;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(k.x,k.y);ctx.lineTo(k.rc80.x,k.rc80.y);ctx.stroke();ctx.globalAlpha=1;}
  for(const e of G.enemies){if(!e.alive)continue;
    if(e.insB80>0&&!EDEF[e.type].passive){ctx.strokeStyle='#ffd36b';ctx.globalAlpha=.6;ctx.lineWidth=1.5;ctx.strokeRect(e.x-e.r-4,e.y-e.r-4,e.r*2+8,e.r*2+8);ctx.globalAlpha=1;}
    switch(e.type){
      case 'labrat':if(e.beam&&e.beam.alive){const b=e.beam;ctx.strokeStyle='#7affc9';ctx.globalAlpha=.55+.3*Math.sin(t*16);ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.globalAlpha=1;glow(b.x,b.y,b.r*1.6,'#7affc9',.3);}break;
      case 'inspector':if(e.ca!==undefined&&e.spawnT<=0){const len=e.clen||420,k=Math.min(1,(e.seeT||0)/.8);ctx.fillStyle=k>0?`rgba(255,211,107,${.12+.16*k})`:'rgba(255,211,107,.08)';ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.arc(e.x,e.y,len,e.ca-.436,e.ca+.436);ctx.closePath();ctx.fill();
        ctx.strokeStyle='#ffd36b';ctx.globalAlpha=.4;ctx.lineWidth=1;ctx.stroke();ctx.globalAlpha=1;if(e.seeT>0){ctx.strokeStyle='#ffd36b';ctx.lineWidth=3;ctx.beginPath();ctx.arc(p.x,p.y,p.r+10,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();}}break;
      case 'defect':if(e.mode){const c=DEF_COL80[e.mode];worldLabel(e.x,e.y-e.r-12,DEF_TXT80[e.mode],c);if(e.mode==='ram'&&e.rst==='aim'&&!G.noTele){ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.3+.5*Math.sin(t*20);ctx.lineWidth=e.r*1.4;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.x+Math.cos(e.aim)*260,e.y+Math.sin(e.aim)*260);ctx.stroke();ctx.globalAlpha=1;}}break;
      case 'recycler':{const n=e.hopper?e.hopper.length:0;if(n)worldLabel(e.x,e.y-e.r-12,'БУНКЕР '+n+'/12','#ffb84d');if(e.fire80>0&&!G.noTele){glow(e.x,e.y,e.r*2,'#ffd36b',.4+.4*Math.sin(t*30));}break;}
      case 'echo80':{const q=G.echoQ80?G.echoQ80.length:0;ctx.strokeStyle='#b48cff';ctx.globalAlpha=.5;ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+8,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,q/12));ctx.stroke();ctx.globalAlpha=1;break;}
      case 'loop':if(e.tr80>0){ctx.strokeStyle='#6b8cff';ctx.globalAlpha=.4+.3*Math.sin(t*8);ctx.lineWidth=2;ctx.setLineDash([4,5]);ctx.beginPath();ctx.arc(e.x,e.y,e.r+6,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=.9;ctx.lineWidth=3;ctx.beginPath();ctx.arc(e.x,e.y,e.r+12,-Math.PI/2,-Math.PI/2+TAU*(1-e.tr80/5));ctx.stroke();ctx.globalAlpha=1;worldLabel(e.x,e.y-e.r-18,'СЛЕД · '+Math.ceil(e.tr80),'#6b8cff');}
        else if(e.win80>0&&e.win80<90&&e.spawnT<=0){ctx.strokeStyle='#ffffff';ctx.globalAlpha=.7;ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+7,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,e.win80/2));ctx.stroke();ctx.globalAlpha=1;}
        if(e.lr80){for(let i=0;i<e.lr80;i++){ctx.fillStyle='#6b8cff';ctx.beginPath();ctx.arc(e.x-6+i*6,e.y+e.r+7,2,0,TAU);ctx.fill();}}break;
      case 'inverse':if(e.itel>0&&!G.noTele){ctx.strokeStyle='#e86bff';ctx.globalAlpha=.8;ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+40*(e.itel/1),0,TAU);ctx.stroke();ctx.globalAlpha=1;}if(e.iw){ctx.strokeStyle='#e86bff';ctx.globalAlpha=.7*(1-e.iw.r/380);ctx.lineWidth=5;ctx.beginPath();ctx.arc(e.iw.x,e.iw.y,e.iw.r,0,TAU);ctx.stroke();ctx.globalAlpha=1;}break;
      case 'pilgrim':if(!e.hostile80)worldLabel(e.x,e.y-e.r-12,'ПАЛОМНИК','#dfe8ff');break;
      case 'convoybox':worldLabel(e.x,e.y-e.r-12,'НА СПИСАНИЕ','#e8d27a');ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(e.x-24,e.y+e.r+6,48,4);ctx.fillStyle='#e8d27a';ctx.fillRect(e.x-24,e.y+e.r+6,48*Math.max(0,e.hp/e.maxHp),4);break;}}
  // штамп на корабле
  if(G.stamp80&&p.hp>0){const s=G.stamp80,k=s.t/s.max;ctx.strokeStyle='#ff7a3d';ctx.lineWidth=3;ctx.globalAlpha=.9;ctx.beginPath();ctx.arc(p.x,p.y,p.r+12,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();ctx.globalAlpha=1;worldLabel(p.x,p.y-p.r-24,'ПРОВЕРЕНО · '+Math.ceil(s.t)+' · РЫВОК','#ff7a3d');}
  // Изнанка: рамка и значок
  if((G.inv80>0||G.slow80>0)&&p.hp>0){const k=(G.inv80||G.slow80)/2;ctx.strokeStyle='#e86bff';ctx.globalAlpha=.55;ctx.lineWidth=6;ctx.strokeRect(CX+3,CY+3,W-6,H-6);ctx.globalAlpha=1;ctx.lineWidth=2;ctx.beginPath();ctx.arc(p.x,p.y,p.r+16,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();worldLabel(p.x,p.y+p.r+26,G.inv80>0?'⇄ '+G.inv80.toFixed(1):'ЗАМЕДЛЕНИЕ','#e86bff');}
  // спасённая копия
  if(G.res80){const R_=G.res80;ctx.save();ctx.translate(R_.x,R_.y);ctx.rotate(R_.a+Math.PI/2);ctx.strokeStyle='#dfe8ff';ctx.fillStyle='#0b0f18';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(9,0);ctx.lineTo(-6,-6);ctx.lineTo(-3,0);ctx.lineTo(-6,6);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
  // числа урона
  ctx.textAlign='center';ctx.font='700 '+fpx(isMob()?17:12)+'px "JetBrains Mono",monospace';for(const n of G.dmgN80||[]){ctx.globalAlpha=Math.min(1,n.t*2);ctx.fillStyle='#04060c';ctx.fillText(String(Math.round(n.v)),n.x+1,n.y+1);ctx.fillStyle=n.col;ctx.fillText(String(Math.round(n.v)),n.x,n.y);}ctx.globalAlpha=1;
  // снаряды в утечке — иней
  const L=G.world?W80.near:(G.x80&&G.x80.leaks);if(L&&L.length&&SET.fx){ctx.fillStyle='rgba(223,246,255,.35)';for(const b of G.pb)if(leakK80(b.x,b.y)<1){ctx.beginPath();ctx.arc(b.x,b.y,5,0,TAU);ctx.fill();}for(const b of G.eb)if(leakK80(b.x,b.y)<1){ctx.beginPath();ctx.arc(b.x,b.y,b.r+3,0,TAU);ctx.fill();}}}
// мир: пульты, полигон, переплавка, конвой
function w80Draw(t){if(!W80.gen)return;const ws=w80S(),p=G.player;
  for(const q of W80.pults){if(!inView(q.x,q.y,120))continue;const ready=(ws.clk||0)>=(ws.alarmAt[q.i]||0),act=W80.alarm&&W80.alarm.i===q.i,col=act?'#ff4f6e':ready?'#ff7a3d':'#6b7280';
    glow(q.x,q.y,40,col,act?.5+.4*Math.sin(t*12):ready?.35:.12);ctx.save();ctx.translate(q.x,q.y);ctx.fillStyle='#10141c';ctx.strokeStyle=col;ctx.lineWidth=2;ctx.fillRect(-16,-12,32,24);ctx.strokeRect(-16,-12,32,24);ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,6,0,TAU);ctx.fill();
    if(q.ch>0){ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,26,-Math.PI/2,-Math.PI/2+TAU*q.ch/.6);ctx.stroke();}ctx.restore();
    const sub=act?(W80.alarm.st==='count'?'ТРЕВОГА ЧЕРЕЗ '+Math.ceil(W80.alarm.t):'ТРЕВОГА · '+Math.ceil(W80.alarm.t)+' С'):ready?'ВСЕМ ПОСТАМ · ДЕРЖИТЕ 0,6 С':'ПЕРЕЗАРЯДКА · '+fmtMS80((ws.alarmAt[q.i]||0)-(ws.clk||0));worldLabel(q.x,q.y-30,'ПУЛЬТ ТРЕВОГИ',col);worldLabel(q.x,q.y+34,sub,col);}
  const r=W80.range;if(r&&inView(r.x,r.y,r.w)){ctx.strokeStyle='#e8d27a';ctx.globalAlpha=.5;ctx.lineWidth=2;ctx.setLineDash([12,8]);ctx.strokeRect(r.x-r.w/2,r.y-r.h/2,r.w,r.h);ctx.setLineDash([]);ctx.globalAlpha=.08;ctx.fillStyle='#e8d27a';ctx.fillRect(r.x-r.w/2,r.y-r.h/2,r.w,r.h);ctx.globalAlpha=.25;
    for(let i=1;i<4;i++){ctx.beginPath();ctx.moveTo(r.x-r.w/2+i*r.w/4,r.y-r.h/2);ctx.lineTo(r.x-r.w/2+i*r.w/4,r.y+r.h/2);ctx.stroke();}ctx.globalAlpha=1;
    worldLabel(r.x,r.y-r.h/2-30,'СТЕНД ИСПЫТАНИЙ','#e8d27a');worldLabel(r.x,r.y-r.h/2-12,'ПОСЛЕДНЕЕ '+Math.round(W80.last||0)+' · УРОН/С '+(W80.dps||0)+' · РЕКОРД '+(ws.rangeBest||0),'#e8d27a');}
  const m=W80.melt;if(m&&inView(m.x,m.y,200)){glow(m.x,m.y,110,'#ff7a3d',.35+.15*Math.sin(t*2));ctx.strokeStyle='#ff7a3d';ctx.lineWidth=3;ctx.beginPath();ctx.arc(m.x,m.y,60,0,TAU);ctx.stroke();worldLabel(m.x,m.y-80,'ПЕРЕПЛАВКА','#ff7a3d');}
  for(const z of W80.zones){if(!z.active)continue;
    if(z.k80==='convoy'&&z.tug){const T=z.tug;ctx.strokeStyle='#e8d27a';ctx.globalAlpha=.25;ctx.setLineDash([6,10]);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(T.x,T.y);for(let i=T.i;i<T.route.length;i++)ctx.lineTo(T.route[i].x,T.route[i].y);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
      if(inView(T.x,T.y,80)){ctx.save();ctx.translate(T.x,T.y);ctx.rotate(T.ang);ctx.fillStyle='#10141c';ctx.strokeStyle='#c9d2de';ctx.lineWidth=2;ctx.fillRect(-18,-11,36,22);ctx.strokeRect(-18,-11,36,22);ctx.restore();if(z.box&&z.box.alive){ctx.strokeStyle='#c9d2de';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(T.x,T.y);ctx.lineTo(z.box.x,z.box.y);ctx.stroke();}}}
    if(z.k80==='audit'&&z.ap&&!z.alarm&&inView(z.ap.x,z.ap.y,900)){ctx.strokeStyle='#ffd36b';ctx.globalAlpha=.12;ctx.lineWidth=1;ctx.strokeRect(z.home.x-820,z.home.y-520,1640,1040);ctx.globalAlpha=1;}}}
function fmtMS80(s){s=Math.max(0,Math.ceil(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0');}
// карта
function w80MapAdd(add,lod,S){w80Gen();if(!W80.gen)return;for(const q of W80.pults)if(revealedAt(q.x,q.y))add('pult80',q.x,q.y,{},lod===2?{t:'ПУЛЬТ ТРЕВОГИ',p:6,c:'#ff7a3d'}:null);
  if(W80.range&&revealedAt(W80.range.x,W80.range.y))add('range80',W80.range.x,W80.range.y,{},lod===2?{t:'СТЕНД',p:6,c:'#e8d27a'}:null);
  if(W80.melt&&revealedAt(W80.melt.x,W80.melt.y))add('melt80',W80.melt.x,W80.melt.y,{},lod===2?{t:'ПЕРЕПЛАВКА',p:6,c:'#ff7a3d'}:null);}
function w80MapIcon(g,kind,o,t){switch(kind){case 'pult80':g.strokeStyle='#ff7a3d';g.strokeRect(-4,-3,8,6);return true;case 'range80':g.strokeStyle='#e8d27a';g.strokeRect(-6,-4,12,8);g.beginPath();g.moveTo(0,-4);g.lineTo(0,4);g.stroke();return true;case 'melt80':g.strokeStyle='#ff7a3d';g.beginPath();g.arc(0,0,5,0,TAU);g.stroke();return true;}return false;}
// маска отключения света: видно рядом с кораблём, снаряды врагов и вспышки
let c80=null,c80x=null;
function w80Mask(ox,oy){const k0=G.bo80||0;if(k0<=.01||!G.player)return;const lo=isMob()?.5:1;const w_=Math.ceil(cv.width*lo),h_=Math.ceil(cv.height*lo);
  if(!c80||c80.width!==w_||c80.height!==h_){c80=document.createElement('canvas');c80.width=w_;c80.height=h_;c80x=c80.getContext('2d');}
  const g=c80x,k=DPR*SC*lo,p=G.player,R=Math.max(300,Math.min(W,H)*.4);g.globalCompositeOperation='source-over';g.clearRect(0,0,w_,h_);g.fillStyle=`rgba(1,2,7,${((SET.fx?.88:.55)*k0).toFixed(3)})`;g.fillRect(0,0,w_,h_);g.globalCompositeOperation='destination-out';
  const hole=(x,y,r)=>{const X=(x+ox)*k,Y=(y+oy)*k,RR=r*k;if(X<-RR||Y<-RR||X>w_+RR||Y>h_+RR)return;const gr=g.createRadialGradient(X,Y,RR*.35,X,Y,RR);gr.addColorStop(0,'rgba(0,0,0,1)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.beginPath();g.arc(X,Y,RR,0,TAU);g.fill();};
  hole(p.x,p.y,R);let n=0;for(const b of G.eb){if(n>=80)break;hole(b.x,b.y,16);n++;}n=0;for(const s of G.shock){if(n>=24)break;hole(s.x,s.y,Math.max(30,s.r));n++;}
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(c80,0,0,cv.width,cv.height);ctx.restore();}
// рисунки новых врагов (из drawE74; true = нарисован)
function drawE80(e,t,icon,col,face,alpha,P){if(!S80T.has(e.type))return false;const r=e.r;
  switch(e.type){
    case 'labrat':ctx.rotate(face);ctx.beginPath();ctx.arc(0,0,r*.8,0,TAU);ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-r*.5,0);ctx.lineTo(r*.5,0);ctx.moveTo(0,-r*.5);ctx.lineTo(0,r*.5);ctx.stroke();for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(r*.6,s*r*.4);ctx.lineTo(r*1.2,s*r*.8);ctx.stroke();}break;
    case 'defect':{const c=icon?col:(e.mT!==undefined&&e.mT<.5&&Math.sin(t*40)>0?'#ffffff':DEF_COL80[e.mode||'shoot']);ctx.strokeStyle=e.flash>0?'#ffffff':c;ctx.rotate(face+(e.mode==='ram'&&e.aim!==undefined?angDiff(e.aim,face):0));
      ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(r*.2,-r*.9);ctx.lineTo(-r*.7,-r*.5);ctx.lineTo(-r,r*.2);ctx.lineTo(-r*.3,r*.9);ctx.lineTo(r*.5,r*.6);ctx.closePath();ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-r*.3,-r*.4);ctx.lineTo(r*.1,r*.3);ctx.stroke();break;}
    case 'inspector':ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();{const a=icon?0:(e.ca||0);ctx.fillStyle=col;ctx.beginPath();ctx.arc(Math.cos(a)*r*.45,Math.sin(a)*r*.45,r*.35,0,TAU);ctx.fill();ctx.strokeStyle=col;ctx.beginPath();ctx.arc(0,0,r*.65,0,TAU);ctx.stroke();}break;
    case 'railshield':{const a=icon?0:(e.fa||0);ctx.rotate(a);ctx.fillStyle=e.shieldFlash>0?'#ffffff':'#141a26';ctx.fillRect(-6,-30,12,60);ctx.strokeRect(-6,-30,12,60);ctx.strokeStyle=col;ctx.globalAlpha=alpha*.6;for(let i=-2;i<=2;i++){ctx.beginPath();ctx.moveTo(-6,i*11);ctx.lineTo(6,i*11+4);ctx.stroke();}ctx.globalAlpha=alpha;
      if(!icon){ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(-14,-38,28,4);ctx.fillStyle=col;ctx.fillRect(-14,-38,28*Math.max(0,e.hp/e.maxHp),4);}break;}
    case 'stamp':ctx.rotate(t*3);ctx.beginPath();for(let i=0;i<8;i++){const a=i/8*TAU,rr=i%2?r*.6:r;ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,r*.3,0,TAU);ctx.fill();break;
    case 'recycler':{ctx.rotate(face);ctx.beginPath();ctx.moveTo(r,-r*.4);ctx.lineTo(r,r*.4);ctx.lineTo(-r*.8,r*.8);ctx.lineTo(-r,0);ctx.lineTo(-r*.8,-r*.8);ctx.closePath();ctx.fill();ctx.stroke();const n=e.hopper?e.hopper.length:0;ctx.fillStyle='#ffb84d';for(let i=0;i<Math.min(6,Math.ceil(n/2));i++)ctx.fillRect(-r*.6+i*5,-2,3,4);
      ctx.strokeStyle=col;ctx.beginPath();ctx.arc(r*.9,0,r*.35,-1.2,1.2);ctx.stroke();break;}
    case 'echo80':{ctx.globalAlpha=alpha*(.75+.25*Math.sin(t*6+e.seed));ctx.rotate(icon?-Math.PI/2:Math.atan2(P.y-e.y,P.x-e.x));ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(-r*.8,-r*.7);ctx.lineTo(-r*.4,0);ctx.lineTo(-r*.8,r*.7);ctx.closePath();ctx.fill();ctx.stroke();ctx.setLineDash([3,3]);ctx.beginPath();ctx.arc(0,0,r*1.25,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=alpha;break;}
    case 'loop':{if(e.tr80>0&&!icon){ctx.globalAlpha=alpha*.3;}ctx.rotate(t*2*(e.dir||1));ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(-r*.35,0,r*.55,r*.4,0,0,TAU);ctx.stroke();ctx.beginPath();ctx.ellipse(r*.35,0,r*.55,r*.4,0,0,TAU);ctx.stroke();ctx.lineWidth=2;ctx.globalAlpha=alpha;break;}
    case 'inverse':{ctx.rotate(-t*2);ctx.beginPath();ctx.moveTo(0,-r);ctx.lineTo(r,0);ctx.lineTo(0,r);ctx.lineTo(-r,0);ctx.closePath();ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-r*.5,-r*.2);ctx.lineTo(r*.5,-r*.2);ctx.moveTo(r*.5,r*.2);ctx.lineTo(-r*.5,r*.2);ctx.stroke();break;}
    case 'pilgrim':{ctx.rotate(icon?-Math.PI/2:face);ctx.strokeStyle=e.hostile80?'#ff4f6e':col;ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(-r*.8,-r*.7);ctx.lineTo(-r*.4,0);ctx.lineTo(-r*.8,r*.7);ctx.closePath();ctx.fill();ctx.stroke();if(!e.hostile80){glow(0,0,r*1.4,'#dfe8ff',.2);}break;}
    case 'rangedummy':{ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();ctx.beginPath();ctx.arc(0,0,r*.6,0,TAU);ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,r*.22,0,TAU);ctx.fill();break;}
    case 'convoybox':{ctx.fillStyle='#1a1a10';ctx.fillRect(-r,-r*.7,r*2,r*1.4);ctx.strokeRect(-r,-r*.7,r*2,r*1.4);ctx.beginPath();ctx.moveTo(-r,-r*.7);ctx.lineTo(r,r*.7);ctx.moveTo(r,-r*.7);ctx.lineTo(-r,r*.7);ctx.globalAlpha=alpha*.5;ctx.stroke();ctx.globalAlpha=alpha;break;}}
  return true;}
// ===== музыка секторов VII–VIII: «Бюро» и «Исток», тёмные варианты, плавная смена =====
SC_.s6={name:'Предел · бюро',root:41,v:[[0,7,14,17],[-2,5,12,14],[0,7,10,14],[-5,2,7,14]],chordT:[10,16],pad:['sawtooth',360,900,.026],sub:.085,noise:['bandpass',1400,.01,.05],bell:['metal',8,14,.02],rev:.32,alert:1,vol:.7,bpm:96,mech:1};
SC_.s6d={name:'Предел · без света',root:41,v:[[0,7,14,17],[-2,5,12,14]],chordT:[14,20],pad:['triangle',260,520,.03],sub:.1,noise:['lowpass',380,.016,.04],bell:['metal',12,20,.014],rev:.45,alert:1,vol:.66,bpm:96,relay:1};
SC_.s7={name:'Исток · хор',root:36,v:[[0,7,12,19],[5,12,17,24],[-2,5,14,19],[0,7,14,19]],chordT:[14,22],pad:['sine',500,1300,.05],sub:.07,noise:['bandpass',900,.008,.04],bell:['glass',9,15,.022],rev:.62,alert:1,vol:.72,bpm:60,vib:[4.6,9],choir:1};
SC_.s7d={name:'Исток · один голос',root:36,v:[[0,12,19,24]],chordT:[20,30],pad:['sine',420,800,.035],sub:.06,noise:['lowpass',300,.01,.03],bell:['glass',14,22,.016],rev:.7,alert:1,vol:.62,bpm:60,vib:[4.2,7]};
SC_.mx6=Object.assign({},SC_.mx6,{name:'Бой · Предел',root:41,bpm:102,metal:1,heavy:1,mech:1,brass:.03});SC_.mx6d=Object.assign({},SC_.mx6,{name:'Бой · Предел без света',pad:['triangle',260,600,.03],toms:'fight',heavy:0,relay:1,brass:0});
SC_.mx7=Object.assign({},SC_.mx7,{name:'Бой · Исток',root:36,bpm:66,vib:[4.6,9],pulse:'q',brass:.025});SC_.mx7d=Object.assign({},SC_.mx7,{name:'Бой · Исток во тьме',pad:['sine',380,700,.03],brass:0});
function scape80(P,c,t){const S=P.sc;if(!S.vib||!P.pad)return;const l=c.createOscillator();l.frequency.value=S.vib[0];const lg=c.createGain();lg.gain.value=S.vib[1];l.connect(lg);for(const v of P.pad)if(v&&v.o)lg.connect(v.o.detune);vStart(l,t);P.nodes.push(l);}
function step80(P,t,st,bar){const S=P.sc,X=P.ext||{},root=S.root+(P.semi||0);
  if(S.mech&&!X.darkOff){if(st===0||st===6||st===10)evNoise(t,.07,.05,P.L.toms,'lowpass',420);if(st===4||st===12)evNoise(t,.04,.03,P.L.tick,'bandpass',3600,9);if(st===14&&bar%2===0)ev(t,mtof(root+24),.18,'square',.012,P.L.fx,.004);}
  if(S.relay&&st%8===3&&Math.random()<.5)evNoise(t,.02,.03,P.L.tick,'highpass',5200);
  if(S.choir&&st===0&&bar%2===0){const iv=P.chord[Math.random()*P.chord.length|0];ev(t,mtof(root+24+iv),3.2,'sine',.018,P.L.bell,.6,null,rnd(-.5,.5));tonal(t,P.id);}
  if(X.siren&&(st===0||st===8)){ev(t,mtof(root+30),.9,'triangle',.03,P.L.fx,.05,mtof(root+33));}}
const SECSC80=new Set(['s6','s7','s6d','s7d','mx6','mx7','mx6d','mx7d']);
function mus80(T){const st=G.state;if(SECSC80.has(T.id)){if(G.bo80>=.5&&SC_[T.id+'d'])T.id=T.id+'d';}
  if(W80.alarm&&G.world)T.ext.siren=1;
  // гистерезис на границе секторов: новая тема — через 2 с в новом секторе
  if(G.world&&st==='world'&&/^s\d+d?$/.test(T.id)){const base=T.id.replace('d','');const H_=MUS.h80||(MUS.h80={id:base,since:G.t});if(H_.cand!==base){H_.cand=base;H_.since=G.t;}if(base!==H_.id&&G.t-H_.since>=2)H_.id=base;if(base!==H_.id){const keep=H_.id+(T.id.endsWith('d')&&SC_[H_.id+'d']?'d':'');if(SC_[keep])T.id=keep;}}
  return T;}
function fade80(cur,id,fade){if(!cur)return fade;const a=cur.id,b=id;if(SECSC80.has(a)||SECSC80.has(b)){const ba=a.replace(/d$/,''),bb=b.replace(/d$/,'');if(ba===bb)return 3;if(/^s\d+$/.test(ba)&&/^s\d+$/.test(bb))return 6;}return fade;}
// --- миссии VIII: не больше 2 Изнанок за миссию и 1 в волне ---
for(let m=32;m<=38;m++){const M=MISSIONS[m-1];if(!M||!M.wavesT)continue;let n=0;for(const wv of M.wavesT){let k=0;for(let i=0;i<wv.length;i++){if(wv[i]==='inverse'){if(n>=2||k>=1)wv[i]='loop';else{n++;k++;}}}}}
// --- мастерство миссий 28–37 ---
Object.assign(MASTERY,{27:{t:'Порвать луч Лаборанта рывком',ok:()=>!!G.mc&&!!G.mc.beam80},28:{t:'Ни разу не взорваться штампом',ok:()=>!!G.mc&&!G.mc.stampBoom80},29:{t:'Ни разу не вызвать «нарушение регламента»',ok:()=>!!G.mc&&!G.mc.seen80},
  31:{t:'Ни разу не получить от себя же',ok:()=>!!G.mc&&!G.mc.echoHit80},32:{t:'Разорвать все Петли с первого раза',ok:()=>!!G.mc&&(G.mc.loopK80||0)>0&&!G.mc.loopBad80},33:{t:'Ни разу не попасть под волну Изнанки',ok:()=>!!G.mc&&!G.mc.inv80},
  34:{t:'Импульсом стереть память Отзвука',ok:()=>!!G.mc&&!!G.mc.echoWipe80},35:{t:'Не задеть ни одного Паломника',ok:()=>!!G.mc&&!G.mc.pilHit80},36:{t:'Уничтожить 10 врагов в темноте',ok:()=>!!G.mc&&(G.mc.dark80||0)>=10}});
