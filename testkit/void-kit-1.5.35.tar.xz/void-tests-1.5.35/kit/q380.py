# 1.5.10 α «Ровно» · этап 2 (ARCH·70). Сборки: base = 1.5.9 (void_v47), on = кандидат, off = кандидат со всеми флагами A-5…A-13 выключенными.
# Тесты, которые ловят дефекты 1.5.9, обязаны падать на base — это проверяется в самих тестах («base ловит дефект»).
import asyncio,json,sys,os,subprocess
from h import *
from q370 import mission_js,ZB_JS
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
NEW=os.environ.get('GAME_URL','file://@@KIT@@/home/void_c.html')
BASE='file://'+SP+'void_v47.html'
FL=['A-5','A-6','A-7','A-8','A-9','A-10','A-11','A-12','A-13']
OFF70="window.__archOff="+json.dumps(FL)+";"
def offs(*k):return "window.__archOff="+json.dumps(list(k))+";"
SEED="""(()=>{let a=%d;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};})();"""
NORAF="window.requestAnimationFrame=()=>0;"
J=lambda o:json.dumps(o,sort_keys=True,ensure_ascii=False)
async def run_in(b,url,code,init='',w=1280,h=760,touch=False,dsf=None,arg=None):
    P=await newpage(b,w,h,url=url,init=init or None,touch=touch,dsf=dsf);r=await P.js(code,arg);e=P.errs[:3];await P.pg.context.close();return r,e

# ---------- B01 · T2: золотые повторы — base, «вкл» и «выкл» совпадают побитно (12 миссий + бой 50 без HUD) ----------
@test('B01')
async def b01(b):
    res={};ok=True
    for m in [1,2,10,6,14,18,22,27,31,38,42,46]:
        o={k:(await run_in(b,u,mission_js(m,60),i)) for k,u,i in [('base',BASE,''),('on',NEW,''),('off',NEW,OFF70)]}
        s=J(o['base'][0])==J(o['on'][0])==J(o['off'][0]);er=[v[1] for v in o.values() if v[1]];ok&=s and not er
        res[m]=('=' if s else 'DIFF')+(' ОШИБКИ '+str(er) if er else '')
    o={k:(await run_in(b,u,ZB_JS,i)) for k,u,i in [('base',BASE,''),('on',NEW,''),('off',NEW,OFF70)]}
    s=J(o['base'][0])==J(o['on'][0])==J(o['off'][0]);ok&=s;res[50]=('=' if s else 'DIFF')+' стадии '+o['on'][0]['stages'][:80]
    rec('B01 T2/T5: золотые повторы 12 миссий и боя 50 (без HUD) — 1.5.9, «вкл» и «все флаги выкл» совпадают побитно',ok,res)

# ---------- B02 · T3: перепись игрового потока в реальном времени со звуком ----------
CEN=r"""()=>{Error.stackTraceLimit=80;const orig=Math.random;window.__ac={};window.__acOn=false;
 const LEAK=/^(v12Retune|sfx|_sx30|snd\d+|postSnd|noiseBuf\d*|musSched|scapeRun|scapeStep|bell|setChord|newScape|makeImpulse|musInit|audioInit|v12\w*|musicTick|zbMapStatic|zbMini|zbMap)$/;
 const SIM=/^(update|worldUpdate|startMission|enterNode|choose|startWorld|zbStart|prologueTick|zbChoose)$/;
 Math.random=function(){if(window.__acOn&&!window.__harness){const st=(new Error).stack.split('\n').slice(2,70).map(x=>{const m=x.trim().match(/^at (?:Object\.)?([\w$.<>]+)/);return m?m[1]:'?';});
   const ai=st.findIndex(f=>LEAK.test(f)),inSim=st.some(f=>SIM.test(f));if(ai>=0&&!inSim){const k=st[ai];__ac[k]=(__ac[k]||0)+1;}}return orig();};}"""
STEP="()=>{window.__harness=1;try{const p=G.player;if(p&&G.st)p.hp=Math.max(p.hp,G.st.maxHp*.7);let n=0;while(G.state==='levelup'&&n++<60)choose(0);if(G.zb&&G.zb.k==='choice')zbChoose(0);}finally{window.__harness=0;}}"
SCN={'мир':"T.fresh();G.save.tut.off=1;",
     'm02':"T.fresh();G.save.tut.off=1;enterNode(2);if(G.state==='intro')startMission();",
     'бой 50':"T.fresh();G.save.tut.off=1;{const S=G.save;S.cleared=49;for(let k=1;k<50;k++)S.medals[k]={clear:1};}G.zbCool=0;const n=zbNode();G.player.x=n.x-200;G.player.y=n.y;zbStart();"}
async def census(b,url):
    out={}
    # запуск звука: makeImpulse и musInit
    # звук запускается сам через 500 мс после загрузки — перепись ставится до скриптов игры
    P=await newpage(b,1280,760,url=url,init="("+CEN+")();window.__acOn=true;")
    out['запуск звука']=await P.js("async()=>{audioWake();await new Promise(r=>setTimeout(r,1500));window.__acOn=false;return Object.assign({},__ac);}");await P.pg.context.close()
    for name,setup in SCN.items():
        P=await newpage(b,1280,760,url=url);await P.js("async()=>{audioWake();SET.sfx=true;SET.amb=true;await new Promise(r=>setTimeout(r,500));}");await P.js(CEN);await P.js("()=>{"+setup+"}")
        await P.js("()=>{__acOn=true;}")
        for i in range(20):await P.js(STEP);await P.wait(250)
        if name=='бой 50':
            await P.js("()=>{openMap('map');}");await P.wait(1200);await P.js("()=>{closeMap&&closeMap();}")
        out[name]=await P.js("()=>{__acOn=false;return Object.assign({},__ac);}");await P.pg.context.close()
    # эхо рывка после финала (G.post): 40 рывков, ждём отложенное эхо
    P=await newpage(b,1280,760,url=url);await P.js("async()=>{audioWake();SET.sfx=true;await new Promise(r=>setTimeout(r,500));}");await P.js(CEN)
    out['эхо рывка']=await P.js("async()=>{T.fresh();G.save.tut.off=1;G.post={};__acOn=true;for(let i=0;i<40;i++){sfx('dash');await new Promise(r=>setTimeout(r,60));}await new Promise(r=>setTimeout(r,2000));__acOn=false;G.post=null;return Object.assign({},__ac);}");await P.pg.context.close()
    return out
@test('B02')
async def b02(b):
    on=await census(b,NEW);base=await census(b,BASE)
    tot=lambda o:sum(sum(v.values()) for v in o.values())
    caught={k:sum(base[k].values())>0 for k in base}
    rec('B02 T3: со звуком в реальном времени никто вне симуляции не берёт игровой Math.random (звук, эхо, таймер музыки, миникарта 50); на 1.5.9 утечки есть в каждом сценарии',
        tot(on)==0 and all(caught.values()),{'кандидат':on,'1.5.9':{k:sum(v.values()) for k,v in base.items()},'1.5.9 ловит':caught})

# ---------- B03 · T4/T12: симуляция не зависит от презентации (внутри одного размера экрана) ----------
RUN="""(a)=>{const [scn,o]=a;SET.fx=o.fx!==false;G.q=o.q;eval(scn);const p=G.player;let now=1000;
 if(o.mus){audioWake();}
 const lv=()=>{let k=0;while(G.state==='levelup'&&k++<60)choose(0);if(G.zb&&G.zb.k==='choice')zbChoose(0);};
 for(let s=0;s<o.n;s++){lv();if(p&&G.st)p.hp=Math.max(p.hp,G.st.maxHp*.6);now+=1000/60;
   if(o.mus&&s%3===0){try{musSched();}catch(e){}}
   if(G.state==='play'){update(1/60);if(o.pres){render(now);updateHUD();}}
   else if(G.state==='world'){p.vx=Math.cos(s/90)*200;p.vy=Math.sin(s/70)*150;worldUpdate(1/60);if(o.pres){renderWorld(now);updateWorldHUD();}if(o.map&&s%30===0){try{if(typeof zbMap==='function'&&zbOn())zbMap();else drawMap();}catch(e){}}}}
 const E=(G.enemies||[]).filter(e=>e.alive);const r=x=>Math.round(x*1000)/1000;
 return {st:G.state,t:r(G.t||0),p:p?[r(p.x),r(p.y),r(p.hp)]:null,n:E.length,ex:r(E.reduce((s,e)=>s+e.x+e.y*3+e.hp*7,0)),kills:G.kills||0,zb:G.zb?G.zb.k:null,next:Math.random()};}"""
PSCN={'m10':"T.fresh();G.save.tut.off=1;{const S=G.save;S.cleared=9;for(let k=1;k<10;k++)S.medals[k]={clear:1};}G.layoutSeed=5;G.keepLayout=true;enterNode(10);if(G.state==='intro')startMission();",
      'm46':"T.fresh();G.save.tut.off=1;{const S=G.save;S.cleared=45;for(let k=1;k<46;k++)S.medals[k]={clear:1};}G.layoutSeed=5;G.keepLayout=true;enterNode(46);if(G.state==='intro')startMission();",
      'мир':"T.fresh();G.save.tut.off=1;",
      'бой 50':SCN['бой 50']}
VARS=[('чистая симуляция',dict(pres=0,q=2),None),('отрисовка+HUD, качество 2',dict(pres=1,q=2),None),('отрисовка+HUD, качество 0',dict(pres=1,q=0),None),
      ('отрисовка+HUD, DPR 2',dict(pres=1,q=2),2),('HUD + карта',dict(pres=1,q=2,map=1),None),('таймер музыки',dict(pres=0,q=2,mus=1),None)]
async def pres_inv(b,url,scn,vp,n=1500):
    w,h,touch=vp;res={}
    for label,o,dsf in VARS:
        o=dict(o,n=n);r,e=await run_in(b,url,RUN,SEED%777+NORAF,w,h,touch,dsf if not touch else (3 if dsf else None),[PSCN[scn],o]);res[label]=r if not e else {'err':e}
    v=list(res.values());same=all(J(x)==J(v[0]) for x in v);return same,res
@test('B03')
async def b03(b):
    out={};ok=True;base_fail=[]
    for vpn,vp in [('ПК',(1280,760,False)),('телефон',(390,844,True))]:
        for scn in PSCN:
            s,r=await pres_inv(b,NEW,scn,vp);ok&=s
            sb,rb=await pres_inv(b,BASE,scn,vp)
            if not sb:base_fail.append(vpn+' '+scn)
            out[vpn+' '+scn]='кандидат '+('=' if s else 'РАСХОДИТСЯ: '+J({k:(x.get('next') if isinstance(x,dict) else x) for k,x in r.items()})[:300])+' · 1.5.9 '+('=' if sb else 'расходится')
            print('   ',vpn,scn,out[vpn+' '+scn],flush=True)
    ok&=any('бой 50' in x for x in base_fail)
    rec('B03 T4/T12: внутри одного размера экрана (ПК и телефон отдельно) отрисовка, HUD, качество, DPR, карта и таймер музыки не меняют симуляцию; на 1.5.9 тест ловит дефект (бой 50, таймер музыки)',ok,{'итог':out,'1.5.9 падает в':base_fail})

# ---------- B04 · T6: время ржавого контейнера через настоящий frame(now) ----------
RUST="""(a)=>{const [hz,jit,o]=a;T.fresh();G.save.tut.off=1;if(G.prologue)prologueEnd();for(let i=0;i<5;i++)worldUpdate(1/60);
 const f=W58.rust.find(q=>q.box);const ws=w58S();const p=G.player;
 if(o.fps30){SET.fps=30;}let t=10000;frame(t);t+=1000;frame(t);p.x=f.x;p.y=f.y;p.vx=p.vy=0;f.rep=0;let sim=0,sx=0;const step=1000/hz;let seed=12345;const rj=()=>{seed=(seed*1103515245+12345)%2147483648;return seed/2147483648;};
 const tick=(dtms)=>{t+=dtms;const st=G.state;frame(t);p.x=f.x;p.y=f.y;p.vx=p.vy=0;if(G.st)p.hp=Math.max(p.hp,G.st.maxHp*.9);};
 let paused=null,hid=null;
 for(let i=0;i<20000&&!ws.rustBox.includes(f.id);i++){const d=step+(jit?(rj()-.5)*2*jit:0);
   if(o.pause&&!paused&&f.rep>=1.5){pause();const r0=f.rep;for(let k=0;k<600;k++)tick(step);paused={st:G.state,same:f.rep===r0};resume();}
   if(o.hide&&!hid&&f.rep>=1.5){Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'));const st=G.state,r0=f.rep;t+=30000;
     Object.defineProperty(document,'hidden',{configurable:true,get:()=>false});resume();const r1=f.rep;tick(step);hid={st,jump:+(f.rep-r1).toFixed(4),held:r1===r0};}
   const before=G.state;tick(d);if(before==='world'&&G.state==='world')sim+=d/1000;}
 return {open:ws.rustBox.includes(f.id),sim:+sim.toFixed(3),paused,hid,mob:isMob(),poiDt:ARCH.poiDt===undefined?'нет':ARCH.poiDt};}"""
@test('B04')
async def b04(b):
    rates=[(30,0),(60,0),(90,0),(120,0),(144,0),(240,0),(60,2)]
    out={'кандидат':{},'1.5.9':{},'кандидат, A-9 выкл':{}};ok=True
    S4='ARCH·73' in open(NEW.replace('file://',''),encoding='utf8').read()  # этап 4: при A-20 шаг и так фиксирован, откат A-9 проверяется на старом цикле
    if S4:out['кандидат, A-9 выкл, A-20 вкл']={}
    for url,key,init in [(NEW,'кандидат',''),(BASE,'1.5.9',''),(NEW,'кандидат, A-9 выкл',offs('A-9','A-20') if S4 else offs('A-9'))]+([(NEW,'кандидат, A-9 выкл, A-20 вкл',offs('A-9'))] if S4 else []):
        for hz,jit in rates:
            r,e=await run_in(b,url,RUST,NORAF+init,arg=[hz,jit,{}]);out[key][f'{hz} Гц'+(f' ±{jit} мс' if jit else '')]=r['sim'] if r['open'] else 'не вскрыт'
            if e:ok=False;print('ERR',e)
        r,e=await run_in(b,url,RUST,NORAF+init,390,844,True,arg=[60,0,{'fps30':1}]);out[key]['телефон, 30 кадров']=r['sim'] if r['open'] else 'не вскрыт'
    c=out['кандидат'];ok&=all(isinstance(v,(int,float)) and abs(v-3.0)<=0.06 for v in c.values())
    bs=out['1.5.9'];ok&=abs(bs['120 Гц']-1.5)<.06 and abs(bs['30 Гц']-6.0)<.1   # дефект виден на 1.5.9
    off=out['кандидат, A-9 выкл'];ok&=J(off)==J(bs)
    if S4:ok&=all(isinstance(v,(int,float)) and abs(v-3.0)<=0.06 for v in out['кандидат, A-9 выкл, A-20 вкл'].values())
    rp,_=await run_in(b,NEW,RUST,NORAF,arg=[60,0,{'pause':1}]);rh,_=await run_in(b,NEW,RUST,NORAF,arg=[60,0,{'hide':1}])
    pz=rp['open'] and rp['paused']['same'] and rp['paused']['st']=='pause' and abs(rp['sim']-3.0)<=.06
    hd=rh['open'] and rh['hid']['st']=='pause' and rh['hid']['held'] and rh['hid']['jump']<=.0501 and abs(rh['sim']-3.0)<=.06
    ok&=pz and hd and rp['poiDt'] is None
    rec('B04 T6: контейнер вскрывается за 3,00 ± 0,06 с игрового времени при 30–240 Гц, с дрожанием и в телефонном режиме 30 кадров; пауза и сворачивание не двигают прогресс, после возврата ≤ 0,05 с; на 1.5.9 — 1,5 с при 120 Гц и 6 с при 30 Гц; с выключенным A-9 — как 1.5.9',
        ok,{**out,'пауза':rp,'сворачивание':rh})

# ---------- B05 · A-9: безопасность ARCH.poiDt и побитовое равенство при 60 Гц ----------
@test('B05')
async def b05(b):
    code="""()=>{T.fresh();G.save.tut.off=1;if(G.prologue)prologueEnd();const f=W58.rust.find(q=>q.box);const p=G.player;const seq=[];
      for(let i=0;i<240;i++){p.x=f.x;p.y=f.y;p.vx=p.vy=0;worldUpdate(1/60);seq.push(f.rep);}
      const out={seq:seq.map(x=>x.toString()).join(','),open:w58S().rustBox.includes(f.id)};
      if(typeof arch70POI!=='function')return out;
      const orig=w58POI;let thrown=false;w58POI=function(){throw new Error('проба');};try{updatePOI(.02);}catch(e){thrown=true;}out.afterThrow=ARCH.poiDt;out.thrown=thrown;
      w58POI=function(card){if(card==='inner'){out.innerDt=arch70Dt();return card;}out.outerSeen=arch70Dt();arch70POI('inner',.5);out.outerAfterNested=arch70Dt();return card;};
      arch70POI(null,.02);out.final=ARCH.poiDt;w58POI=orig;
      out.bad=[NaN,Infinity,-1,'x',undefined].map(d=>{ARCH.poiDt=d;const v=arch70Dt();ARCH.poiDt=null;return v===1/60;});return out;}"""
    on,e1=await run_in(b,NEW,code);base,e2=await run_in(b,BASE,code)
    ok=on['seq']==base['seq'] and on['open']==base['open'] and on['thrown'] and on['afterThrow'] is None and on['innerDt']==.5 and on['outerSeen']==.02 and on['outerAfterNested']==.02 and on['final'] is None and all(on['bad']) and not e1
    rec('B05 A-9: при worldUpdate(1/60) прогресс контейнера побитно как в 1.5.9; после исключения ARCH.poiDt восстановлен; вложенный вызов видит свой шаг и возвращает внешний; NaN, ∞, отрицательный и нечисловой шаг → 1/60',
        ok,{k:v for k,v in on.items() if k!='seq'}|{'seq равны':on['seq']==base['seq'],'вскрыт за 240 шагов':on['open']})

# ---------- B06 · T7: предохранитель, классификация сбоев, void_diag ----------
FAULT="""(a)=>{const [mode]=a;const toasts=[];const t0=toast;toast=function(t){toasts.push(t);return t0.apply(this,arguments);};
 localStorage.removeItem('void_diag');let t=10000;const fr=n=>{for(let i=0;i<n;i++){t+=16.7;frame(t);}};const out={};
 const go=m=>{T.fresh();G.save.tut.off=1;if(G.prologue)prologueEnd();enterNode(m);if(G.state==='intro')startMission();let k=0;while(G.state==='levelup'&&k++<60)choose(0);frame(t);};
 if(mode==='sim'){go(2);const u=update;update=function(){throw new Error('сбой симуляции');};fr(31);out.st1=G.state;out.d1=JSON.parse(localStorage.getItem('void_diag')||'null');resume();fr(31);out.st2=G.state;out.trips=ARCH.trips;update=u;}
 if(mode==='hud'){go(2);const h=updateHUD;const mT=G.mT;updateHUD=(typeof arch70Hud==='function'?arch70Hud:(f=>f))(function(){throw new Error('сбой HUD');});fr(60);out.st=G.state;out.adv=G.mT>mT+.5;out.d=JSON.parse(localStorage.getItem('void_diag')||'null');updateHUD=h;}
 if(mode==='outside'){go(2);const h=updateHUD;updateHUD=arch70Hud(function(){throw new Error('HUD вне кадра');});try{updateHUD();}catch(e){}updateHUD=h;
   const u=update;update=function(){throw new Error('сбой симуляции');};fr(31);out.st=G.state;out.d=JSON.parse(localStorage.getItem('void_diag')||'null');update=u;}
 if(mode==='nested'){go(2);const h=updateHUD;const inner=arch70Hud(function(){throw new Error('внутренний HUD');});updateHUD=arch70Hud(function(){try{inner();}catch(e){}});
   const u=update;update=function(){throw new Error('сбой симуляции');};fr(31);out.st=G.state;out.d=JSON.parse(localStorage.getItem('void_diag')||'null');update=u;updateHUD=h;}
 if(mode==='first'){go(2);const u=update;update=function(){throw new Error('серия');};fr(10);out.mid=!!ARCH.first;update=u;fr(1);out.after=ARCH.first;out.err=ARCH.err;}
 if(mode==='zb'){T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=49;for(let k=1;k<50;k++)S.medals[k]={clear:1};G.zbCool=0;const n=zbNode();G.player.x=n.x-200;G.player.y=n.y;zbStart();frame(t);
   const w=worldUpdate;worldUpdate=function(){throw new Error('сбой мира');};fr(31);out.st=G.state;out.d=JSON.parse(localStorage.getItem('void_diag')||'null');worldUpdate=w;}
 if(mode==='hangar'){go(2);ARCH.err=12;G.state='hangar';arch69Fault(new Error('ангар'));out.err=ARCH.err;out.first=ARCH.first;}
 out.toasts=toasts.filter(x=>x==='СБОЙ В ИГРЕ').length;toast=t0;return out;}"""
@test('B06')
async def b06(b):
    r={};
    for m in ['sim','hud','outside','nested','first','zb','hangar']:
        x,e=await run_in(b,NEW,FAULT,NORAF,arg=[m]);r[m]=x   # ошибки консоли здесь ожидаемы: сбои вносятся намеренно
    bh,_=await run_in(b,BASE,FAULT,NORAF,arg=['hud']);bs,_=await run_in(b,BASE,FAULT,NORAF,arg=['sim'])
    fo,_=await run_in(b,NEW,FAULT,NORAF+offs('A-10','A-12','A-13'),arg=['sim'])
    s=r['sim'];d=s['d1'] or {}
    c1=s['st1']=='pause' and s['st2']=='pause' and s['trips']==2 and s['toasts']==1 and d.get('stage')=='sim' and d.get('m')==2 and d.get('mode')=='world' and d.get('v')==2 and d.get('world') is False
    h=r['hud'];c2=h['st']=='play' and h['adv'] and (h['d'] or {}).get('stage')=='hud' and h['toasts']==0 and bh['st']=='pause'
    c3=r['outside']['st']=='pause' and (r['outside']['d'] or {}).get('stage')=='sim'
    c4=r['nested']['st']=='pause' and (r['nested']['d'] or {}).get('stage')=='sim'
    c5=r['first']['mid'] and r['first']['after'] is None and r['first']['err']==0
    z=r['zb']['d'] or {};c6=r['zb']['st']=='pause' and z.get('zb') is not None and z.get('m') is None and z.get('world') is True
    c7=r['hangar']['err']==0
    fd=fo['d1'] or {};c8=fd.get('m') is None and 'v' not in fd and fo['toasts']==2 and (bs['d1'] or {}).get('m') is None
    rec('B06 T7: сбой симуляции → пауза через 30 кадров, сообщение один раз, void_diag с номером миссии/режимом/стадией боя 50; сбой только HUD → игра идёт, одна запись stage:hud (1.5.9 ставил паузу); HUD вне кадра и вложенный HUD не выдают сбой симуляции за сбой HUD; ARCH.first сброшен после восстановления; ангар сбрасывает счётчик; с выключенными A-10/12/13 — формат и поведение 1.5.9',
        all([c1,c2,c3,c4,c5,c6,c7,c8]),{'сим':c1,'hud':c2,'вне кадра':c3,'вложенный':c4,'first':c5,'бой 50':c6,'ангар':c7,'флаги выкл':c8,'diag':d,'diag hud':h.get('d'),'diag 50':z})

# ---------- B07 · A-11: нечитаемое сохранение при переполненном хранилище ----------
QUOTA="(()=>{const s0=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(String(k).indexOf('void_world_bad')===0){const e=new Error('quota');e.name='QuotaExceededError';throw e;}return s0.apply(this,arguments);};})();"
RAW='{"v":3,"cleared":7,"oops'
async def page_with(b,url,items,init=''):
    P=await newpage(b,1280,760,url=url,init=init or None)
    await P.js("(it)=>{localStorage.clear();for(const k in it)localStorage.setItem(k,it[k]);}",items);await P.pg.reload();await P.wait(400);return P
STATE="()=>({lock:!!(window.ARCH&&ARCH.lock),panel:!!document.getElementById('bak70'),vis:!!(document.getElementById('bak70')&&!document.getElementById('bak70').hidden),bad:Object.keys(localStorage).filter(k=>k.indexOf('void_world_bad')===0).sort(),raw:localStorage.getItem('void_world'),save:!!G.save})"
NEWGAME="()=>{startWorld(true);if(G.prologue)prologueEnd();G.save.lom=777;saveWorld();return {real:localStorage.getItem('void_world'),ls:LS.getItem('void_world'),pers:LS.persisted('void_world'),where:saveWhere()};}"
@test('B07')
async def b07(b):
    r={}
    # 1. обычное хранилище: копия откладывается, защиты нет
    P=await page_with(b,NEW,{'void_world':RAW});r['обычное']=await P.js(STATE);await P.pg.context.close()
    # 2. переполнение: защита, новая игра не трогает старую запись, экспорт, отказ с подтверждением, перезагрузка
    P=await page_with(b,NEW,{'void_world':RAW},QUOTA);s0=await P.js(STATE);ng=await P.js(NEWGAME)
    await P.js("()=>{toMenu();}");await P.wait(600);vis=await P.js(STATE)
    async with P.pg.expect_download() as dl:
        await P.pg.click('#bak70 [data-b70="exp"]')
    d=await dl.value;path=await d.path();content=open(path,encoding='utf8').read();fname=d.suggested_filename
    await P.pg.click('#bak70 [data-b70="drop"]');mid=await P.js(STATE)
    await P.pg.click('#bak70 [data-b70="drop"]');after=await P.js(STATE)
    await P.pg.reload();await P.wait(500);rel=await P.js("()=>({save:!!G.save,lom:G.save&&G.save.lom,lock:!!ARCH.lock})")
    r['переполнение']={'загрузка':s0,'новая игра':{k:(v[:40] if isinstance(v,str) else v) for k,v in ng.items()},'старая цела':ng['real']==RAW,'в меню':vis,'файл':fname,'файл = запись':content==RAW,'после 1 клика':mid['lock'],'после 2 кликов':after,'после перезагрузки':rel,'ошибки':P.errs[:3]}
    await P.pg.context.close()
    # 3. уже три отложенные копии другой записи → четвёртую не создаём, защита
    P=await page_with(b,NEW,{'void_world':RAW,'void_world_bad':'a','void_world_bad_1':'b','void_world_bad_2':'c'});r['три копии']=await P.js(STATE);await P.pg.context.close()
    # 4. та же запись уже отложена → ничего не делаем
    P=await page_with(b,NEW,{'void_world':RAW,'void_world_bad_5':RAW});r['уже отложена']=await P.js(STATE);await P.pg.context.close()
    # 5. localStorage недоступен совсем
    NOLS="Object.defineProperty(window,'localStorage',{configurable:true,get(){throw new Error('denied');}});"
    P=await newpage(b,1280,760,url=NEW,init=NOLS,clear=False)
    r['хранилище недоступно']={'ошибки':P.errs[:3],'lock':await P.js("()=>!!ARCH.lock"),'save':await P.js("()=>!!G.save")};await P.pg.context.close()
    P=await newpage(b,1280,760,url=BASE,init=NOLS,clear=False);r['хранилище недоступно']['ошибки 1.5.9']=P.errs[:3];await P.pg.context.close()
    # 6. 1.5.9 и кандидат с выключенным A-11 при переполнении: старая запись молча перезаписывается (дефект)
    P=await page_with(b,BASE,{'void_world':RAW},QUOTA);bng=await P.js(NEWGAME);await P.pg.context.close()
    P=await page_with(b,NEW,{'void_world':RAW},QUOTA+offs('A-11'));fng=await P.js(NEWGAME);await P.pg.context.close()
    r['1.5.9 перезаписал']=bng['real']!=RAW;r['A-11 выкл перезаписал']=fng['real']!=RAW
    o=r['обычное'];q=r['переполнение'];t=r['три копии'];u=r['уже отложена']
    ok=(not o['lock'] and o['bad']==['void_world_bad'] and o['raw']==RAW
        and s0['lock'] and s0['panel'] and q['старая цела'] and ng['pers'] is False and ng['where']=='ВКЛАДКА' and json.loads(ng['ls'])['lom']==777
        and vis['vis'] and q['файл = запись'] and mid['lock'] and not after['lock'] and not after['panel'] and json.loads(after['raw'])['lom']==777 and rel['save'] and rel['lom']==777 and not q['ошибки']
        and t['lock'] and len(t['bad'])==3 and not u['lock'] and u['bad']==['void_world_bad_5']
        and len(r['хранилище недоступно']['ошибки'])==len(r['хранилище недоступно']['ошибки 1.5.9']) and not r['хранилище недоступно']['lock']
        and r['1.5.9 перезаписал'] and r['A-11 выкл перезаписал'])
    rec('B07 A-11: при переполнении старая запись не перезаписывается, прогресс живёт во вкладке («ВКЛАДКА»), запись скачивается файлом байт в байт, отказ — только вторым нажатием, после него прогресс сохраняется и читается после перезагрузки; три копии → защита; та же копия → ничего; без хранилища — без ошибок; 1.5.9 и A-11 выкл — перезаписывают (дефект)',ok,r)

# ---------- B08 · T8: совместимость сохранений в обе стороны ----------
@test('B08')
async def b08(b):
    mk="""()=>{T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=12;for(let k=1;k<=12;k++)S.medals[k]={clear:1};S.lom=4321;enterNode(2);if(G.state==='intro')startMission();for(let i=0;i<600;i++){let k=0;while(G.state==='levelup'&&k++<60)choose(0);if(G.state!=='play')break;update(1/60);}
      saveWorld();const o={};for(const k of Object.keys(localStorage))o[k]=localStorage.getItem(k);return o;}"""
    res={}
    for src,dst,name in [(NEW,BASE,'кандидат → 1.5.9'),(BASE,NEW,'1.5.9 → кандидат')]:
        dump,_=await run_in(b,src,mk)
        P=await newpage(b,1280,760,url=dst);await P.js("(it)=>{localStorage.clear();for(const k in it)localStorage.setItem(k,it[k]);}",dump);await P.pg.reload();await P.wait(400)
        g=await P.js("()=>G.save?JSON.stringify(migrateSave(JSON.parse(localStorage.getItem('void_world')))):null");lock=await P.js("()=>!!(window.ARCH&&ARCH.lock)");er=P.errs[:2];await P.pg.context.close()
        P=await newpage(b,1280,760,url=src);await P.js("(it)=>{localStorage.clear();for(const k in it)localStorage.setItem(k,it[k]);}",dump);await P.pg.reload();await P.wait(400)
        g0=await P.js("()=>G.save?JSON.stringify(migrateSave(JSON.parse(localStorage.getItem('void_world')))):null");await P.pg.context.close()
        res[name]={'прочитано':g is not None,'совпадает':g==g0,'защита':lock,'ошибки':er,'ключи':sorted(dump.keys())}
    # фикстуры этапа 1: все читаются так же, как в 1.5.9
    fx=json.load(open(SP+'fixtures_v46.json'))['raw'];fxr={}
    for name,raw in fx.items():
        vals=[]
        for u in (BASE,NEW):
            P=await newpage(b,1280,760,url=u);await P.js("(r)=>{localStorage.clear();localStorage.setItem('void_world',r);}",raw);await P.pg.reload();await P.wait(300)
            vals.append(await P.js("()=>G.save?JSON.stringify(G.save):null"));await P.pg.context.close()
        fxr[name]=vals[0]==vals[1]
    ok=all(v['прочитано'] and v['совпадает'] and not v['защита'] and not v['ошибки'] for v in res.values()) and all(fxr.values())
    rec('B08 T8: сохранение кандидата читается 1.5.9 и наоборот (G.save совпадает после миграции); фикстуры этапа 1 читаются одинаково',ok,{**res,'фикстуры':f'{sum(fxr.values())}/{len(fxr)}','расхождения':[k for k,v in fxr.items() if not v]})

# ---------- B09 · T13: режимы игры в реальном времени со звуком ----------
MODES={'кампания m02':"T.fresh();G.save.tut.off=1;enterNode(2);if(G.state==='intro')startMission();",
 'мир, ржавое поле':"T.fresh();G.save.tut.off=1;const f=W58.rust.find(q=>q.box);G.player.x=f.x;G.player.y=f.y;",
 'бой 50':SCN['бой 50'],
 'бесконечный':"T.fresh();G.save.tut.off=1;startEndless();if(G.state==='intro')startMission();",
 'бесконечный, lowFx':"T.fresh();G.save.tut.off=1;startEndless();if(G.state==='intro')startMission();G.lowFx=true;",
 'разработчик + зерно':"T.fresh();G.save.tut.off=1;try{G.dev.seedOn=1;G.dev.seed=4242;}catch(e){}devStart(3);if(G.state==='intro')startMission();try{dvSeedOn(true);}catch(e){}",
 'после финала':"T.fresh();G.save.tut.off=1;postEnter();if(G.state==='intro')startMission();",
 'пролог':"T.fresh();G.save.tut.off=1;prologueStart(true);",
 'обучение':"localStorage.removeItem('void_world');startWorld(true);if(G.prologue)prologueEnd();"}
@test('B09')
async def b09(b):
    res={};ok=True
    for name,setup in MODES.items():
        P=await newpage(b,1280,760,url=NEW);await P.js("async()=>{audioWake();SET.sfx=true;await new Promise(r=>setTimeout(r,400));}");await P.js(CEN)
        try:await P.js("()=>{"+setup+"}")
        except Exception as e:res[name]={'вход':str(e)[:120]};ok=False;await P.pg.context.close();continue
        await P.js("()=>{__acOn=true;}")
        for i in range(48):
            await P.js(STEP)
            if name=='после финала' and i%4==0:await P.js("()=>{try{if(G.post)sfx('dash');}catch(e){}}")
            await P.wait(250)
        r=await P.js("()=>{__acOn=false;const S=G.save;let rt=null;try{saveWorld&&G.world&&saveWorld();const v=JSON.parse(localStorage.getItem('void_world')||'null');rt=!!v&&!!migrateSave(v);}catch(e){rt='ошибка '+e.message;}return {st:G.state,mode:G.mode,post:!!G.post,leak:Object.assign({},__ac),save:rt,trips:ARCH.trips,pdt:ARCH.poiDt};}")
        r['ошибки']=P.errs[:3];res[name]=r;ok&=not r['ошибки'] and sum(r['leak'].values())==0 and r['trips']==0 and r['pdt'] is None
        print('   ',name,json.dumps(r,ensure_ascii=False)[:200],flush=True);await P.pg.context.close()
    rec('B09 T13: девять режимов и состояний по 12 с со звуком — без ошибок консоли, без утечек игрового потока, без срабатываний предохранителя',ok,res)

# ---------- B10 · T1: статика — изменены ровно ожидаемые цепочки, новых владельцев G нет ----------
@test('B10')
async def b10(b):
    env=dict(os.environ,ARCHCHECK_V2='1');html=NEW.replace('file://','')
    AL='arch_allow_70_74.json' if 'ARCH·73' in open(html,encoding='utf8').read() else 'arch_allow_70.json'  # этап 4: заявленные A-20/A-21
    r=subprocess.run(['python3',SP+'archcheck.py','diff',SP+'arch_fp_v47v2.json',html,SP+AL],capture_output=True,text=True,env=env)
    r0=subprocess.run(['python3',SP+'archcheck.py','diff',SP+'arch_fp_v47v2.json',html],capture_output=True,text=True,env=env)
    v=json.loads(r0.stdout)['violations'];want=sorted(json.load(open(SP+AL))['chains'])
    if AL=='arch_allow_70_74.json':  # этап 4: владельцы зоны v74 (frame74/step74) заявлены отдельно; цепочки сравниваются как прежде
        decl={tuple(o) for o in json.load(open(SP+AL))['owners']};got=sorted(x[1] for x in v if x[0]=='chain')
        if any(x[0]!='chain' and (x[1],x[2]) not in decl for x in v):got=got+['незаявленный владелец']
    else:got=sorted(x[1] for x in v)
    s=open(html,encoding='utf8').read();i=s.index('<script>\n"use strict";');j=s.index('</script>',i);js=s[i:j]
    newgen=[n for n in ['xorshift','mulberry(','0x6D2B79F5'] if js.count(n)!=open(SP+'void_v47.html',encoding='utf8').read().count(n)]
    rec('B10 T1: archcheck — изменены ровно 8 ожидаемых цепочек (sfx, zbMapStatic, musSched, v12Retune, makeImpulse, три HUD), новых владельцев G нет, новых генераторов нет',r.returncode==0 and got==want and not newgen,{'нарушения':v,'новые генераторы':newgen})

# ---------- B11 · A-11: экспорт в просмотрщике артефактов (возможность downloads) и честные исходы ----------
CAP="window.claude={use:async(n)=>n==='downloads'?{save:async(r)=>{window.__saved={f:r.filename,d:String(r.data)};if(window.__decline){const e=new Error('no');e.code='declined';throw e;}return {status:'saved'};}}:null};"
@test('B11')
async def b11(b):
    out={}
    for name,extra in [('принято',''),('отклонено','window.__decline=1;')]:
        P=await page_with(b,NEW,{'void_world':RAW},QUOTA+CAP+extra)
        await P.js("()=>{toMenu();}");await P.wait(600)
        await P.pg.click('#bak70 [data-b70="exp"]');await P.wait(400)
        out[name]=await P.js("()=>({saved:window.__saved?{f:window.__saved.f,same:window.__saved.d===localStorage.getItem('void_world')}:null,toast:$('#toastT').textContent,lock:!!ARCH.lock})");out[name]['ошибки']=P.errs[:2];await P.pg.context.close()
    a,d=out['принято'],out['отклонено']
    ok=a['saved'] and a['saved']['same'] and a['saved']['f'].endswith('.txt') and a['toast']=='ЗАПИСЬ СКАЧАНА' and a['lock'] and d['toast']=='СКАЧИВАНИЕ ОТМЕНЕНО' and d['lock'] and not a['ошибки'] and not d['ошибки']
    rec('B11 A-11: в просмотрщике claude.ai запись уходит через downloads.save байт в байт (.txt), «принято» → «ЗАПИСЬ СКАЧАНА», «отклонено» → «СКАЧИВАНИЕ ОТМЕНЕНО»; защита остаётся в обоих случаях',ok,out)

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or t[0] in sel],'res380.json'))
