# 1.1.1 α «Стекло»: приёмка редизайна оболочки по мета-промпту. Каждый тест падает на сборке 1.1.0 (версия 18).
import asyncio,json,sys,os,re
from h import *
from qa1000 import SCREENS_JS
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
VIS="""const vis=e=>{if(!e||e.closest('.sr'))return false;if(e.offsetParent===null&&getComputedStyle(e).position!=='fixed')return false;const r=e.getBoundingClientRect();if(r.width<1||r.height<1)return false;
  let x=e;while(x&&x.nodeType===1){const cs=getComputedStyle(x);if(cs.visibility==='hidden'||cs.display==='none')return false;x=x.parentElement;}return true;};"""

@test('U01')
async def u01(b):
    # фон экранов плотный: игра не просвечивает сквозь текст (кроме главного меню, где за ним — заставка)
    P=await newpage(b)
    r=await P.js("()=>{"+SCREENS_JS+"""const out={};const al=s=>{const a=[...s.matchAll(/rgba?\\(([^)]+)\\)/g)].map(m=>{const v=m[1].split(',').map(Number);return v.length>3?v[3]:1;});return a.length?Math.min(...a):0;};
      for(const [nm,f] of SCR){if(nm==='menu'||nm==='menu_save'||nm==='dev')continue;try{f();}catch(e){out[nm]='EXC';continue;}
        const s=[...document.querySelectorAll('section.screen')].find(e=>!e.hidden&&e.id!=='fsCard');if(!s)continue;const cs=getComputedStyle(s);
        const a=cs.backgroundImage!=='none'?al(cs.backgroundImage):al(cs.backgroundColor);out[nm+':'+s.id]=Math.round(a*100)/100;}return out;}""")
    bad={k:v for k,v in r.items() if v=='EXC' or v<.86}
    rec('U01 экраны поверх игры непрозрачны не меньше чем на 86% по всей ширине',not bad and len(r)>=12,{'bad':bad,'n':len(r),'errs':P.errs[:2]})

@test('U02')
async def u02(b):
    # текст оболочки не мельче 12 px (клавиши-подсказки — 11 px) на ПК и на телефоне
    out={}
    for tag,vw,vh,touch in [('pc',1280,800,False),('pp',390,844,True),('pl',844,390,True)]:
        P=await newpage(b,vw=vw,vh=vh,touch=touch)
        if touch:await P.js("()=>{setInput('touch');}")
        r=await P.js("()=>{"+SCREENS_JS+VIS+"""const bad=[];let n=0;for(const [nm,f] of SCR){if(nm==='dev')continue;try{f();}catch(e){continue;}
          const roots=[...document.querySelectorAll('section.screen')].filter(e=>!e.hidden&&e.id!=='fsCard');for(const id of ['hud','wcard','toast','banner'])if(!$('#'+id).hidden)roots.push($('#'+id));
          for(const R of roots)for(const el of R.querySelectorAll('*')){if(!vis(el))continue;if(![...el.childNodes].some(t=>t.nodeType===3&&t.textContent.trim()))continue;n++;
            const fs=parseFloat(getComputedStyle(el).fontSize),kb=el.tagName==='KBD'||el.closest('kbd');if(fs<(kb?11:12))bad.push(nm+':'+fs+':'+el.textContent.trim().slice(0,24));}}
          return {bad:[...new Set(bad)],n};}""")
        out[tag]=r
    bad={k:v['bad'][:6] for k,v in out.items() if v['bad']}
    rec('U02 текст не мельче 12 px (кнопки-клавиши 11 px) на ПК, в книжной и альбомной',not bad and all(v['n']>500 for v in out.values()),{'bad':bad,'n':{k:v['n'] for k,v in out.items()}})

@test('U03')
async def u03(b):
    # единые токены и компоненты: поверхности, линии, радиусы, длительности; кнопки, вкладки и сегменты — одним шрифтом интерфейса
    P=await newpage(b)
    r=await P.js("""()=>{const R=getComputedStyle(document.documentElement);const tk=['--surface-1','--surface-2','--hairline','--accent','--danger','--r-md','--r-lg','--d2','--ease'].filter(k=>!R.getPropertyValue(k).trim());
      toMenu();const b=getComputedStyle($('#bCodex'));openCodex('menu');const t=getComputedStyle(document.querySelector('#cxTabs .tab'));openSettings('menu');const sg=getComputedStyle(document.querySelector('#setBody .seg button'));
      const tg=document.querySelector('#setBody .tog');const fam=s=>s.fontFamily.split(',')[0].replace(/"/g,'').trim();
      return {tk,btn:[fam(b),parseFloat(b.borderTopLeftRadius),parseFloat(b.fontSize)],tab:[fam(t),parseFloat(t.borderTopLeftRadius)],seg:[fam(sg),parseFloat(sg.borderTopLeftRadius)],sw:tg.getAttribute('role'),ac:tg.getAttribute('aria-checked'),on:tg.classList.contains('on')};}""")
    ok=not r['tk'] and r['btn'][0]=='Exo 2' and r['btn'][1]>=8 and r['btn'][2]>=15 and r['tab'][0]=='Exo 2' and r['tab'][1]>=16 and r['seg'][0]=='Exo 2' and r['seg'][1]>=8 and r['sw']=='switch' and r['ac']==str(r['on']).lower()
    rec('U03 токены на месте; кнопки, вкладки и сегменты — Exo 2 со скруглением; переключатели — role=switch',ok,{**r,'errs':P.errs[:2]})

@test('U04')
async def u04(b):
    # выход из миссии и перезапуск — через окно подтверждения на всех устройствах; Esc отменяет; из полёта по сектору — без вопроса
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();T.go(3);pause();$('#bQuit').click();const c=$('#cfm');const a={st:G.state,open:!!c&&!c.hidden,focus:document.activeElement&&document.activeElement.id};
      dispatchEvent(new KeyboardEvent('keydown',{code:'Escape',key:'Escape',bubbles:true}));const b={st:G.state,open:!c.hidden};
      $('#bRestart').click();const t=$('#cfmT').textContent;$('#cfmOk').click();const r2={st:G.state,open:!c.hidden};
      toMenu();T.fresh();T.openAll();T.go(3);pause();$('#bQuit').click();$('#cfmOk').click();const q={st:G.state};
      T.fresh();T.openAll();const n=WORLD.nodes[2];enterWorldAt(n.x,n.y+400);for(let i=0;i<10;i++)worldUpdate(1/60);pause();$('#bQuit').click();const w={st:G.state,open:!c.hidden};return {a,b,t,r2,q,w};}""")
    ok=r['a']=={'st':'pause','open':True,'focus':'cfmNo'} and r['b']=={'st':'pause','open':False} and 'миссию' in r['t'] and r['r2']['st']=='intro' and not r['r2']['open'] and r['q']['st']=='menu' and r['w']=={'st':'menu','open':False}
    rec('U04 «В меню», «Перезапуск» в миссии — с подтверждением (Esc — отмена); из сектора — сразу',ok and not P.errs,{**r,'errs':P.errs[:2]})

@test('U05')
async def u05(b):
    # стрелки водят фокус по кнопкам меню и паузы в порядке на экране; в полёте стрелки не трогают фокус
    P=await newpage(b)
    await P.js("()=>{toMenu();document.activeElement&&document.activeElement.blur&&document.activeElement.blur();}")
    vis=await P.js("()=>[...document.querySelectorAll('#sMenu .btns .btn')].filter(b=>b.offsetParent).map(b=>b.id)")
    seq=[]
    for k in ['ArrowDown','ArrowDown','ArrowDown','ArrowUp']:
        await P.pg.keyboard.press(k);seq.append(await P.js("()=>document.activeElement&&document.activeElement.id"))
    r=await P.js("()=>{T.fresh();T.openAll();T.go(3);pause();document.activeElement.blur();return 1;}")
    await P.pg.keyboard.press('ArrowUp');pz=await P.js("()=>document.activeElement&&document.activeElement.id")
    await P.js("()=>{resume();document.activeElement.blur();}")
    await P.pg.keyboard.press('ArrowDown');pl=await P.js("()=>[G.state,document.activeElement&&document.activeElement.tagName]")
    ok=seq[0]=='bWorld' and seq[1]==vis[1] and seq[2]==vis[2] and seq[3]==vis[1] and pz in ('bResume','bRestart') and pl==['play','BODY']
    rec('U05 стрелки: меню — по порядку, пауза — фокус на первой кнопке; в полёте фокус не трогается',ok,{'seq':seq,'vis':vis,'pause':pz,'play':pl,'errs':P.errs[:2]})

@test('U06')
async def u06(b):
    # брифинг: на ПК — две колонки (сложность и кнопки справа); в альбомной кнопка старта видна без прокрутки; в книжной — прилипает к низу
    res={}
    for tag,vw,vh,touch in [('pc',1280,800,False),('pl',844,390,True),('pp',390,844,True)]:
        P=await newpage(b,vw=vw,vh=vh,touch=touch)
        if touch:await P.js("()=>{setInput('touch');}")
        res[tag]=await P.js("""()=>{T.fresh();T.openAll();enterNode(23,false);const g=$('#bGo').getBoundingClientRect(),h=$('#inName').getBoundingClientRect(),side=document.querySelector('#sIntro .brief-side');
          return {side:!!side,gx:Math.round(g.left),gb:Math.round(g.bottom),hr:Math.round(h.right),ht:Math.round(h.top),gt:Math.round(g.top),vh:innerHeight,pos:getComputedStyle($('#bGo').parentElement).position};}""")
    pc,pl,pp=res['pc'],res['pl'],res['pp']
    ok=pc['side'] and pc['gx']>pc['hr'] and pc['gb']<=pc['vh'] and pl['gx']>pl['hr'] and pl['gb']<=pl['vh'] and pp['gb']<=pp['vh'] and pp['pos']=='sticky'
    rec('U06 брифинг: две колонки на ПК и в альбомной, старт без прокрутки; в книжной кнопки прилипают к низу',ok,res)

@test('U07')
async def u07(b):
    # уведомление: на ПК — сверху по центру, с полоской времени; на телефоне — читаемый размер (не мельче 12 px)
    res={}
    for tag,vw,vh,touch in [('pc',1280,800,False),('pp',390,844,True)]:
        P=await newpage(b,vw=vw,vh=vh,touch=touch)
        if touch:await P.js("()=>{setInput('touch');}")
        await P.js("()=>{T.fresh();T.openAll();const n=WORLD.nodes[2];enterWorldAt(n.x,n.y+400);for(let i=0;i<10;i++)worldUpdate(1/60);toast('ПРОВЕРКА','Текст уведомления для проверки.');}")
        await P.wait(500)
        res[tag]=await P.js("""()=>{const e=$('#toast'),r=e.getBoundingClientRect();return {c:Math.round(r.left+r.width/2),vw:innerWidth,top:Math.round(r.top),l:Math.round(r.left),in:e.classList.contains('in'),
          fe:parseFloat(getComputedStyle($('#toastT')).fontSize),fp:parseFloat(getComputedStyle($('#toastP')).fontSize),bar:getComputedStyle(e,'::after').animationName};}""")
    pc,pp=res['pc'],res['pp']
    ok=abs(pc['c']-pc['vw']/2)<=3 and pc['top']<160 and pc['in'] and pc['bar']=='toastT' and pp['fe']>=12 and pp['fp']>=12 and pp['l']>=0
    rec('U07 уведомление: на ПК по центру сверху с полоской времени; на телефоне текст не мельче 12 px',ok,res)

@test('U08')
async def u08(b):
    # V-02: всполох памяти не висит поверх открытого экрана; на экране поражения он уходит наверх, не на заголовок
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();T.go(3);memoFlash('ЗАПОМНИ');pause();const a=$('#memo').classList.contains('on');resume();
      memoFlash('ЗАПОМНИ');gameOver();const st=$('#ovStamp'),h=$('#ovName').getBoundingClientRect(),sr=st?st.getBoundingClientRect():null;
      const o={a,fixed:$('#memo').classList.contains('on'),inOver:!!st&&st.closest('#sOver')!==null,txt:st?st.textContent:'',sb:sr?Math.round(sr.bottom):null,ht:Math.round(h.top)};
      toMenu();T.fresh();T.openAll();T.go(3);gameOver();o.again=$('#ovStamp').textContent;return o;}""")
    rec('U08 штамп памяти гаснет при открытии окна; на поражении — внутри экрана, над заголовком; при следующем поражении без штампа — пусто',
        not r['a'] and not r['fixed'] and r['inOver'] and r['txt']=='ЗАПОМНИ' and r['sb'] is not None and r['sb']<=r['ht'] and r['again']=='',{**r,'errs':P.errs[:2]})

@test('U09')
async def u09(b):
    # «ЭФФЕКТЫ: МЕНЬШЕ/ВЫКЛ» отключают анимации оболочки (класс lessfx); «ПОЛНЫЕ» — включают
    P=await newpage(b)
    r=await P.js("""()=>{const out=[];for(const [fx,less] of [[true,true],[false,false],[true,false]]){SET.fx=fx;SET.lessFx=less;applySettings();toMenu();
      out.push([document.documentElement.classList.contains('lessfx'),getComputedStyle(document.querySelector('#sMenu .wrap')).animationName]);}return out;}""")
    ok=r[0][0] and r[0][1]=='none' and r[1][0] and r[2]==[False,'scrIn']
    rec('U09 эффекты «меньше»/«выкл» — оболочка без анимаций; «полные» — с ними',ok,{'r':r,'errs':P.errs[:2]})

@test('U10')
async def u10(b):
    # журналы: пустой сектор — одна строка, без карточки «ЗАПИСЕЙ НЕ НАЙДЕНО»
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();openMap('jr');const el=$('#mapJr');return {lockd:[...el.querySelectorAll('.jr.lockd h4')].map(e=>e.textContent),empty:el.querySelectorAll('.jsec.empty').length,
      secs:WORLD.sectors.filter((s,i)=>WORLD.journals.some(j=>j.sec===i)).length};}""")
    rec('U10 журналы: пустые сектора — строкой, без карточек-заглушек',not any('ЗАПИСЕЙ' in x for x in r['lockd']) and r['empty']==r['secs'] and r['secs']>3,{**r,'errs':P.errs[:2]})

@test('U11')
async def u11(b):
    # V-03/V-05: на телефоне кнопки паузы не наезжают на заголовок; полоса маяка не наезжает на значки внизу HUD
    res={}
    P=await newpage(b,vw=844,vh=390,touch=True);await P.js("()=>{setInput('touch');}")
    res['pl']=await P.js("""()=>{T.fresh();T.openAll();T.go(3);pause();const s=$('#sPause'),hd=[...s.querySelectorAll('.eyebrow,.pstat')].filter(e=>e.offsetParent).map(e=>e.getBoundingClientRect());
      const bs=[...s.querySelectorAll('button')].filter(e=>e.offsetParent).map(e=>e.getBoundingClientRect());let hit=0;for(const a of hd)for(const c of bs)if(a.bottom>c.top+1&&a.top<c.bottom-1&&a.right>c.left&&a.left<c.right)hit++;return {hit,n:bs.length,maxB:Math.round(Math.max(...bs.map(c=>c.bottom))),vh:innerHeight};}""")
    P=await newpage(b,vw=390,vh=844,touch=True);await P.js("()=>{setInput('touch');}")
    res['pp']=await P.js("""()=>{T.fresh();T.openAll();T.go(7);for(let i=0;i<60;i++)update(1/60);updateHUD();const bc=$('#bcBox'),hb=document.querySelector('#hud .hud-b');
      const vc=[...hb.querySelectorAll('.chip')].filter(e=>e.offsetParent&&getComputedStyle(e).display!=='none');const top=vc.length?Math.min(...vc.map(e=>e.getBoundingClientRect().top)):9999;
      return {bc:!bc.hidden,bcB:Math.round(bc.getBoundingClientRect().bottom),chipTop:Math.round(top),n:vc.length};}""")
    ok=res['pl']['hit']==0 and res['pl']['maxB']<=res['pl']['vh'] and res['pp']['bc'] and res['pp']['chipTop']>=res['pp']['bcB']
    rec('U11 телефон: пауза в альбомной без наездов и без прокрутки; значки HUD ниже полосы маяка в книжной',ok,res)

@test('U12')
async def u12(b):
    # версия 1.1.1 α, запись в хронике; герой меню только на широком ПК
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{toMenu();const v=$('#verTag').textContent;window.__devUI=true;cxTab='log';openCodex('menu');const log=$('#cxBody').textContent;window.__devUI=false;toMenu();
      const h=document.querySelector('#sMenu .hero');return {v,log:log.includes('1.1.1 α')&&log.includes('Стекло'),hero:!!h&&getComputedStyle(h).display!=='none',ver:VER_TAG};}""")
    P2=await newpage(b,vw=390,vh=844,touch=True,alpha=False)
    r['heroPhone']=await P2.js("()=>{toMenu();const h=document.querySelector('#sMenu .hero');return !!h&&getComputedStyle(h).display!=='none';}")
    rec('U12 версия 1.1.1 α и запись «Стекло» в хронике; заставка-орбита только на ПК',r['v']=='1.2.5 α' and r['ver']=='1.2.5 α' and r['log'] and r['hero'] and not r['heroPhone'],{**r,'errs':P.errs[:2]})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q150.json'))
