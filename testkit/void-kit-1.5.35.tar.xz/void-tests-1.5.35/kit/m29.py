# 1.2.0 α · m29: сектор I — механики среды в миссиях 1–5 и новый Страж (миссия 6), без новых врагов
import sys,os
P='@@KIT@@/home/void.html'
D=os.path.dirname(os.path.abspath(__file__))
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m29 FAIL count',n,'!=',cnt,'for',a[:100]);sys.exit(1)
    s=s.replace(a,b)
# отрисовка миссии: под врагами (после астероидов) и поверх врагов (перед тьмой миссии 9)
i=s.index('function render(now){');j=s.index('drawRocks(G.rocks);\n  drawPickups();',i)
s=s[:j]+'drawRocks(G.rocks);if(G.s1)s1DrawUnder(t);\n  drawPickups();'+s[j+len('drawRocks(G.rocks);\n  drawPickups();'):]
R("  if(G.dark){drawDark(","  if(G.s1)s1DrawOver(t);\n  if(G.dark){drawDark(")
# отражённые плитой снаряды помечены — для мастерства миссии 2
R("hurt(e,b.dmg,{charged:!!b.charged,drone:!!(b.drone||b.turret),bt95:b.bt95})","hurt(e,b.dmg,{charged:!!b.charged,drone:!!(b.drone||b.turret),bt95:b.bt95,refl:!!b.refl})")
js=open(os.path.join(D,'m29.js'),encoding='utf8').read()
i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s)
print('m29 ok')
