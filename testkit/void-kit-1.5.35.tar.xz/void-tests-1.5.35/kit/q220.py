# 1.2.8 α: музыка меню сразу, обучение 2.0 (калибровка, допуск пилота, показы), кнопки меню на телефоне, громкость звуков. Каждый тест падает на версии 29.
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
NEW="""async(o)=>{o=o||{};window.w8=ms=>new Promise(r=>setTimeout(r,ms));if(typeof TUT==='undefined'||typeof TUT_SK==='undefined')return false;T.fresh();if(o.touch)setInput('touch');
  for(let i=0;i<40&&(G.prologue||G.state!=='world');i++)await w8(100);TUT.hist=[];TUT.gap=0;TUT.log=[];
  window.waitCur=async(k,ms)=>{const t0=performance.now();while(performance.now()-t0<(ms||4000)){if(TUT.cur&&TUT.cur.k===k)return true;await w8(50);}return false;};return true;}"""
STRICT="""window.__gest=false;addEventListener('pointerdown',()=>{window.__gest=true;},true);addEventListener('keydown',()=>{window.__gest=true;},true);
const A_=window.AudioContext;window.AudioContext=class extends A_{constructor(...a){super(...a);super.suspend();}resume(){return window.__gest?super.resume():Promise.resolve();}};"""

@test('U01')
async def u01(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));await w8(1500);return {ctx:AU.ctx?AU.ctx.state:null,want:typeof MZ!=='undefined'?MZ.want:null,live:typeof MZ!=='undefined'?MZ.anyLive:null,st:G.state,clicked:0}}")
    rec('U01 музыка меню сама: без единого нажатия через 0,5 с звук включён и играет трек меню',r['ctx']=='running' and r['want']=='menu' and r['live'],r)

@test('U02')
async def u02(b):
    P=await newpage(b,1280,760,alpha=False,init=STRICT)
    await P.pg.wait_for_timeout(1200)
    a=await P.js("()=>({ctx:AU.ctx?AU.ctx.state:null,dec:typeof MZ!=='undefined'&&MZ.pl.menu?Object.keys(MZ.pl.menu.buf).length:0})")
    await P.pg.mouse.click(1150,650);await P.pg.wait_for_timeout(500)
    c=await P.js("()=>({ctx:AU.ctx?AU.ctx.state:null,live:typeof MZ!=='undefined'&&MZ.anyLive,want:typeof MZ!=='undefined'?MZ.want:null,st:G.state})")
    rec('U02 строгий браузер: трек меню готов заранее; первый клик по пустому месту — музыка за ≤ 0,5 с',a['ctx']=='suspended' and a['dec']>=1 and c['ctx']=='running' and c['live'] and c['want']=='menu' and c['st']=='menu',{'до':a,'после':c})

@test('U03')
async def u03(b):
    out={}
    for (vw,vh) in [(430,932),(390,844),(375,667)]:
        P=await newpage(b,vw,vh,alpha=False,touch=True)
        out[vw]=await P.js("""async()=>{T.fresh();const S=G.save;S.cleared=13;for(let m=1;m<=13;m++)S.medals[m]={clear:1};saveWorld();toMenu();document.documentElement.style.setProperty('--sab','34px');await new Promise(r=>setTimeout(r,500));
          const a=$('#sMenu .btns').getBoundingClientRect(),c=($('#verNote')||$('#recLine')).getBoundingClientRect();const el=document.elementFromPoint(c.left+20,c.top+c.height/2);return {ov:+(a.bottom-c.top).toFixed(1),hit:!!(el&&el.closest('#verNote,#recLine'))}}""")
    rec('U03 меню телефона с нижним вырезом: панель кнопок не наезжает на строку версии внизу меню (1.3.1: вместо плашек «Миссии / Пилот»), она видна и сверху',all(v['ov']<=0 and v['hit'] for v in out.values()),out)

@test('U04')
async def u04(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("""async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));SET.sfx=true;audioInit();await AU.ctx.resume();G.setFrom='menu';openSettings('menu');await w8(200);const sl=document.querySelector('#setBody [data-svol]');if(!sl)return {ok:false};
      const tog=document.querySelector('#setBody .tog[data-k="sfx"]');const tw=tog&&(tog.closest('.srow63')||tog),after=!!tw&&!!tw.nextElementSibling&&tw.nextElementSibling.contains(sl);sl.value='0.25';sl.dispatchEvent(new Event('input',{bubbles:true}));await w8(300);
      return {ok:true,after,g:+AU.sfx.gain.value.toFixed(3),st:JSON.parse(localStorage.getItem('void_settings')).sfxVol,mus:document.querySelectorAll('#setBody [data-vol]').length}}""")
    if r.get('ok'):
        await P.pg.reload();await P.pg.wait_for_timeout(400)
        r['reload']=await P.js("async()=>{audioInit();await AU.ctx.resume();await new Promise(r=>setTimeout(r,300));return [SET.sfxVol,+AU.sfx.gain.value.toFixed(3)]}")
    ok=r.get('ok') and r['after'] and abs(r['g']-.08)<.006 and r['st']==.25 and r['mus']==1 and r['reload'][0]==.25 and abs(r['reload'][1]-.08)<.006
    rec('U04 громкость звуков: ползунок под «Звуки», 25 % → шина звуков 0,08, сохраняется после перезагрузки; музыка — отдельно',ok,r)

@test('U05')
async def u05(b):
    P=await newpage(b,1600,900,alpha=False);ok0=await P.js(NEW,{})
    r=await P.js("""async()=>{const on=await waitCur('calib',4000);const K=TUT.cal,p=G.player,ii=[];for(let i=0;i<3;i++){p.x=K.pts[i].x;p.y=K.pts[i].y;await w8(150);ii.push(K.i);}
      p.x=K.gate.x-K.dx*40;p.y=K.gate.y-K.dy*40;await w8(120);p.x=K.gate.x+K.dx*40;p.y=K.gate.y+K.dy*40;await w8(200);const fail=[K.gate.fails,!!G.save.tut.done.calib];
      p.x=K.gate.x-K.dx*90;p.y=K.gate.y-K.dy*90;await w8(150);p.dashCd=0;tryDash([K.dx,K.dy]);await w8(500);const T=G.save.tut;
      return {on,ii,fail,done:T.done,ok:T.ok,sk:!$('#tutSk').hidden&&$('#tutSk').textContent,cur:TUT.cur&&TUT.cur.k}}""") if ok0 else {}
    ok=ok0 and r['on'] and r['ii']==[1,2,3] and r['fail']==[1,False] and r['done'].get('calib') and r['done'].get('move') and r['done'].get('dash') and r['ok'].get('move') and r['ok'].get('dash') and 'ПОЛЁТ' in r['sk'] and '2/8' in r['sk']
    rec('U05 калибровка: после пробуждения три кольца и луч; пролёт сквозь луч без рывка — «ещё раз», с рывком — полёт и рывок освоены, панель «Допуск 2/8»',ok,r)

@test('U06')
async def u06(b):
    P=await newpage(b,390,844,alpha=False,touch=True);ok0=await P.js(NEW,{'touch':1})
    r=await P.js("""async()=>{const on=await waitCur('calib',4000);await w8(300);const ch=document.querySelector('#tut .tut-chip').getBoundingClientRect(),I=$('#joyIdle').getBoundingClientRect();
      const K=TUT.cal,p=G.player;for(let i=0;i<3;i++){p.x=K.pts[i].x;p.y=K.pts[i].y;await w8(150);}await w8(300);const rg=document.querySelector('#tut .tut-ring.on'),d=$('#tDash').getBoundingClientRect();
      const a=rg?rg.getBoundingClientRect():null;return {on,dx:Math.abs((ch.left+ch.right)/2-(I.left+I.right)/2),ring:a?Math.hypot((a.left+a.right)/2-(d.left+d.right)/2,(a.top+a.bottom)/2-(d.top+d.bottom)/2):null,keys:document.querySelector('#tut .tut-keys').innerHTML}}""") if ok0 else {}
    ok=ok0 and r['on'] and r['dx']<130 and r['ring'] is not None and r['ring']<=2 and r['keys']==''
    rec('U06 калибровка на телефоне: кольца — подсказка у стика, луч — кольцо на кнопке «РЫВОК»',ok,r)

@test('U07')
async def u07(b):
    P=await newpage(b,1600,900,alpha=False);ok0=await P.js(NEW,{})
    r=await P.js("""async()=>{await waitCur('calib',4000);const K=TUT.cal,p=G.player;p.x=K.pts[0].x-K.dx*2100;p.y=K.pts[0].y-K.dy*2100;const t0=performance.now();while(performance.now()-t0<14000&&!G.save.tut.done.calib){await w8(200);}
      const T=G.save.tut,K2=TUT.cal;return {calib:!!T.done.calib,okDash:!!(T.ok&&T.ok.dash),cur:TUT.cur&&TUT.cur.k,near:!!K2&&Math.hypot(K2.pts[0].x-G.player.x,K2.pts[0].y-G.player.y)<1500}}""") if ok0 else {}
    rec('U07 (1.3.3) улетел от трассы — калибровка не снимается, трасса переезжает к игроку, рывок не засчитан',ok0 and not r['calib'] and not r['okDash'] and r['near'],r)

@test('U08')
async def u08(b):
    P=await newpage(b,1600,900,alpha=False)
    r=await P.js("""async()=>{if(typeof TUT_SK==='undefined')return {ok:false};const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();const S=G.save;S.cleared=1;S.medals[1]={clear:1};S.tut={v:1,done:{},seen:{}};saveWorld();startWorld(false);
      for(let i=0;i<40&&(G.prologue||G.state!=='world');i++)await w8(100);TUT.log=[];await w8(3500);return {ok:true,log:TUT.log.slice()}}""")
    rec('U08 калибровка только для совсем новых пилотов: прошёл миссию — её нет',r.get('ok') and 'calib' not in r['log'],r)

@test('U09')
async def u09(b):
    out={}
    for (vw,vh,tch,inp) in [(1600,900,False,'kbm'),(390,844,True,'touch'),(1600,900,False,'pad')]:
        P=await newpage(b,vw,vh,alpha=False,touch=tch);await P.js(NEW,{'touch':1} if tch else {})
        out[inp]=await P.js("""async(inp)=>{if(inp==='pad')setInput('pad');const C0=await waitCur('calib',4000);const x=document.querySelector('#tut .tut-x');x.dispatchEvent(new MouseEvent('click',{bubbles:true}));await w8(200);
          const n=tutSkillN(),okc=!!(G.save.tut.ok&&G.save.tut.ok.calib);pause();await w8(200);const card=$('#tutCard');const row=[...card.querySelectorAll('.tcard-r')].find(r=>r.textContent.includes('РЫВОК'));
          return {n,okc,skip:!!G.save.tut.done.calib,ctl:row&&row.querySelector('.tck').textContent,vis:!!row&&row.querySelector('.tck').getBoundingClientRect().width>0,open:card.open}}""",inp)
    ok=all(v['n']==0 and not v['okc'] and v['skip'] and v['vis'] and v['open'] is False for v in out.values()) and out['kbm']['ctl']=='ПРОБЕЛ' and 'РЫВОК' in out['touch']['ctl'] and out['pad']['ctl']=='A'
    rec('U09 «✕» не засчитывает навык; в паузе — «Допуск пилота» (с 1.3.1 свёрнут) с управлением под устройство: ПРОБЕЛ / кнопка «РЫВОК» / A',ok,out)

@test('U10')
async def u10(b):
    out={}
    for (vw,vh,tch) in [(1600,900,False),(390,844,True)]:
        P=await newpage(b,vw,vh,alpha=False,touch=tch);await P.js(NEW,{'touch':1} if tch else {})
        out[vw]=await P.js("""async()=>{for(const k of ['calib','move','lom','stash','act','fire','dash'])G.save.tut.done[k]=1;if(TUT.cur)tutEnd('abort');G.save.cleared=1;G.save.medals[1]={clear:1};T.go(2);TUT.gap=0;TUT.hist=[];G.player.en=100;spawnEnemy('scout',G.player.x+260,G.player.y,{});const sc=G.enemies[G.enemies.length-1];sc.hp=sc.maxHp=1e9;
          const keep=setInterval(()=>{const p=G.player;p.hp=G.st.maxHp;p.en=Math.max(p.en,100);sc.x=p.x+260;sc.y=p.y;sc.vx=sc.vy=0;},50);const on=await waitCur('energy',3000);await w8(300);
          const rg=document.querySelector('#tut .tut-ring.on'),tg=$(touchMode?'#tPulse':'#enBar').getBoundingClientRect(),a=rg&&rg.getBoundingClientRect();await w8(5200);clearInterval(keep);
          return {on,ring:a?Math.hypot((a.left+a.right)/2-(tg.left+tg.right)/2,(a.top+a.bottom)/2-(tg.top+tg.bottom)/2):null,energy:!!G.save.tut.done.energy,pulse:!!G.save.tut.done.pulse,en:G.player.en}}""")
    ok=all(v['on'] and v['ring'] is not None and v['ring']<=2 and v['energy'] and not v['pulse'] and v['en']>=100 for v in out.values())
    rec('U10 (1.3.4) «Импульс готов» в бою миссии 02: накопитель полон, враг рядом — кольцо на шкале (ПК) или кнопке «ИМП» (телефон); энергия не тратится, урок импульса ждёт боя',ok,out)

@test('U11')
async def u11(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{const errs=[];const p=G.player;for(const d of ['pulse','pulsedemo','dash','stash','calib']){try{tutDemo({k:'x',L:TUT_L.move,v:{draw:d}},performance.now());}catch(e){errs.push(d+':'+e.message);}}
      G.save.cleared=2;G.save.medals[1]={clear:1};G.save.medals[2]={clear:1};p.x+=2500;for(const k of TUT_KEYS_ALL)if(k!=='jump')G.save.tut.done[k]=1;if(TUT.cur)tutEnd('abort');TUT.gap=0;TUT.hist=[];openMap();await w8(1200);const on=$('#mapHint').classList.contains('on');
      try{tutMapDraw(performance.now());}catch(e){errs.push('map:'+e.message);}return {errs,on}}""")
    rec('U11 живые показы (волна импульса, призрак рывка, лом к складу, трасса, путь на карте) рисуются без ошибок',r['on'] and not r['errs'] and not P.errs,{**r,'pe':P.errs[:2]})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q220.json'))
