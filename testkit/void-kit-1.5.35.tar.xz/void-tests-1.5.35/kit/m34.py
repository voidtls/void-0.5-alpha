# 1.2.3 α · m34: полоса разгона, гравитационный колодец закрытых миссий, событие «Погоня»
import sys,os
P='@@KIT@@/home/void.html'
D=os.path.dirname(os.path.abspath(__file__))
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m34 FAIL count',n,'!=',cnt,'for',a[:100]);sys.exit(1)
    s=s.replace(a,b)
# 1. телеграфы таранных атак — одна функция
R("if(e.type==='rammer'&&e.st==='aim'&&!G.noTele){ctx.strokeStyle='#ff4545';ctx.globalAlpha=.25+.5*(1-e.timer/.85);ctx.lineWidth=e.r*1.6;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.x+Math.cos(e.aim)*360,e.y+Math.sin(e.aim)*360);ctx.stroke();ctx.globalAlpha=1;}",
  "if(e.type==='rammer')laneRammer(e);")
R("if(b.ram&&b.ram.st==='tele'&&!G.noTele){ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.4+.4*Math.sin(t*24);ctx.lineWidth=b.r*2;ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(b.x+Math.cos(b.ang)*560,b.y+Math.sin(b.ang)*560);ctx.stroke();ctx.globalAlpha=1;}",
  "if(b.ram&&b.ram.st==='tele'&&!G.noTele){const R_=b.ram,lk=R_.t<=.22;teleLane(b.x,b.y,b.ang,400,b.r*.9+14,1-clamp(R_.t/1.2,0,1),lk,'#ff4f6e',{r:b.r*.6,flash:lk?Math.max(0,1-(.22-R_.t)/.12):0});}")
R("if(e.mode==='ram'&&e.rst==='aim'&&!G.noTele){ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.3+.5*Math.sin(t*20);ctx.lineWidth=e.r*1.4;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.x+Math.cos(e.aim)*260,e.y+Math.sin(e.aim)*260);ctx.stroke();ctx.globalAlpha=1;}",
  "if(e.mode==='ram'&&e.rst==='aim'&&!G.noTele){const T0=.8,lk=e.rt<=.22;teleLane(e.x,e.y,e.aim,420*.6*(G.eSpd||1),e.r+14,1-clamp(e.rt/T0,0,1),lk,'#ff4f6e',{r:e.r+2,flash:lk?Math.max(0,1-(.22-e.rt)/.12):0});}")
# фиксация курса за 0,22 с до рывка у босса и «Дефекта» — подсказка не врёт
R("if(R_.st==='tele'){b.ang+=clamp(","if(R_.st==='tele'){if(R_.t>.22)b.ang+=clamp(")
R("if(e.rst==='aim'){e.vx*=.85;e.vy*=.85;e.aim+=clamp(","if(e.rst==='aim'){e.vx*=.85;e.vy*=.85;if(e.rt>.22)e.aim+=clamp(")
# 2. колодец вместо стены
R("  for(const n of WORLD.nodes){if(nodeState(n.m)!=='locked')continue;const d=Math.hypot(p.x-n.x,p.y-n.y);\n    if(d<420){const a=Math.atan2(p.y-n.y,p.x-n.x);p.x=n.x+Math.cos(a)*420;p.y=n.y+Math.sin(a)*420;p.vx=Math.cos(a)*220;p.vy=Math.sin(a)*220;p.dashT=0;hintOnce('noise','СИГНАЛ НЕ РАСШИФРОВАН','#9fb0c4');}}\n",
  "  wellTick(dt);\n")
i=s.index("  if(st==='locked'){ctx.strokeStyle='#9fb0c4';");j=s.index("worldLabel(n.x,n.y,'?','#7a8ea5');return;}",i)+len("worldLabel(n.x,n.y,'?','#7a8ea5');return;}")
s=s[:i]+"  if(st==='locked'){drawWell(n,t);return;}"+s[j:]
# 3. «Погоня» рисуется в мире рядом с объектами сектора
R("try{postWorldDraw(t);}catch(e){}","try{postWorldDraw(t);}catch(e){}try{chaseDraw(t);}catch(e){}")
js=open(os.path.join(D,'m34.js'),encoding='utf8').read()
i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s)
print('m34 ok')
