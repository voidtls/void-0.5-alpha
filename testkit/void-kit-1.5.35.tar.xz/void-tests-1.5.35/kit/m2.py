# 0.6.0 · часть 2: управление — стик, дуга кнопок с кольцами, свайп-рывок, тап по цели, вибрация, защита от тапа, отсчёт, контекстная кнопка
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m2: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)

RING='<svg class="ring" viewBox="0 0 100 100" aria-hidden="true"><circle class="rb" cx="50" cy="50" r="46"/><circle class="rf" cx="50" cy="50" r="46" pathLength="100"/></svg>'
R('<div id="touch" hidden><div id="joy"><i></i></div><button class="tbtn" id="tPulse">ИМП</button><button class="tbtn" id="tCharge" hidden>ЗАРЯД</button><button class="tbtn" id="tDash">РЫВОК</button></div>',
  '<div id="touch" hidden><div id="joyIdle" aria-hidden="true"><span>ДВИЖЕНИЕ</span></div><div id="joy"><i></i><b class="jl">КУРС</b></div>'
  '<button class="tbtn" id="tPulse" aria-label="Импульс">'+RING+'<span class="lb">ИМП</span><span class="cdn"></span></button>'
  '<button class="tbtn" id="tCharge" hidden aria-label="Заряженный выстрел">'+RING+'<span class="lb">ЗАРЯД</span><span class="cdn"></span></button>'
  '<button class="tbtn" id="tDash" aria-label="Рывок">'+RING+'<span class="lb">РЫВОК</span><span class="cdn"></span></button>'
  '<button class="tbtn" id="tAct" hidden aria-label="Действие">'+RING+'<span class="lb">КАРТА</span><span class="cdn"></span></button></div>')

CSS=r"""
/* --- 0.6.0: сенсорное управление --- */
#touch{--ba:.7}
.tbtn .ring{display:none}
.mob .tbtn{opacity:var(--ba);font-size:12px;font-weight:700;letter-spacing:.06em;color:var(--text);border-color:rgba(143,233,255,.45);background:rgba(8,14,26,.62);transition:opacity .2s}
.mob .tbtn::after{content:'';position:absolute;inset:-12%;border-radius:50%}
.mob .tbtn .ring{display:block;position:absolute;inset:-3px;width:calc(100% + 6px);height:calc(100% + 6px);transform:rotate(-90deg);pointer-events:none}
.mob .tbtn .ring circle{fill:none;stroke-width:5}
.mob .tbtn .ring .rb{stroke:rgba(143,233,255,.12)}
.mob .tbtn .ring .rf{stroke:var(--ice);stroke-dasharray:100;stroke-dashoffset:0;stroke-linecap:round}
.mob .tbtn .lb{position:relative}
.mob .tbtn .cdn{position:absolute;left:0;right:0;bottom:16%;text-align:center;font-size:12px;color:var(--muted);font-weight:700}
.mob .tbtn.cd{opacity:calc(var(--ba)*.8)}
.mob .tbtn.cd .lb{opacity:.55}
.mob #tPulse{color:var(--amber);border-color:rgba(255,184,77,.45)}
.mob #tPulse .ring .rf{stroke:var(--amber)}
.mob #tPulse.rdy{opacity:1;box-shadow:0 0 0 2px rgba(255,184,77,.85),0 0 22px rgba(255,184,77,.45)}
.mob #tCharge .ring .rf{stroke:#ffffff}
.mob #tCharge.chg .ring .rf{stroke:var(--violet)}
.mob #tAct{color:var(--ice)}
.mob #tAct.go{opacity:1;color:var(--void);background:var(--ice);border-color:var(--ice)}
.mob #tAct.go .ring{display:none}
.mob .tbtn.bump{animation:tbump .14s}
@keyframes tbump{0%,100%{translate:0}30%{translate:-4px}70%{translate:4px}}
.mob #touch.calm .tbtn:not(.rdy):not(.go){opacity:calc(var(--ba)*.55)}
#joyIdle{display:none}
.mob[data-input=touch] #joyIdle.on{display:grid;position:absolute;border:1px dashed rgba(143,233,255,.3);border-radius:50%;place-items:center;pointer-events:none;opacity:.5}
#joyIdle span{font:700 12px var(--f-mono);letter-spacing:.14em;color:rgba(143,233,255,.55);display:none}
#joyIdle.hint span{display:block}
#joy .jl{display:none;position:absolute;left:50%;top:-22px;transform:translateX(-50%);font:700 12px var(--f-mono);letter-spacing:.12em;color:var(--amber)}
#joy.lockable{border-color:var(--amber)}
#joy.lockable .jl{display:block}
#joyLock{position:absolute;display:none;pointer-events:none;font:700 12px var(--f-mono);letter-spacing:.12em;color:var(--amber);padding:6px 10px;border:1px solid rgba(255,184,77,.6);background:rgba(8,14,26,.7)}
#joyLock.on{display:block}
"""
R("</style>",CSS+"</style>",1)
R('<div id="joyIdle" aria-hidden="true">','<div id="joyLock" aria-hidden="true">КУРС ЗАФИКСИРОВАН · КОСНИТЕСЬ СТИКА</div><div id="joyIdle" aria-hidden="true">')

# ---------- джойстик: состояние, ввод ----------
R("const joy={on:false,id:null,ox:0,oy:0,x:0,y:0};",
  "const joy={on:false,id:null,ox:0,oy:0,x:0,y:0,lx:null,ly:null,locked:false,lockable:false,lockA:0,lockHold:0,fl:[],flT:0};")
R("  if(joy.on){x+=joy.x;y+=joy.y;}","  if(joy.on||joy.locked){x+=joy.x;y+=joy.y;}")

# рывок: направление (свайп) и вибрация; хранится полная перезарядка для кольца
R("function tryDash(){\n  const p=G.player;","function tryDash(dir){\n  const p=G.player;")
R("  let [x,y]=inputVec();const l=Math.hypot(x,y);if(l<.1){x=Math.cos(p.ang);y=Math.sin(p.ang);}else{x/=l;y/=l;}\n  clearIce();p.dx=x;p.dy=y;p.dashT=.15;p.dashCd=G.st.dashCd*(G.anom&&G.anom.a.kind==='storm'?2:1)*(G.world&&G.chillD||1);",
  "  let [x,y]=dir||inputVec();const l=Math.hypot(x,y);if(l<.1){x=Math.cos(p.ang);y=Math.sin(p.ang);}else{x/=l;y/=l;}\n  clearIce();p.dx=x;p.dy=y;p.dashT=.15;p.dashCd=G.st.dashCd*(G.anom&&G.anom.a.kind==='storm'?2:1)*(G.world&&G.chillD||1);p.dashCdMax=p.dashCd;buzz('dash');")
R("  p.en=0;clearIce();if(G.w)G.w.pulsed=1;","  p.en=0;clearIce();buzz('pulse');if(G.w)G.w.pulsed=1;")
R("  p.chgCd=CHG_CD;sfx('charged');shake(5);","  p.chgCd=CHG_CD;sfx('charged');shake(5);buzz('chg');")
R("  p.hp-=d;G.taken+=d;p.inv=.75;shake(9);G.hurtV=1;sfx('hurt');p.hitT=G.t;comboBreak();",
  "  p.hp-=d;G.taken+=d;p.inv=.75;shake(9);G.hurtV=1;sfx('hurt');p.hitT=G.t;comboBreak();buzz(d>=20?'hit2':'hit');")
R("if(p.hp<=0){p.hp=0;explode(p.x,p.y,'#8fe9ff',60,1.6);sfx('bigboom');G.deadT=1.6;storyDeath(false);}",
  "if(p.hp<=0){p.hp=0;explode(p.x,p.y,'#8fe9ff',60,1.6);sfx('bigboom');G.deadT=1.6;storyDeath(false);buzz('death');}")
R("function bossDeath(b){ambSting('bossDown');","function bossDeath(b){ambSting('bossDown');buzz('boss');")
R("function jamDeath(j){ambSting('bossDown');","function jamDeath(j){ambSting('bossDown');buzz('boss');")
R("function sbDeath(b){if(!b.alive||b.st==='dying')return;ambSting('bossDown');","function sbDeath(b){if(!b.alive||b.st==='dying')return;ambSting('bossDown');buzz('boss');")
R("function worldMissionDone(){if(!G.save||!G.player||!G.mc||G.mode!=='world')return;ambSting('win');",
  "function worldMissionDone(){if(!G.save||!G.player||!G.mc||G.mode!=='world')return;ambSting('win');buzz('win');")

# ---------- обработчики касаний: заменить блок целиком ----------
a=s.index("cv.addEventListener('pointerdown',e=>{if(G.prologue){prologueSkip();return;}")
endm="  ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>tc.addEventListener(ev,()=>{CHG.t=false;}));}\n"
b=s.index(endm,a)+len(endm)
NEW=r"""// ---------- 0.6.0: сенсорное управление ----------
let SAFE={t:0,r:0,b:0,l:0},TBR={};
const TBL={dash:{d:88,dx:92,dy:92},pulse:{d:64,dx:190,dy:64},charge:{d:64,dx:64,dy:190},act:{d:56,dx:188,dy:188}};
function readSafe(){const el=$('#safeProbe');if(!el)return;const cs=getComputedStyle(el);SAFE={t:parseFloat(cs.paddingTop)||0,r:parseFloat(cs.paddingRight)||0,b:parseFloat(cs.paddingBottom)||0,l:parseFloat(cs.paddingLeft)||0};}
function joyR(){return isMob()?56*(SET.btnSize||1):55;}
function joyFixed(){const k=SET.btnSize||1,R=joyR();const x=SET.hand==='l'?CW-SAFE.r-24-R*2.1:SAFE.l+24+R*2.1;return{x,y:CH-SAFE.b-24-R*2.1,R};}
function layoutTouch(){readSafe();const mob=isMob(),k=SET.btnSize||1,left=SET.hand==='l';TBR={};
  const T=$('#touch');if(T)T.style.setProperty('--ba',mob?(SET.btnAlpha||.7):1);
  for(const [id,key] of [['tDash','dash'],['tPulse','pulse'],['tCharge','charge'],['tAct','act']]){const el=$('#'+id);if(!el)continue;
    if(!mob){el.style.cssText='';continue;}
    const L=TBL[key],d=L.d*k,cx=left?SAFE.l+L.dx*k:CW-SAFE.r-L.dx*k,cy=CH-SAFE.b-L.dy*k;
    el.style.left=(cx-d/2)+'px';el.style.top=(cy-d/2)+'px';el.style.right='auto';el.style.bottom='auto';el.style.width=el.style.height=d+'px';TBR[key]={x:cx,y:cy,r:d/2};}
  const R=joyR(),J=$('#joy'),I=$('#joyIdle');
  if(mob){J.style.width=J.style.height=(R*2+10)+'px';J.style.margin=(-(R+5))+'px 0 0 '+(-(R+5))+'px';const kn=J.firstElementChild;kn.style.width=kn.style.height=(R*.82)+'px';kn.style.margin=(-(R*.41))+'px 0 0 '+(-(R*.41))+'px';}
  else{J.style.width=J.style.height=J.style.margin='';const kn=J.firstElementChild;kn.style.width=kn.style.height=kn.style.margin='';}
  if(I){const f=SET.stick==='fixed'?joyFixed():{x:joy.lx??(left?CW-SAFE.r-24-R*2.3:SAFE.l+24+R*2.3),y:joy.ly??(CH-SAFE.b-24-R*2.3)};
    I.style.width=I.style.height=(R*2+10)+'px';I.style.left=(f.x-R-5)+'px';I.style.top=(f.y-R-5)+'px';}}
function stickZone(x,y){if(!isMob())return x<CW*.5;
  const left=SET.hand==='l';if(left?x<CW*.5:x>=CW*.5)return false;
  if(x<SAFE.l+14||x>CW-SAFE.r-14||y>CH-SAFE.b-10)return false;
  for(const k in TBR){const b=TBR[k];if(Math.hypot(x-b.x,y-b.y)<b.r*1.15)return false;}
  if(SET.stick==='fixed'){const f=joyFixed();return Math.hypot(x-f.x,y-f.y)<f.R*1.8;}
  return y>(isPortrait()?CH*.4:SAFE.t+84);}
function joyShow(){const j=$('#joy');j.style.display='block';j.style.left=joy.ox+'px';j.style.top=joy.oy+'px';}
function joyUnlock(){if(!joy.locked)return;joy.locked=false;joy.x=joy.y=0;const L=$('#joyLock');if(L)L.classList.remove('on');}
function prioTap(cx,cy){if(G.state!=='play'&&G.state!=='world')return;const x=cx/SC+CX,y=cy/SC+CY,tm=touchMode&&isMob();let best=null,bd=1e9;
  for(const en of G.enemies){if(!targetable(en))continue;const d=Math.hypot(en.x-x,en.y-y),R=tm?Math.max(en.r*SC+12,28)/SC:en.r+24;if(d<R&&d<bd){bd=d;best=en;}}
  if(best){if(tm&&G.prio===best){G.prio=null;floater(best.x,best.y-best.r-18,'ПРИОРИТЕТ СНЯТ','#9fb0c4');}else{G.prio=best;floater(best.x,best.y-best.r-18,'ПРИОРИТЕТ','#ffffff');}}else G.prio=null;}
const SW=new Map();
cv.addEventListener('pointerdown',e=>{if(G.prologue){if(e.pointerType!=='touch'||G.prologue.t>.8)prologueSkip();return;}
  audioInit();if(e.button===2)return;
  if(e.pointerType==='touch'){touchMode=true;$('#touch').hidden=!(G.state==='play'||G.state==='world');}
  if(G.state!=='play'&&G.state!=='world')return;
  if(e.pointerType==='mouse'&&aimManual())return;
  if(e.pointerType==='touch'){
    if(!joy.on&&stickZone(e.clientX,e.clientY)){joyUnlock();joy.on=true;joy.id=e.pointerId;
      if(isMob()&&SET.stick==='fixed'){const f=joyFixed();joy.ox=f.x;joy.oy=f.y;}else{joy.ox=e.clientX;joy.oy=e.clientY;}
      joy.x=joy.y=0;joy.lockHold=0;joy.lockable=false;joy.fl=[{x:e.clientX,y:e.clientY,t:performance.now()}];joyShow();joyMove(e.clientX,e.clientY);
      const j=$('#joy');j.firstElementChild.style.transform='';const I=$('#joyIdle');if(I)I.classList.remove('on');return;}
    SW.set(e.pointerId,{x:e.clientX,y:e.clientY,t:performance.now()});return;}
  prioTap(e.clientX,e.clientY);
});
function joyMove(cx,cy){const m=joyR();let dx=cx-joy.ox,dy=cy-joy.oy,l=Math.hypot(dx,dy);
  if(isMob()){if(SET.stick!=='fixed'&&l>m){joy.ox+=dx/l*(l-m);joy.oy+=dy/l*(l-m);dx=cx-joy.ox;dy=cy-joy.oy;l=m;$('#joy').style.left=joy.ox+'px';$('#joy').style.top=joy.oy+'px';}
    else if(l>m){dx*=m/l;dy*=m/l;l=m;}
    const n=l/m,dz=.08,o=n<=dz?0:Math.pow((n-dz)/(1-dz),1.25);joy.x=l>0?dx/l*o:0;joy.y=l>0?dy/l*o:0;}
  else{if(l>m){dx*=m/l;dy*=m/l;}joy.x=dx/m;joy.y=dy/m;}
  $('#joy').firstElementChild.style.transform=`translate(${dx}px,${dy}px)`;}
addEventListener('pointermove',e=>{if(!joy.on||e.pointerId!==joy.id)return;joyMove(e.clientX,e.clientY);
  if(isMob()&&SET.oneHand){const now=performance.now();joy.fl.push({x:e.clientX,y:e.clientY,t:now});while(joy.fl.length&&now-joy.fl[0].t>120)joy.fl.shift();
    const a=joy.fl[0],dx=e.clientX-a.x,dy=e.clientY-a.y,d=Math.hypot(dx,dy);if(d>joyR()*2&&now-joy.flT>350){joy.flT=now;joy.fl=[];tryDash([dx/d,dy/d]);}}});
const joyEnd=e=>{if(e.pointerId!==joy.id)return;const keep=e.type==='pointerup'&&joy.lockable&&G.state==='world';
  joy.on=false;joy.id=null;joy.lx=joy.ox;joy.ly=joy.oy;$('#joy').style.display='none';$('#joy').classList.remove('lockable');joy.lockable=false;
  if(keep){joy.locked=true;const L=$('#joyLock');if(L){L.classList.add('on');L.style.left=Math.max(8,joy.ox-90)+'px';L.style.top=Math.max(8,joy.oy-joyR()-40)+'px';}buzz('ready');}
  else{joy.x=joy.y=0;}
  if(isMob())layoutTouch();const I=$('#joyIdle');if(I&&isMob()&&touchMode)I.classList.add('on');};
addEventListener('pointerup',joyEnd);addEventListener('pointercancel',joyEnd);
const swEnd=e=>{const q=SW.get(e.pointerId);if(!q)return;SW.delete(e.pointerId);if(e.type!=='pointerup')return;
  const dx=e.clientX-q.x,dy=e.clientY-q.y,d=Math.hypot(dx,dy),dt=performance.now()-q.t;
  if(isMob()&&SET.dashSwipe!==false&&d>=60&&dt<=200){tryDash([dx/d,dy/d]);return;}
  if(d<14)prioTap(q.x,q.y);};
addEventListener('pointerup',swEnd);addEventListener('pointercancel',swEnd);
function tbBump(el){if(!el)return;el.classList.remove('bump');void el.offsetWidth;el.classList.add('bump');}
$('#tDash').addEventListener('pointerdown',e=>{e.preventDefault();const p=G.player,cd0=p&&p.dashCd;tryDash();if(p&&cd0===p.dashCd&&!(p.dashT>0))tbBump(e.currentTarget);});
$('#tPulse').addEventListener('pointerdown',e=>{e.preventDefault();const p=G.player,en0=p&&p.en;tryPulse();if(p&&p.en===en0&&en0<100)tbBump(e.currentTarget);});
{const tc=$('#tCharge');tc.addEventListener('pointerdown',e=>{e.preventDefault();CHG.t=true;try{tc.setPointerCapture(e.pointerId);}catch(err){}});
  ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>tc.addEventListener(ev,()=>{CHG.t=false;}));}
$('#tAct').addEventListener('pointerdown',e=>{e.preventDefault();const a=e.currentTarget.dataset.act;if(G.state!=='world')return;if(!a||a==='map')openMap();else cardAct(a);});
function ctxBtnSync(){const b=$('#tAct');if(!b)return;const on=isMob()&&touchMode&&G.state==='world'&&!G.prologue;if(b.hidden===on)b.hidden=!on;if(!on)return;
  const W_=$('#wcard'),wb=W_.hidden?null:W_.querySelector('[data-act]');const lab=wb?wb.textContent.trim().split(/\s+/)[0]:'КАРТА',act=wb?wb.dataset.act:'map';
  if(b.dataset.act!==act||b.dataset.lab!==lab){b.dataset.act=act;b.dataset.lab=lab;b.querySelector('.lb').textContent=lab;b.classList.toggle('go',!!wb);}}
// вибрация (Android; на iOS API нет — молча ничего)
let buzzT=0;const BUZZ={dash:12,pulse:30,ready:[8,40,8],chg:35,chgFull:20,hit:25,hit2:50,death:[80,60,120],boss:[40,40,40,40,120],win:[40,40,40,40,120],tap:15};
function buzz(k){if(!SET.haptics||!touchMode||!isMob()||!navigator.vibrate||RMQ&&RMQ.matches)return;const now=performance.now();if(now-buzzT<80)return;buzzT=now;try{navigator.vibrate(BUZZ[k]||15);}catch(e){}}
const RMQ=window.matchMedia?matchMedia('(prefers-reduced-motion: reduce)'):null;
// состояние кнопок: кольца перезарядки, готовность, фиксация курса
const tbC={};
function tbSet(id,p,txt,cls){const el=$('#'+id);if(!el)return;const k=Math.round(p*100);if(tbC[id+'p']!==k){tbC[id+'p']=k;const c=el.querySelector('.rf');if(c)c.style.strokeDashoffset=100-k;}
  if(tbC[id+'t']!==txt){tbC[id+'t']=txt;const n=el.querySelector('.cdn');if(n)n.textContent=txt;}
  for(const c of ['rdy','chg'])if(tbC[id+c]!==(cls===c)){tbC[id+c]=cls===c;el.classList.toggle(c,cls===c);}}
let tbPrevEn=0,tbPrevChg=0;
function touchTick(dt){const T=$('#touch');if(!T||T.hidden||!isMob())return;const p=G.player;if(!p)return;
  const dm=p.dashCdMax||G.st.dashCd||1;tbSet('tDash',p.dashCd>0?1-p.dashCd/dm:1,p.dashCd>1?String(Math.ceil(p.dashCd)):'');
  tbSet('tPulse',Math.min(1,p.en/100),'',p.en>=100?'rdy':'');if(p.en>=100&&tbPrevEn<100)buzz('ready');tbPrevEn=p.en;
  const cf=p.chg>0?Math.min(1,p.chg/CHG_T):p.chgCd>0?1-p.chgCd/CHG_CD:1;tbSet('tCharge',cf,p.chgCd>1?String(Math.ceil(p.chgCd)):'',p.chg>0?'chg':'');if(p.chg>=CHG_T&&tbPrevChg<CHG_T)buzz('chgFull');tbPrevChg=p.chg||0;
  ctxBtnSync();
  const calm=G.state==='world'&&G.calm>5&&p.hp>=G.st.maxHp*.99;if(tbC.calm!==calm){tbC.calm=calm;T.classList.toggle('calm',calm);}
  // фиксация курса в спокойном полёте: стик у края 2,5 с в одном направлении
  if(joy.on&&G.state==='world'&&G.calm>2){const m=Math.hypot(joy.x,joy.y),a=Math.atan2(joy.y,joy.x);
    if(m>.9&&Math.abs(angDiff(a,joy.lockA))<.35){joy.lockHold+=dt;}else{joy.lockHold=0;joy.lockA=a;}
    const lk=joy.lockHold>2.5;if(lk!==joy.lockable){joy.lockable=lk;$('#joy').classList.toggle('lockable',lk);}}
  else if(joy.lockable){joy.lockable=false;$('#joy').classList.remove('lockable');}
  if(joy.locked&&(G.state!=='world'||G.calm<=0||p.hp<=0))joyUnlock();
  const I=$('#joyIdle');if(I){const on=!joy.on&&!joy.locked;if(I.classList.contains('on')!==on)I.classList.toggle('on',on);const hint=on&&(G.mode==='world'&&!G.world&&G.m<=2);if(I.classList.contains('hint')!==hint)I.classList.toggle('hint',hint);}}
"""
s=s[:a]+NEW+s[b:]

# ---------- show(): защита от случайного тапа, «назад», раскладка ----------
R("function show(id){SCREENS.forEach(s=>$('#'+s).hidden=s!==id);",
  "const TAPGUARD={sLevel:350,sDone:500,sOver:500};\nfunction show(id){if(G.scrId!==id){G.scrId=id;G.scrAt=performance.now();}if(G.state!=='menu')histArm();if(id&&isMob()){$('#banner').classList.remove('show');}SCREENS.forEach(s=>$('#'+s).hidden=s!==id);")
R("  if(G.state!=='world'){$('#wcard').hidden=true;G.cardKey=null;}updateCursor();/*DEVW*/if(window.DEVW)DEVW.ui();}",
  "  if(G.state!=='world'){$('#wcard').hidden=true;G.cardKey=null;}updateCursor();/*DEVW*/if(window.DEVW)DEVW.ui();\n  if(G.state!=='world')joyUnlock();if(!$('#touch').hidden&&isMob())layoutTouch();ctxBtnSync();}\n"
  "document.addEventListener('click',e=>{if(!touchMode)return;const sc=G.scrId,g=TAPGUARD[sc];if(!g||performance.now()-G.scrAt>=g)return;const el=e.target.closest&&e.target.closest('section');if(el&&el.id===sc){e.stopPropagation();e.preventDefault();}},true);")

# ---------- отсчёт после паузы (касания) ----------
R("function resume(){if(G.state!=='pause')return;G.state=G.pausedWorld?'world':'play';show('');}",
  "function resume(){if(G.state!=='pause')return;G.state=G.pausedWorld?'world':'play';show('');if(touchMode&&isMob())G.resumeK=1.2;}")

open(P,'w',encoding='utf8').write(s)
print('m2 ok')
