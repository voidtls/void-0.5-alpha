# 0.9.9 R3: бот босса 50 — знает дыхание, шов, остывание, сбой, стойку, стрелки, нули, негатив, воронку, такт, гонку и выбор.
# Два профиля: «идеальный» (реакция в кадр) и «человек» (HUMAN=1: решения раз в 0,2 с, реакция на телеграф ≥ 0,3 с,
# уклонение рывком в половине случаев, недолёт, шум движения, половину времени игнорирует шов, таранит в трети случаев).
ZBOT="""(o)=>{o=Object.assign({maxSec:900,floor:0,render:0,choice:'auto',human:0,nododge:0,prof:''},o||{});const H=!!o.human,PF=o.prof;const TD=(PF==='nodash'||PF==='still')?(()=>{}):tryDash;
  const p=G.player;let s=0,stageT={},lastStage=0,lastT=0,cycles=0,errs=[],outAcc=0,rams=0,frags=0,stuns=0,dmgLog={},lastHp=p.hp;const st0=G.save.story.zero50;
  const W=(window.__zbS&&window.__zbS.z===G.zb&&o.maxSec<1)?window.__zbS:(window.__zbS={z:G.zb,dT:{x:0,y:0,on:0,until:0},jit:{x:0,y:0,t:0},sm:1,smT:0,seen:new Map()});let ramTry=0;
  const R=Math.random;G.zbLastDeath=null;
  const tgSeen=q=>{if(!W.seen.has(q)){const busy=(G.wtg95||[]).filter(z=>z.st==='warn'&&!z.noHit).length>=2||G.eb.length>10;W.seen.set(q,{t0:G.t,rt:.25+R()*.25,ant:R()<.5,dash:R()<.5,miss:R()<(busy?.35:.15),flip:R()<.12});}return W.seen.get(q);};
  const dodge=()=>{const L=G.wtg95||[];if(H&&W.fr%12!==0&&W.dT.on&&G.t<W.dT.until)return true;W.dT.on=0;
    for(const q of L){if(q.st!=='warn'||q.noHit)continue;const lead=q.T-q.t;if(lead<0||lead>(H?.75:.7))continue;const info=tgSeen(q);if(H&&(G.t-info.t0<info.rt||info.miss))continue;{const lx=p.x+(p.vx||0)*Math.min(lead,.4),ly=p.y+(p.vy||0)*Math.min(lead,.4);if(!tgHit95(q,p.x,p.y,p.r+10)&&(H&&!info.ant||!tgHit95(q,lx,ly,p.r+10)))continue;}
      let a;if(q.k==='line'){const c=Math.atan2(q.y2-q.y,q.x2-q.x);let sgn=((p.x-q.x)*-Math.sin(c)+(p.y-q.y)*Math.cos(c))>=0?1:-1;if(H&&info.flip)sgn=-sgn;a=c+Math.PI/2*sgn;}else{a=Math.atan2(p.y-q.y,p.x-q.x);}
      const dist=H?(R()<.25?150:240):260;W.dT={x:p.x+Math.cos(a)*dist,y:p.y+Math.sin(a)*dist,on:1,until:G.t+.25};
      if(lead<(H?.2:.14)&&p.dashCd<=0&&(!H||info.dash))TD([Math.cos(a),Math.sin(a)]);return true;}return false;};
  const inBox=(x,y)=>{const b=zbBox();return x>b[0]+40&&x<b[2]-40&&y>b[1]+40&&y<b[3]-40;};
  const fitIn=(Z,x,y,f)=>{const q=zbInside(Z,x,y,f||.82);return [q.x,q.y];};
  const outside=(Z,d)=>{const c=zbCen(Z);const b=zbBox();const a0=Math.atan2(p.y-c.y,p.x-c.x);for(let k=0;k<16;k++){const a=a0+(k%2?1:-1)*Math.ceil(k/2)*.4;const r=zbRad(Z,a)+d;const x=c.x+Math.cos(a)*r,y=c.y+Math.sin(a)*r;if(inBox(x,y))return [x,y];}const r=zbRad(Z,a0)+d;return [clamp(c.x+Math.cos(a0)*r,b[0]+60,b[2]-60),clamp(c.y+Math.sin(a0)*r,b[1]+60,b[3]-60)];};
  const t0=performance.now();
  while(s<60*o.maxSec){
    if(G.state==='levelup'){if(pickMode==='zbChoice'){const i=o.choice==='auto'?(choices.includes('third')?choices.indexOf('third'):1):choices.indexOf(o.choice);zbChoose(i>=0?i:0);continue;}choose(Math.random()*choices.length|0);continue;}
    if(G.state!=='world')break;W.fr=(W.fr||0)+1;
    const Z=G.zb;if(!Z){if(G.deadT>0){worldUpdate(1/60);s++;continue;}break;}if(Z.k==='idle')break;
    if(o.floor)p.hp=Math.max(p.hp,o.floor);
    const e=Z.boss;let tx=p.x,ty=p.y;if(p.fireT>1)p.fireT=0;
    if(Z.stage!==lastStage){if(lastStage)stageT[lastStage]=+((Z.T-lastT)).toFixed(1);lastStage=Z.stage;lastT=Z.T;}
    if(Z.cycles>cycles)cycles=Z.cycles;
    if(p.hp<lastHp){const k='s'+Z.stage;dmgLog[k]=(dmgLog[k]||0)+(lastHp-p.hp);}lastHp=p.hp;
    if(H&&G.t>W.jit.t){W.jit={x:R()*120-60,y:R()*120-60,t:G.t+.5};}
    if(H&&G.t>W.smT){W.sm=R()<.5?1:0;W.smT=G.t+3;}if(PF==='naive')W.sm=0;
    if((Z.k==='fight'||Z.k==='seg'||Z.k==='race')&&e&&e.alive){const c=zbCen(Z);if(H)G.prio=null;else{let ne=null,nd=280;for(const q of G.enemies)if(q.alive&&q.zbEsc){const dd=Math.hypot(q.x-p.x,q.y-p.y);if(dd<nd){nd=dd;ne=q;}}G.prio=ne||e;}
      const d=Math.hypot(e.x-p.x,e.y-p.y);const st=Z.stage;const nm=st===3?Z.neg.m:'norm';
      // базовая позиция: за кормой (шов), во время стойки — сбоку, в сбое/остывании — ближе
      const back=Z.face+Math.PI;let want=Z.stun>0||Z.cool>0?220:300;let ang=back;
      if(Z.stance>0)ang=Z.stanceA+Math.PI/2*(angDiff(Math.atan2(p.y-e.y,p.x-e.x),Z.stanceA)>=0?1:-1);
      else if(H&&!W.sm)ang=Math.atan2(p.y-e.y,p.x-e.x)+.6;
      tx=e.x+Math.cos(ang)*want;ty=e.y+Math.sin(ang)*want;
      // обход к корме: он поворачивается медленно — держимся ближе (быстрее по углу), рывок вбок, когда отстали
      if(W.sm&&!(Z.stance>0)&&Z.k==='fight'){const pa=Math.atan2(p.y-e.y,p.x-e.x),off=angDiff(pa,Z.face+Math.PI);want=Z.stun>0||Z.cool>0?220:200;const step=clamp(-off,-.9,.9);const ga=pa+step;tx=e.x+Math.cos(ga)*want;ty=e.y+Math.sin(ga)*want;
        if(!H&&Math.abs(off)>1.3&&p.dashCd<=0&&Z.cool<=0&&Z.stun<=0&&!(G.wtg95||[]).some(q=>q.st==='warn'&&!q.noHit&&tgHit95(q,p.x,p.y,p.r+60))){const sg=off>0?-1:1,tg=pa+sg*1.2;TD([e.x+Math.cos(tg)*want-p.x,e.y+Math.sin(tg)*want-p.y]);}}
      if(Z.k==='race'){const n=zbNode();tx=n.x;ty=n.y;if(W.fr%12===0)TD([n.x-p.x,n.y-p.y]);
        if(!H&&d<150&&Math.hypot(e.x-n.x,e.y-n.y)<Math.hypot(p.x-n.x,p.y-n.y)&&p.dashCd<=0)TD([e.x-p.x,e.y-p.y]);}
      else if(Z.k==='seg'){[tx,ty]=fitIn(Z,p.x,p.y,.5);}
      else{
        if(st===2){// внешнее кольцо: 0,68–0,9 радиуса; таран, когда рядом; на нуле — к краю
          const a=Math.atan2(p.y-c.y,p.x-c.x);const R0=zbRad(Z,a);const rr=Math.hypot(tx-c.x,ty-c.y),ta=Math.atan2(ty-c.y,tx-c.x);const lo=zbRad(Z,ta)*.7,hi=zbRad(Z,ta)*.88;const r2=clamp(rr,lo,hi);tx=c.x+Math.cos(ta)*r2;ty=c.y+Math.sin(ta)*r2;
          if(Z.count<2.6||Z.novaT>0){tx=c.x+Math.cos(a)*R0*.86;ty=c.y+Math.sin(a)*R0*.86;}
          else if(PF!=='naive'&&d<240&&p.dashCd<=0&&Z.ramCd<=0&&Z.lunge<=0){ramTry++;if(!H||R()<.35){TD([e.x-p.x,e.y-p.y]);rams++;}}}
        if(st===3&&(nm==='tg'||nm==='neg')){[tx,ty]=outside(Z,nm==='neg'?150:200);if(nm==='neg'&&e){const a2=Math.atan2(p.y-e.y,p.x-e.x);const q=outside(Z,180);tx=q[0];ty=q[1];}
          if(zbIn(Z,p.x,p.y,0)&&nm==='neg'&&Z.outT>.6&&p.dashCd<=0)TD([tx-p.x,ty-p.y]);}
        else if(st===3&&nm==='back'){[tx,ty]=fitIn(Z,c.x,c.y,.4);}
        // осколки
        if(PF!=='naive')for(const f of Z.frags){const fd=Math.hypot(f.x-p.x,f.y-p.y);if(fd<(H?200:360)){tx=f.x;ty=f.y;break;}}
        // воронка: прочь от ядра
        if(Z.sing&&Z.sing.t>=.8){const s0=Z.sing,a=Math.atan2(p.y-s0.y,p.x-s0.x);const dd=Math.hypot(p.x-s0.x,p.y-s0.y);if(dd<520){tx=p.x+Math.cos(a)*260;ty=p.y+Math.sin(a)*260;}}
        // стрелки: не лезть в сердцевину, когда горят
        if(st===2&&zbHandsOn(Z)&&Z.hands){const a=Math.atan2(ty-c.y,tx-c.x);const lim=zbRad(Z,a)*.6+60;if(Math.hypot(tx-c.x,ty-c.y)<lim){tx=c.x+Math.cos(a)*(lim+30);ty=c.y+Math.sin(a)*(lim+30);}
          const pa=Math.atan2(p.y-c.y,p.x-c.x),pr=Math.hypot(p.x-c.x,p.y-c.y);if(pr<zbRad(Z,pa)*.6+40){for(const ha of Z.hands.a){const dd=Math.abs(angDiff(pa,ha));if(dd<(H?.3:.5)){tx=c.x+Math.cos(pa)*(zbRad(Z,pa)*.75);ty=c.y+Math.sin(pa)*(zbRad(Z,pa)*.75);if(dd<.12&&p.dashCd<=0&&!H)TD([tx-p.x,ty-p.y]);}}}}
        // длинная стрелка: перепрыгнуть рывком назад через неё или обогнать по ходу
        if(st===2&&Z.hands&&zbHandsOn(Z)>0){const a0=Z.hands.a[0],pa=Math.atan2(p.y-c.y,p.x-c.x),pr=Math.hypot(p.x-c.x,p.y-c.y),dA=angDiff(pa,a0);
          if(dA>-.05&&dA<(H?.32:.45)&&pr>60){if(W.hA!==Math.round(Z.T/4))W.hA=Math.round(Z.T/4),W.hJ=!H||R()<.6;
            if(W.hJ&&p.dashCd<=0&&dA<(H?.13:.2)){const b2=a0-.35;TD([c.x+Math.cos(b2)*pr-p.x,c.y+Math.sin(b2)*pr-p.y]);}
            else{const b2=pa+.6;tx=c.x+Math.cos(b2)*Math.min(pr,zbRad(Z,b2)*.85);ty=c.y+Math.sin(b2)*Math.min(pr,zbRad(Z,b2)*.85);}}}
        // мины: не подходить
        for(const m of Z.mines){if(m.t<.6)continue;const md=Math.hypot(m.x-p.x,m.y-p.y);if(md<130){const a=Math.atan2(p.y-m.y,p.x-m.x);tx=p.x+Math.cos(a)*200;ty=p.y+Math.sin(a)*200;}}
        // держаться в фигуре (кроме негатива), с учётом следующего выдоха
        if(!(st===3&&(nm==='neg'||nm==='tg'))){const nx=Z.shape.next;if(nx&&nx.type==='S'){const q=zbPolyOf(nx.kind,nx.s,nx.a,nx.c);const dc=Math.hypot(tx-nx.c.x,ty-nx.c.y),th=Math.atan2(ty-nx.c.y,tx-nx.c.x);const rr=zbR(nx.kind,th,nx.a)*nx.s;if(dc>rr*.78){tx=nx.c.x+Math.cos(th)*rr*.7;ty=nx.c.y+Math.sin(th)*rr*.7;}}
          if(!zbIn(Z,tx,ty,70)){[tx,ty]=fitIn(Z,tx,ty,.78);}
          if(!zbIn(Z,p.x,p.y,0)&&Z.outT>.7&&p.dashCd<=0){const q=fitIn(Z,p.x,p.y,.6);TD([q[0]-p.x,q[1]-p.y]);}}
        if(PF!=='naive'&&p.en>=100&&d<G.st.pR*.85&&(!H||R()<.03))tryPulse();
        // таран сквозь корпус в любой стадии (рывок — неуязвимость), когда рядом и рывок не нужен для уклонения
        if(PF!=='naive'&&st!==2&&d<230&&p.dashCd<=0&&Z.ramCd<=0&&!W.dT.on&&!(Z.stance>0&&Math.abs(angDiff(Math.atan2(p.y-e.y,p.x-e.x),Z.stanceA))<.7)){if(W.rmA!==Math.round(Z.T*2)){W.rmA=Math.round(Z.T*2);W.rmJ=!H||R()<.2;}if(W.rmJ){TD([e.x-p.x,e.y-p.y]);rams++;W.rmJ=0;}}
        // заряженный выстрел в окно остывания/сбоя (человек — изредка)
        {const win=Z.cool>.5||Z.stun>.6||(Z.stance>0&&Math.abs(angDiff(Math.atan2(p.y-e.y,p.x-e.x),Z.stanceA))>.8);if(W.qA!==(win?1:0)){W.qA=win?1:0;W.qJ=win&&PF==='charge';}
          if(W.qJ&&!W.dT.on&&p.chgCd<=0){KEYS.KeyQ=true;if(p.chg>=CHG_T){KEYS.KeyQ=false;W.qJ=0;}}else KEYS.KeyQ=false;}
        if(Z.out)outAcc+=1/60;}
      if(!o.nododge)dodge();}
    // уклонение от снарядов
    {let bb=null,bt=1e9;const SB=W.sb||(W.sb=new WeakMap());for(const q of G.eb){if(q.life<=0||q.rift)continue;if(H){let z=SB.get(q);if(!z){z={t0:G.t,miss:R()<.3};SB.set(q,z);}if(z.miss||G.t-z.t0<.25)continue;}const dx=p.x-q.x,dy=p.y-q.y,dd=Math.hypot(dx,dy);if(dd>260)continue;const sp=Math.hypot(q.vx,q.vy)||1;const along=(dx*q.vx+dy*q.vy)/sp;if(along<0)continue;const perp=Math.abs(dx*q.vy-dy*q.vx)/sp;if(perp>(H?40:60))continue;const tt=along/sp;if(tt<bt){bt=tt;bb=q;}}
      if(bb&&bt<(H?.45:.7)){const sp=Math.hypot(bb.vx,bb.vy)||1;const nx=-bb.vy/sp,ny=bb.vx/sp;const sgn=((p.x-bb.x)*nx+(p.y-bb.y)*ny)>=0?1:-1;tx=p.x+nx*sgn*160;ty=p.y+ny*sgn*160;if(bt<.22&&p.dashCd<=0&&!H)TD([nx*sgn,ny*sgn]);}}
    if(o.nododge){W.dT.on=0;}if(W.dT.on&&PF!=='circle'&&PF!=='still'){tx=W.dT.x;ty=W.dT.y;}
    if(PF==='hug'&&Z&&Z.boss&&Z.boss.alive&&Z.k==='fight'){const e2=Z.boss,a2=Math.atan2(p.y-e2.y,p.x-e2.x);tx=e2.x+Math.cos(a2)*110;ty=e2.y+Math.sin(a2)*110;}
    if(PF==='circle'&&Z&&Z.k==='fight'){const c2=zbCen(Z);W.ca=(W.ca||0)+1/60*300/Math.max(150,zbRad(Z,W.ca||0)*.7);tx=c2.x+Math.cos(W.ca)*zbRad(Z,W.ca)*.7;ty=c2.y+Math.sin(W.ca)*zbRad(Z,W.ca)*.7;}
    if(H){tx+=W.jit.x;ty+=W.jit.y;}
    if(PF==='still'){for(const k of KK)KEYS[k]=false;}else steer2(tx,ty);
    try{worldUpdate(1/60);}catch(err){errs.push(String(err).slice(0,200));break;}
    if(G.zb&&G.zb.nStun!==undefined)stuns=Math.max(stuns,G.zb.nStun+(stageT.__st||0));
    if(o.render&&s%o.render===0){try{renderWorld(performance.now());updateWorldHUD();}catch(err){errs.push('R '+String(err).slice(0,200));break;}}
    s++;}
  for(const k of KK)KEYS[k]=false;const Z=G.zb;if(Z&&lastStage)stageT[lastStage]=+((Z.T-lastT)).toFixed(1);
  for(const k in dmgLog)dmgLog[k]=Math.round(dmgLog[k]);
  return {taken:Math.round(G.taken),sec:Math.round(s/60),state:G.state,k:Z?Z.k:'none',stage:Z?Z.stage:0,stageT,cycles,deaths:G.save.story.cyc.deaths,end:G.save.story.zero50,endBefore:st0,done:zbDone(),hp:Math.round(p.hp),errs,outSec:Math.round(outAcc),nShape:Z?Z.nShape:null,rams,dmg:dmgLog,why:G.zbLastDeath||null,ms:Math.round(performance.now()-t0)};}"""
import asyncio,json,sys,os
from h import *
from h120 import H120
src=open(SP+'q74.py').read();HELP=src[src.index('HELP="""')+8:src.index('"""',src.index('HELP="""')+8)]
async def t(b):
    P=await newpage(b);await P.js(HELP);await P.js(H120)
    hum=int(os.environ.get('HUMAN','0'))
    for d in os.environ.get('DS','easy,mid,hard').split(','):
        for seed in [int(x) for x in os.environ.get('SEEDS','1,2,3').split(',')]:
            await P.js('(sd)=>{Math.random=(()=>{let x=sd;return ()=>{x=(x*16807)%2147483647;return (x-1)/2147483646;};})();}',seed*7919+50)
            flags=json.loads(os.environ.get('FLAGS','{"cradle22":"keep","fleet27":"engine","line31":"write","well38":"answer"}'))
            k=await P.js("(o)=>T.zstart(o)",{'diff':d,'flags':flags})
            r=await P.js(ZBOT,{'maxSec':int(os.environ.get('MAX','900')),'floor':int(os.environ.get('FLOOR','0')),'render':int(os.environ.get('RENDER','0')),'choice':os.environ.get('CHOICE','auto'),'human':hum,'nododge':int(os.environ.get('NODODGE','0')),'prof':os.environ.get('PROF','')})
            why=r['why']['n']+'@'+str(r['why']['stage']) if r['why'] else ''
            print('Z50 %s%s%s seed=%d taken=%s sec=%s k=%s stage=%s cycles=%s deaths=%s done=%s out=%s rams=%s stageT=%s dmg=%s why=%s errs=%s'%(os.environ.get('PROF','')+':' if os.environ.get('PROF') else '','H:' if hum else '',d,seed,r['taken'],r['sec'],r['k'],r['stage'],r['cycles'],r['deaths'],r['done'],r['outSec'],r['rams'],json.dumps(r['stageT']),json.dumps(r['dmg']),why,r['errs'][:2]),flush=True)
            if P.errs:print('  ERRS',P.errs[:3]);P.errs.clear()
if __name__=='__main__':asyncio.run(run([('bots120',t)],'bots120.json'))
