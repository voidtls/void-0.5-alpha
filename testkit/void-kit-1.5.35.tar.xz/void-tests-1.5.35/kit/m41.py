# 1.2.5 α · «Пустота-12»: проигрыватель подложки секторов I–II
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
js=open(D+'m41.js',encoding='utf8').read();i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m41 ok')
