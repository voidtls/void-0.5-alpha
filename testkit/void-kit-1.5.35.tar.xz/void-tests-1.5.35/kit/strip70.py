# Обратное преобразование m70: кандидат 1.5.10 минус блок ARCH·70 и все помеченные места → должен получиться 1.5.9 байт в байт.
D='@@KIT@@/'
def pairs():
    js=open(D+'m70.js',encoding='utf8').read();J=open(D+'m70_journal1510.txt',encoding='utf8').read().strip()
    return [('<div class="ver" id="verTag">1.5.9 α</div>','<div class="ver" id="verTag">1.5.10 α</div>'),
     ("const VER_TAG='1.5.9 α';","const VER_TAG='1.5.10 α';"),
     ('<dl class="kv"><dt>1.5.9 α</dt>','<dl class="kv"><dt>1.5.10 α</dt><dd>'+J+'</dd><dt>1.5.9 α</dt>'),
     ('/* ▲▲▲ ARCH·69 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */\n','/* ▲▲▲ ARCH·69 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */\n'+js+'\n'),
     ("function arch69Ok(){ARCH.err=0;}","function arch69Ok(){if(ARCH.err&&!ARCH.off['A-13']){ARCH.first=null;ARCH.last=null;}ARCH.err=0;ARCH.hudErr=null;}/* ARCH·70 A-13 */"),
     ("function arch69Fault(err){if(ARCH.off['A-4'])return;","function arch69Fault(err){if(!(ARCH.off['A-10']&&ARCH.off['A-12']&&ARCH.off['A-13']))return arch70Fault(err);/* ARCH·70 A-10 A-12 A-13 */if(ARCH.off['A-4'])return;"),
     ("function arch69Backup(){if(ARCH.off['A-2'])return;","function arch69Backup(){if(ARCH.off['A-2'])return;if(!ARCH.off['A-11'])return arch70Backup();/* ARCH·70 A-11 */"),
     ("card=w58POI(card);if(card&&card.kind==='node'&&card.n.m===50&&zbOn())card=null;","card=arch70POI(card,dt);/* ARCH·70 A-9 */if(card&&card.kind==='node'&&card.n.m===50&&zbOn())card=null;"),
     ("if(d<70){f.rep=(f.rep||0)+1/60;G.w.boxing=true;","if(d<70){f.rep=(f.rep||0)+arch70Dt();/* ARCH·70 A-9 */G.w.boxing=true;"),
     ("else{f.rep=Math.max(0,(f.rep||0)-1/60);}","else{f.rep=Math.max(0,(f.rep||0)-arch70Dt());/* ARCH·70 A-9 */}"),
     ("setTimeout(()=>{try{if(G.post)_sx30('dash');}catch(e){}}","setTimeout(()=>{try{if(G.post)(ARCH.off['A-7']||typeof iso63!=='function'?_sx30:iso63(_sx30))('dash');/* ARCH·70 A-7 */}catch(e){}}"),
     ("/* ARCH·69 A-2 · A-3 */arch69Boot();\n","/* ARCH·69 A-2 · A-3 */arch69Boot();\n/* ARCH·70 A-5 A-6 A-8 A-12 */arch70Boot();\n")]
def strip70(s):
    for old,new in pairs():
        if s.count(new)!=1:raise ValueError('strip70: место не найдено ровно один раз: '+new[:60])
        s=s.replace(new,old)
    return s
if __name__=='__main__':
    import sys,hashlib
    t=strip70(open(sys.argv[1],encoding='utf8').read());b=open(D+'void_v47.html',encoding='utf8').read()
    left=[k for k in ['ARCH·70','arch70','A-13','poiDt','hudErr'] if t.count(k)!=b.count(k)]
    print('равно 1.5.9:',t==b,'sha:',hashlib.sha256(t.encode()).hexdigest()[:16],'остатки:',left)
