# 0.6.0 «Мобильная» · часть 1: каркас — версия, мета, иконка, базовый CSS, оси ввода и форм-фактора, «назад»
import sys,os
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m1: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
D=os.path.dirname(os.path.abspath(__file__))
ICON=open(os.path.join(D,'icon180.b64')).read().strip()

# ---------- версия ----------
R('<div class="eyebrow">АЛЬФА 0.5.10 · ЧИСТКА</div>','<div class="eyebrow">АЛЬФА 0.6.0 · МОБИЛЬНАЯ</div>')
R("if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.5.10 α</dt>",
  "if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.6.0 α</dt><dd>«Мобильная». Та же игра, но на телефоне теперь удобно. Картинка крупнее на треть, арена миссии одинакова в любой ориентации (в портрете она больше не коридор), камера ведёт корабль, стрелки на краю показывают врагов и цели за кадром. Новое управление: плавающий стик с мёртвой зоной, дуга кнопок с кольцами перезарядки, рывок свайпом, вибрация, защита от случайного нажатия на экранах поверх боя, отсчёт после паузы. HUD на телефоне сокращён до главного, экраны получили крупные кнопки и закреплённые действия внизу, появился экран настроек (масштаб, размер и прозрачность кнопок, режим левши, игра одной рукой, качество, 30 кадров, крупный текст). Экран не гаснет в бою, системная кнопка «назад» работает как Esc, прогресс сохраняется при сворачивании, есть иконка для экрана «Домой». На компьютере всё как было.</dd><dt>0.5.10 α</dt>")

# ---------- мета и иконка ----------
R('<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">',
  '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,interactive-widget=resizes-content">\n'
  '<meta name="theme-color" content="#04060c">\n<meta name="color-scheme" content="dark">\n'
  '<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="mobile-web-app-capable" content="yes">\n'
  '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\n<meta name="apple-mobile-web-app-title" content="VØID">\n'
  '<link rel="apple-touch-icon" href="data:image/png;base64,'+ICON+'">\n<link rel="icon" type="image/png" href="data:image/png;base64,'+ICON+'">')

# ---------- hover только там, где он есть ----------
for rule in [".btn:hover{border-color:var(--ice-dim);background:rgba(20,36,58,.9);transform:translateX(3px)}",
             ".btn.primary:hover{background:#c4f4ff}",".btn.act2:hover{border-color:var(--amber)}",
             ".card:hover{border-color:var(--violet);transform:translateY(-3px)}",".cards.bcm .card:hover{border-color:var(--amber)}",
             ".mapctl button:hover{border-color:var(--ice)}",".devm:hover{border-color:var(--ice-dim)}"]:
    R(rule,"@media (hover:hover){"+rule+"}")

# ---------- базовый мобильный CSS (только .mob и data-input=touch; ПК не затронут) ----------
CSS=r"""
/* ===================== 0.6.0 «Мобильная» ===================== */
:root{--sat:env(safe-area-inset-top,0px);--sar:env(safe-area-inset-right,0px);--sab:env(safe-area-inset-bottom,0px);--sal:env(safe-area-inset-left,0px);--fs:1;--ba:.7}
html,body{height:100%;height:100dvh;overscroll-behavior:none;-webkit-text-size-adjust:100%;text-size-adjust:100%}
#cv,#hud,#touch{-webkit-touch-callout:none}
button{touch-action:manipulation}
#safeProbe{position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;padding:var(--sat) var(--sar) var(--sab) var(--sal)}
[data-input=touch] kbd:not(#bEndBest){display:none}
[data-input=touch] #bDev kbd{display:inline}
.mobonly{display:none!important}
.mob .mobonly:not([hidden]){display:flex!important}
@media (hover:none){.btn:active,.wbtn:active,.tog:active,.tab:active,.card:active,.seg button:active,.skin:active,.maptabs button:active,.rbtn:active{filter:brightness(1.4);transform:scale(.97)}}
"""
R("</style>",CSS+"</style>",1)
R('<div id="radio" hidden>','<div id="safeProbe"></div>\n<div id="radio" hidden>')

# ---------- оси ввода и форм-фактора ----------
R("let touchMode=window.matchMedia&&matchMedia('(pointer:coarse)').matches;",
r"""let touchMode=window.matchMedia&&matchMedia('(pointer:coarse)').matches;
// 0.6.0: три оси адаптации — ввод (G.input), форм-фактор (G.ff), качество (G.q). ПК (ff-desk + kbm) не меняется.
const MOBQ=window.matchMedia?matchMedia('(pointer:coarse)'):null;
G.input=touchMode?'touch':'kbm';G.ff='desk';G.q=2;
let inputT=0,mouseAcc=0,synthKey=false;
document.documentElement.lang='ru';document.documentElement.dataset.input=G.input;
function setInput(m){if(G.input===m)return;if(G.input==='touch'&&m!=='touch'&&performance.now()-inputT<500)return;
  G.input=m;touchMode=m==='touch';document.documentElement.dataset.input=m;for(const k in hudCache)delete hudCache[k];
  try{ffUpdate();$('#touch').hidden=!(touchMode&&(G.state==='play'||G.state==='world'));updateCursor();renderSettings();G.cardKey=null;if(typeof layoutTouch==='function')layoutTouch();}catch(e){console.error(e);}}
function ffUpdate(){const vv=window.visualViewport,w=vv&&vv.width?vv.width:innerWidth,h=vv&&vv.height?vv.height:innerHeight,sm=Math.min(w,h);
  const dev=(MOBQ&&MOBQ.matches)||G.input==='touch';
  const ff=!dev?'desk':sm<600?(h>w?'phone-p':'phone-l'):sm<=1000?'tablet':'desk';
  G.ff=ff;const c=document.documentElement.classList;for(const k of ['desk','phone-p','phone-l','tablet'])c.toggle('ff-'+k,k===ff);
  c.toggle('mob',ff!=='desk');c.toggle('lefty',ff!=='desk'&&SET.hand==='l');}
function isMob(){return G.ff!=='desk';}
function isPortrait(){return G.ff==='phone-p'||(G.ff==='tablet'&&CH>CW);}
// подсказки управления без клавиш на касаниях
function kh(s){if(!touchMode||typeof s!=='string')return s;
  return s.replace(/\s*\[(?:[A-ZЁ]|ESC|ENTER|TAB)\]/g,'').replace(/WASD или стрелки — движение/g,'Стик слева — движение').replace(/ПРОБЕЛ — рывок/g,'Кнопка РЫВОК — рывок').replace(/E или Shift — импульс/g,'Кнопка ИМП — импульс').replace(/Клик по врагу \(или касание\)/g,'Касание врага').replace(/ · J — все журналы/g,' · журналы — на карте').replace(/J — все журналы/g,'журналы — на карте');}
// системная кнопка «назад» = Esc (только на телефоне и планшете)
let histOn=false;
function histArm(){if(histOn||!isMob())return;try{history.pushState({v:1},'');histOn=true;}catch(e){}}
function escAction(){synthKey=true;try{dispatchEvent(new KeyboardEvent('keydown',{code:'Escape',key:'Escape'}));}finally{synthKey=false;KEYS.Escape=false;}}
addEventListener('popstate',()=>{histOn=false;if(G.state==='menu')return;escAction();histArm();});""")

# keydown: смена оси ввода + «назад» на брифинге/настройках
R("addEventListener('keydown',e=>{\n  if(e.target.tagName==='INPUT')return;",
  "addEventListener('keydown',e=>{\n  if(e.target&&e.target.tagName==='INPUT')return;if(!synthKey&&!e.repeat)setInput('kbm');\n  if(G.state==='settings'&&e.code==='Escape'){closeSettings();return;}\n  if(G.state==='intro'&&e.code==='Escape'&&synthKey){if(!$('#bIntroBack').hidden)$('#bIntroBack').click();return;}")
R("addEventListener('pointermove',e=>{if(e.pointerType!=='mouse')return;MOUSE.sx=e.clientX;MOUSE.sy=e.clientY;if(!MOUSE.moved){MOUSE.moved=true;}});",
  "addEventListener('pointermove',e=>{if(e.pointerType!=='mouse')return;if(G.input!=='kbm'){mouseAcc+=Math.abs(e.movementX||0)+Math.abs(e.movementY||0);if(mouseAcc>8){mouseAcc=0;setInput('kbm');}}MOUSE.sx=e.clientX;MOUSE.sy=e.clientY;if(!MOUSE.moved){MOUSE.moved=true;}});\n"
  "addEventListener('pointerdown',e=>{if(e.pointerType==='touch'){inputT=performance.now();setInput('touch');}else if(e.pointerType==='mouse')setInput('kbm');},true);")

# подсказки без клавиш: HUD, карточка узла, тосты, брифинг
R("function setT(id,v){if(hudCache[id]!==v){","function setT(id,v){if(touchMode)v=kh(v);if(hudCache[id]!==v){")
R("  el.innerHTML=h;el.hidden=false;\n}","  el.innerHTML=kh(h);el.hidden=false;if(typeof ctxBtnSync==='function')ctxBtnSync();\n}")
R("function toast(title,text){$('#toastT').textContent=title;$('#toastP').textContent=text;",
  "function toast(title,text){$('#toastT').textContent=kh(title);$('#toastP').textContent=kh(text);")
R("$('#inHint').innerHTML=M.hint.map(h=>`<p>${secHintFmt(h,i+1)}</p>`).join('')",
  "$('#inHint').innerHTML=M.hint.map(h=>`<p>${kh(secHintFmt(h,i+1))}</p>`).join('')")

# resize: форм-фактор первым делом
R("function resize(){\n  DPR=Math.min(2,window.devicePixelRatio||1);CW=window.innerWidth;CH=window.innerHeight;",
  "function resize(){\n  ffUpdate();DPR=Math.min(2,window.devicePixelRatio||1);CW=window.innerWidth;CH=window.innerHeight;")

open(P,'w',encoding='utf8').write(s)
print('m1 ok')
