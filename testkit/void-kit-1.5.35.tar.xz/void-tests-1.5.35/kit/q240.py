# 1.2.9 α: миссии 15–24 — прочность и урон врагов ×1,5, скорость и темп атак без изменений
import asyncio,os,sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from h import *
OLD=os.environ.get('OLD','file://@@KIT@@/home/void_v30.html')
NEW=os.environ.get('NEW','file://@@KIT@@/home/void.html')
PROBE="""(ms)=>{T.fresh();const out={};const R0=Math.random;Math.random=()=>0.5;
 try{for(const m of ms){const r={};G.mode='world';G.world=false;G.m=m;G.enemies.length=0;
  for(const ty of ['frost','corroder','hunter','guard']){const e=spawnEnemy(ty,600,400,{noAffix:true});r['hp_'+ty]=e.maxHp;r['cur_'+ty]=e.hp;r['spd_'+ty]=e.spd;r['cd_'+ty]=e.cd;}
  G.enemies.length=0;r.sb=sbRank();r.kspd=missionK('spd');r.krate=missionK('rate');
  const p=G.player;Object.assign(p,{inv:0,dashT:0,shieldUp:false,hp:5000});G.deadT=0;G.insp80=0;if(G.x85)G.x85.calm=0;damagePlayer(10);r.dmg=+(5000-p.hp).toFixed(4);p.inv=0;
  out[m]=r;}
  G.world=true;G.m=18;const e=spawnEnemy('frost',600,400,{noAffix:true,noSec:true});out.world=e.maxHp;G.enemies.length=0;
 }finally{Math.random=R0;}return out;}"""
MS=[10,14,15,18,19,22,24,25]
async def probe(b,url):
    pg=await newpage(b,url=url);r=await pg.js(PROBE,MS);return r,pg.errs
async def t1(b):
    o,e1=await probe(b,OLD);n,e2=await probe(b,NEW)
    bad=[];info={}
    for m in MS:
        k=1.5 if 15<=m<=24 else 1
        for ty in ['frost','corroder','hunter','guard']:
            ro=n[str(m)]['hp_'+ty]/o[str(m)]['hp_'+ty];rc=n[str(m)]['cur_'+ty]/o[str(m)]['cur_'+ty]
            if abs(ro-k)>1e-6 or abs(rc-k)>1e-6:bad.append((m,ty,round(ro,3)))
        info[m]=round(n[str(m)]['hp_frost'],1)
    rec('V01 прочность врагов ×1,5 ровно в 15–24, вне — без изменений',not bad and not e1+e2,{'bad':bad[:6],'hp_frost_new':info,'err':(e1+e2)[:2]})
    bad=[]
    for m in MS:
        k=1.5 if 15<=m<=24 else 1
        r=n[str(m)]['dmg']/o[str(m)]['dmg']
        if abs(r-k)>1e-6:bad.append((m,round(r,3)))
    rec('V02 урон по игроку ×1,5 в 15–24',not bad,{'bad':bad,'dmg_new':{m:n[str(m)]['dmg'] for m in MS},'dmg_old':{m:o[str(m)]['dmg'] for m in MS}})
    bad=[]
    for m in MS:
        for ty in ['frost','corroder','hunter','guard']:
            for q in ['spd_','cd_']:
                if abs(n[str(m)][q+ty]-o[str(m)][q+ty])>1e-9:bad.append((m,q+ty))
        for q in ['kspd','krate']:
            if n[str(m)][q]!=o[str(m)][q]:bad.append((m,q))
    rec('V03 скорость полёта и темп атак не изменились',not bad,{'bad':bad[:8]})
    bad=[(m,round(n[str(m)]['sb']/o[str(m)]['sb'],3)) for m in MS if abs(n[str(m)]['sb']/o[str(m)]['sb']-(1.5 if 15<=m<=24 else 1))>1e-6]
    rec('V04 боссы секторов и их части (sbRank) ×1,5 в 15–24',not bad,{'bad':bad})
    rec('V05 открытый космос сектора не затронут',abs(n['world']-o['world'])<1e-6,{'old':o['world'],'new':n['world']})
async def t2(b):
    # настоящий запуск миссии 18 с боссом сектора: прочность босса ×1,5
    res={}
    for tag,url in [('old',OLD),('new',NEW)]:
        pg=await newpage(b,url=url)
        res[tag]=await pg.js("""()=>{T.fresh();const S=G.save;S.cleared=30;S.gate=true;for(let m=1;m<=50;m++)S.medals[m]=S.medals[m]||{};saveWorld();
          const st=T.go(18);let r={st,m:G.m};try{G.waveIdx=G.waves.length;G.enemies.length=0;G.spawnQ.length=0;spawnSB(MISSIONS[17].sboss);r.sb=G.sb&&G.sb.maxHp;r.type=G.sb&&G.sb.type;}catch(e){r.err=String(e).slice(0,200);}
          const p=G.player;Object.assign(p,{inv:0,dashT:0,shieldUp:false,hp:5000});G.deadT=0;damagePlayer(20);r.dmg=5000-p.hp;return r;}""")
        res[tag+'_err']=pg.errs[:2]
    o,n=res['old'],res['new']
    ok=o.get('sb') and n.get('sb') and abs(n['sb']/o['sb']-1.5)<0.01 and abs(n['dmg']/o['dmg']-1.5)<1e-6 and n['st']=='play'
    rec('V06 миссия 18: босс сектора прочнее ×1,5, удар по игроку ×1,5',ok and not res['new_err'],res)
async def t3(b):
    pg=await newpage(b,url=NEW)
    r=await pg.js("()=>({ver:VER_TAG,tag:document.getElementById('verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.2.9 α</dt><dd>Баланс')})")
    rec('V07 версия 1.2.9 α и запись в журнале',r['ver']=='1.2.9 α' and r['tag']=='1.2.9 α' and r['log'],r)
asyncio.run(run([('V01-05',t1),('V06',t2),('V07',t3)],'q240'))
