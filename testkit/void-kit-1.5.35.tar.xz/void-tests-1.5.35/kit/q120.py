# 0.9.9 R3: проверки босса 50 «Нулевой миг» — вход (E), дыхание (B), уязвимость (V), атаки (A), стадии (S), стирание (D), развязка (R), без регрессий (N)
import asyncio,json,sys,os
from h import *
from h120 import H120
src=open(SP+'q74.py').read();HELP=src[src.index('HELP="""')+8:src.index('"""',src.index('HELP="""')+8)]
FL="{cradle22:'keep',fleet27:'engine',line31:'write',well38:'answer'}"
def ok(name,cond,info=None):rec(name,cond,info)
async def page(b,**k):
    P=await newpage(b,**k);await P.js(HELP);await P.js(H120);return P
# ---------- E: вход ----------
async def E(b):
    P=await page(b)
    r=await P.js("""()=>{T.zWorld({flags:"""+FL+"""});const h=$('#wcard').innerHTML;const st=G.state;const n=WORLD.nodes[49];const ok=zbCanStart();const log=[];const p=G.player;const y0=p.y;
      T.zgo();for(let i=0;i<20;i++){T.ztick(.25);const Z=G.zb;log.push([+((i+1)*.25).toFixed(2),Z?Z.k:'-',Math.round(Math.hypot(p.x-n.x,p.y-n.y)),Z?+Z.exp.toFixed(2):0,Z?Z.glitch>0:0,Z?Z.mapStatic:0]);}
      return {card:h.includes('ВОЙТИ В КОМНАТУ'),st,ok,log,box:zbBox(),name:WORLD.sectors[11].name,wsec:$('#wSec').textContent};}""")
    L=r['log'];k=lambda t:[q for q in L if abs(q[0]-t)<.01][0]
    ok('E01 карточка узла 50 — «ВОЙТИ В КОМНАТУ», старт разрешён, сектор XII пока «???»',r['card'] and r['ok'] and r['st']=='world' and r['name']=='???',[r['card'],r['ok'],r['name']])
    ok('E02 первые 2 с — тишина (состояние silence, корабль на месте, карта работает)',k(1.0)[1]=='silence' and k(2.0)[1]=='silence' and k(2.0)[2]<140 and not k(2.0)[5],[k(1.0),k(2.0)])
    ok('E03 на 2,25 с — стены и расширение; к 3,25 с корабль отброшен на 700–950',k(2.25)[1] in ('walls','expand') and 700<=k(3.25)[2]<=1000,[k(2.25),k(3.25)])
    ok('E04 карта в помехах с ~3,5 с, искажённая надпись «точка невозврата» с ~4 с',k(3.75)[5]==1 and k(4.25)[4],[k(3.75),k(4.25)])
    ok('E05 стены: игрок не может покинуть рамку сектора XII (box с отступом 60)',r['box']==[37060,13560,39940,18940],r['box'])
    r=await P.js("""()=>{T.zWorld({flags:"""+FL+"""});T.zgo();let pick=null,t=0;for(let i=0;i<60*9;i++){if(G.state==='levelup'){if(!pick)pick={t:+(i/60).toFixed(2),eyebrow:$('#lvEyebrow').textContent,q:G.lvlQ,k:G.zb.k};let n=0;while(G.state==='levelup'&&n++<40)choose(0);}if(G.state==='world')worldUpdate(1/60);if(G.zb&&G.zb.boss&&!t)t=+(i/60).toFixed(2);}
      const Z=G.zb;return {pick,t,k:Z.k,stage:Z.stage,boss:!!Z.boss,type:Z.boss&&Z.boss.type,m:G.m,lvl:G.lvl};}""")
    ok('E06 ~5 с — выбор стартового комплекта как в миссиях (брифинг), босс выходит ≤2 с после выбора',r['pick'] and 4.5<=r['pick']['t']<=5.6 and 'СТАРТОВЫЙ' in r['pick']['eyebrow'] and r['boss'] and r['type']=='zero000' and r['t']-r['pick']['t']<=2.2 and r['stage']==1 and r['k']=='fight',r)
    r=await P.js("""()=>{T.zWorld({flags:"""+FL+"""});T.zgo();T.ztick(3);openMap('map');drawMap();const q=(G.mapPts||[]).find(z=>z.label==='XI');let deny='';const m0=$('#mapMsg')?$('#mapMsg').textContent:'';if(q){mapJumpAt(q.px,q.py);}const m1=$('#mapMsg')?$('#mapMsg').textContent:'';closeMap();
      const p=G.player;const inb=inXII110(p.x,p.y);T.ztick(.5);return {m1,inb,st:G.state,zb:G.zb.k,mini:typeof zbMini==='function'&&zbMini()};}""")
    ok('E07 в бою прыжок по карте запрещён («ТОЧКА НЕВОЗВРАТА»), корабль остаётся в XII, мини-карта в помехах',('НЕВОЗВРАТА' in r['m1'] or r['m1']=='') and r['inb'] and r['st']=='world' and r['mini'],r)
    r=await P.js("""()=>{T.zWorld({flags:"""+FL+"""});T.zgo();T.ztick(3);const h=$('#wcard').hidden;const k0=G.zb.k;cardAct('main');const k1=G.zb.k;const n=WORLD.nodes[49];T.zpos(n.x,n.y+80);T.ztick(.3);const h2=$('#wcard').innerHTML;return [h,k0,k1,h2.includes('ВОЙТИ')||h2.includes('ВХОД')||h2==='',zbCanStart()];}""")
    ok('E08 повторное нажатие во время входа ничего не ломает',r[1]==r[2] and not r[4],r)
    print('ERRS E',P.errs[:4])
# ---------- B: дыхание ----------
def J(code):
    code=code.replace('__FL__',FL).replace('()=>{',"()=>{let __sd=777;Math.random=()=>{__sd=(__sd*16807)%2147483647;return (__sd-1)/2147483646;};",1)
    if os.environ.get('QDBG'):
        code=code.replace('()=>{','()=>{try{',1);code=code[:code.rindex('}')]+"}catch(err){return {ERR:String(err.stack).slice(0,900)};}}"
    return code
async def B(b):
    P=await page(b)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,p=G.player;Z.boss.alive=false;G.eb=[];G.wtg95=[];
      const log=[],nx=[];const BD=window.zbBreathDone,NS=window.zbNextShape;let hud=null;
      window.zbNextShape=(Z_,f)=>{const r=NS(Z_,f);const q=Z_.shape.next;nx.push([+G.t.toFixed(2),q.type,+Z_.shape.tg.toFixed(2),+q.hold.toFixed(2)]);if(!hud&&nx.length===2)hud=[0,1,2].map(k=>zbBreathType(Z_,k));return r;};
      window.zbBreathDone=(Z_,pv)=>{const r=BD(Z_,pv);log.push([+G.t.toFixed(2),Z_.shape.type,Z_.shape.kind,Math.round(Z_.shape.s)]);return r;};
      for(let i=0;i<60*75;i++){p.hp=G.st.maxHp;const c=zbCen(Z);if(i%20===0)T.zpos(c.x,c.y);if(G.state==='world')worldUpdate(1/60);}
      window.zbBreathDone=BD;window.zbNextShape=NS;return {log,nx,hud,pool:ZB_POOL,band:ZB_BAND[1],floor:ZB_FLOOR};}"""))
    L=r['log'];ty=''.join(q[1] for q in L);sz=[q[3] for q in L]
    exp=[];cur=r['band'][1]
    for t in ty:
        cur=max(r['floor'],min(r['band'][1],max(r['band'][0],cur*(.88 if t=='S' else 1.28))));exp.append(round(cur))
    kinds_ok=all((q[2] in r['pool']['out'][1]) if q[1]=='S' else (q[2] in r['pool']['in'][1]) for q in L)
    ok('B01 ритм дыхания «сжатие, сжатие, расширение» (S S E …), размер ×0,88 / ×1,28 в полосе стадии [560;720], выдох — только выпуклые фигуры, вдох — свои',len(ty)>=6 and ty.startswith('SSESSE') and all(abs(a-e)<=2 for a,e in zip(sz,exp)) and kinds_ok,[ty,sz,exp[:len(sz)]])
    N=r['nx'];holds=[q[3] for q in N];tg=[q[2] for q in N]
    morph=[round(L[i][0]-(N[i][0]+N[i][2]),2) for i in range(min(len(L),len(N)))]
    gap=[round(N[i+1][0]-L[i][0],2) for i in range(min(len(L),len(N)-1))]
    ok('B02 телеграф дыхания 1,8 с, морф 1,2 с, пауза 7,5 с ±5% (Средняя); полоса HUD показывает три следующих вдоха/выдоха верно',all(t==1.8 for t in tg) and all(1.15<=m<=1.25 for m in morph) and all(7.1<=g<=7.9 for g in gap) and r['hud']==list(ty[1:4]),[tg[:4],morph[:4],gap[:4],r['hud'],ty[1:4]])
    r=await P.js(J("""()=>{const out=[];for(let k=0;k<24;k++){T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,p=G.player;T.zsettle();if(k>=12){T.zstage(2+(k%3));T.zsettle();}Z.boss.alive=false;G.eb=[];G.wtg95=[];
        const c=zbCen(Z),a=k*1.7,R=zbRad(Z,a);T.zpos(c.x+Math.cos(a)*R*.9,c.y+Math.sin(a)*R*.9);if(!zbIn(Z,p.x,p.y,0))T.zpos(c.x,c.y);
        Z.br.i=0;zbNextShape(Z);const ty=Z.shape.next.type;for(let i=0;i<200;i++){p.hp=G.st.maxHp;worldUpdate(1/60);if(!Z.shape.next&&Z.shape.morph>=1)break;}
        out.push([Z.stage,ty,Math.round(zbEdgeD(Z,p.x,p.y)),Math.round(Z.shape.s)]);}return out.filter(q=>q[2]<110||q[1]!=='S');}"""))
    ok('B03 выдох никогда не выталкивает: после сжатия игрок внутри с запасом ≥ 100 (24 случая, все стадии, у самой кромки; показаны случаи < 110)',all(q[1]=='S' and q[2]>=100 for q in r),r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,p=G.player;T.zsettle();const c=zbCen(Z),R=zbRad(Z,0);
      Z.mines=[{x:c.x+10,y:c.y,t:2,fuse:-1,hp:2},{x:c.x+R+300,y:c.y,t:2,fuse:-1,hp:2}];zbCloneSpawn(Z);const cl=Z.clones;cl[0].x=c.x+R+260;cl[0].y=c.y;cl[1].x=c.x;cl[1].y=c.y+40;
      Z.shape.type='S';zbBreathDone(Z,null);const er=[Z.mines.length,Z.clones.filter(e=>e.alive).length];
      // вдох: прежняя фигура меньше — осколки в новой зоне
      Z.frags=[];Z.shape.type='E';const pv={kind:'circle',s:Z.shape.s*.75,a:0,c:{x:c.x,y:c.y}};zbBreathDone(Z,pv);const fr=Z.frags.map(f=>[Math.round(Math.hypot(f.x-c.x,f.y-c.y)),zbIn(Z,f.x,f.y,40)]);
      const f=Z.frags[0];p.en=10;G.pb=[];p.fireT=9;Z.stg=0;Z.stgLock=0;Z.stun=0;T.zpos(f.x,f.y);worldUpdate(1/60);return {er,fr,pvR:Math.round(pv.s),en:Math.round(p.en),stg:Math.round(Z.stg)};}"""))
    ok('B04 выдох стирает нули и отражения вне фигуры (внутри — остаются); вдох дарит 1–3 осколка в новой зоне; осколок: +25 энергии, +8 сбоя',r['er']==[1,1] and 1<=len(r['fr'])<=3 and all(q[1] and q[0]>r['pvR']-80 for q in r['fr']) and r['en']==35 and r['stg']==8,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();Z.atkT=99;const out=[];
      for(const k of ['pulse','star','dash']){G.wtg95=[];G.eb=[];Z.cool=0;Z.wind=0;Z.lunge=0;const c=zbCen(Z),R=zbRad(Z,0);e.x=c.x+R-200;e.y=c.y;e.vx=e.vy=0;T.zpos(c.x+R-25,c.y);p.inv=0;p.shieldUp=false;p.hp=G.st.maxHp;zbAtk(Z,k);
        let hit=0;for(let i=0;i<80;i++){const h=p.hp;p.vx=p.vy=0;worldUpdate(1/60);if(p.hp<h)hit=1;if(hit)break;}out.push([k,hit,zbIn(Z,p.x,p.y,0),Math.round(zbEdgeD(Z,p.x,p.y))]);}return out;}"""))
    ok('B05 отброс от удара у самой кромки не выкидывает наружу (импульс, звезда, бросок)',all(q[1]==1 and q[2] for q in r),r)
    print('ERRS B',P.errs[:4])
# ---------- V: уязвимость — урон проходит всегда, мастерство умножает ----------
async def V(b):
    P=await page(b)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();let fr=0,v=0,zero=0;
      for(let i=0;i<60*25;i++){p.hp=G.st.maxHp;Z.hp=Z.segMax*.9;if(G.state==='world')worldUpdate(1/60);if(Z.k==='fight'&&Z.stage===1){fr++;const m=zbMult(Z,e);if(m>0)v++;else zero++;}}
      const set=(ang,st)=>{Z.stun=0;Z.cool=0;Z.stance=0;Z.stg=0;Z.stgLock=9;Object.assign(Z,st||{});T.zpos(e.x+Math.cos(ang)*250,e.y+Math.sin(ang)*250);};
      const hit=(ang,st)=>{set(ang,st);const h=Z.hp;hurt(e,100,{});return Math.round(h-Z.hp);};
      const F=Z.face,front=hit(F),back=hit(F+Math.PI),side=hit(F+Math.PI/2);return {share:+(v/Math.max(1,fr)).toFixed(3),zero,front,back,side};}"""))
    ok('V01 урон проходит всегда: в «Зеркале» множитель > 0 в 100% кадров; база ×1 спереди и сбоку, шов (корма) ×1,5',r['share']==1 and r['zero']==0 and r['front']==100 and r['side']==100 and r['back']==150,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();const F=Z.face;
      const hit=(ang,st,stage)=>{Z.stun=0;Z.cool=0;Z.stance=0;Z.stg=0;Z.stgLock=9;Object.assign(Z,st||{});T.zpos(e.x+Math.cos(ang)*250,e.y+Math.sin(ang)*250);const h=Z.hp;hurt(e,100,{});const d=Math.round(h-Z.hp);Z.hp=h;Z.seg[Z.stage-1]=1;return d;};
      const cool=hit(F,{cool:1}),sc=hit(F+Math.PI,{cool:1}),stun=hit(F,{stun:2}),cap=hit(F+Math.PI,{stun:2,cool:1});
      Z.stage=3;Z.neg={m:'neg',t:1};const neg=hit(F);Z.neg={m:'norm',t:0};Z.stage=4;Z.beatT=.02;const beat=hit(F);Z.beatT=.6;const off=hit(F);Z.stage=1;
      return {cool,sc,stun,cap,neg,beat,off};}"""))
    ok('V02 множители: остывание ×1,5, шов+остывание ×2,25, сбой ×2,5, потолок ×3; негатив ×1,5; в такт ×2, мимо ×1',r=={'cool':150,'sc':225,'stun':250,'cap':300,'neg':150,'beat':200,'off':100},r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();const a=1.0;Z.stance=1.3;Z.stanceA=a;Z.face=a;Z.stgLock=9;
      T.zpos(e.x+Math.cos(a)*250,e.y+Math.sin(a)*250);let h=Z.hp;hurt(e,100,{});const front=Math.round(h-Z.hp),defl=e.deflT>0;
      T.zpos(e.x+Math.cos(a+.75)*250,e.y+Math.sin(a+.75)*250);h=Z.hp;hurt(e,100,{});const edge=Math.round(h-Z.hp);
      T.zpos(e.x+Math.cos(a+Math.PI/2)*250,e.y+Math.sin(a+Math.PI/2)*250);h=Z.hp;hurt(e,100,{});const side=Math.round(h-Z.hp);
      T.zpos(e.x+Math.cos(a+Math.PI)*250,e.y+Math.sin(a+Math.PI)*250);h=Z.hp;hurt(e,100,{});const back=Math.round(h-Z.hp);return {front,defl,edge,side,back};}"""))
    ok('V03 единственный щит — лобовая дуга 70° во время стойки луча (отбивает); сбоку ×2, сзади ×3 (сбоку×шов)',r['front']==0 and r['defl'] and r['edge']==200 and r['side']==200 and r['back']==300,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();const F=Z.face;const rs=()=>{Z.stg=0;Z.stgLock=0;Z.stun=0;Z.cool=0;Z.stance=0;Z.ramCd=0;};
      T.zpos(e.x+Math.cos(F)*250,e.y+Math.sin(F)*250);rs();hurt(e,Z.segMax*.05,{});const pct=+Z.stg.toFixed(1);rs();hurt(e,1,{charged:true});const ch=+Z.stg.toFixed(1);
      rs();T.zpos(e.x+e.r+p.r-2,e.y);p.dashT=.15;G.dashId++;worldUpdate(1/60);const ram=Math.round(Z.stg);p.dashT=0;
      rs();T.zpos(e.x+120,e.y);zbPulse(p,300);const pul=Math.round(Z.stg);
      rs();G.pb=[];Z.stg=50;Z.stgT=G.t-3.05;const s0=Z.stg;for(let i=0;i<60;i++){p.hp=G.st.maxHp;p.fireT=9;worldUpdate(1/60);}const dec=+(s0-Z.stg).toFixed(1);
      rs();G.wtg95=[];Z.atkT=0;T.zpos(e.x+300,e.y);zbAtk(Z,'dash');const tg0=zbBossTg();zbStg(Z,100);const tg1=zbBossTg();const st=[+Z.stun.toFixed(1),Z.stgLock,Z.stg];let made=0;const TG=window.tg95;window.tg95=o=>{if(o.zb&&o.src===e)made++;return TG(o);};for(let i=0;i<172;i++){p.hp=G.st.maxHp;worldUpdate(1/60);}window.tg95=TG;for(let i=0;i<12;i++){p.hp=G.st.maxHp;worldUpdate(1/60);}
      const after=[+Z.stun.toFixed(2),+Z.stgLock.toFixed(1)];zbStg(Z,100);const locked=Z.stun<=0;return {pct,ch,ram,pul,dec,tg0,tg1,st,made,after,locked};}"""))
    ok('V04 сбой: 0,6 за 1% сегмента, заряд +14, таран +30, импульс +25; спад 3/с после 3 с тишины; полная шкала — сбой 3 с (×2,5), телеграфы босса гаснут, 3 с без атак, затем замок 4,5 с',r['pct']==3 and r['ch']==14 and r['ram']==30 and r['pul']==25 and 2.6<=r['dec']<=3.2 and r['tg0']>=1 and r['tg1']==0 and r['st']==[3,4.5,0] and r['made']==0 and r['after'][0]==0 and r['locked'],r)
    print('ERRS V',P.errs[:4])
# ---------- A: атаки и дирижёр ----------
async def A(b):
    P=await page(b)
    r=await P.js(J("""()=>{let sd=4242;Math.random=()=>{sd=(sd*16807)%2147483647;return (sd-1)/2147483646;};const out={};for(const d of ['easy','mid','hard']){T.zstart({diff:d,flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();
        const L=[],tgs=[];const AT=window.zbAtk,TG=window.tg95;let maxAct=0;
        window.zbAtk=(Z_,k)=>{const S=Z_.shape;L.push({k,light:Z_.light,act:zbBossTg(),ex:!!((S.next&&S.next.type==='S')||(S.morph<1&&S.type==='S')),wind:Z_.wind>0,st:Z_.stage});return AT(Z_,k);};
        window.tg95=o=>{if(o&&o.zb)tgs.push([o.T,o.dmg||0,o.nm]);return TG(o);};
        for(let st=1;st<=4;st++){if(st>1){T.zstage(st);T.zsettle();}for(let i=0;i<60*30;i++){p.hp=G.st.maxHp;Z.hp=Math.max(Z.hp,Z.segMax*.65);const c=zbCen(Z),a=G.t*.7,R=zbRad(Z,a)*.6;T.zpos(c.x+Math.cos(a)*R,c.y+Math.sin(a)*R);if(G.state==='world')worldUpdate(1/60);maxAct=Math.max(maxAct,zbBossTg());}}
        window.zbAtk=AT;window.tg95=TG;const D=zbDiffK();
        let trip=0,forceBig=0,forceMiss=0,bigEx=0,overB=0;for(let i=0;i<L.length;i++){const q=L[i];if(i>=2&&L[i-1].k===q.k&&L[i-2].k===q.k&&L[i-1].st===q.st&&L[i-2].st===q.st)trip++;if(q.light>=2&&!q.wind&&!q.ex){forceBig++;if(!ZB_ATK[q.k].big)forceMiss++;}if(q.ex&&ZB_ATK[q.k].big)bigEx++;if(q.act>=D.budget)overB++;}
        const per=[1,2,3,4].map(s=>L.filter(q=>q.st===s).length);
        out[d]={n:L.length,per,trip,forceBig,forceMiss,bigEx,overB,maxAct,budget:D.budget,minT:Math.min(...tgs.map(q=>q[0])),heavyT:Math.min(9,...tgs.filter(q=>q[1]>=20).map(q=>q[0])),kinds:[...new Set(L.map(q=>q.k))].sort()};}return out;}"""))
    ok('A01 дирижёр: атака не начинается при полном бюджете угроз (2/3/4), без тройных повторов, после двух лёгких — крупная, крупных нет во время выдоха; темп 9–16 атак на стадию за 30 с',all(v['trip']==0 and v['forceMiss']<=1 and v['bigEx']==0 and v['overB']==0 and all(6<=x<=18 for x in v['per']) for v in r.values()),{k:{j:v[j] for j in ['n','per','trip','forceBig','forceMiss','bigEx','overB','maxAct','budget']} for k,v in r.items()})
    ok('A02 все телеграфы ≥ 0,6 с, тяжёлые (≥20) ≥ 0,7 с; на каждой сложности ≥ 8 видов атак за 2 минуты, все 10 встречаются',all(v['minT']>=.6 and v['heavyT']>=.7 and len(v['kinds'])>=8 for v in r.values()) and set(r['easy']['kinds'])|set(r['mid']['kinds'])|set(r['hard']['kinds'])>={'dash','dashfan','fan','fan2','pulse','beam','repeat','mines','star','burst'},{k:[v['minT'],v['heavyT'],v['kinds']] for k,v in r.items()})
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();Z.atkT=99;G.wtg95=[];G.eb=[];e.x=zbCen(Z).x;e.y=zbCen(Z).y;
      // бросок с упреждением: игрок бежит по касательной, линия смотрит вперёд и замирает за 0,3 с
      T.zpos(e.x+300,e.y);zbAtk(Z,'dash');const o=G.wtg95.find(q=>q.nm==='dash');const W=o.w,TT=o.T;const angs=[];let lead=null;for(let i=0;i<53;i++){p.hp=G.st.maxHp;KEYS['KeyS']=true;worldUpdate(1/60);if(o.st==='warn'){const la=Math.atan2(o.y2-o.y,o.x2-o.x),pa=Math.atan2(p.y-o.y,p.x-o.x);angs.push([+(o.T-o.t).toFixed(2),+la.toFixed(4)]);if(lead===null&&o.T-o.t<=.3)lead=+(la-pa).toFixed(2);}}KEYS['KeyS']=false;
      const last=angs.filter(q=>q[0]<=.28);const locked=last.length>2&&Math.abs(last[0][1]-last[last.length-1][1])<.002;
      // бросок-веер: после выпада — конус 0,55 с с точки приземления, 7 пуль
      G.wtg95=[];G.eb=[];Z.lunge=0;Z.cool=0;Z.wind=0;T.zpos(e.x+300,e.y);Z.seq.push('dashfan');zbAtk(Z,'dashfan');let cone=null,bul=0;for(let i=0;i<120;i++){p.hp=G.st.maxHp;p.inv=1;worldUpdate(1/60);const q=G.wtg95.find(z=>z.nm==='dashfan');if(q&&!cone)cone=[+q.T.toFixed(2),q.k];}bul=G.eb.filter(b=>b.zbN==='dashfan').length;
      return {W,TT,locked,lead,cone,bul,cool:Z.cool>0||Z.hint.cool};}"""))
    ok('A03 бросок: линия 76, 0,9 с, ведёт с упреждением и замирает за 0,3 с; бросок-веер: после выпада конус 0,6 с и 7 пуль, потом остывание',r['W']==76 and r['TT']==.9 and r['locked'] and r['lead'] is not None and r['lead']>0 and r['cone']==[.6,'cone'] and r['bul']>=6,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();Z.atkT=99;const c=zbCen(Z);e.x=c.x;e.y=c.y;const go=()=>{G.wtg95=[];G.eb=[];Z.cool=0;Z.wind=0;Z.stance=0;Z.burst=null;T.zpos(e.x+420,e.y);};
      go();zbAtk(Z,'star');const z=G.wtg95.find(q=>q.nm==='star');const zr=[z.r,z.T];for(let i=0;i<64;i++){p.hp=G.st.maxHp;p.inv=1;worldUpdate(1/60);}const star=G.eb.filter(b=>b.zbN==='star').length,starCool=Z.cool>0;
      go();Z.stage=1;zbAtk(Z,'burst');const tt=[];let n0=0;for(let i=0;i<60;i++){p.hp=G.st.maxHp;p.inv=1;worldUpdate(1/60);const n=G.eb.filter(b=>b.zbN==='burst').length;if(n>n0){tt.push(+(i/60).toFixed(2));n0=n;}}
      go();Z.stage=3;Z.neg={m:'norm',t:0};zbAtk(Z,'burst');let b3=0;for(let i=0;i<70;i++){p.hp=G.st.maxHp;p.inv=1;worldUpdate(1/60);}b3=G.eb.filter(b=>b.zbN==='burst').length;Z.stage=1;
      go();for(let i=0;i<130;i++){p.hp=G.st.maxHp;KEYS['KeyS']=true;worldUpdate(1/60);}KEYS['KeyS']=false;zbAtk(Z,'repeat');const rep=G.wtg95.filter(q=>q.nm==='repeat').map(q=>[q.r,q.T]);
      go();zbAtk(Z,'pulse');const pz=G.wtg95.find(q=>q.nm==='pulse');const pr=[pz.r,pz.T];for(let i=0;i<64;i++){p.hp=G.st.maxHp;worldUpdate(1/60);}const pcool=+Z.cool.toFixed(1);
      return {zr,star,starCool,tt,b3,rep,pr,pcool};}"""))
    ok('A04 звезда: круг 300 / 1 с, затем 12 пуль и остывание; очередь: заряд 0,6 с и 3 пули через 0,16 с (с «Негатива» — 4); повтор: 5 зон 70 по вашему следу; импульс: круг 300 / 1 с, остывание 1 с',r['zr']==[300,1] and r['star']==12 and r['starCool'] and len(r['tt'])==3 and r['tt'] and .58<=r['tt'][0]<=.65 and all(.13<=r['tt'][i+1]-r['tt'][i]<=.19 for i in range(2)) and r['b3']==4 and len(r['rep'])==5 and all(q==[70,.9] for q in r['rep']) and r['pr']==[300,1] and .9<=r['pcool']<=1.0,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();Z.atkT=99;const c=zbCen(Z);e.x=c.x;e.y=c.y;G.wtg95=[];G.eb=[];T.zpos(e.x+500,e.y);
      zbAtk(Z,'mines');const dbg=[];for(let i=0;i<80;i++){p.hp=G.st.maxHp;p.fireT=9;G.pb=[];worldUpdate(1/60);if(i%10===0)dbg.push([Z.mineDrop,Z.mines.length,Z.stun,Z.k,Z.stage,e.alive,G.state]);}const n=Z.mines.length;if(!n)return {n,dbg};
      const m=Z.mines[0];m.t=1;p.shieldUp=false;const hp0=p.hp;p.inv=0;p.dashT=0;T.zpos(m.x+60,m.y);let armAt=null,boom=null;for(let i=0;i<40;i++){p.fireT=9;G.pb=[];worldUpdate(1/60);if(armAt===null&&m.fuse>=0)armAt=i/60;if(boom===null&&!Z.mines.includes(m))boom=+(i/60).toFixed(2);}const hurtM=Math.round(hp0-p.hp);
      Z.mines=[{x:e.x+200,y:e.y+300,t:2,fuse:-1,hp:2},{x:e.x-200,y:e.y-300,t:2,fuse:-1,hp:2}];const m2=Z.mines[0];T.zpos(m2.x+400,m2.y);p.hp=G.st.maxHp;for(let k=0;k<2;k++)G.pb.push({x:m2.x,y:m2.y,px:m2.x,py:m2.y,vx:0,vy:0,dmg:1,pierce:0,rico:0,life:.5,hit:[]});worldUpdate(1/60);const shot=m2.fuse>=0;
      const m3=Z.mines.find(q=>q!==m2&&q.fuse<0);let pul=null;if(m3){T.zpos(m3.x+150,m3.y);zbPulse(p,300);pul=m3.fuse>=0;}
      Z.mines=[{x:e.x+800,y:e.y,t:5.4,fuse:-1,hp:2}];T.zpos(e.x-700,e.y);for(let i=0;i<20;i++){p.hp=G.st.maxHp;worldUpdate(1/60);}const self=Z.mines.length===0;
      for(let k=0;k<4;k++){Z.mineDrop=3;Z.mineDT=0;for(let i=0;i<80;i++){p.hp=G.st.maxHp;worldUpdate(1/60);}}const cap=Z.mines.length;
      return {n,armAt,boom,hurtM,shot,pul,self,cap};}"""))
    ok('A05 нули: три за ~1,2 с; взвод 0,8 с, вблизи 80 — фитиль 0,25 с и взрыв; два попадания — взрыв; импульс поджигает; сами взрываются через 5,5 с; не больше 6',r['n']==3 and r['armAt'] is not None and r['boom'] is not None and .2<=r['boom']-r['armAt']<=.35 and r['hurtM']>0 and r['shot'] and r['pul'] in (True,None) and r['self'] and r['cap']<=6,r)
    print('ERRS A',P.errs[:4])
# ---------- S: стадии ----------
async def S(b):
    P=await page(b)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();Z.atkT=99;const dd=[];
      for(let k=0;k<6;k++){const c=zbCen(Z),a=k*1.1,R=zbRad(Z,a)*.5;T.zpos(c.x+Math.cos(a)*R,c.y+Math.sin(a)*R);for(let i=0;i<120;i++){p.hp=G.st.maxHp;Z.atkT=99;p.vx=p.vy=0;T.zpos(c.x+Math.cos(a)*R,c.y+Math.sin(a)*R);worldUpdate(1/60);}const c2=zbCen(Z);dd.push([Math.round(Math.hypot(e.x-p.x,e.y-p.y)),Math.round(Math.hypot(e.x-(2*c2.x-p.x),e.y-(2*c2.y-p.y)))]);}
      Z.hp=Z.segMax*.49;worldUpdate(1/60);const cl=Z.clones.filter(q=>q.alive);const chp=cl.map(q=>q.cmax);const h0=Z.hp;Z.stg=0;Z.stgLock=0;Z.stun=0;cl[0].chp=1;hurt(cl[0],5,{});const lost=+((h0-Z.hp)/Z.segMax).toFixed(3),stg=Math.round(Z.stg);
      hurt(cl[1],1e6,{});let reAt=null;for(let i=0;i<60*14;i++){p.hp=G.st.maxHp;Z.hp=Math.max(Z.hp,Z.segMax*.3);Z.atkT=99;worldUpdate(1/60);if(reAt===null&&Z.clones.some(q=>q.alive))reAt=+(i/60).toFixed(1);}
      return {dd,n:cl.length,chp,seg5:Math.max(60,Math.round(Z.segMax*.05)),lost,stg,reAt};}"""))
    ok('S01 «Зеркало»: он в зеркальной точке (260–440 от вас); на 50% — два отражения (5% сегмента); разбитое: −3% и +15 сбоя; обе разбиты — через 12 с вернутся',all(250<=q[0]<=450 for q in r['dd']) and r['n']==2 and all(x==r['seg5'] for x in r['chp']) and abs(r['lost']-.03)<.002 and r['stg']==15 and r['reAt'] is not None and 11.5<=r['reAt']<=12.6,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zstage(2);T.zsettle();Z.atkT=99;if(Z.shape.kind==='ring'){Z.shape.kind='circle';}const H=Z.hands;H.t=0;const a0=H.a.slice();
      for(let i=0;i<60;i++){p.hp=G.st.maxHp;Z.atkT=99;Z.count=15;worldUpdate(1/60);}const w=[+(H.a[0]-a0[0]).toFixed(2),+(H.a[1]-a0[1]).toFixed(2)];
      const ph=[];for(const t of [1,6.9,7.5,8.5]){H.t=t;ph.push(zbHandsOn(Z));}H.t=1;
      const c=zbCen(Z);const a=H.a[0],R=zbRad(Z,a);H.cd=0;p.inv=0;p.dashT=0;T.zpos(c.x+Math.cos(a)*R*.85,c.y+Math.sin(a)*R*.85);const hp0=p.hp;zbHandsTick(Z,1/60);const long=Math.round(hp0-p.hp);const pa=Math.atan2(p.y-c.y,p.x-c.x);const behind=+angDiff(pa,H.a[0]).toFixed(2);
      H.cd=0;p.inv=0;const a1=H.a[1],R1=zbRad(Z,a1);T.zpos(c.x+Math.cos(a1)*R1*.4,c.y+Math.sin(a1)*R1*.4);const hp1=p.hp;zbHandsTick(Z,1/60);const short=Math.round(hp1-p.hp);const out1=Math.round(Math.hypot(p.x-c.x,p.y-c.y)/R1*100)/100;
      H.cd=0;p.inv=0;p.dashT=.1;T.zpos(c.x+Math.cos(a)*R*.85,c.y+Math.sin(a)*R*.85);const hp2=p.hp;zbHandsTick(Z,1/60);const dashed=hp2===p.hp;p.dashT=0;
      Z.count=10;Z.ramCd=0;Z.stg=0;Z.stgLock=0;G.pb=[];p.fireT=9;Z.frags=[];G.wtg95=[];Z.wind=0;Z.burst=null;Z.lunge=0;Z.stall=.3;e.vx=e.vy=0;T.zpos(e.x+e.r+p.r-2,e.y);p.dashT=.15;G.dashId++;const dbg0=[Math.round(e.x-p.x),Math.round(e.y-p.y),Z.ramId,G.dashId,Z.ramCd,Z.stun,Z.stgLock,Z.k];worldUpdate(1/60);const dbg1=[Math.round(e.x-p.x),Math.round(e.y-p.y),Z.ramId,p.dashT,Z.count];const ram=[+Z.count.toFixed(1),Math.round(Z.stg)];p.dashT=0;
      Z.count=.02;Z.stun=0;T.zpos(c.x+R*.85,c.y);worldUpdate(1/60);worldUpdate(1/60);const nv=G.wtg95.find(q=>q.nm==='nova');const nova=nv?[nv.T,Math.round(nv.r/zbRad(Z,0)*100)/100]:null;for(let i=0;i<80;i++){p.hp=G.st.maxHp;worldUpdate(1/60);}
      return {dbg0,dbg1,w,ph,long,behind,short,out1,dashed,ram,nova,cool:+Z.cool.toFixed(1),cnt:Math.round(Z.count),dmg10:zbDmg(10)};}"""))
    ok('S02 «Отсчёт»: длинная стрелка (0,97 R) и короткая (0,6 R) крутятся в разные стороны по 0,42 рад/с; горят 7 с, гаснут, мигают; длинная бьёт 10 и сносит за себя; короткая — наружу; рывок проходит; таран +4 с и +30 сбоя; на нуле — зона 0,6 R / 1,2 с, затем остывание 2 с',r['w']==[.42,-.42] and r['ph']==[1,1,0,.5] and r['long']==r['dmg10'] and r['behind']<0 and r['short']==r['dmg10'] and r['out1']>=.6 and r['dashed'] and r['ram']==[14,30] and r['nova']==[1.2,.6] and 1.4<=r['cool']<=2.0,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zstage(3);T.zsettle();Z.sing=null;const seq=[];let last='';let t0=G.t;let br=0,brNeg=0,outB=null,mulNeg=null,badIn=null;const nS0=Z.nShape;
      for(let i=0;i<60*20;i++){p.hp=G.st.maxHp;Z.hp=Math.max(Z.hp,Z.segMax*.5);const c=zbCen(Z),R=zbRad(Z,0);if(Z.neg.m==='neg'||Z.neg.m==='tg')T.zpos(c.x+R+180,c.y);else T.zpos(c.x+R*.5,c.y);worldUpdate(1/60);
        if(Z.neg.m!==last){seq.push([Z.neg.m,+(G.t-t0).toFixed(1)]);last=Z.neg.m;if(Z.neg.m==='neg'){const nS=Z.nShape;brNeg=nS;}if(Z.neg.m==='back'){brNeg=Z.nShape-brNeg;}}
        if(Z.neg.m==='neg'&&Z.neg.t>2.5&&outB===null){outB=!zbIn(Z,e.x,e.y,0);mulNeg=zbMult(Z,e);const q=zbCen(Z);const px=p.x,py=p.y;T.zpos(q.x,q.y);badIn=(Z.out===0);T.zpos(px,py);}}
      return {seq,brNeg,outB,mulNeg};}"""))
    s3=r['seq'];names=[q[0] for q in s3]
    ok('S03 «Негатив»: цикл норм → телеграф 1,5 с → негатив 6 с → возврат 1,5 с; дыхание стоит; он выходит наружу и открыт ×1,5 (и больше)',('tg' in names and names[names.index('tg'):names.index('tg')+4]==['tg','neg','back','norm']) and r['brNeg']==0 and r['outB'] and r['mulNeg']>=1.5,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zstage(3);T.zsettle();Z.sing=null;zbSingStart(Z);const s=Z.sing;T.zpos(s.x+300,s.y);for(let i=0;i<60*1.05;i++){p.hp=G.st.maxHp;p.vx=p.vy=0;worldUpdate(1/60);}const d0=Math.hypot(p.x-s.x,p.y-s.y);for(let i=0;i<60;i++){p.hp=G.st.maxHp;worldUpdate(1/60);}const pulled=Math.round(d0-Math.hypot(p.x-s.x,p.y-s.y));
      T.zpos(s.x+20,s.y);p.inv=0;p.dashT=0;p.shieldUp=false;const h=p.hp;s.cd=0;zbSingTick(Z,1/60);const core=Math.round(h-p.hp);for(let i=0;i<180;i++)worldUpdate(1/60);return {pulled,core,gone:!Z.sing,d10:zbDmg(10)};}"""))
    ok('S04 воронка на вдохе «Негатива»: 1 с — предупреждение, затем тянет ~140/с, ядро 60 бьёт 10, живёт 3,5 с',100<=r['pulled']<=180 and r['core']==r['d10'] and r['gone'],r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zstage(4);T.zsettle();const n=zbNode();const c=zbCen(Z);const nearNode=Math.round(Math.hypot(c.x-n.x,c.y-n.y));const stars=Z.stars.map(s=>s.name);
      T.zpos(n.x+200,n.y);let reds=0,beatsAt=[];const TG=window.tg95,AT=window.zbAtk;let onBeat=0,offBeat=0;window.tg95=o=>{if(o.nm==='beat'){reds++;}return TG(o);};window.zbAtk=(Z_,k)=>{if(Z_.beatT<.05||Z_.onBeat)onBeat++;else offBeat++;return AT(Z_,k);};
      for(let i=0;i<60*12;i++){p.hp=G.st.maxHp;Z.hp=Math.max(Z.hp,Z.segMax*.7);worldUpdate(1/60);}window.tg95=TG;window.zbAtk=AT;
      const h2=Z.hp;const inR=Z.stars.filter(s=>Math.hypot(s.x-e.x,s.y-e.y)<1100).length;for(const s of Z.stars)s.cd=0;G.pb=[];p.fireT=9;worldUpdate(1/60);const ally=+((h2-Z.hp)/Z.segMax).toFixed(4);
      Z.hp=Z.segMax*.59;Z.cloneDone=0;worldUpdate(1/60);const cl=Z.clones.filter(q=>q.alive).length;for(const q of Z.clones)q.alive=false;let again=0;for(let i=0;i<60*14;i++){p.hp=G.st.maxHp;Z.hp=Math.max(Z.hp,Z.segMax*.4);worldUpdate(1/60);if(Z.clones.some(q=>q.alive))again=1;}
      return {nearNode,stars,third:Z.thirdOK,reds,onBeat,offBeat,ally,inR,cl,again};}"""))
    ok('S05 «Кнопка»: фигура у кнопки (≤220); созвездие из помилованных, третий путь; атаки стартуют на ударе сердца; красный выпад на каждый 4-й удар (≥2 за 12 с); союзники в радиусе 1100 — по −0,35%; на 60% — два отражения один раз',r['nearNode']<=222 and r['stars']==['КОЛЫБЕЛЬ','ФЛОТ','ЛИНИЯ','КОЛОДЕЦ'] and r['third'] and r['onBeat']>=2 and r['offBeat']==0 and r['reds']>=1 and r['inR']>=1 and abs(r['ally']-.0035*r['inR'])<.0006 and r['cl']==2 and r['again']==0,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zstage(4);T.zsettle();const n=zbNode();
      Z.hp=Z.segMax*.29;worldUpdate(1/60);const warn=Z.hint.race===1;Z.hp=Z.segMax*.19;worldUpdate(1/60);const race=Z.k,rad=Math.round(Z.shape.s);
      G.pb=[];p.fireT=9;e.x=n.x+300;e.y=n.y;T.zpos(n.x+320,n.y);Z.ramCd=0;p.dashT=.15;G.dashId++;worldUpdate(1/60);const stall=+Z.stall.toFixed(2);p.dashT=0;
      e.x=n.x+20;e.y=n.y;Z.stall=0;T.zpos(n.x+600,n.y);for(let i=0;i<30;i++){if(G.state==='world')worldUpdate(1/60);T.zpos(n.x+600,n.y);}const cyc=Z.cycles,k2=Z.k,hp60=Z.hp/Z.segMax<=.6&&Z.hp/Z.segMax>.5;
      Z.hp=Z.segMax*.19;worldUpdate(1/60);e.x=n.x+800;e.y=n.y;Z.stall=1e9;T.zpos(n.x+10,n.y);for(let i=0;i<10;i++){if(G.state==='world')worldUpdate(1/60);}const k3=Z.k;for(let i=0;i<100&&G.state==='world';i++)worldUpdate(1/60);
      return [warn,race,rad,stall,cyc,k2,hp60,k3,G.state,pickMode,choices];}"""))
    ok('S06 гонка: на 30% предупреждение, на 20% — гонка (круг 300 у кнопки); рывок сквозь него — сбит на 0,6 с; он первым — цикл заново с 60%; вы первым — выбор из трёх',r[0] and r[1]=='race' and r[2]==300 and .55<=r[3]<=.6 and r[4]==1 and r[5]=='fight' and r[6] and r[7]=='choice' and r[8]=='levelup' and r[9]=='zbChoice' and r[10]==['erase','recall','third'],r)
    print('ERRS S',P.errs[:4])
# ---------- X: R4 — вспышка, тройной бросок, решётка, спутники, эхо, ярость, уход с арены ----------
async def X(b):
    P=await page(b)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zstage(2);T.zsettle();Z.atkT=99;G.wtg95=[];G.eb=[];const c=zbCen(Z);e.x=c.x;e.y=c.y;T.zpos(c.x+200,c.y+60);
      zbAtk(Z,'blink');const o=G.wtg95.find(q=>q.nm==='blink');const mk=[o.T,o.r,Math.round(Math.hypot(o.x-p.x,o.y-p.y))];let tp=null,bu=0;for(let i=0;i<115;i++){p.hp=G.st.maxHp;p.inv=1;T.zpos(c.x+200,c.y+60);Z.atkT=99;worldUpdate(1/60);if(tp===null&&Math.hypot(e.x-o.x,e.y-o.y)<30)tp=+(i/60).toFixed(2);}bu=G.eb.filter(q=>q.zbN==='burst').length;
      // тройной бросок
      G.wtg95=[];G.eb=[];Z.cool=0;Z.wind=0;e.x=c.x;e.y=c.y;const lines=[];let silent=1;const AT=window.zbAtk;window.zbAtk=(a,k)=>{silent=0;return AT(a,k);};AT(Z,'tridash');Z.atkT=0;
      let cool=0;for(let i=0;i<60*4.4;i++){p.hp=G.st.maxHp;p.inv=1;worldUpdate(1/60);cool=Math.max(cool,Z.cool);for(const q of G.wtg95)if(q.nm==='tridash'&&!q._s){q._s=1;lines.push(+q.T.toFixed(2));}}window.zbAtk=AT;cool=+cool.toFixed(1);
      // решётка
      Z.stage=4;G.wtg95=[];Z.cool=0;Z.wind=0;Z.chainLock=0;zbAtk(Z,'grid');const gl=G.wtg95.filter(q=>q.nm==='grid');const th=Math.atan2(p.y-e.y,p.x-e.x);const offs=gl.map(q=>{const mx=(q.x+q.x2)/2,my=(q.y+q.y2)/2;return Math.round(((mx-p.x)*-Math.sin(th)+(my-p.y)*Math.cos(th)));}).sort((a,b)=>a-b);
      const gT=gl.map(q=>q.T).sort();const sub=gl.filter(q=>q.sub).length;for(let i=0;i<100;i++){p.hp=G.st.maxHp;p.inv=1;worldUpdate(1/60);}const gcool=Z.cool>0||Z.hint.cool;Z.stage=2;
      return {mk,tp,bu,lines,silent,cool,offs,gT,sub,gcool,w:gl[0]&&gl[0].w};}"""))
    ok('X01 вспышка: метка 0,6 с радиусом 80 в ~310 от вас, он появляется в ней и сразу даёт очередь из 3',r['mk'][0]==.6 and r['mk'][1]==80 and 230<=r['mk'][2]<=400 and r['tp'] is not None and .55<=r['tp']<=.7 and r['bu']==3,r)
    ok('X02 тройной бросок: три красные линии (0,9 · 0,7 · 0,7 с) подряд, дирижёр молчит, после — остывание ~1,8 с',r['lines']==[.9,.7,.7] and r['silent']==1 and 1.5<=r['cool']<=1.8,r)
    ok('X03 решётка: пять линий 56 через 240 (вы — на средней), телеграф 1,1–1,4 с, четыре — «довесок» к одной угрозе, после — остывание',r['offs']==[-480,-240,0,240,480] and r['gT'][0]==1.1 and abs(r['gT'][-1]-1.4)<1e-9 and r['sub']==4 and r['w']==56 and r['gcool'],r)
    r=await P.js(J("""()=>{const out={};T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;const cnt=[];for(let n=1;n<=4;n++){T.zstage(n);cnt.push(Z.sats.length);}
      T.zstage(3);T.zsettle();Z.atkT=99;Z.neg={m:'norm',t:0};const s0=Z.sats[0];T.zpos(e.x+600,e.y);G.eb=[];let shots=0;const seenB=new Set();for(let i=0;i<60*7;i++){p.hp=G.st.maxHp;p.inv=1;p.fireT=9;G.pb=[];Z.atkT=99;Z.neg.t=0;Z.hp=Z.segMax;T.zpos(e.x+600,e.y);worldUpdate(1/60);for(const b of G.eb)if(b.zbN==='sat'&&!seenB.has(b)){seenB.add(b);shots++;}}
      Z.stg=0;Z.stgLock=0;Z.stun=0;const s=Z.sats[0];T.zpos(s.x,s.y);p.dashT=.15;G.dashId++;Z.ramCd=99;worldUpdate(1/60);p.dashT=0;const killed=Z.sats.length,stg=Math.round(Z.stg);
      const s2=Z.sats[0];zbPulse({x:s2.x+50,y:s2.y},300);worldUpdate(1/60);const left=Z.sats.length;let re=null;for(let i=0;i<60*16;i++){p.hp=G.st.maxHp;p.fireT=9;G.pb=[];Z.atkT=99;Z.neg.t=0;Z.hp=Z.segMax;worldUpdate(1/60);if(re===null&&Z.sats.length)re=+(i/60).toFixed(1);}
      return {cnt,shots,killed,stg,left,re};}"""))
    ok('X04 спутники: 0/1/2/2 по стадиям, стреляют раз в 3,2 с, таран сбивает (+10 сбоя), импульс сбивает, через 15 с возвращаются',r['cnt']==[0,1,2,2] and 3<=r['shots']<=5 and r['killed']==1 and r['stg']==10 and r['left']==0 and r['re'] is not None and 14.5<=r['re']<=15.6,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();let rAt=null,sAt=null,n=0;for(let i=0;i<60*14;i++){p.hp=G.st.maxHp;Z.hp=Z.segMax*.9;Z.atkT=99;worldUpdate(1/60);if(rAt===null&&Z.rifts.length){rAt=+(G.zb.T-Z.stT).toFixed(1);n=Z.rifts.length;}if(sAt===null&&zbEchoAlive()){sAt=+(G.zb.T-Z.stT).toFixed(1);}}
      const c=zbCen(Z),rf=Z.echoes.map(q=>Math.round(zbEdgeD(Z,q.x,q.y)));const q=Z.echoes[0];const en0=p.en=10;Z.stg=0;Z.stgLock=0;q.hp=1;hurt(q,999,{});for(let i=0;i<3;i++)worldUpdate(1/60);const en=Math.round(p.en),stg=Math.round(Z.stg);
      Z.echoT=0;zbEchoWave(Z,9);const capped=zbEchoAlive()+Z.rifts.filter(x=>!x.done).length;for(let i=0;i<80;i++){p.hp=G.st.maxHp;worldUpdate(1/60);}
      const far=Z.echoes[0];if(far){far.x=c.x+zbRad(Z,0)+300;far.y=c.y;}Z.shape.type='S';zbBreathDone(Z,null);const erased=far?!far.alive:null;
      zbSegDone(Z);const cleared=zbEchoAlive();return {rAt,n,sAt,en,stg,capped,erased,cleared,hp:q.maxHp,base:EDEF[q.type].hp*3};}"""))
    ok('X05 эхо секторов: первая волна на ~11 с — 2 разлома, враги выходят через 1,2 с, их не больше 4 (mid); убитое эхо: +10 энергии, +6 сбоя; выдох стирает эхо снаружи; снятый сегмент стирает всех',r['rAt'] is not None and 10.5<=r['rAt']<=11.6 and r['n']==2 and r['sAt'] is not None and 1.0<=r['sAt']-r['rAt']<=1.4 and r['en']==20 and r['stg']==6 and r['capped']<=4 and r['erased'] and r['cleared']==0 and r['hp']==r['base'],r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();const r0=Z.rage;Z.hp=Z.segMax*.29;worldUpdate(1/60);const r1=Z.rage;Z.atkT=0;const S=[];for(let i=0;i<3;i++){Z.cool=0;Z.wind=0;Z.lunge=0;Z.stance=0;Z.mineDrop=0;Z.atkT=0;Z.burst=null;G.wtg95=[];zbConduct(Z,1/60);S.push(+(Z.atkT/ZB_TEMPO[1]/zbDiffK().tempo).toFixed(2));}
      T.zstage(4);Z.hp=Z.segMax*.25;worldUpdate(1/60);const r4=Z.rage;return {r0,r1,S,r4};}"""))
    ok('X06 ярость: на 30% сегмента (стадии 1–3) он спешит — темп ×0,8; у кнопки ярости нет (там гонка)',r['r0']==0 and r['r1']==1 and all(.69<=x<=.91 for x in r['S']) and r['r4']==0,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,p=G.player;T.zsettle();const b=zbBox();const out=[];
      for(const [x,y] of [[b[2]+400,(b[1]+b[3])/2],[(b[0]+b[2])/2,b[1]-300],[b[0]-500,b[3]+500]]){T.zpos(x,y);for(let i=0;i<3;i++){p.hp=G.st.maxHp;worldUpdate(1/60);}out.push([p.x>=b[0]&&p.x<=b[2]&&p.y>=b[1]&&p.y<=b[3],!!G.zb&&G.zb.k==='fight']);}return out;}"""))
    ok('X07 стены точки невозврата держат корабль весь бой: за рамку сектора не вылететь, бой идёт',all(q[0] and q[1] for q in r),r)
    r=await P.js(J("""()=>{T.fresh();T.openAll();const p=G.player,S=G.save;delete S.story.zero49;p.x=38500;p.y=13380;p.px=p.x;p.py=p.y;p.vx=p.vy=0;for(let i=0;i<120;i++){KEYS['KeyS']=true;worldUpdate(1/60);}KEYS['KeyS']=false;const down=Math.round(p.y);
      p.x=38200;p.y=12900;p.px=p.x;p.py=p.y;G.mapAnimJump=false;openMap('map');drawMap();const q=(G.mapPts||[]).find(q=>q.label==='XII');const jr=q?mapJumpAt(q.px,q.py):'noPt';const jy=Math.round(p.y);if(G.state!=='world'){closeMap&&closeMap();G.state='world';}
      const n=WORLD.nodes[49];p.x=n.x;p.y=n.y+100;p.vx=p.vy=0;T.wtick(1);const h=$('#wcard').innerHTML;return {open:zeroOpen110(),down,jr,jy,card:h.includes('ВОЙТИ В КОМНАТУ'),can:zbCanStart(),z49:!!S.story.zero49};}"""))
    ok('X09 альфа: без прохождения 49 ворота XI/XII открыты — корабль проходит вниз, прыжок к XII работает, у узла 50 «ВОЙТИ В КОМНАТУ»',r['open'] and r['down']>13700 and r['jy']>13560 and r['card'] and r['can'] and not r['z49'],r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;let out=0,fr=0;const W8={};for(const n of [1,2,4]){if(n>1){T.zstage(n);}T.zsettle();for(let i=0;i<60*12;i++){p.hp=G.st.maxHp;Z.hp=Z.segMax*.8;const c=zbCen(Z);if(i%30===0){const a=rnd(0,TAU);const qq=zbInside(Z,c.x+Math.cos(a)*400,c.y+Math.sin(a)*400,.7);T.zpos(qq.x,qq.y);}worldUpdate(1/60);if(i>120&&Z.lunge<=0&&Z.shape.morph>=1&&!Z.shape.next){fr++;if(!zbIn(Z,e.x,e.y,-40)){out++;const k=n+':'+(Z.cool>0?'cool':Z.wind>0?'wind':Z.stun>0?'stun':Z.stall>0?'stall':'move')+':'+Z.shape.kind+':'+Math.round(-zbEdgeD(Z,e.x,e.y)/100)*100;W8[k]=(W8[k]||0)+1;}}}}return {share:+(out/Math.max(1,fr)).toFixed(3),fr,W8};}"""))
    ok('X08 он держится внутри фигуры (кроме негатива и броска): вне её ≤ 4% кадров',r['share']<=.04,r)
    print('ERRS X',P.errs[:4])
# ---------- D: дренаж ----------
async def D(b):
    P=await page(b)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,p=G.player;const b=zbBox();const c=zbCen(Z);Z.outT=0;Z.out=0;Z.boss.alive=false;G.eb=[];const hp0=p.hp;let outAt=null;const log=[];
      let th=0;for(let i=0;i<60*6;i++){const r=zbRad(Z,th)+500;T.zpos(c.x+Math.cos(th)*r,c.y+Math.sin(th)*r);p.dashCd=2;p.dashCdMax=3;if(G.state==='world')worldUpdate(1/60);if(i%30===29)log.push([+((i+1)/60).toFixed(1),+p.hp.toFixed(1),p.dashCd.toFixed(2),Z.out,+Z.vig.toFixed(2)]);}
      return {hp0,log,maxHp:G.st.maxHp};}"""))
    L=r['log']
    ok('D01 вне фигуры: 1,5 с без урона, затем ~2,5%/с (Средняя), рывок заряжается вдвое медленнее, виньетка растёт',L[2][1]>=r['hp0']-.5 and abs((L[9][1]-L[3][1])/r['maxHp']+.025*3)<.03 and L[11][2]=='1.99' and L[11][3]==1 and L[11][4]>.5,[r['hp0'],L[1],L[2],L[3],L[9],L[11]])
    r=await P.js(J("""()=>{const out=[];for(const d of ['easy','mid','hard']){T.zstart({diff:d,flags:__FL__});const Z=G.zb,p=G.player;Z.boss.alive=false;G.eb=[];const c=zbCen(Z);const r=zbRad(Z,0)+500;T.zpos(c.x+r,c.y);for(let i=0;i<60*4;i++){if(G.state==='world')worldUpdate(1/60);}const h1=p.hp;for(let i=0;i<60*2;i++){if(G.state==='world')worldUpdate(1/60);}out.push([d,+((h1-p.hp)/G.st.maxHp/2).toFixed(3),Z.segBase,Z.segMax===Math.round(Z.segBase*zbDpsK()),+zbDpsK().toFixed(2)]);}return out;}"""))
    ok('D02 дренаж по сложности: 1,8% / 2,5% / 3,3% в секунду; база сегмента 3995 / 4700 / 5405, сегмент масштабирован огневой мощью (×0,75…2,2)',all(abs(q[1]-e)<.006 for q,e in zip(r,[.018,.025,.033])) and [round(q[2]) for q in r]==[3995,4700,5405] and all(q[3] and .75<=q[4]<=2.2 for q in r),r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,p=G.player;T.zstage(3);T.zsettle();Z.boss.alive=false;G.eb=[];Z.neg={m:'neg',t:0};Z.outT=0;const c=zbCen(Z);T.zpos(c.x,c.y);for(let i=0;i<60*3;i++){Z.neg.t=Math.min(Z.neg.t,1);if(G.state==='world')worldUpdate(1/60);const c2=zbCen(Z);T.zpos(c2.x,c2.y);}const inside=Z.out;const h1=p.hp;
      const r=zbRad(Z,0)+300;T.zpos(c.x+r,c.y);for(let i=0;i<60*3;i++){Z.neg.t=Math.min(Z.neg.t,1);if(G.state==='world')worldUpdate(1/60);T.zpos(zbCen(Z).x+r,zbCen(Z).y);}return [inside,h1<G.st.maxHp,Z.out,+p.hp.toFixed(0),+h1.toFixed(0)];}"""))
    ok('D03 «Негатив»: внутри фигуры — стирание, снаружи — жизнь',r[0]==1 and r[1] and r[2]==0 and r[3]==r[4],r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,p=G.player;const c=zbCen(Z);const r=zbRad(Z,0)+600;T.zpos(c.x+r,c.y);p.hp=5;for(let i=0;i<60*12&&G.zb;i++){if(G.state==='world')worldUpdate(1/60);if(G.zb)T.zpos(c.x+r,c.y);}const dead=!G.zb;
      let st='';for(let i=0;i<60*3;i++){if(G.state==='world')worldUpdate(1/60);}const n=WORLD.nodes[49];return [dead,G.deadT,Math.round(Math.hypot(p.x-n.x,p.y-n.y)),G.zbCool>G.t,zbCanStart(),G.enemies.filter(e=>e.alive&&e.zb).length,G.lvl,Object.keys(G.mods).length];}"""))
    ok('D04 гибель — без контрольных точек: бой сброшен, босс ушёл, корабль у кнопки, кнопка остывает, модули сброшены',r[0] and r[1]<=0 and r[2]<400 and r[3] and not r[4] and r[5]==0 and r[6]==1 and r[7]==0,r)
    print('ERRS D',P.errs[:4])
# ---------- R: развязка ----------
async def R(b):
    P=await page(b)
    r=await P.js("""()=>{const out=[];for(const [ch,third] of [['erase',false],['recall',false],['third',true],['third',false]]){T.zstart({diff:'mid',flags:"""+FL+"""});const Z=G.zb;T.zstage(4);Z.thirdOK=third;Z.hp=Z.segMax*.1;worldUpdate(1/60);const n=zbNode();Z.boss.x=n.x+900;Z.boss.y=n.y;Z.stall=1e9;T.zpos(n.x+5,n.y);for(let i=0;i<120&&G.state==='world';i++)worldUpdate(1/60);
        const ch_=choices.slice();const i=choices.indexOf(ch);const lom0=G.save.lom;if(i<0||ch==='third'&&!third){out.push([ch,ch_,'absent']);continue;}choose(i);const k=Z.k,T_=Z.endT;for(let j=0;j<60*12&&G.zb&&G.zb.k!=='idle';j++)worldUpdate(1/60);for(let j=0;j<5;j++)worldUpdate(1/60);
        const S=G.save,md=S.medals[50]||{};out.push([ch,ch_,k,T_,S.story.zero50,!!md.clear,!!md.master,!!md.echo,S.lom-lom0,zbDone(),G.enemies.filter(e=>e.alive&&e.zb).length,G.lvl,WORLD.sectors[11].name]);}return out;}""")
    ok('R01 «Стереть»: флаг 1, медаль, +4000×lom лома, босс ушёл, модули сброшены, сектор получил имя',r[0][2]=='end' and r[0][4]==1 and r[0][5] and r[0][8]>=4000 and r[0][9] and r[0][10]==0 and r[0][11]==1 and r[0][12]=='НУЛЕВОЙ МИГ',r[0])
    ok('R02 «Вспомнить»: флаг 2, кинематограф 7 с',r[1][2]=='end' and r[1][3]==7 and r[1][4]==2,r[1])
    ok('R03 «Третий путь»: доступен только при условии, флаг 3, 10 с; медали «эхо» больше нет (1.2.0)',r[2][2]=='end' and r[2][3]==10 and r[2][4]==3 and not r[2][7] and r[3][2]=='absent' and 'none' in r[3][1],[r[2],r[3]])
    r=await P.js("""()=>{T.zstart({diff:'mid',flags:"""+FL+"""});const Z=G.zb;Z.cycles=1;T.zstage(4);Z.thirdOK=false;Z.hp=Z.segMax*.1;worldUpdate(1/60);const n=zbNode();Z.boss.x=n.x+900;Z.boss.y=n.y;Z.stall=1e9;T.zpos(n.x+5,n.y);for(let i=0;i<120&&G.state==='world';i++)worldUpdate(1/60);choose(0);for(let j=0;j<60*8&&G.zb&&G.zb.k!=='idle';j++)worldUpdate(1/60);
      const md=G.save.medals[50];const n2=WORLD.nodes[49];T.zpos(n2.x,n2.y+90);for(let i=0;i<40;i++)worldUpdate(1/60);const h=$('#wcard').innerHTML;const again=zbCanStart();
      const S=G.save;sanitize90&&0;return [!!md.master,h.includes('ВЕРНУТЬСЯ К КНОПКЕ')||h.includes('ЗАКРЫТА'),again||G.zbCool>G.t,S.story.zero50n];}""")
    ok('R04 с повтором цикла мастерства нет; после победы карточка — «ВЕРНУТЬСЯ К КНОПКЕ» (после остывания), счётчик прохождений',r[0] is False and r[1] and r[2] and r[3]==1,r)
    r=await P.js("""()=>{T.zstart({diff:'mid',flags:"""+FL+"""});const a=musTarget().id;const Z=G.zb;T.zstage(2);const b_=musTarget().id;T.zstage(4);Z.hp=Z.segMax*.1;worldUpdate(1/60);const c=musTarget().id;Z.k='choice';const d=musTarget().id;Z.k='fight';
      const kinds=['inTg','outTg','inhale','exhale','stun','stunEnd','seam','cool','frag','mineSet','mineArm','mineBoom','sing','negTg','neg','stance','repeat','novaTg','cloneDie','clean','press','wall','expand','static','banner','rift','beat','out','edge','seg','stage','copy','deflect','ram','beamHit','allyShot','tick','tock','zero','perfect','ally','dash','pulse','beam','fan','race','cycle','choice','erase','recall','third'];
      let ok=0;for(const k of kinds){try{snd120(k,G.player.x);ok++;}catch(e){}}return [a,b_,c,d,ok,kinds.length,!!SC_.zbg&&!!SC_.zbd&&!!SC_.zbr&&!!SC_.zbc,EDEF.zero000.name,CODEX_ORDER.includes('zero000')];}""")
    ok('R05 музыка: урон → zbd, отсчёт → zbg, гонка → zbr, выбор → zbc; 51 звук без исключений; справочник знает VØID-000',r[0]=='zbd' and r[1]=='zbg' and r[2]=='zbr' and r[3]=='zbc' and r[4]==r[5] and r[6] and 'VØID-000' in r[7] and r[8],r)
    r=await P.js("""()=>{T.zWorld({flags:"""+FL+"""});const p=G.player;const n=WORLD.nodes[49];T.zpos(n.x+300,n.y+400);let gl=0,z=0;for(let i=0;i<60*6;i++){worldUpdate(1/60);if(G.zbAmb&&G.zbAmb.gl.length)gl=Math.max(gl,G.zbAmb.gl.length);const q=zbZoom();if(q&&Math.abs(q-1)>.001)z++;}
      T.zpos(38500,12000);for(let i=0;i<60*2;i++)worldUpdate(1/60);const gl2=G.zbAmb.gl.length;return [gl,z>0,gl2,zbZoom()];}""")
    ok('R06 сектор XII до боя: слабые блики (≤6) и лёгкое дыхание масштаба; вне XII — ничего',r[0]>=1 and r[0]<=6 and r[1] and r[2]==0 and r[3]==0,r)
    print('ERRS R',P.errs[:4])
# ---------- N: без регрессий — мир и миссии рядом ----------
async def N(b):
    P=await page(b)
    r=await P.js("""()=>{T.fresh();T.openAll();G.save.story.zero49=1;const st=T.go(49);let n=0;while(G.state==='levelup'&&n++<40)choose(0);for(let i=0;i<60*3;i++)update(1/60);const a=[G.state,!!G.x110,G.x110&&G.x110.k];
      T.fresh();T.openAll();G.save.story.zero49=1;T.go(48);n=0;while(G.state==='levelup'&&n++<40)choose(0);for(let i=0;i<60*2;i++)update(1/60);const b_=[G.state,G.x110&&G.x110.k];
      T.fresh();T.openAll();const n50=WORLD.nodes[49];G.player.x=n50.x;G.player.y=n50.y+100;for(let i=0;i<30;i++)worldUpdate(1/60);const c=[G.state,!!G.zb,$('#wcard').innerHTML.includes('ВОЙТИ')];
      return [a,b_,c,typeof tickRoom,MISSIONS[49].name,bossLab90(50)];}""")
    ok('N01 миссии 48–49 работают как прежде; узел 50 без боя — обычный мир; имя миссии 50 «Нулевой миг»',r[0][0]=='play' and r[0][2]=='blink' and r[1][0]=='play' and r[1][1]=='launch' and r[2][0]=='world' and not r[2][1] and r[2][2] and r[4]=='Нулевой миг' and r[5]=='VØID-000',r)
    r=await P.js("""()=>{T.fresh();T.openAll();G.save.story.zero49=1;const n=WORLD.nodes[49];T.zpos(n.x,n.y+100);worldUpdate(1/60);T.zgo();T.ztick(9);let k=0;while(G.zb&&G.zb.k!=='fight'&&k++<40)T.ztick(.5);
      // сохранение посреди боя и перезагрузка мира
      saveWorld();const S=G.save;const pos=S.pos;startWorld(false);if(G.prologue)prologueEnd();const p=G.player;return [!!G.zb,G.state,Math.round(p.x),Math.round(p.y),inXII110(p.x,p.y),G.save.story.zero50||0];}""")
    ok('N02 перезагрузка мира посреди боя: боя нет, корабль в секторе XII, флаг не записан',not r[0] and r[1]=='world' and r[4] and r[5]==0,r)
    r=await P.js("""()=>{const S=JSON.parse(JSON.stringify(G.save));S.story.zero50=7;S.story.zero50n='x';S.medals[50]={clear:1};const ok=validSave(S);const T2=sanitizeSave(S);return [ok,T2.story.zero50,T2.medals[50]&&T2.medals[50].clear];}""")
    ok('N03 sanitize: zero50 в 0..9, медаль 50 сохраняется',r[0] and r[1]==7 and r[2]==1,r)
    r=await P.js(J("""()=>{T.zstart({diff:'mid',flags:__FL__});const Z=G.zb,e=Z.boss,p=G.player;T.zsettle();Z.atkT=99;G.wtg95=[];G.eb=[];const c=zbCen(Z);e.x=c.x;e.y=c.y;T.zpos(e.x+300,e.y);p.hp=3;p.inv=0;p.shieldUp=false;
      zbAtk(Z,'dash');let dead=0;for(let i=0;i<60*8&&G.zb;i++){if(p.hp>0){p.vx=p.vy=0;T.zpos(e.x+300,e.y);}else dead=1;worldUpdate(1/60);}return [!G.zb&&dead,G.zbLastDeath];}"""))
    await P.pg.wait_for_timeout(2100)
    bn=await P.js("()=>[$('#banB').textContent,$('#banS').textContent]")
    ok('N04 гибель — разбор: «СТЁР: БРОСОК · СОВЕТ: …» с подсказкой, что делать иначе',r[0] and r[1] and r[1]['n']=='БРОСОК' and 'СТЁР: БРОСОК' in bn[1] and 'СОВЕТ:' in bn[1],[r,bn])
    print('ERRS N',P.errs[:4])
GROUPS={'E':E,'B':B,'V':V,'A':A,'S':S,'X':X,'D':D,'R':R,'N':N}
sel=os.environ.get('QG','EBVASXDRN')
asyncio.run(run([(k,GROUPS[k]) for k in sel if k in GROUPS],'q120.json'))
