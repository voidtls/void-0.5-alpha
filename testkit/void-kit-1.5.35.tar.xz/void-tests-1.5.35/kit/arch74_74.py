# ---------- 74 · A-21 · режиссёр C66 на часах шага ----------
PRE74="""/* ▼▼▼ ARCH·74 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.14 α · этап 4.3: часы режиссёра C66)
   A-21 · такт режиссёра C66 (миссии 1–5) в бою и в мире идёт из шага step74 по 1/60, а не из отрисовки по часам стены.
   Отложенное замедление после оглушения тарана (было setTimeout 140 мс) и метки «последнее убийство / взрыв мины / зона чиста»
   считаются по ARCH.clk. Звуковые setTimeout, заставка брифинга и карточка итога остаются на настоящем времени: игру они не меняют.
   Работает только вместе с циклом A-20 (и A-19). Выключение: window.__archOff=['A-21'] до загрузки. */
ARCH.c66s=!ARCH.off['A-21']&&!ARCH.off['A-20']&&!ARCH.off['A-19'];
function c66Clk(){return ARCH.c66s?ARCH.clk*1000:performance.now();}
"""+END%74
S74=[
 ("inMission())C66.lk={x:e.x,y:e.y,type:e.type,at:performance.now()};","inMission())C66.lk={x:e.x,y:e.y,type:e.type,at:c66Clk()};/* ARCH·74 A-21 */"),
 ("C66.mb={x:e.x,y:e.y,at:performance.now()}","C66.mb={x:e.x,y:e.y,at:c66Clk()}/* ARCH·74 A-21 */"),
 ("C66.clearAt=performance.now();return _bn","C66.clearAt=c66Clk();/* ARCH·74 A-21 */return _bn"),
 ("const lk=C66.lk&&performance.now()-C66.lk.at<1500?","const lk=C66.lk&&c66Clk()-C66.lk.at<1500?/* ARCH·74 A-21 */"),
 ("if(C66.clearAt&&performance.now()-C66.clearAt<800&&","if(C66.clearAt&&c66Clk()-C66.clearAt<800&&/* ARCH·74 A-21 */"),
 ("const at=C66.mb&&performance.now()-C66.mb.at<400?","const at=C66.mb&&c66Clk()-C66.mb.at<400?/* ARCH·74 A-21 */"),
 ("C66.lk={x:p.x+80,y:p.y-60,at:performance.now()}","C66.lk={x:p.x+80,y:p.y-60,at:c66Clk()}/* ARCH·74 A-21 */"),
 ("setTimeout(()=>{if(C66.M===M)c66Slow(.6,.35);},140);",
  "if(ARCH.c66s)M.c66slAt=ARCH.clk+.14;else setTimeout(()=>{if(C66.M===M)c66Slow(.6,.35);},140);/* ARCH·74 A-21 */"),
 ("M.t+=dt;const p=G.player,m=M.m,full=M.full,mode=M.mode;",
  "M.t+=dt;const p=G.player,m=M.m,full=M.full,mode=M.mode;if(M.c66slAt&&ARCH.clk>=M.c66slAt-1e-9){M.c66slAt=0;c66Slow(.6,.35);}/* ARCH·74 A-21 */"),
 ("try{c66Tick(dt);if(C66.M&&!G.world)c66Top();","try{if(!(ARCH.c66s&&live74()))c66Tick(dt);/* ARCH·74 A-21: в бою и мире такт идёт из шага */if(C66.M&&!G.world)c66Top();"),
 ("else if(G.state==='world'){if(G.prologue)prologueTick(dt);else worldUpdate(dt);}}\nfunction frame74",
  "else if(G.state==='world'){if(G.prologue)prologueTick(dt);else worldUpdate(dt);}\n  if(ARCH.c66s){try{c66Tick(STEP74);}catch(e){c66Fail(e);}}/* ARCH·74 A-21 */}\nfunction frame74"),
]
STAGES[74]=dict(vf='1.5.13 α',vt='1.5.14 α',J='m74_journal.txt',pre=PRE74,after=73,sites=S74)
