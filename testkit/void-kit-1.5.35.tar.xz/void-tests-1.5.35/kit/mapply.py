# python3 mapply.py <in.html> <out.html> <n> [<n>...]  — накладывает патчи этапа 4 по порядку; печатает SHA
import sys,hashlib
sys.path.insert(0,'@@KIT@@')
import arch74 as A
s=open(sys.argv[1],encoding='utf8').read()
for n in sys.argv[3:]:s=A.apply(s,int(n))
open(sys.argv[2],'w',encoding='utf8').write(s)
i=s.index('<script>');j=s.index('</script>',i);open(sys.argv[2]+'.js','w',encoding='utf8').write(s[i+8:j])
print('ok',sys.argv[3:],hashlib.sha256(s.encode()).hexdigest(),len(s.encode()))
