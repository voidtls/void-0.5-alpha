# 1.0 QA · часть 22: исправления явных багов, найденных батареей qa1000 (каждое покрыто тестом в q130.py)
import sys
SP='@@KIT@@/'
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m22: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
# (правки добавляются ниже по одной, с номером находки)
# Q01 (F2#2001, касания): на телефоне в альбоме карточка узла (#wcard) лежит внизу по центру и перехватывает касание —
# стик не начинается, корабль не едет (12% зоны стика). Карточка кликается только кнопками [data-act]: остальное пропускает касание к холсту.
R("#wcard{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(84px + env(safe-area-inset-bottom,0px));",
  "#wcard{pointer-events:none}#wcard [data-act],#wcard button{pointer-events:auto}\n#wcard{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(84px + env(safe-area-inset-bottom,0px));")
open(P,'w',encoding='utf8').write(s)
print('m22 ok')
