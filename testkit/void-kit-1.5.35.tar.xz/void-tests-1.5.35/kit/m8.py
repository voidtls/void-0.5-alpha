# 0.6.0 · часть 8: правки по живым скриншотам
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m8: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
R("act:{d:56,dx:188,dy:188}","act:{d:64,dx:190,dy:190}")
R("if(label){ctx.font='700 12px \"JetBrains Mono\",monospace';ctx.textAlign='center';ctx.fillStyle='#04060c';const lx=clamp(ex-Math.cos(a)*30,48,CW-48),ly=clamp(ey-Math.sin(a)*22+4,SAFE.t+70,CH-SAFE.b-10);",
  "if(label){ctx.font='700 12px \"JetBrains Mono\",monospace';ctx.textAlign='center';ctx.fillStyle='#04060c';const lw=ctx.measureText(label).width/2+10,rx=ex-Math.cos(a)*30,lx=clamp(rx,SAFE.l+lw,CW-SAFE.r-lw),ly0=ey-Math.sin(a)*22+4,ly=clamp(Math.abs(lx-ex)<lw+6&&Math.abs(ly0-4-ey)<16?ey+(ey<CH/2?28:-18):ly0,SAFE.t+70,CH-SAFE.b-10);")
CSS=r"""
/* --- 0.6.0: правки по живым скриншотам --- */
.mob #tAct{letter-spacing:0;padding:0}
.ff-phone-p #banner{top:calc(var(--sat) + 224px)}
.ff-phone-p #wcard{box-sizing:border-box;top:calc(var(--sat) + 96px);bottom:auto;left:max(14px,var(--sal));transform:none;width:calc(100% - 112px - max(14px,var(--sal)))}
"""
R("</style>",CSS+"</style>",1)
open(P,'w').write(s)
print('m8 ok')
