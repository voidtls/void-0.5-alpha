# 1.0.0 α · часть 23: (1) сохранение не теряется между версиями — слой хранения с запасной памятью и облачная копия в личной папке
# игрока (db артефакта); (2) коды сохранения — очистка вставки, копирование, честные сообщения; (3) туман войны — миссии по цепочке,
# закрытые сектора под туманом и стеной на всю высоту мира. Каждое изменение покрыто тестом в q130.py (Q02–Q09).
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m23: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)

# ———————————————————————————————— (1) СЛОЙ ХРАНЕНИЯ
# все обращения игры к localStorage идут через LS: чтение берёт память, если запись в браузер не удалась; LS.onWrite будит облако
n=s.count('localStorage.')
if n!=15: sys.exit('m23: localStorage. count %d != 15'%n)
s=s.replace('localStorage.','LS.')
R('<script>\n"use strict";\n','<script>\n"use strict";\n'+r"""/* 1.0.0 α: слой хранения. Браузерное хранилище может отказать (встроенное окно, приватный режим, переполнение) или прийти пустым
   после новой версии. LS держит копию каждой записи в памяти — в этой вкладке прогресс не теряется, а облако (ниже) переносит его между версиями. */
const LS=(function(){const mem={},bad={},hooks=[];let real=null;try{real=window.localStorage;real.getItem('void_world');}catch(e){real=null;}
  const has=k=>Object.prototype.hasOwnProperty.call(mem,k);const fire=k=>{for(const f of hooks){try{f(k);}catch(e){}}};
  return {ok(){return !!real;},persisted(k){return !!real&&!bad[k];},
    getItem(k){if(real&&!bad[k]){try{return real.getItem(k);}catch(e){}}return has(k)?mem[k]:null;},
    setItem(k,v,quiet){v=String(v);mem[k]=v;let ok=false;if(real){try{real.setItem(k,v);ok=true;delete bad[k];}catch(e){bad[k]=1;}}else bad[k]=1;
      if(!quiet)fire(k);if(!ok){const er=new Error('storage write failed');er.name='QuotaExceededError';throw er;}},
    removeItem(k,quiet){delete mem[k];delete bad[k];if(real){try{real.removeItem(k);}catch(e){}}if(!quiet)fire(k);},
    onWrite(f){hooks.push(f);}};})();
""")
# сообщение «сохранение не записано» не пугает, когда облако приняло прогресс
R("if(v!==undefined&&k==='void_world'&&!G.saveFail){","if(v!==undefined&&k==='void_world'&&!G.saveFail&&!(window.CLOUD&&CLOUD.state==='ready')){")

# ———————————————————————————————— (1) ОБЛАКО + (2) КОДЫ
OLD_COPY="""$('#bSaveCopy').onclick=()=>{const t=$('#saveOut');if(!t.value){$('#saveMsg').textContent='Копировать нечего: сохранения пока нет.';return;}
  const done=()=>{$('#saveMsg').textContent='Код скопирован.';};
  try{navigator.clipboard.writeText(t.value).then(done,()=>{t.select();$('#saveMsg').textContent='Код выделен — скопируйте его вручную.';});}catch(e){t.select();$('#saveMsg').textContent='Код выделен — скопируйте его вручную.';}};"""
NEW_COPY="""$('#bSaveCopy').onclick=()=>{const t=$('#saveOut');if(!t.value){$('#saveMsg').textContent='Копировать нечего: сохранения пока нет.';return;}
  const done=()=>{$('#saveMsg').textContent='Код скопирован.';};
  // 1.0.0 α: во встроенном окне буфер часто запрещён — запасной путь через выделение и execCommand
  const manual=()=>{try{t.focus();t.select();t.setSelectionRange(0,t.value.length);if(document.execCommand&&document.execCommand('copy')){done();return;}}catch(e){}
    $('#saveMsg').textContent='Код выделен — скопируйте его вручную (долгое нажатие → «Копировать»).';};
  try{if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t.value).then(done,manual);else manual();}catch(e){manual();}};"""
R(OLD_COPY,NEW_COPY)
OLD_LOAD="""$('#bSaveLoad').onclick=()=>{
  try{const S0=JSON.parse(decodeURIComponent(escape(atob($('#saveIn').value.trim()))));if(!validSave(S0))throw 0;
    store('void_world',S0);const S=migrateSave(JSON.parse(JSON.stringify(S0)));G.save=S;$('#saveMsg').textContent='Загружено: пройдено миссий кампании '+S.cleared+' из '+CORE+', лом '+S.lom+'.';renderMenu();}
  catch(e){$('#saveMsg').textContent='Код не распознан. Проверьте, что он скопирован целиком.';}};"""
NEW_LOAD=r"""// 1.0.0 α: код чистится от того, что добавляют чаты и мессенджеры: кавычки, переносы, неразрывные и невидимые пробелы, текст вокруг
function codeDecode(raw){const one=c=>{c=c.replace(/=+$/,'').replace(/-/g,'+').replace(/_/g,'/');while(c.length%4)c+='=';const S=JSON.parse(decodeURIComponent(escape(atob(c))));return validSave(S)?S:null;};
  const s0=String(raw||'').replace(/[​-‏⁠﻿­]/g,'').replace(/[  -   　]/g,' ');
  const flat=s0.replace(/[\s"'`«»“”„‘’<>]/g,''),cands=[];
  const i=flat.indexOf('eyJ');if(i>=0){const m=flat.slice(i).match(/^[A-Za-z0-9+/=_-]+/);if(m)cands.push(m[0]);}
  const runs=flat.match(/[A-Za-z0-9+/_-]{40,}={0,2}/g);if(runs)cands.push(...runs.sort((a,b)=>b.length-a.length));cands.push(flat);
  for(const c of cands){try{const S=one(c);if(S)return S;}catch(e){}}return null;}
$('#bSaveLoad').onclick=()=>{const raw=$('#saveIn').value,S0=codeDecode(raw);
  if(!S0){$('#saveMsg').textContent=raw.trim()?'Код не распознан. Проверьте, что он скопирован целиком.':'Вставьте код сохранения в поле.';return;}
  store('void_world',S0);const S=migrateSave(JSON.parse(JSON.stringify(S0)));G.save=S;cloudForce();
  $('#saveMsg').textContent='Загружено: пройдено миссий '+worldDone(S0)+' из '+NM+', лом '+S.lom+'. '+saveStatus();renderMenu();};"""
R(OLD_LOAD,NEW_LOAD)
CLOUD_JS=r"""
// ===== 1.0.0 α: облачное сохранение — личная папка игрока в базе артефакта (data/users/<id>/save) =====
// Переживает публикацию новых версий и смену устройства. Решение «облако или браузер»: явное действие (новый полёт, сброс, загрузка
// кода) побеждает; иначе побеждает больший прогресс (пройденные миссии); при равенстве — более свежая запись.
var CLOUD_KEYS=['void_world','void_record','void_endless','void_settings','void_echo100','void_serial85'];
var CLOUD={state:'init',ref:null,dirty:false,busy:false,again:false,tm:0,lastAt:0,sig:'',applying:false,pending:null,waiters:[],gateOff:false,err:''};
function metaGet(){try{const v=JSON.parse(LS.getItem('void_meta')||'null');return v&&typeof v==='object'?{t:+v.t||0,force:+v.force||0}:{t:0,force:0};}catch(e){return {t:0,force:0};}}
function metaSet(m){try{LS.setItem('void_meta',JSON.stringify(m),true);}catch(e){}}
function worldDone(raw){try{const S=typeof raw==='string'?JSON.parse(raw):raw;if(!validSave(S))return 0;let n=0;
  for(let m=1;m<=NM;m++)if((m<=CORE&&+S.cleared>=m)||(S.medals&&S.medals[m]&&S.medals[m].clear)||(m===49&&S.story&&S.story.zero49))n++;return n;}catch(e){return 0;}}
LS.onWrite(k=>{if(CLOUD.applying||!CLOUD_KEYS.includes(k))return;const m=metaGet();m.t=Date.now();metaSet(m);cloudDirty();});
function cloudForce(){const m=metaGet();m.force=m.t=Date.now();metaSet(m);cloudDirty(true);}
function cloudBody(){const keys={};for(const k of CLOUD_KEYS)keys[k]=LS.getItem(k);const m=metaGet();return {v:1,t:m.t||Date.now(),force:m.force||0,done:worldDone(keys.void_world),ver:'1.0.0a',keys};}
function cloudSig(b){return JSON.stringify(b.keys)+'|'+b.force;}
function cloudDirty(now){CLOUD.dirty=true;if(CLOUD.state!=='ready')return;clearTimeout(CLOUD.tm);
  CLOUD.tm=setTimeout(cloudPush,now?60:Math.min(12000,Math.max(3000,12000-(Date.now()-CLOUD.lastAt))));}
async function cloudPush(){if(CLOUD.state!=='ready'||!CLOUD.ref)return;if(CLOUD.busy){CLOUD.again=true;return;}if(!CLOUD.dirty)return;
  const b=cloudBody(),sg=cloudSig(b);if(sg===CLOUD.sig){CLOUD.dirty=false;return;}CLOUD.busy=true;CLOUD.dirty=false;
  try{await CLOUD.ref.set(b);CLOUD.sig=sg;CLOUD.lastAt=Date.now();CLOUD.err='';}
  catch(e){const c=e&&e.code;CLOUD.dirty=true;CLOUD.err=c||'unavailable';
    if(['invalid_argument','not_granted','capability_disabled','capability_removed','revoked','transform_error'].includes(c))CLOUD.state='ro';
    else if(c==='quota_exceeded')toast('ОБЛАКО ЗАПОЛНЕНО','Облачная копия не записана: место в хранилище закончилось. Код сохранения в меню по-прежнему работает.');
    else setTimeout(()=>{if(CLOUD.dirty)cloudPush();},2500+Math.random()*2000);}
  finally{CLOUD.busy=false;if(CLOUD.again){CLOUD.again=false;if(CLOUD.dirty)cloudDirty();}}}
function cloudWinner(body){if(!body||!body.keys)return 'local';const lw=LS.getItem('void_world'),ld=worldDone(lw),m=metaGet(),ct=+body.t||0,cf=+body.force||0,cd=+body.done||0;
  if(m.force&&m.force>ct)return 'local';if(cf&&cf>m.t)return 'cloud';if(!lw&&body.keys.void_world)return 'cloud';
  if(cd>ld)return 'cloud';if(ld>cd)return 'local';return ct>m.t?'cloud':'local';}
function cloudApply(body){CLOUD.applying=true;
  try{for(const k of CLOUD_KEYS){if(!(k in body.keys))continue;const v=body.keys[k];try{if(v===null||v===undefined)LS.removeItem(k,true);else LS.setItem(k,String(v),true);}catch(e){}}
    metaSet({t:+body.t||Date.now(),force:0});}finally{CLOUD.applying=false;}
  CLOUD.sig=cloudSig(cloudBody());cloudReloadState();}
function cloudReloadState(){G.save=migrateSave(store('void_world'));recReload();
  const v=store('void_settings');if(v&&typeof v==='object'&&!Array.isArray(v)){for(const k in SET_DEF){if(!(k in v))continue;const x=v[k];
    if(SET_OPT[k]?SET_OPT[k].includes(x):(typeof x===typeof SET_DEF[k]&&(typeof x!=='number'||Number.isFinite(x))))SET[k]=x;}try{applySettings();renderSettings();}catch(e){}}
  if(G.state==='menu')renderMenu();}
async function cloudInit(){const done=()=>{if(CLOUD.gateOff)return;CLOUD.gateOff=true;const W_=CLOUD.waiters.splice(0);try{if(G.state==='menu')renderMenu();}catch(e){}
    for(const f of W_){try{f();}catch(e){console.error(e);}}};
  setTimeout(done,6000);
  try{const C=typeof window!=='undefined'?window.claude:null;if(!C||typeof C.use!=='function'){CLOUD.state='off';return done();}
    const [db,user]=await Promise.all([C.use('db'),C.use('user')]);if(!db||!user){CLOUD.state='off';return done();}
    const uid=await user.id();if(!uid){CLOUD.state='off';return done();}
    CLOUD.ref=db.doc('data/users/'+uid+'/save');let snap=null;
    for(let a=0;a<2&&!snap;a++){try{snap=await CLOUD.ref.get();}catch(e){if(a)throw e;await new Promise(r=>setTimeout(r,1500));}}
    const body=snap&&snap.exists?snap.data():null;CLOUD.state='ready';
    if(body&&cloudWinner(body)==='cloud'){if(G.state==='menu'){cloudApply(body);const n=worldDone(LS.getItem('void_world'));toast('ПРОГРЕСС ВОССТАНОВЛЕН',n?'Облачная копия: пройдено миссий '+n+' из '+NM+'.':'Облачная копия загружена.');}else CLOUD.pending=body;}
    else cloudDirty(true);
  }catch(e){CLOUD.state='off';CLOUD.err=(e&&e.code)||'error';}
  done();}
function cloudMenuCheck(){const b=CLOUD.pending;if(!b)return;CLOUD.pending=null;if(cloudWinner(b)==='cloud'){cloudApply(b);toast('ПРОГРЕСС ВОССТАНОВЛЕН','Облачная копия загружена.');}else cloudDirty(true);}
function cloudGate(f){if(CLOUD.gateOff||CLOUD.state!=='init'){f();return;}CLOUD.waiters.length=0;CLOUD.waiters.push(f);toast('СИНХРОНИЗАЦИЯ','Проверяю облачное сохранение…');}
function cloudFlush(){if(CLOUD.state==='ready'&&CLOUD.dirty){clearTimeout(CLOUD.tm);cloudPush();}}
addEventListener('visibilitychange',()=>{if(document.hidden)cloudFlush();});addEventListener('pagehide',cloudFlush);
function saveWhere(){const C=window.CLOUD;if(C&&C.state==='init'&&!C.gateOff)return 'ПРОВЕРКА…';if(C&&C.state==='ready')return 'ОБЛАКО';return LS.ok()&&LS.persisted('void_world')?'БРАУЗЕР':'ВКЛАДКА';}
function saveStatus(){const C=window.CLOUD;if(C&&C.state==='ready')return 'Прогресс хранится в облаке артефакта и в браузере — новые версии игры его не сотрут.';
  if(C&&C.state==='ro')return 'Облако недоступно для записи. Прогресс хранится в этом браузере — держите код как запасную копию.';
  if(LS.ok()&&LS.persisted('void_world'))return 'Прогресс хранится в этом браузере. Держите код как запасную копию.';
  return 'Браузер не даёт сохранять: прогресс живёт до закрытия вкладки — держите код под рукой.';}
"""
R("$('#bSaveBack').onclick=()=>toMenu();","$('#bSaveBack').onclick=()=>toMenu();"+CLOUD_JS)
# экран кода: честный статус хранения
R("$('#saveIn').value='';$('#saveMsg').textContent='';show('sSave');","$('#saveIn').value='';$('#saveMsg').textContent=saveStatus();show('sSave');")
# кнопки меню ждут проверки облака (не дольше 6 с), новый полёт и сброс — явные действия
R("$('#bWorld').onclick=()=>startWorld(false);","$('#bWorld').onclick=()=>cloudGate(()=>startWorld(false));")
R("if(newConfirm&&performance.now()-newConfirm<4000){startWorld(true);return;}","if(newConfirm&&performance.now()-newConfirm<4000){cloudGate(()=>{startWorld(true);cloudForce();});return;}")
R("$('#bSave').onclick=openSaveScreen;","$('#bSave').onclick=()=>cloudGate(openSaveScreen);")
R("G.save=null;REC.best=0;REC.maxMission=0;","cloudForce();G.save=null;REC.best=0;REC.maxMission=0;")
R("function toMenu(){unlockArena();","function toMenu(){unlockArena();try{cloudMenuCheck();}catch(e){}")
R("renderSettings();renderMenu();show('sMenu');requestAnimationFrame(frame);\n</script>","renderSettings();renderMenu();show('sMenu');requestAnimationFrame(frame);\ncloudInit();\n</script>")
# строка рекордов в меню: где хранится прогресс
R("+(G.save&&G.save.pilot?`<span>ПИЛОТ <b>УР ${G.save.pilot.lvl}</b></span>`:'')","+(G.save&&G.save.pilot?`<span>ПИЛОТ <b>УР ${G.save.pilot.lvl}</b></span>`:'')+`<span>СОХРАНЕНИЕ <b>${saveWhere()}</b></span>`")

# ———————————————————————————————— (3) ТУМАН ВОЙНЫ
R("const ALPHA_OPEN = (typeof window!=='undefined'&&window.__alpha===false)?false:true;",
  "const ALPHA_OPEN = (typeof window!=='undefined'&&window.__alpha===true); // 1.0.0 α: мир закрыт туманом войны; true выставляют только старые тесты")
R("function zeroOpen110(){return (typeof window!=='undefined'&&window.__alpha!==false)||!!(G.save&&G.save.story&&G.save.story.zero49)||",
  "function zeroOpen110(){return (ALPHA_OPEN&&window.__alpha!==false)||!!(G.save&&G.save.story&&G.save.story.zero49)||!!(G.save&&G.save.medals&&G.save.medals[49]&&G.save.medals[49].clear)||")
OLD_NS="""function nodeState(m){const S=G.save;if(m>CORE)return S.medals[m]&&S.medals[m].clear?'done':'open';if(S.cleared>=m)return 'done';
  if(ALPHA_OPEN)return S.medals[m]&&S.medals[m].clear?'done':'open';// ВРЕМЕННО (альфа 0.5.9): все уровни доступны; пройденные вне очереди — по медали
  if(m===S.cleared+1&&(m<=6||S.gate))return 'open';return 'locked';}"""
NEW_NS=r"""// 1.0.0 α: туман войны. Миссия открыта, только если пройдена предыдущая. Сектор закрыт туманом, пока не пройдена последняя миссия
// предыдущего сектора; стена тумана на всю высоту мира не пускает за кромку (облететь сверху нельзя). Сектор II — ещё и ворота с двумя замками.
function openAllNow(){return ALPHA_OPEN||G.mode==='dev'||!!(window.DEVW&&DEVW.on&&DEVW.on());}
function progDone(m){const S=G.save;if(!S||!m)return false;if(m<=CORE&&+S.cleared>=m)return true;if(S.medals&&S.medals[m]&&S.medals[m].clear)return true;return m===49&&!!(S.story&&S.story.zero49);}
function secOfM(m){if(m<=6)return 0;if(m<=CORE)return 1;const n=WORLD.nodes[m-1];return n&&n.sec!==undefined?n.sec:1;}
const SEC_LAST={};function secLastM(i){if(SEC_LAST[i]!==undefined)return SEC_LAST[i];let r=0;for(const n of WORLD.nodes)if(secOfM(n.m)===i)r=Math.max(r,n.m);return SEC_LAST[i]=r;}
function secSeen(i){if(openAllNow()||i<=0)return true;if(i===1)return progDone(6);if(i===11)return zeroOpen110();return progDone(secLastM(i-1));}
function secOpen(i){return secSeen(i)&&(i!==1||openAllNow()||gateOpen());}
const FOGC={k:null};
function fogMemo(){const S=G.save;let nc=0;if(S&&S.medals)for(const k in S.medals)if(S.medals[k]&&S.medals[k].clear)nc++;
  const k=S?[openAllNow()?1:0,S.cleared,S.gate?1:0,nc,S.story&&S.story.zero49?1:0,G.dev&&G.devZero110?1:0].join('|'):'-';if(FOGC.k===k&&FOGC.s===S)return FOGC;
  FOGC.k=k;FOGC.s=S;const by=f=>{if(!S||openAllNow()||!WORLD.sectors)return Infinity;for(let i=1;i<=10;i++)if(!f(i))return i===1?5000:WORLD.sectors[i].box[0];return Infinity;};
  FOGC.x=by(secOpen);FOGC.sx=by(secSeen);FOGC.z=!S||secSeen(11);FOGC.i=-1;for(let i=1;i<=10;i++)if(!secOpen(i)){FOGC.i=i;break;}return FOGC;}
function fogX(){return fogMemo().x;}
function fogSeeX(){return fogMemo().sx;}
function fogSec(){return fogMemo().i;}
function fogClosedAt(x,y){const F=fogMemo();if(x>=F.sx)return true;return !F.z&&inXII110(x,y);}
function fogBlockedAt(x,y){const F=fogMemo();if(x>=F.x)return true;return !F.z&&inXII110(x,y);}
function fogHint(i){return i===1?(progDone(6)?'УНИЧТОЖЬТЕ ДВА ЗАМКА ВОРОТ':'ПРОЙДИТЕ МИССИЮ 06'):'СЕКТОР '+roman(i+1)+' · ПРОЙДИТЕ МИССИЮ '+pad2(secLastM(i-1));}
function nodeState(m){const S=G.save;if(progDone(m))return 'done';if(openAllNow())return 'open';
  if(m>1&&!progDone(m-1))return 'locked';if(m===7&&!S.gate)return 'locked';return secOpen(secOfM(m))?'open':'locked';}
// стена: держит только пересечение кромки (корабль, уже оказавшийся за ней, не перебрасывает через полмира)
function fogWall(p){if(!p||openAllNow()||p.px===undefined)return;const fx=fogX();if(fx===Infinity)return;const L=fx-p.r;
  if(p.x>L&&p.px<=L+1){p.x=L-1;p.vx=-Math.abs(p.vx)*.4-90;p.dashT=0;const i=fogSec();hintOnce(i===1?'gate':'fog'+i,i===1?(G.save.cleared>=6?'ВОРОТА ЗАПЕРТЫ · УНИЧТОЖЬТЕ ДВА ЗАМКА':'ВОРОТА СЕКТОРА · СНАЧАЛА ЯДРО СТРАЖА'):'ТУМАН ВОЙНЫ · '+fogHint(i),i===1?'#b48cff':'#9fb0c4');}}
// старые сохранения альфы: ворота II, если уже пройдены миссии за ними; корабль не стоит в закрытом тумане
function fogFix(S){if(!S||openAllNow())return;if(!S.gate&&WORLD.nodes.some(n=>n.m>=7&&progDone(n.m)))S.gate=true;
  if(S.pos&&fogBlockedAt(S.pos.x,S.pos.y)){let bn=WORLD.nodes[0];for(const n of WORLD.nodes)if(nodeState(n.m)!=='locked'&&!fogBlockedAt(n.x,n.y))bn=n;S.pos={x:bn.x,y:bn.y+160};S.last={...S.pos};}}
function fogDraw(t){if(openAllNow()||!G.save||!G.player)return;const F=fogMemo(),p=G.player,mob=isMob(),vx0=CX-80,vx1=CX+W+80,vy0=CY-80,vy1=CY+H+80;
  const wall=(ax,ay,bx,by,dir,txt)=>{const E=dir==='x'?860:720;
    const L=Math.max(dir==='x'?ax-E:ax,vx0),R_=Math.min(bx,vx1),T_=Math.max(dir==='y'?ay-E:ay,vy0),B_=Math.min(by,vy1);if(L>=R_||T_>=B_)return;
    const gr=dir==='x'?ctx.createLinearGradient(ax-E,0,ax,0):ctx.createLinearGradient(0,ay-E,0,ay);
    // плавная S-кривая (smootherstep по 13 точкам): к границе сектора мгла полная, обрыва нет
    for(let q=0;q<=12;q++){const u=q/12,a=u*u*u*(u*(u*6-15)+10);gr.addColorStop(u,'rgba(3,5,11,'+(a*.985).toFixed(3)+')');}ctx.fillStyle=gr;ctx.fillRect(L,T_,R_-L,B_-T_);
    if(SET.fx){const st=mob?420:260;const puff=(cx,cy,r)=>{const rg=ctx.createRadialGradient(cx,cy,0,cx,cy,r);rg.addColorStop(0,'rgba(3,5,11,.55)');rg.addColorStop(1,'rgba(3,5,11,0)');ctx.fillStyle=rg;ctx.fillRect(cx-r,cy-r,r*2,r*2);};
      if(dir==='x'){for(let y=Math.floor(T_/st)*st;y<B_+st;y+=st){const k=y/st;puff(ax-60+Math.sin(t*.25+k*1.7)*70,y+Math.sin(t*.2+k)*60,170+50*Math.sin(t*.4+k*2.3));}}
      else{for(let x=Math.floor(L/st)*st;x<R_+st;x+=st){const k=x/st;puff(x+Math.sin(t*.2+k)*60,ay-50+Math.sin(t*.25+k*1.7)*60,170+50*Math.sin(t*.4+k*2.3));}}}
    if(dir==='x'?Math.abs(p.x-ax)<1000:Math.abs(p.y-ay)<1000){const hw=(mob?95:125)/SC,lx=clamp(dir==='x'?ax+190:p.x,CX+hw+8/SC,CX+W-hw-8/SC),ly=dir==='x'?clamp(p.y-40,T_+60,B_-60):ay+130;
      worldLabel(lx,ly,'ТУМАН ВОЙНЫ','#9fb0c4');worldLabel(lx,ly+18,mob?txt.replace(/^СЕКТОР [IVXL]+ · /,''):txt,'#6f8096');}};
  const i=F.sx===Infinity?-1:(()=>{for(let k=1;k<=10;k++)if(!secSeen(k))return k;return -1;})();
  if(i>0)wall(F.sx,0,WW,WH,'x',fogHint(i));
  if(!F.z&&F.sx>WORLD.sectors[11].box[0]){const b=WORLD.sectors[11].box;wall(b[0],b[1],b[2],b[3],'y','СЕКТОР XII · ПРОЙДИТЕ МИССИЮ 49');}}"""
R(OLD_NS,NEW_NS)
# стена в мире — сразу за старыми воротами и воротами XI/XII
R("  gate110(p,S);\n  // обломки рядом с кораблём\n","  gate110(p,S);fogWall(p);\n  // обломки рядом с кораблём\n")
# туман поверх мира: над узлами, врагами и обломками; выстрелы, корабль игрока и цифры урона — поверх тумана
R("w80Mask(sx-CX,sy-CY);\n  ctx.globalCompositeOperation='lighter';\n  const BC=shipBul();","w80Mask(sx-CX,sy-CY);\n  fogDraw(t);\n  ctx.globalCompositeOperation='lighter';\n  const BC=shipBul();")
# старт мира: миграция альфы
R("G.save=S;if(!S.contracts.init&&S.cleared>=2){","G.save=S;fogFix(S);if(!S.contracts.init&&S.cleared>=2){")
# туман исследования: клетки закрытых секторов не открываются и считаются неоткрытыми
R("&&!G.fog[j*FGW+i]){G.fog[j*FGW+i]=1;","&&!G.fog[j*FGW+i]&&!fogClosedAt(cx,cy)){G.fog[j*FGW+i]=1;")
R("const revealedAt=(x,y)=>G.fog&&G.fog[clamp(Math.floor(y/FOG),0,FGH-1)*FGW+clamp(Math.floor(x/FOG),0,FGW-1)]===1;",
  "const revealedAt=(x,y)=>!!G.fog&&G.fog[clamp(Math.floor(y/FOG),0,FGH-1)*FGW+clamp(Math.floor(x/FOG),0,FGW-1)]===1&&!fogClosedAt(x,y);")
R("function mapFog(){if(MAPC.fog&&MAPC.fogVer===G.fogVer)return MAPC.fog;","function mapFog(){const fk=fogMemo().k;if(MAPC.fog&&MAPC.fogVer===G.fogVer&&MAPC.fogK===fk)return MAPC.fog;")
R("for(let j=0;j<FGH;j++)for(let i=0;i<FGW;i++)if(G.fog[j*FGW+i]){const x=(i+.5)*FOG*sc,","for(let j=0;j<FGH;j++)for(let i=0;i<FGW;i++)if(G.fog[j*FGW+i]&&!fogClosedAt((i+.5)*FOG,(j+.5)*FOG)){const x=(i+.5)*FOG*sc,")
R("MAPC.fog=c2;MAPC.fogVer=G.fogVer;return c2;}","MAPC.fog=c2;MAPC.fogVer=G.fogVer;MAPC.fogK=fk;return c2;}"+r"""
// 1.0.0 α: карта — всё скрытое (неисследованное, закрытые туманом войны сектора, Разлом вне секторов) выглядит как один и тот же
// космос за краем мира: фон и звёзды. Видимость считается полем на сетке 200 ед., размывается в коде (три прохода коробки по осям,
// σ ≈ 700 ед.) и сглаживается S-кривой — переходы очень плавные на любом устройстве, без ctx.filter.
const MAPH={R:200,P:8};
function mapHide(){const F=fogMemo(),key=(G.fogVer||0)+'|'+F.k;if(MAPC.hide&&MAPC.hideK===key)return MAPC.hide;
  const R=MAPH.R,P=MAPH.P,gw=Math.ceil(WW/R)+2*P,gh=Math.ceil(WH/R)+2*P,n=gw*gh,v=new Float32Array(n),u=new Float32Array(n);
  // cv — закрытые туманом войны сектора: их край гаснет целиком на открытой стороне (за границей ничего не просвечивает)
  const cv=new Float32Array(n),oa=openAllNow();
  for(let j=0;j<gh;j++)for(let i=0;i<gw;i++){const x=(i-P+.5)*R,y=(j-P+.5)*R,q=j*gw+i;
    if(!oa&&fogClosedAt(clamp(x,0,WW),clamp(y,0,WH)))cv[q]=1;if(j>=P&&j<gh-P&&i>=P&&i<gw-P)v[q]=inSectors(x,y)&&revealedAt(x,y)?1:0;}
  const r=3,blur=(a,b,hz)=>{const Ln=hz?gw:gh,M=hz?gh:gw,at=(m,q)=>{q=q<0?0:q>=Ln?Ln-1:q;return hz?a[m*gw+q]:a[q*gw+m];};
    for(let m=0;m<M;m++){let s=0;for(let q=-r;q<=r;q++)s+=at(m,q);for(let q=0;q<Ln;q++){b[hz?m*gw+q:q*gw+m]=s/(2*r+1);s+=at(m,q+r+1)-at(m,q-r);}}};
  for(let k=0;k<3;k++){blur(v,u,true);blur(u,v,false);}
  if(!oa)for(let k=0;k<3;k++){blur(cv,u,true);blur(u,cv,false);}
  const c=document.createElement('canvas');c.width=gw;c.height=gh;const g=c.getContext('2d'),im=g.createImageData(gw,gh),d=im.data;
  for(let q=0;q<n;q++){let a=(v[q]-.06)/(.82-.06);a=a<0?0:a>1?1:a;a=a*a*(3-2*a);
    // к краю мира видимость гаснет плавно: туманности за краем нет, обрыва быть не должно
    const x=((q%gw)-P+.5)*R,y=(Math.floor(q/gw)-P+.5)*R;let f=Math.min(x,WW-x,y,WH-y)/1100;f=f<0?0:f>1?1:f;f=f*f*(3-2*f);a*=f;
    let e=1-(cv[q]-.015)/(.5-.015);e=e<0?0:e>1?1:e;a*=e*e*(3-2*e);
    d[q*4+3]=Math.round((1-a)*255);}
  g.putImageData(im,0,0);MAPC.hide=c;MAPC.hideK=key;MAPC.hideDark=null;return c;}
function mapHideTint(){return mapHideDark();}
function mapHideDark(){const hm=mapHide();if(MAPC.hideDark)return MAPC.hideDark;const c=document.createElement('canvas');c.width=hm.width;c.height=hm.height;const g=c.getContext('2d');
  g.fillStyle=MAP_BG;g.fillRect(0,0,c.width,c.height);g.globalCompositeOperation='destination-in';g.imageSmoothingEnabled=true;g.drawImage(hm,0,0);MAPC.hideDark=c;return c;}
// поверх содержимого карты — скрытое закрывается цветом фона (одна растянутая маска), затем звёзды и мягкая виньетка поверх всего
function mapSpace(g,X,Y,k,w,h,t,fx,V_){const pd=MAPH.P*MAPH.R;g.save();g.globalAlpha=1;g.globalCompositeOperation='source-over';g.imageSmoothingEnabled=true;
  g.drawImage(mapHideTint(),X(-pd),Y(-pd),(WW+2*pd)*k,(WH+2*pd)*k);g.restore();
  mapStarsDraw(g,w,h,k,V_,fx,t);g.globalAlpha=1;
  const vg=g.createRadialGradient(w/2,h/2,Math.min(w,h)*.25,w/2,h/2,Math.max(w,h)*.78);vg.addColorStop(0,'rgba(1,2,6,0)');vg.addColorStop(1,'rgba(1,2,6,.5)');g.fillStyle=vg;g.fillRect(0,0,w,h);}""")
# раздел 1 (фон и звёзды) — в функцию, чтобы слой космоса рисовал его точь-в-точь
_i=s.index("// 1. фон\n",s.index("function drawMap(){"))+len("// 1. фон\n");_j=s.index("  // 2. туманности",_i);_sec1=s[_i:_j]
_k=_sec1.find("const st=mapStars()")
if _k<0: sys.exit('m23: раздел 1 карты не найден')
_stars="  "+_sec1[_k:]
s=s[:_i]+"  g.fillStyle=MAP_BG;g.fillRect(0,0,w,h);\n"+s[_j:]
R("function drawMap(){","const MAP_BG='#050a15';\nfunction mapStarsDraw(g,w,h,k,V_,fx,t){\n"+_stars+"}\nfunction drawMap(){")
# старый тёмный туман исследования и рамка мира на телефоне — больше не рисуются; космос — перед гиперлиниями
R("g.drawImage(mapFog(),X(0),Y(0),WW*k,WH*k);if(isMob()){g.strokeStyle='rgba(127,154,181,.35)';g.lineWidth=1;g.setLineDash([6,6]);g.strokeRect(X(0),Y(0),WW*k,WH*k);g.setLineDash([]);}","")
R("  // 5. гиперлинии\n  const NS=m=>nodeState(m);","  mapSpace(g,X,Y,k,w,h,t,fx,V_);\n  // 5. гиперлинии\n  const NS=m=>nodeState(m);")
# закрытые туманом войны сектора: маршруты, значки и названия не рисуются вовсе
R("  for(const sg of mapSegs()){const b=sg.bb;if(X(b[2])<-20||X(b[0])>w+20||Y(b[3])<-20||Y(b[1])>h+20)continue;","  for(const sg of mapSegs()){const b=sg.bb;if(X(b[2])<-20||X(b[0])>w+20||Y(b[3])<-20||Y(b[1])>h+20)continue;if(!openAllNow()&&fogClosedAt(sg.b.x,sg.b.y))continue;")
R("const add=(kind,x,y,o,lab)=>{if(!vis(x,y,30))return;","const add=(kind,x,y,o,lab)=>{if(!vis(x,y,30))return;if(kind!=='lost'&&kind!=='unk'&&!openAllNow()&&fogClosedAt(x,y))return;")
R("WORLD.sectors.forEach((sc,i)=>{const b=sc.box,cx=(b[0]+b[2])/2,cy=b[0]===0||b[0]===5000?b[3]-700:(b[1]+b[3])/2;if(!vis(cx,cy,300))return;","WORLD.sectors.forEach((sc,i)=>{const b=sc.box,cx=(b[0]+b[2])/2,cy=b[0]===0||b[0]===5000?b[3]-700:(b[1]+b[3])/2;if(!vis(cx,cy,300))return;if(!openAllNow()&&!secSeen(i))return;")
# подпись тумана войны в первом закрытом секторе
R("  // 8. корабль и точки прыжка\n","""  // 1.0.0 α: подпись над первым закрытым сектором (сам сектор — космос, как пустота вокруг)
  if(!openAllNow()){const F=fogMemo();
    const label=(bb,txt)=>{const L=Math.max(0,X(bb[0])),T_=Math.max(0,Y(bb[1])),R_=Math.min(w,X(bb[2])),B_=Math.min(h,Y(bb[3]));if(R_-L<40||B_-T_<40)return;
      const t2=isMob()?txt.replace(/^СЕКТОР [IVXL]+ · /,''):txt;g.font='700 '+(isMob()?10:11)+'px "JetBrains Mono",monospace';g.textAlign='center';
      const tw=Math.max(g.measureText('ТУМАН ВОЙНЫ').width,g.measureText(t2).width)+6,x0=clamp(L+14,6,w-tw-6),cy=B_-T_>140?clamp(T_+48,T_+22,B_-22):(T_+B_)/2;g.textAlign='left';
      g.globalAlpha=.9;g.fillStyle='#8a9bb3';g.fillText('ТУМАН ВОЙНЫ',x0,cy-8);g.fillStyle='#5f7088';g.fillText(t2,x0,cy+9);g.globalAlpha=1;};
    let i=-1;for(let q=1;q<=10;q++)if(!secSeen(q)){i=q;break;}
    if(i>0)label(WORLD.sectors[i].box,fogHint(i));if(!F.z&&F.sx>WORLD.sectors[11].box[0])label(WORLD.sectors[11].box,'СЕКТОР XII · ПРОЙДИТЕ МИССИЮ 49');}
  // 8. корабль и точки прыжка
""")
# обзор мира в углу: то же поле видимости
R("g.globalAlpha=.8;g.drawImage(mapFog(),mx,my,mw,mh);g.globalAlpha=1;","g.imageSmoothingEnabled=true;{const hd=mapHideDark(),P_=MAPH.P;g.drawImage(hd,P_,P_,hd.width-2*P_,hd.height-2*P_,mx,my,mw,mh);}")
# мини-карта: туман справа от кромки
R("  g.translate(s/2,s/2);g.rotate(p.ang);g.fillStyle=shipCol();","  if(!openAllNow()){const fx=fogSeeX();if(fx<Infinity){const [gx]=P(fx,0);if(gx<s+30){const gr=g.createLinearGradient(gx-26,0,gx+4,0);gr.addColorStop(0,'rgba(3,5,11,0)');gr.addColorStop(1,'rgba(3,5,11,.95)');g.fillStyle=gr;g.fillRect(Math.max(0,gx-26),0,s,s);}}}\n  g.translate(s/2,s/2);g.rotate(p.ang);g.fillStyle=shipCol();")
# прыжки по карте — только в открытые сектора
R("label:'∞'});return pts;}","label:'∞'});return pts.filter(q=>!fogBlockedAt(q.x,q.y-150));}")
R("['locked','помехи']","['locked','закрыто · туман']")

# ———————————————————————————————— версия
R('<div class="eyebrow">АЛЬФА 0.9.9 · НУЛЕВОЙ МИГ</div>','<div class="eyebrow">1.0.0 АЛЬФА · ТУМАН ВОЙНЫ</div>')
R("if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.9.9 α</dt>","if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>1.0.0 α</dt><dd>«Туман войны». Миссии открываются по порядку: следующая — только после предыдущей. Сектор закрыт туманом войны, пока не пройдена последняя миссия предыдущего сектора: на карте и в мире он скрыт, стена тумана не пускает за кромку (и облететь её сверху нельзя), прыжок туда недоступен. Сектор II, как и раньше, — после миссии 06 и двух замков ворот, сектор XII — после «Мига» (49). Сохранение больше не теряется после обновлений: прогресс копируется в облако артефакта (личная папка игрока) и возвращается при следующем запуске, а если браузер не даёт писать — держится в памяти вкладки. Коды сохранения: вставка прощает кавычки, переносы, невидимые пробелы и текст вокруг кода; «Копировать» работает и во встроенном окне; экран кода и меню показывают, где хранится прогресс. Карта: всё скрытое — неисследованное, закрытые сектора и Разлом между секторами — выглядит как та же чёрная пустота со звёздами, что и вокруг мира; между открытым и скрытым — широкие плавные градиенты, у закрытого сектора мгла полная уже на его границе. В мире кромка тумана — такая же плавная чёрная мгла, корабль и выстрелы видны поверх неё.</dd><dt>0.9.9 α</dt>")

open(P,'w',encoding='utf8').write(s)
print('m23 ok')
