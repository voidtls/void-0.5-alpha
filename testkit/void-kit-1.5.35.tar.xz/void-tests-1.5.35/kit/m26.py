# 1.2.0 α · m26: режим «Эхо» удалён полностью (вход, флаг, медаль, контракт, клавиша, кнопка, тексты) + миграция сохранений
import sys,os
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m26 FAIL count',n,'!=',cnt,'for',a[:100]);sys.exit(1)
    s=s.replace(a,b)
# флаг режима и его эффекты
R("  if(G.echo&&!G.world&&!STATIC.has(type)&&!d.passive&&type!=='boss'){e.hp*=1.3;e.maxHp=e.hp;}\n","")
R("affixCh:G.echo?Math.max(.45,M.affix||0):(M.affix||0),","affixCh:(M.affix||0),")
R("$('#inThreat').innerHTML=(G.echo?'<span class=\"tag mod\">ЭХО</span>':'')+dangerTag(M)","$('#inThreat').innerHTML=dangerTag(M)")
R("G.devStep=step0||1;G.echo=false;G.world=false;","G.devStep=step0||1;G.world=false;")
R("G.mode='dev';G.devRun=true;G.world=false;G.echo=!!D.echo;","G.mode='dev';G.devRun=true;G.world=false;")
R("lightFull:0,affixCh:0,echo:false,endT:0,","lightFull:0,affixCh:0,endT:0,")
R("  G.world=false;G.echo=!!echo;G.card=null;","  G.world=false;G.card=null;")
R("  if(G.echo&&!md.echo){md.echo=1;got.push('Эхо');lom+=60;}\n","")
R("if(G.echo)conEvent('clearEcho');","")
R("'МИССИЯ ВЫПОЛНЕНА')+(G.echo?' · ЭХО':'');","'МИССИЯ ВЫПОЛНЕНА');")
R("${mrow(md.echo,'Эхо','в режиме «Эхо»')}","")
# сектор: кнопка, клавиша, точки медалей
R("<i class=\"echo ${md.echo?'on':''}\"></i>","")
R("${done?`<button class=\"wbtn violet\" data-act=\"echo\">ЭХО [R]</button>`:''}","")
R("if(e.code==='KeyR')cardAct('echo');","")
R("if(c.kind==='node'){if(act==='echo'){if(nodeState(c.n.m)==='done')enterNode(c.n.m,true);}else{","if(c.kind==='node'){if(act==='echo')return;{")
R("const arr=[md.clear,md.clean,md.master,md.echo];arr.forEach((on,i)=>{ctx.fillStyle=on?(i===3?'#b48cff':'#ffb84d'):'#26324a';ctx.beginPath();ctx.arc(n.x-15+i*10,",
  "const arr=[md.clear,md.clean,md.master];arr.forEach((on,i)=>{ctx.fillStyle=on?'#ffb84d':'#26324a';ctx.beginPath();ctx.arc(n.x-10+i*10,")
R("[md.clear,md.clean,md.master,md.echo].forEach((on,i)=>{ctx.fillStyle=on?(i===3?'#b48cff':'#ffb84d'):'#26324a';ctx.beginPath();ctx.arc(n.x-15+i*10,",
  "[md.clear,md.clean,md.master].forEach((on,i)=>{ctx.fillStyle=on?'#ffb84d':'#26324a';ctx.beginPath();ctx.arc(n.x-10+i*10,")
R("if(k==='third')md.echo=1;","")
R("const medalCount=md=>md?(md.clear?1:0)+(md.clean?1:0)+(md.master?1:0)+(md.echo?1:0):0;","const medalCount=md=>md?(md.clear?1:0)+(md.clean?1:0)+(md.master?1:0):0;")
# контракт и меню разработчика
R("  {id:'c_echo',s:'Эхо',t:()=>'Пройти миссию в режиме «Эхо»',ev:'clearEcho',n:[1,1],req:2},\n","")
R("['echo','Режим «Эхо»'],","")
R("G.dev=Object.assign({build:'typ',god:false,bcGod:false,echo:false,","G.dev=Object.assign({build:'typ',god:false,bcGod:false,")
# справочник
R("['R','Войти в режиме «Эхо»'],","")
R("'Прохождение, чистота (почти без урона), мастерство (своё условие у каждой миссии) и эхо — повтор с усиленными врагами.'",
  "'Прохождение, чистота (почти без урона) и мастерство — своё условие у каждой миссии.'")
# миграция: медаль «Эхо» и её контракт исчезают из сохранения; лом, полученный за неё, остаётся
R("for(const f of ['clear','clean','master','echo'])if(v[f])o[f]=1;","for(const f of ['clear','clean','master'])if(v[f])o[f]=1;")
# миссия 2: название не должно путаться с удалённым режимом
R("{name:'Эхо выстрелов',","{name:'Отзвук выстрелов',")
# CSS точки «эхо»
R(".medals i.echo{border-color:var(--violet)}.medals i.echo.on{background:var(--violet)}","")
# после загрузки — пополнить контракты, если удалённый «эхо»-контракт освободил место
R("  G.save=S;fogFix(S);if(!S.contracts.init&&S.cleared>=2){fillContracts();S.contracts.init=1;}",
  "  G.save=S;fogFix(S);if(!S.contracts.init&&S.cleared>=2){fillContracts();S.contracts.init=1;}else if(S.contracts.init&&S.contracts.list.length<3){try{fillContracts();}catch(e){}}")
import re
if re.search(r"G\.echo\b(?!\w)|md\.echo\b|'c_echo'|clearEcho",s):
    print('m26 FAIL leftovers');sys.exit(1)
open(P,'w',encoding='utf8').write(s)
print('m26 ok')
