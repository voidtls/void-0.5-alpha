# 1.5.9 α «Опора» — ARCH·69: этап 1 мета-промпта второго уровня (дефекты без изменения игры)
import sys,os
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m69 FAIL',n,a[:80]);sys.exit(1)
    s=s.replace(a,b)
R('<div class="ver" id="verTag">1.5.8 α</div>','<div class="ver" id="verTag">1.5.9 α</div>')
R("const VER_TAG='1.5.8 α';","const VER_TAG='1.5.9 α';")
J=open(D+'m69_journal159.txt',encoding='utf8').read().strip()
R('<dl class="kv"><dt>1.5.8 α</dt>','<dl class="kv"><dt>1.5.9 α</dt><dd>'+J+'</dd><dt>1.5.8 α</dt>')
# блок ARCH·69 — первым в главном скрипте (флаги нужны кадру и загрузке)
js=open(D+'m69.js',encoding='utf8').read()
R('<script>\n"use strict";\n','<script>\n"use strict";\n'+js+'\n')
# A-1 · карта: новый запуск цикла гасит прежний
R("if(t==='jr')renderJournals($('#mapJr'),true);else mapLoop();}","if(t==='jr')renderJournals($('#mapJr'),true);else{ARCH.mapGen++;mapLoop();}/* ARCH·69 A-1 */}")
R("drawMap();requestAnimationFrame(mapLoop);}","drawMap();arch69MapNext();/* ARCH·69 A-1 */}")
# A-4 · предохранитель стадии симуляции/мира в frame()
R("else if(G.state==='arsenal')arsDemoTick(now);}catch(err){console.error(err);}","else if(G.state==='arsenal')arsDemoTick(now);arch69Ok();}catch(err){console.error(err);arch69Fault(err);/* ARCH·69 A-4 */}")
# A-2 + A-3 · последняя строка главного скрипта: все обёртки migrateSave уже на месте
i=s.rindex('</script>');s=s[:i]+'/* ARCH·69 A-2 · A-3 */arch69Boot();\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m69 ok')
