# 1.5.9 α «Опора» · этап 0 (стенд доказательств) + этап 1 (дефекты). Сборки: эталон 1.5.8 (void_v46), новая «вкл», новая «выкл» (__archOff).
# Каждая проверка этапа 0 сопровождается мутантом: в него вносится порча, и проверка обязана её поймать.
import asyncio,json,sys,os,subprocess
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
NEW=os.environ.get('GAME_URL','file://@@KIT@@/home/void_t.html')
BASE='file://'+SP+'void_v46.html'
ARCHOFF="window.__archOff=['A-1','A-2','A-3','A-4'];"
VARIANTS=[('base',BASE,''),('on',NEW,''),('off',NEW,ARCHOFF)]
ISO="{if(!window.__iso360){window.__iso360=1;const mi=makeImpulse;makeImpulse=function(){const mr=Math.random;Math.random=mulberry(4096);try{return mi.apply(this,arguments);}finally{Math.random=mr;}};}}"
def MUT(code):return "addEventListener('DOMContentLoaded',()=>{try{"+code+"}catch(e){}});"
MUT_RNG=MUT("const se=spawnEnemy;spawnEnemy=function(){Math.random();return se.apply(this,arguments);};")
def same3(o):
    j=[json.dumps(o[k],sort_keys=True) for k in ('base','on','off')];return j[0]==j[1]==j[2]
async def run_in(b,url,code,init='',w=1280,h=760,touch=False):
    P=await newpage(b,w,h,url=url,init=init or None,touch=touch);r=await P.js(code);e=P.errs[:3];await P.pg.context.close();return r,e

# ---------- A0-1 · золотые повторы: 12 миссий + босс 50 ----------
PILOT=("const pilot=(s)=>{const p=G.player;if(!p)return;p.hp=Math.max(p.hp,G.st.maxHp*.6);if(G.bc)G.bc.hp=Math.max(G.bc.hp,G.bc.maxHp*.6);const a=s/150;"
       "const tg=G.boss||null;steer2((tg?tg.x:W/2)+Math.cos(a)*(tg?220:W*.28),(tg?tg.y:H/2)+Math.sin(a)*(tg?220:H*.28));if(s%140===0)tryDash();if(p.en>=100)tryPulse();};")
SIG=("const sig=()=>{const p=G.player;let ph=0;for(const q of G.parts)ph=(ph*31+Math.round(q.x*8)+Math.round(q.y*8)*7+Math.round(q.life*1000))%1000000007;"
     "return {st:G.state,t:G.mT!=null?+(+G.mT).toFixed(3):null,k:G.kills,tk:Math.round(G.taken||0),x:p?+p.x.toFixed(4):null,y:p?+p.y.toFixed(4):null,hp:p?+p.hp.toFixed(4):null,lvl:G.lvl,lom:G.save&&G.save.lom,"
     "e:G.enemies.filter(e=>e.alive).map(e=>e.type+':'+e.x.toFixed(3)+':'+e.y.toFixed(3)+':'+Math.round(e.hp)).join(','),"
     "boss:G.boss?[G.boss.st,G.boss.phase,Math.round(G.boss.hp)]:null,zb:G.zb?[G.zb.k,G.zb.stage,G.zb.boss?Math.round(G.zb.boss.hp):null]:null,np:G.parts.length,ph,rnd:Math.random()};};")
def mission_js(m,sec):
    return ("async()=>{"+ISO+PILOT+SIG+"Math.random=mulberry(777);G.layoutSeed=55;G.keepLayout=true;T.fresh();G.save.tut.off=1;"
            "{const S=G.save;S.cleared=Math.max(S.cleared,%d-1);for(let k=1;k<%d;k++)S.medals[k]={clear:1};}enterNode(%d);if(G.state==='intro')startMission();"%(m,m,m)+
            "const mid=[];let s=0;for(;s<60*%d;s++){if(G.state==='levelup'){let k=0;while(G.state==='levelup'&&k++<60)choose(0);}if(G.state!=='play')break;pilot(s);update(1/60);if(s%%4===0)render(1000+s*16.667);if(s===60*%d)mid.push(sig());}"%(sec,sec//2)+
            "return {steps:s,mid:mid[0]||null,end:sig()};}")
ZB_JS=("async()=>{"+ISO+SIG+"Math.random=mulberry(778);T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=49;for(let k=1;k<50;k++)S.medals[k]={clear:1};G.zbCool=0;const n=zbNode();G.player.x=n.x-200;G.player.y=n.y;const ok=zbStart();"
       "const ks=[];let s=0;for(;s<60*180&&G.zb;s++){const Z=G.zb;if(G.state==='levelup'){let k=0;while(G.state==='levelup'&&k++<60)choose(0);}if(Z.k==='choice'){try{zbChoose(0);}catch(e){}}"
       "const p=G.player;p.hp=Math.max(p.hp,G.st.maxHp*.6);const a=s/150,bx=Z.boss?Z.boss.x:n.x,by=Z.boss?Z.boss.y:n.y;steer2(bx+Math.cos(a)*220,by+Math.sin(a)*220);if(G.state!=='world')break;worldUpdate(1/60);if(s%4===0)renderWorld(1000+s*16.667);"
       "if(!ks.length||ks.at(-1)[0]!==Z.k)ks.push([Z.k,s,Z.stage]);}return {ok,steps:s,stages:ks.map(x=>x[0]+x[2]).join(' '),end:sig()};}")
@test('A01')
async def a01(b):
    res={};ok=True
    for m in [1,2,10,6,14,18,22,27,31,38,42,46]:
        code=mission_js(m,60);o={k:(await run_in(b,u,code,i)) for k,u,i in VARIANTS}
        s=same3({k:v[0] for k,v in o.items()});er=[v[1] for v in o.values() if v[1]];ok&=s and not er
        e=o['on'][0]['end'];res[m]=('=' if s else 'DIFF')+f" шагов {o['on'][0]['steps']} · убито {e['k']} · {e['st']}"+(' ОШИБКИ '+str(er) if er else '')
        print('   ',m,res[m],flush=True)
    o={k:(await run_in(b,u,ZB_JS,i)) for k,u,i in VARIANTS}
    s=same3({k:v[0] for k,v in o.items()});er=[v[1] for v in o.values() if v[1]];ok&=s and not er and o['on'][0]['ok']
    res[50]=('=' if s else 'DIFF')+f" шагов {o['on'][0]['steps']} · стадии {o['on'][0]['stages'][:120]}"
    print('    50',res[50],flush=True)
    # мутант: лишний Math.random в spawnEnemy — повтор обязан разойтись
    mu=(await run_in(b,BASE,mission_js(6,60),MUT_RNG))[0];bs=(await run_in(b,BASE,mission_js(6,60)))[0]
    caught=json.dumps(mu,sort_keys=True)!=json.dumps(bs,sort_keys=True);ok&=caught;res['мутант']='пойман' if caught else 'НЕ ПОЙМАН'
    rec('A01 золотые повторы: миссии 01, 02, 10 и боссы 06, 14, 18, 22, 27, 31, 38, 42, 46 по 60 с + босс 50 (бой в мире, 180 с, все стадии) — 1.5.8, «вкл» и «выкл» совпадают до бита; мутант с лишним случайным числом пойман',ok,res)

# ---------- A0-2 · отпечаток цепочек и владельцы G ----------
@test('A02')
async def a02(b):
    html=NEW.replace('file://','')
    r=subprocess.run(['python3',SP+'archcheck.py','diff',SP+'arch_fp_v46.json',html,SP+(lambda s:'arch_allow_74.json' if 'ARCH·73' in s else 'arch_allow_69_70.json' if 'ARCH·70' in s else 'arch_allow_69.json')(open(html,encoding='utf8').read())],capture_output=True,text=True)
    m1=subprocess.run(['python3',SP+'archcheck.py','diff',SP+'arch_fp_v46.json',SP+'mut_chain.html'],capture_output=True,text=True).returncode
    m2=subprocess.run(['python3',SP+'archcheck.py','diff',SP+'arch_fp_v46.json',SP+'mut_owner.html'],capture_output=True,text=True).returncode
    rec('A02 отпечаток 129 цепочек обёрток (209 мест) и писателей 276 ключей G совпадает с 1.5.8 с учётом заявленных изменений; мутанты (перестановка обёрток musTarget, запись G.state из неба) пойманы',r.returncode==0 and m1==1 and m2==1,{'new':r.stdout.strip()[:400],'mut_chain':m1,'mut_owner':m2})

# ---------- A0-3 · перепись потребителей игрового Math.random ----------
CENSUS=r"""()=>{Error.stackTraceLimit=80;const orig=Math.random;window.__rc={};window.__rcOn=false;const SIM=/^(update|worldUpdate|startMission|enterNode|choose|nextPick|openLevelUp|startWorld|prologueTick|zbStart|spawnEnemy|kill|hurt)$/;
 Math.random=function(){if(__rcOn&&!window.__harness){const st=(new Error).stack.split('\n').slice(2,40).map(x=>{const m=x.trim().match(/^at (?:Object\.)?([\w$.<>]+)/);return m?m[1]:'?';});
   if(!st.some(f=>SIM.test(f))){const k=st.slice(0,3).join(' ← ');__rc[k]=(__rc[k]||0)+1;}}return orig();};}"""
# известные потребители вне симуляции: звук (этап 2) и статика миникарты в бою с боссом 50 (находка 1.5.9, этап 2)
ALLOWED=('scapeRun','bell','musSched','makeImpulse','musInit','setChord','v12Retune','zbMapStatic')
@test('A03')
async def a03(b):
    async def census(url,init):
        out={}
        for name,setup,secs in [('мир',"()=>{T.fresh();G.save.tut.off=1;}",5),('m02',"()=>{T.fresh();G.save.tut.off=1;enterNode(2);if(G.state==='intro')startMission();}",5),
                                ('m46',"()=>{T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=45;for(let k=1;k<46;k++)S.medals[k]={clear:1};enterNode(46);if(G.state==='intro')startMission();}",5),
                                ('босс50',"()=>{T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=49;for(let k=1;k<50;k++)S.medals[k]={clear:1};G.zbCool=0;const n=zbNode();G.player.x=n.x-200;G.player.y=n.y;zbStart();}",8)]:
            P=await newpage(b,1280,760,url=url,init=init or None);await P.js(CENSUS);await P.js(setup);await P.js("()=>{__rcOn=true;}")
            for i in range(secs*4):
                await P.js("()=>{window.__harness=1;try{const p=G.player;if(p&&G.st)p.hp=Math.max(p.hp,G.st.maxHp*.7);let n=0;while(G.state==='levelup'&&n++<60)choose(0);if(G.zb&&G.zb.k==='choice')zbChoose(0);}finally{window.__harness=0;}}");await P.wait(250)
            r=await P.js("()=>{__rcOn=false;return __rc;}");out[name]=r;await P.pg.context.close()
        bad={k:v for sc in out.values() for k,v in sc.items() if not any(a in k for a in ALLOWED)}
        return out,bad
    out,bad=await census(NEW,'')
    _,badm=await census(NEW,"setInterval(()=>{Math.random();},100);")
    ok=not bad and bool(badm)
    rec('A03 перепись игрового Math.random в реальном цикле (мир, миссии 02 и 46, босс 50): вне симуляции его берут только известные потребители звука (звук: musSched/scapeRun/v12Retune/makeImpulse; статика миникарты босса 50 zbMapStatic — всё в этап 2); мутант с таймером, берущим случайность, пойман',ok,{'вне_симуляции_разрешённые':{k:v for sc in out.values() for k,v in sc.items()},'новые':bad,'мутант':list(badm)[:3]})

# ---------- A0-4 · фикстуры сохранений ----------
FIXGEN=r"""()=>{const out={};const snap=()=>{saveWorld();return localStorage.getItem('void_world');};
 T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=3;for(let k=1;k<=3;k++)S.medals[k]={clear:1};S.lom=120;out.early=snap();
 S.cleared=24;for(let k=1;k<=24;k++)S.medals[k]={clear:1};S.lom=940;out.mid=snap();
 S.cleared=49;for(let k=1;k<=49;k++)S.medals[k]={clear:1};S.lom=3100;out.prefinal=snap();
 S.cleared=50;S.medals[50]={clear:1};out.postfinal=snap();
 const v1=JSON.parse(out.early);v1.v=1;delete v1.pilot;delete v1.chase;delete v1.tut;v1.run.mods={dmg:2,rate:1};out.v1=JSON.stringify(v1);
 out.trunc=out.mid.slice(0,out.mid.length-40);out.invalid='{"v":2,"cleared":3}';out.garbage='не json';return out;}"""
NORM="const norm=(o)=>JSON.stringify(o,(k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.keys(v).sort().reduce((a,x)=>(a[x]=v[x],a),{}):v);"
def fix_path():return SP+'fixtures_v46.json'
async def fix_load(b,url,raw,init=''):
    """страница стартует с этим сохранением; возвращает G.save на загрузке и полное migrateSave(raw)"""
    ctx=await b.new_context(viewport={'width':1280,'height':760})
    await ctx.add_init_script("window.__alpha=true;if(!sessionStorage.getItem('fx')){sessionStorage.setItem('fx','1');localStorage.clear();localStorage.setItem('void_world',"+json.dumps(raw)+");}"+init)
    pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
    await pg.goto(url);await pg.wait_for_timeout(700)
    r=await pg.evaluate("()=>{"+NORM+"const raw=localStorage.getItem('void_world');let full=null,twice=null;try{full=migrateSave(JSON.parse(raw));}catch(e){full='ERR';}try{twice=full&&full!=='ERR'?migrateSave(JSON.parse(JSON.stringify(full))):null;}catch(e){twice='ERR';}"
                        "return {boot:G.save?norm(G.save):null,full:full&&full!=='ERR'?norm(full):full,idem:twice&&twice!=='ERR'?norm(twice)===norm(full):null,toast:!$('#toast').hidden?$('#toast').textContent.slice(0,80):''};}")
    # новая игра поверх: что стало с исходными байтами
    r2=await pg.evaluate("()=>{try{startWorld(!G.save);saveWorld();}catch(e){}const k=Object.keys(localStorage).filter(k=>k.startsWith('void_world_bad'));return {bad:k.map(x=>localStorage.getItem(x)),keys:k};}")
    await ctx.close();r.update(r2);r['errs']=errs;return r
@test('A04')
async def a04(b):
    if not os.path.exists(fix_path()):
        P=await newpage(b,1280,760,url=BASE);fx=await P.js(FIXGEN);await P.pg.context.close()
        exp={}
        for k,raw in fx.items():exp[k]=await fix_load(b,BASE,raw)
        json.dump({'raw':fx,'exp':exp},open(fix_path(),'w'),ensure_ascii=False)
    F=json.load(open(fix_path()));res={};ok=True;defect={}
    for k,raw in F['raw'].items():
        e=F['exp'][k];n=await fix_load(b,NEW,raw);f=await fix_load(b,NEW,raw,ARCHOFF)
        same_full=n['full']==e['full']==f['full'];idem=(n['idem'] in (True,None)) and (e['idem'] in (True,None))
        boot_ok=n['boot']==n['full'] if n['full'] not in (None,'ERR') else n['boot'] is None
        bad_kept=(raw in n['bad']) if n['full'] in (None,'ERR') else (not n['keys'])
        ok&=same_full and idem and not n['errs']
        defect[k]={'boot=full 1.5.8':e['boot']==e['full'] if e['full'] not in (None,'ERR') else e['boot'] is None,'boot=full 1.5.9':boot_ok,'резерв 1.5.8':(raw in e['bad']) if e['full'] in (None,'ERR') else None,'резерв 1.5.9':bad_kept if n['full'] in (None,'ERR') else None}
        res[k]={'migrate_same':same_full,'idempotent':idem,'errs':n['errs'][:1]}
    # мутант: обёртка migrateSave теряет поле chase
    mu=await fix_load(b,NEW,F['raw']['mid'],MUT("const m=migrateSave;migrateSave=function(S){const r=m.apply(this,arguments);if(r)delete r.chase;return r;};"))
    caught=mu['full']!=F['exp']['mid']['full'];ok&=caught
    rec('A04 фикстуры сохранений (v1, раннее, середина, перед финалом, после финала, обрезанное, невалидное, мусор): полная миграция совпадает с 1.5.8 во всех трёх сборках и идемпотентна; мутант миграции пойман',ok,{'fixtures':res,'mutant':caught})
    # этап 1: дефектные проверки (на 1.5.8 должны падать, на 1.5.9 — проходить)
    d_boot=all(v['boot=full 1.5.9'] for v in defect.values());b_boot=all(v['boot=full 1.5.8'] for v in defect.values())
    d_bak=all(v['резерв 1.5.9'] for v in defect.values() if v['резерв 1.5.9'] is not None);b_bak=all(v['резерв 1.5.8'] for v in defect.values() if v['резерв 1.5.8'] is not None)
    rec('A11 порядок миграций (A-3): сохранение на загрузке уже прошло всю цепочку миграций — как на входе в мир (1.5.8: нет → 1.5.9: да)',d_boot,{'1.5.8':b_boot,'1.5.9':d_boot,'по фикстурам':defect})
    rec('A12 резерв нечитаемого сохранения (A-2): обрезанное, невалидное и мусорное сохранение копируются в void_world_bad до того, как новая игра их перезапишет (1.5.8: нет → 1.5.9: да)',d_bak and not b_bak,{'1.5.8':b_bak,'1.5.9':d_bak})

# ---------- A0-5 · детерминированные пиксели ----------
import pix_probe as PP
async def pix(b,url,kind,init=''):
    ctx=await b.new_context(viewport={'width':1280,'height':760});await ctx.route(lambda u:u.startswith('http'),lambda r:r.abort())
    await ctx.add_init_script('window.__alpha=true;'+PP.FREEZE+init);pg=await ctx.new_page();await pg.goto(url);await pg.wait_for_timeout(300);await pg.evaluate(LIB)
    await pg.evaluate("""()=>{window.T={fresh(){localStorage.removeItem('void_world');startWorld(true);if(G.prologue)prologueEnd();$('#toast').hidden=true;return G.state;}};}""")
    if kind=='map':
        r=await pg.evaluate("async()=>{"+PP.HASH+"__stopTimers();Math.random=mulberry(9);T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=9;for(let k=1;k<=9;k++)S.medals[k]={clear:1};openMap('map');__flushIdle();__tt+=16;drawMap();__tt+=16;drawMap();return [hsh($('#mapC'))];}")
    elif kind=='zb50':
        r=await pg.evaluate("async()=>{"+PP.ISO+PP.HASH+"__stopTimers();Math.random=mulberry(9);T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=49;for(let k=1;k<50;k++)S.medals[k]={clear:1};G.zbCool=0;const n=zbNode();G.player.x=n.x-200;G.player.y=n.y;zbStart();const hs=[];for(let s=0;s<1500;s++){const p=G.player;p.hp=G.st.maxHp;if(G.zb&&G.zb.k==='choice')zbChoose(0);let k=0;while(G.state==='levelup'&&k++<60)choose(0);__tt+=1000/60;worldUpdate(1/60);if(s%300===299){__flushIdle();renderWorld(__tt);mobOverlay(__tt);hs.push(hsh($('#cv')));}}return hs;}")
    else:
        r=await pg.evaluate(PP.scen(kind))
    await ctx.close();return r
@test('A05')
async def a05(b):
    res={};ok=True
    for kind in ['world','m02','m18','m46','zb50','map']:
        o={k:await pix(b,u,kind,i) for k,u,i in VARIANTS};b2=await pix(b,BASE,kind)
        s=o['base']==o['on']==o['off'];ctl=o['base']==b2;ok&=s and ctl;res[kind]={'same':s,'base=base':ctl,'кадров':len(o['on'])}
    mu=await pix(b,NEW,'m18',MUT("const sv=secVignette;secVignette=function(){const r=sv.apply(this,arguments);ctx.fillStyle='#010101';ctx.fillRect(5,5,1,1);return r;};"))
    caught=mu!=(await pix(b,NEW,'m18'));ok&=caught;res['мутант 1 пиксель']='пойман' if caught else 'НЕ ПОЙМАН'
    rec('A05 детерминированный пиксельный стенд (время, кадры, простой, ГСЧ загрузки и сеть зафиксированы): мир, миссии 02/18/46, босс 50, карта — 1.5.8, «вкл», «выкл» совпадают бит в бит, эталон сам с собой тоже; порча в 1 пиксель поймана',ok,res)

# ---------- A0-6 · file:// без сети ----------
async def offline(b,url,init=''):
    ctx=await b.new_context(viewport={'width':1280,'height':760});await ctx.route(lambda u:not u.startswith('file:'),lambda r:r.abort())
    if init:await ctx.add_init_script(init)
    pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append('PAGE '+str(e)[:150]));pg.on('console',lambda m:(m.type=='error' and 'net::' not in m.text and 'Failed to load resource' not in m.text) and errs.append('CON '+m.text[:150]))
    await pg.goto(url);await pg.wait_for_timeout(1500)
    r=await pg.evaluate("async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));const a=G.state;localStorage.removeItem('void_world');startWorld(true);if(G.prologue)prologueEnd();await w8(800);const b=G.state;enterNode(1);if(G.state==='intro')startMission();let n=0;while(G.state==='levelup'&&n++<60)choose(0);await w8(1500);return [a,b,G.state];}")
    await ctx.close();return r,errs
@test('A06')
async def a06(b):
    r,e=await offline(b,NEW);rm,em=await offline(b,NEW,"setTimeout(()=>{null.x},400);")
    rec('A06 запуск из file:// без сети в чистом профиле: меню → мир → миссия 01 без ошибок в консоли; мутант с ошибкой при загрузке пойман',r==['menu','world','play'] and not e and bool(em),{'states':r,'errs':e,'mutant':em[:1]})

# ---------- этап 1 ----------
@test('A13')
async def a13(b):
    code="""async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();G.save.tut.off=1;await w8(300);let n=0;const dm=drawMap;drawMap=function(){n++;return dm.apply(this,arguments);};
      openMap('map');await w8(1000);const a=n;n=0;for(let i=0;i<4;i++)mapTab('map');await w8(1000);const b_=n;n=0;mapTab('jr');await w8(200);mapTab('map');await w8(1000);const c=n;closeMap&&closeMap();await w8(100);n=0;await w8(500);return {once:a,after4:b_,afterSwitch:c,afterClose:n};}"""
    o={k:(await run_in(b,u,code,i))[0] for k,u,i in VARIANTS}
    good=lambda r:abs(r['after4']-r['once'])<=r['once']*.25+2 and r['afterClose']==0
    rec('A13 карта (A-1): повторные нажатия вкладки «Карта» не запускают второй цикл отрисовки (1.5.8 и «выкл»: в ~3 раза чаще)',good(o['on']) and not good(o['base']) and not good(o['off']),o)
@test('A14')
async def a14(b):
    code="""async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();G.save.tut.off=1;enterNode(2);if(G.state==='intro')startMission();let n=0;while(G.state==='levelup'&&n++<60)choose(0);await w8(400);n=0;while(G.state==='levelup'&&n++<60)choose(0);
      localStorage.removeItem('void_diag');const ce=console.error;let errs=0;console.error=function(){errs++;};const b9=buffs90;buffs90=function(){throw new Error('проба: сбой buffs90');};const t0=performance.now();
      let tp=null;for(let i=0;i<30;i++){await w8(100);if(G.state==='pause'&&tp===null)tp=performance.now()-t0;}buffs90=b9;console.error=ce;
      const d=localStorage.getItem('void_diag');return {state:G.state,pausedAfterMs:tp&&Math.round(tp),errors:errs,toast:!$('#toast').hidden?$('#toast').textContent.slice(0,60):'',diag:d?JSON.parse(d):null};}"""
    o={k:(await run_in(b,u,code,i))[0] for k,u,i in VARIANTS}
    on=o['on'];okon=on['state']=='pause' and on['diag'] and on['diag'].get('stage')=='sim' and 'проба' in on['diag'].get('msg','') and on['errors']<=40
    rec('A14 предохранитель симуляции (A-4): 30 кадров подряд с ошибкой → пауза, сообщение игроку и запись в void_diag вместо «замёрзшего» боя (1.5.8 и «выкл»: бой стоит, ошибки идут бесконечно)',okon and o['base']['state']=='play' and o['off']['state']=='play',o)
@test('A15')
async def a15(b):
    # предохранитель не срабатывает в мире при ошибке, которая случается один раз (ложное срабатывание недопустимо)
    code="""async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();G.save.tut.off=1;await w8(300);const ce=console.error;console.error=function(){};let once=true;const wu=worldUpdate;worldUpdate=function(){if(once){once=false;throw new Error('однократный сбой');}return wu.apply(this,arguments);};
      await w8(1500);worldUpdate=wu;console.error=ce;return {state:G.state,diag:localStorage.getItem('void_diag')};}"""
    r,_=await run_in(b,NEW,code)
    rec('A15 предохранитель: одиночная ошибка в мире не ставит игру на паузу (счётчик сбрасывается на первом удачном кадре)',r['state']=='world' and not r['diag'],r)

@test('A16')
async def a16(b):
    # аудит разницы: 1.5.9 минус блок ARCH·69 и его точечные места = 1.5.8 байт в байт (код боя, отрисовки, звука, боссов не тронут)
    new=open(NEW.replace('file://',''),encoding='utf8').read();base=open(BASE.replace('file://',''),encoding='utf8').read()
    import arch74 as _A74
    for _n in (75,74,73,72):
        if 'ARCH·%d'%_n in new:new=_A74.strip(new,_n)   # этап 4: сначала снимаются ARCH·72…75
    if 'ARCH·71' in new:
        from strip71 import strip71;new=strip71(new)   # 1.5.11: сначала снимается этап 3 (его аудит — orc71/strip71)
    if 'ARCH·70' in new:
        from strip70 import strip70;new=strip70(new)   # 1.5.10: сначала снимается этап 2 (его аудит — q380)
    js=open(SP+'m69.js',encoding='utf8').read();J=open(SP+'m69_journal159.txt',encoding='utf8').read().strip()
    t=new.replace('<script>\n"use strict";\n'+js+'\n','<script>\n"use strict";\n',1).replace('<dt>1.5.9 α</dt><dd>'+J+'</dd>','',1)
    t=t.replace('id="verTag">1.5.9 α<','id="verTag">1.5.8 α<',1).replace("const VER_TAG='1.5.9 α';","const VER_TAG='1.5.8 α';",1)
    t=t.replace("else{ARCH.mapGen++;mapLoop();}/* ARCH·69 A-1 */}","else mapLoop();}",1).replace("drawMap();arch69MapNext();/* ARCH·69 A-1 */}","drawMap();requestAnimationFrame(mapLoop);}",1)
    t=t.replace("arsDemoTick(now);arch69Ok();}catch(err){console.error(err);arch69Fault(err);/* ARCH·69 A-4 */}","arsDemoTick(now);}catch(err){console.error(err);}",1)
    t=t.replace("/* ARCH·69 A-2 · A-3 */arch69Boot();\n","",1)
    left=[k for k in ['ARCH.','arch69'] if t.count(k)!=base.count(k)]
    rec('A16 аудит разницы: если убрать из 1.5.9 блок ARCH·69, четыре помеченных места, версию и запись журнала, получается 1.5.8 байт в байт',t==base and not left,{'equal':t==base,'left':left,'len':[len(new),len(base)]})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or t[0] in sel],'res370.json'))
