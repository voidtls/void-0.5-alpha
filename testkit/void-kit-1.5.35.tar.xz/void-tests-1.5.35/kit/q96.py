# 0.9.6: доводка «до идеала» — проверки (часы Сердца, кульминация фазы 4, тревога, страж, миссия 41, звук, кадр, тексты)
import asyncio,json,sys,os
from h import *
src=open(SP+'q74.py').read();HELP=src[src.index('HELP="""')+8:src.index('"""',src.index('HELP="""')+8)]
q9=open(SP+'q90.py').read();H90=q9[q9.index('H90="""')+7:q9.index('"""',q9.index('H90="""')+7)]
q5=open(SP+'q95.py').read();H95=q5[q5.index('H95="""')+7:q5.index('"""',q5.index('H95="""')+7)]
def ok(name,cond,info=None):rec(name,cond,info)
async def page(b,**k):
    P=await newpage(b,**k);await P.js(HELP);await P.js(H90);await P.js(H95);return P
# ---------- V: Сердце ----------
async def V(b):
    P=await page(b)
    r=await P.js("""()=>{const b=T.b90('heart',{ph:1});const bt0=b.bt,n0=b.beatN;G.rdt90=.05;G.rdtU96=0;update(1/60);const d1=(b.beatN-n0)*b.btN+b.bt-bt0;
      const bt1=b.bt,n1=b.beatN;G.rdt90=1/60;G.rdtU96=2;update(1/120);update(1/120);const d2=(b.beatN-n1)*b.btN+b.bt-bt1;return [+d1.toFixed(4),+d2.toFixed(4),G.rdtU96];}""")
    ok('V01 часы Сердца: без кадра — dt симуляции, в кадре — реальное время подшагами (30 к/с не ускоряет удар)',abs(r[0]-1/60)<.002 and abs(r[1]-2/60)<.003 and r[2]==0,r)
    r=await P.js("()=>{const fr=frame.toString();return [fr.includes('G.rdtU96=(devOn('),fr.includes('G.rdt90=(G.rdt90||dt)/sub')];}")
    ok('V02 кадр делит реальное время на подшаги (телефон 30 к/с)',r[0] and r[1],r)
    r=await P.js("()=>{const out=[];for(const d of ['easy','mid','hard']){const b=T.b90('heart',{ph:4,diff:d});out.push([b.lN96,b.keyN]);}return out;}")
    ok('V03 фаза 4: запусков нужно 2 на Лёгкой, 3 на Нормальной и Тяжёлой',r==[[2,3],[3,4],[3,4]],r)
    r=await P.js("""()=>{const b=T.b90('heart',{ph:4});T.tick(1,T.god);const hs=[];for(let j=0;j<2;j++){heartLaunch(b,false);for(let i=0;i<300;i++){if(b.launch>0)hurt(b,500,{});T.tick(1/60,T.god);}hs.push(+(b.hp/b.maxHp).toFixed(4));}
      return [hs,b.st,b.launches];}""")
    ok('V04 Сердце не падает раньше последнего запуска: после 1-го ≥ 10%, после 2-го ≥ 5%',r[0][0]>=.0995 and r[0][1]>=.0495 and r[1]=='fight' and r[2]==2,r)
    r=await P.js("""()=>{const b=T.b90('heart',{ph:4});T.tick(1,T.god);heartLaunch(b,false);T.tick(4.3,T.god);const o1=b.keys.map(k=>k.ki).join('');const lab=heartDraw.toString().includes('[k.ki]');
      heartLaunch(b,false);T.tick(4.3,T.god);const a0=b.keyA96,x0=b.keys[0].x;T.tick(1,T.god);return [o1,b.rot96>0,+(b.keyA96-a0).toFixed(2),Math.round(Math.abs(b.keys[0].x-x0))>5,lab];}""")
    ok('V05 второй круг — обратный порядок, третий — ключи плывут; подпись — номер текущего ключа',r[0]=='3210' and r[1] and r[2]>=.25 and r[3] and r[4],r)
    r=await P.js("""()=>{const b=T.b90('heart',{ph:4});T.tick(1,T.god);heartLaunch(b,false);T.tick(4.3,T.god);heartLaunch(b,false);T.tick(4.3,T.god);heartLaunch(b,false);
      let t=0;for(;t<300&&b.st==='fight';t++)T.tick(1/60,T.god);return [b.fin96,b.st,+(t/60).toFixed(2)];}""")
    ok('V06 последний запуск: Сердце гаснет за 4 с без единого выстрела',r[1]!='fight' and r[2]<=4.1,r)
    r=await P.js("""()=>{const b=T.b90('heart',{ph:4});T.tick(1,T.god);const k=b.keys[0];const p=G.player;let hit=false;for(let i=0;i<180&&!hit;i++){p.x=k.x;p.y=k.y;p.vx=p.vy=0;T.tick(1/60,T.god);if(b.keyI>0)hit=true;}
      return [hit,b.keyI];}""")
    ok('V07 ключ берётся в такт и в обычном порядке (I → II)',r[0] and r[1]==1,r)
    r=await P.js("""()=>{const res=[];for(const ph of [1,2,3]){const b=T.b90('heart',{ph});const p=G.player;b.fibT=999;b.thrT=999;b.leukT=999;let hits=0;const D0=damagePlayer;damagePlayer=function(d,...a){const h0=p.hp;D0.call(this,d,...a);if(p.hp<h0&&(new Error()).stack.includes('heartWaves'))hits++;};
      for(let t=0;t<60*10;t++){let a;if(ph===1)a=b.ves[0].a+.15;else if(ph===2){const g=b.nextGaps&&b.nextGaps.length?b.nextGaps:b.curGaps;let w0=null;const pd=Math.hypot(p.x-b.cx,p.y-b.cy);for(const w of b.waves){if(w.hit||w.r>pd)continue;if(!w0||w.r>w0.r)w0=w;}const G2=w0?w0.gaps:g;const pa=Math.atan2(p.y-b.cy,p.x-b.cx);a=G2[0].a;let bd=9;for(const q of G2){const d=Math.abs(angDiff(pa,q.a));if(d<bd){bd=d;a=q.a;}}}
        else a=b.gth96+(b.gdir96||1)*heartOff96()/2;const R=b.R*.56;p.x=b.cx+Math.cos(a)*R;p.y=b.cy+Math.sin(a)*R;p.vx=p.vy=0;p.inv=0;p.hp=G.st.maxHp;G.player.fireT=99;update(1/60);}
      damagePlayer=D0;res.push(hits);}return res;}""")
    ok('V09 у каждой волны есть проход: в проходе (ф.1 — у сосуда, ф.2 — у пары, ф.3 — в пересечении) за 10 с ни одного попадания волной',r==[0,0,0],r)
    r=await P.js("""()=>{const b=T.b90('heart',{ph:3});b.fibT=.01;T.tick(.3,T.god);const n0=b.waves.length,g=new Set();let whip=0;const tgs=()=>tgList95().filter(o=>o.key==='heartWhip'||o.key==='heartRain').length;const w0=tgs();
      for(let i=0;i<150;i++){T.tick(1/60,T.god);for(const w of b.waves)if(w.thin&&w.gaps)g.add(Math.round(w.gaps[0].a*10));}
      const normal=b.waves.filter(w=>!w.thin&&w.r<b.R*.5).length;return [b.fib>0||b.fibT>15,g.size<=6,normal,tgs()-w0];}""")
    ok('V10 фибрилляция: обычные удары молчат, мелкие волны держат проход по стрелке',r[0] and r[1] and r[2]==0 and r[3]<=0,r)
    r=await P.js("()=>{const b=T.b90('heart',{ph:4});return [b.maxHp, Math.round(EDEF.heart90.hp*SBX.heart.K*sbRank()*cycHp())];}")
    ok('V08 пул Сердца ×1,3 (было ×1,08)',r[0]==r[1] and r[0]>0,r)
# ---------- A: тревога ----------
async def A(b):
    P=await page(b)
    r=await P.js("()=>{const X=T.m90(41);X.alarm=59.9;X.stage=1;G.lastFire90=G.t;T.tick(.5,()=>{T.god();G.lastFire90=G.t;});return [X.stage,Math.round(X.alarm*10)/10];}")
    ok('A01 переход на 60 срабатывает и от постоянного роста (раньше — только от событий)',r[0]==2,r)
    r=await P.js("""()=>{const X=T.m90(41);G.enemies.forEach(e=>{e.alive=false;});G.waves=[['gunner']];G.waveBase=[1];G.waveIdx=0;G.spawnQ=[];G.waveHold=999;G.endT=0;
      X.alarm=50;G.lastFire90=G.t-5;T.tick(1,T.god);const calm=50-X.alarm;
      const e=T.sp('gunner',G.player.x+400,G.player.y);e.cd=999;X.alarm=50;G.lastFire90=G.t-5;T.tick(1,T.god);const quiet=50-X.alarm;
      X.alarm=50;T.tick(1,()=>{T.god();G.lastFire90=G.t;});const fire=X.alarm-50;return [+calm.toFixed(2),+quiet.toFixed(2),+fire.toFixed(2)];}""")
    ok('A02 тревога: в затишье −5/с, в тишине при врагах −2,5/с, в бою +0,5/с',abs(r[0]-5)<.3 and abs(r[1]-2.5)<.3 and abs(r[2]-.5)<.15,r)
    r=await P.js("""()=>{const X=T.m90(41);G.enemies.forEach(e=>{if(e.type==='phago90')e.alive=false;});X.alarm=89.5;X.al90T=0;alarm90(1,0);const a1=X.alarm,cd=X.al90T;T.tick(1.6,T.god);const ob=G.enemies.filter(e=>e.alive&&e.ob96);
      const a2=X.alarm;kill(ob[0]);return [Math.round(a1),Math.round(cd),ob.length,+(a2-X.alarm).toFixed(1)];}""")
    ok('A03 облава: 3 Фагоцита с меткой, тревога падает до 55, пауза 30 с, сбитый фагоцит облавы −4',r[0]==55 and r[1]==30 and r[2]==3 and abs(r[3]-4)<.3,r)
    r=await P.js("""()=>{const X=T.m90(41);G.waves=[['gunner','gunner','gunner']];G.waveBase=[3];G.waveIdx=0;G.spawnQ=[];G.enemies.forEach(e=>{if(!e.dummy)e.alive=false;});
      for(let i=0;i<6;i++){const e=T.sp('phago90',60+i*30,60);e.ob96=1;e.cd=999;}T.tick(4,T.god);return [G.waveIdx,G.enemies.filter(e=>e.alive&&e.type==='gunner').length];}""")
    ok('A04 фагоциты облавы не держат волну: волна выходит при 6 живых облавных',r[0]==1 and r[1]>=2,r)
    r=await P.js("()=>{const X=T.m90(41);const e=T.sp('phago90',W/2,H/3);e.ob96=1;e.cd=999;let n=0;const S=ctx.arc;ctx.arc=function(...a){if(Math.abs(a[2]-(e.r+9))<.01)n++;return S.apply(this,a);};render(performance.now());ctx.arc=S;return n;}")
    ok('A05 фагоцит облавы помечен пунктирным кольцом',r>=1,r)
    r=await P.js("()=>[d95Hint=MISSIONS[39].hint[0],MISSIONS[40].hint[0]].map(s=>s.includes('в затишье'))")
    ok('A06 подсказки миссий 40 и 41 объясняют затишье и облаву',r==[True,True],r)
# ---------- G: страж и миссия 41 ----------
async def Gd(b):
    P=await page(b)
    r=await P.js("""()=>{T.m90(41);const p=G.player;p.x=W*.3;p.y=H*.6;const e=T.sp('guard95',p.x+150,p.y);e.fa95=Math.PI;e.bs95=.01;T.tick(.2,T.god);let t=0;while(e.bash95&&t<120){T.tick(1/60,T.god);t++;}
      const mb=e.mb95,wk=e.weak95;const h0=e.hp;const a=Math.atan2(e.y-p.y,e.x-p.x),d=Math.hypot(e.x-p.x,e.y-p.y);const sx=e.x-Math.cos(a)*Math.max(60,e.r+30),sy=e.y-Math.sin(a)*Math.max(60,e.r+30);
      const front=guardFront95(Object.assign({},e,{mb95:0}),sx,sy);T.shoot(sx,sy,a,{dmg:20});T.tick(.1,T.god);return [+mb.toFixed(2),+wk.toFixed(2),Math.round(h0-e.hp),front];}""")
    ok('A07 страж: после удара щитом мембрана опущена ~1,2 с, окно ✦, спереди пули проходят',r[0]>=1.1 and r[1]>=1.1 and r[2]>0,r)
    r=await P.js("()=>{T.m90(41);const p=G.player;const e=T.sp('guard95',p.x+150,p.y);e.fa95=0;e.bs95=9;const a0=e.fa95;T.tick(.5,T.god);return +(Math.abs(angDiff(e.fa95,a0))).toFixed(2);}")
    ok('A08 страж поворачивается не быстрее 1,6 рад/с — обойти можно',r<=.82,r)
    r=await P.js("()=>{T.m90(41);const w={o:{e95:1}};const a=T.sp('guard95',W/2,H/3),b=T.sp('spasm95',W/2,H/2);const ha=a.hp,hb=b.hp;spawned95(a,w);spawned95(b,w);return [+(a.hp/ha).toFixed(2),+(b.hp/hb).toFixed(2),EDEF.guard95.hp];}")
    ok('A09 элита-страж ×1,5 прочности (остальные ×2), база стража 130',r==[1.5,2,130],r)
    r=await P.js("""()=>{T.m90(43);const e=T.sp('gunner',W/2,-60);e.cd=999;let t=0;for(;t<240&&!(e.y>-10&&e.y<H+10);t++)T.tick(1/60,T.god);return [Math.round(e.y),+(t/60).toFixed(2),targetable(e)||e.spawnT>0];}""")
    ok('A11 враг за краем арены IX–X возвращается внутрь за 2,5–3 с',r[0]>=-10 and r[1]<=3.1 and r[2],r)
    r=await P.js("""()=>{const X=T.m90(41);const L=X.locks[0];G.waves=[];G.waveIdx=0;G.spawnQ=[];G.enemies.forEach(e=>{if(!e.dummy)e.alive=false;});X.t=(LOCK90.open+LOCK90.warn+1)-L.ph;T.tick(.05,T.god);const before=lockCyc90(L);
      for(let i=0;i<3;i++){const e=T.sp('gunner',W*.2+i*40,H*.3);e.cd=999;}T.tick(.2,T.god);let n=0;const S=ctx.arc;ctx.arc=function(...a){if(a[2]>20&&a[2]<40)n++;return S.apply(this,a);};render(performance.now());ctx.arc=S;return [before,lockCyc90(L),!!X.fin96,n>=3];}""")
    ok('A12 финальная зачистка: волны кончились, врагов ≤ 5 — шлюзы открыты насовсем, последние враги обведены',r[1]=='open' and r[2] and r[3],r)
    r=await P.js("()=>[SEC_WAVES[41].old.includes('hunter'),SEC_WAVES[41].old.includes('mite')]")
    ok('A10 миссия 41: старый «Охотник» заменён — две роли охотника не дублируются',r==[False,True],r)
# ---------- S: звук, кадр, тексты ----------
async def S(b):
    P=await page(b)
    r=await P.js("()=>{const s=snd90.toString(),q=snd95.toString();return [s.includes(\"case 'beat':{const k=(v===undefined?1:v)*.7;\"),s.includes(\"tone(1250,700,.035,'triangle',.03*k)\"),q.includes(\"case 'streak':noise(.5,.11,\"),q.includes(\"case 'tears':noise(1,.09,\")];}")
    ok('S01 микс: удар сердца −3 дБ со щелчком 1,25 кГц, «чирк» −4 дБ, слёзы −2,5 дБ',r==[True]*4,r)
    r=await P.js("""()=>{T.mis(43,{diff:'mid'});ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#000';ctx.fillRect(0,0,cv.width,cv.height);secVignette();const px=Array.from(ctx.getImageData(2,2,1,1).data);
      const w=cv.width,h=cv.height;const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.fillStyle='#000';g.fillRect(0,0,w,h);const gr=g.createRadialGradient(w/2,h/2,Math.min(w,h)*.45,w/2,h/2,Math.max(w,h)*.72);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(122,255,201,.08)');g.globalAlpha=isMob()?.67:1;g.fillStyle=gr;g.fillRect(0,0,w,h);
      const ex=Array.from(g.getImageData(2,2,1,1).data);return [px,ex,SVIG96.size>0];}""")
    ok('S02 виньетка сектора из кэша совпадает со старой формулой (±1)',max(abs(a-b_) for a,b_ in zip(r[0],r[1]))<=1 and r[2],r)
    r=await P.js("""()=>{const X=T.m90(43);X.plq=null;X.newT={};banner('ТЕСТ','БАННЕР');const e=T.sp('blot95',W/2,H/3);(X.seen||[]).length=0;T.tick(.5,T.god);const t1=X.plq?X.plq.t:-1;banT=0;T.tick(.5,T.god);const t2=X.plq?X.plq.t:-1;return [+t1.toFixed(2),+t2.toFixed(2)];}""")
    ok('S03 табличка новой встречи ждёт, пока сойдёт баннер',r[0]==0 and r[1]>.3,r)
    r=await P.js("()=>{const s=[...document.styleSheets].flatMap(x=>{try{return [...x.cssRules].map(r=>r.cssText)}catch(e){return []}}).join(' ');return s.includes('.ff-phone-l #banner { top: calc(var(--sat) + 78px)')}")
    ok('S04 телефон в альбомной: баннер ниже полосы босса',r,r)
    r=await P.js("()=>[$('#verTag')&&$('#verTag').textContent,(()=>{cxTab='log';try{renderCodex();}catch(e){}return document.body.innerHTML.includes('0.9.6 α');})()]")
    ok('S05 версия «АЛЬФА 0.9.7» и запись 0.9.6 в хронике',r[0]=='1.2.5 α' and r[1],r)
# ---------- E: край арены и финальная зачистка ----------
async def E(b):
    P=await page(b)
    for m in (40,41):
        r=await P.js("""(m)=>{T.fresh();T.openAll();const S=G.save;S.diff='mid';enterNode(m,false);if(G.state==='intro')startMission();let k=0;while(G.state==='levelup'&&k++<40)choose(0);
          const X=G.x90,out=[G.waves.length>0,X.fin96||0];T.tick(3,T.god);out.push(X.fin96||0,X.locks.length);X.t=18;out.push(X.locks.map(L=>lockCyc90(L)).join('/'));return out;}""",m)
        ok('E01 миссия %d: в начале шлюзы живут по циклу, зачистка не включена'%m,r[0] and r[1]==0 and r[2]==0 and r[3]==2 and 'closed' in r[4],r)
    r=await P.js("()=>{const X=T.m90(40);G.waves=[];G.waveIdx=0;G.spawnQ=[];for(let i=0;i<3;i++){const e=T.sp('gunner',W*.2+i*60,H*.3);e.cd=999;}T.tick(.2,T.god);X.t=18;const a=X.locks.map(L=>lockCyc90(L));X.ev95={k:'quar',t:10,sp:1};const c=X.locks.map(L=>lockCyc90(L));X.ev95=null;return [X.fin96||0,a.join('/'),c.join('/')];}")
    ok('E02 волны кончились, врагов ≤ 5 — шлюзы открыты насовсем (и в «Карантин»)',r==[1,'open/open','open/open'],r)
    r=await P.js("()=>{const X=T.m90(40);G.waves=[];G.waveIdx=0;G.spawnQ=[];for(let i=0;i<7;i++){const e=T.sp('gunner',W*.15+i*50,H*.3);e.cd=999;}T.tick(.2,()=>{T.god();for(const e of G.enemies)e.cd=999;});return X.fin96||0;}")
    ok('E03 врагов больше пяти — зачистка не включается',r==0,r)
    for m in (3,41):
        r=await P.js("(m)=>{T.mis(m,{diff:'mid'});const e=T.sp('gunner',W/2,H/2);e.cd=999;T.tick(.1,T.god);e.x=-60;e.vx=-300;T.tick(.1,()=>{T.god();e.cd=999;});const r=e.r||12;return [+e.x.toFixed(1),r,e.alive,!!e.in96];}",m)
        ok('E04 миссия %d: вошедший в арену враг не уходит за край'%m,r[2] and r[3] and r[1]-.5<=r[0]<W_HALF,r)
    r=await P.js("()=>{T.mis(3,{diff:'mid'});const e=T.sp('thief',W/2,H/2);T.tick(.1,T.god);e.loot=1;startFlee(e);T.tick(4,T.god);return [e.alive,Math.round(e.x)];}")
    ok('E05 похититель с грузом по-прежнему уходит за край',r[0]==False,r)
    r=await P.js("()=>['lastkind','linkor','pilgrim','pass90','witness100','echoship','echoguard','icecopy','boss','jam'].filter(t=>!OUT96.has(t))")
    ok('E06 уходящие по замыслу (Последний из рода, линкор, паломники, пассажиры, свидетели, эхо, копия, боссы) не удерживаются',r==[],r)
    r=await P.js("()=>{T.mis(41,{diff:'mid'});const e=T.sp('gunner',-40,H/2);e.cd=999;let at=-1;T.tick(3.2,(i)=>{T.god();e.cd=999;if(!e.in96){e.x=-40;e.vx=0;}else if(at<0)at=i/60;});return [e.in96||0,Math.round(e.x),+at.toFixed(2)];}")
    ok('E07 застрявший снаружи после появления через 2,5 с возвращается внутрь',r[0]==1 and r[1]>=50 and 2.3<=r[2]<=2.8,r)
    r=await P.js("()=>{let ok=0;for(let k=0;k<12;k++){T.m90(44);G.x90.er=null;const g=T.sp('gunner',W/2,H*.3);T.calm();hurt(g,g.maxHp*.5,{});const h1=g.hp;T.sp('fixer100',W/2+100,H*.3);T.tick(2.2,T.god);if(g.hp>h1)ok++;}return ok;}")
    ok('E08 Корректор в миссии 44 доводит ремонт: обход строк-стен ведёт к цели ремонта, а не к игроку',r>=11,r)
    r=await P.js("()=>{T.m90(40);G.waves=[['gunner']];G.waveBase=[1];G.waveIdx=0;G.spawnQ=[];G.waveHold=999;for(let i=0;i<4;i++){const e=spawnEnemy('spasm95',W*.3+i*80,H*.4,{noAffix:true,spawnT:.8});}T.tick(1/60,T.god);const sp=G.enemies.filter(e=>e.alive&&e.type==='spasm95');return [sp.length,G.enemies.filter(e=>e.alive&&!e.dummy).length,sp.every(e=>e.cap90)];}")
    ok('E09 лимит видов — в момент появления: 4 Спазма из события → 2 Спазма и 2 других врага уже в первом кадре',r[0]==2 and r[1]==4 and r[2],r)
W_HALF=10000
asyncio.run(run([('V',V),('A',A),('G',Gd),('S',S),('E',E)],'q96.json'))
