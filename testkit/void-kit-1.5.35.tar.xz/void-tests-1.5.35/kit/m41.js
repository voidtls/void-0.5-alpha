/* ===== 1.2.5 α: «Пустота-12» — живая подложка открытого мира в секторах I–II ===== */
const V12={name:'Пустота-12',seg:16,pre:.1,tail:.25,xf:.02,bpm:60,
  order:['intro0','intro1','loop0','loop1','loop2','loop3','loop4','loop5','loop6','loop7','loop8','loop9'],
  buf:{},dec:{},fail:0,ok:false,live:0,on:false,cur:null,nxt:null,pos:null,introDone:false,gain:.38,nodes:null,sec:-1,lastOff:0};
V12.next=n=>{const i=V12.order.indexOf(n);return n==='loop9'?'loop0':V12.order[i+1];};
V12.loopIdx=n=>n.startsWith('loop')?+n.slice(4):-1;
function v12Raw(n){const el=document.getElementById('v12-'+n);return el?el.textContent.trim():'';}
function v12Decode(n){if(V12.buf[n])return Promise.resolve(V12.buf[n]);if(V12.dec[n])return V12.dec[n];
  const b64=v12Raw(n);if(!b64||!AU.ctx)return Promise.reject(new Error('no '+n));
  const bin=atob(b64),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
  const p=new Promise((res,rej)=>{try{const r=AU.ctx.decodeAudioData(u.buffer,res,rej);if(r&&r.then)r.then(res,rej);}catch(e){rej(e);}})
    .then(b=>{V12.buf[n]=b;delete V12.dec[n];if(!V12.ok){V12.ok=true;v12Retune(true);}return b;})
    .catch(e=>{delete V12.dec[n];V12.fail++;throw e;});
  V12.dec[n]=p;return p;}
function v12Keep(){const keep=new Set([V12.cur&&V12.cur.n,V12.nxt&&V12.nxt.n,V12.cur&&V12.next(V12.cur.n)]);for(const k in V12.buf)if(!keep.has(k))delete V12.buf[k];}
function v12Nodes(){if(V12.nodes||!AU.ctx||!AU.musLP)return V12.nodes;const c=AU.ctx;
  const g=c.createGain();g.gain.value=0;const duck=c.createGain();duck.gain.value=1;const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=18000;f.Q.value=.5;
  const lo=c.createBiquadFilter();lo.type='lowshelf';lo.frequency.value=120;const hi=c.createBiquadFilter();hi.type='highshelf';hi.frequency.value=1800;
  const pk=c.createBiquadFilter();pk.type='peaking';pk.frequency.value=180;pk.Q.value=.8;const lc=c.createBiquadFilter();lc.type='lowshelf';lc.frequency.value=60;
  const bus=c.createGain();bus.gain.value=1;
  bus.connect(lo);lo.connect(hi);hi.connect(pk);pk.connect(lc);lc.connect(f);f.connect(duck);duck.connect(g);g.connect(AU.musLP);
  V12.nodes={g,duck,f,lo,hi,pk,lc,bus};return V12.nodes;}
/* хочет ли игра подложку прямо сейчас */
function v12Want(){const p=G.player;if(!SET.amb||!AU.ctx||V12.fail>3)return 0;
  if(!(G.mode==='world'&&G.world&&p&&!G.post&&['world','map','pause','codex'].includes(G.state)))return 0;
  const si=sectorIdx(p.x,p.y);if(si!==0&&si!==1)return 0;V12.sec=si;return 1;}
function v12Start(name,off){const c=AU.ctx,N=v12Nodes(),b=V12.buf[name];if(!N||!b)return false;const when=c.currentTime+.06;
  const s=c.createBufferSource();s.buffer=b;const sg=c.createGain();sg.gain.value=1;s.connect(sg);sg.connect(N.bus);
  s.start(when,V12.pre+off);V12.cur={n:name,src:s,g:sg,t0:when-off};return true;}
function v12Chain(){const c=AU.ctx,C=V12.cur,N=V12.nodes;if(!C)return;const now=c.currentTime,end=C.t0+V12.seg,nn=V12.next(C.n);
  if(!V12.nxt&&end-now<8&&!V12.buf[nn])v12Decode(nn).catch(()=>{});
  if(!V12.nxt&&end-now<2){const b=V12.buf[nn];
    if(b){const s=c.createBufferSource();s.buffer=b;const sg=c.createGain();sg.gain.setValueAtTime(0,end-V12.xf/2);sg.gain.linearRampToValueAtTime(1,end+V12.xf/2);
      s.connect(sg);sg.connect(N.bus);s.start(end-V12.xf/2,V12.pre-V12.xf/2);C.g.gain.setValueAtTime(1,end-V12.xf/2);C.g.gain.linearRampToValueAtTime(0,end+V12.xf/2);
      try{C.src.stop(end+V12.tail);}catch(e){}V12.nxt={n:nn,src:s,g:sg,t0:end};}
    else if(now>end-.05){/* кусок не успел — доиграть хвост и войти позже с сильной доли */try{C.g.gain.setTargetAtTime(0,end,.08);C.src.stop(end+V12.tail);}catch(e){}
      V12.pos={n:nn,off:0,t:performance.now()};V12.cur=null;v12Decode(nn).then(()=>{if(V12.on&&!V12.cur){v12Start(nn,0);}}).catch(()=>{});return;}}
  if(V12.nxt&&now>=V12.nxt.t0){if(V12.cur.n==='intro1')V12.introDone=true;V12.cur=V12.nxt;V12.nxt=null;v12Keep();}}
function v12Pos(){const C=V12.cur;if(!C||!AU.ctx)return null;const off=clamp(AU.ctx.currentTime-C.t0,0,V12.seg-.01);return {n:C.n,off,t:performance.now()};}
function v12Stop(fade){V12.gen=(V12.gen||0)+1;const c=AU.ctx,N=V12.nodes;if(!N)return;V12.pos=v12Pos()||V12.pos;const t=c.currentTime;
  N.g.gain.cancelScheduledValues(t);N.g.gain.setValueAtTime(N.g.gain.value,t);N.g.gain.linearRampToValueAtTime(0,t+fade);
  for(const X of [V12.cur,V12.nxt])if(X)try{X.src.stop(t+fade+.05);}catch(e){}V12.cur=V12.nxt=null;V12.lvl=0;}
/* куда входить: вступление один раз, потом петля; вернулся быстрее 90 с — с того же места */
function v12Entry(){const P=V12.pos;if(P&&performance.now()-P.t<90000){let n=P.n,off=Math.floor(P.off/4)*4;if(n.startsWith('intro')&&V12.introDone){n='loop0';off=0;}return {n,off};}
  if(!V12.introDone&&!V12.everIntro){V12.everIntro=1;return {n:'intro0',off:0};}return {n:V12.sec===1?'loop4':'loop0',off:0};}
/* уровни и окраска */
function v12Mix(dt){const N=V12.nodes,c=AU.ctx;if(!N)return;const t=c.currentTime,p=G.player,T=MUS.cur;
  const phone=G.ff==='phone';let db=0,lp=18000;
  const I=T&&T.I||0,zone=typeof zbOn==='function'&&zbOn(),anom=!!G.anom;
  if(zone||anom){db-=12;lp=700;}else if(I>.5){db-=5;lp=1800;}
  if(['map','pause','codex'].includes(G.state)){db-=8;lp=Math.min(lp,900);}
  if(G.well&&G.well.depth>0){db-=6*G.well.depth;lp=Math.min(lp,500+17500*Math.pow(1-G.well.depth,2));}
  try{const r=radioEl();if(r&&!r.hidden)db-=2;}catch(e){}
  if(typeof CHS!=='undefined'&&CHS&&CHS.ph==='live'){db=Math.min(db,-5);lp=Math.min(lp,1800);}
  const lvl=V12.on?V12.gain*(phone?1.19:1)*Math.pow(10,db/20):0;
  if(Math.abs(lvl-(V12.lvl||0))>.002||V12.fadeIn){const tc=V12.fadeIn?1.3:(lvl<(V12.lvl||0)?.5:1.2);const G_=N.g.gain;G_.cancelScheduledValues(t);G_.setValueAtTime(G_.value,t);G_.setTargetAtTime(lvl,t,tc);V12.lvl=lvl;V12.fadeIn=0;}
  if(Math.abs(lp-(V12.lp||0))>30){N.f.frequency.setTargetAtTime(lp,t,lp<(V12.lp||18000)?.4:1.2);V12.lp=lp;}
  const s=V12.sec;const eq=s===1?[-1.5,2]:[1.5,-2];if(V12.eqSec!==s+(phone?10:0)){V12.eqSec=s+(phone?10:0);N.lo.gain.setTargetAtTime(eq[0],t,2);N.hi.gain.setTargetAtTime(eq[1],t,2);N.hi.frequency.setTargetAtTime(s===1?1500:2000,t,2);
    N.pk.gain.setTargetAtTime(phone?2:0,t,.5);N.lc.gain.setTargetAtTime(phone?-3:0,t,.5);}
  /* Разлом: лёгкая «плывучесть» */
  const rI=G.riftI||0,rate=rI>.5?1-.015*Math.min(1,(rI-.5)*2):1;if(Math.abs(rate-(V12.rate||1))>.001){V12.rate=rate;for(const X of [V12.cur,V12.nxt])if(X)X.src.playbackRate.setTargetAtTime(rate,t,.8);}
}
function v12Tick(dt){if(!AU.ctx||AU.ctx.state!=='running')return;const want=v12Want();
  if(want&&!V12.on){V12.on=true;V12.fadeIn=1;const gen=V12.gen=(V12.gen||0)+1;const E=v12Entry();v12Decode(E.n).then(()=>{if(V12.on&&!V12.cur&&gen===V12.gen){v12Nodes();v12Start(E.n,E.off);v12Retune(true);}}).catch(()=>{});}
  else if(!want&&V12.on){V12.on=false;V12.gen=(V12.gen||0)+1;v12Stop(SET.amb?3.5:.4);v12Retune(false);}
  if(V12.on&&V12.cur)v12Chain();
  V12.live=V12.on&&V12.cur?1:0;
  if(V12.nodes)v12Mix(dt);
  if(V12.live)MUS.lastName=V12.name;
}
/* такт и доля подложки для синхронных слоёв */
V12.beatAt=function(t){const C=V12.cur;if(!C)return null;const k=C.n.startsWith('loop')?V12.loopIdx(C.n)*16:(C.n==='intro1'?16:0);const pos=k+(t-C.t0)*(V12.rate||1);return {beat:Math.floor(pos),ph:pos-Math.floor(pos),bar0:C.t0-((k%4))};};
/* перенастройка процедурных пейзажей I–II в фа минор, пока звучит подложка */
V.v12=[[0,7,12,15],[-4,3,8,12],[3,10,15,19],[-2,5,10,14]];
const V12_KEEP={belt:{root:SC_.belt.root,v:SC_.belt.v,bpm:SC_.belt.bpm},drift:{root:SC_.drift.root,v:SC_.drift.v,bpm:SC_.drift.bpm}};
const PENTA0=PENTA.slice(),PENTA_F=[523.25,622.25,698.46,830.61,932.33];
function v12Retune(on){const B=SC_.belt,D=SC_.drift;
  if(on&&V12.ok){B.root=41;B.v=V.v12;B.bpm=120;D.root=44;D.v=V.v12.map(ch=>ch.map(x=>x-3));D.bpm=120;PENTA.splice(0,5,...PENTA_F);}
  else{Object.assign(B,V12_KEEP.belt);Object.assign(D,V12_KEEP.drift);if(V12_KEEP.belt.bpm===undefined)delete B.bpm;if(V12_KEEP.drift.bpm===undefined)delete D.bpm;PENTA.splice(0,5,...PENTA0);}
  try{const P=MUS.cur;if(P&&(P.id==='belt'||P.id==='drift')&&AU.ctx){setChord(P,AU.ctx.currentTime);}}catch(e){}}
{const _sl=scapeLayers;scapeLayers=function(P){_sl(P);if(V12.live&&(P.id==='belt'||P.id==='drift')){const t=AU.ctx.currentTime;P.L.pad.gain.setTargetAtTime(0,t,.8);P.L.sub.gain.setTargetAtTime(0,t,.8);P.L.noise.gain.setTargetAtTime(.6,t,.8);}};}
/* сетка секвенсора и колокольчики — по долям подложки */
{const _sr=scapeRun;scapeRun=function(P,now,ahead){if(V12.live&&(P.id==='belt'||P.id==='drift')){const B=V12.beatAt(now);if(B){const sd=60/(120+(P.ext.bpmAdd||0))/4,g0=now-B.ph*(1/(V12.rate||1));
    if(P.next>=now-.25){const k=Math.ceil((P.next-g0)/sd-1e-6),snap=g0+k*sd;if(Math.abs(snap-P.next)>.002){P.next=snap;P.step=((B.beat%4)*8+k)%32;}}
    if(P.nextBell<ahead){const q=g0+Math.ceil((Math.max(now,P.nextBell)-g0))*1;P.nextBell=q;}}}
  return _sr(P,now,ahead);};}
/* взрывы на мгновение прижимают подложку */
{const _sfx=sfx;sfx=function(n){const r=_sfx.apply(this,arguments);try{if(V12.live&&V12.nodes&&(n==='boom'||n==='bigboom')){const t=AU.ctx.currentTime,g=V12.nodes.duck.gain,d=n==='bigboom'?.5:.71;
  g.cancelScheduledValues(t);g.setTargetAtTime(d,t,.01);g.setTargetAtTime(1,t+.05,.15);}}catch(e){}return r;};}
{const _mt=musicTick;musicTick=function(dt){_mt(dt);try{v12Tick(dt);}catch(e){console.error(e);}};}
