# 1.3.2 α «Проверка» — исправления по прогонам
import sys
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m57 FAIL',n,a[:80]);sys.exit(1)
    s=s.replace(a,b)
# подписи стрелок у края экрана читались поверх подписей мира (наслаивались на «МАСТЕРСКАЯ «ОБОД»») — тёмная обводка
R("ctx.fillText(label,lx+1,ly+1);ctx.fillStyle=col;ctx.fillText(label,lx,ly);}","ctx.lineJoin='round';ctx.lineWidth=4;ctx.strokeStyle='rgba(4,6,12,.92)';ctx.strokeText(label,lx,ly);ctx.fillStyle=col;ctx.fillText(label,lx,ly);}")
R("ctx.fillText(label+' · '+dd,clamp(ex-Math.cos(a)*34*UI,stageL()+70*UI,CW-stageL()-70*UI),ey-(Math.sin(a)*22-4)*UI);};",
  "{const tx=clamp(ex-Math.cos(a)*34*UI,stageL()+70*UI,CW-stageL()-70*UI),ty=ey-(Math.sin(a)*22-4)*UI;ctx.lineJoin='round';ctx.lineWidth=4*UI;ctx.strokeStyle='rgba(4,6,12,.92)';ctx.strokeText(label+' · '+dd,tx,ty);ctx.fillText(label+' · '+dd,tx,ty);}};")
R("c.fillText(lab+' · '+fmtAU(Math.hypot(x-p.x,y-p.y)),clamp(ex-Math.cos(a)*34*u,sl+70*u,CW-sl-70*u),ey-(Math.sin(a)*22-4)*u);return true;};",
  "{const tl=lab+' · '+fmtAU(Math.hypot(x-p.x,y-p.y)),tx=clamp(ex-Math.cos(a)*34*u,sl+70*u,CW-sl-70*u),ty=ey-(Math.sin(a)*22-4)*u;c.lineJoin='round';c.lineWidth=4*u;c.strokeStyle='rgba(4,6,12,.92)';c.strokeText(tl,tx,ty);c.fillText(tl,tx,ty);}return true;};")
css=open(D+'m57.css',encoding='utf8').read();i=s.find('</style>');s=s[:i]+css+'\n'+s[i:]
js=open(D+'m57.js',encoding='utf8').read();i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m57 ok')
