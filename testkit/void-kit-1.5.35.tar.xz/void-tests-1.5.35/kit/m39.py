P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
css=open(D+'m39.css',encoding='utf8').read();i=s.rindex('</style>');s=s[:i]+css+s[i:]
js=open(D+'m39.js',encoding='utf8').read();i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
s=s.replace("function layoutTouch(){readSafe();const mob=isMob(),k=SET.btnSize||1,","function layoutTouch(){readSafe();const mob=isMob(),k=(SET.btnSize||1)*(typeof tabK==='function'?tabK():1),",1)
open(P,'w',encoding='utf8').write(s);print('m39 ok')
