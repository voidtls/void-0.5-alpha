# 1.2.6 α · записанная музыка: меню, миссии 1–10, Страж-0, Глушитель; пауза −90 %. Каждый тест падает на версии 27.
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
M="""async(m)=>{T.fresh();SET.amb=true;SET.sfx=true;audioInit();await AU.ctx.resume();T.openAll();T.go(m);
  window.__calm=true;window.__step=async(ms)=>{const t0=performance.now();while(performance.now()-t0<ms){if(G.player)G.player.hp=Math.max(G.player.hp,G.st?G.st.maxHp:50);if(__calm)G.enemies=G.enemies.filter(e=>e.type==='boss'||e.type==='jam');if(G.boss)G.boss.hp=Math.max(G.boss.hp,50);if(G.jam)G.jam.hp=Math.max(G.jam.hp,50);musicTick(.05);await new Promise(r=>setTimeout(r,50));}};
  window.__lvl=async(ms)=>{const an=AU.ctx.createAnalyser();an.fftSize=32768;AU.amb.connect(an);const buf=new Float32Array(an.fftSize);let s=0,n=0;const t0=performance.now();while(performance.now()-t0<ms){await __step(250);an.getFloatTimeDomainData(buf);for(const v of buf)s+=v*v;n+=buf.length;}AU.amb.disconnect(an);return +(10*Math.log10(s/n+1e-12)).toFixed(1);};
  window.__st=()=>{const o={want:MZ.want};for(const k in MZ.pl){const P=MZ.pl[k];o[k]=[P.on,+(P.fade?P.fade.gain.value:0).toFixed(2),P.cur?P.cur.i:null];}return o;};
  return typeof MZ!=='undefined'&&G.state;}"""

@test('B1')
async def b1(b):
    P=await newpage(b,alpha=False)
    r=await P.js("""async()=>{if(typeof MZ==='undefined')return {ok:false};audioInit();await AU.ctx.resume();const bad=[];let n=0;
      for(const k in MZ_TR){const T=MZ_TR[k],Pl=mzP(k);for(let i=0;i<T.segs.length;i++){const bf=await mzDecode(Pl,i);n++;const want=T.segs[i][1]+2*MZ.pre+MZ.tail;if(Math.abs(bf.duration-want)>.004)bad.push([T.segs[i][0],bf.duration,want]);delete Pl.buf[i];}}
      return {ok:true,n,bad,tr:Object.keys(MZ_TR)}}""")
    rec('B1 четыре трека (меню, миссии, Страж-0, Глушитель) — все куски декодируются, длины точные',r.get('ok') and r['n']>=40 and not r['bad'] and r['tr']==['menu','m10','s0','s10'],r)

@test('B2')
async def b2(b):
    P=await newpage(b,alpha=False)
    r=await P.js("""async()=>{if(typeof MZ==='undefined')return {ok:false};const sr=48000;const C=new OfflineAudioContext(2,sr,sr);const dec=n=>{const s=mzRaw(n),u=Uint8Array.from(atob(s),c=>c.charCodeAt(0));return C.decodeAudioData(u.buffer);};
      const res={};for(const k in MZ_TR){const T=MZ_TR[k],L=T.segs.length;for(const [a,bi] of [[L-1,T.intro],[T.intro-1,T.intro],[T.intro+1,T.intro+2]]){const A=await dec(T.segs[a][0]),B=await dec(T.segs[bi][0]);const C2=new OfflineAudioContext(1,sr*4,sr);
        const off=T.segs[a][1]-2,end=2,xf=MZ.xf,pre=MZ.pre;const s1=C2.createBufferSource();s1.buffer=A;const g1=C2.createGain();s1.connect(g1);g1.connect(C2.destination);s1.start(0,pre+off);g1.gain.setValueAtTime(1,end-xf/2);g1.gain.linearRampToValueAtTime(0,end+xf/2);s1.stop(end+.25);
        const s2=C2.createBufferSource();s2.buffer=B;const g2=C2.createGain();g2.gain.setValueAtTime(0,end-xf/2);g2.gain.linearRampToValueAtTime(1,end+xf/2);s2.connect(g2);g2.connect(C2.destination);s2.start(end-xf/2,pre-xf/2);
        const d=(await C2.startRendering()).getChannelData(0);const w=240;const rms=i=>{let s=0;for(let q=i;q<i+w;q++)s+=d[q]*d[q];return 10*Math.log10(s/w+1e-12);};
        let jS=0,jB=[];for(let i=0;i+2*w<d.length;i+=w){const j=Math.abs(rms(i+w)-rms(i));if(Math.abs(i-2*sr)<.03*sr)jS=Math.max(jS,j);else jB.push(j);}jB.sort((x,y)=>x-y);
        res[k+':'+a+'>'+bi]=[+jS.toFixed(1),+jB[Math.floor(jB.length*.99)].toFixed(1)];}}
      return {ok:true,res}}""")
    ok=r.get('ok') and all(v[0]<=v[1]+3 for v in r['res'].values())
    rec('B2 стыки кусков, переход вступление→петля и петля по кругу без щелчков во всех четырёх треках',ok,r)

@test('B3')
async def b3(b):
    P=await newpage(b,alpha=False)
    r=await P.js("""async()=>{if(typeof MZ==='undefined')return {ok:false};SET.amb=true;audioInit();await AU.ctx.resume();toMenu();const step=async ms=>{const t0=performance.now();while(performance.now()-t0<ms){musicTick(.05);await new Promise(r=>setTimeout(r,50));}};
      const Pl=mzP('menu');await step(2000);mzOff(Pl,.05);await step(300);mzOn(Pl,MZ_TR.menu.intro,0,.05);await step(3000);const an=AU.ctx.createAnalyser();an.fftSize=32768;AU.amb.connect(an);const buf=new Float32Array(an.fftSize);let s=0,n=0;for(let i=0;i<24;i++){await step(250);an.getFloatTimeDomainData(buf);for(const v of buf)s+=v*v;n+=buf.length;}
      return {ok:true,want:MZ.want,live:MZ.anyLive,mus:+AU.mus.gain.value.toFixed(3),lvl:+(10*Math.log10(s/n)).toFixed(1),name:MUS.lastName}}""")
    ok=r.get('ok') and r['want']=='menu' and r['live'] and r['mus']<.02 and -37<=r['lvl']<=-31
    rec('B3 главное меню: звучит «Меню», процедурная музыка заглушена, уровень шины ≈ −34 dBFS',ok,r)

@test('B4')
async def b4(b):
    P=await newpage(b,alpha=False);out={}
    for m in [1,3,7]:
        await P.js(M,m)
        out[m]=await P.js("async()=>{await __step(3000);const Pl=MZ.pl.m10;mzOff(Pl,.05);await __step(300);mzOn(Pl,MZ_TR.m10.intro,0,.05);await __step(2500);const lvl=await __lvl(6000);return {lvl,st:__st(),mus:+AU.mus.gain.value.toFixed(3),state:G.state}}")
    ok=all(o['st']['want']=='m10' and o['st']['m10'][0] and o['mus']<.02 and -33.5<=o['lvl']<=-27.5 for o in out.values())
    rec('B4 миссии 1, 3, 7: звучит «Войд-10», процедурная заглушена, уровень ≈ −30,5 dBFS',ok,out)

@test('B5')
async def b5(b):
    P=await newpage(b,alpha=False);await P.js(M,6)
    r=await P.js("""async()=>{await __step(4000);const a=__st();G.bossSpawned=true;spawnBoss();await __step(600);const mid=__st();await __step(3500);const c=__st();mzOff(MZ.pl.s0,.05);await __step(300);mzOn(MZ.pl.s0,MZ_TR.s0.intro,0,.05);await __step(1500);const lvl=await __lvl(5000);
      G.boss.alive=false;G.boss=null;G.endT=99;await __step(1500);const d=__st();await __step(3000);const e=__st();return {a,mid,c,d,e,lvl}}""")
    ok=r['a']['want']=='m10' and r['mid']['want']=='s0' and 0.05<r['mid']['m10'][1]<.98 and r['c']['s0'][1]>.95 and r['c']['m10'][1]<.02 and r['d']['want']=='s0' and r['e']['want']=='m10' and -32<=r['lvl']<=-26
    rec('B5 миссия 6: до босса «Войд-10», при появлении Стража плавный переход (2–2,5 с) на «Страж-0»; после гибели держится 3 с',ok,r)

@test('B6')
async def b6(b):
    P=await newpage(b,alpha=False);await P.js(M,10)
    r=await P.js("""async()=>{await __step(4000);const a=__st();if(!G.jam){G.bc&&(G.bc.transStarted=true);spawnJam();}await __step(4500);const c=__st();mzOff(MZ.pl.s10,.05);await __step(300);mzOn(MZ.pl.s10,MZ_TR.s10.intro,0,.05);await __step(1500);const lvl=await __lvl(5000);return {a,c,lvl,jam:!!G.jam}}""")
    ok=r['a']['want']=='m10' and r['c']['want']=='s10' and r['c']['s10'][1]>.95 and r['c']['m10'][1]<.02 and -32<=r['lvl']<=-26
    rec('B6 миссия 10: при появлении Глушителя «Войд-10» плавно сменяется на «Страж-10»',ok,r)

@test('B7')
async def b7(b):
    P=await newpage(b,alpha=False);await P.js(M,3)
    r=await P.js("""async()=>{await __step(4000);const g=()=>+AU.pauseG.gain.value.toFixed(3);const a=g();pause();const tr=[];for(let i=0;i<16;i++){await __step(250);tr.push(g());}
      resume();const back=[];for(let i=0;i<8;i++){await __step(250);back.push(g());}return {a,tr,back,want:MZ.want,on:MZ.pl.m10.on}}""")
    tr=r['tr'];bk=r['back']
    ok=r['a']>.99 and tr[1]>.5 and tr[3]>.3 and tr[-1]<.13 and abs(tr[-1]-.1)<.03 and bk[3]>.9 and bk[-1]>.98 and r['want']=='m10' and r['on']
    rec('B7 пауза: музыка плавно (≈ 3 с) уходит на −90 %; после паузы возвращается быстрее (≈ 1 с); трек не перезапускается',ok,r)

@test('B8')
async def b8(b):
    P=await newpage(b,alpha=False);await P.js(M,3)
    r=await P.js("""async()=>{await __step(5000);const i0=MZ.pl.m10.cur&&MZ.pl.m10.cur.i;toMenu();await __step(1200);const mid=__st();await __step(4000);const c=__st();
      T.fresh();const s=WORLD.sectors[0].box;G.player.x=(s[0]+s[2])/2;G.player.y=(s[1]+s[3])/2;await __step(5000);const w=__st();return {mid,c,w,v12:typeof V12!=='undefined'&&V12.on}}""")
    ok=r['mid']['want']=='menu' and 0<r['mid']['m10'][1]<1 and r['c']['menu'][1]>.95 and r['c']['m10'][1]<.02 and r['w']['want'] is None and r['w']['menu'][1]<.02 and r['v12']
    rec('B8 миссия → меню → открытый мир: равномощные переходы, в мире звучит «Пустота-12», записи молчат',ok,r)

@test('B9')
async def b9(b):
    P=await newpage(b,alpha=False)
    r=await P.js("""async()=>{if(typeof MZ==='undefined')return {ok:false};const st=async ms=>{const t0=performance.now();while(performance.now()-t0<ms){musicTick(.05);await new Promise(r=>setTimeout(r,50));}};
      T.fresh();SET.amb=true;audioInit();await AU.ctx.resume();T.openAll();T.go(12);await st(3000);const m12=MZ.want;toMenu();SET.amb=false;await st(4000);const off=[MZ.want,MZ.pl.menu&&MZ.pl.menu.fade?+MZ.pl.menu.fade.gain.value.toFixed(3):0];
      return {ok:true,m12,off,state:G.state}}""")
    ok=r.get('ok') and r['m12'] is None and r['off'][0] is None and r['off'][1]<.02
    rec('B9 миссии после 10-й без записей; «Музыка» выключена — записи замолкают',ok,r)

@test('B10')
async def b10(b):
    P=await newpage(b,alpha=False);await P.js(M,6)
    r=await P.js("""async()=>{await __step(4000);const a=PENTA.slice();spawnBoss();await __step(4000);const f=PENTA.slice();return {a,f,errs:0}}""")
    rec('B10 звук убийства в тональности трека (фа минор в миссиях и у Стража-0)',r['a'][1]==622.25 and r['f'][1]==622.25 and not P.errs,{**r,'errs':P.errs[:3]})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q200.json'))
