# 1.2.9 α — усиление врагов миссий 15–24
import sys
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m55 FAIL',n,a[:80]);sys.exit(1)
    s=s.replace(a,b)
# прочность обычных врагов: после потолка сектора (×8 от базы), чтобы прибавка не срезалась
R("  if(type==='boss'||type==='jam'){if(G.bossMul){e.hp*=G.bossMul;e.maxHp=e.hp;}e.th=[e.maxHp*2/3,e.maxHp/3,0];}",
  "  if(!d.passive){const k129=hpX129();if(k129!==1){e.hp*=k129;e.maxHp*=k129;}}\n  if(type==='boss'||type==='jam'){if(G.bossMul){e.hp*=G.bossMul;e.maxHp=e.hp;}e.th=[e.maxHp*2/3,e.maxHp/3,0];}")
js=open(D+'m55.js',encoding='utf8').read();i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
# версия
R('<div class="ver" id="verTag">1.2.8 α</div>','<div class="ver" id="verTag">1.2.9 α</div>')
R("const VER_TAG='1.2.8 α';","const VER_TAG='1.2.9 α';")
R("toast('ЧТО НОВОГО · '+VER_TAG,'Музыка меню звучит сразу. В настройках — громкость звуков. В паузе — «Допуск пилота»: управление под ваше устройство.');",
  "toast('ЧТО НОВОГО · '+VER_TAG,'Миссии 15–24 стали жёстче: враги в 1,5 раза прочнее и бьют в 1,5 раза больнее. Скорость и темп их атак прежние.');")
R('<dl class="kv"><dt>1.2.8 α</dt>','<dl class="kv"><dt>1.2.9 α</dt><dd>Баланс середины кампании. В миссиях 15–24 (сектора «Ржавые хроники», «Чужие колыбели» и первые узлы «Кладбища флота») прочность всех врагов, включая боссов секторов и их части, умножена на 1,5, урон их выстрелов и таранов — тоже на 1,5. Скорость полёта врагов и темп их атак не менялись. Остальные миссии, бесконечный режим и открытый космос сектора — без изменений.</dd><dt>1.2.8 α</dt>')
open(P,'w',encoding='utf8').write(s);print('m55 ok')
