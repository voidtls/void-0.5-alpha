# 0.7.0 «Арсенал» · часть 12: данные и статы, оружие «Разрыв», точка в мире и карта, экран Арсенала, брифинг, доход, сохранение, тексты
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m12: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)

# ============ 1. данные и статы ============
R("function perk(k){return G.mode==='world'&&G.save&&G.save.perks?(G.save.perks[k]||0):0;}",
"""function perk(k){return G.mode==='world'&&G.save&&G.save.perks?(G.save.perks[k]||0):0;}
// ===== 0.7.0: Арсенал «Иней» — прокачка орудия и второе оружие =====
const ARS={
  gun:{name:'ОРУДИЕ',d:'Основное орудие: быстрый одиночный снаряд, работает с пробитием, рикошетом и сдвоенным стволом.',tracks:{
    pow:{name:'СИЛА',k:[1.2,1.3,1.4],cost:[2000,3000,4000]},rate:{name:'ТЕМП',k:[1.1,1.2,1.3],cost:[1500,2500,3500]}}},
  blast:{name:'РАЗРЫВ',price:5000,d:'Снаряд не бьёт в точку, а детонирует при касании: урон всем в радиусе, сильнее в центре. Темп ниже, пробитие и рикошет не действуют.',tracks:{
    pow:{name:'МОЩНОСТЬ',k:[1.2,1.3,1.4],cost:[2000,3000,4000]},rad:{name:'РАДИУС',k:[1.15,1.2,1.25],cost:[1500,2500,3500]}}}};
const BOSS_TROPHY={14:2000,18:3000,22:4000,27:5000,31:6000,38:7000,42:8000,46:9000,50:10000};
function arsDef(){return {weapon:'gun',own:{gun:1,blast:0},lv:{gun:{pow:0,rate:0},blast:{pow:0,rad:0}}};}
function arsMul(w,t,n){const k=ARS[w].tracks[t].k;let m=1;for(let i=0;i<Math.min(n||0,k.length);i++)m*=k[i];return m;}
function arsK(w,t){const S=G.save;if(G.mode!=='world'||!S||!S.ars||!S.ars.lv[w])return 1;return arsMul(w,t,S.ars.lv[w][t]||0);}
function arsWeapon(){const S=G.save;return G.mode==='world'&&S&&S.ars&&S.ars.weapon==='blast'&&S.ars.own.blast?'blast':'gun';}
function arsOpen(){const S=G.save;return !!(S&&S.medals&&S.medals[14]&&S.medals[14].clear);}""")
R("cargo:V('tractor')+perk('cargo'),sync:V('sync'),rico:V('rico'),phase:V('phase'),light:V('light'),linek:V('linekit')};",
  "cargo:V('tractor')+perk('cargo'),sync:V('sync'),rico:V('rico'),phase:V('phase'),light:V('light'),linek:V('linekit')};\n  {const aw=arsWeapon();G.st.weapon=aw;G.st.dmg*=arsK(aw,'pow');if(aw==='gun')G.st.rate/=arsK('gun','rate');else G.st.rate*=1.6;G.st.blastR=110*arsK('blast','rad');const wc=$('#wpnC');if(wc)wc.hidden=aw!=='blast';}")

# ============ 2. оружие «Разрыв» ============
R("  const tw=perk('twin')>0;\n  for(let i=0;i<n;i++){const a=base+(i-(n-1)/2)*spread;const sx=p.x+Math.cos(p.ang)*16,sy=p.y+Math.sin(p.ang)*16;\n    if(tw){",
  "  const tw=perk('twin')>0&&st.weapon!=='blast';\n  for(let i=0;i<n;i++){const a=base+(i-(n-1)/2)*spread;const sx=p.x+Math.cos(p.ang)*16,sy=p.y+Math.sin(p.ang)*16;\n    if(st.weapon==='blast'){G.pb.push({x:sx,y:sy,px:sx,py:sy,vx:Math.cos(a)*620,vy:Math.sin(a)*620,dmg:st.dmg*st.shotK,pierce:0,rico:0,life:.75,hit:[],blast:true,R:st.blastR,age:0});continue;}\n    if(tw){")
R("  G.pb.push({x:sx,y:sy,px:sx,py:sy,vx:Math.cos(a)*1300,vy:Math.sin(a)*1300,dmg:G.st.dmg*6,pierce:99,rico:0,life:.9,hit:[],charged:true});",
  "  if(G.st.weapon==='blast')G.pb.push({x:sx,y:sy,px:sx,py:sy,vx:Math.cos(a)*900,vy:Math.sin(a)*900,dmg:G.st.dmg*6,pierce:0,rico:0,life:.9,hit:[],charged:true,blast:true,R:G.st.blastR,age:0});\n  else G.pb.push({x:sx,y:sy,px:sx,py:sy,vx:Math.cos(a)*1300,vy:Math.sin(a)*1300,dmg:G.st.dmg*6,pierce:99,rico:0,life:.9,hit:[],charged:true});")
# детонация
R("function updateBullets(dt){",
"""// взрыв «Разрыва»: всем в радиусе, сильнее в центре; щиты гвардии и зеркальщиков, купол босса — уважаются; броня сектора — как у обычного снаряда
function blastAt(x,y,R,dmg,charged){
  for(const e of G.enemies){if(!e.alive||e.spawnT>0||e.ghost||e.down>0)continue;if(e.type==='obseg')continue;
    if(e.type==='boss'&&(!G.boss||G.boss.st!=='fight'||bossShielded()))continue;if(e.type==='jam'&&(!G.jam||G.jam.st!=='fight'||jamShielded()))continue;
    if(EDEF[e.type].sbp&&G.sb&&(G.sb.st==='enter'||G.sb.st==='dying'))continue;
    const d=Math.max(0,Math.hypot(e.x-x,e.y-y)-e.r);if(d>R)continue;const a=Math.atan2(y-e.y,x-e.x);
    if(e.type==='guard'&&!(e.shieldDown>0)&&Math.abs(angDiff(a,e.face))<1.05){e.shieldFlash=.12;continue;}
    if(e.type==='mirror'&&Math.abs(angDiff(a,e.face))<1.0){e.shieldFlash=.12;continue;}
    hurt(e,dmg*(1.4-.9*clamp(d/R,0,1)),{blast:true,charged:!!charged});}
  for(const r of G.rocks){if(r.alive&&Math.hypot(r.x-x,r.y-y)<R+r.r)rockHit(r,dmg*.7);}
  if(G.shock.length<60)G.shock.push({x,y,r:6,R,t:0,col:'#9fe3ff',thin:true});explode(x,y,'#9fe3ff',charged?26:12,charged?1.1:.7);sfx('boom');shake(charged?4:1.5);
}
function updateBullets(dt){""")
R("  for(const b of G.pb){\n    b.px=b.x;b.py=b.y;","  for(const b of G.pb){\n    b.px=b.x;b.py=b.y;b.age=(b.age||0)+dt;")
R("for(const r of G.rocks){if(!r.alive)continue;if(segDist(b.px,b.py,b.x,b.y,r.x,r.y)<r.r){if(b.charged){",
  "for(const r of G.rocks){if(!r.alive)continue;if(segDist(b.px,b.py,b.x,b.y,r.x,r.y)<r.r){if(b.blast){b.life=0;break;}if(b.charged){")
R("      b.hit.push(e);hurt(e,b.dmg,{charged:!!b.charged,drone:!!(b.drone||b.turret)});",
  "      if(b.blast){if(b.age<.06)continue;b.life=0;break;}\n      b.hit.push(e);hurt(e,b.dmg,{charged:!!b.charged,drone:!!(b.drone||b.turret)});")
R("  if(G.world)for(const b of G.pb)if(b.life>.5&&!inSectors(b.x,b.y))b.life=.5;\n  G.pb=G.pb.filter(",
  "  for(const b of G.pb)if(b.blast&&b.life<=0&&!b.det){b.det=true;blastAt(b.x,b.y,(b.R||G.st.blastR||110)*(b.charged?1.5:1),b.dmg,b.charged);}\n  if(G.world)for(const b of G.pb)if(b.life>.5&&!inSectors(b.x,b.y))b.life=.5;\n  G.pb=G.pb.filter(")
# отрисовка
R("const BC=shipBul();for(const b of G.pb){if(b.charged){",
  "const BC=shipBul();for(const b of G.pb){if(b.blast){glow(b.x,b.y,b.charged?34:22,'#9fe3ff',.8);ctx.strokeStyle='#9fe3ff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(b.x-b.vx*.03,b.y-b.vy*.03);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.fillStyle='#dff6ff';ctx.beginPath();ctx.arc(b.x,b.y,b.charged?7:4.5,0,TAU);ctx.fill();continue;}if(b.charged){",2)
# предложения модулей: с «Разрывом» пробитие и рикошет не предлагаются
R("const avail=shuffle(Object.keys(MODS).filter(k=>(G.mods[k]||0)<MODS[k].max&&G.m>=MODS[k].from&&!(G.mode==='endless'&&['tractor','sync','linekit','light'].includes(k))));",
  "const avail=shuffle(Object.keys(MODS).filter(k=>(G.mods[k]||0)<MODS[k].max&&G.m>=MODS[k].from&&!(G.mode==='endless'&&['tractor','sync','linekit','light'].includes(k))&&!(G.st.weapon==='blast'&&(k==='pierce'||k==='rico'))));")

# ============ 3. доход ============
R("  if(first){const sr=secRew(m);lom+=m<=CORE?20+12*m:Math.round((100+3*(m-CORE))*sr);px+=(40+8*m)*mul*sr;}\n  else{lom+=Math.max(2,Math.round((6+2*m)*Math.pow(.6,k)));",
  "  const sr=secRew(m),firstLom=m<=CORE?20+12*m:Math.round((100+3*(m-CORE))*sr*(m>=15?3:1));/* 0.7.0: сектора IV+ платят втрое */\n  if(first){lom+=firstLom;px+=(40+8*m)*mul*sr;}\n  else{lom+=m>CORE?Math.round(firstLom*.35)/* 0.7.0: повторы в секторах III+ — плоские 35 % */:Math.max(2,Math.round((6+2*m)*Math.pow(.6,k)));")
R("  lom=Math.round(lom*mul*(G.sbLomK||1));px+=25*got.length;",
  "  lom=Math.round(lom*mul*(G.sbLomK||1));px+=25*got.length;\n  {const tr=BOSS_TROPHY[m];if(tr&&!(S.trophy&&S.trophy[m])){S.trophy=S.trophy||{};S.trophy[m]=1;lom+=tr;G.trophyMsg=tr;if(m===14)G.arsMsg=1;}}")
R("  enterWorldAt(S.pos.x,S.pos.y);\n  try{const ios=",
  "  enterWorldAt(S.pos.x,S.pos.y);\n  if(G.arsMsg){G.arsMsg=0;G.trophyMsg=0;const ar=WORLD.arsenal;setTimeout(()=>{banner('АРСЕНАЛ ОТКРЫТ','«ИНЕЙ» · СЕКТОР III · ТРОФЕЙ +2000 ЛОМА');if(G.state==='world'){G.course={x:ar.x,y:ar.y+150,label:ar.name};}},700);}\n  else if(G.trophyMsg){const tr=G.trophyMsg;G.trophyMsg=0;setTimeout(()=>banner('ТРОФЕЙ БОССА','+'+tr+' ЛОМА НА СКЛАД'),700);}\n  try{const ios=")

# ============ 4. точка в мире ============
R("  for(let i=0;i<2;i++)WORLD.fields2.push({x:x0+800+R()*(x1-x0-1600),y:y0+1200+R()*(y1-y0-2400),r:350+R()*200,n:12+Math.floor(R()*8)});});}",
  "  for(let i=0;i<2;i++)WORLD.fields2.push({x:x0+800+R()*(x1-x0-1600),y:y0+1200+R()*(y1-y0-2400),r:350+R()*200,n:12+Math.floor(R()*8)});});}\n// 0.7.0: Арсенал «Иней» — рядом с узлом 14, внутри сектора III, не ближе 520 к другим узлам\n{const n14=WORLD.nodes.find(n=>n.m===14),b=WORLD.sectors[2].box;let best=null;for(const [dx,dy] of [[-650,-520],[-650,520],[650,-520],[-900,0],[650,520],[0,-800]]){const x=n14.x+dx,y=n14.y+dy;if(x<b[0]+450||x>b[2]-450||y<b[1]+450||y>b[3]-450)continue;if(WORLD.nodes.some(q=>q!==n14&&Math.hypot(q.x-x,q.y-y)<520))continue;best={x,y};break;}\n  if(!best)best={x:clamp(n14.x-650,b[0]+450,b[2]-450),y:clamp(n14.y-520,b[1]+450,b[3]-450)};WORLD.arsenal={x:Math.round(best.x),y:Math.round(best.y),name:'АРСЕНАЛ «ИНЕЙ»'};}")
R("const pois=[WORLD.hangar,WORLD.abyss,...WORLD.nodes,","const pois=[WORLD.hangar,WORLD.abyss,WORLD.arsenal,...WORLD.nodes,")
R("function storyObstacles(){const o=[...WORLD.nodes,...WORLD.shops,...WORLD.anomalies,...WORLD.caches,...WORLD.relays,WORLD.hangar,WORLD.abyss,WORLD.gate];",
  "function storyObstacles(){const o=[...WORLD.nodes,...WORLD.shops,...WORLD.anomalies,...WORLD.caches,...WORLD.relays,WORLD.hangar,WORLD.arsenal,WORLD.abyss,WORLD.gate];")
R("  if(Math.hypot(x-WORLD.hangar.x,y-WORLD.hangar.y)<600)return true;",
  "  if(Math.hypot(x-WORLD.hangar.x,y-WORLD.hangar.y)<600)return true;if(Math.hypot(x-WORLD.arsenal.x,y-WORLD.arsenal.y)<600)return true;")
# отрисовка в секторе
R("  drawAbyss(t);\n  // узлы миссий",
"""  {const ar=WORLD.arsenal;if(inView(ar.x,ar.y,220)){const open=arsOpen();ctx.save();ctx.translate(ar.x,ar.y);glow(0,0,120,'#8fd8ff',open?.3:.12);ctx.save();ctx.rotate(t*.15);ctx.strokeStyle=open?'#9fe3ff':'#3a5a74';ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;ctx[i?'lineTo':'moveTo'](Math.cos(a)*56,Math.sin(a)*56);}ctx.closePath();ctx.stroke();ctx.globalAlpha=.3;ctx.fillStyle=open?'#8fd8ff':'#1c2e44';ctx.fill();ctx.globalAlpha=1;ctx.restore();
    ctx.rotate(-t*.5);for(let i=0;i<3;i++){ctx.save();ctx.rotate(i/3*TAU);ctx.translate(34,0);ctx.fillStyle=open?'#dff6ff':'#3a5a74';ctx.globalAlpha=open?.6+.3*Math.sin(t*3+i):.5;ctx.fillRect(-10,-3,20,6);ctx.restore();}ctx.restore();
    if(!open){ctx.strokeStyle='#9fd8ff';ctx.lineWidth=2;ctx.strokeRect(ar.x-9,ar.y-6,18,14);ctx.beginPath();ctx.arc(ar.x,ar.y-6,6,Math.PI,0);ctx.stroke();}
    worldLabel(ar.x,ar.y-84,ar.name+(open?'':' · ЗАПЕЧАТАН'),open?'#9fe3ff':'#5a7a94');}}
  drawAbyss(t);
  // узлы миссий""")
# карточка и действие
R("  {const hg=WORLD.hangar;if(Math.hypot(p.x-hg.x,p.y-hg.y)<175){card={kind:'hangar',key:'hangar|'+curSkin()};S.last={x:hg.x,y:hg.y+150};}}",
  "  {const hg=WORLD.hangar;if(Math.hypot(p.x-hg.x,p.y-hg.y)<175){card={kind:'hangar',key:'hangar|'+curSkin()};S.last={x:hg.x,y:hg.y+150};}}\n  {const ar=WORLD.arsenal;if(Math.hypot(p.x-ar.x,p.y-ar.y)<175){card={kind:'arsenal',key:'arsenal|'+(arsOpen()?1:0)+'|'+(S.ars?S.ars.weapon:'')};S.last={x:ar.x,y:ar.y+150};}}")
R("  else if(card.kind==='abyss'){const eb=bestEndless();",
  "  else if(card.kind==='arsenal'){const open=arsOpen(),A=S.ars||arsDef();h=`<div class=\"eyebrow\">${WORLD.arsenal.name}${open?'':' · ЗАПЕЧАТАН'}</div><h3>${open?'Прокачка орудия и второе оружие':'Склад Изобретателя'}</h3><p class=\"note\">${open?`Оружие: ${ARS[A.weapon].name} · на складе ${lomH(S.lom,1)}`:'Откроется после первой победы в комнате босса 14.'}</p><div class=\"wc-row\">${open?'<button class=\"wbtn amber\" data-act=\"arsenal\">ОТКРЫТЬ [F]</button>':'<button class=\"wbtn\" disabled>ЗАПЕЧАТАНО</button>'}</div>`;}\n  else if(card.kind==='abyss'){const eb=bestEndless();")
R("  else if(c.kind==='hangar'&&act!=='echo')openHangar();",
  "  else if(c.kind==='hangar'&&act!=='echo')openHangar();\n  else if(c.kind==='arsenal'&&act!=='echo'){if(arsOpen())openArsenal();}")
# карта
R("  {const hg=WORLD.hangar;if(revealedAt(hg.x,hg.y))add('hangar',hg.x,hg.y,{},lod>=1?{t:hg.name,p:4,c:'#ff6bd0'}:null);}",
  "  {const hg=WORLD.hangar;if(revealedAt(hg.x,hg.y))add('hangar',hg.x,hg.y,{},lod>=1?{t:hg.name,p:4,c:'#ff6bd0'}:null);}\n  {const ar=WORLD.arsenal;if(revealedAt(ar.x,ar.y)||arsOpen())add('arsenal',ar.x,ar.y,{open:arsOpen()},lod>=1?{t:ar.name+(arsOpen()?'':' · ЗАПЕЧАТАН'),p:3,c:arsOpen()?'#9fe3ff':'#5a7a94'}:null);}")
R("    case 'hangar':glowC('#ff6bd0',12);",
  "    case 'arsenal':{const c=o.open||o.small?'#9fe3ff':'#3a5a74';glowC('#8fd8ff',12);g.strokeStyle=c;g.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;g[i?'lineTo':'moveTo'](Math.cos(a)*6.5,Math.sin(a)*6.5);}g.closePath();g.stroke();if(o.open||o.small){g.globalAlpha=.45;g.fillStyle='#8fd8ff';g.fill();g.globalAlpha=1;}break;}\n    case 'hangar':glowC('#ff6bd0',12);")
R("['shop','мастерская'],['hangar','хранилище'],","['shop','мастерская'],['hangar','хранилище'],['arsenal','арсенал'],")
R("hangar:WORLD.hangar.name,beacon:","hangar:WORLD.hangar.name,arsenal:WORLD.arsenal.name+(arsOpen()?'':' · запечатан'),beacon:")
R("  if(revealedAt(WORLD.hangar.x,WORLD.hangar.y))pts.push({x:WORLD.hangar.x,y:WORLD.hangar.y+150,label:'А'});",
  "  if(revealedAt(WORLD.hangar.x,WORLD.hangar.y))pts.push({x:WORLD.hangar.x,y:WORLD.hangar.y+150,label:'А'});\n  if(arsOpen())pts.push({x:WORLD.arsenal.x,y:WORLD.arsenal.y+150,label:'И'});")
R("  {const [x,y]=P(WORLD.hangar.x,WORLD.hangar.y);g.save();g.translate(x,y);g.rotate(Math.PI/4);g.fillStyle='#ff6bd0';g.fillRect(-4,-4,8,8);g.restore();}",
  "  {const [x,y]=P(WORLD.hangar.x,WORLD.hangar.y);g.save();g.translate(x,y);g.rotate(Math.PI/4);g.fillStyle='#ff6bd0';g.fillRect(-4,-4,8,8);g.restore();}\n  {const [x,y]=P(WORLD.arsenal.x,WORLD.arsenal.y);g.fillStyle=arsOpen()?'#9fe3ff':'#3a5a74';g.beginPath();g.arc(x,y,4,0,TAU);g.fill();}")

# ============ 5. экран Арсенала ============
R("const SCREENS=['sMenu','sCodex','sIntro','sLevel','sDone','sPause','sOver','sMap','sShop','sSave','sDev','sHangar','sCycle','sReport','sSet'];",
  "const SCREENS=['sMenu','sCodex','sIntro','sLevel','sDone','sPause','sOver','sMap','sShop','sSave','sDev','sHangar','sCycle','sReport','sSet','sArsenal'];")
R("""<!-- Новый цикл -->
<section class="screen" id="sReport" hidden>""",
"""<!-- 0.7.0: Арсенал «Иней» -->
<section class="screen" id="sArsenal" hidden>
  <div class="wrap ars">
    <div class="ars-head"><div><div class="eyebrow">АРСЕНАЛ «ИНЕЙ» · ХОЛОДНЫЙ АРХИВ · ДОПУСК ПОСЛЕ ИЗОБРЕТАТЕЛЯ</div><h2>Оружейный стенд</h2></div><div class="ars-lom" id="arsLom"></div></div>
    <div class="ars-cards" id="arsCards"></div>
    <p class="note" id="arsNote">Каждая ступень считается от текущего значения. Покупка подтверждается вторым нажатием. Купленное оружие переключается здесь или на брифинге миссии.</p>
    <div class="btns"><button class="btn primary" id="bArsClose">В ПОЛЁТ <kbd>ESC</kbd></button></div>
  </div>
</section>

<!-- Новый цикл -->
<section class="screen" id="sReport" hidden>""")
CSS=r"""
/* --- 0.7.0: Арсенал «Иней» --- */
.ars{width:min(980px,100%);display:grid;gap:14px}
.ars-head{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap}
.ars-lom{font-family:var(--f-mono);font-size:13px;letter-spacing:.1em;color:#9fd8ff;border:1px solid #2a4a66;padding:8px 12px;background:#06101c;white-space:nowrap}
.ars-cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.ars-card{position:relative;border:1px solid #2a4a66;background:linear-gradient(180deg,#07121f,#040a14);padding:14px;display:grid;gap:10px;align-content:start;box-shadow:inset 0 0 40px rgba(143,216,255,.05)}
.ars-card::before{content:'';position:absolute;inset:0;pointer-events:none;background:radial-gradient(circle at 0 0,rgba(159,227,255,.16),transparent 36%),radial-gradient(circle at 100% 100%,rgba(159,227,255,.10),transparent 40%)}
.ars-card.cur{border-color:#8fd8ff;box-shadow:0 0 0 1px rgba(143,216,255,.25),inset 0 0 40px rgba(143,216,255,.12)}
.ars-card .eyebrow{color:#9fd8ff}
.ars-demo{width:100%;height:auto;aspect-ratio:2/1;display:block;background:#030710;border:1px solid #1c2e44}
.ars-stats{font-family:var(--f-mono);font-size:12px;letter-spacing:.08em;color:#dff6ff}
.ars-track{display:grid;gap:6px}
.ars-tl{display:flex;justify-content:space-between;font-family:var(--f-mono);font-size:11px;letter-spacing:.18em;color:#9fd8ff}
.ars-segs{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.ars-seg{min-height:40px;border:1px solid #2a4a66;background:#06101c;color:#9fb8cc;font-family:var(--f-mono);font-size:11px;letter-spacing:.06em;clip-path:polygon(8px 0,100% 0,calc(100% - 8px) 100%,0 100%);padding:0 12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ars-seg.f{background:linear-gradient(180deg,#9fe3ff,#5fb8e6);color:#04060c;border-color:#9fe3ff}
.ars-seg.next:not([disabled]){border-color:#9fe3ff;color:#dff6ff;animation:arsPulse 1.6s infinite}
.ars-seg.poor{color:#ff8a7a;border-color:#5a2a38;animation:none}
.ars-seg.arm{background:#9fe3ff;color:#04060c;animation:none}
.ars-seg[disabled]{cursor:default;opacity:.55}
@keyframes arsPulse{0%,100%{box-shadow:0 0 0 0 rgba(159,227,255,0)}50%{box-shadow:0 0 14px 0 rgba(159,227,255,.45)}}
.ars-after{font-family:var(--f-mono);font-size:11px;color:#7a8ea5;letter-spacing:.06em}
.ars-buyw.poor{color:#ff8a7a;border-color:#5a2a38}
.ars-buyw.arm{background:#ffb84d;color:#04060c}
.ars-msg{font-family:var(--f-mono);font-size:11px;color:#ff8a7a;letter-spacing:.06em;min-height:14px}
.mob .ars{margin-left:0}
.ff-phone-p .ars-cards{grid-template-columns:1fr}
.mob .ars-seg{min-height:44px}
.mob .ars-tl,.mob .ars-seg,.mob .ars-after,.mob .ars-msg,.mob .ars-stats{font-size:calc(12px*var(--fs))}
.ff-phone-l .ars-demo,.ff-phone-l .ars-card>.note,.ff-phone-l #arsNote{display:none}
.ff-phone-l .ars-head h2{font-size:18px}
.ff-phone-l .ars-card{padding:10px}
#inWpnBox .seg button.on{border-color:#9fe3ff;color:#9fe3ff}
"""
R("</style>",CSS+"</style>",1)
R("function openHangar(){if(G.state!=='world')return;G.state='hangar';renderHangar();show('sHangar');}",
"""function openHangar(){if(G.state!=='world')return;G.state='hangar';renderHangar();show('sHangar');}
// ---- 0.7.0: Арсенал ----
function openArsenal(){if(G.state!=='world'||!arsOpen())return;const S=G.save;if(S&&!S.ars)S.ars=arsDef();G.state='arsenal';G.arsArm=null;renderArsenal();show('sArsenal');saveWorld();}
function closeArsenal(){if(G.state!=='arsenal')return;G.state='world';G.cardKey=null;G.arsArm=null;computeStats();show('');}
const f1=v=>(Math.round(v*10)/10).toFixed(1).replace('.',',');
function arsStat(w,lv){const dmg=10*arsMul(w,'pow',lv.pow),rate=w==='gun'?(1/.27)*arsMul('gun','rate',lv.rate):(1/.27)/1.6,R=110*arsMul('blast','rad',lv.rad||0);return {dmg,rate,R};}
function renderArsenal(){const S=G.save;if(!S)return;const A=S.ars||(S.ars=arsDef());if(G.arsArm&&performance.now()-G.arsArmT>6000)G.arsArm=null;
  $('#arsLom').innerHTML=`ЛОМ НА СКЛАДЕ ${lomH(S.lom,1)}`;
  const card=w=>{const W=ARS[w],own=!!A.own[w],cur=A.weapon===w&&own,lv=A.lv[w],st=arsStat(w,lv);
    const stats=w==='gun'?`УРОН ${f1(st.dmg)} · ТЕМП ${f1(st.rate)} ВЫСТР./С`:`ВЗРЫВ ${f1(st.dmg*1.4)} В ЦЕНТРЕ · ТЕМП ${f1(st.rate)} ВЫСТР./С · РАДИУС ${Math.round(st.R)}`;
    const tracks=Object.entries(W.tracks).map(([t,T])=>{const n=lv[t]||0;const curV=t==='pow'?st.dmg*(w==='blast'?1.4:1):t==='rate'?st.rate:st.R,nxt=n<3?curV*T.k[n]:null;
      const segs=T.k.map((k,i)=>{const can=own&&i===n,cost=T.cost[i],arm=G.arsArm===w+':'+t,poor=can&&S.lom<cost;
        return `<button class="ars-seg ${i<n?'f':i===n?'next':''} ${poor?'poor':''} ${arm&&can?'arm':''}" data-buy="${w}:${t}" ${can?'':'disabled'} aria-label="${T.name} ступень ${i+1}">${i<n?'✓ '+(i+1):arm&&can?'ПОДТВЕРДИТЬ':lomH(cost)}</button>`;}).join('');
      return `<div class="ars-track" data-t="${t}"><div class="ars-tl"><span>${T.name} · +${Math.round((T.k[Math.min(n,2)]-1)*100)} % ${n<3?'за ступень '+(n+1):''}</span><span>${n}/3</span></div><div class="ars-segs">${segs}</div><div class="ars-after">${!own?'сначала купите оружие':n<3?`сейчас ${t==='rad'?Math.round(curV):f1(curV)} → после ${t==='rad'?Math.round(nxt):f1(nxt)}`:'максимум'}</div></div>`;}).join('');
    const arm=G.arsArm==='w:'+w,btn=!own?`<button class="wbtn amber ars-buyw ${S.lom<W.price?'poor':''} ${arm?'arm':''}" data-buyw="${w}">${arm?'ПОДТВЕРДИТЬ · ':'КУПИТЬ ОРУЖИЕ · '}${lomH(W.price)}</button>`:cur?`<button class="wbtn" disabled>АКТИВНО</button>`:`<button class="wbtn" data-pickw="${w}">ВЫБРАТЬ</button>`;
    return `<div class="ars-card ${cur?'cur':''}" data-w="${w}"><div class="eyebrow">${W.name}${cur?' · АКТИВНО':own?' · КУПЛЕНО':' · '+lomH(W.price)}</div><canvas class="ars-demo" data-demo="${w}" width="440" height="220" aria-hidden="true"></canvas><div class="ars-stats">${stats}</div><p class="note">${W.d}</p>${tracks}<div class="wc-row">${btn}</div></div>`;};
  $('#arsCards').innerHTML=card('gun')+card('blast');const m=$('#arsMsg');if(m)m.textContent=G.arsMsgT||'';G.arsMsgT='';}
function arsBuy(key){const S=G.save,A=S.ars;if(!A)return false;
  if(key.startsWith('w:')){const w=key.slice(2),W=ARS[w];if(A.own[w])return false;if(S.lom<W.price){G.arsMsgT='НЕ ХВАТАЕТ '+(W.price-S.lom)+' ЛОМА';sfx('block');return false;}S.lom-=W.price;A.own[w]=1;A.weapon=w;}
  else{const [w,t]=key.split(':'),T=ARS[w].tracks[t],n=A.lv[w][t]||0;if(!A.own[w]||n>=3)return false;const cost=T.cost[n];if(S.lom<cost){G.arsMsgT='НЕ ХВАТАЕТ '+(cost-S.lom)+' ЛОМА';sfx('block');return false;}S.lom-=cost;A.lv[w][t]=n+1;}
  G.arsArm=null;computeStats();saveWorld();sfx('level');buzz('win');return true;}
document.addEventListener('click',e=>{if(G.state!=='arsenal')return;const S=G.save;if(!S||!S.ars)return;
  const b=e.target.closest('[data-buy],[data-buyw],[data-pickw]');if(!b||b.disabled)return;
  if(b.dataset.pickw){S.ars.weapon=b.dataset.pickw;computeStats();saveWorld();buzz('tap');renderArsenal();return;}
  const key=b.dataset.buyw?'w:'+b.dataset.buyw:b.dataset.buy;
  if(G.arsArm===key){arsBuy(key);}else{G.arsArm=key;G.arsArmT=performance.now();buzz('tap');}renderArsenal();});
// живые демонстрации выстрела
function arsDemoTick(now){const S=G.save;if(!S||!S.ars)return;const t=now/1000;
  document.querySelectorAll('#arsCards .ars-demo').forEach(c=>{const w=c.dataset.demo,g=c.getContext('2d'),W=c.width,H=c.height,lv=S.ars.lv[w],st=arsStat(w,lv);g.clearRect(0,0,W,H);
    g.fillStyle='#030710';g.fillRect(0,0,W,H);g.strokeStyle='#10213a';g.lineWidth=1;for(let x=0;x<W;x+=40){g.beginPath();g.moveTo(x,0);g.lineTo(x,H);g.stroke();}
    const sx=60,sy=H/2;g.fillStyle='#8fe9ff';g.beginPath();g.moveTo(sx+16,sy);g.lineTo(sx-12,sy-11);g.lineTo(sx-6,sy);g.lineTo(sx-12,sy+11);g.closePath();g.fill();
    const tg=[[W-70,sy-52],[W-60,sy],[W-74,sy+50]];const cyc=w==='gun'?1.2:2.4,ph=(t%cyc)/cyc;
    if(w==='gun'){const gap=Math.max(28,90*3.7/st.rate);const th=1.5+(st.dmg/10-1)*2;g.strokeStyle='#8fe9ff';g.lineWidth=th;for(let x=sx+20+(ph*gap)%gap;x<W-80;x+=gap){g.beginPath();g.moveTo(x-16,sy);g.lineTo(x,sy);g.stroke();}
      for(const [x,y] of tg){const hit=Math.abs(y-sy)<8&&((t*st.rate)%1)<.25;g.strokeStyle=hit?'#ffffff':'#ff4f6e';g.lineWidth=2;g.beginPath();g.arc(x,y,12,0,TAU);g.stroke();if(hit){g.fillStyle='rgba(255,255,255,.35)';g.fill();}}}
    else{const fx=sx+20+ph*(W-sx-120)/.6,R=st.R*.55;const expl=ph>.6;const ex=W-90,ey=sy;
      if(!expl){g.fillStyle='#dff6ff';g.beginPath();g.arc(Math.min(fx,ex),sy,5,0,TAU);g.fill();g.strokeStyle='#9fe3ff';g.lineWidth=2;g.beginPath();g.moveTo(Math.min(fx,ex)-18,sy);g.lineTo(Math.min(fx,ex),sy);g.stroke();}
      else{const q=(ph-.6)/.4;g.strokeStyle=`rgba(159,227,255,${1-q})`;g.lineWidth=3;g.beginPath();g.arc(ex,ey,R*Math.min(1,q*1.6),0,TAU);g.stroke();g.fillStyle=`rgba(159,227,255,${.25*(1-q)})`;g.fill();}
      for(const [x,y] of tg){const d=Math.hypot(x-ex,y-ey),hit=expl&&d<R*Math.min(1,(ph-.6)/.4*1.6);g.strokeStyle=hit?'#ffffff':'#ff4f6e';g.lineWidth=2;g.beginPath();g.arc(x,y,12,0,TAU);g.stroke();if(hit){g.fillStyle='rgba(255,255,255,.35)';g.fill();}}
      g.strokeStyle='rgba(159,227,255,.25)';g.setLineDash([4,4]);g.beginPath();g.arc(ex,ey,R,0,TAU);g.stroke();g.setLineDash([]);}
  });}""")
R("    else if(G.state==='hangar')drawHangarPreviews(now);}catch(err){console.error(err);}",
  "    else if(G.state==='hangar')drawHangarPreviews(now);else if(G.state==='arsenal')arsDemoTick(now);}catch(err){console.error(err);}")
R("  if(G.state==='hangar'){if(e.code==='Escape')closeHangar();return;}",
  "  if(G.state==='hangar'){if(e.code==='Escape')closeHangar();return;}\n  if(G.state==='arsenal'){if(e.code==='Escape')closeArsenal();return;}")
R("$('#bResume').onclick=resume;","$('#bArsClose').onclick=closeArsenal;$('#bResume').onclick=resume;")
# сообщение об ошибке покупки — строка под карточками
R('<p class="note" id="arsNote">','<div class="ars-msg" id="arsMsg"></div><p class="note" id="arsNote">')

# ============ 6. брифинг: выбор оружия ============
R('<div class="diffbox" id="inDiffBox" hidden><div class="eyebrow">СЛОЖНОСТЬ МИССИИ</div><div class="seg" id="inDiff"></div><p class="note" id="inDiffNote"></p></div>',
  '<div class="diffbox" id="inDiffBox" hidden><div class="eyebrow">СЛОЖНОСТЬ МИССИИ</div><div class="seg" id="inDiff"></div><p class="note" id="inDiffNote"></p><div id="inWpnBox" hidden><div class="eyebrow" style="margin-top:6px">ОРУЖИЕ · АРСЕНАЛ</div><div class="seg" id="inWpn"></div></div></div>')
R("renderDiff();if(isMob()&&M.hint.length>1)","renderDiff();renderWpnSel();if(isMob()&&M.hint.length>1)")
R("function renderDiff(){",
"""function renderWpnSel(){const box=$('#inWpnBox');if(!box)return;const S=G.save,ok=G.mode==='world'&&G.state==='intro'&&S&&S.ars&&S.ars.own.blast;box.hidden=!ok;if(!ok)return;
  $('#inWpn').innerHTML=['gun','blast'].map(w=>`<button data-wpn="${w}" class="${S.ars.weapon===w?'on':''}">${ARS[w].name}</button>`).join('');}
document.addEventListener('click',e=>{const b=e.target.closest('[data-wpn]');if(!b||!G.save||!G.save.ars||!G.save.ars.own[b.dataset.wpn])return;G.save.ars.weapon=b.dataset.wpn;computeStats();saveWorld();renderWpnSel();buzz('tap');});
function renderDiff(){""")

# ============ 7. сохранение ============
R("  const pk={};for(const k of Object.keys(obj(S.perks)))if(PERKS[k])pk[k]=num(S.perks[k],0,0,PERKS[k].max,true);S.perks=pk;",
  "  const pk={};for(const k of Object.keys(obj(S.perks)))if(PERKS[k])pk[k]=num(S.perks[k],0,0,PERKS[k].max,true);S.perks=pk;\n  {const A=obj(S.ars),lv=obj(A.lv),g=obj(lv.gun),bl=obj(lv.blast);S.ars={weapon:A.weapon==='blast'?'blast':'gun',own:{gun:1,blast:obj(A.own).blast?1:0},lv:{gun:{pow:num(g.pow,0,0,3,true),rate:num(g.rate,0,0,3,true)},blast:{pow:num(bl.pow,0,0,3,true),rad:num(bl.rad,0,0,3,true)}}};if(!S.ars.own.blast)S.ars.weapon='gun';\n   const tr={};for(const k of Object.keys(obj(S.trophy))){const i=+k;if(BOSS_TROPHY[i]&&S.trophy[k])tr[i]=1;}S.trophy=tr;}")
# HUD-чип
R('<div class="chip" id="chgC" hidden>ЗАРЯД — ГОТОВ</div>','<div class="chip" id="chgC" hidden>ЗАРЯД — ГОТОВ</div><div class="chip" id="wpnC" hidden style="color:#9fe3ff;border-color:#2a4a66">РАЗРЫВ</div>')

# ============ 8. тексты ============
R("Награда за первое прохождение уровней 11–50: 100 + 3×(N−10) лома.</dd>",
  "Награда за первое прохождение уровней 11–14: 100 + 3×(N−10) лома ×1,5; с уровня 15 — втрое больше. Повторы в секторах III и дальше дают 35 % от первой награды, без затухания. За первую победу над каждым боссом — трофей: 2000 за 14-го, 3000 за 18-го и далее +1000.</dd><dt>Арсенал «Иней»</dt><dd>Открывается после первой победы в комнате босса 14, стоит рядом с узлом 14 в Холодном архиве. Прокачка основного орудия: СИЛА +20/30/40 % (2000/3000/4000) и ТЕМП +10/20/30 % (1500/2500/3500) — каждая ступень от текущего значения. Второе оружие «Разрыв» (5000): снаряд детонирует при касании и бьёт всех в радиусе 110, темп ниже, пробитие и рикошет не действуют; свои ветки — МОЩНОСТЬ и РАДИУС. Оружие переключается в Арсенале или на брифинге миссии. В Бесконечности Арсенал не действует.</dd>")
R("<dt>ESC / P</dt><dd>Пауза</dd>","<dt>ЗАРЯД С «РАЗРЫВОМ»</dt><dd>Заряженный выстрел второго оружия — один взрыв ×6 радиусом в полтора раза больше обычного</dd><dt>ESC / P</dt><dd>Пауза</dd>")
R('<div class="eyebrow">АЛЬФА 0.6.2 · МОБИЛЬНАЯ</div>','<div class="eyebrow">АЛЬФА 0.7.0 · АРСЕНАЛ</div>')
R("if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.6.2 α</dt>",
  "if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.7.0 α</dt><dd>«Арсенал». После комнаты босса 14 в Холодном архиве открывается Арсенал «Иней»: прокачка силы и темпа орудия по три ступени и второе оружие «Разрыв» — снаряд по области со своими ветками мощности и радиуса. Новый доход во второй половине игры: трофеи боссов, тройные награды с 15-й миссии, повторы в секторах III+ дают 35 % без затухания.</dd><dt>0.6.2 α</dt>")

open(P,'w',encoding='utf8').write(s)
print('m12 ok')
