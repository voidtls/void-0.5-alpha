# 1.2.7 α «Первый вылет»: обучение внутри игры и надпись запрета прыжка
import sys
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m45 FAIL',n,a[:90]);sys.exit(1)
    s=s.replace(a,b)
# запрет прыжка: те же проверки, вынесенные в jumpDenyReason; отказ ещё и крупно по центру карты
i=s.find('function mapJumpAt(');a=s.find("const deny=m=>{",i);b=s.find("const go=()=>",i)
old=s[a:b]
assert "deny('ПРЫЖОК НЕВОЗМОЖЕН · ТОЧКА НЕВОЗВРАТА');return true;}" in old
new="const deny=(m,r)=>{mapMsg(m);G.mapDeny={x:best.x,y:best.y-150,until:performance.now()+700};sfx('block');try{mapDenyShow(r);}catch(e){}};\n  {const r=jumpDenyReason(best);if(r){deny(JUMP_DENY[r].msg,r);return true;}}\n  "
s=s[:a]+new+s[b:]
R("const hv=G.mapHover==='jp'+q.label;g.strokeStyle=hv?'rgba(255,255,255,.9)':'rgba(255,255,255,.3)';","const hv=G.mapHover==='jp'+q.label;g.strokeStyle=mapJpCol(hv);")
R("Белое кольцо — точка прыжка: нажмите, чтобы перенестись (не рядом с врагами).","Белое кольцо — точка прыжка: нажмите, чтобы перенестись. Рядом с врагами и во время патруля кольца краснеют — прыжок недоступен.")
css=open(D+'m45.css',encoding='utf8').read()+'\n'+open(D+'m47.css',encoding='utf8').read()
i=s.find('</style>');s=s[:i]+css+'\n'+s[i:]
js=open(D+'m45.js',encoding='utf8').read()+'\n'+open(D+'m47.js',encoding='utf8').read()
i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m45 ok')
