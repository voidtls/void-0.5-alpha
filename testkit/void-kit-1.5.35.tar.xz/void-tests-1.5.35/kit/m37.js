/* ===== 1.2.4 α: единый масштаб интерфейса UI (1080p = 1, 1440p = 1,35, 4K = 2) + сцена 21:9 ===== */
var UI=1;
SET_DEF.uiSize=1;SET_OPT.uiSize=[.9,1,1.1,1.25];SEGS.uiSize=[['ИНТЕРФЕЙС',[[.9,'90%'],[1,'АВТО'],[1.1,'110%'],[1.25,'125%']]]];
try{const v=store('void_settings');if(v&&SET_OPT.uiSize.includes(v.uiSize))SET.uiSize=v.uiSize;}catch(e){}
function uiCalc(){if(G.ff!=='desk')return 1;const a=Math.min(CW/1920,CH/1080);return Math.max(.85,Math.round(clamp(a,1,2.5)*(SET.uiSize||1)*20)/20);}
function stageW(){return G.ff==='desk'&&CW/CH>2.45?Math.round(CH*21/9):CW;}
function uiApply(){const u=uiCalc(),R=document.documentElement;UI=u;R.style.setProperty('--ui',u);R.classList.toggle('uiz',G.ff==='desk');
  const m=Math.max(0,(CW-stageW())/2);R.style.setProperty('--stage-m',(m/u).toFixed(2)+'px');R.style.setProperty('--stage-px',m.toFixed(1)+'px');R.classList.toggle('ultra',m>0);}
{const _rz=resize;resize=function(){_rz();try{uiApply();}catch(e){}};addEventListener('resize',()=>{try{uiApply();}catch(e){}});try{uiApply();}catch(e){}}
try{let mq=null;const watch=()=>{try{if(mq)mq.removeEventListener('change',on);mq=matchMedia('(resolution: '+(window.devicePixelRatio||1)+'dppx)');mq.addEventListener('change',on);}catch(e){}};const on=()=>{resize();watch();};watch();}catch(e){}
/* арена миссии на ПК шире 21:9 — 21:9 по центру, остальное — фон */
{const _la=lockArena;lockArena=function(){if(!isMob()&&VW/VH>21/9+.02){G.arena={w:Math.round(VH*21/9),h:Math.round(VH)};applyWH();return;}_la();};}
/* настройки: строка «Интерфейс» на ПК; применяется сразу */
{const _as=applySettings;applySettings=function(){_as();try{uiApply();}catch(e){}};}
if(SET.uiSize===undefined)SET.uiSize=1;
function stageL(){return (CW-stageW())/2;}
/* стрелка у края экрана (вызывается из погони и телефона): на ПК — в масштабе UI и в пределах сцены */
{const _ea=edgeArrow;edgeArrow=function(x,y,col,size,label){if(isMob()||UI===1&&!stageL())return _ea(x,y,col,size,label);
  const sl=stageL(),cw=CW,ch=CH,sc=SC,cx=CX,cy=CY;ctx.save();ctx.translate(sl,0);ctx.scale(UI,UI);
  try{CW=stageW()/UI;CH=ch/UI;SC=sc/UI;CX=cx+sl/sc;return _ea(x,y,col,size,label);}finally{CW=cw;CH=ch;SC=sc;CX=cx;CY=cy;ctx.restore();}};}
/* подписи на большой карте растут вместе с UI */
try{const c=document.getElementById('mapC'),g=c&&c.getContext('2d');if(g){const D=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,'font');
  Object.defineProperty(g,'font',{configurable:true,get(){return D.get.call(this);},set(v){D.set.call(this,UI===1?v:String(v).replace(/(\d+(?:\.\d+)?)px/,(m,n)=>(+n*UI).toFixed(1)+'px'));}});}}catch(e){}
/* арена 21:9 на сверхшироком: за краями — приглушённый фон и тонкая рамка поля */
{const _mo=mobOverlay;mobOverlay=function(now){try{if(!isMob()&&G.arena&&!G.world&&(G.state==='play'||G.state==='pause'||G.state==='levelup'||G.state==='intro')){
  ctx.setTransform(DPR,0,0,DPR,0,0);const x0=(0-CX)*SC,x1=(W-CX)*SC;ctx.fillStyle='rgba(2,3,8,.42)';if(x0>0)ctx.fillRect(0,0,x0,CH);if(x1<CW)ctx.fillRect(x1,0,CW-x1,CH);
  ctx.strokeStyle='rgba(143,233,255,.14)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x0+.5,0);ctx.lineTo(x0+.5,CH);ctx.moveTo(x1-.5,0);ctx.lineTo(x1-.5,CH);ctx.stroke();}}catch(e){}
  return _mo(now);};}
