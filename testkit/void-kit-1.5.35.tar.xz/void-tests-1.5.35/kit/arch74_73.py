# ---------- 73 · A-20 · фиксированная частота шагов 1/60 с накопителем (C1) ----------
PRE73="""/* ▼▼▼ ARCH·73 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.13 α · этап 4.2: игровой шаг 1/60)
   A-20 · главный цикл frame74: накопитель реального времени кадра, шаги ровно по 1/60 с, не больше 3 за кадр
   (тот же предел 0,05 с, что у старого цикла). Замедление slow95, ударная пауза hs90 и resumeK масштабируют dt шага (C1),
   а их таймеры, часы ARCH.clk и зум камеры camZ (видимая область VW/VH) отсчитываются по шагам. HUD, звук и отрисовка — раз в кадр,
   ветка HUD выбирается по состоянию на начало кадра, как прежде; мир не удваивается режимом speed, как прежде.
   Старый frame() остаётся целиком: window.__archOff=['A-20'] (или выключенный A-19) до загрузки — и игра идёт по нему. */
const STEP74=1/60,MAXN74=3;let ACC74=0;ARCH.sc74=1;ARCH.n74=0;ARCH.steps74=0;
function live74(){return G.state==='play'||G.state==='world';}
function camZ74(dt){const zt=camZTarget(),z=G.camZ||1;if(Math.abs(zt-z)>.001){G.camZ=z+clamp(zt-z,-.15*dt,.15*dt);setScale();}}
function mobTick74(dt,now){
  touchTick(dt);qTick(dt,now);wakeSync(now);padTick(now);tutTick();
  cv.classList.toggle('fs-cursor',!isMob()&&FS.state==='native'&&(G.state==='play'||G.state==='world')&&now-(MOUSE.mvAt||0)>2500);}
function step74(){
  ARCH.clk+=STEP74;camZ74(STEP74);let k=1;const L=live74();
  if(G.resumeK>0&&L){G.resumeK=Math.max(0,G.resumeK-STEP74);if(G.resumeK>0)k*=.3;}
  const S_=G.slow95;if(S_&&S_.t>0&&L){S_.t-=STEP74;k*=S_.k;if(S_.t<=0)G.slow95=null;}
  G.rdt90=STEP74*k;let kh=1;const H_=G.hs90;
  if(H_&&G.state==='play'){if(H_.t>0){H_.t-=STEP74;kh=.04;}else if(H_.ramp>0){const r0=H_.ramp;H_.ramp-=STEP74;kh=.3+.7*(1-r0/.4);}else G.hs90=null;}
  const dt=STEP74*k*kh,reps=devOn('speed')?2:1;G.rdtU96=reps;ARCH.sc74=k*kh;ARCH.steps74++;
  if(G.state==='play'){for(let r=0;r<reps&&G.state==='play';r++)update(dt);}
  else if(G.state==='world'){if(G.prologue)prologueTick(dt);else worldUpdate(dt);}}
function frame74(now){
  if(isMob()&&SET.fps===30&&now-last<29&&now>=last){requestAnimationFrame(frame);return;}
  const dt0=Math.min(.05,Math.max(0,(now-last)/1000));last=now;
  try{mobTick74(dt0,now);}catch(err){console.error(err);}
  let n=0;const st0=G.state,pro0=G.prologue;
  try{if(!live74()){ACC74=0;ARCH.sc74=1;camZ74(dt0);if(G.state!=='pause')G.resumeK=0;}
    else{ACC74=Math.min(ACC74+dt0,STEP74*MAXN74+1e-9);while(ACC74>=STEP74-1e-9&&n<MAXN74&&live74()){ACC74-=STEP74;n++;step74();}}
    if(st0==='play'){if(G.mode==='endless')updateEndlessHUD();else updateHUD();}
    else if(st0==='world'){if(!pro0)updateWorldHUD();}
    else if(st0==='hangar')drawHangarPreviews(now);else if(st0==='arsenal')arsDemoTick(now);arch69Ok();}catch(err){console.error(err);arch69Fault(err);/* ARCH·69 A-4 */}
  ARCH.n74=n;const dt=live74()?dt0*ARCH.sc74:dt0;
  if(dt>0)fpsAvg+=(1/dt-fpsAvg)*.05;
  if(G.mode==='endless'&&G.state==='play'&&!G.lowFx){G.fpsLow=dt>1/40?(G.fpsLow||0)+dt:Math.max(0,(G.fpsLow||0)-dt*.5);if(G.fpsLow>3)G.lowFx=true;}
  try{if(G.prologue&&G.state!=='world')prologueEnd();if(G.state!=='world'&&G.state!=='play'&&G.radio&&G.radio.cur)radioClear();if(G.state==='menu')menuGlitch(dt);else menuGlitchOff();}catch(err){console.error(err);}
  try{musicTick(dt);if(G.state!=='play'&&G.x90&&(G.x90.hudAll||G.x90.hud&&G.x90.hud.cur))clearHud100();}catch(err){console.error(err);}
  try{if(G.world&&G.player)renderWorld(now);else{render(now);secVignette();}mobOverlay(now);drawDevOverlay();}catch(err){console.error(err);}
  requestAnimationFrame(frame);}
"""+END%73
S73=[
 ("function frame(now){\n  if(isMob()&&SET.fps===30&&now-last<29&&now>=last){requestAnimationFrame(frame);return;}",
  "function frame(now){\n  if(!ARCH.off['A-20']&&!ARCH.off['A-19'])return frame74(now);/* ARCH·73 A-20 */\n  if(isMob()&&SET.fps===30&&now-last<29&&now>=last){requestAnimationFrame(frame);return;}"),
]
STAGES[73]=dict(vf='1.5.12 α',vt='1.5.13 α',J='m73_journal.txt',pre=PRE73,after=72,sites=S73)
