# ARCH·71 (1.5.11 α) — единый список правок: m71.py применяет, strip71.py обращает.
# Каждая правка: точный фрагмент 1.5.10 (встречается ровно один раз) и группа. Внутри фрагмента
# Math.random() → vR<g>() и rnd( → vrnd<g>( — только в этом фрагменте; фрагмент выбран так, что вся случайность в нём визуальная
# (разбор каждой строки — в журнале m71_journal.md). Никаких массовых замен по файлу.
import re
D='@@KIT@@/'
SITES=[
 # ---- группа 1 · A-14 · ядро боя
 (1,'tryDash:996',"if(SET.fx)for(let i=0;i<10;i++)part(p.x,p.y,-x*rnd(80,260)+rnd(-60,60),-y*rnd(80,260)+rnd(-60,60),.35,(SKINS[curSkin()]||SKINS.base).trail,2.2);"),
 (1,'updateBullets:1119',"rockHit(r,b.dmg);b.life=0;if(SET.fx)part(b.x,b.y,rnd(-60,60),rnd(-60,60),.2,'#9fb0c4',2);break;"),
 (1,'updateBullets:1137',"if(SET.fx)part(b.x,b.y,-b.vx*.08+rnd(-50,50),-b.vy*.08+rnd(-50,50),.18,'#d8f8ff',1.6);"),
 # ---- группа 2 · A-15 · мир и сюжет
 (2,'worldUpdate:3439',"if(SET.fx&&Math.random()<dt*12)part(p.x+rnd(-10,10),p.y+rnd(-10,10),(a.x-p.x)/d*220,(a.y-p.y)/d*220,.6,'#c9a6ff',2);"),
 (2,'worldUpdate:3440',"if(G.cruise&&SET.fx&&Math.hypot(p.vx,p.vy)>320&&Math.random()<.6)part(p.x-p.vx*.04+rnd(-6,6),p.y-p.vy*.04+rnd(-6,6),-p.vx*.3,-p.vy*.3,.35,shipCol(),2);"),
 (2,'storyRetreatMove:4995',"if(SET.fx&&Math.random()<.25)part(e.x,e.y,rnd(-40,40),rnd(-40,40),.4,'#dfe8ff',1.5);"),
 (2,'storyWorldTick:5353',"G.parts.length<300&&Math.random()<e*dt*6){const p=G.player;part(p.x+rnd(-300,300),p.y+rnd(-200,200),rnd(-20,20),rnd(10,40),1.2,'#6b4a8c',1.5);}"),
 (2,'postDirector:12818',"if(SET.fx)for(let k=0;k<8;k++)part(ex,ey,rnd(-140,140),rnd(-60,160),.4,'#dff6ff',1.6);"),
 # ---- группа 3 · A-16 · боссы и сектора (живая копия b74Hit — объявление 7131)
 (3,'b74Hit:7132+7134',"for(const h of X.hulls){if(hullIn(h,b.x,b.y,2)){b.life=0;if(SET.fx)part(b.x,b.y,rnd(-60,60),rnd(-60,60),.2,'#9fb0c4',2);return true;}}\n  for(const e of G.enemies){if(e.type!=='absorber'||!e.alive||e.spawnT>0||b.charged||e.tired)continue;if(segDist(b.px,b.py,b.x,b.y,e.x,e.y)>e.r+3)continue;\n    b.life=0;b.det=true;e.ab=(e.ab||0)+1;e.flash=.05;if(SET.fx)part(b.x,b.y,rnd(-30,30),rnd(-30,30),.25,'#ff9fe0',2);\n    if(e.ab>=25){e.ab=0;e.bursts="),
 (3,'b74Hit:7141',"hurt(e,b.dmg*.35,{memb:true});b.life=0;e.shieldFlash=.08;if(SET.fx)part(b.x,b.y,rnd(-40,40),rnd(-40,40),.3,'#ff8fa8',2.5);"),
 (3,'tgFx95:10041',"if(o.k==='line'){for(let i=0;i<n;i++){const u=Math.random();part(o.x+(o.x2-o.x)*u,o.y+(o.y2-o.y)*u,rnd(-60,60),rnd(-60,60),rnd(.2,.45),i%3?c:'#ffffff',2);}}"),
 (3,'tgFx95:10042',"for(let i=0;i<n;i++){const a=rnd(0,TAU);part(o.x+Math.cos(a)*o.r*.5,o.y+Math.sin(a)*o.r*.5,Math.cos(a)*rnd(40,140),Math.sin(a)*rnd(40,140),rnd(.25,.5),c,2);}}"),
 (3,'tgFx95:10043',"else if(o.k==='cone'){for(let i=0;i<n;i++){const a=o.a+rnd(-o.arc/2,o.arc/2),d=rnd(20,o.len);part(o.x+Math.cos(a)*d,o.y+Math.sin(a)*d,Math.cos(a)*80,Math.sin(a)*80,.3,c,2);}}}"),
# ---- группа 3, продолжение: строки У6-18, реально достигнутые прогонами T4 на 1.5.10 и разобранные по одной (все — только аргументы/условия part)
 (3,'updateEnemies:1241',"if(SET.fx&&Math.random()<.6)part(e.x,e.y,rnd(-30,30),rnd(-30,30),.3,'#ff4545',2.5);"),
 (3,'updateEnemies:1343',"if(e.dT>0){e.dT-=dt;if(SET.fx)part(e.x,e.y,rnd(-30,30),rnd(-30,30),.25,'#ff2e4a',2);}"),
 (3,'updateBoss:1495',"if(SET.fx&&Math.random()<.4)part(b.x+rnd(-30,30),b.y+rnd(-30,30),rnd(-80,80),rnd(-80,80),.4,'#ffffff',2);"),
 (3,'addIce:5556',"if(SET.fx)for(let i=0;i<14;i++)part(p.x,p.y,rnd(-120,120),rnd(-120,120),.5,'#dff6ff',2.5);"),
 (3,'secEnemyUpdate:5618',"if(SET.fx&&Math.random()<.3)part(tg.x+rnd(-8,8),tg.y+rnd(-8,8),0,-30,.3,'#ffb060',2);"),
 (3,'obRingBullet:5854',"if(SET.fx)part(q.x,q.y,rnd(-50,50),rnd(-50,50),.2,'#ffb060',2);"),
 (3,'b74Hit:7147',"b.life=0;if(SET.fx)part(x,y,rnd(-50,50),rnd(-50,50),.3,'#ffd36b',2);"),
 (3,'wellBullet:8308',"if(SET.fx)part(x,y,rnd(-40,40),rnd(-40,40),.25,'#9fb8ff',2);"),
 (3,'dying85:8558',"if(fx.kind==='answer'&&SET.fx&&Math.random()<.4)part(b.cx+rnd(-20,20),b.cy+rnd(-20,20),rnd(-60,60),rnd(-60,60),.8,shipCol(),2.5);"),
 (3,'s1Tick:12552',"if(SET.fx)for(let k=0;k<10;k++)part((L.a.x+L.b.x)/2,(L.a.y+L.b.y)/2,rnd(-120,120),rnd(-120,120),.4,S1C.violet,2.5);"),
 (3,'hurt(обёртка s1):12608',"e.shieldFlash=.12;if(SET.fx)part(e.x,e.y,rnd(-50,50),rnd(-50,50),.2,S1C.violet,2);return;"),
 (3,'b80Hit:7491',"hurt(e,b.dmg,{rail:true});b.life=0;e.shieldFlash=.08;if(SET.fx)part(b.x,b.y,rnd(-40,40),rnd(-40,40),.25,'#c9d2de',2);"),
 (3,'lekBelts:7994','k.life=0;if(SET.fx)part(k.x,g.furY+10,rnd(-20,20),-60,.5,C85.hot,3);'),
 (3,'lekStrike:8031',"if(SET.fx)for(let i=0;i<14;i++)part(x+rnd(-hw,hw),y+rnd(-hh*.6,hh*.6),rnd(-160,160),rnd(-40,40),.5,'#9fb0c4',3);"),
 (3,'lekBullet:8107',"if(SET.fx)part(bu.x,bu.y,rnd(-60,60),rnd(-60,60),.2,'#ffffff',2);if(!bu.charged){bu.life=0;return true;}"),
 (3,'tideTick100:9119','if(SET.fx)for(let i=0;i<12;i++)part(p.x,p.y,rnd(-120,120),rnd(-120,120),.4,C90.sh,2);'),
 (3,'echoAI100:9211',"if(SET.fx)part(e.x,e.y,rnd(-30,30),rnd(-30,30),.3,'#e0fff4',2);return;}"),
 (3,'eraserAI100:9237','if(SET.fx&&Math.random()<.7)glyph95(e.x,e.y,1,C90.sh);','if(SET.fx&&vR3()<.7)glyph95(e.x,e.y,1,C90.sh,1);'),
 (3,'shoreHands95:9595',"if(SET.fx&&Math.random()<.6)glyph95(sw.vert?sw.x+rnd(-30,30):at,sw.vert?at:sw.y+rnd(-30,30),1,'#f4fff9');","if(SET.fx&&vR3()<.6)glyph95(sw.vert?sw.x+vrnd3(-30,30):at,sw.vert?at:sw.y+vrnd3(-30,30),1,'#f4fff9',1);"),
 (3,'shoot95:10161',"if(SET.fx)for(let i=0;i<fxN95(6);i++){const a=rnd(0,TAU);part(b.x,b.y,Math.cos(a)*120,Math.sin(a)*120,.3,b.col,2);}snd95('pop',b.x);"),
 (3,'death95:10134','if(sec===8&&SET.fx){const n=fxN95(10);for(let i=0;i<n;i++){const a=rnd(0,TAU),v=rnd(60,220);part(e.x,e.y,Math.cos(a)*v,Math.sin(a)*v,rnd(.3,.7),i%3?C90.blood:C95.bloodD,rnd(2,3.5));}}'),
 (3,'spawned95:10475',"snd95('pore',e.x);if(SET.fx)for(let i=0;i<fxN95(8);i++){const a=rnd(0,TAU);part(e.x,e.y,Math.cos(a)*90,Math.sin(a)*90,.4,C90.blood,2.5);}"),
 (3,'t95Tick:10922','for(const q of X.pud){if(Math.random()<dt*2)q.bub=(q.bub||[]).concat([{a:rnd(0,TAU),d:rnd(0,q.r*.8),t:0}]).slice(-6);'),
 (3,'t95Tick:10923',"inPud90(p.x,p.y)&&Math.random()<.5)part(p.x,p.y,-(p.x-p.px)*10,-(p.y-p.py)*10,.6,'#5a0a16',3);"),
 (3,'heartFinTick96:11007',"if(SET.fx&&Math.random()<.5){const a=rnd(0,TAU),v=rnd(80,240);part(b.cx+Math.cos(a)*b.r*.6,b.cy+Math.sin(a)*b.r*.6,Math.cos(a)*v,Math.sin(a)*v,rnd(.4,.9),Math.random()<.5?'#ffffff':C90.ark,rnd(2,3.5));}"),
 # ---- группа 4 · A-17 · «Ноль»
 (4,'zbTick:11507',"if(SET.fx&&Math.random()<.7)part(p.x,p.y,-Z.dir.x*300+rnd(-60,60),-Z.dir.y*300+rnd(-60,60),.4,C120.zero,2);"),
 (4,'zbArc:11699',"function zbArc(Z,x1,y1,x2,y2,col){if(!SET.fx)return;const P=[[x1,y1]],n=6;for(let i=1;i<n;i++){const k=i/n;P.push([x1+(x2-x1)*k+rnd(-14,14),y1+(y2-y1)*k+rnd(-14,14)]);}"),
 (4,'zbShards:11701',"n=isMob()?Math.ceil(n/2):n;for(let i=0;i<n;i++){const a=rnd(0,TAU),v=rnd(.35,1)*spd;zbFx(Z,{k:'shard',x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,a:rnd(0,TAU),va:rnd(-9,9),s:rnd(5,13),t:0,T:rnd(.6,1.2),col});}}"),
 (4,'zbFxTick:11704',"let q=mob?.3:2;while(q>0){if(q<1&&Math.random()>q)break;q--;const th=rnd(0,TAU),r=zbRad(Z,th),x=c.x+Math.cos(th)*r,y=c.y+Math.sin(th)*r;if(!inView(x,y,40))continue;const sg=Math.random()<.5?1:-1,tv=rnd(30,90)*sg,ov=N&&N.type==='S'?-50:30;part(x,y,-Math.sin(th)*tv+Math.cos(th)*ov,Math.cos(th)*tv+Math.sin(th)*ov,rnd(.4,.8),col,2);}"),
 (4,'zbFxTick:11705',"Z.arcT=mob?.16:.08;const a1=rnd(0,TAU),a2=a1+rnd(1,2.6),r1=e.r+rnd(6,50),r2=e.r+rnd(6,50);zbArc(Z,e.x+Math.cos(a1)*r1,e.y+Math.sin(a1)*r1,e.x+Math.cos(a2)*r2,e.y+Math.sin(a2)*r2,Math.random()<.5?C120.white:C120.ice);"),
 (4,'zbFxTick:11706',"while(M.length<want)M.push({a:rnd(0,TAU),r:rnd(.2,1),v:rnd(.03,.09),w:rnd(.15,.5)});if(M.length>want)M.length=want;for(const m of M){m.r-=m.v*dt;m.a+=m.w*dt*(1.2-m.r);if(m.r<.04){m.r=rnd(.9,1);m.a=rnd(0,TAU);}}"),
 (4,'zbFxTick:11708',"if((Z.wind>0||Z.stance>0||(Z.burst&&Z.burst.t>0))&&Math.random()<(mob?.4:1)){const q=rnd(0,TAU),r=rnd(90,150);part("),
 (4,'zbFxTick:11709',"if(v>220&&Math.random()<(mob?.4:.9)){part(e.x-e.vx/v*e.r*.6+rnd(-10,10),e.y-e.vy/v*e.r*.6+rnd(-10,10),"),
 (4,'zbFxTick:11710',"if(Z.stage===2&&Z.novaT>0&&Math.random()<(mob?.5:1)){const c=zbCen(Z),q=rnd(0,TAU),r=zbRad(Z,q)*.6;part("),
 (4,'zbHurt:11855',"n=(m>=2.5?7:m>=1.5?5:3)*(isMob()?.5:1);for(let i=0;i<n;i++){const q=a+rnd(-1,1),v=rnd(120,360);part(hx,hy,"),
 (4,'zbHurt:11856',"if(SET.fx&&Math.random()<(isMob()?.35:.7)){const a=Math.atan2(p.y-e.y,p.x-e.x)+rnd(-.5,.5),"),
 (4,'zbHurt:11857',"for(let i=0;i<(m>=2?4:2);i++)part(hx,hy,Math.cos(a)*rnd(80,220)+rnd(-60,60),Math.sin(a)*rnd(80,220)+rnd(-60,60),rnd(.2,.4),col,m>=2?3:2);"),
 (4,'zbHurt:11858',"if(m>=2.5&&G.shock.length<60&&Math.random()<.25)G.shock.push({x:hx,y:hy,r:4,R:40,t:0,col,thin:true});"),
 (4,'zbAmbTick:11872',"if(on&&SET.fx){if(A.gl.length<6&&Math.random()<dt*.8)A.gl.push({x:Math.random(),y:Math.random(),t:0,T:rnd(2.5,5),s:rnd(6,16),c:Math.random()<.5?C120.zero:C120.ice,vx:rnd(-.01,.01),vy:rnd(-.008,.008)});"),
 # ---- группа 5 · A-18 · частота кадров (HUD и мини-карта; работают и без эффектов)
 (5,'updateWorldHUD:3675',"if(I>=.7&&SET.fx){hd.style.transform=Math.random()<.25?`translate(${rnd(-4,4).toFixed(1)}px,${rnd(-2,2).toFixed(1)}px)`:'';hd.style.opacity=Math.random()<.12?'.55':'1';if(Math.random()<.08){"),
 (5,'drawMini:3697',"for(let i=0;i<40;i++){g.fillStyle=Math.random()<.5?'#ff4f6e':'#9fb0c4';g.fillRect(Math.random()*s,Math.random()*s,2,1);}"),
 (5,'glyph95:10121','function glyph95(x,y,n,col){const X=G.x90;const L=X&&inMission()?(X.gl95||(X.gl95=[])):(G.wgl95||(G.wgl95=[]));n=fxN95(n);for(let i=0;i<n;i++){if(L.length>60)L.shift();const a=rnd(0,TAU),v=rnd(30,120);L.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-30,life:rnd(.6,1.2),max:1.2,ch:GLYPH95[Math.random()*GLYPH95.length|0],col:col||C90.sh,rot:rnd(-1,1)});}}','function glyph95(x,y,n,col,vis){const X=G.x90;const L=X&&inMission()?(X.gl95||(X.gl95=[])):(G.wgl95||(G.wgl95=[]));const gR=vis?vR3:vR5,gRnd=vis?vrnd3:vrnd5;/* ARCH·71: vis — вызов под SET.fx (A-16), иначе A-18 */n=fxN95(n);for(let i=0;i<n;i++){if(L.length>60)L.shift();const a=gRnd(0,TAU),v=gRnd(30,120);L.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-30,life:gRnd(.6,1.2),max:1.2,ch:GLYPH95[gR()*GLYPH95.length|0],col:col||C90.sh,rot:gRnd(-1,1)});}}'),
]
def new(t):
    return t[3] if len(t)>3 else conv(t[0],t[2])
def conv(g,s):
    t=s.replace('Math.random()','vR%d()'%g)
    t=re.sub(r'(?<![\w.$])rnd\(','vrnd%d('%g,t)
    return t
PRE=open(D+'m71.js',encoding='utf8').read() if __import__('os').path.exists(D+'m71.js') else ''
def pairs(J):
    P=[('<div class="ver" id="verTag">1.5.10 α</div>','<div class="ver" id="verTag">1.5.11 α</div>'),
       ("const VER_TAG='1.5.10 α';","const VER_TAG='1.5.11 α';"),
       ('<dl class="kv"><dt>1.5.10 α</dt>','<dl class="kv"><dt>1.5.11 α</dt><dd>'+J+'</dd><dt>1.5.10 α</dt>'),
       ('/* ▲▲▲ ARCH·70 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */\n','/* ▲▲▲ ARCH·70 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */\n'+PRE+'\n'),
       ("const VFXR65=(()=>{let s=0x51ED27;return ()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return (s>>>0)/4294967296;};})();\n",
        "const VFXR65=(()=>{let s=0x51ED27;return ()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return (s>>>0)/4294967296;};})();\n/* ARCH·71 A-14…A-18 */arch71Boot();\n")]
    for t in SITES:P.append((t[2],new(t)))
    return P
