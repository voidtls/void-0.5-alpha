/* ===== 1.4.2 α «Пульт»: одна кнопка «Готово», вкладки без прокрутки =====
   1) верхняя «ГОТОВО» из 1.4.1 убрана: на телефоне нижняя и так всегда на экране, на ПК — Esc и нижняя (с подсказкой ESC);
   2) на телефоне вкладки — плитка 3 + 2 со значками, видны все пять сразу, ничего не листается вбок. */
const TIC64={snd:'<path d="M3 7.5h3l4-3v11l-4-3H3z"/><path d="M13.5 7c1.1 1.6 1.1 4.4 0 6M15.8 5c2 2.7 2 7.3 0 10"/>',
  ctl:'<circle cx="10" cy="10" r="7"/><circle cx="10" cy="10" r="2.6"/>',
  scr:'<rect x="2.5" y="3.5" width="15" height="10" rx="1.5"/><path d="M7 17h6M10 13.5V17"/>',
  acc:'<path d="M1.8 10S5 4.5 10 4.5 18.2 10 18.2 10 15 15.5 10 15.5 1.8 10 1.8 10z"/><circle cx="10" cy="10" r="2.6"/>',
  game:'<path d="M10 2.5l6 14-6-3.2-6 3.2z"/>'};
function tabIco64(k){return `<svg class="tic64" viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round">${TIC64[k]||''}</svg>`;}
{const _h=head63;head63=function(){const r=_h.apply(this,arguments);try{
  const d=$('#bSetDone63');if(d)d.remove();
  document.querySelectorAll('#sSet button[data-tab63]').forEach(b=>{if(b.querySelector('.tic64'))return;const n=b.textContent;b.innerHTML=tabIco64(b.dataset.tab63)+`<span>${n}</span>`;b.setAttribute('aria-label',n);});
  const bk=$('#bSetBack');if(bk&&!bk.querySelector('kbd'))bk.insertAdjacentHTML('beforeend',' <kbd class="pconly64">ESC</kbd>');}catch(e){console.error(e);}return r;};}
