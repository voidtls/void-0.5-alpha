# аудиоданные встраиваются последними: блоки base64 в конце <body>
import base64
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
names=['intro0','intro1']+['loop%d'%i for i in range(10)]
blocks=''.join('<script type="application/octet-stream" id="v12-%s">%s</script>\n'%(n,base64.b64encode(open(D+'au/seg/%s.m4a'%n,'rb').read()).decode()) for n in names)
import json
man=json.load(open(D+'au/seg2/manifest.json'))
for k,v in man.items():
    for x in v['segs']:
        blocks+='<script type="application/octet-stream" id="mz-%s">%s</script>\n'%(x[0],base64.b64encode(open(D+'au/seg2/%s.m4a'%x[0],'rb').read()).decode())
s=s.rstrip()+'\n'+blocks
open(P,'w',encoding='utf8').write(s);print('m99 ok',round(len(s.encode())/1e6,2),'MB')
