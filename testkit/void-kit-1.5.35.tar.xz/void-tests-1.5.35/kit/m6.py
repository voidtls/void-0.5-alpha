# 0.6.0 · часть 6: правки по скриншотам
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m6: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)

# HUD не просвечивает под паузой и выбором модуля на телефоне
R("$('#hud').hidden=!['play','levelup','pause','world'].includes(G.state);",
  "$('#hud').hidden=!['play','levelup','pause','world'].includes(G.state)||isMob()&&(G.state==='levelup'||G.state==='pause');")

# стрелки мира на телефоне — общий экранный механизм с обходом кнопок
R("  const arrow=(x,y,col,label)=>{const X=(x-CX)*SC,Y=(y-CY)*SC;if(X>20&&X<CW-20&&Y>20&&Y<CH-20)return;",
  "  const arrow=(x,y,col,label)=>{if(isMob()){edgeArrow(x,y,col,10,label+' · '+fmtAU(Math.hypot(x-p.x,y-p.y)));ctx.setTransform(DPR,0,0,DPR,0,0);return;}const X=(x-CX)*SC,Y=(y-CY)*SC;if(X>20&&X<CW-20&&Y>20&&Y<CH-20)return;")
R("  const [ex,ey,a]=edgePt(X,Y,SAFE.l+26,SAFE.t+74,CW-SAFE.r-26,CH-SAFE.b-26);",
  "  let [ex,ey,a]=edgePt(X,Y,SAFE.l+26,SAFE.t+74,CW-SAFE.r-26,CH-SAFE.b-26);\n  if(ex>CW-SAFE.r-130&&ey<SAFE.t+176)ey=SAFE.t+176;\n  for(let n=0;n<2;n++)for(const k in TBR){const b=TBR[k];if(Math.hypot(ex-b.x,ey-b.y)<b.r+22){if(Math.abs(ex-b.x)>Math.abs(ey-b.y)&&ey<b.y)ey=b.y-b.r-24;else if(ex>CW/2)ex=b.x-b.r-24;else ex=b.x+b.r+24;}}")

CSS=r"""
/* --- 0.6.0: правки по скриншотам --- */
.ff-phone-l #hud .hud-w{top:calc(66px + var(--sat));right:calc(max(12px,var(--sar)) + 106px)}
.mob #hud.endless .hud-tr{flex-direction:column-reverse;align-items:flex-end}
.mob #hud.endless #score{font-size:16px}
.ff-phone-l #sMap{padding-top:calc(10px + var(--sat));padding-bottom:calc(8px + var(--sab))}
.ff-phone-l #sMap .mapwrap{gap:6px;position:relative}
.ff-phone-l #mapPane>.bar-l{display:none}
.ff-phone-l #mapPane{gap:6px!important}
.ff-phone-l #sMap .mapwrap>.btns{position:absolute;top:0;right:0;bottom:auto;width:auto;padding:0;margin:0;background:none}
.ff-phone-l #sMap .mapwrap>.btns .btn{min-height:44px;padding:8px 14px}
.ff-phone-l .mapleg{display:none}
.ff-phone-l #shopBot,.ff-phone-l #sShop h2,.ff-phone-l #shopLom{display:none}
.ff-phone-l #sShop .shop{gap:10px}
.mob .alphaJump select{min-height:40px;max-width:100%}
.mob .alphaJump .wbtn{min-height:40px}
"""
R("</style>",CSS+"</style>",1)
# карта: в ландшафте кнопка «В ПОЛЁТ» вверху справа — больше места под холст
R("h=isMob()?Math.max(180,Math.round(innerHeight-c.getBoundingClientRect().top-(innerWidth>innerHeight?64:96)-SAFE.b))",
  "h=isMob()?Math.max(180,Math.round(innerHeight-c.getBoundingClientRect().top-(innerWidth>innerHeight?14:96)-SAFE.b))")

open(P,'w',encoding='utf8').write(s)
print('m6 ok')
