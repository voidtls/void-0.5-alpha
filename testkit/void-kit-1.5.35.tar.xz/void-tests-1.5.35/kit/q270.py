# 1.3.3 α «Курс без тупиков»: ворота рывка до успеха, склад после миссии 01, карта после миссии 02. Каждый тест падает на v33 (1.3.2).
import asyncio,json,sys,os
from h import *
NEW=open(SP+'q210.py').read().split('NEW="""')[1].split('"""')[0]
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
HELP="""()=>{
window.flyTo=async(tx,ty,R,maxMs,dashAt)=>{const t0=performance.now();let dashed=false;while(performance.now()-t0<maxMs){const p=G.player;if(!p||G.state!=='world')break;const d=Math.hypot(tx-p.x,ty-p.y);if(d<R)break;steer2(tx,ty);
  if(dashAt&&!dashed&&Math.hypot(dashAt.x-p.x,dashAt.y-p.y)<dashAt.r){p.dashCd=0;tryDash([(tx-p.x)/d,(ty-p.y)/d]);dashed=true;}await w8(16);}for(const k of KK)KEYS[k]=false;};
window.WIN=async(m)=>{T.go(m);missionComplete();await w8(500);returnToWorld();$('#toast').hidden=true;for(let i=0;i<30&&G.state!=='world';i++)await w8(100);/* патруль у узла — отдельный урок, здесь не мешает */for(const z of (G.zones||[]).concat(typeof W58!=='undefined'&&W58.zones||[])){if(z){z.active=false;z.cool=1e6;}}G.enemies.forEach(e=>{if(e.zone)e.alive=false;});TUT.hist=[];};
window.curK=()=>TUT.cur&&TUT.cur.k;window.chipTxt=()=>{const c=document.querySelector('#tut .tut-txt');return c?c.textContent:'';};
window.ringOn=(el)=>{const r=[...document.querySelectorAll('#tut .tut-ring.on')];if(!el||!r.length)return false;const a=el.getBoundingClientRect();return r.some(q=>{const b=q.getBoundingClientRect();const cx=(b.left+b.right)/2,cy=(b.top+b.bottom)/2;return cx>a.left-4&&cx<a.right+4&&cy>a.top-4&&cy<a.bottom+4;});};
window.toRings=async()=>{await waitCur('calib',5000);await w8(300);const K=TUT.cal;for(const q of K.pts){await flyTo(q.x,q.y,30,8000);}return K;};
return 1;}"""
async def mk(b,w=1280,h=720,touch=False,calib=False):
    P=await newpage(b,w,h,alpha=False,touch=touch)
    await P.js(NEW,{'calib':calib,'touch':touch});await P.js(HELP)
    return P

@test('Y01')
async def y01(b):
    P=await mk(b,calib=True)
    r=await P.js("""async()=>{const K=await toRings();const g=K.gate;await flyTo(g.x+K.dx*300,g.y+K.dy*300,40,8000);const fails=g.fails;
      radioLine('ПЕРЕХВАТ · СТРАЖ','#ff4f6e','Он стреляет первым. Как только увидите вспышку — уходите в сторону. Повторяю: уходите в сторону.');await w8(400);
      const radio=!!(G.radio&&G.radio.cur),cur1=curK();
      await flyTo(g.x-K.dx*300,g.y-K.dy*300,40,9000,{x:g.x,y:g.y,r:110});const radio2=!!(G.radio&&G.radio.cur);
      return {fails,radio,cur1,radio2,done:!!G.save.tut.done.calib,okDash:!!(G.save.tut.ok&&G.save.tut.ok.dash)}}""")
    ok=r['fails']>=1 and r['radio'] and r['done'] and r['okDash']
    rec('Y01 пролетел луч без рывка, заговорило радио — ворота остаются; рывок назад сквозь луч во время реплики засчитан',ok,r)

@test('Y02')
async def y02(b):
    P=await mk(b,calib=True)
    r=await P.js("""async()=>{const K=await toRings();const g=K.gate;await flyTo(g.x+K.dx*300,g.y+K.dy*300,40,8000);const p=G.player;
      p.x=g.x+K.dx*2400;p.y=g.y+K.dy*2400;if(sectorIdx(p.x,p.y)>1){p.x=g.x-K.dx*2400;p.y=g.y-K.dy*2400;}p.vx=p.vy=0;
      const t0=performance.now();while(performance.now()-t0<15000){p.vx=p.vy=0;await w8(200);}
      const K2=TUT.cal;const gd=K2?Math.round(Math.hypot(K2.gate.x-p.x,K2.gate.y-p.y)):null;
      return {done:!!G.save.tut.done.calib,i:K2&&K2.i,gd,cal:G.save.tut.calI}}""")
    ok=(not r['done']) and r['i']==3 and r['gd'] is not None and r['gd']<800
    rec('Y02 пролетел без рывка и улетел далеко на 15 с — калибровка не снята, ворота переехали к игроку, кольца засчитаны',ok,r)

@test('Y03')
async def y03(b):
    P=await mk(b,calib=True)
    r=await P.js("""async()=>{await waitCur('calib',5000);await w8(300);const K=TUT.cal;for(const q of K.pts.slice(0,2))await flyTo(q.x,q.y,30,8000);const i0=K.i;
      await WIN(1);const t0=performance.now();const seq=[];while(performance.now()-t0<9000){const k=curK();if(k&&seq[seq.length-1]!==k)seq.push(k);if(k==='lom'||k==='stash'){if(k==='stash')break;}await w8(50);}
      G.save.tut.done.lom=1;G.save.tut.done.stash=1;if(TUT.cur&&(curK()==='lom'||curK()==='stash'))tutEnd('abort');TUT.gap=0;
      const back=await waitCur('calib',5000);const iAfter=TUT.cal&&TUT.cal.i;saveWorld();
      return {i0,seq,back,iAfter,calI:G.save.tut.calI,calS:G.save.tut.calS,cleared:G.save.cleared}}""")
    await P.pg.reload();await P.pg.wait_for_timeout(400);await P.js(LIB)
    r2=await P.js("""async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));startWorld(false);for(let i=0;i<40&&(G.prologue||G.state!=='world');i++)await w8(100);$('#toast').hidden=true;
      G.save.tut.done.lom=1;G.save.tut.done.stash=1;G.save.tut.done.patrol=1;for(const z of (G.zones||[]).concat(typeof W58!=='undefined'&&W58.zones||[])){if(z){z.active=false;z.cool=1e6;}}G.enemies.forEach(e=>{if(e.zone)e.alive=false;});if(TUT.cur&&TUT.cur.k==='patrol')tutEnd('abort');TUT.hist=[];TUT.gap=0;const t0=performance.now();while(performance.now()-t0<6000&&!(TUT.cur&&TUT.cur.k==='calib'))await w8(50);await w8(200);
      return {cur:TUT.cur&&TUT.cur.k,i:TUT.cal&&TUT.cal.i,calI:G.save.tut.calI}}""")
    ok=r['i0']==2 and 'stash' in r['seq'] and r['back'] and r['iAfter']==2 and r2['cur']=='calib' and r2['i']==2
    rec('Y03 не доделал калибровку и прошёл миссию 01: сначала дорога на склад, потом ворота снова ждут; после перезагрузки пройденные кольца на месте',ok,{'a':r,'b':r2})

@test('Y04')
async def y04(b):
    out={}
    for (w,h,t) in [(1280,720,False),(844,390,True)]:
        P=await mk(b,w,h,touch=t)
        out[f'{w}x{h}']=await P.js("""async()=>{done('move','act');const lom0=G.save.lom;await WIN(1);const lom1=G.save.lom;const t0=performance.now();const on=await waitCur('stash',6000);const lat=Math.round(performance.now()-t0);await w8(400);
          const txt=chipTxt(),ring=ringOn($('#wLom'));const tl=performance.now();const st=await waitCur('stash',100);const lat2=Math.round(performance.now()-tl);await w8(400);const txt2=chipTxt();const s=tutShopPt();
          await flyTo(s.x,s.y,200,40000);await w8(400);const T=G.save.tut;return {on,lat,txt,ring,st,lat2,txt2,done:!!T.done.stash,ok:!!(T.ok&&T.ok.stash),lomSame:G.save.lom===lom1,gain:lom1-lom0,carry:G.save.carry}}""")
    ok=all(v['on'] and v['lat']<5000 and 'НАГРАДА' in v['txt'] and v['ring'] and v['st'] and v['lat2']<6500 and 'НА СКЛАД' in v['txt2'] and v['done'] and v['ok'] and v['lomSame'] for v in out.values())
    rec('Y04 (1.3.4) вернулся из миссии 01: «НАГРАДА — НА СКЛАДЕ» с кольцом на счётчике лома и дорожкой к складу сразу; долетел — «СКЛАД» засчитан, лом не тронут (ПК и телефон)',ok,out)

@test('Y05')
async def y05(b):
    P=await mk(b)
    r=await P.js("""async()=>{done('move','act');G.save.carry=40;const seen=new Set();let t0=performance.now();while(performance.now()-t0<4000){if(curK())seen.add(curK());await w8(50);}
      const before=[...seen];G.save.cleared=1;G.save.medals[1]={clear:1};TUT.worldT=150;TUT.gap=0;TUT.hist=[];seen.clear();t0=performance.now();while(performance.now()-t0<4000){if(curK())seen.add(curK());await w8(50);}
      return {before,late:[...seen]}}""")
    ok=not any(k in r['before'] for k in ['lom','stash'])
    rec('Y05 до миссии 01 лом в трюме подсказок не вызывает',ok,r)

@test('Y06')
async def y06(b):
    P=await mk(b)
    r=await P.js("""async()=>{done('move','act');await WIN(1);await waitCur('lom',6000);const st=await waitCur('stash',9000);if(TUT.cur)TUT.cur.t=44.95;await w8(400);const T=G.save.tut;const d1=!T.done.stash,ok1=!!(T.ok&&T.ok.stash);
      TUT.gap=0;const seen=[];const t0=performance.now();while(performance.now()-t0<6000){if(curK())seen.push(curK());await w8(100);}return {st,d1,ok1,again:seen.includes('stash')}}""")
    ok=r['st'] and r['d1'] and not r['ok1'] and r['again']
    rec('Y06 (1.3.4) дорожку к складу игнорируют 45 с — она не закрывается и ведёт домой до визита',ok,r)

@test('Y07')
async def y07(b):
    P=await mk(b)
    r=await P.js("""async()=>{done('move','lom','stash','act','fire','dash','pulse','patrol');G.save.cleared=1;G.save.medals[1]={clear:1};const p=G.player;const s=tutShopPt();p.x=s.x+2600;p.y=s.y;TUT.worldT=40;
      const seen=new Set();let t0=performance.now();while(performance.now()-t0<4000){if(curK())seen.add(curK());await w8(50);}openMap();await w8(1500);const inMap=curK();const hint=!!($('#mapHint')&&$('#mapHint').classList.contains('on'));closeMap();
      return {seen:[...seen],inMap,hint}}""")
    ok=not any(k in r['seen'] for k in ['map','jump']) and r['inMap']!='jump' and not r['hint']
    rec('Y07 после миссии 01 (далеко от склада): ни «КАРТА», ни прыжка к мастерской — карта молчит',ok,r)

@test('Y08')
async def y08(b):
    out={}
    for (w,h,t) in [(1280,720,False),(844,390,True)]:
        P=await mk(b,w,h,touch=t)
        out[f'{w}x{h}']=await P.js("""async(t)=>{done('move','lom','stash','act','fire','dash','pulse','patrol','energy');G.save.cleared=1;G.save.medals[1]={clear:1};await WIN(2);const t0=performance.now();const on=await waitCur('map',6000);const lat=Math.round(performance.now()-t0);await w8(400);
          const tgt=t?(tutVis($('#tAct'))&&$('#tAct').dataset.act==='map'?$('#tAct'):$('#mini')):$('#btnMap');return {on,lat,ring:ringOn(tgt),txt:chipTxt(),cleared:G.save.cleared}}""",t)
    ok=all(v['on'] and v['lat']<5000 and v['ring'] and v['cleared']==2 for v in out.values())
    rec('Y08 вернулся из миссии 02: кольцо на кнопке карты за ≤5 с (после баннера победы) (ПК — «КАРТА [M]», телефон — мини-карта)',ok,out)

@test('Y09')
async def y09(b):
    P=await mk(b)
    r=await P.js("""async()=>{done('move','lom','stash','act','fire','dash','pulse','patrol','energy');G.save.cleared=2;G.save.medals[1]={clear:1};G.save.medals[2]={clear:1};TUT.worldT=200;
      openMap();await w8(1000);const el=$('#mapHint');const on1=!!el&&el.classList.contains('on');const txt=el?el.textContent:'';const cur=curK();
      const R=el?el.querySelector('.mh-band').getBoundingClientRect():null;const hit=R?document.elementFromPoint((R.left+R.right)/2,(R.top+R.bottom)/2):null;
      await w8(4300);const on2=el.classList.contains('on');await w8(1300);const on3=el.classList.contains('on')||getComputedStyle(el).visibility!=='hidden';const jh=!!G.save.tut.jh;
      closeMap();await w8(300);openMap();await w8(1500);const again=el.classList.contains('on');
      const q=G.mapPts.find(z=>Math.hypot(z.x-G.player.x,z.y-G.player.y)>800);let okJ=null;if(q){G.mapAnimJump=false;mapJumpAt(q.px,q.py);G.mapAnimJump=undefined;await w8(700);okJ=!!(G.save.tut.ok&&G.save.tut.ok.jump);}if(G.state==='map')closeMap();
      return {on1,txt,cur,hit:hit&&hit.id,on2,on3,jh,again,okJ}}""")
    P2=await mk(b)
    r2=await P2.js("""async()=>{done('move','lom','stash','act','fire','dash','pulse','patrol','energy');G.save.cleared=2;G.save.medals[1]={clear:1};G.save.medals[2]={clear:1};const p=G.player;spawnEnemy('scout',p.x+300,p.y,{});const e=G.enemies[G.enemies.length-1];e.hp=e.maxHp=1e9;
      await w8(300);e.x=p.x+300;e.y=p.y;const deny=jumpDenyReason(null);openMap();await w8(1200);const h=$('#mapHint');return {deny,hint:!!h&&h.classList.contains('on'),jh:!!G.save.tut.jh}}""")
    ok=r['on1'] and 'НАЖМИ НА ТОЧКУ' in r['txt'] and r['cur']!='jump' and r['hit']=='mapC' and r['on2'] and not r['on3'] and r['jh'] and not r['again'] and r['okJ'] and r2['deny'] and not r2['hint'] and not r2['jh']
    rec('Y09 первое открытие карты после миссии 02: «НАЖМИ НА ТОЧКУ — ПРЫЖОК» ~5 с и уходит, нажатия проходят сквозь неё, второй раз не показывается; при запрете прыжка — молчит; «ПРЫЖОК» засчитан только настоящим прыжком',ok,{'a':r,'deny':r2})

@test('Y10')
async def y10(b):
    out={}
    for (w,h,t) in [(360,640,True),(390,844,True),(844,390,True),(1280,720,False),(1024,1366,True)]:
        P=await mk(b,w,h,touch=t)
        out[f'{w}x{h}']=await P.js("""async()=>{done('move','lom','stash','act','fire','dash','pulse','patrol','energy');G.save.cleared=2;G.save.medals[1]={clear:1};G.save.medals[2]={clear:1};openMap();await w8(1300);
          const el=$('#mapHint');if(!el||!el.classList.contains('on'))return {on:false};const B=el.querySelector('.mh-band').getBoundingClientRect(),M=document.querySelector('#sMap .mapbox').getBoundingClientRect(),C=document.querySelector('#sMap .mapctl').getBoundingClientRect();
          const l=el.querySelector('.mh-l'),s=el.querySelector('.mh-s');const one=x=>{const r=x.getBoundingClientRect(),lh=parseFloat(getComputedStyle(x).lineHeight)||parseFloat(getComputedStyle(x).fontSize)*1.2;return r.height<lh*1.6&&x.scrollWidth<=x.clientWidth+1&&r.left>=B.left-1&&r.right<=B.right+1;};
          const ov=!(B.right<=C.left||B.left>=C.right||B.bottom<=C.top||B.top>=C.bottom);
          return {on:true,inside:B.left>=M.left-1&&B.right<=M.right+1&&B.top>=M.top-1&&B.bottom<=M.bottom+1,one:one(l)&&one(s),ov,band:[B.left,B.top,B.width,B.height].map(Math.round)}}""")
        await P.pg.screenshot(path=SP+f'shots/y10_{w}x{h}.png')
    ok=all(v['on'] and v['inside'] and v['one'] and not v['ov'] for v in out.values())
    rec('Y10 подпись в карте на 360×640, 390×844, 844×390, 1280×720, 1024×1366: внутри карты, каждая строка в одну линию, не на кнопках масштаба',ok,out)

@test('Y11')
async def y11(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("()=>({ver:VER_TAG,tag:$('#verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.3.3 α</dt>')})")
    rec('Y11 версия 1.3.3 α и запись в журнале',r['ver']=='1.3.3 α' and r['tag']=='1.3.3 α' and r['log'],r)

if __name__=='__main__':
    sel=sys.argv[1:]
    if sel:TESTS=[t for t in TESTS if t[0] in sel]
    asyncio.run(run(TESTS,'q270'))
