# QA-1000: батарея из 1000+ независимых итераций всей игры по семи направлениям (A миссии, B босс 50, C мир, D экраны,
# E сохранения, F телефон, G отрисовка). Запуск: python3 qa1000.py OUTDIR WORKER NWORKERS [DIRS] [LIMIT]
# Каждая итерация: свежая страница, своё зерно Math.random, общий набор оракулов QA.inv(), находки → OUTDIR/find_W.jsonl
import asyncio,json,sys,os,random,time,base64,traceback,copy
from playwright.async_api import async_playwright
SP='@@KIT@@/'
GAME=os.environ.get('GAME_URL','file://@@KIT@@/home/void.html')
LIB=open(SP+'lib.js').read()
# ——— заимствуем готовые куски из прежних наборов (без запуска их main)
def grab(fn,name):
    s=open(SP+fn).read();i=s.index(name+'="""')+len(name)+4;return s[i:s.index('"""',i)]
HELP74=grab('q74.py','HELP')
BOT74=grab('bal74.py','BOT74')
from h120 import H120
_ns={}
_src=open(SP+'chaos120.py').read();exec(compile(_src[:_src.index('async def t(b):')],'chaos120_head','exec'),_ns)
CH_SETUP,CH_RUN,CH_BOT1,CH_EVS,CH_FL=_ns['SETUP'],_ns['RUN'],_ns['BOT1'],_ns['EVS'],_ns['FL']
ZBOT=_ns['ZBOT']
_fz={}
_src=open(SP+'fuzz200.py').read();exec(compile(_src[:_src.index('async def iteration')],'fuzz200_head','exec'),_fz)
FZ_HELP,FZ_A,FZ_KEYS=_fz['HELP'],_fz['A'],_fz['KEYPOOL']
T_JS=r"""()=>{window.T=Object.assign(window.T||{},{
  go(m,echo){enterNode(m,echo);if(G.state==='intro')startMission();let n=0;while(G.state==='levelup'&&n++<40)choose(0);return G.state;},
  fresh(){localStorage.removeItem('void_world');startWorld(true);if(G.prologue)prologueEnd();$('#toast').hidden=true;return G.state;},
  openAll(){const S=G.save;S.cleared=10;S.gate=true;for(let m=1;m<=49;m++)S.medals[m]=Object.assign(S.medals[m]||{},{clear:1});S.medals[50]=S.medals[50]||{};saveWorld();}});return 1;}"""
QA_JS=r"""()=>{window.QA={
 SMAP:{menu:'sMenu',codex:'sCodex',intro:'sIntro',levelup:'sLevel',done:'sDone',pause:'sPause',over:'sOver',map:'sMap',shop:'sShop',save:'sSave',dev:'sDev',hangar:'sHangar',cycle:'sCycle',report:'sReport',arsenal:'sArsenal',settings:'sSet'},
 cap(k){return k==='parts'?PMAX+5:k==='enemies'?500:(k==='eb'||k==='pb')?2500:4000;},
 vis(){return [...document.querySelectorAll('section.screen')].filter(e=>!e.hidden&&e.id!=='fsCard').map(e=>e.id);},
 inv(txt){const bad=[];const p=G.player,S=G.save;const fin=v=>typeof v!=='number'||Number.isFinite(v);
  if(p){for(const k of ['x','y','hp','vx','vy','en','r'])if(k in p&&!fin(p[k]))bad.push('nanP:'+k);
    if(G.st&&Number.isFinite(G.st.maxHp)&&p.hp>G.st.maxHp*1.01+1&&(G.state==='play'||G.state==='world'))bad.push('hpOverMax:'+Math.round(p.hp)+'/'+Math.round(G.st.maxHp));
    if(G.st)for(const k in G.st){if(typeof G.st[k]==='number'&&!Number.isFinite(G.st[k])){bad.push('nanSt:'+k);break;}}}
  if(S){for(const k of ['lom','carry','cleared','cycle'])if(k in S){const v=+S[k];if(!Number.isFinite(v))bad.push('nanS:'+k);else if(v<0)bad.push('negS:'+k);}
    if(S.pilot&&(!Number.isFinite(+S.pilot.lvl)||!Number.isFinite(+S.pilot.xp)))bad.push('nanPilot');
    if(S.perks)for(const k in S.perks){if(PERKS[k]&&(S.perks[k]>PERKS[k].max||S.perks[k]<0)){bad.push('perkRange:'+k+'='+S.perks[k]);break;}}}
  for(const k of ['score','kills','xp','lvl','t','taken','need'])if(k in G&&!fin(G[k]))bad.push('nanG:'+k);
  if(G.xp<0||G.score<0)bad.push('negG');
  try{if(!Number.isFinite(CX)||!Number.isFinite(CY))bad.push('nanCam');}catch(e){}
  for(const k of Object.keys(G)){const a=G[k];if(!Array.isArray(a))continue;if(a.length>QA.cap(k))bad.push('grow:'+k+'='+a.length);
    for(let i=0;i<Math.min(a.length,400);i++){const o=a[i];if(o&&typeof o==='object'&&!Array.isArray(o)&&('x' in o)&&(!fin(o.x)||!fin(o.y))){bad.push('nanArr:'+k+(o.type?':'+o.type:''));break;}}}
  for(const e of G.enemies||[]){if(!e.alive)continue;if(!fin(e.hp)||!fin(e.vx)||!fin(e.vy)){bad.push('nanE:'+e.type);break;}if(e.maxHp&&e.hp>e.maxHp*1.01+1){bad.push('eHpOver:'+e.type+':'+Math.round(e.hp)+'/'+Math.round(e.maxHp));break;}}
  if(G.mode==='world'&&p&&G.state==='world'&&(p.x<-50||p.y<-50||p.x>WW+50||p.y>WH+50))bad.push('pOutWorld:'+Math.round(p.x)+','+Math.round(p.y));
  const vis=QA.vis();if(vis.length>1)bad.push('screens:'+vis.join(','));
  const want=QA.SMAP[G.state];
  if(want&&!(vis.length===1&&vis[0]===want))bad.push('screenMismatch:'+G.state+'/'+vis.join(','));
  if((G.state==='world'||G.state==='play')&&vis.length)bad.push('screenOverPlay:'+G.state+'/'+vis.join(','));
  if(!want&&G.state!=='world'&&G.state!=='play')bad.push('state?:'+G.state);
  if(txt){const t=document.body.innerText;const m=t.match(/[^\n]{0,30}(undefined|NaN|\[object|Infinity)[^\n]{0,30}/);if(m)bad.push('badText:'+m[0].trim().slice(0,80));}
  return bad;},
 ctxState(){const c=ctx;const t=c.getTransform();return JSON.stringify([+c.globalAlpha.toFixed(3),c.globalCompositeOperation,c.shadowBlur,c.filter,c.getLineDash().length,[t.a,t.b,t.c,t.d].map(v=>+v.toFixed(3))]);},
 black(){try{const w=cv.width,h=cv.height;const d=ctx.getImageData(0,0,w,h).data;let lit=0;for(let k=0;k<400;k++){const x=(Math.random()*w)|0,y=(Math.random()*h)|0,i=(y*w+x)*4;if(d[i]+d[i+1]+d[i+2]>12)lit++;}return lit;}catch(e){return -1;}},
 // универсальный бот миссии: босс/подбосс/глушитель/маяк/обычные волны; god — корпус не падает ниже половины
 mbot(o){o=Object.assign({maxSec:360,god:0,rN:0,charge:1},o||{});const p=G.player;let s=0,lk=-1,lt=0,emptyT=0,bad=[],deaths=0,chg=0;const st0=G.state;
  for(;s<60*o.maxSec;s++){
    if(G.state==='intro'){startMission();continue;}
    if(G.state==='levelup'){let n=0;while(G.state==='levelup'&&n++<10)choose(Math.random()*choices.length|0);continue;}
    if(G.state!=='play')break;
    if(o.god){if(p.hp<G.st.maxHp*.5){p.hp=G.st.maxHp*.5;deaths++;}if(G.bc)G.bc.hp=Math.max(G.bc.hp,G.bc.maxHp*.6);}
    const a=s/90;let tx=W/2,ty=H/2;const b=G.sb,bc=G.bc,tg=G.boss||G.jam;
    if(b&&b.sbk==='nurse'){const w=(b.wombs||[]).find(w=>w.alive);
      if(b.st==='final'&&b.docks){const d=b.docks[s%1200<600?0:b.docks.length-1];tx=d.x;ty=d.y;}
      else if(w&&b.phase===1){tx=w.x+(b.cx-w.x)*.35;ty=w.y+(b.cy-w.y)*.35;G.prio=w;}
      else{tx=b.cx+Math.cos(a)*b.R*.5;ty=b.cy+Math.sin(a)*b.R*.5;}}
    else if(b&&b.sbk==='flag'){if(b.st==='final'&&b.docks){const d=b.docks[s%1200<600?0:b.docks.length-1];tx=d.x;ty=d.y;}
      else{const ex=flRole(b,'engL')||flRole(b,'engR');if(ex)G.prio=ex;tx=b.x-Math.cos(b.ang)*230+Math.cos(a)*60;ty=b.y-Math.sin(b.ang)*230+Math.sin(a)*60;}}
    else if(b&&b.docks&&b.st==='final'){const d=b.docks[s%1200<600?0:b.docks.length-1];tx=d.x;ty=d.y;}
    else if(bc&&!G.jam){const cut=(G.relays||[]).find(r=>r.cut);if(cut&&(s%1200)<300){tx=(cut.x+bc.x)/2;ty=(cut.y+bc.y)/2;}else{tx=bc.x+Math.cos(a)*75;ty=bc.y+Math.sin(a)*75;}
      const cell=(G.pick||[]).find(k=>k.k==='cell'&&!(k.stab>0));if(cell&&p.cargo<G.st.cargo&&(s%600)<300){tx=cell.x;ty=cell.y;}}
    else if(tg){tx=tg.x+Math.cos(a)*170;ty=tg.y+Math.sin(a)*170;}
    else{let c=null,cd=1e9;for(const e of G.enemies){if(!e.alive||EDEF[e.type].passive||e.spawnT>0)continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<cd){cd=d;c=e;}}
      if(c){tx=c.x+Math.cos(a)*200;ty=c.y+Math.sin(a)*200;}else{tx=W/2+Math.cos(a)*160;ty=H/2+Math.sin(a)*160;}}
    {const X=G.x110;if(X&&X.k==='const'&&X.phase==='read'&&typeof next47==='function'){const q=next47(X);if(q){tx=q.x;ty=q.y;}}}
    if(s%200===0){const t=G.enemies.find(e=>targetable(e)&&['pylon','jam','leech','antenna','decoy','vent','membrane','absorber'].includes(e.type));if(t)G.prio=t;}
    tx=clamp(tx,30,W-30);ty=clamp(ty,30,H-30);steer2(tx,ty);
    if(o.charge){chg++;KEYS.KeyQ=(chg%240)<70;}
    if(s%170===0)tryDash();if(p.en>=100)tryPulse();
    update(1/60);
    if(G.kills!==lk){lk=G.kills;lt=s;}
    if(s%60===0){const al=G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive);
      if(s-lt>60*150&&al.length&&!bad.length&&G.state==='play')bad.push('stall150:'+al.slice(0,4).map(e=>e.type+(e.ghost?'g':'')+'@'+Math.round(e.x)+','+Math.round(e.y)+(targetable(e)?'':'!t')).join('|'));
      if(!al.length&&!(G.spawnQ&&G.spawnQ.length))emptyT+=60;else emptyT=0;
      if(emptyT>60*45&&!bad.length&&G.state==='play')bad.push('emptyStall:w'+G.waveIdx+'/'+(G.waves?G.waves.length:'?')+':sb='+(b?b.st:'-')+':bc='+(bc?Math.round(bc.charge||0):'-'));}
    if(s%120===0){const c=QA.inv(s%1200===0);if(c.length){for(const x of c)bad.push(x);break;}}
    if(o.rN&&s%o.rN===0){render(performance.now());if(G.mode==='endless')updateEndlessHUD();else updateHUD();}
    if(bad.length&&bad[0].startsWith('stall'))break;
  }
  for(const k of KK)KEYS[k]=false;KEYS.KeyQ=false;
  return {state:G.state,sec:Math.round(s/60),bad,deaths,m:G.m,kills:G.kills,lvl:G.lvl};},
};return 1;}"""
SEEDJS="(s)=>{Math.random=(function(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};})(s);return 1;}"

class Pg:
    def __init__(s,ctx,pg,errs):s.ctx=ctx;s.pg=pg;s.errs=errs
    async def js(s,code,arg=None):return await (s.pg.evaluate(code,arg) if arg is not None else s.pg.evaluate(code))
    async def prep(s):
        await s.pg.evaluate(LIB);await s.pg.evaluate(T_JS);await s.pg.evaluate(QA_JS)
async def page(b,vw=1280,vh=760,touch=False):
    ctx=await b.new_context(viewport={'width':vw,'height':vh},has_touch=touch,is_mobile=touch)
    pg=await ctx.new_page();errs=[]
    pg.on('pageerror',lambda e:errs.append('PAGE '+str(e)[:300]))
    pg.on('console',lambda m:(m.type=='error' and 'ERR_TUNNEL' not in m.text and 'Failed to load' not in m.text) and errs.append('CON '+m.text[:300]))
    await pg.goto(GAME);await pg.wait_for_timeout(150)
    await pg.evaluate("()=>localStorage.clear()");await pg.reload();await pg.wait_for_timeout(150)
    P=Pg(ctx,pg,errs);await P.prep();return P

# ————————————————— A. миссии 1–49
async def itA(b,j):
    P=await page(b);m,d,seed,god=j['m'],j['d'],j['seed'],j['god']
    await P.js(SEEDJS,seed)
    r0=await P.js("""(o)=>{T.fresh();T.openAll();const S=G.save;S.diff=o.d;S.lom=500;if(o.ars){S.ars=arsDef();S.ars.lv.gun={pow:o.ars,rate:o.ars};}G.layoutSeed=o.seed;
       enterNode(o.m,false);const brief=document.body.innerText;const bad=[];if(/undefined|NaN|\\[object/.test(brief))bad.push('badBrief');
       if(G.state!=='intro'&&G.state!=='play')bad.push('enterState:'+G.state);return {bad,st:G.state,lom:S.lom,cl:S.cleared};}""",{'m':m,'d':d,'seed':seed,'ars':j.get('ars',0)})
    bad=list(r0['bad'])
    r=await P.js("(o)=>QA.mbot(o)",{'maxSec':j['maxSec'],'god':god,'rN':j.get('rN',0)})
    bad+=r['bad']
    info={'end':r['state'],'sec':r['sec'],'deaths':r['deaths'],'kills':r['kills']}
    if god and r['state']=='play' and not r['bad']:bad.append('noWin%ds'%j['maxSec'])
    if r['state']=='done':
        r2=await P.js("""()=>{const S=G.save;const l0=S.lom,c0=S.carry,md=JSON.stringify(S.medals[G.m]||null);const bad=QA.inv(true);const b=$('#bNext');const out={l0,c0,md,vis:QA.vis().join()};
          if(!b||b.hidden||b.offsetParent===null){bad.push('noNextBtn');return {bad,out};}
          b.click();const s1=G.state,l1=S.lom,c1=S.carry;b.click();const l2=S.lom,c2=S.carry;out.s1=s1;out.l=[l0,l1,l2];out.c=[c0,c1,c2];
          if(l2>l1||c2>c1)bad.push('doubleReward:'+[l0,l1,l2]+'/'+[c0,c1,c2]);
          for(const x of QA.inv(true))bad.push('afterNext:'+x);if(!['world','report','levelup','cycle','intro','play','done','map'].includes(G.state))bad.push('afterNextState:'+G.state);return {bad,out,st:G.state};}""")
        bad+=r2['bad'];info['next']=r2.get('st')
        # пара секунд мира после возврата
        r3=await P.js("()=>{let n=0;while(G.state==='levelup'&&n++<10)choose(0);for(let i=0;i<180&&G.state==='world';i++){worldUpdate(1/60);if(i%30===0)renderWorld(performance.now());}return QA.inv(true);}")
        bad+=['world:'+x for x in r3]
    elif r['state']=='over':
        r2=await P.js("""(k)=>{const bad=QA.inv(true);const b=$(k);if(!b||b.hidden){return {bad,skip:1};}b.click();for(const x of QA.inv(true))bad.push('afterOver:'+x);
           if(G.state==='intro')startMission();for(let i=0;i<120&&(G.state==='play'||G.state==='world');i++){if(G.state==='play')update(1/60);else worldUpdate(1/60);}for(const x of QA.inv(true))bad.push('afterOver2:'+x);return {bad,st:G.state};}""",random.Random(seed).choice(['#bToWorld','#bRetry']))
        bad+=r2['bad'];info['next']=r2.get('st')
    return bad,info,P

# ————————————————— B. босс 50
async def itB(b,j):
    P=await page(b);await P.js(HELP74);await P.js(H120);await P.js(CH_SETUP)
    await P.js(SEEDJS,j['seed'])
    await P.js("(o)=>{T.zstart(o);return 1;}",{'diff':j['d'],'flags':{"cradle22":"keep","fleet27":"engine","line31":"write","well38":"answer"}})
    bad=[];info={}
    if j['kind']=='chaos':
        r=await P.js(CH_RUN.replace('__BOT__',CH_BOT1),{'n':j['n'],'ev':j['ev']})
        bad+=r['bad'];info={'k':r['k'],'stage':r['stage'],'st':r['st'],'ev':j['ev']}
        if r['err']:bad.append('ERR '+r['err'][:300])
        # после хаоса — снова общий оракул
        x=await P.js("()=>{if(G.state==='levelup'&&pickMode==='zbChoice')zbChoose(0);return QA.inv(true);}");bad+=x
    else:
        for chunk in range(j['chunks']):
            r=await P.js(ZBOT,{'maxSec':5,'floor':j['floor'],'render':j['rN'],'choice':'auto','human':j['human'],'nododge':0,'prof':j['prof']})
            if r['errs']:bad+=['ZERR '+e for e in r['errs'][:2]]
            x=await P.js("()=>{const a=CH120.inv();const b=(G.state==='world'||G.state==='levelup')?QA.inv(false):[];return a.concat(b);}")
            if x:bad+=x;break
            if r['done'] or r['state'] not in ('world','levelup'):break
            if P.errs:break
        info={'k':r['k'],'stage':r['stage'],'st':r['state'],'done':r['done'],'deaths':r['deaths'],'prof':j['prof'],'human':j['human']}
        x=await P.js("()=>QA.inv(true)");bad+=x
    return bad,info,P

# ————————————————— C. мир
WRUN=r"""(o)=>{T.fresh();T.openAll();const S=G.save;S.diff=o.d;S.lom=o.lom;computeStats();const p=G.player;
  const sec=WORLD.sectors[o.sec];const bx=sec.box;p.x=bx[0]+300+Math.random()*(bx[2]-bx[0]-600);p.y=bx[1]+300+Math.random()*(bx[3]-bx[1]-600);camSnap();
  const bad=[],evs=[];const evAt=o.ev.map(e=>({e,at:Math.random()*o.n|0}));let wp=null,err=null;
  const ev=(e)=>{evs.push(e);switch(e){
    case 'anom':{const a=WORLD.anomalies[Math.random()*WORLD.anomalies.length|0];if(a&&!G.anom){enterWorldAt(a.x-100,a.y);try{startAnom(a);}catch(x){bad.push('anomEXC:'+x.message);}}break;}
    case 'conv':if(typeof w58ConvStart==='function'&&window.W58&&W58.depot&&!G.anom){enterWorldAt(W58.depot.x,W58.depot.y);w58ConvStart();}break;
    case 'w58':if(typeof W58DEV==='function'&&G.w)W58DEV(['storm','tug','wander','pack'][Math.random()*4|0]);break;
    case 'map':openMap(Math.random()<.5?'map':'jr');mapZoom(.5+Math.random()*2);drawMap();closeMap();break;
    case 'jump':if(typeof alphaJump==='function'){openMap('map');drawMap();const L=['01','05','09','12','14','17','18','25','33','41','46','50'];alphaJump(L[Math.random()*L.length|0]);if(G.state==='map')closeMap();}break;
    case 'pause':pause();for(let i=0;i<5;i++)worldUpdate(1/60);resume();break;
    case 'death':{p.inv=0;p.dashT=0;p.shieldUp=false;G.dev.god=false;damagePlayer(99999);break;}
    case 'shop':{const s=WORLD.shops[Math.random()*WORLD.shops.length|0];if(s){enterWorldAt(s.x,s.y+100);openShop(s);const bs=[...document.querySelectorAll('#shopPerks button:not([disabled])')];if(bs.length)bs[Math.random()*bs.length|0].click();closeShop();}break;}
    case 'hangar':{const h=WORLD.hangar;enterWorldAt(h.x,h.y+100);openHangar();const b=document.querySelector('#skinGrid [data-buy]:not([disabled]),#skinGrid [data-pick]');if(b)b.click();closeHangar();break;}
    case 'arsenal':if(typeof arsOpen==='function'&&arsOpen()){openArsenal();const bs=[...document.querySelectorAll('#sArsenal button:not([disabled])')].filter(b=>!/bArsBack|Close/i.test(b.id));if(bs.length)bs[Math.random()*bs.length|0].click();if(G.state==='arsenal')closeArsenal();}break;
    case 'speed':G.dev.wspeed=[.5,2,4,8][Math.random()*4|0];break;
    case 'node':{const n=WORLD.nodes[Math.random()*49|0];enterWorldAt(n.x,n.y+90);break;}
    case 'tele':{const s2=WORLD.sectors[Math.random()*WORLD.sectors.length|0].box;p.x=s2[0]+200+Math.random()*(s2[2]-s2[0]-400);p.y=s2[1]+200+Math.random()*(s2[3]-s2[1]-400);camSnap();break;}
  }};
  let i=0;try{for(;i<o.n;i++){for(const q of evAt)if(q.at===i)ev(q.e);
    if(G.state==='levelup'){let n=0;while(G.state==='levelup'&&n++<10)choose(Math.random()*choices.length|0);}
    if(G.state==='intro'){startMission();}
    if(G.state==='play'){const r=QA.mbot({maxSec:40,god:1});for(const x of r.bad)bad.push('mis:'+x);if(G.state==='play'){missionComplete();}
      if(G.state==='done'){$('#bNext').click();}else if(G.state==='over'){$('#bToWorld').click();}let n=0;while(G.state==='levelup'&&n++<10)choose(0);}
    if(G.state==='report'){const b=$('#bRepGo');if(b)b.click();if(G.prologue)prologueEnd();}
    if(G.state!=='world'){const vis=QA.vis();if(G.state==='map')closeMap();else if(G.state==='pause')resume();else if(G.state==='shop')closeShop();else if(G.state==='hangar')closeHangar();else if(G.state==='arsenal')closeArsenal();
      if(G.state!=='world'){bad.push('stuckState:'+G.state+'/'+vis.join());break;}}
    if(o.god)p.hp=Math.max(p.hp,G.st.maxHp*.4);
    let c=null,cd=900;for(const e of G.enemies){if(!e.alive||e.spawnT>0)continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<cd){cd=d;c=e;}}
    if(c){const a=i/80;steer2(c.x+Math.cos(a)*220,c.y+Math.sin(a)*220);}
    else{if(!wp||Math.hypot(wp.x-p.x,wp.y-p.y)<80||i%900===0){const s2=WORLD.sectors[o.sec].box;wp={x:s2[0]+200+Math.random()*(s2[2]-s2[0]-400),y:s2[1]+200+Math.random()*(s2[3]-s2[1]-400)};}steer2(wp.x,wp.y);}
    if(i%170===0&&o.dash)tryDash();if(p.en>=100&&o.pulse)tryPulse();
    worldUpdate(1/60);
    if(i%10===0){renderWorld(performance.now());}if(i%30===0)updateWorldHUD();
    if(i%60===0){const b=QA.inv(i%600===0);if(b.length){for(const x of b)bad.push(x);break;}}}}
  catch(x){err=String(x.stack||x).slice(0,400);}
  for(const k of KK)KEYS[k]=false;G.dev.wspeed=1;
  return {bad,err,evs,frames:i,st:G.state,sec:o.sec};}"""
async def itC(b,j):
    P=await page(b);await P.js(SEEDJS,j['seed'])
    r=await P.js(WRUN,j)
    bad=list(r['bad'])
    if r['err']:bad.append('ERR '+r['err'])
    return bad,{'frames':r['frames'],'st':r['st'],'evs':r['evs']},P

# ————————————————— D. экраны и меню (fuzz200 + клики по видимым кнопкам)
CLICKVIS="""()=>{const vis=[...document.querySelectorAll('section.screen')].filter(e=>!e.hidden&&e.id!=='fsCard');if(!vis.length)return 'skip';
  const bs=[...vis[0].querySelectorAll('button,[data-v],[data-tab],.tab')].filter(b=>!b.disabled&&b.offsetParent!==null&&!/bSaveCopy|bSaveShare|bSavePaste|bFs/.test(b.id||''));if(!bs.length)return 'skip';const b=bs[Math.random()*bs.length|0];
  const id=(b.id||b.textContent||'').trim().slice(0,24);b.click();return 'c:'+vis[0].id+':'+id;}"""
DA=FZ_A+[('mouse',10,'MOUSE'),('clickVis',14,CLICKVIS),('clickVis2',8,CLICKVIS),('playBurst',6,"()=>{if(G.state==='play'){const r=QA.mbot({maxSec:8,god:1});return r.bad.join(';')||'p';}if(G.state==='world'){for(let i=0;i<240;i++){steer2(G.player.x+Math.cos(i/40)*300,G.player.y+Math.sin(i/40)*300);worldUpdate(1/60);}for(const k of KK)KEYS[k]=false;return 'w';}return 'skip';}")]
DW=[a[1] for a in DA]
async def itD(b,j):
    P=await page(b);await P.js(FZ_HELP)
    rnd=random.Random(j['seed'])
    await P.js("(c)=>{startWorld(true);if(G.prologue)prologueEnd();const S=G.save;S.cleared=c;S.lom=333;S.medals[1]={clear:1};saveWorld();REC.best=42;saveRec();toMenu();return 1;}",rnd.choice([1,4,7,10]))
    bad=[];log=[]
    for step in range(j['steps']):
        name,_,js=rnd.choices(DA,weights=DW)[0]
        try:
            if js=='WAIT':await P.pg.wait_for_timeout(600);r='w'
            elif js=='RELOAD':
                await P.pg.reload();await P.pg.wait_for_timeout(200);await P.prep();await P.js(FZ_HELP);r='r'
            elif js=='KEYS':
                for _ in range(4):await P.pg.keyboard.press(rnd.choice(FZ_KEYS));await P.pg.wait_for_timeout(20)
                r='k'
            elif js=='MOUSE':
                for _ in range(rnd.randint(1,4)):
                    x,y=rnd.uniform(0,1280),rnd.uniform(0,760)
                    if rnd.random()<.2:await P.pg.mouse.wheel(0,rnd.choice([-300,300]))
                    await P.pg.mouse.click(x,y,button=rnd.choice(['left','left','left','right']));await P.pg.wait_for_timeout(40)
                r='mouse'
            else:
                await P.js(SEEDJS,j['seed']*1000+step)
                r=await P.js(js)
                if name=='sandboxExitEsc' and r!='skip':await P.pg.keyboard.press('Escape')
            await P.pg.wait_for_timeout(15)
            st=await P.js("()=>[G.state,F.inv(),QA.inv(true)]")
        except Exception as e:
            bad.append('EXC@%d:%s %s'%(step,name,str(e)[:200]));break
        log.append('%s:%s%s'%(name,st[0],(':'+str(r)) if isinstance(r,str) and r.startswith('c:') else ''))
        v=([] if st[1]=='ok' else ['F:'+st[1]])+st[2]
        if v:bad+=['@%d %s: %s'%(step,name,x) for x in v];break
        if P.errs:break
    return bad,{'log':log[-12:]},P

# ————————————————— E. сохранения
GENSAVE=r"""(o)=>{T.fresh();const S=G.save;S.cleared=o.cl;S.lom=o.lom;S.carry=o.carry;S.gate=o.cl>=10;S.diff=o.d;
  for(let m=1;m<=50;m++){if(m<=o.cl||Math.random()<.3)S.medals[m]={clear:1,...(Math.random()<.5?{fast:1}:{}),...(Math.random()<.3?{clean:1}:{})};}
  for(const k in PERKS){if(Math.random()<.6)S.perks[k]=Math.floor(Math.random()*(PERKS[k].max+1));}
  S.ownSkins=['base',...Object.keys(SKINS).filter(k=>k!=='base'&&Math.random()<.4)];S.skin=S.ownSkins[Math.random()*S.ownSkins.length|0];
  S.pilot={lvl:1+(Math.random()*20|0),xp:Math.random()*50|0};if(S.ars){for(const k in S.ars.lv||{}){if(Math.random()<.5)S.ars.lv[k]={pow:Math.random()*4|0,rate:Math.random()*4|0};}}
  G.player.x=WORLD.nodes[Math.random()*49|0].x;G.player.y=WORLD.nodes[0].y+120;saveWorld();toMenu();openSaveScreen();const code=$('#saveOut').value;return {code,raw:localStorage.getItem('void_world')};}"""
LOADCODE=r"""(code)=>{toMenu();openSaveScreen();$('#saveIn').value=code;$('#bSaveLoad').click();const msg=$('#saveMsg').textContent;return {msg,raw:localStorage.getItem('void_world'),st:G.state,bad:QA.inv(true)};}"""
PLAYSAVE=r"""(o)=>{const bad=[];let err=null;try{toMenu();startWorld(false);if(G.prologue)prologueEnd();const S=G.save;const keep=JSON.stringify([S.cleared,S.lom,S.perks,Object.keys(S.medals).length,S.ownSkins,S.pilot&&S.pilot.lvl]);
   for(let i=0;i<60*o.sec;i++){if(G.state==='levelup')choose(0);if(G.state!=='world')break;steer2(G.player.x+Math.cos(i/50)*400,G.player.y+Math.sin(i/50)*400);if(i%170===0)tryDash();worldUpdate(1/60);if(i%10===0)renderWorld(performance.now());if(i%30===0)updateWorldHUD();if(i%60===0){const b=QA.inv(i%600===0);if(b.length){bad.push(...b);break;}}}
   for(const k of KK)KEYS[k]=false;
   for(const f of [()=>{openMap('map');drawMap();closeMap();},()=>{openMap('jr');drawMap();closeMap();},()=>{openShop(WORLD.shops[0]);closeShop();},()=>{openHangar();drawHangarPreviews(performance.now());closeHangar();},()=>{toMenu();renderMenu();openCodex('menu');for(const t of document.querySelectorAll('#cxTabs .tab'))t.click();closeCodex();startWorld(false);if(G.prologue)prologueEnd();}]){f();const b=QA.inv(true);if(b.length){bad.push(...b);break;}}
   if(o.mis&&G.state==='world'){T.openAll();T.go(1+(Math.random()*12|0));const r=QA.mbot({maxSec:15,god:1});bad.push(...r.bad);}
   return {bad,err,keep,st:G.state};}catch(x){err=String(x.stack||x).slice(0,400);return {bad,err};}}"""
def mutate(rnd,S):
    S=copy.deepcopy(S)
    # случайный путь в дереве
    path=[];cur=S
    for _ in range(rnd.randint(1,4)):
        if isinstance(cur,dict) and cur:
            k=rnd.choice(list(cur.keys()));path.append(k)
            if isinstance(cur[k],(dict,list)) and cur[k] and rnd.random()<.6:cur=cur[k];continue
            break
        elif isinstance(cur,list) and cur:
            k=rnd.randrange(len(cur));path.append(k)
            if isinstance(cur[k],(dict,list)) and cur[k] and rnd.random()<.6:cur=cur[k];continue
            break
        else:break
    if not path:return S,'none'
    tgt=S
    for k in path[:-1]:tgt=tgt[k]
    k=path[-1]
    vals=[None,-5,-1e9,1e308,'x','<img src=x onerror=alert(1)>',[],{},True,0,'NaN',3.7,'1e999',[1,2,3],{'a':{'b':1}},'']
    op=rnd.random()
    if op<.15 and isinstance(tgt,dict):del tgt[k];what='del'
    else:
        v=rnd.choice(vals);tgt[k]=v;what=json.dumps(v)[:30]
    return S,'/'.join(map(str,path))+'='+what
def enc(S):return base64.b64encode(json.dumps(S,ensure_ascii=False).encode('utf8')).decode()
async def itE(b,j):
    P=await page(b);rnd=random.Random(j['seed']);await P.js(SEEDJS,j['seed'])
    bad=[];info={}
    g=await P.js(GENSAVE,{'cl':rnd.choice([0,1,5,9,10,10,10]),'lom':rnd.choice([0,10,999,123456]),'carry':rnd.choice([0,5,77]),'d':rnd.choice(['easy','mid','hard'])})
    code=g['code']
    if not code:bad.append('noExportCode');return bad,info,P
    S=json.loads(base64.b64decode(code).decode('utf8'))
    if j['kind']=='round':
        # честный круг: очистить хранилище → перезагрузка → вставить код → игра на нём
        await P.js("()=>{localStorage.clear();return 1;}");await P.pg.reload();await P.pg.wait_for_timeout(150);await P.prep()
        l=await P.js(LOADCODE,code)
        if 'загружен' not in l['msg'].lower():bad.append('roundRejected:'+l['msg'][:60])
        if l['raw']!=g['raw']:
            a=json.loads(g['raw']);c=json.loads(l['raw'] or 'null')
            diff=[k for k in set(list(a.keys())+list((c or {}).keys())) if json.dumps(a.get(k),sort_keys=True)!=json.dumps((c or {}).get(k),sort_keys=True)]
            bad.append('roundDiff:'+','.join(sorted(diff))[:120])
        bad+=l['bad']
        r=await P.js(PLAYSAVE,{'sec':j['sec'],'mis':j['mis']})
        bad+=r['bad']
        if r.get('err'):bad.append('ERR '+r['err'])
        if r.get('keep'):
            k=json.loads(r['keep']);exp=[S['cleared'],S['lom'],S.get('perks'),len(S['medals']),S.get('ownSkins'),(S.get('pilot') or {}).get('lvl')]
            if k[0]!=exp[0] or k[1]!=exp[1] or json.dumps(k[2],sort_keys=True)!=json.dumps(exp[2],sort_keys=True) or k[3]!=exp[3]:
                bad.append('progressChanged:'+json.dumps(k)[:120]+' vs '+json.dumps(exp)[:120])
        # перезагрузка страницы на этом сохранении
        await P.pg.reload();await P.pg.wait_for_timeout(150);await P.prep()
        x=await P.js("()=>{toMenu();startWorld(false);if(G.prologue)prologueEnd();for(let i=0;i<60;i++)worldUpdate(1/60);renderWorld(performance.now());return QA.inv(true);}");bad+=['reload:'+v for v in x]
        info={'cl':S['cleared'],'lom':S['lom']}
    else:
        M,what=mutate(rnd,S)
        if rnd.random()<.15:
            # битый код целиком
            c2=rnd.choice([code[:len(code)//2],code+'@@','',' '*5,'e30=',base64.b64encode(b'[]').decode(),base64.b64encode(b'null').decode(),'%%%'])
            what='rawcode:'+c2[:12]
        else:c2=enc(M)
        l=await P.js(LOADCODE,c2)
        bad+=['load:'+v for v in l['bad']]
        r=await P.js(PLAYSAVE,{'sec':j['sec'],'mis':j['mis']})
        bad+=r['bad']
        if r.get('err'):bad.append('ERR '+r['err'])
        await P.pg.reload();await P.pg.wait_for_timeout(150);await P.prep()
        x=await P.js("()=>{const b=QA.inv(true);try{toMenu();startWorld(false);if(G.prologue)prologueEnd();for(let i=0;i<120;i++)worldUpdate(1/60);renderWorld(performance.now());updateWorldHUD();openMap('map');drawMap();closeMap();}catch(e){b.push('ERR '+String(e.stack||e).slice(0,300));}return b.concat(QA.inv(true));}");bad+=['reload:'+v for v in x]
        info={'mut':what,'msg':l['msg'][:50]}
    return bad,info,P

# ————————————————— F. телефон
async def itF(b,j):
    vw,vh=(390,844) if j['orient']=='p' else (844,390)
    P=await page(b,vw,vh,touch=True);await P.js(SEEDJS,j['seed'])
    bad=[];info={'what':j['what'],'orient':j['orient']}
    if j['what']=='mission':
        await P.js("(o)=>{T.fresh();T.openAll();G.save.diff=o.d;G.layoutSeed=o.seed;enterNode(o.m,false);return 1;}",{'m':j['m'],'d':j['d'],'seed':j['seed']})
        r=await P.js("(o)=>QA.mbot(o)",{'maxSec':20,'god':1,'rN':3});bad+=r['bad']
        await P.pg.set_viewport_size({'width':vh,'height':vw});await P.pg.wait_for_timeout(120)
        r=await P.js("(o)=>QA.mbot(o)",{'maxSec':20,'god':1,'rN':3});bad+=['rot:'+x for x in r['bad']]
        # пауза тапом по кнопке паузы, если видна
        x=await P.js("()=>{const b=document.querySelector('#bPause,#pauseBtn,[data-act=pause]');if(!b||b.offsetParent===null)return null;const r=b.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2];}")
        if x:
            await P.pg.touchscreen.tap(x[0],x[1]);await P.pg.wait_for_timeout(80)
            y=await P.js("()=>[G.state,QA.inv(true)]");bad+=y[1]
            if y[0]!='pause' and y[0]=='play':bad.append('pauseTapNoop')
    elif j['what']=='world':
        r=await P.js(WRUN,{'sec':j['sec'],'d':j['d'],'lom':500,'n':1800,'ev':j['ev'],'god':1,'dash':1,'pulse':1})
        bad+=r['bad']
        if r['err']:bad.append('ERR '+r['err'])
        await P.pg.set_viewport_size({'width':vh,'height':vw});await P.pg.wait_for_timeout(120)
        x=await P.js("()=>{for(let i=0;i<120;i++){worldUpdate(1/60);if(i%5===0)renderWorld(performance.now());}updateWorldHUD();return QA.inv(true);}");bad+=['rot:'+v for v in x]
    elif j['what']=='boss':
        await P.js(HELP74);await P.js(H120);await P.js(CH_SETUP)
        await P.js("(o)=>{T.zstart(o);return 1;}",{'diff':j['d'],'flags':{"cradle22":"keep","fleet27":"engine","line31":"write","well38":"answer"}})
        for c in range(6):
            r=await P.js(ZBOT,{'maxSec':5,'floor':60,'render':3,'choice':'auto','human':1,'nododge':0,'prof':''})
            if r['errs']:bad+=['ZERR '+e for e in r['errs'][:2]]
            if c==2:await P.pg.set_viewport_size({'width':vh,'height':vw});await P.pg.wait_for_timeout(120)
            x=await P.js("()=>CH120.inv().concat(G.state==='world'?QA.inv(false):[])")
            if x:bad+=x;break
            if r['state'] not in ('world','levelup'):break
    else: # screens: каждый экран → кнопки в пределах окна (или экран прокручивается)
        x=await P.js(SCREENS_TOUCH)
        bad+=x['bad'];info['n']=x['n']
    return bad,info,P
SCREENS_JS=r"""const SCR=[
  ['menu',()=>{toMenu();renderMenu();}],
  ['codex',()=>{toMenu();openCodex('menu');}],['codex2',()=>{toMenu();openCodex('menu');const t=document.querySelectorAll('#cxTabs .tab');t[t.length-1].click();}],
  ['intro',()=>{T.fresh();T.openAll();enterNode(1+(Math.random()*49|0),false);}],
  ['levelup',()=>{T.fresh();T.openAll();T.go(3);for(let i=0;i<30;i++)update(1/60);openLevelUp();}],
  ['done',()=>{T.fresh();T.openAll();T.go(2);missionComplete();}],
  ['over',()=>{T.fresh();T.openAll();T.go(2);const p=G.player;G.dev.god=false;let n=0;while(G.state==='play'&&n++<400){p.inv=0;p.dashT=0;p.shieldUp=false;damagePlayer(9999);update(1/60);}}],
  ['pause',()=>{T.fresh();T.openAll();T.go(4);pause();}],['pauseW',()=>{T.fresh();pause();}],
  ['map',()=>{T.fresh();T.openAll();openMap('map');drawMap();}],['journal',()=>{T.fresh();openMap('jr');drawMap();}],
  ['shop',()=>{T.fresh();T.openAll();G.save.lom=5000;openShop(WORLD.shops[0]);}],
  ['hangar',()=>{T.fresh();T.openAll();openHangar();drawHangarPreviews(performance.now());}],
  ['arsenal',()=>{T.fresh();T.openAll();G.save.cleared=10;if(typeof arsOpen==='function'&&arsOpen())openArsenal();}],
  ['report',()=>{T.fresh();T.openAll();openReport();}],
  ['cycle',()=>{T.fresh();T.openAll();G.save.cleared=CORE;openCycle();}],
  ['settings',()=>{toMenu();openSettings('menu');}],['settingsP',()=>{T.fresh();pause();openSettings('pause');}],
  ['dev',()=>{toMenu();openDev();}],['save',()=>{T.fresh();toMenu();openSaveScreen();}],
];"""
SCREENS_TOUCH=r"""()=>{"""+SCREENS_JS+r"""const bad=[];let n=0;const VW=innerWidth,VH=innerHeight;
  for(const [nm,f] of SCR){try{f();}catch(e){bad.push(nm+':EXC '+String(e).slice(0,120));continue;}n++;
    for(const x of QA.inv(true))bad.push(nm+':'+x);
    const vis=[...document.querySelectorAll('section.screen')].filter(e=>!e.hidden&&e.id!=='fsCard');
    for(const s of vis){const scroll=s.scrollHeight>s.clientHeight+2||getComputedStyle(s).overflowY==='auto'||getComputedStyle(s).overflowY==='scroll';
      for(const b of s.querySelectorAll('button')){if(b.offsetParent===null||b.disabled)continue;const r=b.getBoundingClientRect();if(r.width<2)continue;
        let anc=b.parentElement,sc=false;while(anc&&anc!==document.body){const cs=getComputedStyle(anc);if((cs.overflowY==='auto'||cs.overflowY==='scroll'||cs.overflowX==='auto'||cs.overflowX==='scroll'))sc=true;anc=anc.parentElement;}
        if(!scroll&&!sc&&(r.right<4||r.left>VW-4||r.bottom<4||r.top>VH-4)){bad.push(nm+':btnOff:'+(b.id||b.textContent.trim().slice(0,16))+'@'+[r.left|0,r.top|0]);break;}
        if(r.left<-2||r.right>VW+2){if(!sc){bad.push(nm+':btnCut:'+(b.id||b.textContent.trim().slice(0,16))+'@'+[r.left|0,r.right|0]);break;}}}}}
  try{toMenu();}catch(e){}
  return {bad,n};}"""
# ————————————————— G. отрисовка
async def itG(b,j):
    vw,vh={'pc':(1280,760),'p':(390,844),'l':(844,390)}[j['vp']]
    P=await page(b,vw,vh,touch=j['vp']!='pc');await P.js(SEEDJS,j['seed'])
    if j['scene'] in ('boss',):
        await P.js(HELP74);await P.js(H120);await P.js(CH_SETUP)
    x=await P.js(RENDER_JS,{'scene':j['scene'],'k':j['k']})
    bad=x['bad']
    shot=None
    if bad and j.get('shots'):
        shot=os.path.join(j['out'],'G_%s_%s_%s.png'%(j['scene'],j['vp'],j['seed']));await P.pg.screenshot(path=shot)
    return bad,{'lit':x.get('lit'),'n':x.get('n'),'shot':shot},P
RENDER_JS=r"""(o)=>{"""+SCREENS_JS+r"""const bad=[];let lit=null,n=0;
  const chk=(nm,fr)=>{fr();const a=QA.ctxState();fr();n++;const z=QA.ctxState();/* установившийся режим: два кадра подряд кончаются одинаково (иначе состояние копится) */if(a!==z)bad.push(nm+':ctxLeak:'+a+'→'+z);for(const x of QA.inv(true))bad.push(nm+':'+x);};
  try{
  if(o.scene==='screens'){for(const [nm,f] of SCR){try{f();}catch(e){bad.push(nm+':EXC '+String(e).slice(0,160));continue;}
      chk(nm,()=>{if(G.state==='world'||G.world)renderWorld(performance.now());else render(performance.now());});}}
  else if(o.scene==='world'){T.fresh();T.openAll();const secs=WORLD.sectors;for(let s=0;s<secs.length;s++){const bx=secs[s].box;G.player.x=(bx[0]+bx[2])/2;G.player.y=(bx[1]+bx[3])/2;camSnap();
      for(let i=0;i<40;i++)worldUpdate(1/60);chk('sec'+s,()=>{renderWorld(performance.now());updateWorldHUD();});const L=QA.black();if(L===0)bad.push('sec'+s+':blackFrame');lit=L;}}
  else if(o.scene==='missions'){T.fresh();T.openAll();for(let m=1+o.k*5;m<=Math.min(49,5+o.k*5);m++){T.go(m);for(let i=0;i<240&&G.state==='play';i++){G.player.hp=Math.max(G.player.hp,50);update(1/60);}if(G.state!=='play')continue;
      chk('m'+m,()=>{render(performance.now());updateHUD();});const L=QA.black();if(L===0)bad.push('m'+m+':blackFrame');lit=L;toMenu();T.fresh();T.openAll();}}
  else if(o.scene==='boss'){T.zstart({diff:'mid',flags:{cradle22:'keep',fleet27:'engine',line31:'write',well38:'answer'}});const Z=G.zb;
      for(let st=0;st<5;st++){for(let i=0;i<300&&G.state==='world';i++){G.player.hp=Math.max(G.player.hp,60);if(G.state==='levelup')choose(0);worldUpdate(1/60);}
        chk('zb'+(G.zb?G.zb.k+G.zb.stage:'none'),()=>{renderWorld(performance.now());updateWorldHUD();});if(G.zb&&G.zb.k==='fight'){G.zb.hp=Math.max(1,G.zb.hp-G.zb.segMax*.5);}}}
  else if(o.scene==='fx'){T.fresh();T.openAll();T.go(1+(o.k%49));SET.fx=o.k%2===0;SET.lessFx=o.k%3===0;for(let i=0;i<600&&G.state==='play';i++){G.player.hp=Math.max(G.player.hp,50);if(i%100===0)tryPulse();update(1/60);if(i%20===0)chk('fx'+i,()=>{render(performance.now());});}}
  }catch(e){bad.push('EXC '+String(e.stack||e).slice(0,300));}
  return {bad,lit,n};}"""

# ————————————————— H. строгие оракулы экранов: мёртвые кнопки и текст за краем окна
BTN_JS=r"""(o)=>{"""+SCREENS_JS+r"""const bad=[];const ent=SCR.find(x=>x[0]===o.scr);if(!ent)return {bad:['noScreen'],n:0};const f=ent[1];
  const sig=()=>{const v=QA.vis();const sc=v.length?document.getElementById(v[0]).innerHTML.length+':'+document.getElementById(v[0]).innerText.slice(0,4000):'';
    return JSON.stringify([G.state,v.join(),sc,localStorage.getItem('void_world')&&localStorage.getItem('void_world').length,JSON.stringify(SET),document.activeElement&&document.activeElement.id,G.mode,!!G.player,document.body.className,location.hash,(G.save&&G.save.lom),document.querySelectorAll('[hidden]').length,document.querySelectorAll('.on,.sel,.active,[aria-pressed=true],[aria-selected=true]').length,JSON.stringify(G.dev||null),JSON.stringify(G.mapView||null),String(G.devStep),String(G.devCyc),$('#devGrid')?$('#devGrid').innerText.length:0]);};
  try{f();}catch(e){return {bad:['openEXC '+String(e).slice(0,120)],n:0};}
  const VW=innerWidth,VH=innerHeight;
  // текст за краем окна (горизонтально) — когда экран не прокручивается вбок
  for(const s of QA.vis().map(id=>document.getElementById(id))){if(s.scrollWidth>s.clientWidth+2&&getComputedStyle(s).overflowX!=='hidden')bad.push('hScroll:'+s.id+':'+s.scrollWidth+'>'+s.clientWidth);
    for(const e of s.querySelectorAll('h1,h2,h3,h4,p,button,li,dt,dd,.eyebrow,span,b,div')){if(e.offsetParent===null||!e.textContent.trim()||e.children.length>3)continue;const r=e.getBoundingClientRect();if(r.width<2)continue;
      let anc=e.parentElement,sc=false;while(anc&&anc!==document.body){const cs=getComputedStyle(anc);if(cs.overflowX==='auto'||cs.overflowX==='scroll'||cs.overflowX==='hidden')sc=true;anc=anc.parentElement;}
      if(!sc&&(r.right>VW+1.5||r.left<-1.5)){bad.push('textOff:'+s.id+':'+(e.id||e.tagName)+':'+e.textContent.trim().slice(0,20)+'@'+[r.left|0,r.right|0]);break;}}}
  const list=()=>{const v=QA.vis();if(!v.length)return [];return [...document.getElementById(v[0]).querySelectorAll('button')].filter(b=>b.offsetParent!==null&&!b.disabled&&!/bSaveCopy|bSaveShare|bSavePaste|bFs|fs/i.test(b.id||''));};
  const B0=list().map((b,i)=>({i,id:b.id,t:b.textContent.trim().slice(0,24),ds:JSON.stringify(b.dataset)}));let n=0;
  for(const d of B0){try{toMenu();}catch(e){}try{f();}catch(e){continue;}const L=list();const b=L.find(x=>x.id&&x.id===d.id)||L[d.i];if(!b)continue;
    G.scrAt=-1e9;/* как живой игрок: защита от случайного касания (TAPGUARD) уже истекла */const s0=sig();let err=null;try{b.click();}catch(e){err=String(e).slice(0,120);}n++;
    if(err){bad.push('clickEXC:'+o.scr+':'+(d.id||d.t)+':'+err);continue;}
    const s1=sig();const active=b.classList.contains('on')||b.classList.contains('sel')||b.getAttribute('aria-pressed')==='true'||b.getAttribute('aria-selected')==='true';const atMin=/^dev[A-Za-z]*M$/.test(d.id||'');/* «−» на минимуме */if(s0===s1&&!active&&!atMin)bad.push('btnNoop:'+o.scr+':'+(d.id||d.t)+':'+d.ds);
    for(const x of QA.inv(true))bad.push('afterClick:'+o.scr+':'+(d.id||d.t)+':'+x);}
  try{toMenu();}catch(e){}
  return {bad,n,btns:B0.length};}"""
async def itH(b,j):
    vw,vh={'pc':(1280,760),'p':(390,844),'l':(844,390),'se':(320,568),'sel':(568,320),'hd':(1920,1080),'s360':(360,640)}[j['vp']]
    P=await page(b,vw,vh,touch=j['vp'] not in ('pc','hd'));await P.js(SEEDJS,j['seed'])
    x=await P.js(BTN_JS,{'scr':j['scr']})
    return x['bad'],{'n':x.get('n'),'btns':x.get('btns')},P

# ————————————————— план работ
def plan(seed0=1):
    R=random.Random(seed0);J=[]
    # A: 49 миссий × 3 сложности × 2 зерна = 294 + 6 с арсеналом
    for m in range(1,50):
        for d in ['easy','mid','hard']:
            for k in range(2):
                sd=R.randint(1,10**6);J.append({'dir':'A','m':m,'d':d,'seed':sd,'god':1 if (k==0) else 0,'maxSec':360 if k==0 else 240,'rN':0 if R.random()<.8 else 7})
    for i in range(6):J.append({'dir':'A','m':R.randint(1,49),'d':R.choice(['easy','mid','hard']),'seed':R.randint(1,10**6),'god':1,'maxSec':360,'ars':3,'rN':0})
    # B: 100 хаос + 100 ботов
    for i in range(100):J.append({'dir':'B','kind':'chaos','d':R.choice(['easy','mid','hard']),'seed':R.randint(1,10**6),'n':R.randint(900,3000),'ev':R.sample(CH_EVS,R.randint(2,6))})
    for i in range(100):J.append({'dir':'B','kind':'bot','d':R.choice(['easy','mid','hard']),'seed':R.randint(1,10**6),'chunks':R.choice([12,24,36]),'prof':R.choice(['','','still','nodash','naive','hug','circle','charge']),'human':R.choice([0,1,1]),'floor':R.choice([0,0,60]),'rN':R.choice([0,0,10])})
    # C: 150 мир
    WEV=['anom','conv','w58','map','jump','pause','death','shop','hangar','arsenal','speed','node','tele']
    for i in range(150):J.append({'dir':'C','seed':R.randint(1,10**6),'sec':i%12,'d':R.choice(['easy','mid','hard']),'lom':R.choice([0,500,9999]),'n':R.choice([1800,3600,5400]),'ev':R.sample(WEV,R.randint(1,5)),'god':R.random()<.7,'dash':R.random()<.8,'pulse':R.random()<.8})
    # D: 200 экранных цепочек
    for i in range(200):J.append({'dir':'D','seed':R.randint(1,10**6),'steps':R.choice([40,60,80])})
    # E: 60 честных кругов + 140 порч
    for i in range(60):J.append({'dir':'E','kind':'round','seed':R.randint(1,10**6),'sec':R.choice([5,15,30]),'mis':R.random()<.4})
    for i in range(140):J.append({'dir':'E','kind':'mut','seed':R.randint(1,10**6),'sec':R.choice([5,10,20]),'mis':R.random()<.3})
    # F: 80 телефон
    WEV2=['map','pause','jump','node','anom','death']
    for i in range(80):
        w=['mission','mission','world','boss','screens'][i%5]
        J.append({'dir':'F','what':w,'orient':R.choice(['p','l']),'seed':R.randint(1,10**6),'m':R.randint(1,49),'d':R.choice(['easy','mid','hard']),'sec':R.randrange(12),'ev':R.sample(WEV2,2)})
    # G: 60 отрисовка
    for vp in ['pc','p','l']:
        for i in range(20):
            sc=['screens','screens','world','missions','missions','boss','fx'][i%7]
            J.append({'dir':'G','vp':vp,'scene':sc,'k':i%10,'seed':R.randint(1,10**6),'shots':1})
    SCRN=['menu','codex','codex2','intro','levelup','done','over','pause','pauseW','map','journal','shop','hangar','arsenal','report','cycle','settings','settingsP','dev','save']
    for vp in (['pc','p','l'] if not os.environ.get('HVP') else os.environ['HVP'].split(',')):
        for sc in SCRN:J.append({'dir':'H','vp':vp,'scr':sc,'seed':R.randint(1,10**6)})
    for i,j in enumerate(J):j['it']=i
    return J
FN={'A':itA,'B':itB,'C':itC,'D':itD,'E':itE,'F':itF,'G':itG,'H':itH}
async def main():
    out=sys.argv[1];w=int(sys.argv[2]);nw=int(sys.argv[3]);dirs=sys.argv[4] if len(sys.argv)>4 else 'ABCDEFG';lim=int(sys.argv[5]) if len(sys.argv)>5 else 10**9
    seed0=int(os.environ.get('PLANSEED','1'))
    os.makedirs(out,exist_ok=True)
    J=[j for j in plan(seed0) if j['dir'] in dirs]
    if os.environ.get('ONLY'):ids=set(int(x) for x in os.environ['ONLY'].split(','));J=[j for j in J if j['it'] in ids]
    # пилот: первые LIMIT каждого направления
    if lim<10**9:
        cnt={};K=[]
        for j in J:
            if cnt.get(j['dir'],0)<lim:K.append(j);cnt[j['dir']]=cnt.get(j['dir'],0)+1
        J=K
    J=[j for i,j in enumerate(J) if i%nw==w]
    done=set()
    fp=os.path.join(out,'find_%d.jsonl'%w)
    if os.path.exists(fp):
        for l in open(fp):
            try:done.add(json.loads(l)['it'])
            except Exception:pass
    f=open(fp,'a')
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox','--disable-gpu'])
        k=0
        for j in J:
            if j['it'] in done:continue
            j['out']=out
            t0=time.time();P=None
            try:
                bad,info,P=await asyncio.wait_for(FN[j['dir']](b,j),timeout=int(os.environ.get('TMO','420')))
                errs=P.errs[:4] if P else []
            except Exception as e:
                bad,info,errs=['HARNESS '+type(e).__name__+': '+str(e)[:300]],{},[]
            rec={'it':j['it'],'dir':j['dir'],'job':{k2:v for k2,v in j.items() if k2 not in ('out',)},'bad':bad[:12],'errs':errs,'info':info,'s':round(time.time()-t0,1)}
            f.write(json.dumps(rec,ensure_ascii=False)+'\n');f.flush()
            flag='BUG' if (bad or errs) else 'ok '
            print('%s %s#%d %.1fs %s %s'%(flag,j['dir'],j['it'],rec['s'],json.dumps(bad[:3],ensure_ascii=False)[:300],json.dumps(errs[:2],ensure_ascii=False)[:300]),flush=True)
            for c in list(b.contexts):
                try:await c.close()
                except Exception:pass
            k+=1
            if k%60==0:
                await b.close();b=await p.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox','--disable-gpu'])
        await b.close()
    print('WORKER_DONE',w,flush=True)
if __name__=='__main__':asyncio.run(main())
