# 1.2.4 α · масштаб интерфейса
import sys,re
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m37 FAIL count',n,'!=',cnt,'for',a[:100]);sys.exit(1)
    s=s.replace(a,b)
R("@media (min-width:1680px) and (min-height:1000px){html:not(.mob) .screen:not(#sMap)>*:not(.hero),html:not(.mob) #cfm .box{zoom:1.25}}","")
R("@media (min-width:2400px) and (min-height:1300px){html:not(.mob) .screen:not(#sMap)>*:not(.hero),html:not(.mob) #cfm .box{zoom:1.5}}","")
R("${segHTML('zoom')}${segHTML('textScale')}","${segHTML('zoom')}${G.ff==='desk'?segHTML('uiSize'):''}${segHTML('textScale')}")
# --- переопределения vw/vh внутри масштабированных элементов (zoom умножает и vw/vh) ---
css=''.join(re.findall(r'<style[^>]*>(.*?)</style>',s,re.S))
SKIP=('html,','body','#cv','#touch','.hero','#wake','#fsCurtain','#fsCard','#devPanel','#devBar','#devBtn','.ff-phone','.ff-tab','.mob','#safeProbe')
U=re.compile(r'(-?\d*\.?\d+)(vw|vh|dvh|svh|lvh|vmin|vmax)\b')
out=[]
def walk(text,media):
    i=0
    while i<len(text):
        j=text.find('{',i)
        if j<0:break
        head=text[i:j].strip()
        # найти парную }
        d=1;k=j+1
        while k<len(text) and d:
            if text[k]=='{':d+=1
            elif text[k]=='}':d-=1
            k+=1
        body=text[j+1:k-1]
        head=re.sub(r'/\*.*?\*/','',head,flags=re.S).strip()
        if head.startswith('@media'):walk(body,head)
        elif head.startswith('@'):pass
        else:
            props=[p for p in body.split(';') if U.search(p) and ':' in p]
            sels=[x.strip() for x in head.split(',') if x.strip()]
            sels=[x for x in sels if not any(x.startswith(sk) or sk in x for sk in SKIP) and x not in ('html','body')]
            if props and sels:
                ns=[]
                for x in sels:
                    if x.startswith('html:not(.mob)'):ns.append('html.uiz'+x[len('html'):])
                    elif x.startswith('html'):continue
                    else:ns.append('html.uiz '+x)
                if ns:
                    pb=';'.join(U.sub(lambda m:'calc(%s%s / var(--ui))'%(m.group(1),m.group(2)),p.strip()) for p in props)
                    rule=','.join(ns)+'{'+pb+'}'
                    out.append(media+'{'+rule+'}' if media else rule)
        i=k
walk(css,'')
CSS=""":root{--ui:1;--stage-m:0px;--stage-px:0px}
html.uiz .screen>*:not(.hero),html.uiz #cfm .box,html.uiz #hud,html.uiz #toast,html.uiz #radio,html.uiz #fragTxt,html.uiz #memo,html.uiz #wcard,html.uiz #banner{zoom:var(--ui)}
html.uiz #hud{left:var(--stage-m);right:var(--stage-m)}
html.uiz #radio{left:calc(var(--stage-m) + 16px)}
html.uiz #toast{margin-left:var(--stage-m)}
html.uiz.ultra #sMenu .hero{right:calc(var(--stage-px) + max(3vw,24px))}
html.uiz.ultra .screen{padding-left:var(--stage-px);padding-right:var(--stage-px)}
"""+'\n'.join(out)+"\n"
i=s.rindex('</style>');s=s[:i]+CSS+s[i:]
R("const cx=CW/2,cy=CH/2,a=Math.atan2(Y-cy,X-cx),m=46,ex=clamp(cx+Math.cos(a)*CW,m,CW-m),ey=clamp(cy+Math.sin(a)*CH,m+170,CH-m-80);",
  "const cx=CW/2,cy=CH/2,a=Math.atan2(Y-cy,X-cx),m=46*UI,sl=stageL(),ex=clamp(cx+Math.cos(a)*CW,sl+m,CW-sl-m),ey=clamp(cy+Math.sin(a)*CH,m+170*UI,CH-m-80*UI);")
R("ctx.save();ctx.translate(ex,ey);ctx.rotate(a);ctx.fillStyle=col;ctx.globalAlpha=.85+.15*Math.sin(t*5);","ctx.save();ctx.translate(ex,ey);ctx.rotate(a);ctx.scale(UI,UI);ctx.fillStyle=col;ctx.globalAlpha=.85+.15*Math.sin(t*5);")
R("ctx.globalAlpha=1;ctx.font='700 10px \"JetBrains Mono\",monospace';ctx.textAlign='center';ctx.fillStyle=col;const dd=fmtAU(Math.hypot(x-p.x,y-p.y));","ctx.globalAlpha=1;ctx.font='700 '+(10*UI)+'px \"JetBrains Mono\",monospace';ctx.textAlign='center';ctx.fillStyle=col;const dd=fmtAU(Math.hypot(x-p.x,y-p.y));")
R("ctx.fillText(label+' · '+dd,clamp(ex-Math.cos(a)*34,70,CW-70),ey-Math.sin(a)*22+4);};","ctx.fillText(label+' · '+dd,clamp(ex-Math.cos(a)*34*UI,stageL()+70*UI,CW-stageL()-70*UI),ey-(Math.sin(a)*22-4)*UI);};")
js=open('@@KIT@@/m37.js',encoding='utf8').read()
i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m37 ok',len(out),'vw/vh overrides')
