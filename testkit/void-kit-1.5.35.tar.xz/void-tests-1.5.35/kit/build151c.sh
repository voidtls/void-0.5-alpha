set -e
cd @@KIT@@
mkdir -p @@KIT@@/home/.stage151c
ST=@@KIT@@/home/.stage151c/void.html
cp void_0510final.html $ST
for m in m1 m2 m3 m4 m5 m6 m7 m8 m9 m10 m11 m12 m13 m14 m15 m16 m17 m18 m19 m20 m21 m22 m23 m24 m25 m26 m27 m28 m29 m30 m31 m32 m33 m34 m35 m36 m37 m38 m39 m40 m41 m42 m43 m44 m45 m46 m48 m49 m55 m56 m57 m58 m59 m60 m61 m62 m63 m64 m65 m66 m67 m68 m69 m70 m71 m99; do
  python3 -c "import sys;src=open('$m.py',encoding='utf8').read();assert \"P='@@KIT@@/home/void.html'\" in src;import os;exec(compile(src.replace(\"P='@@KIT@@/home/void.html'\",\"P='$ST'\"),'$m.py','exec'),{'__file__':os.path.abspath('$m.py'),'__name__':'__main__'})"
done
python3 - <<'PY'
s=open('@@KIT@@/home/.stage151c/void.html',encoding='utf8').read()
i=s.index('<script>');j=s.index('</script>',i)
open('@@KIT@@/g151c.js','w').write(s[i+8:j])
PY
node --check g151c.js
mv -f $ST @@KIT@@/home/void_b151c.html
echo BUILD_OK
