# 1.5.1 α «Кадр» (CINE·PROTO): кинематографичные миссии 01–04. C01–C14.
import asyncio,json,sys,os,re
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
W8="const w8=ms=>new Promise(r=>setTimeout(r,ms));"
# кадр без реального времени: шаг симуляции 1/60 + отрисовка + режиссёр с подставленным dt (как в frame)
FR=("const fr=(n,cine)=>{for(let i=0;i<n;i++){if(G.state==='levelup'){let k=0;while(G.state==='levelup'&&k++<10)choose(0);}if(G.state!=='play')break;"
    "update(1/60);if(cine){render(performance.now());secVignette();C66.last=performance.now()-1000/60;drawDevOverlay();}}};")
BOT=("const pilot=(s)=>{const p=G.player;p.hp=Math.max(p.hp,G.st.maxHp*.6);const a=s/150;let tx=W/2+Math.cos(a)*W*.28,ty=H/2+Math.sin(a)*H*.28;const S=G.s1;"
     "if(S&&S.buoys&&S.buoys.length){const b=S.buoys.find(b=>!b.ever);if(b&&s%900<500){tx=b.x;ty=b.y;}}steer2(tx,ty);if(s%140===0)tryDash();if(p.en>=100)tryPulse();};")
PREP=lambda m:("{T.fresh();G.save.tut.off=1;const S=G.save;S.cleared=Math.max(S.cleared,%d-1);for(let k=1;k<%d;k++)S.medals[k]={clear:1};saveWorld();}"%(m,m))
CINE='window.__cine66=true;'

async def cpage(b,w=1280,h=760,touch=False,cine=True):
    return await newpage(b,w,h,alpha=True,touch=touch,init=CINE if cine else None)

@test('C01')
async def c01(b):
    P=await cpage(b)
    code=("async()=>{"+W8+FR+BOT+"const run=(mode)=>{SET.cine=mode;"+PREP(2)+"Math.random=mulberry(4242);G.layoutSeed=99;G.keepLayout=true;enterNode(2);if(G.state==='intro')startMission();"
          "for(let s=0;s<60*45&&(G.state==='play'||G.state==='levelup');s++){if(G.state==='play')pilot(s);fr(1,true);}const p=G.player;"
          "const o={st:G.state,t:+G.mT.toFixed(3),k:G.kills,tk:Math.round(G.taken),x:Math.round(p.x),y:Math.round(p.y),w:G.waveIdx,e:G.enemies.filter(e=>e.alive).map(e=>e.type+Math.round(e.x)).join(','),rnd:Math.random()};"
          "const log=C66.log.map(x=>x.k).join(',');Math.random=Math.random;return [o,log];};"
          "const full=run('full');toMenu();await w8(100);const off=run('off');return {same:JSON.stringify(full[0])===JSON.stringify(off[0]),full:full[0],off:off[0],beats:full[1]}}")
    r=await P.js(code)
    rec('C01 бой не меняется: 45 с миссии 02 с одним сидом — с кино «полное» (кадры, приёмы, режиссёр) и «выкл» — один итог до последнего врага и следующего случайного числа',r['same'] and 'echo' in r['beats'],r)

@test('C02')
async def c02(b):
    P=await cpage(b)
    out={}
    for m in (1,2,3,4):
        r=await P.js("async()=>{"+W8+FR+BOT+"SET.cine='full';"+PREP(m)+"enterNode(%d);if(G.state==='intro')startMission();let s=0;for(;s<60*240&&(G.state==='play'||G.state==='levelup');s++){if(G.state==='play')pilot(s);fr(1,true);}"
                     "const M=C66.M;return {st:G.state,sec:Math.round(s/60),ni:M?+M.ni.toFixed(2):null,cap:M?+c66NIcap(M).toFixed(2):null,slow:M?+M.slow.toFixed(2):null,beats:C66.log.map(x=>x.k).join(',')}}"%m)
        out[m]=r;await P.js("()=>{toMenu();}")
    ok=all(v['st']=='done' and v['ni'] is not None and v['ni']<=v['cap'] and v['slow']<=1.2 for v in out.values())
    rec('C02 бюджет: каждая из миссий 01–04 пройдена ботом с кино; неинтерактив ≤ 8 % миссии, замедление в бою ≤ 1,2 с',ok,out)

@test('C03')
async def c03(b):
    P=await cpage(b)
    r=await P.js("async()=>{"+W8+FR+"const res={};for(const mode of ['off','calm','full']){SET.cine=mode;"+PREP(3)+"enterNode(3);startMission();fr(30,true);const M=C66.M;G.slow95=null;G.hs90=null;"
                 "if(M){M.slow=0;c66Slow(.5,.35);}res[mode]={M:!!M,slow:!!G.slow95,dom:!!C66.dom&&!C66.dom.el.hidden};toMenu();await w8(50);}"
                 "SET.cine='full';SET.fx=false;"+PREP(4)+"enterNode(4);startMission();fr(30,true);res.fxOff={fx:c66Fx(),loud:c66Loud(),M:!!C66.M};SET.fx=true;SET.lessFx=true;res.less={fx:c66Fx(),loud:c66Loud()};SET.lessFx=false;return res}")
    ok=r['off']['M'] is False and r['off']['dom'] is False and r['calm']['M'] and not r['calm']['slow'] and r['full']['M'] and r['full']['slow'] and r['fxOff']['fx'] is False and r['fxOff']['M'] and r['less']['fx'] and not r['less']['loud']
    rec('C03 настройки: «выкл» — режиссёра нет; «тихое» — без замедления; «полное» — с ним; «Эффекты: выкл» — без света и цвета, «меньше» — без вспышек и призрака',ok,r)

@test('C04')
async def c04(b):
    P=await cpage(b)
    r=await P.js("async()=>{"+W8+FR+"SET.cine='full';"+PREP(2)+"G.save.tut.off=0;enterNode(2);startMission();fr(2,true);const M=C66.M;M.ttl=null;fr(1,true);TUT.blk=null;const blk0=tutBlockers().length;M.ttl={at:0,short:false};TUT.cur={k:'dash',L:{fight:true},t:0};"
                 "fr(30,true);const waitT=!(M.ttl&&M.ttl.on);TUT.cur=null;fr(4,true);const on=!!(M.ttl&&M.ttl.on);const gap=TUT.gap;"
                 "M.card=null;M.ttl=null;const ty='gunner';delete c66Store().c[ty];M.warnSeen={};TUT.cur={k:'dash',L:{fight:true},t:0};G.warns.push({type:ty,x:20,y:200,mx:20,my:200,t:.5});fr(1,true);const cardBusy=!!M.card;"
                 "TUT.cur=null;fr(1,true);const cardFree=!!M.card;G.warns=[];"
                 "TUT.blk=null;const blk=tutBlockers().length;const blk2=tutBlockers().length;const blk3=tutBlockers().length;"
                 "return {waitT,on,gap:+gap.toFixed(2),cardBusy,cardFree,blk0,blk,blk2,blk3}}")
    ok=r['waitT'] and r['on'] and r['gap']>=2 and not r['cardBusy'] and r['cardFree'] and r['blk']>r['blk0'] and r['blk3']==r['blk2']==r['blk']
    rec('C04 одна очередь с обучением: при уроке на экране титр и табличка ждут; титр держит паузу урокам; титр и табличка — препятствия для подсказки (кэш не растёт)',ok,r)

@test('C05')
async def c05(b):
    P=await cpage(b)
    r=await P.js("async()=>{"+W8+FR+BOT+"SET.cine='full';"+PREP(1)+"enterNode(1);startMission();fr(3,true);const a={first:C66.M.first,full:C66.M.full,lids:C66.bar>.1,boot:!!document.querySelector('#hud .c66off')};toMenu();await w8(50);"
                 ""+PREP(1)+"G.save.cine66={i:{1:1},d:{1:1},c:{},lc:0};enterNode(1);startMission();fr(3,true);const M=C66.M;const b={first:M.first,full:M.full,bar:C66.bar,boot:!!document.querySelector('#hud .c66off')};"
                 "C66.lk={x:300,y:300,at:performance.now()};c66KillCam(M);fr(20,true);b.kcBars=C66.barT;b.slowK=G.slow95?G.slow95.k:null;"
                 "C66.M.ttl={at:C66.M.t,short:false};C66.M.ttl.on=1;C66.M.ttl.t=.6;const d=c66Dom();d.ttl.className='ttl66 on';c66Skip();fr(2,true);b.skip=C66.M.ttl?C66.M.ttl.out===1:true;return {a,b}}")
    ok=r['a']['first'] and r['a']['lids'] and r['a']['boot'] and not r['b']['first'] and not r['b']['full'] and r['b']['bar']==0 and not r['b']['boot'] and r['b']['kcBars']==0 and r['b']['skip']
    rec('C05 повтор: первый показ — веки и загрузка систем; после победы — без них, финальный удар без полос; титр гасится Esc/Enter',ok,r)

@test('C06')
async def c06(b):
    P=await cpage(b,cine=False)
    r=await P.js("async()=>{"+W8+"T.fresh();enterNode(1);startMission();await w8(1500);return {M:!!C66.M,hidden:!C66.dom||C66.dom.el.hidden,boot:!!document.querySelector('#hud .c66off'),cine:G.save.cine66||null,name:$('#inName').textContent,bot:c66Bot()}}")
    ok=r['bot'] and not r['M'] and r['hidden'] and not r['boot'] and r['cine'] is None
    rec('C06 под автотестом (navigator.webdriver) кино выключено само: нет режиссёра, оверлея и записей в сохранение',ok,r)

@test('C07')
async def c07(b):
    P=await cpage(b)
    r=await P.js("async()=>{"+W8+FR+"SET.cine='full';"+PREP(1)+"enterNode(1);startMission();fr(20,true);const n0=document.querySelectorAll('#hud .c66off').length;const pause=getComputedStyle($('#btnPause')).opacity;"
                 "G.taken+=5;fr(2,true);const hull=!$('#hud .hud-tl').classList.contains('c66off');fr(60*15,true);const n1=document.querySelectorAll('#hud .c66off').length;"
                 "toMenu();await w8(50);"+PREP(1)+"enterNode(1);startMission();fr(5,true);c66Play('boot');fr(3,true);const n2=document.querySelectorAll('#hud .c66off').length;toMenu();fr(1,true);await w8(50);const n3=document.querySelectorAll('#hud .c66off,#hud.c66boot').length;"
                 "return {n0,pause,hull,n1,n2,n3}}")
    ok=r['n0']>=3 and r['pause']=='1' and r['hull'] and r['n1']==0 and r['n2']>=3 and r['n3']==0
    rec('C07 загрузка систем (01): интерфейс прячется, кнопка паузы — нет; корпус зажигается на первом ударе; к 14 с включено всё; выход из миссии возвращает всё',ok,r)

@test('C08')
async def c08(b):
    P=await cpage(b)
    r=await P.js("async()=>{"+BOT+"SET.cine='off';SET.radio=true;"+PREP(1)+"enterNode(1);startMission();const said=[];const _rs=radioSay;radioSay=function(g,i){said.push(g+(i+1)+'@'+G.waveIdx+'@'+Math.round(G.mT));return _rs.apply(this,arguments);};"
                 "let s=0;for(;s<60*200&&G.state==='play';s++){pilot(s);update(1/60);if(G.state==='levelup'){let k=0;while(G.state==='levelup'&&k++<10)choose(0);}}radioSay=_rs;const a={said:said.slice(),st:G.state};"
                 "toMenu();SET.radio=false;"+PREP(1)+"enterNode(1);startMission();said.length=0;const _r2=radioSay;radioSay=function(g,i){said.push(g+(i+1));return _r2.apply(this,arguments);};for(s=0;s<60*200&&G.state==='play';s++){pilot(s);update(1/60);if(G.state==='levelup'){let k=0;while(G.state==='levelup'&&k++<10)choose(0);}}radioSay=_r2;SET.radio=true;"
                 "return {a,off:said.slice()}}")
    ok=r['a']['said'][:1]==[r['a']['said'][0]] and len(r['a']['said'])>=1 and r['a']['said'][0].startswith('А1@4') and len(r['a']['said'])<=2 and r['off']==[]
    rec('C08 радио Стража в 01 — по событию: первая реплика «Объект в секторе» ровно в паузе после волны 3 (не по таймеру), не больше двух за миссию; радио выкл — ни одной',ok,r)

@test('C09')
async def c09(b):
    P=await cpage(b)
    r=await P.js("async()=>{"+W8+FR+BOT+"SET.cine='full';SET.radio=true;"+PREP(4)+"enterNode(4);startMission();let s=0;for(;s<60*260&&(G.state==='play'||G.state==='levelup');s++){if(G.state==='play')pilot(s);fr(1,true);}const st=G.state;"
                 "await w8(2200);const lc=document.querySelector('#sDone .lcut66 span');const typed=lc?lc.textContent:null;const beats=C66.log.map(x=>x.k).join(',');returnToWorld();await w8(150);const cur=G.radio&&G.radio.cur;"
                 "return {st,typed,beats,txt:cur?cur.txt:null,t:cur?+cur.t.toFixed(2):null,mc:!!C66.world,lc:G.save.cine66.lc}}")
    ok=r['st']=='done' and r['typed'] and r['typed'].startswith('Он стреляет') and r['txt']=='Он стреляет первым. Как всегда.' and r['t']>=.5 and r['mc'] and r['lc']==1 and 'shadow' in r['beats'] and 'killcam' in r['beats']
    rec('C09 04: тень гиганта и финальный удар; L-cut — голос Стража начинается на экране итога и договаривает в секторе; склейка в мир — кольцо узла',ok,r)

@test('C10')
async def c10(b):
    P=await cpage(b)
    r=await P.js("async()=>{"+W8+"openSettings();await w8(100);tabGo63('scr');await w8(50);const row=document.querySelector('[data-n63=\"cine\"]');const vis=row&&!row.closest('.tab63').hidden;const n=row?row.querySelectorAll('[data-cine66]').length:0;"
                 "row.querySelector('[data-cine66=\"calm\"]').click();await w8(50);const a=SET.cine;const on=document.querySelector('[data-cine66=\"calm\"]').classList.contains('on');const st=JSON.parse(localStorage.getItem('void_settings')).cine;"
                 "document.querySelector('[data-cine66=\"full\"]').click();return {vis,n,a,on,st,def:SET_DEF.cine}}")
    ok=r['vis'] and r['n']==3 and r['a']=='calm' and r['on'] and r['st']=='calm' and r['def']=='full'
    rec('C10 настройка «КИНО: ПОЛНОЕ / ТИХОЕ / ВЫКЛ» во вкладке «ЭКРАН», сохраняется; по умолчанию — полное',ok,r)

@test('C11')
async def c11(b):
    P=await cpage(b,1280,760)
    r=await P.js("async()=>{"+W8+FR+BOT+"SET.cine='full';"+PREP(4)+"enterNode(4);startMission();for(let s=0;s<200;s++){pilot(s);fr(1,true);}c66ShadowStart(C66.M);C66.M.shadow.T=99;C66.M.search={t:.3,T:99};c66Ring(300,300,200,'#fff',1);"
                 "for(let s=0;s<150;s++){pilot(s);update(1/60);render(performance.now());C66.last=performance.now()-16.7;drawDevOverlay();}"
                 "const bt=(n,f)=>{const v=[];for(let k=0;k<5;k++){const t0=performance.now();for(let i=0;i<n;i++)f(k*n+i);v.push((performance.now()-t0)/n);}v.sort((a,b)=>a-b);return v[2];};"
                 "const sh=C66.M.shadow,se=C66.M.search;if(sh){sh.T=99;}if(se){se.T=99;}"
                 "const tick=bt(30,i=>{C66.last=performance.now()-16.7;c66Tick(1/60);c66Top();});const lay=bt(30,i=>{c66Under(i/60);c66Mid(i/60);});return {tick:+tick.toFixed(3),lay:+lay.toFixed(3),avg:+C66.stat.ms.toFixed(3)}}")
    ok=r['tick']+r['lay']<.3
    rec('C11 скорость: режиссёр и все слои в самом тяжёлом кадре (тень, прожектор, огни мин, кольца) — меньше 0,3 мс на кадр',ok,r)

@test('C12')
async def c12(b):
    res={}
    for (w,h) in ((844,390),(390,844)):
        P=await cpage(b,w,h,touch=True)
        r=await P.js("async()=>{"+W8+FR+"SET.cine='full';"+PREP(1)+"enterNode(1);startMission();fr(80,true);const bar=C66.bar,mx=c66BarMax();const M=C66.M;M.ttl={at:M.t,short:false};fr(60,true);"
                     "const t=c66Dom().ttl.getBoundingClientRect(),p=G.player,[px,py]=c66Css(p.x,p.y);const over=px>t.left-20&&px<t.right+20&&py>t.top-20&&py<t.bottom+20;return {bar:+bar.toFixed(3),mx,over,t:[Math.round(t.left),Math.round(t.top),Math.round(t.right),Math.round(t.bottom)],vw:innerWidth,ship:[Math.round(px),Math.round(py)]}}")
        res[f'{w}x{h}']=r;await P.pg.screenshot(path=SP+f'c66/C12_{w}x{h}.png')
    ok=all(not v['over'] and v['t'][2]<=v['vw'] and v['mx']<=.05 for v in res.values()) and res['844x390']['mx']<=.035
    rec('C12 телефон: полосы ≤ 3,5 % в альбомной и ≤ 5 % в портретной; титр не закрывает корабль и не вылезает за экран',ok,res)

@test('C13')
async def c13(b):
    P=await cpage(b)
    r=await P.js("()=>({ver:VER_TAG,tag:$('#verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.5.10 α</dt>')&&document.documentElement.outerHTML.includes('<dt>1.5.9 α</dt>')&&document.documentElement.outerHTML.includes('<dt>1.5.1 α</dt>')})")
    rec('C13 версия 1.5.10 α и записи 1.5.10 / 1.5.9 / 1.5.1 в журнале',r['ver']=='1.5.10 α' and r['tag']=='1.5.10 α' and r['log'],r)

@test('C14')
async def c14(b):
    s=open('@@KIT@@/home/void.html',encoding='utf8').read()
    a=s.find('/* ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ CINE·PROTO');z=s.find('▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲ CINE·PROTO');z=s.find('*/',z)+2
    ca=s.find('/* ▼▼▼ CINE·PROTO');cz=s.find('КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА (CSS) ▲▲▲ */')+len('КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА (CSS) ▲▲▲ */')
    ok0=a>0 and z>a and ca>0 and cz>ca
    cut=s[:a]+s[z:];cut=cut[:ca]+cut[cz:] if ca<a else None
    if cut is None:cut=s[:ca]+s[cz:a]+s[z:]
    rest=len(re.findall(r'\bC66\.|\bc66[A-Z]\w*\(|#c66\b|\.c66|data-cine66',cut))
    open('@@KIT@@/home/void_cut66.html','w',encoding='utf8').write(cut)
    P=await newpage(b,1280,760,url='file://@@KIT@@/home/void_cut66.html',alpha=True,init=CINE)
    r=await P.js("async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();enterNode(1);startMission();await w8(1500);const k=T.bot({maxSec:30});return {C66:typeof C66,st:G.state,k:k.state}}")
    ok=ok0 and rest==0 and r['C66']=='undefined' and r['st'] in ('play','done') and not P.errs
    rec('C14 вырезаемость: блок CINE·PROTO отмечен в JS и CSS; без него не остаётся ни одного c66, игра грузится и миссия 01 идёт без ошибок',ok,{'marks':ok0,'rest':rest,**r,'errs':P.errs[:3]})

@test('C15')
async def c15(b):
    P=await newpage(b,1280,800,alpha=False,init='window.__devUI=true;'+CINE)
    r=await P.js("async()=>{"+W8+"toMenu();openDev();await w8(150);DEVW.enter();await w8(400);$('#toast').hidden=true;SET.cine='full';dvGoNode(4,true);await w8(80);startMission();await w8(400);"
                 "dvxOpen(true);await w8(80);document.querySelector('#dvx [data-a=tab][data-v=fight]').click();await w8(60);const grp=[...document.querySelectorAll('#dvx .g65 h4')].map(h=>h.textContent).filter(t=>/КИНО/.test(t));"
                 "const btns=document.querySelectorAll('#dvx [data-a=c66play]').length;document.querySelector('#dvx [data-a=c66play][data-v=shadow]').click();await w8(120);const sh=!!(C66.M&&C66.M.shadow);"
                 "document.querySelector('#dvx [data-a=c66mode][data-v=calm]').click();await w8(30);const calm=SET.cine;document.querySelector('#dvx [data-a=c66mode][data-v=full]').click();"
                 "document.querySelector('#dvx [data-a=c66reset]').click();const live=(document.querySelector('#dvx [data-live=c66]')||{}).textContent||'';dvLeave();return {grp,btns,sh,calm,live,errs:(window.__fzErr||[]).length}}")
    ok=len(r['grp'])==1 and r['btns']>=12 and r['sh'] and r['calm']=='calm' and '04' in r['live']
    rec('C15 Верстак: во вкладке «БОЙ» — группа «КИНО · 1.5.0»: режим, «▶» на каждый приём (тень гиганта играет сразу), «забыть уже видел», живая строка бюджета',ok,r)

@test('C16')
async def c16(b):
    P=await cpage(b)
    r=await P.js("async()=>{"+W8+FR+"SET.cine='full';"+PREP(2)+"enterNode(2);await w8(60);const nm=$('#inName').textContent,lab=!!document.querySelector('#sIntro .ch66');await w8(900);const note=($('#inHint .note')||{}).textContent||'';"
                 "startMission();for(let i=0;i<200&&!(C66.M&&C66.M.ttl&&C66.M.ttl.on);i++)fr(1,true);const d=c66Dom();const b0=d.ttl.querySelector('b').textContent;fr(2,true);const b1=d.ttl.querySelector('b').textContent;"
                 "const all=(d.el.textContent||'')+($('#sIntro').textContent||'');return {nm,lab,note:note.length,b0,b1,glava:/ГЛАВА/.test(all),want:mTitle(MISSIONS[1]).toUpperCase()}}")
    ok=r['nm']==r['want'].capitalize() or r['nm'].upper()==r['want']
    ok=ok and not r['lab'] and r['b0']==r['want'] and r['b1']==r['want'] and not r['glava'] and 0<r['note']
    rec('C16 заголовки без печати и без «ГЛАВА»: название на брифинге сразу целиком, титр в миссии — название миссии целиком с первого кадра; печатается только примечание БОРТА',ok,r)

@test('C17')
async def c17(b):
    P=await cpage(b)
    r=await P.js("async()=>{"+W8+FR+"SET.cine='full';SET.fx=true;SET.amb=true;"+PREP(1)+"audioInit();enterNode(1);startMission();fr(70,true);const z=cv.style.transform,f=cv.style.filter;"
                 "C66.aerr=null;const v0=C66.vox;for(const k of ['open','title','sub','impact','shadow','search','whooshIn','chime','whiz'])c66Sting(k,1,300);const v1=C66.vox;"
                 "fr(260,true);const z2=cv.style.transform;C66.lk={x:500,y:300,at:performance.now()};c66KillCam(C66.M);fr(12,true);const zk=cv.style.transform;"
                 "toMenu();await w8(50);return {z,f,z2,zk,zEnd:cv.style.transform,fEnd:cv.style.filter,snd:v1-v0,err:C66.aerr,ctx:!!AU.ctx}}")
    sc=lambda t:float(t[6:-1]) if t and t.startswith('scale(') else 1.0
    ok=sc(r['z'])>1.05 and 'blur' in (r['f'] or '') and sc(r['z2'])==1.0 and sc(r['zk'])>1.03 and r['zEnd']=='' and r['fEnd']=='' and (not r['ctx'] or (r['snd']>=20 and not r['err']))
    rec('C17 камера и звук: 01 открывается наездом в расфокусе и отъезжает к обычному кадру; финальный удар — наезд; выход из миссии всё сбрасывает; кино-звуки собираются без ошибок',ok,r)

if __name__=='__main__':
    sel=sys.argv[1:]
    if sel:TESTS=[t for t in TESTS if t[0] in sel]
    asyncio.run(run(TESTS,'q340'))
