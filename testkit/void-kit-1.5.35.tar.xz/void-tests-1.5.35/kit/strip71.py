# Обратное преобразование m71: кандидат 1.5.11 минус блок ARCH·71 и все места vR/vrnd → должен получиться 1.5.10 байт в байт.
# python3 strip71.py <кандидат.html> [эталон.html]   (M71_GROUPS — как при сборке)
import sys,os,hashlib
D='@@KIT@@/';sys.path.insert(0,D)
import m71_pairs as M
def strip71(s):
    J=open(D+'m71_journal1511.txt',encoding='utf8').read().strip()
    G=set(int(x) for x in os.environ.get('M71_GROUPS','1,2,3,4,5').split(','))
    P=M.pairs(J)[:5]+[(t[2],M.new(t)) for t in M.SITES if t[0] in G]
    for old,new in reversed(P):
        if s.count(new)!=1:raise ValueError('strip71: место не найдено ровно один раз: '+new[:70])
        s=s.replace(new,old)
    return s
if __name__=='__main__':
    t=strip71(open(sys.argv[1],encoding='utf8').read());ref=sys.argv[2] if len(sys.argv)>2 else D+'void_v48.html'
    b=open(ref,encoding='utf8').read()
    left=[k for k in ['ARCH·71','arch71','VR71_','vR1(','vrnd1(','vR2(','vrnd2(','vR3(','vrnd3(','vR4(','vrnd4(','vR5(','vrnd5(','1.5.11'] if k in t]
    print('равно 1.5.10:',t==b,'sha:',hashlib.sha256(t.encode()).hexdigest()[:16],'остатки:',left)
