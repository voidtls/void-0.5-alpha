# 1.5.8 α «Тише» — PERF·OPT: оптимизации без изменения поведения (блок в начале скрипта + точечные места с флагами)
import sys,os
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
OFF=set((os.environ.get('M68_SKIP') or '').split(','))
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m68 FAIL',n,a[:80]);sys.exit(1)
    s=s.replace(a,b)
R('<div class="ver" id="verTag">1.5.7 α</div>','<div class="ver" id="verTag">1.5.8 α</div>')
R("const VER_TAG='1.5.7 α';","const VER_TAG='1.5.8 α';")
J158=open(D+'m68_journal158.txt',encoding='utf8').read().strip()
R('<dl class="kv"><dt>1.5.7 α</dt>','<dl class="kv"><dt>1.5.8 α</dt><dd>'+J158+'</dd><dt>1.5.7 α</dt>')
# блок PERF·OPT — первым в главном скрипте: флаги и функции нужны с первой строки
js=open(D+'m68.js',encoding='utf8').read()
R('<script>\n"use strict";\n','<script>\n"use strict";\n'+js+'\n')
# O-6 · форматирование чисел (HUD, магазин, итоги)
if 'O-6' not in OFF:
  R("const fmt=n=>Math.round(n).toLocaleString('ru-RU');","const fmt=n=>ru68(Math.round(n));/* PERF·OPT O-6 */")
  R("const fmtN=n=>typeof n==='number'?Math.round(n).toLocaleString('ru-RU'):n;","const fmtN=n=>typeof n==='number'?ru68(Math.round(n)):n;/* PERF·OPT O-6 */")
# O-3 · updateEnemies: щитоносцы, командиры, разведение
if 'O-3' not in OFF:
  old="const c=G.enemies.filter(o=>o.alive&&o!==s&&o.type!=='shielder'&&!HEAVY.has(o.type)&&o.type!=='moth'&&Math.hypot(o.x-s.x,o.y-s.y)<240).sort((a,b)=>Math.hypot(a.x-s.x,a.y-s.y)-Math.hypot(b.x-s.x,b.y-s.y)).slice(0,3);"
  R(old,"const c=PERF.off['O-3']?"+old[8:-1]+":o3Near(s);/* PERF·OPT O-3 */")
  old="for(const o of G.enemies)if(o!==c&&o.alive&&!HEAVY.has(o.type)&&Math.hypot(o.x-c.x,o.y-c.y)<220)o.buff=1.25;"
  R(old,"{const f3=!PERF.off['O-3'],cx=c.x,cy=c.y;for(const o of G.enemies){if(f3){const dx=o.x-cx,dy=o.y-cy;if(dx>=220||dx<=-220||dy>=220||dy<=-220)continue;}if(o!==c&&o.alive&&!HEAVY.has(o.type)&&Math.hypot(o.x-c.x,o.y-c.y)<220)o.buff=1.25;}}/* PERF·OPT O-3 */")
  old=("  for(let i=0;i<es.length;i++){const a=es[i];if(!sep(a))continue;\n"
       "    for(let j=i+1;j<es.length;j++){const b=es[j];if(!sep(b))continue;\n"
       "      const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy),m=a.r+b.r+2;if(d>0&&d<m){const k=(m-d)/d*.5;a.x-=dx*k;a.y-=dy*k;b.x+=dx*k;b.y+=dy*k;}}}\n")
  R(old,"  if(!PERF.off['O-3'])o3Sep(es,sep);else{/* PERF·OPT O-3: старый путь */\n"+old+"  }\n")
# O-4 (updateFx) и O-2 (быстрее «Разлом» карты) сделаны, проверены и сняты: замер не показал выигрыша (см. журнал PERF·OPT)
open(P,'w',encoding='utf8').write(s);print('m68 ok')
