set -e
cd @@KIT@@
bash build151.sh >/dev/null
python3 mapply.py @@KIT@@/home/void_b151.html @@KIT@@/home/void_b155.html 72 73 74 75
node --check @@KIT@@/home/void_b155.html.js && echo BUILD_OK
