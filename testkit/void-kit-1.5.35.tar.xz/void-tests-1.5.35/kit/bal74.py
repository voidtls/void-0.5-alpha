import asyncio,json,sys,os
from h import *
BOT74="""(o)=>{o=Object.assign({maxSec:600,floor:40,diff:'easy'},o||{});G.save.diff=o.diff;
  let s=0,deaths=0,ph=[],chg=0;
  for(;s<60*o.maxSec&&(G.state==='play'||G.state==='levelup'||G.state==='intro');s++){
    if(G.state==='intro'){startMission();continue;}
    if(G.state==='levelup'){let n=0;while(G.state==='levelup'&&n++<10)choose(Math.random()*choices.length|0);continue;}
    const p=G.player;if(o.floor&&p.hp<o.floor){p.hp=o.floor;deaths++;}
    const b=G.sb;let tx=W/2,ty=H/2;const a=s/90;
    if(b&&b.sbk==='nurse'){const w=(b.wombs||[]).find(w=>w.alive);
      if(b.st==='final'&&b.docks){const d=b.docks.find(d=>d.kind===(o.choice||'cut'));tx=d.x;ty=d.y;}
      else if(w&&b.phase===1){tx=w.x+(b.cx-w.x)*.35;ty=w.y+(b.cy-w.y)*.35;G.prio=w;}
      else{tx=b.cx+Math.cos(a)*b.R*.5;ty=b.cy+Math.sin(a)*b.R*.5;}}
    else if(b&&b.sbk==='flag'){if(b.st==='final'&&b.docks){const d=b.docks.find(d=>d.kind===(o.choice||'engine'));tx=d.x;ty=d.y;}
      else{const ex=flRole(b,'engL')||flRole(b,'engR');if(ex&&o.eng!==false)G.prio=ex;tx=b.x-Math.cos(b.ang)*230+Math.cos(a)*60;ty=b.y-Math.sin(b.ang)*230+Math.sin(a)*60;}}
    else{const es=G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive&&e.spawnT<=0);let c=null,cd=1e9;for(const e of es){const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<cd){cd=d;c=e;}}
      if(c){tx=c.x+Math.cos(a)*220;ty=c.y+Math.sin(a)*220;}else{tx=W/2+Math.cos(a)*160;ty=H/2+Math.sin(a)*160;}
      const v=G.enemies.find(e=>e.alive&&(e.type==='vent'||e.type==='membrane'||e.type==='absorber')&&e.spawnT<=0);if(v){G.prio=v;}}
    tx=clamp(tx,30,W-30);ty=clamp(ty,30,H-30);steer2(tx,ty);
    // заряд: каждые ~4 с по приоритетной цели
    const want=(G.prio&&G.prio.alive)||(b&&b.st==='fight');chg++;KEYS.KeyQ=want&&(chg%240)<80;
    if(s%170===0)tryDash();if(p.en>=100)tryPulse();
    const cur=b?b.st+b.phase:'none';if(cur!==ph[ph.length-1])ph.push(cur);
    update(1/60);}
  for(const k of KK)KEYS[k]=false;KEYS.KeyQ=false;const b=G.sb;
  return {sec:Math.round(s/60),state:G.state,ph:ph.slice(0,10),deaths,choice:G.sbChoiceTxt?G.sbChoiceTxt.slice(0,30):null,lomK:G.sbLomK,lvl:G.lvl,lom74:G.lom74,cord:G.mc&&G.mc.cord74};}"""
MS=[int(x) for x in os.environ.get('MS','15,16,17,19,20,21,23,24,25,26').split(',')]
ARS=os.environ.get('ARS','0,3').split(',')
REP=int(os.environ.get('REP','2'))
OPT=json.loads(os.environ.get('OPT','{}'))
async def t(b):
    P=await newpage(b)
    res={}
    for lv in ARS:
        for m in MS:
            secs=[]
            for k in range(REP):
                r=await P.js("(a)=>{T.fresh();T.openAll();const S=G.save;S.ars=arsDef();S.ars.lv.gun={pow:+a.lv,rate:+a.lv};G.layoutSeed=a.seed;enterNode(a.m,false);const f=%s;return f(a.o);}"%BOT74,{'m':m,'lv':lv,'seed':100+k*7,'o':OPT})
                secs.append(r['sec']);print(m,'ars',lv,json.dumps(r,ensure_ascii=False),flush=True)
                if P.errs:print('ERR',P.errs[:4]);P.errs.clear()
            res[(m,lv)]=secs
    print('SUMMARY');
    for lv in ARS: print('ars',lv,' '.join('%d:%s'%(m,'/'.join(map(str,res[(m,lv)]))) for m in MS))
asyncio.run(run([('bal74',t)],'p_zone.json'))
