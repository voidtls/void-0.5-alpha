/* ===== 1.3.4 α «Дорога домой» =====
   1) после миссии 01 через секунду — склад: кольцо на счётчике лома, дорожка и кольцо на самом складе, стрелка «СКЛАД» вместо «МИССИЯ 02».
      Подсказка держится, пока игрок не долетит до склада; радио, баннер и тосты её не гасят. Только потом путь ведёт ко второй миссии;
   2) импульс предлагается только в бою миссии 02 и дальше, когда враги рядом — не в секторе и не у склада;
   3) склад и «Хранилище корпусов» всегда на карте, даже под туманом. */

/* ---------- 1. дом после миссии 01 ---------- */
function tut134Pending(){try{const S=G.save,T=tutT();return !!(S&&T&&tutOn()&&!T.vet&&!T.off&&(S.cleared||0)===1&&!T.done.stash);}catch(e){return false;}}
/* стрелка у края экрана: пока склад не посещён — «СКЛАД», не «МИССИЯ 02» (когда горит дорожка, стрелку рисует сам урок) */
function tut134Home(){if(TUT.cur&&TUT.cur.k==='stash')return null;const s=tutShopPt();return s?{x:s.x,y:s.y,label:'СКЛАД',col:'#ffb84d'}:null;}
TUT_L.lom.when=function(){return false;};/* «лом» теперь часть одного шага «домой» — кольцо на счётчике загорается вместе с дорожкой */
{const L=TUT_L.stash,_v=L.view;L.dur=0;L.fight=true;/* радио, баннер, тост её не снимают */
  L.when=function(){const p=G.player;if(!tut134Pending()||!p||TUT.worldT<.9)return false;if(tutNearFoes(600)>0||p.hp<(G.st&&G.st.maxHp||100)*.35)return false;/* бой свят: стартуем в тишине, радио и баннер не мешают */const s=tutShopPt();if(!s)return false;return Math.hypot(s.x-p.x,s.y-p.y)>240;};
  L.view=function(){const S=G.save,V=_v.apply(this,arguments)||{},el=$('#wLom');
    V.text=(S.carry||0)>0?'<i class="a"></i>ЛОМ <b>НА СКЛАД</b>':'<i class="a"></i>НАГРАДА <span class="sep">—</span> <b>НА СКЛАДЕ</b>';
    if(el&&tutVis(el)){V.ring=[el];V.ringCls='amber sq';}return V;};}
/* «склад» — первый в очереди после боевых: карточка объекта у миссии 01 его не перебивает */
{const order=['patrol','dash','pulse','fire','cell','line','stash','lom','map','calib','move','act','energy','jump'];
  const rest=TUT_PRI.filter(k=>!order.includes(k));TUT_PRI.length=0;order.concat(rest).forEach(k=>TUT_PRI.push(k));}
{const L=TUT_L.act,_w=L.when;L.when=function(){if(tut134Pending()&&!(G.card&&G.card.kind==='shop'))return false;return _w.apply(this,arguments);};}
{const _t=tutTick2;tutTick2=function(dt,now){
  try{const C=TUT.cur,T=tutT();
    if(C&&C.k==='stash'&&T){
      /* ушёл в миссию 02, не заходя на склад, — дорога домой закрыта без галочки */
      if(!tut134Pending()&&!T.done.stash&&(G.save.cleared||0)>=2){TUT.cur=null;tutDomHide('out');T.done.stash=1;tutSave();}
      /* патруль важнее: уступаем, после боя дорожка вернётся */
      else if(G.state==='world'&&!T.done.patrol&&TUT_L.patrol.when())tutEnd('abort');}
    /* долетел до склада — визит засчитан, даже если дорожку в этот момент перебил патруль или карта */
    if(tut134Pending()&&G.state==='world'&&G.player){const s=tutShopPt(),p=G.player;if(s&&Math.hypot(s.x-p.x,s.y-p.y)<240)tutDone('stash');}
    /* дорожка гаснет ровно в момент визита: так «ЛОМ» тоже засчитан */
    if(T&&T.done.stash&&!T.done.lom&&(G.save.cleared||0)>=1){T.done.lom=1;tutSave();}}catch(e){}
  return _t.apply(this,arguments);};}
/* в 1.3.3 игнор дорожки 45 с закрывал урок — теперь он держится до визита */
{const _e=tutEnd;tutEnd=function(how){const C=TUT.cur;if(C&&C.k==='stash'&&how==='miss'&&tut134Pending()){TUT.cur=null;TUT.gap=4;tutDomHide('out');return;}return _e.apply(this,arguments);};}

/* ---------- 2. импульс — только в бою миссии 02+ ---------- */
function tut134PulseOk(R){const p=G.player;return !!p&&G.state==='play'&&!G.world&&(G.m||0)>=2&&tutNearFoes(R)>=1;}
{const L=TUT_L.energy,_w=L.when;L.ctx='mission';L.fight=true;/* показывается именно в бою */L.when=function(){if(!tut134PulseOk(420))return false;return _w.apply(this,arguments);};}
{const L=TUT_L.pulse,_w=L.when;L.ctx='mission';L.when=function(){if(!tut134PulseOk(420))return false;return _w.apply(this,arguments);};}
