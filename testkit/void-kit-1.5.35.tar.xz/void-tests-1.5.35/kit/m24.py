# 1.1.0 α · «Чистый интерфейс»: тексты по мета-промпту «чистка текстового шума» (документ в Claude Docs).
# Убраны неправда о версии, служебный текст, точные числа без решения за ними, названия механик; HP игрока остаётся числом.
# Коды строк реестра (М-04, H-02, K-22…) — в комментариях у правок. Тесты — q140.py.
import sys,os
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m24: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
def RX(start,end,new):
    """заменить кусок от start (включительно) до end (не включая)"""
    global s
    i=s.find(start)
    if i<0 or s.count(start)!=1: sys.exit('m24: RX start %d: %s'%(s.count(start),start[:80]))
    j=s.find(end,i)
    if j<0: sys.exit('m24: RX end not found: '+end[:80])
    s=s[:i]+new+s[j:]

VER='1.1.0 α'
# ═══════════════════════════ 1. ПРАВДА И РАЗРАБОТЧИК ═══════════════════════════
# М-01 версия — мелко в углу; М-02 жанр по-английски; М-03 «пакет»; М-04 неправда про 2 сектора
R('    <div class="eyebrow">1.0.0 АЛЬФА · ТУМАН ВОЙНЫ</div>\n','')
R('      <div class="genre">DEEP SPACE SURVIVAL</div>\n','')
R('<div class="log">ПОСЛЕДНИЙ ПРИНЯТЫЙ ПАКЕТ: 0x3F·Ø<br>Два сектора, десять источников сигнала, ядро <em>Стража</em> и старый маяк.<br>Летите куда хотите: пройденное открыто, дальше — только помехи.</div>',
  '<div class="log">Двенадцать секторов. Пятьдесят сигналов.<br>Летите на свет — и вспомните, кто вы.</div>')
R('    <p class="note mobonly" id="wvNote" hidden>','    <div class="ver" id="verTag">'+VER+'</div>\n    <p class="note mobonly" id="wvNote" hidden>')
# М-05/М-06 кнопки меню; М-07 меню разработчика — только за скрытым входом; М-09 настройки — одной кнопкой (и на ПК)
R('<button class="btn primary" id="bWorld">ОТКРЫТЫЙ СЕКТОР <kbd>ENTER</kbd></button>','<button class="btn primary" id="bWorld">НАЧАТЬ <kbd>ENTER</kbd></button>')
R('<button class="btn" id="bCodex">БОРТОВОЙ СПРАВОЧНИК <kbd>C</kbd></button>','<button class="btn" id="bCodex">СПРАВОЧНИК <kbd>C</kbd></button>')
R('<button class="btn" id="bFsPc" hidden>ВО ВЕСЬ ЭКРАН <kbd>F11</kbd></button>','<button class="btn" id="bFsPc" hidden>ПОЛНЫЙ ЭКРАН <kbd>F11</kbd></button>')
R("pc.innerHTML=on?'ОКОННЫЙ РЕЖИМ <kbd>F11</kbd>':can?'ВО ВЕСЬ ЭКРАН <kbd>F11</kbd>':'НА ВЕСЬ ЭКРАН: НАЖМИТЕ F11';","pc.innerHTML=on?'ОКОННЫЙ РЕЖИМ <kbd>F11</kbd>':'ПОЛНЫЙ ЭКРАН <kbd>F11</kbd>';")
R('<button class="btn mobonly" id="bSettings">НАСТРОЙКИ</button>','<button class="btn" id="bSettings">НАСТРОЙКИ</button>')
R('<button class="btn mobonly" id="bMore">ЕЩЁ · НОВЫЙ ПОЛЁТ, КОД, ВЫБОР МИССИЙ</button>','<button class="btn mobonly" id="bMore">ЕЩЁ</button>')
R("$('#bMore').textContent=$('#sMenu').classList.contains('more')?'СКРЫТЬ':'ЕЩЁ · НОВЫЙ ПОЛЁТ, КОД, ВЫБОР МИССИЙ'","$('#bMore').textContent=$('#sMenu').classList.contains('more')?'СКРЫТЬ':'ЕЩЁ'")
R('<button class="btn" id="bDev" hidden style="border-color:#00ff8844;color:#7fe0b0">ВЫБОР МИССИЙ <kbd>РАЗРАБОТКА</kbd></button>','<button class="btn" id="bDev" hidden style="border-color:#00ff8844;color:#7fe0b0">ВЫБОР МИССИЙ</button>')
R("$('#bDev').hidden=!DEV_MENU;","$('#bDev').hidden=!devUnlocked();")
R('const DEV_MENU=true;','''const DEV_MENU=true;
/* 1.1.0: меню разработчика скрыто от игроков; вход — пять нажатий по логотипу или ?dev в адресе (запоминается в этой вкладке) */
function devUnlocked(){try{if(/[?&#]dev\\b/.test(location.search+location.hash))sessionStorage.setItem('void_dev_ui','1');return DEV_MENU&&(window.__devUI===true||sessionStorage.getItem('void_dev_ui')==='1');}catch(e){return window.__devUI===true;}}
(function(){let n=0,t=0;const L=document.querySelector('#sMenu .logo');if(L)L.addEventListener('click',()=>{const now=performance.now();n=now-t<600?n+1:1;t=now;if(n>=5){window.__devUI=true;try{sessionStorage.setItem('void_dev_ui','1');}catch(e){}renderMenu();toast('РАЗРАБОТКА','Меню разработчика открыто.');}});})();''')
# М-10 отладочная строка полного экрана — нигде не показывается игроку
R("<p class=\"fsdiag\">${FS.diag()}</p>","${devUnlocked()?'<p class=\"fsdiag\">'+FS.diag()+'</p>':''}")
# М-08 строка рекордов: прогресс, пилот, цикл; предупреждение — только когда прогресс под угрозой
RX("function renderRecord(){","\n",
"""function renderRecord(){const S=G.save&&validSave(G.save)?G.save:null,risk=saveWhere()==='ВКЛАДКА',a=[];
  if(S){a.push(`<span>МИССИИ <b>${doneCountS(S)}/${NM}</b></span>`);if(S.pilot)a.push(`<span>ПИЛОТ <b>${S.pilot.lvl}</b></span>`);if((S.cycle||1)>1)a.push(`<span>ЦИКЛ <b>${roman(S.cycle)}</b></span>`);}
  if(risk)a.push(`<span class="warn"><b>СОХРАНИТЕ КОД</b></span>`);
  $('#recLine').innerHTML=a.join('');}""")
R("$('#bWorld').firstChild.nodeValue=S?'ПРОДОЛЖИТЬ ПОЛЁТ · '+doneCountS(S)+'/'+NM+((S.cycle||1)>1?' · ЦИКЛ '+roman(S.cycle):'')+' ':'ОТКРЫТЫЙ СЕКТОР ';",
  "$('#bWorld').firstChild.nodeValue=S?'ПРОДОЛЖИТЬ ':'НАЧАТЬ ';")
# М-09/М-15 блок настроек в меню и на паузе убран: всё — на экране «Настройки»
R("    if(isMob()&&box.closest('#sMenu,#sPause')){if(box.innerHTML)box.innerHTML='';return;}","    if(box.closest('#sMenu,#sPause')){if(box.innerHTML)box.innerHTML='';return;}")
R('<button class="btn mobonly" id="bPauseSet">НАСТРОЙКИ</button>','<button class="btn" id="bPauseSet">НАСТРОЙКИ</button>')
# М-14 сброс
R(">${arm?'ОТМЕНА':'ОБНУЛЕНИЕ ПРОГРЕССА'}</button>",">${arm?'ОТМЕНА':'СБРОСИТЬ ПРОГРЕСС'}</button>")
# K-09 «БОСС · ДОРАБОТКА» — неправда
R("""${M.bossRoom?' <span class="badge" style="color:#ff6b8a">БОСС · ДОРАБОТКА</span>':''}""","""${M.bossRoom||M.boss||M.sboss?' <span class="badge" style="color:#ff6b8a">БОСС</span>':''}""")
# C-01…C-05 сохранение
R('<p class="note">Прогресс открытого сектора хранится только в этом браузере. Скопируйте код, чтобы перенести полёт на другое устройство или подстраховаться от очистки данных.</p>',
  '<p class="note">Код — копия вашего полёта. С ним можно продолжить на другом устройстве.</p>')
RX("function saveStatus(){","\n\n",
"""function saveStatus(){const C=window.CLOUD;if(C&&C.state==='ready')return 'Прогресс сохраняется автоматически.';
  if(LS.ok()&&LS.persisted('void_world'))return 'Прогресс хранится только на этом устройстве — сохраните код.';
  return 'Здесь прогресс не сохраняется. Скопируйте код перед выходом.';}""")
R("$('#saveMsg').textContent='Загружено: пройдено миссий '+worldDone(S0)+' из '+NM+', лом '+S.lom+'. '+saveStatus();","$('#saveMsg').textContent='Полёт загружен: пройдено миссий — '+worldDone(S0)+'.';")

# ═══════════════════════════ 2. HUD ═══════════════════════════
# H-01 корпус: остаётся число «82/100» (по просьбе игрока), слово «КОРПУС» убрано; износ — словом, без процентов; ДВИГ −% и ⊘ убраны
R('<div class="bar-l"><span>КОРПУС</span><b id="hpT">100/100</b></div>','<div class="bar-l hpl"><span></span><b id="hpT">100/100</b></div>')
R("setT('hpT',Math.ceil(p.hp)+'/'+st.maxHp+(G.wear>0?' · ИЗНОС '+wearPct()+'%':'')+((G.eng74||0)>=.5?' · ДВИГ −'+Math.round(G.eng74*10)+'%':'')+(noHeal()?' ⊘':''));",
  "setT('hpT',Math.ceil(p.hp)+'/'+st.maxHp+(G.wear>0?' · ИЗНОС':''));")
# H-03 накопитель: подпись и проценты убраны, остаётся полоса (полная — светится)
R('<div class="bar-l"><span>НАКОПИТЕЛЬ</span><b id="enT">0%</b></div>','<div class="bar-l enl"><span></span><b id="enT"></b></div>')
# H-05 название миссии без «МИССИЯ 07/50 ·»
R("setT('misT','МИССИЯ '+pad2(G.m)+'/'+pad2(NM)+' · '+MISSIONS[G.m-1].name.toUpperCase());","setT('misT',mName(MISSIONS[G.m-1]).toUpperCase());")
R('<span id="misT">МИССИЯ 01/10</span><b id="sigT">СИГНАЛ 0%</b>','<span id="misT"></span><b id="sigT"></b>')
# H-06…H-10 маяк: без секунд продувки и процентов заряда; целостность — полосой
R("else if(bc.cool>0)s='ПРОДУВКА '+bc.cool.toFixed(1)+' с';","else if(bc.cool>0)s='ПРОДУВКА';")
R("s=(bc.charge>=80?'ПЕРЕДАЧА ':'ПЕРЕДАЧА НА ПАУЗЕ · ')+Math.ceil(bc.trans)+' с';","s=(bc.charge>=80?'ПЕРЕДАЧА · ':'ПЕРЕДАЧА НА ПАУЗЕ · ')+Math.ceil(bc.trans)+' С';")
R("else s='ЗАРЯД '+Math.floor(bc.charge)+'%'+(bc.drain>0?' ▼':bc.inRing?' ▲':'');","else s='ЗАРЯД'+(bc.drain>0?' ▼':bc.inRing?' ▲':'');")
R("setT('biT',Math.ceil(bc.hp)+(bc.barrier>0?' +'+Math.ceil(bc.barrier):''));","setT('biT',bc.barrier>0?'ЩИТ':'');")
R('<div class="bar-l"><span>ЦЕЛОСТНОСТЬ МАЯКА</span><b id="biT">0</b></div>','<div class="bar-l"><span>КОРПУС МАЯКА</span><b id="biT"></b></div>')
# H-11/H-12 боссы: без фаз и десятых долей секунды
R("if(SB){setT('sigT',sbHud(SB));","if(SB){setT('sigT',hudClean(sbHud(SB)));")
R("setT('sigT',G.boss.over>0?'ПЕРЕГРУЗКА '+G.boss.over.toFixed(1)+' с':'СТРАЖ · ФАЗА '+G.boss.phase);","setT('sigT',G.boss.over>0?'ПЕРЕГРУЗКА':'СТРАЖ');")
# H-04 сигнал: полоса уже показывает прогресс
R("setT('sigT','СИГНАЛ '+Math.round(pr*100)+'%');","setT('sigT','СИГНАЛ');")
# H-13…H-16 чипы: состояние вместо секунд и процентов; перезарядка — заливкой чипа
R("setT('dashC',blocked?'РЫВОК — ПОМЕХИ':p.dashCd<=0?'РЫВОК — ГОТОВ':'РЫВОК — '+p.dashCd.toFixed(1)+' с');","setT('dashC',blocked?'РЫВОК · ПОМЕХИ':'РЫВОК');setF('dashC',p.dashCd>0?1-p.dashCd/(p.dashCdMax||st.dashCd||1):0);")
R("setT('dashC',p.dashCd<=0?'РЫВОК — ГОТОВ':'РЫВОК — '+p.dashCd.toFixed(1)+' с');","setT('dashC','РЫВОК');setF('dashC',p.dashCd>0?1-p.dashCd/(p.dashCdMax||st.dashCd||1):0);",2)
R("setT('pulseC',pr?'ИМПУЛЬС — ГОТОВ [E]':'ИМПУЛЬС — '+Math.floor(p.en)+'%');","setT('pulseC',pr?'ИМПУЛЬС [E]':'ИМПУЛЬС');setF('pulseC',pr?0:p.en/100);",3)
R("setT('lvC','МОДУЛИ · УР '+G.lvl+(st.shieldCd?(p.shieldUp?' · ЩИТ ●':' · ЩИТ ○'):''));","setT('lvC','ЩИТ');setH('lvC',!st.shieldCd);setC('lvC','ok',!!(st.shieldCd&&p.shieldUp));",3)
R("const rd=p.chgCd<=0&&!(p.chg>0);setT('chgC',p.chgCd>0?'ЗАРЯД — '+p.chgCd.toFixed(1)+' с':p.chg>0?'ЗАРЯД — '+Math.min(100,Math.round(p.chg/CHG_T*100))+'%':'ЗАРЯД — ГОТОВ [Q]');",
  "const rd=p.chgCd<=0&&!(p.chg>0);setT('chgC',rd?'ЗАРЯД [Q]':'ЗАРЯД');setF('chgC',p.chgCd>0?1-p.chgCd/CHG_CD:p.chg>0?Math.min(1,p.chg/CHG_T):0);")
R("setH('aimC',touchMode||!MOUSE.moved);if(!touchMode)setT('aimC','ПРИЦЕЛ · '+(aimManual()?'РУЧНОЙ':'АВТО')+' [T]');","setH('aimC',true);")
R("if(on)setT('comboC','КОМБО ×'+C.mul.toFixed(2).replace('.',',')+' · '+C.n);","if(on)setT('comboC','КОМБО '+C.n);")
R('<div class="chip" id="dashC">РЫВОК — ГОТОВ</div><div class="chip en" id="pulseC">ИМПУЛЬС — 0%</div><div class="chip" id="chgC" hidden>ЗАРЯД — ГОТОВ</div>','<div class="chip" id="dashC">РЫВОК</div><div class="chip en" id="pulseC">ИМПУЛЬС</div><div class="chip" id="chgC" hidden>ЗАРЯД</div>')
R('<div class="chip" id="lvC">МОДУЛИ · УР 1</div>','<div class="chip" id="lvC" hidden>ЩИТ</div>')
# кнопки телефона: перезарядку показывает кольцо, цифры секунд убраны
R("p.dashCd>1?String(Math.ceil(p.dashCd)):''","''")
R("p.chgCd>1?String(Math.ceil(p.chgCd)):''","''")
# помощники HUD
R("function setH(id,h){",r"""function setF(id,f){const k=id+'f',v=Math.round(clamp(f,0,1)*50)*2;if(hudCache[k]!==v){hudCache[k]=v;hudEls[id].style.setProperty('--f',v+'%');}}
function mName(M){return M?String(M.name).replace(/^Комната босса · /,''):'';}
function hudClean(v){return String(v==null?'':v).replace(/\s·\sФАЗА\s\d+/g,'').replace(/ФАЗА\s\d+\s·\s/g,'').replace(/(\d+)[,.](\d)\s?[сС](?![А-ЯЁа-яё])/g,(m,a,b)=>Math.ceil(+(a+'.'+b))+' С');}
function setH(id,h){""")
# H-21…H-24 мир: сектор без слова «СЕКТОР», лом и «+N» в трюме, подстрочник — только аномалия
R("setT('wSec','СЕКТОР · '+sectorName(p.x,p.y));","setT('wSec',sectorName(p.x,p.y));")
R('+(S.carry?` <span style="font-size:13px;color:var(--amber)">+${fmtN(S.carry)} при себе</span>`:\'\');','+(S.carry?` <span style="font-size:13px;color:var(--amber)">+${fmtN(S.carry)}</span>`:\'\');')
R("let sub=`ПИЛОТ · УР ${S.pilot.lvl}${(S.cycle||1)>1?' · ЦИКЛ '+roman(S.cycle):''} · МИССИИ ${doneCount()}/${NM} · МЕДАЛИ ${totalMedals()}/${NM*4}`;","let sub='';")
R("  else if(G.cruise)sub='КРЕЙСЕРСКИЙ РЕЖИМ';\n","")
R("setT('wSub',sub);setC('hud0','subimp',!!G.anom);","setT('wSub',hudClean(sub));setC('hud0','subimp',!!G.anom);")
# H-25…H-27 Бесконечность: время без десятых, ступень без обратного отсчёта
R("setT('eTime',fmtT(E.t));","setT('eTime',mmss(E.t));")
R("if(bo){setT('eStep',(bo.type==='boss'?'ЭХО СТРАЖА':'ЭХО ГЛУШИТЕЛЯ')+' · '+Math.max(0,Math.ceil(bo.hp/bo.maxHp*100))+'% · СТУПЕНЬ НА ПАУЗЕ');}",
  "if(bo){setT('eStep',bo.type==='boss'?'ЭХО СТРАЖА':'ЭХО ГЛУШИТЕЛЯ');}")
R("else{const tb=E.nextBoss-E.t;setT('eStep','СТУПЕНЬ '+E.step+' · '+(tb<=30?'ЭХО ЧЕРЕЗ '+Math.ceil(tb)+' С':'УСИЛЕНИЕ ЧЕРЕЗ '+(E.dur-E.stepT).toFixed(1).replace('.',',')+' С'));}}",
  "else{const tb=E.nextBoss-E.t;setT('eStep','СТУПЕНЬ '+E.step+(tb<=10?' · ЭХО БЛИЗКО':''));}}")
R("if(E.best){const d=E.t-E.best.t;setT('eRec',E.beat?'НОВЫЙ РЕКОРД · +'+fmtT(d):'РЕКОРД '+fmtT(E.best.t)+' · −'+fmtT(-d));setC('eRec','beat',E.beat);}\n  else setT('eRec',G.devRun?'ТЕСТОВЫЙ ЗАБЕГ':'ПЕРВЫЙ ЗАБЕГ');",
  "if(E.best){setT('eRec',E.beat?'НОВЫЙ РЕКОРД':'РЕКОРД '+mmss(E.best.t));setC('eRec','beat',E.beat);}\n  else setT('eRec','');")
R('<div id="eTime">0:00.0</div>','<div id="eTime">0:00</div>')
# HUD CSS: заливка чипов, скрытые строки, счёт только в Бесконечности, версия в углу меню
R('.chip.bad{color:var(--hostile);border-color:#5a2a38}',""".chip.bad{color:var(--hostile);border-color:#5a2a38}
.chip{background-image:linear-gradient(90deg,rgba(143,216,255,.14) var(--f,0%),transparent var(--f,0%))}.chip.en{background-image:linear-gradient(90deg,rgba(255,184,77,.16) var(--f,0%),transparent var(--f,0%))}
#hud .enl{display:none!important}#hud:not(.endless) #score{display:none}#hud .hpl span:empty{display:none}
#sMenu .ver{position:absolute;right:max(16px,env(safe-area-inset-right,0px));bottom:calc(12px + env(safe-area-inset-bottom,0px));font-family:var(--f-mono);font-size:11px;letter-spacing:.12em;color:#4a5a6e;pointer-events:none}
.rec .warn b{color:var(--amber)}""")

# ═══════════════════════════ 3. ВСПЛЫВАЮЩИЕ НАДПИСИ И БАННЕРЫ ═══════════════════════════
# X-01…X-20: длительность эффекта «· 5 С», множители «×1,5» и проценты в доп. частях не показываются — одним фильтром
R("function floater(x,y,text,col){if(G.float.length>24)","function floater(x,y,text,col){text=tclean(text);if(G.float.length>24)")
R("function banner(b,s){$('#banB').textContent=b;$('#banS').textContent=s||'';","function banner(b,s){s=tclean(s);if(/^(ЛОМ|УРОН|ЗАРЯД|ОПЫТ)$/.test(s||''))s='';$('#banB').textContent=b;$('#banS').textContent=s||'';")
R("let banT=0;\n",r"""let banT=0;
/* 1.1.0: чистка всплывающих надписей */
function tclean(s){if(typeof s!=='string'||!s||G.devRun)return s;let t=s.replace(/\s·\s~?\d+(?:[,.]\d+)?\s?[сС](?![А-ЯЁа-яё])/g,'').replace(/^~?\d+(?:[,.]\d+)?\s?[сС]\s·\s/,'');
  const seg=t.split(' · ');if(seg.length>1){const k=seg.filter(x=>!/×\s?\d/.test(x)&&!/[+−-]?\d+(?:[,.]\d+)?\s?%/.test(x));if(k.length)t=k.join(' · ');}
  t=t.replace(/\s*×\s?\d+(?:[,.]\d+)?(?=$|\s·|,)/g,'').replace(/\s+,/g,',').trim();return t||s;}
""")
R("floater(bc.x,bc.y-bc.r-18,'+'+add+'% ЗАРЯДА','#ffb84d')","floater(bc.x,bc.y-bc.r-18,'+ЗАРЯД','#ffb84d')")
R("floater(k.x,k.y-14,'+'+Math.round(34*st.eGain)+'% ЭНЕРГИИ','#ffb84d')","floater(k.x,k.y-14,'+ЭНЕРГИЯ','#ffb84d')")
R("floater(p.x,p.y-26,'РЕМОНТНИК · ИЗНОС +2%','#ffb060')","floater(p.x,p.y-26,'ИЗНОС','#ffb060')")
R("floater(p.x,p.y-30,'ДВИГАТЕЛЬ −'+Math.round(G.eng74*10)+'%','#b8c4d6')","floater(p.x,p.y-30,'ДВИГАТЕЛЬ ПОВРЕЖДЁН','#b8c4d6')")
R("floater(p.x,p.y-38,'НАРУШЕНИЕ РЕГЛАМЕНТА · ВРАГИ +20% УРОНА','#ffd36b')","floater(p.x,p.y-38,'НАРУШЕНИЕ РЕГЛАМЕНТА · ВРАГИ СИЛЬНЕЕ','#ffd36b')")

# ═══════════════════════════ 4. БРИФИНГ, ИТОГИ, ПОРАЖЕНИЕ, ПАУЗА, ВЫБОР МОДУЛЯ ═══════════════════════════
# B-01 надзаголовок без «/50»; B-02 название без повтора сектора; B-03 теги без множителей; B-04 «опасность» точками вместо «×N»
R("$('#inSector').textContent='МИССИЯ '+pad2(i+1)+'/'+pad2(NM)+' · '+M.sector;$('#inName').textContent=M.name;",
  "$('#inSector').textContent='МИССИЯ '+pad2(i+1)+' · '+M.sector;$('#inName').textContent=mTitle(M);")
R("""$('#inThreat').innerHTML=(G.echo?'<span class="tag" style="border-color:#5a3a8c;color:var(--violet)">ЭХО · АФФИКСЫ ЭЛИТЫ · ПРОЧНОСТЬ ВРАГОВ ×1,3</span>':'')""",
  """$('#inThreat').innerHTML=(G.echo?'<span class="tag" style="border-color:#5a3a8c;color:var(--violet)">ЭХО</span>':'')+dangerTag(M)""")
R("(M.mech||[]).map(k=>`<span class=\"tag mech\">${k}</span>`).join('')","mechTags(M).map(k=>`<span class=\"tag mech\">${k}</span>`).join('')")
R("`<button class=\"rbtn more mobonly\" id=\"bHintMore\">ЕЩЁ ПОДСКАЗКИ · ${M.hint.length-1}</button>`","`<button class=\"rbtn more mobonly\" id=\"bHintMore\">ЕЩЁ ПОДСКАЗКИ</button>`")
# B-05 сложность: одна строка смысла вместо таблицы множителей
RX("  const em=D.enemy*cycCnt(),parts=","\n}\n",
"""  const M=MISSIONS[G.m-1],noRep=!!(M&&M.gen&&SEC_SCALE[M.sec]);
  $('#inDiffNote').textContent=(DIFF_NOTE[cur]||'')+(noRep?' Ремонта нет.':'')+(cycleN()>1?' Цикл '+roman(cycleN())+': враги крепче.':'');""")
R('<div class="eyebrow">СЛОЖНОСТЬ МИССИИ</div>','<div class="eyebrow">СЛОЖНОСТЬ</div>')
R('<div class="eyebrow" style="margin-top:6px">ОРУЖИЕ · АРСЕНАЛ</div>','<div class="eyebrow" style="margin-top:6px">ОРУЖИЕ</div>')
# R-01…R-05 итоги миссии: время и лом; медали — кружками с условием; без таблицы множителей и счётчика повторов
R("$('#dnEyebrow').textContent=(G.echo?'ЭХО · ':'')+D.name+' · '+(m===6&&first?'ЯДРО ПРОЙДЕНО':m===CORE&&first?'АКТ I ЗАВЕРШЁН':'МИССИЯ '+pad2(m)+'/'+pad2(NM)+' ВЫПОЛНЕНА');",
  "$('#dnEyebrow').textContent=(m===6&&first?'ЯДРО ПРОЙДЕНО':m===CORE&&first?'АКТ I ЗАВЕРШЁН':'МИССИЯ ВЫПОЛНЕНА')+(G.echo?' · ЭХО':'');")
R("  $('#dnName').textContent=MISSIONS[m-1].name;\n  const cells=[['ВРЕМЯ',mmss(G.mT)],['УНИЧТОЖЕНО',G.kills-G.missionKills],['ПОЛУЧЕНО УРОНА',Math.round(taken)],['ЛОМ',lomH('+'+lom,1)],['ОПЫТ ПИЛОТА','+'+Math.round(px+(G.kills-G.missionKills)*mul)]];\n  if(G.bc)cells.splice(3,0,['МАЯК ЦЕЛ НА',Math.round(G.bc.hp/G.bc.maxHp*100)+'%']);",
  "  $('#dnName').textContent=mName(MISSIONS[m-1]);\n  const cells=[['ВРЕМЯ',mmss(G.mT)],['ЛОМ',lomH('+'+lom,1)]];")
R("${mrow(md.clean,'Чистота','урон корпусу меньше '+cleanLim)}${mrow(md.master,'Мастерство',MASTERY[m-1].t)}${mrow(md.echo,'Эхо','пройти в режиме «Эхо»')}</span>`+",
  "${mrow(md.clean,'Чистота','почти без урона')}${mrow(md.master,'Мастерство',MASTERY[m-1].t)}${mrow(md.echo,'Эхо','в режиме «Эхо»')}</span>`+")
R("    `<br>Сложность: ${D.name} · лом и опыт пилота ×${fx(D.lom)}${cycleN()>1?' · цикл '+roman(cycleN())+' ×'+fx(cycLom()):''}${first?'':' · повтор №'+(k+1)+' (награда снижается)'}. `+\n    (got.length?`Новые медали: ${got.join(', ')}. `:'')+(G.sbChoiceTxt?G.sbChoiceTxt+' ':'')+(healed>0?`Ремонтные дроны восстановили ${healed} ед. корпуса.`:'');",
  "    (G.sbChoiceTxt?'<br>'+G.sbChoiceTxt:'');")
R('<p class="note" id="dnNote">Ремонтные дроны восстановили 30% корпуса.</p>','<p class="note" id="dnNote"></p>')
# O-01…O-04 поражение: коротко, без таблицы
R("'СИГНАЛ ПОТЕРЯН · ВОСПОМИНАНИЕ НЕ СОХРАНЕНО':'СИГНАЛ ПОТЕРЯН';$('#ovName').textContent=(G.loseBeacon?'Маяк разрушен':'Корабль уничтожен')+' · миссия '+pad2(G.m);",
  "'СИГНАЛ ПОТЕРЯН':'СИГНАЛ ПОТЕРЯН';$('#ovName').textContent=G.loseBeacon?'Маяк разрушен':'Корабль уничтожен';")
R("$('#ovStats').innerHTML=statCells([['ВРЕМЯ',mmss(G.mT)],['УНИЧТОЖЕНО',G.kills-G.missionKills],['УРОВЕНЬ МОДУЛЕЙ',G.lvl],['ОЧКИ',fmt(G.score)]]);",
  "$('#ovStats').innerHTML=statCells([['ВРЕМЯ',mmss(G.mT)]]);")
R("$('#ovNote').textContent=(G.loseBeacon?'Следите за целостностью маяка: пиявок и осаждающих (метка-ромб) снимайте в первую очередь. ':'')+'Повтор начнёт миссию заново с теми модулями и корпусом, что были на её старте.';",
  "$('#ovNote').textContent=G.loseBeacon?'Пиявок и врагов с ромбом над головой снимайте первыми.':'';")
# P-01 пауза: одна строка о главном
R("$('#pauseStat').textContent=G.pausedWorld&&S?`ПИЛОТ УР ${S.pilot.lvl} · МИССИИ ${doneCount()}/${NM} · МЕДАЛИ ${totalMedals()}/${NM*4}`+(S.carry?` · ТРЮМ ${fmtN(S.carry)}`:''):G.mode==='endless'?`СТУПЕНЬ ${G.end?G.end.step:1} · УНИЧТОЖЕНО ${G.kills} · МОДУЛИ УР ${G.lvl}`:`МИССИЯ ${pad2(G.m)} · МОДУЛИ УР ${G.lvl} · ОЧКИ ${fmt(G.score)}`;",
  "$('#pauseStat').textContent=G.pausedWorld&&S?`МИССИИ ${doneCount()}/${NM}`:G.mode==='endless'?`СТУПЕНЬ ${G.end?G.end.step:1}`:mName(MISSIONS[G.m-1]).toUpperCase();")
R('<button class="btn" id="bPauseFs" hidden>ВО ВЕСЬ ЭКРАН</button>','<button class="btn" id="bPauseFs" hidden>ПОЛНЫЙ ЭКРАН</button>')
R('<button class="btn primary" id="bFsResume" hidden>ПРОДОЛЖИТЬ ВО ВЕСЬ ЭКРАН</button>','<button class="btn primary" id="bFsResume" hidden>ПРОДОЛЖИТЬ · ПОЛНЫЙ ЭКРАН</button>')
R('    <div class="settings" data-settings style="max-width:none"></div>\n','')
R('    <div class="settings" data-settings></div>\n','')
# L-01…L-06 выбор модуля: без строки цифр, без «· АКТ II»; ремонт — словами
R("$('#lvEyebrow').textContent=G.briefQ>0?'БРИФИНГ · СТАРТОВЫЙ КОМПЛЕКТ · ВЫБОР '+(G.briefN-G.briefQ+1)+' ИЗ '+G.briefN+' · ДЕЙСТВУЕТ ДО КОНЦА МИССИИ':'УРОВЕНЬ МОДУЛЕЙ '+G.lvl+' · ВЫБЕРИТЕ ОДИН'+(G.lvlQ>1?' · ЕЩЁ '+(G.lvlQ-1):'');",
  "$('#lvEyebrow').textContent=G.briefQ>0?'СТАРТОВЫЙ МОДУЛЬ · '+(G.briefN-G.briefQ+1)+' ИЗ '+G.briefN:'НОВЫЙ МОДУЛЬ'+(G.lvlQ>1?' · ЕЩЁ '+(G.lvlQ-1):'');")
R("<p>Все доступные модули на пределе. ${noHeal()?'Ремонт в секторе недоступен: полный накопитель и щит.':'Восстановить 40 ед. корпуса.'}</p>","<p>Все модули на пределе. ${noHeal()?'Полный накопитель и щит.':'Подлатать корпус.'}</p>")
R("<span>${M.tag}${M.from>=7?' · АКТ II':''}</span><span>${i+1}</span></div><h3>${M.name}</h3><div class=\"pips\">${pips}</div><p>${M.d}</p><div class=\"fx\">${M.fx(M.v[l],M.v[l+1])}</div></button>",
  "<span>${M.tag}</span><span>${i+1}</span></div><h3>${M.name}</h3><div class=\"pips\">${pips}</div><p>${M.d}</p></button>")
R("$('#lvEyebrow').textContent='МОДУЛЬ МАЯКА · ДЕЙСТВУЕТ ДО КОНЦА МИССИИ';","$('#lvEyebrow').textContent='МОДУЛЬ МАЯКА';")
R("<h3>Ремонт маяка</h3><p>Все модули маяка установлены. Восстановить 120 ед. целостности.</p>","<h3>Ремонт маяка</h3><p>Все модули маяка стоят. Починить маяк.</p>")
R("<div class=\"k\"><span>МАЯК${M.max>1?' · УР '+(l+1)+'/'+M.max:''}</span><span>${i+1}</span></div><h3>${M.name}</h3><p>${M.d}</p><div class=\"fx\">${M.fx(l)}</div></button>",
  "<div class=\"k\"><span>МАЯК</span><span>${i+1}</span></div><h3>${M.name}</h3>${M.max>1?'<div class=\"pips\">'+Array.from({length:M.max},(_,j)=>`<i class=\"${j<l?'f':j===l?'n':''}\"></i>`).join('')+'</div>':''}<p>${M.d}</p></button>")

# ═══════════════════════════ 5. КАРТОЧКИ МИРА, МАСТЕРСКАЯ, АНГАР, АРСЕНАЛ ═══════════════════════════
R("h=`<div class=\"eyebrow\">МИССИЯ ${pad2(m)}/${pad2(NM)} · ${done?'ПРОЙДЕНА':'ДОСТУПНА'}${M.gen?' · СЕКТОР '+roman(M.sec+1):''}</div><h3>${M.name}",
  "h=`<div class=\"eyebrow\">МИССИЯ ${pad2(m)}${done?' · ПРОЙДЕНА':''}</div><h3>${mName(M)}")
RX("      ${S.bestDiff[m]!==undefined?`<div class=\"note\">Лучшая сложность:","\n",
   "")
R("<span>${S.best[m]?'лучшее время '+mmss(S.best[m]):'медали: прохождение · чистота · мастерство · эхо'}</span>","<span>${S.best[m]?'лучшее время '+mmss(S.best[m]):''}</span>")
R("<h3>Ремонт, склад и улучшения</h3>","<h3>Ремонт и улучшения</h3>")
R("<h3>Скины корабля</h3><p class=\"note\">Сейчас: ${SKINS[curSkin()].name} · пилот ур ${S.pilot.lvl} · скинов ${S.ownSkins.length}/${Object.keys(SKINS).length}</p>","<h3>Скины корабля</h3><p class=\"note\">${SKINS[curSkin()].name}</p>")
R("'Откроется после первой победы в комнате босса 14.'","'Откроется после победы над боссом Холодного архива.'")
R("<p class=\"note\">Базовый корабль без перков (кроме «Боевого ритма»). Рекорд идёт в общую таблицу${eb?' · лучшее '+fmtT(eb.t):''}. В сектор ничего не переносится: ни лом, ни опыт, ни контракты. Лом при себе будет сдан на склад. Сейчас: ${lomH(S.lom)}${S.carry?' + '+lomH(S.carry):''}.</p>",
  "<p class=\"note\">Бесконечность на базовом корабле. В сектор ничего не переносится.${eb?' Лучшее: '+mmss(eb.t)+'.':''}</p>")
R("$('#shopName').textContent=G.shopName+' · АВТОМАТ ОБСЛУЖИВАНИЯ · ПРОЕКТ Э. В. · КОРПУС ВОССТАНОВЛЕН';","$('#shopName').textContent=G.shopName+' · КОРПУС ВОССТАНОВЛЕН';")
RX("  $('#shopLom').innerHTML=`<span>ЛОМ НА СКЛАДЕ","\n","  $('#shopLom').innerHTML=`<span>ЛОМ ${lomH(S.lom,1)}</span>`;")
R("`<p class=\"note\">Выполнено: ${C.done}. Новые контракты поступают после каждого нового прохождения миссии (до трёх). Награда растёт на 10% за каждый выполненный контракт (до +100%). В Бесконечности и Бездне не засчитываются.</p>`",
  "`<p class=\"note\">Выполнено: ${C.done}.</p>`")
R("<p>${T.t(c.n)} · ${c.p}/${c.n} · награда ${lomH(c.lom)} и ${c.px} опыта пилота</p>","<p>${T.t(c.n)} · ${c.p}/${c.n} · ${lomH(c.lom)}</p>")
R("<p>Сектор начинается заново: враги прочнее и многочисленнее, лом и опыт пилота ×${Math.min(2,1+.25*(S.cycle||1)).toFixed(2).replace('.',',')}. Перки, скины, уровень пилота и лом сохраняются.</p>",
  "<p>Сектор начинается заново: враги сильнее, награды больше. Перки, скины, уровень пилота и лом остаются.</p>")
R('<div class="cx-h2" id="shopConH">КОНТРАКТЫ · ОТПРАВИТЕЛЬ: Н.</div>','<div class="cx-h2" id="shopConH">КОНТРАКТЫ</div>')
R('<p class="note">Перки мастерской постоянные. Модули корабля выбираются на брифинге и в бою и действуют до конца миссии. Скины — в ангаре «Зеркало» рядом с миссией 05.</p>','<p class="note">Перки остаются навсегда.</p>')
R('<div class="eyebrow">ХРАНИЛИЩЕ КОРПУСОВ · ДОПУСК Э. В.</div>','<div class="eyebrow">ХРАНИЛИЩЕ КОРПУСОВ</div>')
R("$('#hangarNote').innerHTML=`Пилот · уровень ${lv} · на складе ${lomH(Sv.lom,1)}<br>Скин открывается уровнем пилота и покупается за лом. Скин не меняет размер корабля и уязвимость.`;",
  "$('#hangarNote').innerHTML=`Уровень пилота ${lv} · ${lomH(Sv.lom,1)}<br>Скины открываются уровнем пилота и покупаются за лом.`;")
R('<p class="note" id="hangarNote">Скин открывается уровнем пилота и покупается за лом. Скин не меняет размер корабля и уязвимость.</p>','<p class="note" id="hangarNote"></p>')
R('<div class="eyebrow">АРСЕНАЛ «ИНЕЙ» · ХОЛОДНЫЙ АРХИВ · ДОПУСК ПОСЛЕ ИЗОБРЕТАТЕЛЯ</div>','<div class="eyebrow">АРСЕНАЛ «ИНЕЙ»</div>')
R("$('#arsLom').innerHTML=`ЛОМ НА СКЛАДЕ ${lomH(S.lom,1)}`;","$('#arsLom').innerHTML=`ЛОМ ${lomH(S.lom,1)}`;")
R("<span>${T.name} · +${Math.round((T.k[Math.min(n,2)]-1)*100)} % ${n<3?'за ступень '+(n+1):''}</span>","<span>${T.name}</span>")
R("<div class=\"ars-after\">${!own?'сначала купите оружие':n<3?`сейчас ${t==='rad'?Math.round(curV):f1(curV)} → после ${t==='rad'?Math.round(nxt):f1(nxt)}`:'максимум'}</div>","<div class=\"ars-after\">${!own?'сначала купите оружие':n<3?'':'максимум'}</div>")
R("<div class=\"ars-stats\">${stats}</div>","")
R('<p class="note" id="arsNote">Каждая ступень считается от текущего значения. Покупка подтверждается вторым нажатием. Купленное оружие переключается здесь или на брифинге миссии.</p>','<p class="note" id="arsNote">Покупка — двойным нажатием. Оружие меняется здесь или на брифинге.</p>')

# ═══════════════════════════ 6. НАСТРОЙКИ ═══════════════════════════
RX("function renderSetScreen(){","\nfunction applySettings(){",r"""function renderSetScreen(){const B=$('#setBody');if(!B||G.state!=='settings')return;const ios=/iP(hone|ad|od)/.test(navigator.userAgent)||navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1,tch=touchMode||isMob();
  const fxl=!SET.fx?'off':SET.lessFx?'less':'full',fxSeg=`<div class="setrow"><div class="eyebrow">ЭФФЕКТЫ</div><div class="seg">${[['full','ПОЛНЫЕ'],['less','МЕНЬШЕ'],['off','ВЫКЛ']].map(([v,n])=>`<button data-fxl="${v}" class="${fxl===v?'on':''}">${n}</button>`).join('')}</div></div>`;
  B.innerHTML=`<div class="setgrp"><div class="cx-h2">ЗВУК</div>${togHTML('amb','МУЗЫКА')}
      <label class="vol"><span>ГРОМКОСТЬ МУЗЫКИ</span><input type="range" min="0" max="1" step="0.05" value="${SET.ambVol}" data-vol id="vol-sSet"></label>${togHTML('sfx','ЗВУКИ')}
      ${ios?'<p class="note">Нет звука? Проверьте беззвучный режим.</p>':''}</div>
    <div class="setgrp"><div class="cx-h2">УПРАВЛЕНИЕ</div>${tch?`${segHTML('btnSize')}${segHTML('btnAlpha')}${segHTML('hand')}${segHTML('stick')}
      ${togHTML('dashSwipe','РЫВОК СВАЙПОМ')}${togHTML('oneHand','ОДНОЙ РУКОЙ')}${navigator.vibrate?togHTML('haptics','ВИБРАЦИЯ'):''}`:togHTML('manual','ПРИЦЕЛ МЫШЬЮ')}</div>
    <div class="setgrp"><div class="cx-h2">ЭКРАН</div>${segHTML('fsMode')}${FS.can()?'':`<p class="note" id="fsNote">${FS.noteText()}</p>`}${FS.hintKind()&&!FS.can()?'<div><button class="wbtn" data-fshint>КАК УБРАТЬ ПАНЕЛИ</button></div>':''}${FS.orientOK()?segHTML('orient'):''}
      ${segHTML('zoom')}${segHTML('textScale')}${segHTML('quality')}${segHTML('fps')}${segHTML('shake')}${fxSeg}${devUnlocked()?'<p class="fsdiag">'+FS.diag()+'</p>':''}</div>
    <div class="setgrp"><div class="cx-h2">ПРОЧЕЕ</div>${togHTML('radio','РАДИОЭФИР')}${togHTML('softInv','БЕЗ ПЕРЕВОРОТА УПРАВЛЕНИЯ')}${togHTML('noErase','БЕЗ СТИРАНИЯ ИНТЕРФЕЙСА')}${G.setFrom==='menu'?resetBlock():''}</div>`;}
document.addEventListener('click',e=>{const b=e.target.closest('[data-fxl]');if(!b)return;const v=b.dataset.fxl;SET.fx=v!=='off';SET.lessFx=v==='less';saveSet();applySettings();renderSettings();buzz('tap');});""")
R("orient:[['ОРИЕНТАЦИЯ · В ПОЛНОМ ЭКРАНЕ',","orient:[['ОРИЕНТАЦИЯ',")
for a in ['МАСШТАБ','ТЕКСТ','КАЧЕСТВО','КАДРЫ','ТРЯСКА']: R("[['ЭКРАН · "+a+"',","[['"+a+"',")
for a in ['РАЗМЕР КНОПОК','ПРОЗРАЧНОСТЬ КНОПОК','РУКА','СТИК']: R("[['УПРАВЛЕНИЕ · "+a+"',","[['"+a+"',")
R("[30,'30 · ЭКОНОМИЯ БАТАРЕИ']","[30,'30']")
R("['l','ЛЕВАЯ · ЗЕРКАЛО']","['l','ЛЕВАЯ']")
R('    <div class="eyebrow">НАСТРОЙКИ</div>\n    <h2>Настройки</h2>','    <h2>Настройки</h2>')
R("<p class=\"rwarn\">ТОЧНО? СОТРЁТСЯ: сектор, циклы, уровень пилота, перки, купленные скины, контракты, медали, лом.</p><button class=\"rbtn go\" id=\"bResetGo\">ОБНУЛИТЬ</button>",
  "<p class=\"rwarn\">Сотрётся весь полёт: миссии, пилот, перки, скины и лом.</p><button class=\"rbtn go\" id=\"bResetGo\">СТЕРЕТЬ</button>")

# ═══════════════════════════ 7. СПРАВОЧНИК ═══════════════════════════
i0=s.find("  if(cxTab==='log')B.innerHTML=`<dl class=\"kv\">");j0=s.find("</dl>`;",i0)+len("</dl>`;")
if i0<0 or j0<i0: sys.exit('m24: log block not found')
LOG=s[i0:j0].replace("<dl class=\"kv\"><dt>1.0.0 α</dt>","<dl class=\"kv\"><dt>1.1.0 α</dt><dd>«Чистый интерфейс». Из игры убран текстовый шум: точные секунды, проценты и множители там, где за ними нет решения; служебные строки; названия механик в подсказках. Полосы и значки вместо цифр, у корпуса число осталось. Подсказки всех 50 миссий и описания угроз переписаны коротко. Меню разработчика скрыто. Справочник — семь разделов. Настройки — одной кнопкой и на ПК.</dd><dt>1.0.0 α</dt>",1)
if '1.1.0 α' not in LOG: sys.exit('m24: log insert failed')
RX("// справочник\nconst CX_TABS=","function drawIcons(){",r"""// справочник (1.1.0: семь разделов, коротко; «Версии» — только в режиме разработчика)
const CX_TABS=[['ctrl','УПРАВЛЕНИЕ'],['world','МИР'],['threat','УГРОЗЫ'],['mods','МОДУЛИ'],['endless','БЕСКОНЕЧНОСТЬ'],['chron','ХРОНИКА'],['journals','ЖУРНАЛЫ'],['log','ВЕРСИИ']];
let cxTab='ctrl',codexFrom='menu';
function cxTabs(){return CX_TABS.filter(([k])=>k!=='log'||devUnlocked()||cxTab==='log');}
function openCodex(from){codexFrom=from;G.state='codex';$('#cxTabs').innerHTML=cxTabs().map(([k,n])=>`<button class="tab ${k===cxTab?'on':''}" data-t="${k}">${n}</button>`).join('');renderCodex();show('sCodex');}
function closeCodex(){if(codexFrom==='pause'){G.state='pause';renderSettings();show('sPause');}else toMenu();}
const kv=a=>`<dl class="kv">${a.filter(Boolean).map(([t,d])=>`<dt>${t}</dt><dd>${d}</dd>`).join('')}</dl>`;
function renderCodexWorld(B){
  const S=G.save&&validSave(G.save)?G.save:null,F=touchMode?'кнопку над рывком':'F';
  if(cxTab==='world')B.innerHTML=kv([
    ['Сектора','Двенадцать секторов, пятьдесят миссий. Следующая миссия открывается после предыдущей, следующий сектор — после последней миссии текущего. Закрытое скрыто туманом.'],
    ['Узлы','Каждая миссия — источник сигнала. Голубой — пройден, янтарный — доступен. Подлетите и нажмите '+F+'.'],
    ['Модули и перки','Модули действуют до конца миссии: часть выбирается на брифинге, остальные — за осколки данных в бою. Перки мастерской — навсегда.'],
    ['Маяк','Миссии 7–10. Стойте в кольце вокруг маяка, чтобы заряжать его, и везите туда энергоячейки. На рисках шкалы маяк вспыхивает и даёт модуль маяка. Маяк разрушен — провал.'],
    ['Метки','Ромб — враг летит к маяку, треугольник — охотится на вас, кольцо — диверсант.'],
    ['Предметы','Осколки данных — опыт модулей. Энергоячейка — заряд импульса, на миссиях с маяком — груз для маяка. Ремкомплект — ремонт корпуса.'],
    ['Лом','Обломки и награды. Лом при себе сдаётся в мастерской или при входе в миссию. Погибли — лом остаётся на месте гибели.'],
    ['Медали','Прохождение, чистота (почти без урона), мастерство (своё условие у каждой миссии) и эхо — повтор с усиленными врагами.'],
    ['Сложность','Выбирается на брифинге. Выше сложность — сильнее враги и больше лома.'],
    ['Без ремонта','С сектора III корпус в миссии не чинится. В миссию вы входите целым.'],
    ['Мастерская','Ремонт, перки за лом, контракты и новый цикл.'],
    ['Арсенал «Иней»','Открывается после победы над боссом Холодного архива: улучшения орудия и второе оружие «Разрыв».'],
    ['Пилот','Опыт пилота растёт за бой, миссии и находки. Уровень пилота открывает скины в Хранилище корпусов.'+(S?' Сейчас — уровень '+S.pilot.lvl+'.':'')],
    ['Находки','Тайники, бортжурналы, фрагменты памяти, аномалии и ретрансляторы. Ретрансляторы раскрывают карту и становятся точками прыжка.'],
    ['Карта',(touchMode?'Кнопка КАРТА':'M')+' — карта. Прыжок к пройденному узлу, мастерской или ретранслятору, если рядом нет врагов.'],
    ['Разлом','За краем секторов пространство нестабильно. В глубине живут Неизвестные: их снаряды смертельны, спасает только рывок.'],
    ['Бездна','Бесконечность на базовом корабле. Вход — за воротами у миссии 10.'],
    ['Новый цикл','Сектор начинается заново: враги сильнее, награды больше. Перки, скины, уровень пилота и лом остаются.']]);
  if(cxTab==='journals'){if(S){renderJournals(B,false);return;}}
  if(cxTab==='journals')B.innerHTML=WORLD.journals.map(j=>S&&S.journals[j.id]?`<div class="cx-row" style="grid-template-columns:minmax(0,1fr)"><div><h4>${j.title}</h4><p>${j.text}</p></div></div>`:`<div class="cx-row" style="grid-template-columns:minmax(0,1fr)"><div><h4 class="lock">ЗАПИСЬ НЕ НАЙДЕНА</h4></div></div>`).join('');
}
$('#cxTabs').addEventListener('click',e=>{const b=e.target.closest('.tab');if(!b)return;cxTab=b.dataset.t;openCodex(codexFrom);});
const GRP_NAME={siege:'К МАЯКУ',hunt:'ОХОТНИК',sab:'ДИВЕРСАНТ'};
function renderCodex(){
  const B=$('#cxBody');if(cxTab==='pilot'||cxTab==='items'||cxTab==='beacon')cxTab='world';
  if(cxTab==='chron'){B.innerHTML=chronicleHTML();return;}if(cxTab==='world'||cxTab==='journals'){renderCodexWorld(B);return;}
  if(cxTab==='endless'){const L=endRecords();B.innerHTML=kv([
    ['Цель','Продержитесь как можно дольше.'],
    ['Ступени','С каждой ступенью врагов больше, появляются новые.'],
    ['Эхо боссов','Время от времени приходит эхо Стража или Глушителя. Пока оно живо, ступень стоит.'],
    ['Корабль','Базовый, без модулей и перков сектора. Прогресс сектора не меняется.']])+
    `<div class="cx-h">ЛУЧШИЕ ЗАБЕГИ</div>`+(L.length?L.map((r,i)=>`<div class="cx-row" style="grid-template-columns:40px minmax(0,1fr)"><div class="eyebrow" style="color:var(--amber)">${pad2(i+1)}</div><div><h4>${mmss(r.t)}<small>СТУПЕНЬ ${r.s} · УНИЧТОЖЕНО ${r.k}</small></h4></div></div>`).join(''):'<p class="note">Забегов пока нет.</p>');return;}
  if(cxTab==='ctrl'&&touchMode&&isMob())B.innerHTML=kv([
    ['СТИК','Коснитесь '+(SET.hand==='l'?'правой':'левой')+' половины экрана — там появится стик. Дальше от центра — быстрее.'],
    ['РЫВОК','Кнопка справа или быстрый свайп по экрану — рывок туда, куда провели. Кольцо — перезарядка.'],
    ['ИМП','Импульс, когда кольцо кнопки заполнено: сносит снаряды и отбрасывает врагов.'],
    ['ЗАРЯД','Удерживайте и отпустите — мощный выстрел насквозь.'],
    ['КАСАНИЕ ВРАГА','Цель. Повторное касание снимает отметку.'],
    ['ОГОНЬ','Сам, по ближайшей цели.'],
    ['В СЕКТОРЕ','Кнопка над рывком: у узла или мастерской — войти, иначе — карта. Держите стик у края в спокойном полёте — корабль полетит сам.'],
    ['НАЗАД','Системная кнопка «назад» — пауза или закрыть экран.']]);
  else if(cxTab==='ctrl')B.innerHTML=kv([
    ['WASD / стрелки','Движение'],['ПРОБЕЛ','Рывок сквозь снаряды'],['E / SHIFT','Импульс, когда шкала полна'],['ПКМ / Q','Удерживать — заряженный выстрел насквозь'],
    ['МЫШЬ','Ручной прицел; наведите на врага — прицел захватит его. T — ручной или авто'],['КЛИК ПО ВРАГУ','Цель; клик по пустому месту снимает отметку'],
    ['F / ENTER','Войти в миссию, открыть мастерскую, начать аномалию'],['R','Войти в режиме «Эхо»'],['1 · 2 · 3 · A','Выбор модуля · автовыбор'],
    ['M / TAB · J','Карта · журналы'],['C','Справочник'],['ESC / P','Пауза'],['F11','Полный экран'],['Огонь','Сам, по ближайшей видимой цели']]);
  if(cxTab==='threat'){let html='',act=0,lk=0;const flush=()=>{if(lk)html+=`<p class="note cx-lockn">Не опознано: ${lk}. Встретьте их в бою.</p>`;lk=0;};
    CODEX_ORDER.forEach(k=>{const d=EDEF[k];if(d.act!==act){flush();act=d.act;html+=`<div class="cx-h">${act===1?'АКТ I · ПУТЬ К СТРАЖУ':act===2?'АКТ II · МАЯК':act===6?'НУЛЕВАЯ ТОЧКА И НУЛЕВОЙ МИГ':act===5?'СЕРДЦЕ КОВЧЕГА И СТЁРТЫЕ БЕРЕГА':act===4?'ПРЕДЕЛ И ИСТОК':'АРХИВ, ХРОНИКИ, КОЛЫБЕЛИ, ФЛОТ'}</div>`;}
      if(!REC.seen.includes(k)){lk++;return;}html+=`<div class="cx-row"><canvas data-icon="${k}" width="128" height="128"></canvas><div><h4>${d.name}${d.grp?`<small>${GRP_NAME[d.grp]}</small>`:''}</h4><p>${d.desc}</p>${d.lore?`<p class="lore">${d.lore}</p>`:''}</div></div>`;});flush();
    html+=`<div class="cx-h">ЭЛИТА · ЦВЕТНОЙ ПУНКТИР</div>`+Object.values(AFX).map(a=>`<div class="cx-row" style="grid-template-columns:110px minmax(0,1fr)"><div class="eyebrow" style="color:${a.col}">- - - -</div><div><h4>${a.name}</h4><p>${a.d[0].toUpperCase()+a.d.slice(1)}.</p></div></div>`).join('');
    B.innerHTML=html;drawIcons();}
  if(cxTab==='mods')B.innerHTML=`<p class="note">Модули действуют до конца миссии. У каждого — несколько уровней.</p>`+Object.values(MODS).map(M=>`<div class="cx-row" style="grid-template-columns:110px minmax(0,1fr)"><div class="eyebrow" style="color:var(--violet)">${M.tag}</div><div><h4>${M.name}</h4><p>${M.d}</p></div></div>`).join('')+
    `<div class="cx-h">МОДУЛИ МАЯКА</div>`+Object.values(BMODS).map(M=>`<div class="cx-row" style="grid-template-columns:110px minmax(0,1fr)"><div class="eyebrow" style="color:var(--amber)">МАЯК</div><div><h4>${M.name}</h4><p>${M.d}</p></div></div>`).join('');
"""+LOG+"""
}
""")
R('<div class="eyebrow">БОРТОВОЙ СПРАВОЧНИК</div>','<div class="eyebrow">СПРАВОЧНИК</div>')
R('.legi span{display:inline-flex;align-items:center;gap:6px}','.legi span{display:inline-flex;align-items:center;gap:6px}\n.cx-lockn{margin:6px 0 4px;opacity:.7}')

# ═══════════════════════════ 8. КАРТА ═══════════════════════════
R("`${(S.cycle||1)>1?'ЦИКЛ '+roman(S.cycle)+' · ':''}МИССИИ ${doneCount()}/${NM} · МЕДАЛИ ${totalMedals()}/${NM*4} · ТАЙНИКИ ${cc}/4 · ЖУРНАЛЫ ${jc}/${WORLD.journals.length} · АНОМАЛИИ ${ac}/3`",
  "`МИССИИ ${doneCount()}/${NM}${(S.cycle||1)>1?' · ЦИКЛ '+roman(S.cycle):''}`")
R('<summary>? ЛЕГЕНДА И УПРАВЛЕНИЕ</summary>','<summary>? ЛЕГЕНДА</summary>')
R('<p class="note">Колесо, кнопки или щипок — масштаб; перетаскивание — прокрутка; нажатие на обзор в углу — перенос вида. Нажмите на точку прыжка (белое кольцо): маяк сектора, пройденный узел, мастерская, ретранслятор. Прыжок невозможен рядом с врагами и в Разломе.</p>',
  '<p class="note">Колесо или щипок — масштаб, перетаскивание — прокрутка. Белое кольцо — точка прыжка: нажмите, чтобы перенестись (не рядом с врагами).</p>')
R('<div class="bar-l eyebrow"><span>КАРТА СЕКТОРОВ</span><span id="mapStat"></span></div>','<div class="bar-l eyebrow"><span>КАРТА</span><span id="mapStat"></span></div>')

# ═══════════════════════════ 8b. МЕЛОЧИ МИРА И МЕНЮ ═══════════════════════════
R('<span id="wSec">СЕКТОР</span>','<span id="wSec"></span>')
R("v<.1?'< 0,1 а.е.':v.toFixed(1).replace('.',',')+' а.е.'","v<1?'рядом':Math.round(v)+' а.е.'")
R("toast('ОТКРЫТЫЙ СЕКТОР','Янтарная стрелка ведёт к доступной миссии. Обломки и патрули дают немного лома, основной доход — миссии и находки. Лом тратят в мастерской. M — карта и прыжки между пройденными узлами. F — взаимодействие.');",
  "toast('ОТКРЫТЫЙ СЕКТОР',touchMode?'Янтарная стрелка ведёт к доступной миссии. Кнопка над рывком — войти или карта.':'Янтарная стрелка ведёт к доступной миссии. M — карта, F — взаимодействие.');")
R("else banner('СЕКТОР · '+sectorName(S.pos.x,S.pos.y),((S.cycle||1)>1?'ЦИКЛ '+roman(S.cycle)+' · ':'')+'ПИЛОТ · УР '+S.pilot.lvl);",
  "else banner(sectorName(S.pos.x,S.pos.y),(S.cycle||1)>1?'ЦИКЛ '+roman(S.cycle):'');")
R("toast('ДВИГАТЕЛИ ПЕРЕНАСТРОЕНЫ','За прохождение уровня 10 скорость корабля навсегда выросла на 15%. Новый цикл её не снимает.'","toast('ДВИГАТЕЛИ ПЕРЕНАСТРОЕНЫ','Корабль навсегда стал быстрее.'")
R("$('#bEndBest').textContent=eb?fmtT(eb.t):'—';","$('#bEndBest').textContent=eb?mmss(eb.t):'';")
R("hintOnce('rust','ИЗНОС КОРПУСА '+wearPct()+'%'","hintOnce('rust','ИЗНОС КОРПУСА'")
R('.setbody{display:grid;gap:18px}','.setbody{display:grid;gap:18px}\n@media (min-width:900px){html:not(.mob) #sSet .wrap{width:min(980px,100%)}html:not(.mob) #sSet .setbody{grid-template-columns:repeat(2,minmax(0,1fr));align-items:start;column-gap:40px}}\n#bEndBest:empty{display:none}')

R("<div class=\"eyebrow\">МИССИЯ 50/${pad2(NM)} · СЕКТОР XII · ${done?'ПРОЙДЕНА':'ДОСТУПНА'}</div>","<div class=\"eyebrow\">МИССИЯ 50${done?' · ПРОЙДЕНА':''}</div>")

R("$('#cycNote').textContent=`В цикле ${roman(n)}: лом и опыт пилота ×${Math.min(2,1+.25*(n-1)).toFixed(2).replace('.',',')}, прочность врагов ×${Math.min(1.5,1+.1*(n-1)).toFixed(1).replace('.',',')}, число врагов ×${Math.min(1.25,1+.05*(n-1)).toFixed(2).replace('.',',')}.`;",
  "$('#cycNote').textContent=`В цикле ${roman(n)} враги сильнее и их больше, а лома и опыта — больше.`;")
R("'КАПСУЛЫ · ПОСТОЙТЕ РЯДОМ 1,5 С'","'КАПСУЛЫ · ПОСТОЙТЕ РЯДОМ'")
R("setT('enT',Math.floor(p.en)+'%');","",3)

# телефон в альбомной: строка рекордов скрыта, но предупреждение «СОХРАНИТЕ КОД» видно всегда
R(".ff-phone-l #sMenu .genre,.ff-phone-l #sMenu .log,.ff-phone-l #sMenu #recLine{display:none}",".ff-phone-l #sMenu .genre,.ff-phone-l #sMenu .log{display:none}.ff-phone-l #sMenu #recLine span:not(.warn){display:none}")

# ═══════════════════════════ 9. ДАННЫЕ: подсказки миссий, теги, описания угроз и модулей ═══════════════════════════
DATA=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'m24data.js'),encoding='utf8').read()
k=s.index('<script>');k2=s.index('</script>',k)
s=s[:k2]+'\n'+DATA+'\n'+s[k2:]

open(P,'w',encoding='utf8').write(s)
print('m24 ok')
