# 0.6.0 · часть 4: мобильный HUD, экраны, экран настроек, подключение к кадру
import sys,re
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m4: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)

# ---------- настройки: новые ключи с умолчаниями и проверкой типов ----------
R("const SET=Object.assign({amb:true,ambVol:.6,sfx:false,fx:true,manual:true,radio:true},store('void_settings')||{});",
r"""const SET_DEF={amb:true,ambVol:.6,sfx:false,fx:true,manual:true,radio:true,zoom:1,btnSize:1,btnAlpha:.7,hand:'r',stick:'float',dashSwipe:true,haptics:true,oneHand:false,quality:'auto',fps:60,textScale:1};
const SET_OPT={zoom:[.85,1,1.15],btnSize:[.85,1,1.2],btnAlpha:[.45,.7,1],hand:['r','l'],stick:['float','fixed'],quality:['auto',0,1,2],fps:[60,30],textScale:[1,1.15,1.3]};
const SET=Object.assign({},SET_DEF,(()=>{const v=store('void_settings');return v&&typeof v==='object'&&!Array.isArray(v)?v:{};})());
for(const k in SET_DEF){const d=SET_DEF[k];if(SET_OPT[k]){if(!SET_OPT[k].includes(SET[k]))SET[k]=d;}else if(typeof SET[k]!==typeof d||(typeof d==='number'&&!Number.isFinite(SET[k])))SET[k]=d;}
if(SET.ambVol<0||SET.ambVol>1)SET.ambVol=SET_DEF.ambVol;""")

# ---------- фокус кнопок только с клавиатуры (на iOS фокус прокручивает и рисует рамку) ----------
s,n=re.subn(r"\$\('#(\w+)'\)\.focus\(\)",r"(touchMode||$('#\1').focus())",s)
if n<5: sys.exit('m4: focus %d'%n)
R("show('sLevel');const f=$('#cards .card');if(f)f.focus();","show('sLevel');const f=$('#cards .card');if(f&&!touchMode)f.focus();",2)

# ---------- разметка: экран настроек, кнопки «НАСТРОЙКИ» / «ЕЩЁ», вкладки мастерской, строка паузы ----------
R('      <button class="btn" id="bSave">КОД СОХРАНЕНИЯ</button>',
  '      <button class="btn" id="bSave">КОД СОХРАНЕНИЯ</button>\n      <button class="btn mobonly" id="bSettings">НАСТРОЙКИ</button>\n      <button class="btn mobonly" id="bMore">ЕЩЁ · НОВЫЙ ПОЛЁТ, КОД, ВЫБОР МИССИЙ</button>')
R('      <button class="btn" id="bPauseCodex">СПРАВОЧНИК</button>',
  '      <button class="btn" id="bPauseCodex">СПРАВОЧНИК</button>\n      <button class="btn mobonly" id="bPauseSet">НАСТРОЙКИ</button>')
R('    <div class="eyebrow">ПАУЗА</div>','    <div class="eyebrow">ПАУЗА</div>\n    <div class="pstat mobonly" id="pauseStat"></div>')
R('<div class="cx-h2">КОНТРАКТЫ · ОТПРАВИТЕЛЬ: Н.</div>','<div class="cx-h2" id="shopConH">КОНТРАКТЫ · ОТПРАВИТЕЛЬ: Н.</div>')
R('    <div id="shopPerks"></div>','    <div class="seg mobonly" id="shopTabs"><button data-st="perks" class="on">ПЕРКИ</button><button data-st="con">КОНТРАКТЫ</button><button data-st="cyc" id="shopTabCyc">ЦИКЛ</button><span id="shopTabsLom"></span></div>\n    <div id="shopPerks"></div>')
R('    <div class="btns"><button class="btn" id="bSaveCopy">СКОПИРОВАТЬ КОД</button></div>',
  '    <div class="btns"><button class="btn" id="bSaveCopy">СКОПИРОВАТЬ КОД</button><button class="btn mobonly" id="bSaveShare" hidden>ПОДЕЛИТЬСЯ КОДОМ</button></div>')
R('    <textarea id="saveIn" placeholder="Вставьте код сохранения сюда"></textarea>',
  '    <textarea id="saveIn" placeholder="Вставьте код сохранения сюда"></textarea>\n    <div class="btns mobonly" id="savePasteRow" hidden><button class="btn" id="bSavePaste">ВСТАВИТЬ ИЗ БУФЕРА</button></div>')
R('<!-- Выбор миссий (разработка) -->',
  '<!-- Настройки (0.6.0, телефон и планшет) -->\n<section class="screen" id="sSet" hidden>\n  <div class="wrap">\n    <div class="eyebrow">НАСТРОЙКИ</div>\n    <h2>Настройки</h2>\n    <div class="setbody" id="setBody"></div>\n    <div class="btns"><button class="btn primary" id="bSetBack">ГОТОВО</button></div>\n  </div>\n</section>\n<!-- Выбор миссий (разработка) -->')
R("const SCREENS=['sMenu','sCodex','sIntro','sLevel','sDone','sPause','sOver','sMap','sShop','sSave','sDev','sHangar','sCycle','sReport'];",
  "const SCREENS=['sMenu','sCodex','sIntro','sLevel','sDone','sPause','sOver','sMap','sShop','sSave','sDev','sHangar','sCycle','sReport','sSet'];")

# ---------- настройки: на телефоне — отдельный экран; в меню и паузе — пусто ----------
R("function renderSettings(){\n  document.querySelectorAll('[data-settings]').forEach(box=>{\n    box.innerHTML=`",
  "function renderSettings(){\n  document.querySelectorAll('[data-settings]').forEach(box=>{\n    if(isMob()&&box.closest('#sMenu,#sPause')){if(box.innerHTML)box.innerHTML='';return;}\n    box.innerHTML=`")
R("<span>ПРИЦЕЛ МЫШЬЮ · T</span>","<span>${touchMode?'ПРИЦЕЛ · НА ТЕЛЕФОНЕ ВСЕГДА АВТО':'ПРИЦЕЛ МЫШЬЮ · T'}</span>")
R("+(box.closest('#sMenu')?resetBlock():'');\n  });\n}",
r"""+(box.closest('#sMenu')?resetBlock():'');
  });
  renderSetScreen();
}
// ---- экран настроек (0.6.0) ----
const SEGS={zoom:[['ЭКРАН · МАСШТАБ',[[.85,'КРУПНЕЕ'],[1,'СТАНДАРТ'],[1.15,'ДАЛЬШЕ']]]],textScale:[['ЭКРАН · ТЕКСТ',[[1,'ОБЫЧНЫЙ'],[1.15,'КРУПНЫЙ'],[1.3,'ОЧЕНЬ КРУПНЫЙ']]]],
  quality:[['ЭКРАН · КАЧЕСТВО',[['auto','АВТО'],[0,'ЭКОНОМ'],[1,'СТАНДАРТ'],[2,'ВЫСОКОЕ']]]],fps:[['ЭКРАН · КАДРЫ',[[60,'60'],[30,'30 · ЭКОНОМИЯ БАТАРЕИ']]]],
  btnSize:[['УПРАВЛЕНИЕ · РАЗМЕР КНОПОК',[[.85,'МЕНЬШЕ'],[1,'СТАНДАРТ'],[1.2,'КРУПНЕЕ']]]],btnAlpha:[['УПРАВЛЕНИЕ · ПРОЗРАЧНОСТЬ КНОПОК',[[.45,'СИЛЬНАЯ'],[.7,'СРЕДНЯЯ'],[1,'НЕТ']]]],
  hand:[['УПРАВЛЕНИЕ · РУКА',[['r','ПРАВАЯ'],['l','ЛЕВАЯ · ЗЕРКАЛО']]]],stick:[['УПРАВЛЕНИЕ · СТИК',[['float','ПЛАВАЮЩИЙ'],['fixed','ЗАКРЕПЛЁННЫЙ']]]]};
function segHTML(k){const [lab,opts]=SEGS[k][0];return `<div class="setrow"><div class="eyebrow">${lab}</div><div class="seg" data-seg="${k}">${opts.map(([v,n])=>`<button data-v="${v}" class="${String(SET[k])===String(v)?'on':''}">${n}</button>`).join('')}</div></div>`;}
function togHTML(k,lab,on,off){return `<button class="tog ${SET[k]?'on':''}" data-k="${k}"><span>${lab}</span><span>${SET[k]?(on||'ВКЛ'):(off||'ВЫКЛ')}</span></button>`;}
function renderSetScreen(){const B=$('#setBody');if(!B||G.state!=='settings')return;const ios=/iP(hone|ad|od)/.test(navigator.userAgent)||navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1;
  B.innerHTML=`<div class="setgrp"><div class="cx-h2">ЗВУК</div>${togHTML('amb','МУЗЫКА'+(MUS.lastName&&SET.amb?' · «'+MUS.lastName+'»':''))}
      <label class="vol"><span>ГРОМКОСТЬ МУЗЫКИ</span><input type="range" min="0" max="1" step="0.05" value="${SET.ambVol}" data-vol id="vol-sSet"></label>${togHTML('sfx','ЗВУКИ')}
      ${ios?'<p class="note">Нет звука на iPhone? Проверьте переключатель беззвучного режима сбоку.</p>':''}</div>
    <div class="setgrp"><div class="cx-h2">УПРАВЛЕНИЕ</div>${segHTML('btnSize')}${segHTML('btnAlpha')}${segHTML('hand')}${segHTML('stick')}
      ${togHTML('dashSwipe','РЫВОК СВАЙПОМ СПРАВА')}${togHTML('oneHand','ИГРА ОДНОЙ РУКОЙ · РЕЗКИЙ ВЗМАХ СТИКОМ = РЫВОК')}${navigator.vibrate?togHTML('haptics','ВИБРАЦИЯ'):''}</div>
    <div class="setgrp"><div class="cx-h2">ЭКРАН</div>${segHTML('zoom')}${segHTML('textScale')}${segHTML('quality')}${segHTML('fps')}${togHTML('fx','ЭФФЕКТЫ · частицы и тряска')}
      ${document.fullscreenEnabled?`<button class="tog" id="bFull"><span>НА ВЕСЬ ЭКРАН</span><span>${document.fullscreenElement?'ВКЛ':'ВЫКЛ'}</span></button>`:ios?'<p class="note">На весь экран: «Поделиться» → «На экран Домой» — игра откроется без адресной строки.</p>':''}</div>
    <div class="setgrp"><div class="cx-h2">ПРОЧЕЕ</div>${togHTML('radio','ПЕРЕХВАТЫ · радиоэфир')}${G.setFrom==='menu'?resetBlock():''}</div>`;}
function applySettings(){document.documentElement.style.setProperty('--fs',SET.textScale||1);ffUpdate();resize();layoutTouch();}
function openSettings(from){G.setFrom=from;G.setPrev=G.state;G.state='settings';renderSetScreen();show('sSet');}
function closeSettings(){if(G.state!=='settings')return;if(G.setFrom==='pause'){G.state='pause';renderSettings();show('sPause');}else{toMenu();}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-seg] [data-v]');if(!b)return;const k=b.closest('[data-seg]').dataset.seg,raw=b.dataset.v,opts=SET_OPT[k];if(!opts)return;
  const v=opts.find(o=>String(o)===raw);if(v===undefined)return;SET[k]=v;saveSet();applySettings();renderSetScreen();buzz('tap');});
document.addEventListener('click',e=>{if(!e.target.closest('#bFull'))return;try{if(document.fullscreenElement)document.exitFullscreen();else document.documentElement.requestFullscreen({navigationUI:'hide'}).catch(()=>{});}catch(err){}setTimeout(renderSetScreen,300);});
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&(G.state==='play'||G.state==='world')&&isMob())pause();});""")

# ---------- кнопки меню и паузы ----------
R("$('#bSave').onclick=openSaveScreen;",
  "$('#bSave').onclick=openSaveScreen;$('#bSettings').onclick=()=>openSettings('menu');$('#bMore').onclick=()=>{$('#sMenu').classList.toggle('more');$('#bMore').textContent=$('#sMenu').classList.contains('more')?'СКРЫТЬ':'ЕЩЁ · НОВЫЙ ПОЛЁТ, КОД, ВЫБОР МИССИЙ';};$('#bPauseSet').onclick=()=>openSettings('pause');$('#bSetBack').onclick=closeSettings;")
# опасные действия паузы на касаниях — вторым нажатием
R("$('#bResume').onclick=resume;$('#bRestart').onclick=()=>{",
  "function confirm2(el,f){return e=>{if(!touchMode||!isMob())return f(e);const now=performance.now();if(el.dataset.arm&&now-+el.dataset.arm<3000){el.dataset.arm='';el.textContent=el.dataset.lab;return f(e);}el.dataset.arm=now;el.dataset.lab=el.dataset.lab||el.textContent;el.textContent='ТОЧНО? НАЖМИТЕ ЕЩЁ РАЗ';setTimeout(()=>{if(el.dataset.arm&&performance.now()-+el.dataset.arm>=2900){el.dataset.arm='';el.textContent=el.dataset.lab;}},3000);};}\n$('#bResume').onclick=resume;$('#bRestart').onclick=()=>{")
R("$('#bPauseCodex').onclick=()=>openCodex('pause');$('#bQuit').onclick=toMenu;",
  "$('#bPauseCodex').onclick=()=>openCodex('pause');$('#bQuit').onclick=toMenu;\n['bRestart','bAbandon','bQuit'].forEach(id=>{const el=$('#'+id),f=el.onclick;el.onclick=confirm2(el,f);});")
R("  show('sPause');(touchMode||$('#bResume').focus());",
  "  ['bRestart','bAbandon','bQuit'].forEach(id=>{const el=$('#'+id);if(el.dataset.arm){el.dataset.arm='';el.textContent=el.dataset.lab;}el.dataset.lab='';});\n  {const S=G.save;$('#pauseStat').textContent=G.pausedWorld&&S?`ПИЛОТ УР ${S.pilot.lvl} · МИССИИ ${doneCount()}/${NM} · МЕДАЛИ ${totalMedals()}/${NM*4}`+(S.carry?` · ТРЮМ ${fmtN(S.carry)}`:''):G.mode==='endless'?`СТУПЕНЬ ${G.end?G.end.step:1} · УНИЧТОЖЕНО ${G.kills} · МОДУЛИ УР ${G.lvl}`:`МИССИЯ ${pad2(G.m)} · МОДУЛИ УР ${G.lvl} · ОЧКИ ${fmt(G.score)}`;}\n  show('sPause');(touchMode||$('#bResume').focus());")

# ---------- брифинг: остальные подсказки и строка множителей — по нажатию ----------
R("renderDiff();show('sIntro');(touchMode||$('#bGo').focus());",
  "renderDiff();if(isMob()&&M.hint.length>1){$('#inHint').insertAdjacentHTML('beforeend',`<button class=\"rbtn more mobonly\" id=\"bHintMore\">ЕЩЁ ПОДСКАЗКИ · ${M.hint.length-1}</button>`);}$('#inHint').classList.remove('open');show('sIntro');(touchMode||$('#bGo').focus());")
R("$('#inDiff').addEventListener('click',e=>{",
  "$('#inHint').addEventListener('click',e=>{if(e.target.closest('#bHintMore')){$('#inHint').classList.add('open');e.target.remove();}});\n$('#inDiffNote').addEventListener('click',()=>$('#inDiffNote').classList.toggle('open'));\n$('#inDiff').addEventListener('click',e=>{")

# ---------- мастерская: вкладки на телефоне ----------
R("function renderShop(){\n  const S=G.save;",
  "function renderShop(){\n  const S=G.save;{const sh=$('#sShop .shop');if(!sh.dataset.st)sh.dataset.st='perks';const cy=S.cleared>=CORE;$('#shopTabCyc').hidden=!cy;if(!cy&&sh.dataset.st==='cyc')sh.dataset.st='perks';$('#shopTabs').querySelectorAll('[data-st]').forEach(b=>b.classList.toggle('on',b.dataset.st===sh.dataset.st));$('#shopTabsLom').innerHTML=lomH(S.lom,1);}")
R("$('#shopCon').addEventListener('click',e=>{",
  "$('#shopTabs').addEventListener('click',e=>{const b=e.target.closest('[data-st]');if(!b)return;$('#sShop .shop').dataset.st=b.dataset.st;renderShop();$('#sShop').scrollTop=0;});\n$('#shopCon').addEventListener('click',e=>{")

# ---------- код сохранения: поделиться и вставить ----------
R("$('#bSaveBack').onclick=()=>toMenu();",
  "$('#bSaveBack').onclick=()=>toMenu();\n$('#bSaveShare').onclick=()=>{const t=$('#saveOut').value;if(!t||!navigator.share)return;navigator.share({title:'VØID · код сохранения',text:t}).catch(()=>{});};\n$('#bSavePaste').onclick=()=>{try{navigator.clipboard.readText().then(v=>{$('#saveIn').value=v||'';$('#saveMsg').textContent=v?'Код вставлен — нажмите «ЗАГРУЗИТЬ КОД».':'Буфер обмена пуст.';},()=>{$('#saveMsg').textContent='Браузер не дал прочитать буфер — вставьте код вручную.';});}catch(e){$('#saveMsg').textContent='Вставьте код вручную.';}};")
R("function openSaveScreen(){","function openSaveScreen(){try{$('#bSaveShare').hidden=!navigator.share;$('#savePasteRow').hidden=!(navigator.clipboard&&navigator.clipboard.readText);}catch(e){}")

# ---------- справочник: управление касаниями ----------
R("  if(cxTab==='ctrl')B.innerHTML=`<dl class=\"kv\">",
  "  if(cxTab==='ctrl'&&touchMode&&isMob()){B.innerHTML=`<dl class=\"kv\"><dt>СТИК</dt><dd>Коснитесь левой половины экрана${SET.hand==='l'?' (в режиме левши — правой)':''} — там появится стик. Чем дальше палец от центра, тем быстрее корабль; у самого центра — мёртвая зона для точного маневра. Палец можно вести дальше края — стик поедет следом.</dd><dt>РЫВОК</dt><dd>Большая кнопка справа или быстрый свайп по правой половине экрана — рывок туда, куда провели. Кольцо вокруг кнопки и вокруг корабля — перезарядка.</dd><dt>ИМП</dt><dd>Импульс при полном накопителе: кольцо кнопки заполняется, готовность подсвечивается янтарём.</dd><dt>ЗАРЯД</dt><dd>С миссии 2: удерживайте кнопку 1,2 с и отпустите — выстрел ×6, пробивает всех, кроме щитов. Пока держите, автоогонь молчит и скорость −30%.</dd><dt>КАСАНИЕ ВРАГА</dt><dd>Приоритетная цель; повторное касание снимает отметку.</dd><dt>ОГОНЬ</dt><dd>Автоматический, по ближайшей цели.</dd><dt>В СЕКТОРЕ</dt><dd>Кнопка над рывком: у узла, мастерской или аномалии — «ВОЙТИ / ОТКРЫТЬ / НАЧАТЬ», иначе — карта. Миникарта тоже открывает карту. Держите стик у края 2,5 с в спокойном полёте — появится «КУРС», отпустите палец, и корабль продолжит лететь сам до первой угрозы.</dd><dt>НАЗАД</dt><dd>Системная кнопка или жест «назад» — пауза, закрыть карту или экран.</dd><dt>НАСТРОЙКИ</dt><dd>Масштаб, размер и прозрачность кнопок, режим левши, закреплённый стик, игра одной рукой, вибрация, качество и 30 кадров — в меню «НАСТРОЙКИ».</dd></dl>`;}\n  else if(cxTab==='ctrl')B.innerHTML=`<dl class=\"kv\">")

# ---------- карта: высота под экран телефона ----------
R("  const w=Math.max(200,c.clientWidth),h=Math.round(w<520?Math.min(w*1.15,innerHeight*.62):Math.min(w*.56,innerHeight*.62));",
  "  const w=Math.max(200,c.clientWidth),h=isMob()?Math.max(180,Math.round(innerHeight-c.getBoundingClientRect().top-(innerWidth>innerHeight?64:96)-SAFE.b)):Math.round(w<520?Math.min(w*1.15,innerHeight*.62):Math.min(w*.56,innerHeight*.62));")
R("  L.open=innerWidth>640;}","  L.open=innerWidth>640&&!isMob();}")

# ---------- мир: важная подстрока, миникарта = карта ----------
R("  setT('wSub',sub);\n  hudEls.score.firstChild.nodeValue=fmt(G.score);",
  "  setT('wSub',sub);setC('hud0','subimp',!!G.anom);\n  hudEls.score.firstChild.nodeValue=fmt(G.score);")
R("const hudEls={};['hpT',","const hudEls={hud0:document.getElementById('hud')};['hpT',")
R("function drawMini(){","$('#mini').addEventListener('click',()=>{if(G.state==='world'&&isMob())openMap();});\nfunction drawMini(){")

# ---------- кадр: тик телефона, отсчёт, 30 кадров, экранный слой ----------
R("""function frame(now){
  const dt=Math.min(.05,Math.max(0,(now-last)/1000));last=now;""",
r"""function camZTarget(){if(!isMob()||(RMQ&&RMQ.matches))return 1;if(G.state==='play'&&!G.world)return (G.sb&&G.sb.alive&&G.sb.st!=='enter')||(G.boss&&G.boss.alive)||(G.jam&&G.jam.alive)?1.15:1;if(G.state==='world')return G.calm>3?1.1:1;return G.camZ||1;}
function mobTick(dt,now){
  if(G.resumeK>0&&(G.state==='play'||G.state==='world'))G.resumeK=Math.max(0,G.resumeK-dt);else if(G.state!=='pause')G.resumeK=0;
  const zt=camZTarget(),z=G.camZ||1;if(Math.abs(zt-z)>.001){G.camZ=z+clamp(zt-z,-.15*dt,.15*dt);setScale();}
  touchTick(dt);if(typeof qTick==='function')qTick(dt,now);}
function frame(now){
  if(isMob()&&SET.fps===30&&now-last<29&&now>=last){requestAnimationFrame(frame);return;}
  const dt0=Math.min(.05,Math.max(0,(now-last)/1000));last=now;
  try{mobTick(dt0,now);}catch(err){console.error(err);}
  const dt=G.resumeK>0&&(G.state==='play'||G.state==='world')?dt0*.3:dt0,sub=isMob()&&SET.fps===30&&dt>.025?2:1;""")
R("  try{if(G.state==='play'){const reps=devOn('speed')?2:1;for(let r=0;r<reps&&G.state==='play';r++)update(dt);if(G.mode==='endless')updateEndlessHUD();else updateHUD();}\n    else if(G.state==='world'){if(G.prologue)prologueTick(dt);else{worldUpdate(dt);updateWorldHUD();}}",
  "  try{if(G.state==='play'){const reps=(devOn('speed')?2:1)*sub;for(let r=0;r<reps&&G.state==='play';r++)update(dt/sub);if(G.mode==='endless')updateEndlessHUD();else updateHUD();}\n    else if(G.state==='world'){if(G.prologue)prologueTick(dt);else{for(let r=0;r<sub&&G.state==='world';r++)worldUpdate(dt/sub);updateWorldHUD();}}")
R("  try{if(G.world&&G.player)renderWorld(now);else{render(now);secVignette();}drawDevOverlay();}catch(err){console.error(err);}",
  "  try{if(G.world&&G.player)renderWorld(now);else{render(now);secVignette();}mobOverlay(now);drawDevOverlay();}catch(err){console.error(err);}")
R("resize();renderSettings();renderMenu();show('sMenu');requestAnimationFrame(frame);",
  "document.documentElement.style.setProperty('--fs',SET.textScale||1);resize();renderSettings();renderMenu();show('sMenu');requestAnimationFrame(frame);")

# ---------- CSS: HUD и экраны на телефоне ----------
CSS=r"""
/* --- 0.6.0: HUD на телефоне --- */
.mob #hud{font-size:12px;letter-spacing:.06em}
.mob .hud-tl{top:calc(10px + var(--sat));left:max(14px,var(--sal));width:min(210px,32vw);gap:5px}
.ff-phone-p .hud-tl{width:calc(100% - 82px - max(14px,var(--sal)) - max(12px,var(--sar)))}
.mob .bar.hp{height:8px}
.mob #hpT{font-size:13px}
[data-input=touch].mob .hud-tl>.bar-l:nth-child(3),[data-input=touch].mob #enBar{display:none}
.mob .hud-tc,.mob #hud .hud-e{top:calc(10px + var(--sat));width:min(300px,34vw)}
.ff-phone-p .hud-tc,.ff-phone-p #hud .hud-e{top:calc(52px + var(--sat));left:max(14px,var(--sal));transform:none;width:calc(100% - 118px - max(14px,var(--sal)));text-align:left}
.mob #misT{display:none}
.mob .hud-tc .bar-l{justify-content:center}.ff-phone-p .hud-tc .bar-l{justify-content:flex-start}
.mob #eTime{font-size:24px}
.mob .hud-tr{top:calc(8px + var(--sat));right:max(12px,var(--sar));gap:8px}
.mob #btnPause{width:44px;height:44px;position:relative}
.mob #btnPause::after{content:'';position:absolute;inset:-6px}
[data-input=touch].mob #btnMap{display:none}
.mob #hud:not(.endless) #score{display:none}
.mob #mini{top:calc(60px + var(--sat));right:max(12px,var(--sar));width:96px;height:96px;pointer-events:auto;cursor:pointer}
.ff-phone-p #mini{width:80px;height:80px;top:calc(58px + var(--sat))}
.mob #hud .hud-w{top:calc(162px + var(--sat));left:auto;right:max(12px,var(--sar));transform:none;width:auto;max-width:46vw;text-align:right}
.ff-phone-p #hud .hud-w{top:calc(144px + var(--sat))}
.mob #hud .hud-w .bar-l{justify-content:flex-end}
.mob #wSec,.mob #hud .wsub{display:none}
.mob #hud.subimp .wsub{display:block;font-size:12px;color:#c9a6ff}
.mob #wLom .lom.big{font-size:16px}
.mob .hud-b{left:max(14px,var(--sal));right:auto;bottom:auto;top:calc(var(--sat) + 52px);display:flex;flex-direction:column;align-items:flex-start;gap:6px}
.ff-phone-p .hud-b{top:calc(var(--sat) + 92px)}
[data-input=touch].mob #dashC,[data-input=touch].mob #pulseC,[data-input=touch].mob #chgC,[data-input=touch].mob #aimC,[data-input=touch].mob #comboC,[data-input=touch].mob #lvC{display:none!important}
.mob .chips{gap:6px}
.mob .chip{font-size:12px;padding:4px 8px}
.mob .bar.xp{position:fixed;top:var(--sat);left:0;right:0;height:3px;border:0}
.mob #radio{left:max(14px,var(--sal));top:calc(var(--sat) + 84px);bottom:auto;max-width:min(420px,44vw);font-size:12px}
.ff-phone-p #radio{top:calc(var(--sat) + 124px);max-width:calc(100% - 120px)}
.mob #banner{top:15%}
.mob #banner b{font-size:clamp(18px,5vw,26px)}
.mob #banner span{font-size:12px;letter-spacing:.16em}
.ff-phone-l #toast{top:calc(var(--sat) + 48px);left:50%;transform:translateX(-50%);width:min(380px,44vw)}
.ff-phone-p #toast{top:calc(var(--sat) + 148px);left:max(14px,var(--sal));width:calc(100% - 28px)}
.mob #toast p{font-size:13px}
.mob #wcard{padding:10px 12px;gap:6px;width:min(360px,40vw);bottom:calc(var(--sab) + 12px)}
.ff-phone-p #wcard{width:calc(100% - 28px);bottom:calc(40% + 8px)}
.mob #wcard .medals,.mob #wcard .note{display:none}
.mob #wcard p{font-size:12px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.mob #wcard h3{font-size:14px}
.mob #wcard .eyebrow{font-size:12px}
.mob .wbtn{min-height:44px;font-size:12px}
.mob #memo{font-size:13px}
.mob #fragTxt{font-size:15px}
/* --- 0.6.0: экраны на телефоне --- */
.mob .screen{background:rgba(4,6,12,.94);padding:calc(16px + var(--sat)) max(16px,var(--sar)) calc(16px + var(--sab)) max(16px,var(--sal));align-items:flex-start;overscroll-behavior:contain}
.mob .screen.dim{background:rgba(4,6,12,.86)}
.mob .wrap,.mob .codex,.mob .shop{margin:0 auto;width:min(620px,100%);gap:16px}
.mob .eyebrow{font-size:calc(12px*var(--fs));letter-spacing:.14em;color:#5a9ab3}
.mob h2{font-size:calc(24px*var(--fs))}
.mob .btns{max-width:none;width:100%}
.mob .btn{min-height:48px;font-size:calc(14px*var(--fs));padding:12px 16px;letter-spacing:.1em}
.mob .btn.primary{min-height:54px;font-size:calc(15px*var(--fs));order:99}
.mob .screen .wrap>.btns,.mob .codex>.btns,.mob .mapwrap>.btns,.mob .shop>.btns{position:sticky;bottom:calc(-16px - var(--sab));z-index:2;padding:14px 0 calc(16px + var(--sab));margin-bottom:calc(-16px - var(--sab));background:linear-gradient(rgba(4,6,12,0),rgba(4,6,12,.97) 26%)}
.mob .tog{min-height:48px;font-size:calc(13px*var(--fs))}
.mob .vol{min-height:48px;font-size:calc(13px*var(--fs))}
.mob .tab,.mob .maptabs button{min-height:44px;font-size:calc(12px*var(--fs))}
.mob .wbtn,.mob .rbtn{min-height:44px;font-size:calc(12px*var(--fs))}
.mob .seg{font-size:calc(12px*var(--fs))}
.mob .seg button{min-height:44px;min-width:44px;font-size:calc(12px*var(--fs));letter-spacing:.06em}
.mob .seg button.on{border-color:var(--ice);color:var(--ice)}
.mob .skin{min-height:48px;font-size:calc(12px*var(--fs))}
.mob .mapctl{bottom:auto;top:50%;transform:translateY(-50%)}
.mob .mapctl button{width:48px;height:48px}
.mob .card{min-height:44px}
.mob p,.mob .note,.mob .card p,.mob .perk p,.mob .cx-row p,.mob .hint p,.mob .kv{font-size:calc(14px*var(--fs))}
.mob .chip,.mob .badge,.mob #eStep,.mob #eRec,.mob .genre,.mob .log,.mob .rec,.mob .settings,.mob .cx-h,.mob .cx-h2,.mob .card .k,.mob .card .fx,.mob .stats div,.mob .tag,.mob .legi,.mob .mapleg summary,.mob .maplegend,.mob .jhull,.mob .jr .meta,.mob .rwarn,.mob #mapTip,.mob .kv dt,.mob .alphaJump,.mob .bar-l,.mob .rnote,.mob .rchk,.mob textarea,.mob .cx-row h4 small,.mob .devm small{font-size:calc(12px*var(--fs))}
.mob textarea{font-size:16px}
.mob .cx-row .lock{color:#6a7b90}
.mob .cx-row{grid-template-columns:48px minmax(0,1fr)}
.mob .cx-row canvas{width:48px;height:48px}
.mob .pstat{font:600 calc(12px*var(--fs)) var(--f-mono);color:var(--muted);letter-spacing:.08em}
/* меню */
.mob #sMenu .log{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.mob #sMenu:not(.more) #bWorldNew,.mob #sMenu:not(.more) #bSave,.mob #sMenu:not(.more) #bDev{display:none!important}
.mob #sMenu #bMore{order:50}.mob #sMenu #bSettings{order:40}
.mob #sMenu .btn{order:10}.mob #sMenu #bWorldNew,.mob #sMenu #bSave,.mob #sMenu #bDev{order:60}
.ff-phone-l #sMenu .wrap{grid-template-columns:minmax(0,1fr) minmax(0,1fr);column-gap:28px;width:100%;max-width:900px;align-items:start}
.ff-phone-l #sMenu .wrap>*{grid-column:1}
.ff-phone-l #sMenu .wrap>.btns{grid-column:2;grid-row:1 / span 6;position:static;margin:0;padding:0;background:none}
.ff-phone-l #sMenu .logo{font-size:64px}
.ff-phone-p #sMenu .logo{font-size:clamp(56px,20vw,96px)}
/* брифинг */
.mob #inHint:not(.open) p:nth-child(n+2){display:none}
.mob #inHint .more{justify-self:start}
.mob #inDiffNote:not(.open){display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;cursor:pointer}
/* выбор модуля */
.mob .lvwrap{width:100%;gap:12px}
.mob .cards{gap:10px}
.ff-phone-p .card{padding:12px 14px;gap:6px}
.ff-phone-p .card p{font-size:calc(13px*var(--fs))}
.ff-phone-l .card{padding:12px;gap:6px}
.ff-phone-l .card p{font-size:calc(13px*var(--fs))}
/* итоги */
.mob .stats{grid-template-columns:1fr 1fr}
/* карта */
.mob .mapwrap{width:100%;gap:8px}
.mob #mapC{aspect-ratio:auto}
/* мастерская */
.mob #shopTabs{position:sticky;top:calc(-16px - var(--sat));z-index:2;background:rgba(4,6,12,.97);padding:10px 0;margin:-4px 0 0;gap:6px}
.mob #shopTabsLom{margin-left:auto;font-size:calc(14px*var(--fs))}
.mob .shop[data-st=perks] #shopConH,.mob .shop[data-st=perks] #shopCon,.mob .shop[data-st=perks] #shopCycle,.mob .shop[data-st=con] #shopPerks,.mob .shop[data-st=con] #shopCycle,.mob .shop[data-st=cyc] #shopPerks,.mob .shop[data-st=cyc] #shopConH,.mob .shop[data-st=cyc] #shopCon{display:none}
.mob .perk{gap:6px 12px}
/* Хранилище */
.mob .skingrid{max-height:none;overflow:visible;grid-template-columns:repeat(auto-fill,minmax(150px,1fr))}
/* справочник */
.mob .codex{max-height:none}
.mob .tabs{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;margin:0 calc(-1*max(16px,var(--sar))) 0 calc(-1*max(16px,var(--sal)));padding:0 max(16px,var(--sar)) 4px max(16px,var(--sal))}
.mob .tabs::-webkit-scrollbar{display:none}
.mob .tab{flex:0 0 auto}
.mob .cx{max-height:none;overflow:visible}
.mob .kv{grid-template-columns:1fr;gap:4px}
.mob .kv dd{margin:0 0 10px}
/* настройки */
.setbody{display:grid;gap:18px}
.setgrp{display:grid;gap:10px}
.setrow{display:grid;gap:6px}
.mob #sSet .seg button{flex:1 1 auto}
.mob .reset{display:grid;gap:8px}
"""
R("</style>",CSS+"</style>",1)

open(P,'w',encoding='utf8').write(s)
print('m4 ok')
