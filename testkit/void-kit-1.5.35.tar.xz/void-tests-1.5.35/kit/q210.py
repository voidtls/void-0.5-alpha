# 1.2.7 α «Первый вылет»: обучение внутри игры и надпись запрета прыжка. Каждый тест падает на версии 28.
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
# новая игра; ждём конца пролога; w8 — пауза; done(...) — отметить уроки пройденными
NEW="""async(o)=>{o=o||{};window.w8=ms=>new Promise(r=>setTimeout(r,ms));if(typeof TUT==='undefined')return false;T.fresh();if(o.touch)setInput('touch');if(o.hand)SET.hand=o.hand;if(o.hand)layoutTouch();
  if(!o.calib)G.save.tut.done.calib=1;for(let i=0;i<40&&(G.prologue||G.state!=='world');i++)await w8(100);TUT.hist=[];TUT.gap=0;TUT.log=[];
  window.done=(...ks)=>{for(const k of ks)G.save.tut.done[k]=1;if(TUT.cur&&G.save.tut.done[TUT.cur.k])tutEnd('abort');TUT.gap=0;TUT.hist=[];};window.chipOn=()=>{const c=document.querySelector('#tut .tut-chip');return !!c&&!$('#tut').hidden&&c.classList.contains('on');};
  window.chipBox=()=>{const r=document.querySelector('#tut .tut-chip').getBoundingClientRect();return [r.left,r.top,r.right,r.bottom];};
  window.waitCur=async(k,ms)=>{const t0=performance.now();while(performance.now()-t0<(ms||4000)){if(TUT.cur&&TUT.cur.k===k)return true;await w8(50);}return false;};
  return true;}"""

@test('T01')
async def t01(b):
    P=await newpage(b,1600,900,alpha=False);ok0=await P.js(NEW,{})
    r=await P.js("""async()=>{const on=await waitCur('move',4000);const html=document.querySelector('#tut .tut-keys').innerHTML;const c1=chipOn();
      KEYS.KeyD=true;await w8(1600);KEYS.KeyD=false;await w8(500);return {on,wasd:['W','A','S','D'].every(k=>html.includes('>'+k+'<')),c1,done:!!G.save.tut.done.move,c2:chipOn(),cur:TUT.cur&&TUT.cur.k}}""") if ok0 else {}
    rec('T01 ПК: после пролога урок «move» с клавишами W A S D; пролетел 250 — урок закрыт, подсказка ушла',ok0 and r['on'] and r['wasd'] and r['c1'] and r['done'] and not r['c2'],r)

@test('T02')
async def t02(b):
    out={}
    for hand in ['r','l']:
        P=await newpage(b,390,844,alpha=False,touch=True);ok0=await P.js(NEW,{'touch':1,'hand':hand})
        out[hand]=await P.js("""async()=>{const on=await waitCur('move',4000);await w8(300);const r=document.querySelector('#tut .tut-chip').getBoundingClientRect();const keys=document.querySelector('#tut .tut-keys').innerHTML;
          const I=$('#joyIdle').getBoundingClientRect();return {on,cx:(r.left+r.right)/2,CW,keys,joy:(I.left+I.right)/2,txt:document.querySelector('#tut .tut-txt').textContent}}""") if ok0 else None
    ok=all(out[h] and out[h]['on'] and out[h]['keys']=='' for h in out) and out['r']['joy']<195 and out['l']['joy']>195 and abs(out['r']['cx']-out['r']['joy'])<120 and abs(out['l']['cx']-out['l']['joy'])<120
    rec('T02 телефон: подсказка движения у стика (без клавиш); для левши — справа',ok,out)

@test('T03')
async def t03(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    pc=await P.js("""async()=>{done('move','lom','stash','act','fire');const p=G.player;p.dashCd=0;const shoot=()=>G.eb.push({x:p.x+240,y:p.y,vx:-520,vy:0,dmg:0,col:'#ff9900',r:4,life:9});
      let on=false;for(let i=0;i<20&&!on;i++){shoot();await w8(60);on=TUT.cur&&TUT.cur.k==='dash';}await w8(200);const keys=document.querySelector('#tut .tut-keys').textContent;
      p.dashCd=1;tryDash();await w8(100);const notYet=!G.save.tut.done.dash;p.dashCd=0;tryDash();await w8(200);return {on,keys,notYet,done:!!G.save.tut.done.dash}}""")
    P2=await newpage(b,390,844,alpha=False,touch=True);await P2.js(NEW,{'touch':1})
    ph=await P2.js("""async()=>{done('move','lom','stash','act','fire');const p=G.player;p.dashCd=0;const shoot=()=>G.eb.push({x:p.x+240,y:p.y,vx:-520,vy:0,dmg:0,col:'#ff9900',r:4,life:9});
      let on=false;for(let i=0;i<20&&!on;i++){shoot();await w8(60);on=TUT.cur&&TUT.cur.k==='dash';}await w8(400);const rg=document.querySelector('#tut .tut-ring.on'),d=$('#tDash');if(!rg)return {on,ring:false};
      const a=rg.getBoundingClientRect(),c=d.getBoundingClientRect();return {on,ring:true,dx:Math.abs((a.left+a.right)/2-(c.left+c.right)/2),dy:Math.abs((a.top+a.bottom)/2-(c.top+c.bottom)/2),keys:document.querySelector('#tut .tut-keys').innerHTML}}""")
    ok=pc['on'] and 'ПРОБЕЛ' in pc['keys'] and pc['notYet'] and pc['done'] and ph['on'] and ph['ring'] and ph['dx']<=2 and ph['dy']<=2 and ph['keys']==''
    rec('T03 рывок: на ПК «ПРОБЕЛ», на телефоне кольцо точно на кнопке рывка; рывок на перезарядке урок не закрывает',ok,{'pc':pc,'ph':ph})

@test('T04')
async def t04(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{const p=G.player;p.dashCd=0;tryDash();await w8(300);done('move');p.dashCd=0;for(let i=0;i<10;i++){G.eb.push({x:p.x+240,y:p.y,vx:-520,vy:0,dmg:0,col:'#ff9900',r:4,life:9});await w8(80);}
      return {done:!!G.save.tut.done.dash,log:TUT.log.slice()}}""")
    rec('T04 сам сделал рывок до урока — урок закрыт молча и ни разу не показан',r['done'] and 'dash' not in r['log'],r)

@test('T05')
async def t05(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{done('move');G.save.cleared=1;G.save.medals[1]={clear:1};TUT.worldT=0;G.save.carry=30;G.save.lom=7;const on1=await waitCur('stash',3000);const on2=on1;const s=tutShopPt(),p=G.player;
      const ang=TUT.cur&&TUT.cur.k==='stash';p.x=s.x+120;p.y=s.y+60;const actOn=await waitCur('act',6000)?'act':(TUT.cur&&TUT.cur.k);cardAct('main');await w8(300);const st=G.state;if(G.state==='shop')closeShop();await w8(200);
      return {on1,on2,ang,actOn,st,lom:G.save.lom,carry:G.save.carry,done:G.save.tut.done}}""")
    ok=r['on1'] and r['on2'] and r['actOn']=='act' and r['st']=='shop' and r['lom']==37 and r['carry']==0 and r['done'].get('stash') and r['done'].get('act') and r['done'].get('lom')
    rec('T05 после миссии 01: «лом» → «склад»: стрелка к мастерской, у неё — «действие»; лом на складе ровно +30, экономика не тронута',ok,r)

@test('T06')
async def t06(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{done('move','lom','stash','act','fire','dash','pulse','patrol');G.save.cleared=2;G.save.medals[1]={clear:1};G.save.medals[2]={clear:1};const p=G.player;const s=tutShopPt();p.x=s.x+2600;p.y=s.y;TUT.worldT=0;
      const m=await waitCur('map',3000);const ring=!!document.querySelector('#tut .tut-ring.on');openMap();await w8(150);const mapDone=!!G.save.tut.done.map;const j=await waitCur('jump',1500);await w8(900);const pt=$('#mapHint')&&$('#mapHint').classList.contains('on')?'hint':null;
      const q=G.mapPts.find(z=>Math.hypot(z.x-p.x,z.y-p.y)>800);const x0=p.x;mapJumpAt(q.px,q.py);await w8(700);const moved=Math.hypot(G.player.x-q.x,G.player.y-q.y)<5;
      return {m,ring,mapDone,j,pt,moved,jumpDone:!!G.save.tut.done.jump,st:G.state}}""")
    P2=await newpage(b,1600,900,alpha=False);await P2.js(NEW,{})
    r2=await P2.js("""async()=>{done('move','lom','stash','act','fire','dash','pulse','patrol','map');G.save.cleared=1;G.save.medals[1]={clear:1};const p=G.player;const s=tutShopPt();p.x=s.x+2600;p.y=s.y;const seen=[];
      for(let i=0;i<3;i++){openMap();const j=await waitCur('jump',1200);closeMap();await w8(200);seen.push(j?1:0);TUT.gap=0;}return {seen,done:!!G.save.tut.done.jump}}""")
    ok=r['m'] and r['ring'] and r['mapDone'] and not r['j'] and r['pt']=='hint' and r['moved'] and r['jumpDone'] and r2['seen']==[0,0,0] and not r2['done']
    rec('T06 (1.3.3) после миссии 02: кольцо на «КАРТА [M]»; в карте — подпись, без прожектора на мастерской; прыжок засчитан делом; после миссии 01 урока прыжка нет',ok,{'a':r,'b':r2})

@test('T07')
async def t07(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{done(...TUT_KEYS_ALL);G.save.cleared=1;G.save.medals[1]={clear:1};const p=G.player;p.x+=2500;const z={};spawnEnemy('scout',p.x+300,p.y,{zone:z});const e=G.enemies[G.enemies.length-1];
      openMap();await w8(500);const soft=$('#mapDeny')&&$('#mapDeny').classList.contains('soft');await w8(1500);const x0=p.x,y0=p.y;const q=G.mapPts[0];mapJumpAt(q.px,q.py);await w8(300);mapJumpAt(q.px,q.py);await w8(250);
      const el=$('#mapDeny'),bx=document.querySelector('#sMap .mapbox').getBoundingClientRect(),bd=el.querySelector('.md-band').getBoundingClientRect(),cs=getComputedStyle(el.querySelector('.md-l'));
      const o={n:document.querySelectorAll('#mapDeny').length,on:el.classList.contains('on')&&!el.classList.contains('soft'),txt:el.textContent,col:cs.color,pe:getComputedStyle(el).pointerEvents,
        cx:((bd.left+bd.right)/2-bx.left)/bx.width,cy:((bd.top+bd.bottom)/2-bx.top)/bx.height,stat:$('#mapStat').textContent,soft};await w8(2600);o.after=el.classList.contains('on');o.moved=Math.hypot(G.player.x-x0,G.player.y-y0);
      const ring=mapJpCol(false);o.ring=ring;return o}""")
    import re
    a=re.findall(r'rgba?\(([^)]*)\)',r['col']);alpha=float(a[0].split(',')[3]) if a and len(a[0].split(','))==4 else 1
    ok=r['n']==1 and r['on'] and 'ВО ВРЕМЯ ПАТРУЛЯ' in r['txt'] and 'ПЕРЕМЕЩЕНИЕ НЕДОСТУПНО' in r['txt'] and alpha<1 and r['col'].startswith('rgba(255, 79, 110') and r['pe']=='none' and abs(r['cx']-.5)<.04 and abs(r['cy']-.5)<.04 and not r['after'] and r['moved']<1 and r['soft'] and 'РЯДОМ ВРАГИ' in r['stat'] and r['ring'].startswith('rgba(255,79,110')
    rec('T07 карта во время патруля: крупная полупрозрачная красная надпись по центру, клики сквозь неё, без дублей, гаснет; кольца точек красные; корабль на месте',ok,r)

@test('T08')
async def t08(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{done(...TUT_KEYS_ALL);G.save.cleared=1;G.save.medals[1]={clear:1};const p=G.player,res=[];p.x+=2500;let bad=0;
      spawnEnemy('scout',p.x+500,p.y,{});openMap();await w8(200);const q=G.mapPts[0];mapJumpAt(q.px,q.py);await w8(200);res.push($('#mapDeny').textContent);closeMap();G.enemies.forEach(e=>e.alive=false);G.enemies=[];
      G.anom={a:{kind:'x',name:'Т',x:p.x,y:p.y},t:0,dur:30};openMap();await w8(200);mapJumpAt(G.mapPts[0].px,G.mapPts[0].py);await w8(200);res.push($('#mapDeny').textContent);closeMap();G.anom=null;
      const R=mulberry(7);for(let i=0;i<60;i++){const S=G.save;G.enemies=[];const home={x:p.x,y:p.y};const d=500+R()*800,zone=R()<.5,a=R()*TAU;spawnEnemy(R()<.2?'mine':'scout',p.x+Math.cos(a)*d,p.y+Math.sin(a)*d,zone?{zone:{}}:{});
        const e=G.enemies[G.enemies.length-1];e.vx=e.vy=0;openMap();drawMap();const tgt=G.mapPts.find(z=>Math.hypot(z.x-p.x,z.y-p.y)>300);const rsn=jumpDenyReason(tgt);const exp=e.type!=='mine'&&Math.hypot(e.x-p.x,e.y-p.y)<900;
        G.mapAnimJump=false;const was=[p.x,p.y];mapJumpAt(tgt.px,tgt.py);G.mapAnimJump=undefined;const jumped=Math.hypot(G.player.x-was[0],G.player.y-was[1])>5;if(G.state==='map')closeMap();
        if(!!rsn!==exp||jumped===exp||(exp&&(rsn==='patrol')!==zone))bad++;Object.assign(G.player,{x:home.x,y:home.y});mapDenyHide();}
      return {res,bad}}""")
    ok=('РЯДОМ ВРАГИ' in r['res'][0] and 'ИДЁТ АНОМАЛИЯ' in r['res'][1] and r['bad']==0)
    rec('T08 причины запрета: «рядом враги» без патруля, «идёт аномалия»; 60 случайных ситуаций — прыжок ровно как раньше (порог 900, мины не мешают)',ok,r)

@test('T09')
async def t09(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    await P.js("async()=>{done('move','lom','stash','act','fire','dash');saveWorld();return 1}")
    await P.pg.reload();await P.pg.wait_for_timeout(400);await P.pg.evaluate(LIB)
    r=await P.js("""async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));startWorld(false);for(let i=0;i<40&&(G.prologue||G.state!=='world');i++)await w8(100);if(typeof prologueEnd==='function'&&G.prologue)prologueEnd();TUT.log=[];TUT.hist=[];
      const p=G.player;G.save.carry=40;const t0=performance.now();while(performance.now()-t0<8000){p.dashCd=0;G.eb.push({x:p.x+240,y:p.y,vx:-520,vy:0,dmg:0,col:'#ff9900',r:4,life:9});const s=tutShopPt();if(performance.now()-t0>4000){p.x=s.x+120;p.y=s.y+60;}await w8(150);}
      return {log:TUT.log.slice(),done:G.save.tut.done}}""")
    rec('T09 пройденные уроки после перезагрузки не возвращаются ни при каких триггерах',not any(k in r['log'] for k in ['move','lom','stash','act','fire','dash']) and r['done'].get('dash'),r)

@test('T10')
async def t10(b):
    P=await newpage(b,1600,900,alpha=False)
    r=await P.js("""async()=>{if(typeof TUT==='undefined')return {ok:false};const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();const S=G.save;S.cleared=4;for(let m=1;m<=4;m++)S.medals[m]={clear:1};delete S.tut;store(saveKey(),S);
      startWorld(false);for(let i=0;i<40&&(G.prologue||G.state!=='world');i++)await w8(100);TUT.log=[];const p=G.player;G.save.carry=50;spawnEnemy('scout',p.x+400,p.y,{zone:{}});const e=G.enemies[G.enemies.length-1];e.hp=e.maxHp=1e9;await w8(3000);e.x=p.x+400;e.y=p.y;
      openMap();await w8(200);mapJumpAt(G.mapPts[0].px,G.mapPts[0].py);await w8(200);return {ok:true,tut:G.save.tut,log:TUT.log.slice(),deny:$('#mapDeny')&&$('#mapDeny').classList.contains('on'),toastT:$('#toastT').textContent}}""")
    rec('T10 ветеран (старое сохранение, пройдено 4): обучения нет совсем, надпись запрета на карте работает',r.get('ok') and r['tut'].get('off')==1 and r['tut'].get('vet')==1 and r['log']==[] and r['deny'],r)

@test('T11')
async def t11(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{done('move','lom','fire','dash','pulse','patrol');G.save.cleared=1;G.save.medals[1]={clear:1};TUT.worldT=0;const p=G.player;spawnEnemy('scout',p.x+400,p.y,{});const e=G.enemies[G.enemies.length-1];G.save.carry=40;TUT.lomAt=0;
      let any=false;e.hp=e.maxHp=1e9;for(let i=0;i<30;i++){e.x=p.x+400;e.y=p.y;e.vx=e.vy=0;p.hp=G.st.maxHp;if(TUT.cur)any=TUT.cur.k;await w8(100);}e.alive=false;G.enemies=[];
      const t0=performance.now();const on=await waitCur('stash',4000);const lat=performance.now()-t0;const n=document.querySelectorAll('#tut .tut-chip').length;
      tutEnd('miss');const t1=performance.now();let next=null;while(performance.now()-t1<6000){if(TUT.cur){next=performance.now()-t1;break;}await w8(50);}
      return {any,on,lat,n,next,cur:TUT.cur&&TUT.cur.k}}""")
    rec('T11 «бой свят»: при враге рядом мирные уроки не начинаются; одна подсказка за раз; пауза между подсказками ≥ 4 с',(not r['any']) and r['on'] and r['n']==1 and (r['next'] is None or r['next']>=3900),r)

@test('T12')
async def t12(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{const on=await waitCur('move',4000);await w8(300);const x=document.querySelector('#tut .tut-x');const rb=x.getBoundingClientRect();
      x.dispatchEvent(new MouseEvent('click',{bubbles:true}));await w8(700);const a={done:!!G.save.tut.done.move,cur:TUT.cur&&TUT.cur.k,hidden:$('#tut').hidden,stored:JSON.parse(localStorage.getItem('void_world')).tut.done.move};
      pause();openSettings('pause');await w8(200);$('[data-tutk]').click();await w8(100);const off=G.save.tut.off;closeSettings();resume();G.save.carry=40;await w8(2500);const curOff=TUT.cur&&TUT.cur.k;
      pause();openSettings('pause');await w8(100);$('[data-tutreset]').click();await w8(100);const af=JSON.parse(JSON.stringify(G.save.tut));closeSettings();resume();return {on,a,off,curOff,af,xs:[rb.width,rb.height]}}""")
    ok=r['on'] and r['a']['done'] and r['a']['cur'] is None and r['a']['stored'] and r['off']==1 and r['curOff'] is None and r['af']['done']=={} and not r['af'].get('off')
    rec('T12 «✕» закрывает урок навсегда; переключатель в настройках гасит обучение; «пройти заново» сбрасывает уроки',ok,r)

@test('T13')
async def t13(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{if(typeof TUT==='undefined')return null;const run=(on,m)=>{T.fresh();if(G.prologue)prologueEnd();G.save.tut=on?{v:1,done:{},seen:{}}:{v:1,off:1,done:{},seen:{}};T.openAll();G.save.cleared=6;G.save.tut.off=on?0:1;
        const _r=Math.random;Math.random=mulberry(1234+m);try{T.go(m);const o=T.bot({maxSec:60,full:true});return [o.taken,G.kills,Math.round(G.player.x),Math.round(G.player.y),G.lvl,Math.round(G.score)];}finally{Math.random=_r;}};
      const out={};for(const m of [1,3,8]){out[m]=[run(true,m),run(false,m)];}return out}""")
    ok=bool(r) and all(v[0]==v[1] for v in r.values())
    rec('T13 механики не тронуты: одинаковый сид и бот в миссиях 1, 3, 8 — с обучением и без результат совпадает до единицы',ok,r)

@test('T14')
async def t14(b):
    out={}
    for (vw,vh,tch) in [(390,844,True),(844,390,True),(820,1180,True),(1920,1080,False),(3440,1440,False),(3840,2160,False)]:
        P=await newpage(b,vw,vh,alpha=False,touch=tch);await P.js(NEW,{'touch':1} if tch else {})
        out[f'{vw}x{vh}']=await P.js("""async()=>{const res=[];const chk=()=>{const c=document.querySelector('#tut .tut-chip'),r=c.getBoundingClientRect();const fs=parseFloat(getComputedStyle(c.querySelector('.tut-txt')).fontSize);
          const blk=tutBlockers().filter(b=>!(b[0]<=-1e4));const hit=blk.some(b=>r.left<b[2]&&r.right>b[0]&&r.top<b[3]&&r.bottom>b[1]);
          return {in:r.left>=(SAFE.l||0)&&r.right<=CW-(SAFE.r||0)&&r.top>=(SAFE.t||0)&&r.bottom<=CH-(SAFE.b||0),hit,fs:+fs.toFixed(1),k:TUT.cur&&TUT.cur.k};};
          await waitCur('move',4000);await w8(300);res.push(chk());done('move','lom','stash','act','fire');TUT.gap=0;TUT.hist=[];const p=G.player;p.dashCd=0;
          for(let i=0;i<20&&!(TUT.cur&&TUT.cur.k==='dash');i++){G.eb.push({x:p.x+240,y:p.y,vx:-520,vy:0,dmg:0,col:'#ff9900',r:4,life:9});await w8(60);}await w8(300);res.push(chk());return res}""")
    ok=all(len(v)==2 and all(x['in'] and not x['hit'] and x['fs']>=11 and x['k'] for x in v) for v in out.values())
    rec('T14 адаптивность: 390×844, 844×390, 820×1180, 1920×1080, 3440×1440, 3840×2160 — подсказки в безопасной зоне, не на кнопках и HUD, шрифт ≥ 11 px',ok,out)

@test('T15')
async def t15(b):
    P=await newpage(b,1600,900,alpha=False);await P.js(NEW,{})
    r=await P.js("""async()=>{done('dash');saveWorld();const S=JSON.parse(localStorage.getItem('void_world'));const C=JSON.parse(JSON.stringify(S));C.tut={v:1,done:{map:1},seen:{}};C.cleared=2;
      toMenu();await w8(200);cloudApply({t:Date.now(),keys:{void_world:JSON.stringify(C)}});const d=G.save.tut.done;
      const g=migrateSave(Object.assign(JSON.parse(JSON.stringify(S)),{tut:{done:{move:'yes',evil:1,__proto__:{x:1}},seen:{map:99,pulse:-3},off:'1'}}));
      return {merged:Object.keys(d).sort(),g:g.tut}}""")
    ok=r['merged']==['calib','dash','map'] and r['g']=={'v':1,'done':{'move':1},'seen':{'map':3},'off':1}
    rec('T15 облако: пройденное локально и в облаке объединяется; мусор в S.tut вычищается',ok,r)

@test('T16')
async def t16(b):
    out={}
    for (vw,vh,tch) in [(1920,1080,False),(390,844,True)]:
        P=await newpage(b,vw,vh,alpha=False,touch=tch);await P.js(NEW,{'touch':1} if tch else {})
        out[f'{vw}x{vh}']=await P.js("""async()=>{done('move','lom','stash','act','fire');const p=G.player;p.dashCd=0;for(let i=0;i<20&&!(TUT.cur&&TUT.cur.k==='dash');i++){G.eb.push({x:p.x+240,y:p.y,vx:-520,vy:0,dmg:0,col:'#ff9900',r:4,life:9});await w8(60);}
          let n=0;const t0=performance.now();for(let i=0;i<300;i++){const now=performance.now();tutTick2(1/300,now);tutWorldDraw(now);tutGhostDraw(now);n++;if(!TUT.cur)break;}const tt=performance.now()-t0;
          return {med:+(tt/n).toFixed(3),n,k:TUT.cur&&TUT.cur.k}}""")
        out[f'{vw}x{vh}']['errs']=P.errs[:2]
    ok=out['1920x1080']['med']<=.3 and out['390x844']['med']<=.8 and all(not v['errs'] and v['n']>=300 for v in out.values())
    rec('T16 производительность: добавка к кадру при активной подсказке ≤ 0,3 мс (ПК) и ≤ 0,8 мс (телефон), без ошибок',ok,out)

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q210.json'))
