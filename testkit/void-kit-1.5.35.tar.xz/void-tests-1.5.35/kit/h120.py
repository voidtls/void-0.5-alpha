# 0.9.9: хуки проверок босса 50
H120="""()=>{
 T.zWorld=(o)=>{o=o||{};T.fresh();T.openAll();G.slow95=null;G.hs90=null;const S=G.save;S.diff=o.diff||'mid';S.story.zero49=1;if(o.flags)Object.assign(S.story,o.flags);const n=WORLD.nodes[49],p=G.player;p.x=n.x;p.y=n.y+100;p.px=p.x;p.py=p.y;p.vx=p.vy=0;camSnap();T.wtick(.3);return G.state;};
 T.ztick=(sec,f)=>{for(let i=0;i<Math.round(sec*60);i++){if(G.state==='levelup'){let n=0;while(G.state==='levelup'&&n++<40)choose(0);}if(f)f(i);if(G.state==='world')worldUpdate(1/60);}};
 T.zdraw=()=>{try{renderWorld(performance.now());updateWorldHUD();return 'ok';}catch(e){return 'ERR '+e.message;}};
 T.zgo=()=>{cardAct('main');return G.zb?G.zb.k:'none';};
 T.zstart=(o)=>{T.zWorld(o);T.zgo();T.ztick(9);let n=0;while(G.zb&&G.zb.k!=='fight'&&n++<40)T.ztick(.5);return G.zb?G.zb.k:'none';};
 T.zstage=(n)=>{const Z=G.zb;if(!Z)return 'none';for(const e of G.enemies)if(e.alive&&e.zb===2)e.alive=false;Z.clones=[];Z.k='fight';Z.t=0;Z.stall=0;Z.lunge=0;G.wtg95=[];G.eb=[];if(Z.boss){Z.boss.ghost=false;Z.boss.zbHide=0;}zbStageInit(Z,n);T.ztick(.1);return Z.stage;};
 T.zsettle=(mx)=>{const Z=G.zb;let n=0;while(Z&&(Z.shape.next||Z.shape.morph<1)&&n++<(mx||400)){G.player.hp=G.st.maxHp;if(G.state==='world')worldUpdate(1/60);}return n;};
 T.zhit=(dmg,o)=>{const Z=G.zb,e=(o&&o.e)||Z.boss;hurt(e,dmg,o||{});return Z.hp;};
 T.zpos=(x,y)=>{const p=G.player;p.x=x;p.y=y;p.px=x;p.py=y;p.vx=p.vy=0;};
 T.zcen=()=>zbCen(G.zb);
 T.god=T.god||(()=>{G.player.hp=G.st.maxHp;});
 return 1;}"""
