# 1.3.1 α: низ меню, без «Что нового», «Допуск пилота» свёрнут, прозрачность кнопок и стика, подсказка о звуке
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
W8="window.w8=ms=>new Promise(r=>setTimeout(r,ms));"
MENU="""async()=>{"""+W8+"""T.fresh();G.save.cleared=5;G.save.pilot={lvl:5,xp:0};saveWorld();toMenu();await w8(500);renderRecord&&renderRecord();
  const v=$('#verNote'),r=v?v.getBoundingClientRect():null,sc=$('#sMenu');const bs=[...document.querySelectorAll('#sMenu .btns .btn')].filter(b=>b.offsetParent).map(b=>b.getBoundingClientRect());
  const ov=r&&bs.some(q=>!(q.right<=r.left||q.left>=r.right||q.bottom<=r.top||q.top>=r.bottom));
  return {rec:$('#recLine').textContent,txt:v?v.innerText.replace(/\\s+/g,' '):'',vis:!!r&&r.height>0&&r.bottom<=innerHeight+1&&r.top>=0,ov,scroll:sc.scrollHeight>sc.clientHeight+1,
    fs:v?Math.min(...[...v.querySelectorAll('*')].filter(e=>e.offsetParent&&e.childElementCount===0&&e.textContent.trim()).map(e=>parseFloat(getComputedStyle(e).fontSize))):0,verTagVis:$('#verTag').offsetParent!==null}}"""
@test('W01')
async def w01(b):
    out={}
    for (w,h,tc) in [(1280,760,False),(1920,1080,False),(390,844,True),(360,640,True),(844,390,True)]:
        P=await newpage(b,w,h,alpha=False,touch=tc);out[f'{w}x{h}']=await P.js(MENU)
    ok=all('МИССИИ' not in r['rec'] and 'ПИЛОТ' not in r['rec'] and 'VØID 1.' in r['txt'] and 'АЛЬФА' in r['txt'] and 'НОВОЕ В 1.' in r['txt'] and r['vis'] and not r['ov'] and not r['scroll'] and r['fs']>=12 and not r['verTagVis'] for r in out.values())
    ok=ok and all('игра в разработке' in out[k]['txt'] for k in ['1280x760','1920x1080','390x844','844x390'])
    rec('W01 меню: нет плашек «Миссии/Пилот»; внизу версия, «альфа» и кратко об обновлении — без наездов и прокрутки, шрифт ≥ 12',ok,{k:{x:y for x,y in v.items() if x!='txt'} for k,v in out.items()})
@test('W02')
async def w02(b):
    P=await newpage(b,1280,760,alpha=False,clear=False)
    await P.js("()=>{localStorage.clear();}");
    await P.js("()=>{T.fresh();saveWorld();localStorage.setItem('void_ver_seen','1.2.9 α');}")
    await P.pg.reload();await P.wait(3200)
    r=await P.js("()=>({toast:!$('#toast').hidden?$('#toast').innerText.slice(0,80):'',fresh:$('#verNote').classList.contains('fresh'),seen:localStorage.getItem('void_ver_seen'),st:G.state})")
    rec('W02 вернувшийся игрок: «Что нового» не всплывает, вместо этого пометка у строки обновления внизу меню',r['st']=='menu' and 'ЧТО НОВОГО' not in r['toast'] and r['fresh'] and r['seen']==(await P.js('()=>VER_TAG')),r)
@test('W03')
async def w03(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("""async()=>{"""+W8+"""T.fresh();await w8(300);pause();await w8(200);const d=$('#tutCard'),a={hidden:d.hidden,open:d.open};resume&&resume();
      for(const k in tutOkMap())delete tutOkMap()[k];TUT_SK.forEach(s=>{});const ok=tutOkMap();['move','dash','pulse','act','stash','map','jump','cell','line','calib','fire','energy','lom'].forEach(k=>ok[k]=1);
      const n=tutSkillN();pause();await w8(200);const d2=$('#tutCard');return {a,n,all:TUT_SK.length,b:{hidden:d2.hidden}}}""")
    rec('W03 пауза: «Допуск пилота» свёрнут; когда освоены все навыки — карточки нет',r['a']['hidden']==False and r['a']['open']==False and r['n']==r['all'] and r['b']['hidden']==True,r)
@test('W04')
async def w04(b):
    P=await newpage(b,390,844,alpha=False,touch=True,clear=False)
    await P.js("()=>{localStorage.clear();}")
    # старое сохранённое значение «сильной» — 0.45 — переходит в новое
    key=await P.js("()=>{const k=Object.keys(localStorage).find(k=>{try{return 'btnAlpha' in JSON.parse(localStorage.getItem(k));}catch(e){return false;}});return k||null;}")
    await P.js("()=>{saveSet();}")
    key=await P.js("()=>Object.keys(localStorage).find(k=>{try{return 'btnAlpha' in JSON.parse(localStorage.getItem(k));}catch(e){return false;}})")
    await P.js("(k)=>{const o=JSON.parse(localStorage.getItem(k));o.btnAlpha=.45;localStorage.setItem(k,JSON.stringify(o));}",key)
    await P.pg.reload();await P.wait(400);await P.pg.evaluate(LIB)
    r=await P.js("""async()=>{"""+W8+"""const mig=SET.btnAlpha;localStorage.removeItem('void_world');startWorld(true);if(G.prologue)prologueEnd();G.save.tut.off=true;
      const o={mig};for(const v of [.2,.7,1]){SET.btnAlpha=v;applySettings();layoutTouch();G.player.en=100;G.calm=0;$('#tAct').classList.add('go');for(let i=0;i<5;i++)update(1/60);await w8(450);
        o[v]={pulse:+getComputedStyle($('#tPulse')).opacity,rdy:$('#tPulse').classList.contains('rdy'),act:+getComputedStyle($('#tAct')).opacity,dash:+getComputedStyle($('#tDash')).opacity};}return o;}""")
    ok=r['mig']==0.2 and r['0.2']['rdy'] and r['0.2']['pulse']<=.3 and r['0.2']['act']<=.3 and r['0.2']['dash']<=.21 and r['1']['pulse']==1 and r['0.7']['dash']==.7
    rec('W04 прозрачность кнопок: «сильная» действует на всю кнопку, включая готовый импульс и «действие»; старое 0,45 → 0,2',ok,r)
@test('W05')
async def w05(b):
    P=await newpage(b,390,844,alpha=False,touch=True)
    r=await P.js("""async()=>{"""+W8+"""T.fresh();G.save.tut.off=true;toMenu();openSettings();await w8(300);const row=document.querySelector('[data-seg="stickAlpha"]');if(!row)return {row:false};
      const rw=row.closest('.srow63')||row.closest('.setrow'),prev=rw.previousElementSibling,after=!!prev&&!!prev.querySelector('[data-seg="btnAlpha"]');const ic=!!row.closest('.setrow').querySelector('.eyebrow .opic');
      row.querySelector('[data-v="0.05"]').click();await w8(200);closeSettings();T.fresh();G.save.tut.off=true;setInput&&setInput('touch');layoutTouch();
      const cv=document.querySelector('canvas');const ev=(t,x,y)=>new PointerEvent(t,{pointerId:9,clientX:x,clientY:y,bubbles:true,pointerType:'touch',isPrimary:true});
      cv.dispatchEvent(ev('pointerdown',90,600));cv.dispatchEvent(ev('pointermove',110,590));await w8(100);const j=$('#joy'),js=getComputedStyle(j);
      const o={row:true,after,ic,v:SET.stickAlpha,joy:js.display!=='none'?+js.opacity:null,saved:Object.keys(localStorage).some(k=>{try{return JSON.parse(localStorage.getItem(k)).stickAlpha===.05;}catch(e){return false;}})};cv.dispatchEvent(ev('pointerup',110,590));
      SET.stickAlpha=1;applySettings();cv.dispatchEvent(ev('pointerdown',90,600));await w8(100);o.joy1=+getComputedStyle($('#joy')).opacity;cv.dispatchEvent(ev('pointerup',90,600));return o;}""")
    ok=r.get('row') and r['after'] and r['ic'] and r['v']==0.05 and r['joy'] is not None and r['joy']<=.051 and r['saved'] and r['joy1']==1
    rec('W05 отдельная прозрачность стика со своим значком: «сильная» — стик прозрачен на 95%',ok,r)
STRICT="""window.__gest=false;const _g=e=>{if(e.isTrusted)window.__gest=true;};addEventListener('pointerdown',_g,true);addEventListener('keydown',_g,true);
const A_=window.AudioContext;window.AudioContext=class extends A_{constructor(...a){super(...a);super.suspend();}resume(){return window.__gest?super.resume():Promise.resolve();}};"""
@test('W06')
async def w06(b):
    P=await newpage(b,1280,760,alpha=False,init=STRICT)
    await P.wait(2400)
    s=lambda:P.js("()=>[AU.ctx?AU.ctx.state:'none',$('#verNote').classList.contains('mute'),getComputedStyle($('#verNote .vn-s')).display]")
    a=await s()
    await P.js("()=>{const el=document.elementFromPoint(900,700)||document.body;['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t=>el.dispatchEvent(new PointerEvent(t,{bubbles:true,clientX:900,clientY:700})));}")
    await P.wait(1800);b2=await s()
    await P.pg.mouse.click(900,700);await P.wait(900);c=await s()
    ok=a[0]=='suspended' and a[1] and a[2]=='flex' and b2[0]=='suspended' and c[0]=='running' and not c[1]
    rec('W06 звук: пока браузер держит звук — тихая подсказка внизу меню; искусственный клик не помогает, первое настоящее касание включает музыку',ok,{'load':a,'synthetic':b2,'real':c})
@test('W07')
async def w07(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("()=>({ver:VER_TAG,tag:$('#verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.3.1 α</dt><dd>Чище и честнее')})")
    rec('W07 версия 1.3.1 α и запись в журнале',r['ver']=='1.3.1 α' and r['tag']=='1.3.1 α' and r['log'],r)
asyncio.run(run(TESTS,'q250'))
