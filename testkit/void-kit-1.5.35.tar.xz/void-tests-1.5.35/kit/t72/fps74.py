# Этап 4 · стенд частоты кадров (только чтение сборки; рабочая игра не меняется).
# Гоняет настоящий frame(now) с синтетическими метками времени. Ввод бота — функция РЕАЛЬНОГО времени.
# python3 fps72.py <jobs.json> <out.jsonl> [parallel]
# job: {id,url,enc,prof,seed,dur,mob,fps30,cine,noRender,ev}
import asyncio,json,sys,time,os
sys.path.insert(0,'@@KIT@@')
from h import *
INIT="""(()=>{let a=%d;const R=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
window.__rt={n:0,c:null};Math.random=function(){const T=window.__rt;T.n++;if(T.c){const st=new Error().stack.split('\\n');let k=[];for(let j=2;j<st.length&&k.length<3;j++){const m=/:(\\d+):\\d+\\)?$/.exec(st[j]);if(!m)continue;const fn=(/at (?:Object\\.)?([\\w$.<>]+) /.exec(st[j])||[,'?'])[1];k.push(fn+':'+m[1]);}const key=k.join(' < ');T.c[key]=(T.c[key]||0)+1;}return R();};
window.requestAnimationFrame=()=>0;%s})();"""
RUN=r"""(J)=>{
 const enc=J.enc;const prof=J.prof;let jit=J.seed*7919+13;const jr=()=>{jit=(jit*1103515245+12345)%2147483648;return jit/2147483648;};
 const C={spawn:0,shots:0,dmg:0,upd:0,updDt:0,hurtN:0};
 {const f=spawnEnemy;spawnEnemy=function(){C.spawn++;return f.apply(this,arguments);};}
 {const f=fire;fire=function(){C.shots++;return f.apply(this,arguments);};}
 {const f=hurt;hurt=function(e,d){const h0=e&&typeof e.hp==='number'?e.hp:0;const r=f.apply(this,arguments);if(e&&typeof e.hp==='number'){C.dmg+=Math.max(0,h0-Math.max(0,e.hp));C.hurtN++;}return r;};}
 {const f=update;update=function(dt){C.upd++;C.updDt+=dt;return f.apply(this,arguments);};}
 {const f=worldUpdate;worldUpdate=function(dt){C.upd++;C.updDt+=dt;return f.apply(this,arguments);};}
 C.slow=0;C.hs=0;{const f=slow95;slow95=function(){C.slow++;return f.apply(this,arguments);};}{const f=hs90;hs90=function(){C.hs++;return f.apply(this,arguments);};}
 if(J.cineMode)SET.cine=J.cineMode;
 if(J.noRender){render=function(){};renderWorld=function(){};mobOverlay=function(){};}
 audioWake();T.fresh();G.save.tut.off=1;
 let m=0,zb=false,wd=false,xm=false,wv=null,n=null;
 if(enc==='50'){zb=true;}else if(enc==='w'){wd=true;}else if(enc==='endless'||enc==='post'){xm=true;}else m=+enc;
 const G0=G.save;G0.cleared=Math.max(G0.cleared,(m||50)-1);for(let k=1;k<(m||50);k++)G0.medals[k]={clear:1};
 if(J.mob&&J.fps30)SET.fps=30;else SET.fps=60;
 let p;
 if(enc==='endless'){startEndless();if(G.state==='intro')startMission();}
 else if(enc==='post'){postEnter();if(G.state==='intro')startMission();}
 else if(wd){G0.cleared=9;for(let k=1;k<=9;k++)G0.medals[k]={clear:1};G0.story.absorbed=EROSION_FULL*.4;p=G.player;let bd=1e18;for(const e of riftEdges()){const mx=(e[0]+e[2])/2,my=(e[1]+e[3])/2,ox=e[4],oy=e[5],qx=mx+ox*1600,qy=my+oy*1600;if(!(ox||oy)||qx<200||qy<200||qx>WW-200||qy>WH-200||inSectors(qx,qy)||inSectors(mx-ox*250,my-oy*250)===false)continue;const d=Math.hypot(mx-p.x,my-p.y);if(d<bd){bd=d;wv={x:mx,y:my,ux:ox,uy:oy};}}p.x=wv.x-wv.ux*250;p.y=wv.y-wv.uy*250;p.vx=p.vy=0;}
 else if(zb){G.zbCool=0;n=zbNode();p=G.player;p.x=n.x-200;p.y=n.y;zbStart();}
 else{enterNode(m);if(G.state==='intro')startMission();if(J.boss){while(G.state==='levelup')choose(0);G.enemies=[];G.warns=[];G.eb=[];G.waveIdx=G.waves.length;G.gapT=.1;}}
 let now=50000;window.__pn=now;if(!J.realPerf){performance.now=()=>window.__pn;}last=now-16.667;frame(now);
 const t0=G.t,rn0=window.__rt.n;if(J.census)window.__rt.c={};for(const k in C)C[k]=0;
 let R=0,dashK=0,dist=0,frames=0,bossT=null,ttk=null,bossSeen=0,ph=[],ev=J.ev||{},paused=false,hidden=false,end=null,levelups=0;const sec=[];
 let px=G.player?G.player.x:0,py=G.player?G.player.y:0;
 const base=J.mob?1000/60:(prof==='p30'?1000/30:prof==='p120'?1000/120:prof==='p144'?1000/144:prof==='p50'?20:prof==='p15'?1000/15:1000/60);
 const nextD=()=>{if(prof==='jit')return 1000/60*(.55+.9*jr());if(prof==='hic')return (Math.floor((R+1000/60)/3000)>Math.floor(R/3000))?140:1000/60;if(prof==='mix')return [1000/144,1000/60,1000/30][Math.floor(R/5000)%3];return base;};
 const DUR=J.dur*1000;
 while(R<DUR){
   const d=nextD();R+=d;now+=d;
   if(ev.pauseAt&&!paused&&R>=ev.pauseAt*1000&&R<(ev.pauseAt+ev.pauseFor)*1000){pause();paused=true;}
   if(paused&&R>=(ev.pauseAt+ev.pauseFor)*1000){resume();paused=false;}
   if(ev.hideAt&&R>=ev.hideAt*1000&&R<(ev.hideAt+ev.hideFor)*1000){if(!hidden){pause();hidden=true;}continue;}
   if(hidden&&R>=(ev.hideAt+ev.hideFor)*1000){hidden=false;resume();}
   if(ev.fxAt&&Math.abs(R-ev.fxAt*1000)<d/2+.01){SET.fx=!SET.fx;try{fx25();}catch(e){}}
   if(ev.fxBack&&Math.abs(R-ev.fxBack*1000)<d/2+.01){SET.fx=!SET.fx;try{fx25();}catch(e){}}
   if(ev.slowAt&&Math.abs(R-ev.slowAt*1000)<d/2+.01){slow95(ev.slowT||1.2,ev.slowK||.35);}
   if(ev.hsAt&&Math.abs(R-ev.hsAt*1000)<d/2+.01){hs90(.25,2);}
   let st=G.state;
   if(st==='levelup'){let k=0;while(G.state==='levelup'&&k++<20)choose(0);levelups++;}
   if(zb){const Z=G.zb;if(Z&&Z.k==='choice'){try{zbChoose(0);}catch(e){}}}
   st=G.state;
   if(!paused&&st!=='play'&&st!=='world'){end=st;break;}
   p=G.player;
   if(!paused&&p){
     if(p.hp<G.st.maxHp*.4)p.hp=G.st.maxHp*.4;
     const tg=(wd||xm)?null:zb?(G.zb&&G.zb.boss):(G.boss||G.jam||G.sb||G.enemies.find(e=>e.alive&&dvBossy(e))||null);
     if(!wd&&!xm){if(!zb){if(bossSeen&&ttk===null&&(!tg||tg.alive===false||tg.hp<=0))ttk=+(G.t-t0).toFixed(3);if(tg&&tg.alive!==false){if(!bossSeen){bossSeen=1;bossT=+(G.t-t0).toFixed(3);}{const q=(tg.phase!==undefined?tg.phase:'')+':'+(tg.st||'');if((ph.length?ph[ph.length-1][0]:null)!==q)ph.push([q,+(G.t-t0).toFixed(2)]);}}}
       else{const Z=G.zb;if(Z){const k=Z.k+Z.stage;if((ph.length?ph[ph.length-1][0]:null)!==k)ph.push([k,+(G.t-t0).toFixed(2)]);}}}
     const A=R/1500;
     if(wd){const k=-300+1650*(1-Math.cos(R/15000*Math.PI));steer2(wv.x+wv.ux*k+Math.cos(R/667)*60,wv.y+wv.uy*k+Math.sin(R/667)*60);}
     else if(xm){const cx=G.world?p.x+Math.cos(A)*300:W/2+Math.cos(A)*Math.min(W,H)*.3,cy=G.world?p.y+Math.sin(A)*300:H/2+Math.sin(A)*Math.min(W,H)*.3;steer2(cx,cy);}
     else{const cx=tg?tg.x:(zb?n.x:W/2),cy=tg?tg.y:(zb?n.y:H/2),Rr=tg?200:Math.min(W,H)*.3;steer2(cx+Math.cos(A)*Rr,cy+Math.sin(A)*Rr);}
     const dk=Math.floor(R/2833);if(dk>dashK){dashK=dk;tryDash();}
     if(p.en>=100)tryPulse();
   }
   window.__pn=now;frame(now);frames++;
   if(G.player){dist+=Math.hypot(G.player.x-px,G.player.y-py);px=G.player.x;py=G.player.y;}
   if(Math.floor(R/1000)>sec.length){sec.push([+(G.t-t0).toFixed(3),G.kills||0,C.spawn,C.shots,Math.round(C.dmg),Math.round(G.taken||0),window.__rt.n-rn0]);}
 }
 for(const k of KK)KEYS[k]=false;
 return {simT:+(G.t-t0).toFixed(3),realT:+(R/1000).toFixed(3),frames,upd:C.upd,updDt:+C.updDt.toFixed(3),kills:G.kills||0,spawn:C.spawn,shots:C.shots,dmg:Math.round(C.dmg),hurtN:C.hurtN,taken:Math.round(G.taken||0),
   rng:window.__rt.n-rn0,census:window.__rt.c,slowN:C.slow,hsN:C.hs,dist:Math.round(dist),bossT,ttk,ph,end,st:G.state,levelups,q:G.q,lowFx:!!G.lowFx,zb:G.zb?[G.zb.k,G.zb.stage]:null,riftI:G.riftI,sec};
}"""
async def one(b,J):
    mob=bool(J.get('mob',False));vw,vh=(390,844) if mob else (1280,760)
    init=INIT%(J.get('seed',7),('window.__cine66=1;' if J.get('cine') else '')+'window.__archOff=%s;'%json.dumps(J.get('flags',[])))
    P=await newpage(b,vw,vh,url=J['url'],init=init,touch=mob,clear=False)
    t=time.time()
    try:r=await P.js(RUN,J)
    except Exception as e:r={'err':str(e)[:400]}
    r['id']=J['id'];r['errs']=P.errs[:3];r['nerr']=len(P.errs);r['wall']=round(time.time()-t,1)
    await P.pg.context.close();return r
async def main():
    jobs=json.load(open(sys.argv[1]));out=open(sys.argv[2],'a');par=int(sys.argv[3]) if len(sys.argv)>3 else 2
    done=set()
    try:
        for l in open(sys.argv[2]):done.add(json.loads(l)['id'])
    except Exception:pass
    jobs=[j for j in jobs if j['id'] not in done]
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
        q=asyncio.Queue()
        for j in jobs:q.put_nowait(j)
        async def worker():
            while not q.empty():
                J=await q.get()
                r=await one(b,J);out.write(json.dumps(r,ensure_ascii=False)+'\n');out.flush()
                print(r['id'],'sim',r.get('simT'),'k',r.get('kills'),'sh',r.get('shots'),'dmg',r.get('dmg'),'tk',r.get('taken'),'sp',r.get('spawn'),'rng',r.get('rng'),'end',r.get('end'),'err',r.get('nerr'),r.get('err','')[:120],'wall',r['wall'],flush=True)
        await asyncio.gather(*[worker() for _ in range(par)])
        await b.close()
asyncio.run(main())
