import asyncio,sys,glob,json
sys.path.insert(0,'@@KIT@@')
from h import *
async def main():
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for f in sorted(glob.glob('@@KIT@@/out1520/*.html')):
            P=await newpage(b,1280,760,url='file://'+f,clear=True,alpha=False)
            await P.pg.wait_for_timeout(1500)
            r=await P.js("()=>({ver:VER_TAG,vi:ARCH.vi,a24:ARCH.a24,a25:ARCH.a25,old:!!ARCH.off['A-20'],st:G.state,raf:(()=>{const n=ARCH.steps74;return n})()})")
            print(f.split('/')[-1],json.dumps(r,ensure_ascii=False),P.errs[:2]);await P.pg.context.close()
        await b.close()
asyncio.run(main())
