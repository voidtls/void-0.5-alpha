# Ввод между кадрами (реальные нажатия, а не по номеру шага): короткие нажатия клавиш движения и рывок.
# События получают случайное время; браузер обрабатывает их перед ближайшим кадром rAF. Кадры — настоящий frame(now).
# Меряем: долю «увиденных» коротких нажатий, задержку от события до первого кадра с изменённой позицией корабля,
# число принятых рывков (ни пропусков, ни повторов). python3 input74.py <out.json>
import asyncio,json,sys
sys.path.insert(0,'@@KIT@@')
from h import *
D='file://@@KIT@@/t72/'
INIT="""(()=>{let a=3;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
window.requestAnimationFrame=()=>0;window.__archOff=%s;})();"""
RUN=r"""(J)=>{audioWake();T.fresh();G.save.tut.off=1;const G0=G.save;G0.cleared=1;G0.medals[1]={clear:1};enterNode(2);if(G.state==='intro')startMission();
 G.dev.god=true;let now=50000;performance.now=()=>now;last=now;const F=1000/J.hz;let seed=J.seed||11;const rnd=()=>{seed=(seed*1103515245+12345)%2147483648;return seed/2147483648;};
 const quiet=()=>{G.enemies=[];G.eb=[];G.warns=[];G.waveIdx=0;G.gapT=999;};
 const tick=()=>{now+=F;let k=0;while(G.state==='levelup'&&k++<20)choose(0);frame(now);};
 for(let i=0;i<60;i++)tick();
 const out={taps:{},dash:{n:0,ok:0,dup:0,lat:[]},mv:{lat:[]}};
 // короткие нажатия
 for(const d of J.durs){let seen=0;for(let r=0;r<J.reps;r++){quiet();const p=G.player;p.x=W/2;p.y=H/2;p.vx=p.vy=0;for(const k in KEYS)KEYS[k]=false;{const z=6+Math.floor(rnd()*5);for(let i=0;i<z;i++)tick();}
     const x0=p.x,y0=p.y;const tp=now+rnd()*F,tr=tp+d;let down=false,up=false;
     for(let i=0;i<40;i++){const nf=now+F;if(!down&&tp<nf){KEYS.KeyD=true;down=true;}if(down&&!up&&tr<nf){KEYS.KeyD=false;up=true;}tick();}
     KEYS.KeyD=false;for(let i=0;i<10;i++)tick();if(Math.abs(p.x-x0)>1e-6||Math.abs(p.y-y0)>1e-6)seen++;}
   out.taps[d]=+(seen/J.reps).toFixed(3);}
 // задержка движения: нажатие держится 200 мс, время до первого кадра с изменённой позицией
 for(let r=0;r<J.reps;r++){quiet();const p=G.player;p.x=W/2;p.y=H/2;p.vx=p.vy=0;for(const k in KEYS)KEYS[k]=false;{const z=6+Math.floor(rnd()*5);for(let i=0;i<z;i++)tick();}
   const x0=p.x;const tp=now+rnd()*F;let lat=null;for(let i=0;i<40;i++){const nf=now+F;if(tp<nf)KEYS.KeyD=true;tick();if(lat===null&&p.x!==x0)lat=now-tp;}KEYS.KeyD=false;for(let i=0;i<20;i++)tick();out.mv.lat.push(lat);}
 // рывок: нажатие в случайный момент между кадрами (обработчик клавиши вызывает tryDash сразу)
 for(let r=0;r<J.reps;r++){quiet();const p=G.player;p.x=W/2;p.y=H/2;p.vx=p.vy=0;p.dashCd=0;for(const k in KEYS)KEYS[k]=false;{const z=6+Math.floor(rnd()*5);for(let i=0;i<z;i++)tick();}
   const x0=p.x,y0=p.y;const tp=now+rnd()*F;let fired=false,lat=null,starts=0,prevT=p.dashT||0;
   for(let i=0;i<60;i++){const nf=now+F;if(!fired&&tp<nf){fired=true;out.dash.n++;const cd0=p.dashCd;tryDash([1,0]);if(p.dashCd!==cd0||p.dashT>0)out.dash.ok++;}
     tick();if(fired&&lat===null&&(p.x!==x0||p.y!==y0))lat=now-tp;const dT=p.dashT||0;if(dT>prevT+1e-9)starts++;prevT=dT;}
   if(starts>1)out.dash.dup++;out.dash.lat.push(lat);}
 const st=a=>{const b=a.filter(x=>x!==null).sort((x,y)=>x-y);return {n:b.length,mean:+(b.reduce((s,x)=>s+x,0)/b.length).toFixed(2),p50:+b[Math.floor(b.length/2)].toFixed(2),p95:+b[Math.floor(b.length*.95)].toFixed(2),max:+b[b.length-1].toFixed(2),miss:a.length-b.length};};
 out.mv=st(out.mv.lat);out.dash.lat=st(out.dash.lat);out.ver=VER_TAG;return out;}"""
async def main():
    res={}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for tag,url,fl in [('1.5.11','game.html',[]),('1.5.13','g153.html',[])]:
            for hz in (60,90,120,144):
                P=await newpage(b,1280,760,url=D+url,init=INIT%json.dumps(fl),clear=False)
                try:r=await P.js(RUN,dict(hz=hz,reps=200,durs=[4,8,12,16,25,40,80]))
                except Exception as e:r={'err':str(e)[:300]}
                r['errs']=P.errs[:2];await P.pg.context.close();res[f'{tag}@{hz}']=r;print(tag,hz,json.dumps(r,ensure_ascii=False)[:600],flush=True)
        await b.close()
    json.dump(res,open(sys.argv[1],'w'),ensure_ascii=False,indent=1)
asyncio.run(main())
