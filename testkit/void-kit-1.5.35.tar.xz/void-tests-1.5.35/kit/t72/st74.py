# Этап 4 · прототип варианта C (накопитель, шаг 1/60) ВНУТРИ стенда: рабочая сборка не меняется,
# frame подменяется только в странице теста. Проверка: исход по номеру шага не зависит от частоты кадров.
# python3 proto74.py <jobs.json> <out.jsonl> [par]
import asyncio,json,sys,time
sys.path.insert(0,'@@KIT@@')
from h import *
INIT="""(()=>{let a=%d;const R=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
window.__rt={n:0};Math.random=function(){window.__rt.n++;return R();};window.requestAnimationFrame=()=>0;})();"""
RUN=r"""(J)=>{
 const STEP=1/60,MAXN=3;let ACC=0,ST=0;
 const live=()=>G.state==='play'||G.state==='world';
 if(J.mode==='direct'||J.mode==='frameC')hs90=function(d,prio){if(!inMission()||G.state!=='play')return;const now=ST;if(prio<1&&G.hsLast90&&now-G.hsLast90<.5)return;G.hsLast90=now;const H_=G.hs90;
   if(H_&&H_.t>d&&prio<=(H_.prio||0))return;G.hs90={t:d,ramp:prio>=2?.4:prio>=1?.15:0,prio:prio||0};};
 const stepC=()=>{ST+=STEP;if(J.camStep)camStep(STEP);let k=1;
   if(G.resumeK>0&&live()){G.resumeK=Math.max(0,G.resumeK-STEP);if(G.resumeK>0)k*=.3;}
   const S_=G.slow95;if(S_&&S_.t>0&&live()){S_.t-=STEP;k*=S_.k;if(S_.t<=0)G.slow95=null;}
   G.rdt90=STEP*k;let kh=1;const H_=G.hs90;
   if(H_&&G.state==='play'){if(H_.t>0){H_.t-=STEP;kh=.04;}else if(H_.ramp>0){const r0=H_.ramp;H_.ramp-=STEP;kh=.3+.7*(1-r0/.4);}else G.hs90=null;}
   const dt=STEP*k*kh;const reps=devOn('speed')?2:1;G.rdtU96=reps;
   if(G.state==='play'){for(let r=0;r<reps&&G.state==='play';r++)update(dt);}
   else if(G.state==='world'){if(G.prologue)prologueTick(dt);else worldUpdate(dt);}};
 const camStep=(dt)=>{const zt=camZTarget(),z=G.camZ||1;if(Math.abs(zt-z)>.001){G.camZ=z+clamp(zt-z,-.15*dt,.15*dt);setScale();}};
 const mobTickC=(dt,now)=>{if(!J.camStep||!live())camStep(dt);touchTick(dt);qTick(dt,now);wakeSync(now);padTick(now);tutTick();};
 const frameC=(now)=>{if(isMob()&&SET.fps===30&&now-last<29&&now>=last)return 0;
   const dt0=Math.min(.05,Math.max(0,(now-last)/1000));last=now;try{mobTickC(dt0,now);}catch(e){}
   let n=0;if(!live())ACC=0;else{ACC=Math.min(ACC+dt0,STEP*MAXN+1e-9);while(ACC>=STEP-1e-9&&n<MAXN&&live()){ACC-=STEP;n++;stepC();}}
   if(G.state==='play'){if(G.mode==='endless')updateEndlessHUD();else updateHUD();}else if(G.state==='world'&&!G.prologue)updateWorldHUD();
   try{musicTick(dt0);}catch(e){}
   try{if(G.world&&G.player)renderWorld(now);else render(now);mobOverlay(now);drawDevOverlay();}catch(e){}
   return n;};
 if(J.noRender){render=function(){};renderWorld=function(){};mobOverlay=function(){};}
 if(J.cineMode)SET.cine=J.cineMode;audioWake();T.fresh();const enc=J.enc;if(enc!=='wt')G.save.tut.off=1;let m=0,zb=false,wd=false,xm=false,wv=null,n=null,p;
 if(enc==='pro'){localStorage.removeItem('void_world');startWorld(true);}
 if(enc==='50')zb=true;else if(enc==='wt'||enc==='pro')xm=true;else if(enc==='w')wd=true;else if(enc==='endless'||enc==='post')xm=true;else m=+enc;
 const G0=G.save;if(enc!=='wt'&&enc!=='pro'){G0.cleared=Math.max(G0.cleared,(m||50)-1);for(let k=1;k<(m||50);k++)G0.medals[k]={clear:1};}SET.fps=J.mob&&J.fps30?30:60;
 if(enc==='wt'||enc==='pro'){}else if(enc==='endless'){startEndless();if(G.state==='intro')startMission();}else if(enc==='post'){postEnter();if(G.state==='intro')startMission();}
 else if(wd){G0.cleared=9;for(let k=1;k<=9;k++)G0.medals[k]={clear:1};G0.story.absorbed=EROSION_FULL*.4;p=G.player;let bd=1e18;for(const e of riftEdges()){const mx=(e[0]+e[2])/2,my=(e[1]+e[3])/2,ox=e[4],oy=e[5],qx=mx+ox*1600,qy=my+oy*1600;if(!(ox||oy)||qx<200||qy<200||qx>WW-200||qy>WH-200||inSectors(qx,qy)||inSectors(mx-ox*250,my-oy*250)===false)continue;const d=Math.hypot(mx-p.x,my-p.y);if(d<bd){bd=d;wv={x:mx,y:my,ux:ox,uy:oy};}}p.x=wv.x-wv.ux*250;p.y=wv.y-wv.uy*250;p.vx=p.vy=0;}
 else if(zb){G.zbCool=0;n=zbNode();p=G.player;p.x=n.x-200;p.y=n.y;zbStart();}
 else{enterNode(m);if(G.state==='intro')startMission();if(J.boss){while(G.state==='levelup')choose(0);G.enemies=[];G.warns=[];G.eb=[];G.waveIdx=G.waves.length;G.gapT=.1;}}
 let now=50000;window.__pn=now;performance.now=()=>window.__pn;last=now;
 const FP=()=>{const p=G.player,A=[+G.t,G.state,G.kills||0,G.taken||0,G.xp||0,G.lvl||0,G.score||0];if(p)A.push(p.x,p.y,p.hp,p.en,p.vx,p.vy,p.inv||0);
   for(const e of (G.enemies||[]))A.push(e.type,e.x,e.y,e.hp,e.alive?1:0);A.push((G.eb||[]).length,(G.pb||[]).length,(G.pick||[]).length);
   for(const b of (G.eb||[]))A.push(b.x,b.y);const B=G.boss||G.jam||G.sb;if(B)A.push(B.hp,B.phase,B.x,B.y);if(G.zb){const Z=G.zb;A.push(Z.k,Z.stage,Z.t,Z.boss?Z.boss.hp:0);}A.push(window.__rt.n);
   const s=JSON.stringify(A);let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16);};
 let s=0;const fps=[],N=J.steps;
 const bot=()=>{const p=G.player;if(!p)return;if(p.hp<G.st.maxHp*.4)p.hp=G.st.maxHp*.4;
   const tg=(wd||xm)?null:zb?(G.zb&&G.zb.boss):(G.boss||G.jam||G.sb||G.enemies.find(e=>e.alive&&dvBossy(e))||null);const A=s/90;
   if(wd){const k=-300+1650*(1-Math.cos(s/900*Math.PI));steer2(wv.x+wv.ux*k+Math.cos(s/40)*60,wv.y+wv.uy*k+Math.sin(s/40)*60);}
   else if(xm){const cx=G.world?p.x+Math.cos(A)*300:W/2+Math.cos(A)*Math.min(W,H)*.3,cy=G.world?p.y+Math.sin(A)*300:H/2+Math.sin(A)*Math.min(W,H)*.3;steer2(cx,cy);}
   else{const cx=tg?tg.x:(zb?n.x:W/2),cy=tg?tg.y:(zb?n.y:H/2),R=tg?200:Math.min(W,H)*.3;steer2(cx+Math.cos(A)*R,cy+Math.sin(A)*R);}
   if(s%170===0)tryDash();if(p.en>=100)tryPulse();};
 {const f=update;update=function(dt){bot();const r=f.apply(this,arguments);s++;if(s%60===0)fps.push(FP());return r;};}
 {const f=worldUpdate;worldUpdate=function(dt){bot();const r=f.apply(this,arguments);s++;if(s%60===0)fps.push(FP());return r;};}
 {const f=prologueTick;prologueTick=function(dt){const r=f.apply(this,arguments);s++;if(s%60===0)fps.push(FP());return r;};}
 let jit=J.seed*7919+13;const jr=()=>{jit=(jit*1103515245+12345)%2147483648;return jit/2147483648;};
 const prof=J.prof,base=J.mob?1000/60:{p30:1000/30,p60:1000/60,p90:1000/90,p120:1000/120,p144:1000/144,p50:20,p15:1000/15}[prof]||1000/60;
 let R=0;const nd=()=>prof==='jit'?1000/60*(.55+.9*jr()):prof==='hic'?((Math.floor((R+1000/60)/3000)>Math.floor(R/3000))?140:1000/60):base;
 const t0=performance.now.call(performance);let frames=0,zero=0,two=0,three=0,guard=0;const wall0=Date.now();
 const between=()=>{let k=0;while(G.state==='levelup'&&k++<20)choose(0);if(zb){const Z=G.zb;if(Z&&Z.k==='choice'){try{zbChoose(0);}catch(e){}}}};
 const EV=J.ev||null;let evDone=false,hold=0;
 let evS=-1;const evCheck=(direct)=>{if(!EV||evDone||s<EV.at)return;evDone=true;evS=s;
   if(EV.k==='pause'){pause();if(direct)resume();else hold=R+EV.ms;}
   else if(EV.k==='pauseT'){touchMode=true;pause();if(direct)resume();else hold=R+EV.ms;}
   else if(EV.k==='hide'){pause();lifeSave();if(!direct){now+=EV.ms;R+=EV.ms;window.__pn=now;}resume();}
   else if(EV.k==='enter'){if(G.state==='world'){enterNode(2);if(G.state==='intro')startMission();}}
   else if(EV.k==='menu'){toMenu();startWorld(false);if(G.prologue)prologueEnd();}
   else if(EV.k==='fx'){SET.fx=!SET.fx;try{fx25();}catch(e){}}
   else if(EV.k==='slow'){slow95(1.2,.35);}else if(EV.k==='hs'){hs90(.25,2);}};
 const stepG=()=>window.step74();
 const CNT={hs:0,slow:0,rk:0};{const h=hs90;hs90=function(){CNT.hs++;return h.apply(this,arguments);};const sl=slow95;slow95=function(){CNT.slow++;return sl.apply(this,arguments);};}
 const stepE3=()=>{if(G.resumeK>0)CNT.rk++;if(G.state==='play')update(1/60);else if(G.state==='world'){if(G.prologue)prologueTick(1/60);else worldUpdate(1/60);}};
 if(J.mode==='direct'||J.mode==='gdirect'||J.mode==='e3'){const st=J.mode==='direct'?stepC:J.mode==='e3'?stepE3:stepG;while(s<N&&guard++<N*3){between();evCheck(true);between();if(!live())break;st();}}
 else if(J.mode==='game'){while(s<N&&guard++<N*20){between();evCheck(false);between();if(hold&&R>=hold){hold=0;resume();}if(!live()&&!hold)break;const d=nd();R+=d;now+=d;window.__pn=now;const s0=s;frame(now);frames++;const k=s-s0;if(k===0)zero++;else if(k===2)two++;else if(k===3)three++;}}
 else if(J.mode==='frameC'){while(s<N&&guard++<N*20){between();evCheck(false);if(hold&&R>=hold){hold=0;resume();}if(!live()&&!hold)break;const d=nd();R+=d;now+=d;window.__pn=now;const k=frameC(now);frames++;if(k===0)zero++;else if(k===2)two++;else if(k===3)three++;}}
 else{while(s<N&&guard++<N*20){between();if(!live())break;const d=nd();R+=d;now+=d;window.__pn=now;frame(now);frames++;}}
 for(const k of KK)KEYS[k]=false;
 const DEEP=(()=>{const seen=new WeakSet();let s;try{s=JSON.stringify([G.player,G.enemies,G.eb,G.pb,G.pick,G.boss,G.zb,G.post,CX,CY,G.camZ],(k,v)=>{if(k==='motes')return 'M';if(v&&typeof v==='object'){if(seen.has(v))return '~';if(v instanceof Node)return 'N';seen.add(v);}return v;});}catch(e){s='ERR'+e;}let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}if(J.deepDump)window.__deep=s;return (h>>>0).toString(16)+':'+s.length;})();
 return {evS,deepS:J.deepDump?window.__deep:undefined,deep:DEEP,ver:VER_TAG,steps:s,fp:fps,frames,zero,two,three,realT:+(R/1000).toFixed(2),simT:+G.t.toFixed(3),st:G.state,kills:G.kills||0,taken:Math.round(G.taken||0),rng:window.__rt.n,cnt:CNT,ip:(typeof IP76!=='undefined'?{...IP76.st,act:IP76.act,ema:+IP76.ema.toFixed(5)}:null),c66:(typeof C66!=='undefined'&&C66.M?{t:+C66.M.t.toFixed(3),slow:C66.M.slow}:null),wall:(Date.now()-wall0)/1000};}"""
async def one(b,J):
    mob=bool(J.get('mob'));vw,vh=(390,844) if mob else (1280,760)
    for _try in range(3):
        try:
            P=await newpage(b,vw,vh,url=J['url'],init=(INIT%J.get('seed',7)).replace('window.requestAnimationFrame=()=>0;','window.requestAnimationFrame=()=>0;window.__archOff=%s;%s'%(json.dumps(J.get('flags',[])),('window.__cine66=1;' if J.get('cine') else '')+('window.__ip76mode="x";' if J.get('ipx') else ''))),touch=mob,clear=False);break
        except Exception as e:
            if _try==2:return {'id':J['id'],'err':'LOAD '+str(e)[:200],'nerr':1,'errs':[]}
    try:r=await P.js(RUN,J)
    except Exception as e:r={'err':str(e)[:400]}
    r['id']=J['id'];r['nerr']=len(P.errs);r['errs']=P.errs[:2];await P.pg.context.close();return r
async def main():
    import os
    done=set(json.loads(l)['id'] for l in open(sys.argv[2])) if os.path.exists(sys.argv[2]) else set()
    jobs=[j for j in json.load(open(sys.argv[1])) if j['id'] not in done];out=open(sys.argv[2],'a');par=int(sys.argv[3]) if len(sys.argv)>3 else 2
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        q=asyncio.Queue()
        for j in jobs:q.put_nowait(j)
        async def w():
            while not q.empty():
                J=await q.get();r=await one(b,J);out.write(json.dumps(r,ensure_ascii=False)+'\n');out.flush()
                print(r['id'],'steps',r.get('steps'),'fr',r.get('frames'),'0/2/3',r.get('zero'),r.get('two'),r.get('three'),'k',r.get('kills'),'tk',r.get('taken'),'err',r.get('nerr'),r.get('err','')[:150],flush=True)
        await asyncio.gather(*[w() for _ in range(par)])
        await b.close()
asyncio.run(main())
