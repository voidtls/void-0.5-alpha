import asyncio,sys
sys.path.insert(0,'@@KIT@@')
from h import *
async def main():
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for vw,vh,t,nm in [(1280,760,False,'pc'),(390,844,True,'ph')]:
            P=await newpage(b,vw,vh,url='file://'+sys.argv[1],init="window.__devUI=true;window.requestAnimationFrame=()=>0;",touch=t,clear=False)
            await P.js("""()=>{audioWake();T.fresh();G.save.tut.off=1;G.dev.diag77=true;const S=G.save;S.cleared=9;for(let k=1;k<10;k++)S.medals[k]={clear:1};enterNode(10);if(G.state==='intro')startMission();
              let now=50000;performance.now=()=>now;last=now;for(let i=0;i<900;i++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);const p=G.player;if(p){p.hp=G.st.maxHp;const A=i/120;steer2(p.x+Math.cos(A)*300,p.y+Math.sin(A)*300);}now+=1000/144+(i%7===0?0.4:0);frame(now);}}""")
            await P.pg.screenshot(path=f'shot77_{nm}.png');await P.pg.context.close()
        await b.close()
asyncio.run(main())
