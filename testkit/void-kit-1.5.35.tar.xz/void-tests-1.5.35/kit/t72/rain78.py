# ARCH·78 · воспроизведение: (1) чей Math.random работает внутри w58Screen; (2) двигаются ли снег/дождь при A-23.
# python3 snow78.py <url> <out.json> [flags-json]
import asyncio,json,sys
sys.path.insert(0,'@@KIT@@')
from h import *
INIT="""(()=>{let a=9;const R=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
window.__gameR=function(){window.__gn=(window.__gn||0)+1;return R();};Math.random=window.__gameR;window.requestAnimationFrame=()=>0;window.__archOff=%s;})();"""
RUN=r"""(J)=>{audioWake();T.fresh();G.save.tut.off=1;SET.fx=true;let now=50000;performance.now=()=>now;last=now;
 const trace={calls:0,vfx:0,game:0,other:0,gameDraws:0};
 {const f=w58Screen;w58Screen=function(){trace.calls++;const r=Math.random;if(r===VFXR65)trace.vfx++;else if(r===window.__gameR)trace.game++;else trace.other++;const g0=window.__gn||0;const out=f.apply(this,arguments);trace.gameDraws+=(window.__gn||0)-g0;return out;};}
 const F=1000/J.hz;const tick=()=>{now+=F;if(G.w&&G.player){try{G.w.storms.__t={x:G.player.x,y:G.player.y,k:1,ph:'on',kind:'rain',t:0,T:99};}catch(e){}}frame(now);};
 for(let i=0;i<Math.round(J.hz*1.5);i++)tick();
 const w=G.w;if(!w||!w.rain||!w.rain.length)return {err:'нет дождя',st:G.state,w:!!w,trace};
 const S=w.rain.slice(0,8),p0=S.map(f=>[f.x,f.y]);const n=Math.round(J.hz*1);let moved=0,frames=0,stuck=0;
 for(let i=0;i<n;i++){const b=S.map(f=>[f.x,f.y]);tick();frames++;let any=false;for(let k=0;k<S.length;k++){if(S[k].x!==b[k][0]||S[k].y!==b[k][1])any=true;}if(any)moved++;else stuck++;}
 const dy=S.map((f,k)=>{let d=f.y-p0[k][1];if(d<0)d+=1;return +d.toFixed(4);});
 return {hz:J.hz,act:typeof IP76!=='undefined'?IP76.act:null,ip:typeof IP76!=='undefined'?IP76.st.ip:null,snowN:w.rain.length,framesMoved:moved,framesStuck:stuck,dySecond:dy,trace};}"""
async def main():
    url,out=sys.argv[1],sys.argv[2];fl=sys.argv[3] if len(sys.argv)>3 else '[]';res={}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for hz in (60,144):
            P=await newpage(b,1280,760,url=url,init=INIT%fl,clear=False)
            try:r=await P.js(RUN,dict(hz=hz))
            except Exception as e:r={'err':str(e)[:300]}
            r['errs']=P.errs[:2];await P.pg.context.close();res[hz]=r;print(hz,json.dumps(r,ensure_ascii=False),flush=True)
        await b.close()
    json.dump(res,open(out,'w'),ensure_ascii=False)
asyncio.run(main())
