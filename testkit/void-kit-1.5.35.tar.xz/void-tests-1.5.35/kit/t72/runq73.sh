cd @@KIT@@/t72
python3 st74.py jobs_k1.json k1.jsonl 2 > k1.log 2>&1; echo K1END >> q73.txt
python3 st74.py jobs_k3.json k3.jsonl 2 > k3.log 2>&1; echo K3END >> q73.txt
python3 st74.py jobs_k3t.json k3t.jsonl 2 > k3t.log 2>&1; echo K3TEND >> q73.txt
python3 fps74.py jobs_k5.json k5.jsonl 2 > k5.log 2>&1; echo K5END >> q73.txt
