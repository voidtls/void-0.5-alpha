cd @@KIT@@/t72
while ! grep -q K2223END q73.txt 2>/dev/null; do sleep 20; done
python3 input74.py input74.json > input74.log 2>&1; echo INPUTEND >> q73.txt
python3 fps74.py jobs_k6.json k6.jsonl 2 > k6.log 2>&1; echo K6END >> q73.txt
python3 fps74.py jobs_rt.json rt.jsonl 2 > rt.log 2>&1; echo RTEND >> q73.txt
