# K6 · эквивалентность баланса на 60 Гц: 1.5.13 против 1.5.11, по сценариям, метрики на прогон.
# TOST (два односторонних t-теста Уэлча, α=0,05) на относительную разницу средних в пределах ±δ, δ=5 %; поправка Холма по метрикам сценария.
# Плюс бутстреп-интервал 95 % относительной разницы. «Нет значимой разницы» не считается эквивалентностью.
import json,sys,math,random,collections
from statistics import mean,stdev
from scipy.stats import t as _T
def tcdf(t,df):return float(_T.cdf(t,df))
def welch(a,b):
    ma,mb=mean(a),mean(b);va,vb=stdev(a)**2/len(a),stdev(b)**2/len(b);se=math.sqrt(va+vb) or 1e-12
    df=(va+vb)**2/((va*va/(len(a)-1) if va else 0)+(vb*vb/(len(b)-1) if vb else 0) or 1e-12)
    return ma,mb,se,max(1,df)
R=[json.loads(l) for l in open(sys.argv[1])]
D=collections.defaultdict(lambda:collections.defaultdict(list))
AA=len(sys.argv)>3 and sys.argv[3]=='aa'
for r in R:
    if r.get('err'):continue
    pre,sc,ver,sd=r['id'].split('/')
    if not AA:
        if pre!='k6':continue
        D[sc][ver].append(r)
    else:
        # A/A: 1.5.11 на зёрнах 1–24 (k6) против 1.5.11 на зёрнах 25–48 (aa); вторая группа подставляется на место «1513»
        if ver!='1511':continue
        D[sc]['1511' if pre=='k6' else '1513'].append(r)
MET=['kills','dmg','taken','shots','spawn','hurtN','simT']
DELTA=float(sys.argv[2]) if len(sys.argv)>2 else .05
random.seed(1);out={}
for sc in sorted(D):
    A=D[sc].get('1511',[]);B=D[sc].get('1513',[])
    res=[]
    for m in MET:
        a=[float(x.get(m) or 0) for x in A];b=[float(x.get(m) or 0) for x in B]
        if len(a)<3 or len(b)<3:continue
        ma,mb,se,df=welch(b,a)
        if ma==mb and se<1e-9:res.append((m,ma,mb,0.0,(0,0),0.0,'идентично'));continue
        base=abs(mb) or 1;lo,hi=-DELTA*base,DELTA*base;d=ma-mb
        p1=1-tcdf((d-lo)/se,df);p2=tcdf((d-hi)/se,df);p=max(p1,p2)
        bs=[]
        for _ in range(2000):
            sa=[random.choice(a) for _ in a];sb=[random.choice(b) for _ in b];bs.append((mean(sb)-mean(sa))/base)
        bs.sort();ci=(bs[50],bs[1949])
        res.append((m,mb,ma,(ma-mb)/base,ci,p,None))
    # Холм
    ps=sorted([(r[5],i) for i,r in enumerate(res) if r[6] is None]);k=len(ps);ok=set()
    for j,(p,i) in enumerate(ps):
        if p<=.05/(k-j):ok.add(i)
        else:break
    print(f'== {sc}: 1.5.11 n={len(A)}, 1.5.13 n={len(B)}')
    rows=[]
    for i,(m,mb,ma,rel,ci,p,tag) in enumerate(res):
        verdict=tag or ('эквивалентно' if i in ok else 'эквивалентность не доказана')
        print(f'   {m:6s} 1.5.11 {mb:9.2f}  1.5.13 {ma:9.2f}  разница {100*rel:+6.2f}%  бутстреп95 [{100*ci[0]:+6.2f}%, {100*ci[1]:+6.2f}%]  p_TOST {p:.4f}  {verdict}')
        rows.append(dict(m=m,old=mb,new=ma,rel=rel,ci=ci,p=p,verdict=verdict))
    out[sc]=rows
json.dump(out,open(sys.argv[1]+'.stat.json','w'),ensure_ascii=False,indent=1)
