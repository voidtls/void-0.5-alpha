# ARCH·80 · маршруты A-24 в мире: неподвижные (закреплённые) враги, корабль летит по заданной программе.
# Сравнение A-24 выкл/вкл на 60 и 144 Гц: цели и выстрелы должны совпасть, меняются только корпус и точка вылета.
# python3 a24route.py <out.json>
import asyncio,json,sys
sys.path.insert(0,'@@KIT@@')
from h import *
D='@@KIT@@/t72/'
INIT="""(()=>{let a=13;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};window.requestAnimationFrame=()=>0;%s})();"""
ROUTES={
 'away':   dict(en=[[300,0]],prog=[[-1,0,3.0]]),
 'side':   dict(en=[[300,0]],prog=[[0,1,3.0]]),
 'diag':   dict(en=[[300,0]],prog=[[-1,-1,3.0]]),
 'turn':   dict(en=[[300,0]],prog=[[-1,0,1.5],[1,0,1.5]]),
 'stop':   dict(en=[[300,0]],prog=[[-1,0,1.0],[0,0,.4],[-1,0,1.0]]),
 'multi':  dict(en=[[300,0],[60,280],[-420,-60]],prog=[[-1,0,1.2],[0,1,1.2],[1,-1,1.2]]),
 'reenter':dict(en=[[300,0]],prog=[[-1,0,2.6],[1,0,3.0]]),
 'dash0':  dict(en=[[300,0]],prog=[[-1,0,1.0],[0,0,.03,'dash'],[0,0,.6]]),
 'circle': dict(en=[[260,0]],prog=[[0,1,.6],[-1,1,.6],[-1,0,.6],[-1,-1,.6],[0,-1,.6],[1,-1,.6]]),
}
RUN=r"""(J)=>{audioWake();T.fresh();G.save.tut.off=1;let now=50000;performance.now=()=>now;last=now;
 for(let i=0;i<30;i++){now+=1000/60;frame(now);}
 const p=G.player;p.vx=p.vy=0;G.enemies.length=0;G.eb.length=0;G.pb.length=0;G.prio=null;const ox=p.x,oy=p.y;
 const E=J.en.map(([dx,dy],i)=>{const e=spawnEnemy('scout',ox+dx,oy+dy);e.spawnT=0;e.__k=i;return e;});
 const pin=()=>{for(let i=0;i<E.length;i++){const e=E[i];e.x=ox+J.en[i][0];e.y=oy+J.en[i][1];e.vx=e.vy=0;e.hp=1e9;e.alive=true;e.spawnT=0;}
   G.enemies=G.enemies.filter(e=>E.includes(e));G.eb.length=0;p.hp=G.st.maxHp;p.inv=1;};
 const log=[];const up=updatePlayer;let seg=0;
 updatePlayer=function(dt){pin();const n0=G.pb.length;const r=up.apply(this,arguments);const tg=G.tg90;const A=ARCH.a24s||{};
   let mz=[];for(let i=n0;i<G.pb.length;i++){const b=G.pb[i];if(b.drone)continue;const a=Math.atan2(b.vy,b.vx);mz.push(+(((b.x-p.x)*Math.cos(a)+(b.y-p.y)*Math.sin(a))).toFixed(3));}
   const sp=Math.hypot(p.vx,p.vy);let aim=null,dist=null;if(tg){const q=aimPt(tg);aim=Math.atan2(q.y-p.y,q.x-p.x);dist=Math.hypot(q.x-p.x,q.y-p.y);}
   log.push([seg,+p.ang.toFixed(6),tg?tg.__k:-1,aim===null?null:+aim.toFixed(6),+Math.atan2(p.vy,p.vx).toFixed(6),+sp.toFixed(2),A.w===undefined?0:+A.w.toFixed(4),mz,dist===null?null:+dist.toFixed(1),+p.x.toFixed(2),+p.y.toFixed(2),typeof a24Hull==='function'?a24Hull(p):p.ang]);return r;};
 const F=1000/J.hz;let dashAng=null;
 for(seg=0;seg<J.prog.length;seg++){const [dx,dy,T,act]=J.prog[seg];const n=Math.round(T*J.hz);
   for(let i=0;i<n;i++){const k=1000;if(dx||dy)steer2(p.x+dx*k,p.y+dy*k);else steer2(p.x,p.y);
     if(act==='dash'&&i===0){const a0=p.ang;tryDash();dashAng=[+a0.toFixed(6),+Math.atan2(p.dy,p.dx).toFixed(6)];}
     now+=F;frame(now);}}
 updatePlayer=up;
 return {log,dashAng,a24:!!ARCH.a24,n:ARCH.a24s?ARCH.a24s.n:0};}"""
async def main():
    out=sys.argv[1];res={}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for hz in (60,):
            for rn,R in [(k,v) for k,v in ROUTES.items() if k in ('away','multi','turn','circle')]:
                for v,init in (('off',''),('on','window.__a24on=true;')):
                    P=await newpage(b,1280,760,url='file://'+D+'g160.html',init=INIT%init,clear=False)
                    try:r=await P.js(RUN,dict(hz=hz,**R))
                    except Exception as e:r={'err':str(e)[:300]}
                    r['errs']=P.errs[:2];await P.pg.context.close();res[f'{hz}/{rn}/{v}']=r
                    print(hz,rn,v,r.get('err',''),r['errs'],len(r.get('log',[])),r.get('n'),r.get('dashAng'),flush=True)
        await b.close()
    json.dump(res,open(out,'w'))
asyncio.run(main())
