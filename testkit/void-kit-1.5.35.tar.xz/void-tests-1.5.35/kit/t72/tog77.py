import asyncio,sys,json
sys.path.insert(0,'@@KIT@@')
from h import *
async def main():
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        P=await newpage(b,1280,760,url='file://'+sys.argv[1]+'?dev',clear=True)
        r=await P.js("""async()=>{openDev();await new Promise(r=>setTimeout(r,300));const b=[...document.querySelectorAll('#devToggles .dtog')].map(x=>x.textContent);
          document.querySelector('.dtog[data-d=diag77]').click();const on=G.dev.diag77;startEndless(true);if(G.state==='intro')startMission();await new Promise(r=>setTimeout(r,2500));
          const st=D77.on,rows=D77.n;toMenu();openDev();document.querySelector('.dtog[data-d=diag77]').click();await new Promise(r=>setTimeout(r,500));
          return {b,on,st,rows,off:G.dev.diag77,d77on:D77.on,exp:window.__diag77last?{why:__diag77last.why,rows:__diag77last.rows.length,ver:__diag77last.ver}:null,stored:JSON.parse(localStorage.getItem('void_dev')||'{}').diag77};}""")
        print(json.dumps(r,ensure_ascii=False),P.errs[:3]);await b.close()
asyncio.run(main())
