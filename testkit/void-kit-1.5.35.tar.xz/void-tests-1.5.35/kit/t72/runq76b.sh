cd @@KIT@@/t72
while ! grep -q KALLDONE ../reg16i/done.txt 2>/dev/null; do sleep 30; done
for e in "10 0" "22 1" "46 1" "50 0" "world 0" "endless 0" "post 0" "6 1" "38 1" "14 1" "27 1"; do set -- $e; timeout 900 python3 mot76.py file://$PWD/g156.html $1 $2 900 cov2_$1.json > cov2_$1.txt 2>&1; done; echo COV2END >> q73.txt
python3 st74.py jobs_k23b.json k23b.jsonl 2 > k23b.log 2>&1; echo K23BEND >> q73.txt
python3 perf76.py perf156r.json 8 > perf156r.log 2>&1; echo PERF76REND >> q73.txt
