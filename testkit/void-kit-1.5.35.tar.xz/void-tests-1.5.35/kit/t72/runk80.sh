cd @@KIT@@/t72
python3 st74.py jobs_k80.json k80.jsonl 2 > k80.log 2>&1; echo K80END >> q80.txt
python3 st74.py jobs_e24.json e24.jsonl 2 > e24.log 2>&1; echo E24END >> q80.txt
