import asyncio,json,sys
sys.path.insert(0,'@@KIT@@')
from h import *
D='file://@@KIT@@/t72/'
INIT="""(()=>{let a=7;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};window.requestAnimationFrame=()=>0;window.__archOff=%s;})();"""
RUN=r"""()=>{render=function(){};renderWorld=function(){};audioWake();T.fresh();G.save.tut.off=1;G.save.cleared=1;G.save.medals[1]={clear:1};enterNode(2);if(G.state==='intro')startMission();
 while(G.state==="levelup")choose(0);updateWaves=function(){};G.enemies=[];G.warns=[];G.eb=[];const p=G.player;window.__st=G.state;let now=90000;performance.now=()=>now;last=now;frame(now);
 const tr=[];const fr=()=>{now+=1000/60;frame(now);tr.push([+p.x.toFixed(2),+(p.dashT||0).toFixed(4),+p.vx.toFixed(1),+(G.rdt90||0).toFixed(5)]);};
 for(let i=0;i<20;i++)fr();p.x=200;p.vx=p.vy=0;p.dashCd=0;tryDash([1,0]);for(let i=0;i<16;i++)fr();
 const h=[];const t0=G.t;hs90(.25,2);for(let i=0;i<60;i++){now+=1000/60;frame(now);h.push(+(G.t-t0).toFixed(4));}
 return {st:window.__st,dash:tr.slice(20),hs:h}}"""
async def main():
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        R={}
        for tag,u,fl in [('old','game.html',[]),('new','g153.html',[]),('newOff','g153.html',['A-20'])]:
            P=await newpage(b,url=D+u,init=INIT%json.dumps(fl),clear=False);R[tag]=await P.js(RUN);R[tag]['errs']=P.errs[:2];await P.pg.context.close()
        await b.close()
    for k in ['dash','hs']:
        for i in range(max(len(R['old'][k]),len(R['new'][k]))):
            a=R['old'][k][i] if i<len(R['old'][k]) else None;c=R['new'][k][i] if i<len(R['new'][k]) else None
            if a!=c or i<3:print(k,i,'old',a,'new',c)
asyncio.run(main())
