import json,math,sys
R=json.load(open(sys.argv[1]))
def ad(a,b):
    d=(a-b)%(2*math.pi)
    if d>math.pi:d-=2*math.pi
    return d
print('маршрут        цели= выстр= | макс Δугла/шаг off/on (°) | ср. откл. корпуса от полёта при удалении off/on (°) | макс откл. корпуса от цели on (°) | точка вылета мин (px) off/on | смен цели/с')
for k in sorted(R):
    hz,rn,v=k.split('/')
    if v!='off':continue
    A=R[k]['log'];B=R[f'{hz}/{rn}/on']['log']
    tgA=[x[2] for x in A];tgB=[x[2] for x in B]
    shA=sum(len(x[7]) for x in A);shB=sum(len(x[7]) for x in B)
    pos=all(abs(a[9]-b[9])<1e-6 and abs(a[10]-b[10])<1e-6 for a,b in zip(A,B))
    dA=max(abs(ad(A[i][1],A[i-1][1])) for i in range(1,len(A)));dB=max(abs(ad(B[i][1],B[i-1][1])) for i in range(1,len(B)))
    def dev(L):
        v=[abs(ad(x[1],x[4])) for x in L if x[5]>150 and x[3] is not None and math.cos(ad(x[4],x[3]))<-.3]
        return (sum(v)/len(v)*180/math.pi if v else float('nan')),len(v)
    da,na=dev(A);db,nb=dev(B)
    mt=max([abs(ad(x[1],x[3])) for x in B if x[3] is not None] or [0])*180/math.pi
    mzA=min([m for x in A for m in x[7]] or [99]);mzB=min([m for x in B for m in x[7]] or [99])
    sw=sum(1 for i in range(1,len(A)) if A[i][2]!=A[i-1][2] and A[i][2]!=-1 and A[i-1][2]!=-1)/(len(A)/60)
    print(f'{hz:>3} {rn:8s} {str(tgA==tgB):5s} {str(shA==shB):5s} поз={pos} | {dA*180/math.pi:5.1f}/{dB*180/math.pi:5.1f} | {da:6.1f}/{db:6.1f} (n={nb}) | {mt:6.1f} | {mzA:6.2f}/{mzB:6.2f} | {sw:.2f}  выстр {shA}/{shB}')
