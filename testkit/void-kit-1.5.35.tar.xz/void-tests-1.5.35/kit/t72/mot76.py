# 4.5 · перепись движущихся объектов: какие объекты, достижимые из G (и камера CX/CY), меняют x/y между шагами.
# Нужна для измеримого покрытия интерполяции: доля перемещения (px·объект), которую покрывает выбранный список путей.
# python3 mot76.py <url> <enc> <boss> <steps> <out.json>
import asyncio,json,sys
sys.path.insert(0,'@@KIT@@')
from h import *
INIT="""(()=>{let a=1;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};window.requestAnimationFrame=()=>0;})();"""
RUN=r"""(J)=>{audioWake();T.fresh();G.save.tut.off=1;const enc=J.enc;let m=+enc,zb=enc==='50';
 const G0=G.save;G0.cleared=Math.max(G0.cleared,(m||50)-1);for(let k=1;k<(m||50);k++)G0.medals[k]={clear:1};
 if(enc==='endless'){startEndless();if(G.state==='intro')startMission();}else if(enc==='post'){postEnter();if(G.state==='intro')startMission();}
 else if(enc==='world'){}else if(zb){G.zbCool=0;const n=zbNode();const p=G.player;p.x=n.x-200;p.y=n.y;zbStart();}
 else{enterNode(m);if(G.state==='intro')startMission();if(J.boss){while(G.state==='levelup')choose(0);G.enemies=[];G.warns=[];G.eb=[];G.waveIdx=G.waves.length;G.gapT=.1;}}
 let now=50000;performance.now=()=>now;last=now;
 const SKIP=new Set(['save','fog','fogT','world','nodes','dev','mc','runStart','x90','radio','ach','stat']);
 const prev=new Map();const agg={};let objs=0;
 const walk=(o,path,depth,seen,out)=>{if(!o||typeof o!=='object'||seen.has(o))return;seen.add(o);
   if(ArrayBuffer.isView(o))return;
   if(Array.isArray(o)){if(o.length&&typeof o[0]!=='object')return;for(let i=0;i<o.length&&i<600;i++)walk(o[i],path+'[]',depth+1,seen,out);return;}
   if(typeof o.x==='number'&&typeof o.y==='number')out.push([o,path]);
   if(depth>=5)return;for(const k in o){if(SKIP.has(k))continue;const v=o[k];if(v&&typeof v==='object')walk(v,path+'.'+k,depth+1,seen,out);}};
 const fake={x:0,y:0};
 for(let s=0;s<J.steps;s++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);if(zb&&G.zb&&G.zb.k==='choice'){try{zbChoose(0);}catch(e){}}
   if(G.state!=='play'&&G.state!=='world')break;const p=G.player;if(p&&p.hp<G.st.maxHp*.4)p.hp=G.st.maxHp*.4;
   if(p){const A=s/90,tg=G.boss||G.jam||G.sb||null;steer2((tg?tg.x:W/2)+Math.cos(A)*200,(tg?tg.y:H/2)+Math.sin(A)*200);if(s%170===0)tryDash();if(p.en>=100)tryPulse();}
   window.step74();const COV=(typeof ip76Post==='function')?(ip76Post(),IP76.B.m):null;
   const out=[];walk(G,'G',0,new Set(),out);fake.x=CX;fake.y=CY;out.push([fake,'CAM']);objs=Math.max(objs,out.length);
   const cur=new Map();for(const [o,path] of out){const q=prev.get(o);cur.set(o,[o.x,o.y]);if(!q)continue;const d=Math.hypot(o.x-q[0],o.y-q[1]);
     const A=agg[path]||(agg[path]={n:0,mov:0,sum:0,max:0,jump:0,cov:0});A.n++;if(d>0){A.mov++;A.sum+=d;if(d>A.max)A.max=d;if(d>60)A.jump++;if(path==='CAM'||(COV&&COV.has(o)))A.cov+=d;}}
   prev.clear();for(const [o,v] of cur)prev.set(o,v);}
 return {agg,objs,st:G.state,t:G.t};}"""
async def main():
    url,enc,boss,steps,out=sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4]),sys.argv[5]
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        P=await newpage(b,1280,760,url=url,init=INIT,clear=False)
        r=await P.js(RUN,dict(enc=enc,boss=boss,steps=steps));r['errs']=P.errs[:3];await b.close()
    json.dump(r,open(out,'w'),ensure_ascii=False)
    A=r['agg'];tot=sum(a['sum'] for a in A.values()) or 1
    print('COVERAGE %.2f%% of per-step displacement'%(100*sum(a.get('cov',0) for a in A.values())/tot))
    print('objs',r['objs'],'st',r['st'],'t',round(r['t'],2),'errs',r['errs'])
    for k,a in sorted(A.items(),key=lambda kv:-kv[1]['sum'])[:40]:
        print('%-46s share %5.1f%% cov %5.1f%%  moving %6d/%6d  mean %.2f  max %.1f  jumps>60 %d'%(k[:46],100*a['sum']/tot,100*a.get('cov',0)/max(1e-9,a['sum']) if a['sum'] else 100,a['mov'],a['n'],a['sum']/max(1,a['mov']),a['max'],a['jump']))
asyncio.run(main())
