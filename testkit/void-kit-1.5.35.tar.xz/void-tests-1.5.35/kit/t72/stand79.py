# ARCH·79 · стенд модели rAF: реалистичные метки кадров (частота, округление, дрожание vsync, пропуски кадров),
# видимое движение корабля и камеры в момент отрисовки, распределение шагов за кадр, доля игрового времени.
# Отрисовка заменена записью положения (интерполяция A-23 применяется и снимается вокруг неё как обычно).
# python3 stand79.py <out.jsonl> [секунд] [фильтр-вариантов]
import asyncio,json,sys,random,math,os
sys.path.insert(0,'@@KIT@@')
from h import *
D='@@KIT@@/t72/'
VAR={'cur':('g159.html','["A-25"]'),'a25':('g159.html','[]'),'noip':('g159.html','["A-25","A-23"]'),'old':('g159.html','["A-20"]'),'noip25':('g159.html','["A-23"]')}
NOISE={'clean':(0,0,0),'r01':(.1,0,0),'r01j03':(.1,.3,0),'r01j1':(.1,1.0,0),'r1':(1.0,0,0),'r01miss':(.1,0,.01)}
def stamps(hz,q,sig,miss,sec,seed):
    R=random.Random(seed);T=1000/hz;tt=[];ts=[];t0=50000+R.random()*T;k=0
    while True:
        t=t0+k*T;k+=1
        if t-t0>sec*1000:break
        if miss and R.random()<miss:continue
        r=t+(R.gauss(0,sig) if sig else 0)
        if q:r=round(r/q)*q
        tt.append(t);ts.append(r)
    for i in range(1,len(ts)):
        if ts[i]<=ts[i-1]:ts[i]=ts[i-1]+(q or .001)
    return tt,ts
INIT="""(()=>{let a=11;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};window.requestAnimationFrame=()=>0;window.__archOff=%s;})();"""
RUN=r"""(J)=>{audioWake();T.fresh();G.save.tut.off=1;
 let cur=J.ts[0]-1000/J.hz,tru=0;performance.now=()=>cur;last=cur;
 const cap=[];const rec=function(){const p=G.player;if(p&&(G.state==='world'||G.state==='play'))cap.push([tru,+p.x.toFixed(4),+p.y.toFixed(4),+CX.toFixed(4),+CY.toFixed(4),typeof ARCH.n74==='number'&&!(ARCH.off['A-20'])?ARCH.n74:-1,+p.vx.toFixed(3),+p.vy.toFixed(3),typeof IP76!=='undefined'&&IP76.act?1:0]);};
 renderWorld=rec;render=rec;
 // вход в игру как у игрока: несколько кадров не в игре (пауза), затем мир; разгон 1,5 с кадрами 60 Гц без записи
 pause();for(let i=0;i<5;i++){cur+=1000/60;tru=cur;frame(cur);}resume();G.resumeK=0;
 for(let i=0;i<90;i++){cur+=1000/60;tru=cur;const p=G.player;if(p){p.hp=G.st?G.st.maxHp:p.hp;steer2(p.x+2000,p.y);}frame(cur);}
 cap.length=0;const s0=ARCH.steps74||0,c0=ARCH.clk;
 // пауза-вход: каждые J.pz кадров — пауза на J.pl кадров (проверка доли времени при входах)
 let live=0,ent=0;const ts=J.ts,tt=J.tt,base=cur-ts[0]+1000/J.hz;
 for(let i=0;i<ts.length;i++){const p=G.player;if(p){p.hp=G.st?G.st.maxHp:p.hp;steer2(p.x+2000,p.y);}
   if(J.pz&&i%J.pz===J.pz-J.pl&&G.state==='world'){pause();}
   if(J.pz&&i%J.pz===0&&i&&G.state==='pause'){resume();ent++;}
   const pre=cur;cur=ts[i]+base;tru=tt[i]+base;const wl=G.state==='world';frame(cur);if(wl)live+=Math.min(.05,(cur-pre)/1000);}
 return {cap,steps:(ARCH.steps74||0)-s0,clk:ARCH.clk-c0,live,ent,st:G.state,n:ts.length};}"""
def metr(cap,hz):
    out={}
    if len(cap)<50:return {'err':'мало кадров'}
    ns=[c[5] for c in cap]
    if ns[0]>=0:
        dist={k:ns.count(k) for k in (0,1,2,3)};mins=(cap[-1][0]-cap[0][0])/60000
        out['steps']=dist;out['z_min']=round(dist[0]/mins,1);out['two_min']=round(dist[2]/mins,1)
    for key,ix in (('ship',1),('cam',3)):
        es=[];stall=jump=0;m=0
        for i in range(1,len(cap)):
            a,b=cap[i-1],cap[i];v=b[6]
            if abs(b[6]-a[6])>abs(v)*.002 or abs(v)<50 or abs(b[7])>abs(v)*.02 or b[8]!=a[8]:continue
            dT=(b[0]-a[0])/1000;ideal=v*dT;d=b[ix]-a[ix]
            if key=='cam' and abs(d)<1e-9 and abs(ideal)>1:pass
            e=d/ideal-1;es.append(e);m+=1
            if d<.05*ideal:stall+=1
            if d>1.5*ideal:jump+=1
        if m<30:out[key]={'n':m};continue
        es.sort();mins=(cap[-1][0]-cap[0][0])/60000
        out[key]={'n':m,'J':round(sum(abs(x) for x in es)/m*100,2),'p95':round(sorted(abs(x) for x in es)[int(.95*m)]*100,1),'stall_min':round(stall/mins,1),'jump_min':round(jump/mins,1)}
    return out
async def main():
    outp=sys.argv[1];sec=float(sys.argv[2]) if len(sys.argv)>2 else 15;flt=sys.argv[3].split(',') if len(sys.argv)>3 else list(VAR)
    done=set()
    try:
        for l in open(outp):done.add(json.loads(l)['id'])
    except FileNotFoundError:pass
    jobs=[]
    if os.environ.get('TSFILE'):
        rows=json.load(open(os.environ['TSFILE']))['rows'];d=sorted(rows[i][0]-rows[i-1][0] for i in range(1,len(rows)));hz=round(1000/d[len(d)//2],2)
        jobs=[(hz,'file',v,0,0) for v in flt]
    else:
        HZ=[float(x) for x in os.environ.get('HZ','59.94,60,60.05,90,120,144').split(',')]
        NZ=os.environ.get('NZ',','.join(NOISE)).split(',')
        for hz in HZ:
            for nz in NZ:
                for v in flt:jobs.append((hz,nz,v,0,0))
        if not os.environ.get('NOPZ'):
            for v in flt:jobs.append((60,'r01',v,90,12));jobs.append((144,'r01',v,216,29))
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for hz,nz,v,pz,pl in jobs:
            jid=f'{hz}/{nz}/{v}/{pz}'
            if jid in done:continue
            if nz=='file':
                rows=json.load(open(os.environ['TSFILE']))['rows'];ts=[r[0] for r in rows];tt=list(ts)
            else:
                q,sig,miss=NOISE[nz];tt,ts=stamps(hz,q,sig,miss,sec,int(hz*100)*31+sum(map(ord,nz)))
            f,off=VAR[v]
            for att in range(3):
                try:
                    P=await newpage(b,1280,760,url='file://'+D+f,init=INIT%off,clear=False)
                    r=await P.js(RUN,dict(ts=ts,tt=tt,hz=hz,pz=pz,pl=pl));await P.pg.context.close();break
                except Exception as e:
                    r={'err':str(e)[:200]}
                    try:await P.pg.context.close()
                    except Exception:pass
            res={'id':jid,'hz':hz,'noise':nz,'var':v,'pz':pz}
            if 'cap' in r:
                res.update(metr(r['cap'],hz));res['steps_total']=r['steps'];res['live_s']=round(r['live'],4);res['ent']=r['ent']
                res['ratio']=round(r['steps']/60/r['live'],6) if r['live'] else None
                res['clk_ratio']=round(r['clk']/r['live'],6) if r['live'] else None
            else:res.update(r)
            open(outp,'a').write(json.dumps(res,ensure_ascii=False)+'\n');print(json.dumps(res,ensure_ascii=False)[:400],flush=True)
        await b.close()
asyncio.run(main())
