# Этап 4 · микротесты механик при разной частоте кадров (настоящий frame(now), синтетическое время; сборка не меняется)
import asyncio,json,sys,time
sys.path.insert(0,'@@KIT@@')
from h import *
import os
U=os.environ.get('MICRO_URL','file://@@KIT@@/t72/game.html')
INIT="""(()=>{let a=7;const R=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
Math.random=R;window.requestAnimationFrame=()=>0;})();"""
RUN=r"""(o)=>{const prof=o.prof;let jit=99;const jr=()=>{jit=(jit*1103515245+12345)%2147483648;return jit/2147483648;};
 const base=o.mob?1000/60:{p30:1000/30,p60:1000/60,p120:1000/120,p144:1000/144,p50:20,p15:1000/15}[prof]||1000/60;
 const nd=()=>prof==='jit'?1000/60*(.55+.9*jr()):base;
 render=function(){};renderWorld=function(){};
 let shots=0;{const f=fire;fire=function(){shots++;return f.apply(this,arguments);};}
 SET.fps=o.mob&&o.fps30?30:60;
 const setup=()=>{audioWake();T.fresh();G.save.tut.off=1;G.save.cleared=1;G.save.medals[1]={clear:1};enterNode(2);if(G.state==='intro')startMission();
   updateWaves=function(){};G.enemies=[];G.warns=[];G.eb=[];const p=G.player;p.x=W/2-300;p.y=H/2;p.vx=p.vy=0;p.hp=G.st.maxHp;p.dashCd=0;};
 let now=(o.t0||90000);const run=(ms,f)=>{let R=0;while(R<ms-1e-6){const d=nd();R+=d;now+=d;if(f)f(R);frame(now);if(G.state==='levelup'){while(G.state==='levelup')choose(0);}}return R;};
 const out={};const kd=()=>{for(const k of KK)KEYS[k]=false;};
 setup();last=now;frame(now);
 // 1. разгон 1 с вправо и выбег 0,5 с
 {const p=G.player;p.x=200;p.y=H/2;p.vx=p.vy=0;kd();KEYS.KeyD=true;const t0=G.t;run(100);const v1=p.vx;run(100);out.accel={v100:+v1.toFixed(2),v200:+p.vx.toFixed(2),dx200:+(p.x-200).toFixed(2)};run(800);kd();const x1=p.x;run(500);out.coast={dx:+(p.x-x1).toFixed(2),v:+p.vx.toFixed(2)};}
 // 2. рывок из покоя
 {const p=G.player;p.x=200;p.y=H/2;p.vx=p.vy=0;kd();run(300);p.x=200;p.vx=p.vy=0;p.dashCd=0;tryDash([1,0]);run(500);out.dash={dx:+(p.x-200).toFixed(2)};}
 // 3. темп огня по неподвижной мишени: три уровня темпа
 {const p=G.player;const rs=[.27,.2106,.1674],res=[];for(const r of rs){G.enemies=[];p.x=W/2-150;p.y=H/2;p.vx=p.vy=0;kd();const e=spawnEnemy('guard',W/2+60,H/2);e.hp=e.max=1e9;e.spawnT=0;
   run(500,()=>{G.st.rate=r;e.stun=1;});shots=0;const t0=G.t;run(10000,()=>{G.st.rate=r;p.vx=p.vy=0;p.x=W/2-150;p.y=H/2;e.hp=1e9;e.x=W/2+60;e.y=H/2;e.vx=e.vy=0;e.stun=1;p.hp=G.st.maxHp;});res.push({rate:r,shots,sim:+(G.t-t0).toFixed(3),period:+((G.t-t0)/Math.max(1,shots)).toFixed(4)});}
  out.fire=res;G.enemies=[];}
 // 4. скольжение оглушённого врага: e.stun → vx*=.9 за шаг
 {G.enemies=[];const p=G.player;p.x=100;p.y=100;const e=spawnEnemy('scout',W/2,H/2);e.spawnT=0;e.hp=e.max=1e9;e.stun=.6;e.vx=400;e.vy=0;const x0=e.x;run(500,()=>{p.fireT=99;});out.stunSlide={dx:+(e.x-x0).toFixed(2),vx:+e.vx.toFixed(3)};G.enemies=[];}
 // 5. стоп-кадр hs90(.25,2) и замедление slow95(1,.35): игровое время за 1 с реального
 {kd();const t0=G.t;hs90(.25,2);run(1000);out.hitstop={sim:+(G.t-t0).toFixed(4)};}
 {kd();const t0=G.t;slow95(1,.35);run(1000);out.slow={sim:+(G.t-t0).toFixed(4)};}
 // 6. игровое время за 2 с реального (обрезка dt)
 {kd();const t0=G.t;run(2000);out.simPerReal={sim:+((G.t-t0)/2).toFixed(4)};}
 // 7. после паузы на телефоне: resumeK
 {pause();run(200);resume();const t0=G.t;run(1500);out.resume={sim:+(G.t-t0).toFixed(4),resumeK:G.resumeK};}
 return out;}"""
PROFS=[('p60',0,0)]
async def main():
    res={}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for pr,mob,f30,t0,u in [('p60',0,0,t0,u) for t0 in (50000,90000,123456.789,1e6) for u in ('game.html','g153.html')]:
            P=await newpage(b,1280,760,url=U.rsplit('/',1)[0]+'/'+u,init=INIT,touch=False)
            try:r=await P.js(RUN,dict(prof=pr,mob=mob,fps30=f30,t0=t0))
            except Exception as e:r={'err':str(e)[:300]}
            r['errs']=P.errs[:3];res[f'{u}@{t0}']=r;print(u,t0,json.dumps(r,ensure_ascii=False),flush=True)
            await P.pg.context.close()
        await b.close()
    json.dump(res,open(sys.argv[1],'w'),ensure_ascii=False,indent=1)
asyncio.run(main())
