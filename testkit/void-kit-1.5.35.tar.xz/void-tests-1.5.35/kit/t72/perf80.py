# ARCH·77–80: ABAB 1.5.16 (A) против 1.5.20 (B, A-24 выкл.) · K10 · ABAB-замер стоимости кадра frame() с отрисовкой (виртуальное время игры, реальное время ЦП).
# python3 perf74.py <out.json> [reps]   варианты: A = 1.5.13 (A-20 вкл.), B = 1.5.13 с __archOff=['A-20'] (старый frame)
import asyncio,json,sys
sys.path.insert(0,'@@KIT@@')
from h import *
U='file://@@KIT@@/t72/g156.html'
INIT="""(()=>{let a=5;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
window.requestAnimationFrame=()=>0;window.__RN=performance.now.bind(performance);window.__archOff=%s;})();"""
RUN=r"""(J)=>{T.fresh();G.save.tut.off=1;const G0=G.save;G0.cleared=Math.max(G0.cleared,J.m-1);for(let k=1;k<J.m;k++)G0.medals[k]={clear:1};
 enterNode(J.m);if(G.state==='intro')startMission();
 let now=50000;performance.now=()=>now;last=now;const dt=1000/J.hz,N=Math.round(J.sec*J.hz);let cpu=0,steps=0;const fr=[];
 for(let i=0;i<N;i++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);const p=G.player;if(p&&p.hp<G.st.maxHp*.4)p.hp=G.st.maxHp*.4;
   if(p)steer2(W/2+Math.cos(i*dt/1500)*Math.min(W,H)*.3,H/2+Math.sin(i*dt/1500)*Math.min(W,H)*.3);
   now+=dt;const t0=window.__RN();frame(now);const c=window.__RN()-t0;cpu+=c;fr.push(c);}
 fr.sort((x,y)=>x-y);return {msFrame:+(cpu/N).toFixed(3),p95:+fr[Math.floor(N*.95)].toFixed(3),msPerGameSec:+(cpu/J.sec).toFixed(1),simT:+G.t.toFixed(2),st:G.state,ver:VER_TAG};}"""
async def one(b,flags,hz,m,sec,u=U):
    P=await newpage(b,1280,760,url=u,init=INIT%json.dumps(flags),clear=False)
    try:r=await P.js(RUN,dict(hz=hz,m=m,sec=sec))
    except Exception as e:r={'err':str(e)[:300]}
    r['nerr']=len(P.errs);await P.pg.context.close();return r
async def main():
    out=sys.argv[1];reps=int(sys.argv[2]) if len(sys.argv)>2 else 3;res=[]
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for hz in (60,120,144):
            for m in (10,46):
                for r in range(reps):
                    for tag,fl,u in (('A',[],U),('B',[],U.replace('g156','g160'))):
                        x=await one(b,fl,hz,m,8,u);x.update(tag=tag,hz=hz,m=m,rep=r);res.append(x);print(x,flush=True)
        await b.close()
    json.dump(res,open(out,'w'),ensure_ascii=False)
asyncio.run(main())
