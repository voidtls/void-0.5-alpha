import re,sys
L=open('g151c.js').read().split('\n')
pat=re.compile(sys.argv[1]);W=int(sys.argv[2]) if len(sys.argv)>2 else 70
fn_re=re.compile(r'^\s*(?:async\s+)?function\s+([\w$]+)|^\s*\{const (_\w+)=([\w$.]+);|^\s*(?:const|let|var)\s+([\w$]+)\s*=\s*(?:function|\()')
cur='?'
for i,l in enumerate(L,1):
    m=fn_re.match(l)
    if m:cur=m.group(1) or ('wrap:'+m.group(3) if m.group(3) else None) or m.group(4) or cur
    for mm in pat.finditer(l):
        s=max(0,mm.start()-W);print(f"{i}\t{cur}\t{l[s:mm.end()+W]}")
