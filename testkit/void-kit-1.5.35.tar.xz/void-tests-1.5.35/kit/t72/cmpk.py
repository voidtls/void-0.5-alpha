import json,sys,collections
R={};[R.__setitem__(r['id'],r) for r in map(json.loads,open(sys.argv[1]))]
G=collections.defaultdict(dict)
for i,r in R.items():
    g,_,v=i.rpartition('/');G[g][v]=r
bad=0;tot=0
for g in sorted(G):
    d=G[g];ref=d.get('ref')
    if not ref:print(g,'NO REF',list(d));continue
    out=[]
    for v,r in sorted(d.items()):
        if v=='ref':continue
        tot+=1
        if r.get('err') or r.get('nerr'):out.append(f"{v}:ERR {r.get('err','')[:80]} {r.get('errs')}");bad+=1;continue
        a,b=ref['fp'],r['fp'];k=next((i for i,(x,y) in enumerate(zip(a,b)) if x!=y),None)
        same=k is None and len(a)==len(b) and r['steps']==ref['steps'] and r['rng']==ref['rng'] and r['kills']==ref['kills'] and (r.get('deep') is None or ref.get('deep') is None or r['deep']==ref['deep'])
        over=(k is None and len(a)==len(b) and 0<r['steps']-ref['steps']<=2 and r['steps']>=1800)
        if same:out.append(f"{v}:=")
        elif over:out.append(f"{v}:=+{r['steps']-ref['steps']}")
        else:bad+=1;out.append(f"{v}:DIFF@{(k+1)*60 if k is not None else 'len'} st{r['steps']}/{ref['steps']} rng{r['rng']}/{ref['rng']} k{r['kills']}/{ref['kills']}")
        if v not in('gdirect',) and r.get('frames'):out[-1]+=f"[f{r['frames']} 0:{r['zero']} 2:{r['two']} 3:{r['three']}]"
    print(g,f"(steps {ref['steps']} k{ref['kills']} rng{ref['rng']} st {ref['st']})",' '.join(out))
print('TOTAL',tot,'BAD',bad)
