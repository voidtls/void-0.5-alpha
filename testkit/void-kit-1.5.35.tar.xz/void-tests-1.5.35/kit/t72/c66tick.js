function c66Tick(dt){
  if(C66.world){C66.world.t+=dt;if(C66.world.t>1.6)C66.world=null;}
  c66BriefTick(dt);c66DoneTick(dt);
  if(!c66Live()){if(C66.M)c66End();else c66Vis(false);return;}
  const st=G.state;if(st==='play'&&!C66.M)c66Begin();const M=C66.M;if(!M){c66Vis(false);return;}if(M.m!==G.m){c66End();return;}
  c66Vis(st==='play');if(st!=='play'){if(st==='done'||st==='over'){C66.bar=0;C66.barT=0;C66.duckQ=1;c66BootEnd(true);c66CamReset();}return;}
  M.t+=dt;const p=G.player,m=M.m,full=M.full,mode=M.mode;
  /* полосы */
  if(M.barOff&&M.t>M.barOff){M.barOff=0;c66Bars(0);}
  if(M.lids){/* веки: закрыты → приоткрылись → моргнули → открылись (как в прологе) */const t=M.t,mx=c66BarMax(),o=t<.55?0:t<.8?.35*ease3((t-.55)/.25):t<.95?.35-.2*((t-.8)/.15):t<1.8?.15+.85*easeIO((t-.95)/.85):1;C66.bar=.5-(.5-mx)*o;if(t>=1.8){M.lids=0;C66.bar=mx;c66Bars(mx);}}
  else{const bt=C66.barT,bk=C66.bar>bt?2.2:1.6;C66.bar+=clamp(bt-C66.bar,-bk*dt,bk*dt);if(C66.bar<.0005)C66.bar=0;}
  {const D=c66Dom(),h=(C66.bar*100).toFixed(2)+'vh';if(D.bt.style.height!==h){D.bt.style.height=h;D.bb.style.height=h;}}
  /* музыка */
  let dq=1;if(M.dk){if(M.t<M.dk.until)dq=M.dk.v;else M.dk=null;}dq=Math.round(dq*20)/20;C66.duckQ=dq;
  c66BootTick(M);c66TitleTick(M,dt);c66CardTick(M,dt);c66CapTick(M,dt);c66BortTick(M,dt);c66KillCamTick(M,dt);c66TracerTick(M,dt);
  for(const r of M.rings)r.t+=dt;M.rings=M.rings.filter(r=>r.t<r.T);for(const f of M.fl)f.t+=dt;M.fl=M.fl.filter(f=>f.t<f.T);for(const q of M.puffs)q.t+=dt;M.puffs=M.puffs.filter(q=>q.t<q.T);
  if(M.flash>0)M.flash=Math.max(0,M.flash-dt*3);
  /* общий план 04: холст в рамке → наезд */
  c66Cam(M,dt);if(M.riserAt&&M.t>=M.riserAt){M.riserAt=0;c66Sting('riser',1.05);}
  /* финальный удар */
  if(C66.clearAt&&performance.now()-C66.clearAt<800&&!M.kc&&m<=4){C66.clearAt=0;c66KillCam(M);}
  /* по миссиям */
  const wv=G.waveIdx||0,wvUp=wv!==M.w;M.wPrev=M.w;M.w=wv;
  if(m===1){const S1=G.s1;if(S1&&S1.buoys)for(const b of S1.buoys){const on=b.lit>0;if(on&&!M.bl[b.i]){c66Flare(b.x,b.y,'#8fe9ff',300,.8);M.bc=M.bc||{};if(!M.bc[b.i]){M.bc[b.i]=1;M.nb=(M.nb||0)+1;c66Sting('chime',M.nb-1,b.x);c66Ring(b.x,b.y,190,'#8fe9ff',1.1,2);}}M.bl[b.i]=on;}
    if(!M.did.light&&G.radio&&G.radio.cur&&/^Объект в секторе/.test(G.radio.cur.txt||'')){M.did.light=1;M.stra={x:W*.79,y:H*.08,on:1,a:0,radio:1};c66Note('light','огонёк Стража');}}
  if(m===2){if(full&&!M.did.echo&&M.t>.35){M.did.echo=1;c66EchoStart(M);}
    if(full&&wvUp&&wv===5&&!M.did.ghost&&c66Loud()){M.did.ghost=1;M.ghostAt=M.t+.9;}
    if(M.ghostAt&&M.t>=M.ghostAt){M.ghostAt=0;const S=G.s1;let best=null,bd=-1;for(const pl of (S&&S.plates)||[]){const d=Math.hypot(pl.x-p.x,pl.y-p.y);if(d>bd){bd=d;best=pl;}}
      if(best&&!c66Danger()){M.ghost={x:best.x+Math.cos(best.a+1.57)*36,y:best.y+Math.sin(best.a+1.57)*36,a:Math.atan2(p.y-best.y,p.x-best.x),t:0};c66Sting('ghost');c66Note('ghost','силуэт у дальней плиты');}}
    if(M.ghost){M.ghost.t+=dt;if(M.ghost.t>.5)M.ghost=null;}
    if(!M.did.thread&&p.dashT>0){for(const b of G.eb||[]){if(b.life>0&&Math.hypot(b.x-p.x,b.y-p.y)<64){M.did.thread=1;if(c66Slow(.5,.35)||mode!=='full'){if(mode==='full')M.lpUntil=M.t+.6;c66Cap('СКВОЗЬ ОГОНЬ',p.x,p.y,'#8fe9ff',1.4);c66Note('slow','рывок сквозь огонь');}break;}}}
    const rf=(G.mc&&G.mc.s1refl)||0;if(rf>M.refl){M.refl=rf;if(!M.did.refl){M.did.refl=1;const lk=C66.lk||p;if(c66Slow(.5,.35)||mode!=='full'){if(mode==='full')M.lpUntil=M.t+.6;c66Cap('ИХ ЖЕ ОГНЁМ',lk.x,lk.y,'#ffb84d',1.5);c66Ring(lk.x,lk.y,120,'#ffb84d',.7);c66Note('slow','рикошет во врага');}}}}
  if(m===3){for(const w of G.warns||[]){if(w.type==='rammer'&&!M.did.silence){M.did.silence=1;c66Duck(.04,1.8);const x=w.mx!==undefined?w.mx:w.x,y=w.my!==undefined?w.my:w.y;c66Sting('rumble',0,x);
        for(let i=0;i<14;i++){const a=r66()*TAU,v=20+r66()*50;M.puffs.push({x:clamp(x,8,W-8)+Math.cos(a)*14,y:clamp(y,8,H-8)+Math.sin(a)*14,vx:Math.cos(a)*v+(W/2-x)*.12,vy:Math.sin(a)*v+(H/2-y)*.12,t:-r66()*.5,T:1.5+r66()*.6,s:2+r66()*3});}
        c66Note('silence','тишина перед тараном');break;}}
    const sn=(G.mc&&G.mc.s1stun)||0;if(sn>M.stun){M.stun=sn;if(!M.did.stun){M.did.stun=1;let e=null;for(const o of G.enemies)if(o.alive&&o.type==='rammer'&&o.s1dz>G.t){e=o;break;}const x=e?e.x:p.x,y=e?e.y:p.y;
        if(mode==='full'&&full&&!c66Danger()){hs90(.12,2);M.ni+=.12;}if(mode==='full'){trauma90(.45);setTimeout(()=>{if(C66.M===M)c66Slow(.6,.35);},140);}
        c66Ring(x,y,220,'#ffd24d',.8,3);c66Ring(x,y,120,'#ffffff',.5,1.5);c66Flare(x,y,'#ffd24d',320,.8);if(mode==='full')M.lpUntil=M.t+.9;if(c66Loud()&&full)M.flash=.5;c66Sting('impact',0,x);if(mode==='full'&&SET.fx&&!c66Danger())M.punch={t:0,T:.6,s:1.07,x,y};c66Cap('ОГЛУШЁН · УРОН ×2',x,y,'#ffd24d',1.8,1);c66Note('stun','первый таран о глыбу');}}
    const pu=(G.mc&&G.mc.pulses)||0;if(pu>M.pulses){M.pulses=pu;if(!M.did.pulse){M.did.pulse=1;c66Duck(.25,.9);c66Ring(p.x,p.y,Math.max(W,H)*.75,'#ffb84d',1.1,2);c66Sting('whoomp');c66Note('pulse','первый импульс — вдох');}}}
  if(m===4){/* тень — в паузе после волны 4 (тогда же радио Стража) */
    if(wvUp&&wv===5&&!M.did.shadow&&(full||M.cyc>1)){M.did.shadow=1;M.shadowAt=M.t+.35;}
    if(M.shadowAt&&M.t>=M.shadowAt){M.shadowAt=0;c66ShadowStart(M);}
    if(M.shadow){M.shadow.t+=dt;if(M.shadow.t>=M.shadow.T)M.shadow=null;}
    /* цепь мин: ноты пентатоники по восходящей, первая длинная — замедление на всю цепь */
    const S=G.s1;if(S&&S.chains){for(const id in S.chains){const C=S.chains[id],was=M.chains[id]||0;if(C.n>was){M.chains[id]=C.n;for(let k=was;k<C.n&&k<9;k++){const i=k;setTimeout(()=>c66Sting('note',i),(k-was)*45);}
          if(C.n>=3&&!M.chainCine){M.chainCine=+id;if(c66Slow(.6,.3)){M.lpUntil=M.t+1;c66Note('chain','замедление на цепь');}}
          else if(+id===M.chainCine&&C.n>3&&mode==='full'&&M.slow<1.2){const add=Math.min(.14,1.2-M.slow);M.slow+=add;slow95(Math.max(.15,(G.slow95&&G.slow95.t)||0)+add,.3);}
          const at=C66.mb&&performance.now()-C66.mb.at<400?C66.mb:null;if(at)c66Ring(at.x,at.y,70+C.n*14,'#ff4f6e',.6,1.5);
          if(C.n>=5&&C.hit&&!M.did.chain5){M.did.chain5=1;const q=at||p;c66Flare(q.x,q.y,'#ffd24d',360,1);c66Cap('ЦЕПЬ ×'+C.n+' · МАСТЕРСТВО',q.x,q.y,'#ffd24d',1.9);}}}}
    if(M.search){M.search.t+=dt;if(M.search.t>0&&!M.search.snd){M.search.snd=1;c66Sting('search');c66Note('search','прожектор нашёл корабль');}if(M.search.t>M.search.T)M.search=null;}}
  if(M.stra){const L=M.stra;L.a=Math.min(1,L.a+dt*1.5);if(L.radio&&!(G.radio&&G.radio.cur)){L.radio=0;L.fade=1;}if(L.fade){L.on-=dt*.4;if(L.on<=0)M.stra=null;}}
  if(M.far5){M.far5.t+=dt;if(M.far5.t>3.2)M.far5=null;}
  for(const d of M.dust){const F=c66Drift();d.x+=(F[0]*d.k+6)*dt;d.y+=F[1]*d.k*dt;if(d.x<-10)d.x+=W+20;if(d.x>W+10)d.x-=W+20;if(d.y<-10)d.y+=H+20;if(d.y>H+10)d.y-=H+20;}
}
function c66Drift(){let vx=0,vy=0,n=0;for(const r of G.rocks||[]){if(!r.alive||!r.s1big)continue;vx+=r.vx;vy+=r.vy;n++;}return n?[vx/n*1.6,vy/n*1.6]:[10,0];}

/* ---------- СЛОИ ОТРИСОВКИ ---------- */
/* под врагами: свет и цвет фона, дальний план (огонёк Стража, мины-звёзды, пыль), тень по фону */
function c66Under(t){const M=C66.M;if(!M||G.state==='menu')return;const p=G.player;if(!p)return;const fx=c66Fx();
  if(M.m===1&&fx){const S=G.s1,ever=S?S.buoys.filter(b=>b.ever).length:0,lit=M.lit=(M.lit===undefined?0:M.lit)+((ever/3)-(M.lit||0))*.04;const a=.52*(1-lit);
    if(a>.01){const R=Math.max(W,H)*.8,g=ctx.createRadialGradient(p.x,p.y,140,p.x,p.y,R);g.addColorStop(0,'rgba(2,5,12,0)');g.addColorStop(.35,`rgba(2,5,12,${(a*.55).toFixed(3)})`);g.addColorStop(1,`rgba(2,5,12,${a.toFixed(3)})`);ctx.fillStyle=g;ctx.fillRect(-60,-60,W+120,H+120);}
    if(S){ctx.globalCompositeOperation='lighter';for(const b of S.buoys){if(b.lit<=0)continue;const k=Math.min(1,b.lit/2)*(.85+.15*Math.sin(t*2+b.i));const g=ctx.createRadialGradient(b.x,b.y,10,b.x,b.y,300);g.addColorStop(0,`rgba(143,233,255,${(.13*k).toFixed(3)})`);g.addColorStop(1,'rgba(143,233,255,0)');ctx.fillStyle=g;ctx.fillRect(b.x-300,b.y-300,600,600);}ctx.globalCompositeOperation='source-over';}}
  if(M.m===3&&fx){ctx.fillStyle='#e8c69a';for(const d of M.dust){ctx.globalAlpha=d.a;ctx.fillRect(d.x,d.y,d.s,d.s);}ctx.globalAlpha=1;}
  if(M.m===4&&fx){ctx.fillStyle='rgba(6,14,52,.22)';ctx.fillRect(-60,-60,W+120,H+120);
    if(M.lights){const ox=(p.x-W/2)*.12,oy=(p.y-H/2)*.12;for(const L of M.lights){const x=L.x*W-ox,y=L.y*H-oy,ph=((t+L.ph)%L.T)/L.T,on=ph<.14?1-ph/.14:0;let a=.26+.7*on;
        const sh=c66InShadow(x,y);if(sh>0)a*=1-sh;if(M.est)a=Math.min(1,a*1.6+.15);if(a<.03)continue;ctx.globalAlpha=a;ctx.fillStyle='#ff4f6e';ctx.fillRect(x-L.s/2,y-L.s/2,L.s,L.s);if(on>.3)glow(x,y,7+L.s*2,'#ff4f6e',on*.5*(1-sh));}ctx.globalAlpha=1;}}
  if(M.stra&&fx){const L=M.stra;let a=L.a*Math.max(0,L.on);const sh=c66InShadow(L.x,L.y);a*=1-sh;if(L.radio){const c=G.radio&&G.radio.cur;a*=c&&c.shown<c.len?.55+.45*Math.abs(Math.sin(t*9)):.75;}else a*=.55+.2*Math.sin(t*1.7);
    if(a>.02){glow(L.x,L.y,38,'#ff6b8a',a*.75);glow(L.x,L.y,12,'#ffffff',a*.5);ctx.strokeStyle='#ffd0da';ctx.globalAlpha=a*.7;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(L.x-18,L.y);ctx.lineTo(L.x+18,L.y);ctx.moveTo(L.x,L.y-8);ctx.lineTo(L.x,L.y+8);ctx.stroke();
