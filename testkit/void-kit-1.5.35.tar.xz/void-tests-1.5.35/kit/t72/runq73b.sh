cd @@KIT@@/t72
while ! grep -q K5END q73.txt 2>/dev/null; do sleep 20; done
python3 st74.py jobs_k3t.json k3t.jsonl 2 > k3t.log 2>&1; echo K3TEND >> q73.txt
MICRO_URL=file://@@KIT@@/t72/g153.html python3 micro72.py micro153.json > micro153.log 2>&1; echo MICROEND >> q73.txt
cd .. && K9NEW=void_c153.html python3 q73save.py > t72/k9_153.log 2>&1; cd t72; echo K9END >> q73.txt
python3 perf74.py perf153.json 3 > perf153.log 2>&1; echo PERFEND >> q73.txt
python3 st74.py jobs_k21.json k21.jsonl 2 > k21.log 2>&1; echo K21END >> q73.txt
python3 st74.py jobs_k2223.json k2223.jsonl 2 > k2223.log 2>&1; echo K2223END >> q73.txt
