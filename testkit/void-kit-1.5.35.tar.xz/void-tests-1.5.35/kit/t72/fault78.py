# ARCH·78 · внедрение сбоев в A-23: исключение при переписи после шага / перед отрисовкой / после отрисовки.
# Ожидание: цикл не останавливается, A-23 выключается, ни один объект не остаётся в промежуточном положении,
# игровое состояние совпадает побитно с прогоном без A-23 (с тем же «зондом» в G).
# python3 fault78.py <url> <out.json>
import asyncio,json,sys
sys.path.insert(0,'@@KIT@@')
from h import *
INIT="""(()=>{let a=7;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};window.__raf=0;window.requestAnimationFrame=()=>{window.__raf++;return 0;};window.__archOff=%s;})();"""
RUN=r"""(J)=>{audioWake();T.fresh();G.save.tut.off=1;SET.fx=true;const S=G.save;S.cleared=Math.max(S.cleared,9);for(let k=1;k<10;k++)S.medals[k]={clear:1};
 enterNode(10);if(G.state==='intro')startMission();
 let now=50000;performance.now=()=>now;last=now;
 // зонд: обычный объект с x/y в G; в нужный момент его чтение/запись бросает исключение
 let mode=J.mode,armed=false,px=0,py=0,thrown=0,sets=0;
 const probe={};Object.defineProperty(probe,'x',{enumerable:true,get(){if(armed&&mode==='post'){thrown++;armed=false;throw new Error('зонд: чтение x');}return px;},set(v){if(armed&&mode==='apply'){thrown++;armed=false;throw new Error('зонд: запись x');}if(armed&&mode==='restore'){sets++;if(sets===2){thrown++;armed=false;throw new Error('зонд: возврат x');}}px=v;}});
 Object.defineProperty(probe,'y',{enumerable:true,get(){return py;},set(v){py=v;}});
 probe.vx=0;G.zz78=probe;
 const H=()=>{const p=G.player,r=[G.t,p.x,p.y,p.ang,p.hp,p.vx,p.vy,CX,CY,G.kills,G.enemies.length,G.pb.length,G.eb.length,ACC74,ARCH.clk];
   for(const e of G.enemies)r.push(e.x,e.y,e.ang||0,e.hp);for(const b of G.pb)r.push(b.x,b.y);for(const b of G.eb)r.push(b.x,b.y);for(const k of G.pick||[])r.push(k.x,k.y);
   let h=2166136261;const s=r.map(v=>typeof v==='number'?v.toPrecision(17):String(v)).join(',');for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16);};
 const F=1000/J.hz,hs=[];let mid=null,raf0=0,errs=0;
 const oe=console.error;console.error=function(){errs++;return oe.apply(this,arguments);};
 for(let i=0;i<J.frames;i++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);const p=G.player;
   if(p){if(p.hp<G.st.maxHp*.4)p.hp=G.st.maxHp*.4;const A=i/120;steer2(p.x+Math.cos(A)*300,p.y+Math.sin(A)*300);}
   if(i===J.at){armed=true;sets=0;}
   // проверка «нет промежуточного состояния»: сразу после кадра сбоя положения всех переписанных объектов равны точным (после шага)
   raf0=window.__raf;now+=F;frame(now);
   if(i===J.at&&typeof IP76!=='undefined'){const C=IP76.B;let bad=0;for(let j=0;j<C.n;j++){const o=C.o[j];if(!o||o===probe)continue;if(o.x!==C.x[j]||o.y!==C.y[j])bad++;}
     mid={bad,n:C.n,rafCalled:window.__raf-raf0,vi:ARCH.vi,d78:typeof ARCH.d78==='object'?Object.assign({},ARCH.d78):null,camOk:CX===C.cx&&CY===C.cy};}
   if(i%60===59)hs.push(H());if(G.state!=='play'&&G.state!=='levelup')break;}
 console.error=oe;
 return {mode,hz:J.hz,thrown,mid,hs,vi:ARCH.vi,act:typeof IP76!=='undefined'?IP76.act:null,ip:typeof IP76!=='undefined'?IP76.st.ip:null,st:G.state,raf:window.__raf,errs,d78:typeof ARCH.d78==='object'?ARCH.d78:null};}"""
async def main():
    url,out=sys.argv[1],sys.argv[2];res={}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for name,off,mode in [('off','["A-23"]','none'),('on','[]','none'),('post','[]','post'),('apply','[]','apply'),('restore','[]','restore')]:
            P=await newpage(b,1280,760,url=url,init=INIT%off,clear=False)
            try:r=await P.js(RUN,dict(mode=mode,hz=144,frames=1440,at=700))
            except Exception as e:r={'err':str(e)[:300]}
            r['perrs']=P.errs[:2];await P.pg.context.close();res[name]=r;print(name,json.dumps(r,ensure_ascii=False)[:900],flush=True)
        await b.close()
    base=res['off'].get('hs')
    for k,r in res.items():print(k,'хэши = без A-23:',r.get('hs')==base)
    json.dump(res,open(out,'w'),ensure_ascii=False)
asyncio.run(main())
