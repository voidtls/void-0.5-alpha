# ARCH·78 · перепись состояний, которые меняет ОТРИСОВКА (при выключенной A-23): x, y, ang всех объектов, достижимых из G
# (полный обход без исключений), плюс CX/CY — до render/renderWorld и после drawDevOverlay того же кадра.
# python3 rcensus78.py <url> <out.json>
import asyncio,json,sys
sys.path.insert(0,'@@KIT@@')
from h import *
INIT="""(()=>{let a=5;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};window.requestAnimationFrame=()=>0;window.__archOff=['A-23'];%s})();"""
RUN=r"""(J)=>{audioWake();T.fresh();G.save.tut.off=1;SET.fx=true;const enc=J.enc;let m=+enc;
 const G0=G.save;if(enc!=='world'&&enc!=='snow'&&enc!=='rain'){G0.cleared=Math.max(G0.cleared,(m||50)-1);for(let k=1;k<(m||50);k++)G0.medals[k]={clear:1};}
 if(enc==='endless'){startEndless();if(G.state==='intro')startMission();}else if(enc==='post'){postEnter();if(G.state==='intro')startMission();}
 else if(enc==='50'){G.zbCool=0;const n=zbNode();const p=G.player;p.x=n.x-200;p.y=n.y;zbStart();}
 else if(enc==='world'||enc==='snow'||enc==='rain'){}
 else{enterNode(m);if(G.state==='intro')startMission();if(J.boss){while(G.state==='levelup')choose(0);G.enemies=[];G.warns=[];G.eb=[];G.waveIdx=G.waves.length;G.gapT=.1;}}
 let now=50000;performance.now=()=>now;last=now;
 const SEEN=new Set(),walk=(o,path,d,out)=>{if(!o||typeof o!=='object'||SEEN.has(o))return;SEEN.add(o);if(ArrayBuffer.isView(o)||o instanceof Node)return;
   if(Array.isArray(o)){if(!o.length||typeof o[0]!=='object')return;for(let i=0;i<o.length&&i<3000;i++)walk(o[i],path+'[]',d+1,out);return;}
   if(typeof o.x==='number'||typeof o.ang==='number')out.push([o,path,o.x,o.y,o.ang]);if(d>=6)return;for(const k in o){const v=o[k];if(v&&typeof v==='object')walk(v,path+'.'+k,d+1,out);}};
 let pre=null,preC=null;const agg={};let frames=0;
 const snap=()=>{SEEN.clear();const out=[];walk(G,'G',0,out);return out;};
 for(const nm of ['render','renderWorld']){const f=window[nm]||eval(nm);const w=function(){pre=snap();preC=[CX,CY];return f.apply(this,arguments);};if(nm==='render')render=w;else renderWorld=w;}
 {const f=drawDevOverlay;drawDevOverlay=function(){const r=f.apply(this,arguments);if(pre){frames++;for(const [o,path,x,y,a] of pre){const dx=o.x!==x&&!(Number.isNaN(o.x)&&Number.isNaN(x)),da=o.ang!==a&&!(Number.isNaN(o.ang)&&Number.isNaN(a));const dy=o.y!==y;
       if(dx||dy||da){const A=agg[path]||(agg[path]={n:0,xy:0,ang:0});A.n++;if(dx||dy)A.xy++;if(da)A.ang++;}}
     if(CX!==preC[0]||CY!==preC[1]){const A=agg.CAM||(agg.CAM={n:0,xy:0,ang:0});A.n++;A.xy++;}pre=null;}return r;};}
 const F=1000/60;
 for(let i=0;i<J.frames;i++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);if(G.zb&&G.zb.k==='choice'){try{zbChoose(0);}catch(e){}}
   const p=G.player;if(p&&p.hp<G.st.maxHp*.4)p.hp=G.st.maxHp*.4;if(p){const A=i/90;steer2(p.x+Math.cos(A)*300,p.y+Math.sin(A)*300);if(i%170===0)tryDash();if(p.en>=100)tryPulse();}
   if(G.w&&(enc==='snow'||enc==='world'))G.w.chill=1;
   if(enc==='rain'&&G.w&&p){try{G.w.storms.__t={x:p.x,y:p.y,k:1,ph:'on',kind:'rain',t:0,T:99};}catch(e){}}
   now+=F;frame(now);if(G.state!=='play'&&G.state!=='world'&&G.state!=='levelup')break;}
 return {enc,frames,st:G.state,agg};}"""
async def main():
    url,out=sys.argv[1],sys.argv[2];res={}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox'])
        for enc,boss,cine in [('snow',0,0),('rain',0,0),('world',0,0),('2',0,1),('3',0,1),('10',0,0),('22',1,0),('46',1,0),('50',0,0),('endless',0,0),('post',0,0),('6',1,0),('38',1,0)]:
            P=await newpage(b,1280,760,url=url,init=INIT%('window.__cine66=1;' if cine else ''),clear=False)
            try:r=await P.js(RUN,dict(enc=enc,boss=boss,frames=600))
            except Exception as e:r={'err':str(e)[:300]}
            r['errs']=P.errs[:2];await P.pg.context.close();res[enc]=r;print(enc,r.get('frames'),r.get('st'),json.dumps(r.get('agg'),ensure_ascii=False)[:600],r.get('err',''),r['errs'],flush=True)
        await b.close()
    json.dump(res,open(out,'w'),ensure_ascii=False)
asyncio.run(main())
