import json,math,random,sys,collections
R=[json.loads(l) for l in open(sys.argv[1] if len(sys.argv)>1 else 'fps.jsonl')]
D=collections.defaultdict(list)
for r in R:
    if 'err' in r or r.get('simT') is None:continue
    sc,p,s=r['id'].split('/')
    if p.startswith('ctl'):continue
    st=max(1e-9,r['simT'])
    ph2=None
    for q in (r.get('ph') or []):
        k=str(q[0])
        if k.startswith('2:') or k=='fight1' or k.startswith('fight1'):ph2=q[1];break
    m=dict(kills=r['kills']/st*60,shots=r['shots']/st*60,dmg=r['dmg']/st*60,taken=r['taken']/st*60,spawn=r['spawn']/st*60,rng=r['rng']/st,dist=r['dist']/st,simT=r['simT'],ph2=ph2,hs=r.get('hsN',0),slow=r.get('slowN',0))
    D[(sc,p)].append(m)
def mean(x):return sum(x)/len(x)
def sd(x):
    m=mean(x);return math.sqrt(sum((v-m)**2 for v in x)/max(1,len(x)-1))
def welch(a,b):
    if len(a)<2 or len(b)<2:return None
    va,vb=sd(a)**2/len(a),sd(b)**2/len(b)
    if va+vb==0:return 0.0 if mean(a)==mean(b) else float('inf')
    t=(mean(a)-mean(b))/math.sqrt(va+vb);df=(va+vb)**2/((va**2/(len(a)-1) if len(a)>1 else 0)+(vb**2/(len(b)-1) if len(b)>1 else 0)+1e-300)
    # p-value via normal approx corrected (student t approx by Hill not needed for small report): use t-dist survival approx
    x=df/(df+t*t)
    # regularized incomplete beta for two-sided p
    def betacf(a,b,x):
        MAXIT=200;EPS=3e-12;qab=a+b;qap=a+1;qam=a-1;c=1;d=1-qab*x/qap
        d=1/d if abs(d)>1e-30 else 1e30;h=d
        for m in range(1,MAXIT):
            m2=2*m;aa=m*(b-m)*x/((qam+m2)*(a+m2));d=1+aa*d;d=1/d if abs(d)>1e-30 else 1e30;c=1+aa/c if abs(c)>1e-30 else 1e30;h*=d*c
            aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2));d=1+aa*d;d=1/d if abs(d)>1e-30 else 1e30;c=1+aa/c if abs(c)>1e-30 else 1e30;de=d*c;h*=de
            if abs(de-1)<EPS:break
        return h
    a_,b_=df/2,.5
    bt=math.exp(math.lgamma(a_+b_)-math.lgamma(a_)-math.lgamma(b_)+a_*math.log(x)+b_*math.log(1-x)) if 0<x<1 else 0
    I=bt*betacf(a_,b_,x)/a_ if x<(a_+1)/(a_+b_+2) else 1-bt*betacf(b_,a_,1-x)/b_
    return I
def boot(a,b,n=2000):
    rnd=random.Random(1);out=[]
    for _ in range(n):
        A=[rnd.choice(a) for _ in a];B=[rnd.choice(b) for _ in b]
        mb=mean(B)
        if mb!=0:out.append(mean(A)/mb-1)
    out.sort();return out[int(.025*len(out))],out[int(.975*len(out))]
KEYS=['kills','shots','dmg','taken','spawn','rng','dist','simT','ph2']
res={}
for (sc,p),L in sorted(D.items()):
    if p=='p60':continue
    base=D.get((sc,'p60'))
    if not base:continue
    if p in('mob30',):base=D.get((sc,'mob60'))
    if not base:continue
    row={'n':len(L),'nb':len(base)}
    for k in KEYS:
        a=[x[k] for x in L if x[k] is not None];b=[x[k] for x in base if x[k] is not None]
        if len(a)<2 or len(b)<2 or mean(b)==0:continue
        r=mean(a)/mean(b)-1;pv=welch(a,b);lo,hi=boot(a,b)
        row[k]=(round(100*r,1),round(pv,4) if pv is not None else None,round(100*lo,1),round(100*hi,1))
    res[f'{sc}/{p}']=row
    print(sc,p,row)
json.dump(res,open('ana72.json','w'),ensure_ascii=False,indent=0)
# pooled A/A noise per metric (CV of per-run values in p60)
print('--- CV p60 per scenario')
for (sc,p),L in sorted(D.items()):
    if p=='p60':print(sc,len(L),{k:round(100*sd([x[k] for x in L if x[k] is not None])/max(1e-9,mean([x[k] for x in L if x[k] is not None])),1) for k in KEYS if len([x[k] for x in L if x[k] is not None])>1})
