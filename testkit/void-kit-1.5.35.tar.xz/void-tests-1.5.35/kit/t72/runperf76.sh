cd @@KIT@@/t72
while ! grep -q PERFQEND q73.txt 2>/dev/null; do sleep 30; done
python3 perf76.py perf156q.json 8 > perf156q.log 2>&1; echo PERF76END >> q73.txt
