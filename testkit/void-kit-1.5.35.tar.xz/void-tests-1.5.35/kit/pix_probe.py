# Поиск детерминированного пиксельного стенда: эталон сам с собой должен совпасть бит в бит
import asyncio,json,sys,hashlib
from h import *
FREEZE=r"""(()=>{{let a=123456789;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}window.__tt=1000;const pn=performance.now.bind(performance);performance.now=()=>window.__tt;Date.now=()=>1.7e12+window.__tt;
 window.requestAnimationFrame=function(){return 0;};window.__idleQ=[];window.requestIdleCallback=function(cb){window.__idleQ.push(cb);return window.__idleQ.length;};window.cancelIdleCallback=function(){};
 window.__flushIdle=function(){let n=0;while(window.__idleQ.length&&n++<500){const q=window.__idleQ.splice(0);for(const cb of q){try{cb({timeRemaining:()=>50,didTimeout:false});}catch(e){}}}return n;};
 window.__stopTimers=function(){let id=setTimeout(()=>{},0);for(let i=0;i<=id;i++){clearTimeout(i);clearInterval(i);}};})();"""
ISO="{if(!window.__iso360){window.__iso360=1;const mi=makeImpulse;makeImpulse=function(){const mr=Math.random;Math.random=mulberry(4096);try{return mi.apply(this,arguments);}finally{Math.random=mr;}};}}"
HASH="const hsh=(cv)=>{const g=cv.getContext('2d'),d=g.getImageData(0,0,cv.width,cv.height).data;let h1=0,h2=0;for(let i=0;i<d.length;i+=4){h1=(h1*31+d[i]+d[i+1]*3+d[i+2]*7)>>>0;h2=(h2+d[i]+d[i+1]+d[i+2])>>>0;}return h1+':'+h2;};"
def scen(kind):
    if kind=='world':
        setup="T.fresh();G.save.tut.off=1;"
        step="const p=G.player;p.vx=Math.cos(s/90)*300;p.vy=Math.sin(s/120)*200;worldUpdate(1/60);"
        draw="__flushIdle();renderWorld(__tt);mobOverlay(__tt);"
    else:
        m=int(kind[1:])
        setup="T.fresh();G.save.tut.off=1;{const S=G.save;S.cleared=Math.max(S.cleared,%d-1);for(let k=1;k<%d;k++)S.medals[k]={clear:1};}enterNode(%d);if(G.state==='intro')startMission();"%(m,m,m)
        step="if(G.state==='levelup'){let k=0;while(G.state==='levelup'&&k++<60)choose(0);}if(G.state!=='play')return null;const p=G.player;p.hp=Math.max(p.hp,G.st.maxHp*.6);steer2(W/2+Math.cos(s/150)*W*.28,H/2+Math.sin(s/150)*H*.28);update(1/60);"
        draw="__flushIdle();render(__tt);secVignette();mobOverlay(__tt);"
    return ("async()=>{"+ISO+HASH+"__stopTimers();Math.random=mulberry(9);G.layoutSeed=3;G.keepLayout=true;"+setup+
            "const hs=[];const st=(s)=>{"+step+"return 1;};for(let s=0;s<360;s++){if(st(s)===null)break;__tt+=1000/60;if(s%60===59){"+draw+"hs.push(hsh($('#cv')));}}const pl=G.player;return [hs.at(-1),{t:+(G.t||0).toFixed(4),cx:+CX.toFixed(3),cy:+CY.toFixed(3),sc:SC,px:+pl.x.toFixed(3),py:+pl.y.toFixed(3),ne:G.enemies.length,np:G.parts.length,vfx:VFXR65(),rnd:Math.random(),w:W,h:H,dpr:DPR,mt:G.mT,bg:typeof BG67!=='undefined'?[BG67.dead,BG67.err,!!BG67.job]:0,decor:(G.decor||[]).length,stars:(typeof stars!=='undefined'&&stars)?stars.length:0}];}")
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='@@CHROME@@',args=['--no-sandbox','--disable-gpu','--font-render-hinting=none'])
        for kind in sys.argv[1:] or ['world','m02','m18']:
            res=[]
            for rep in range(3):
                ctx=await b.new_context(viewport={'width':1280,'height':760})
                await ctx.route(lambda u: u.startswith('http'),lambda r: r.abort())
                await ctx.add_init_script('window.__alpha=true;'+FREEZE)
                pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
                await pg.goto(GAME);await pg.wait_for_timeout(300)
                await pg.evaluate(LIB)
                await pg.evaluate("""()=>{window.T={fresh(){localStorage.removeItem('void_world');startWorld(true);if(G.prologue)prologueEnd();$('#toast').hidden=true;return G.state;}};}""")
                r=await pg.evaluate(scen(kind));res.append(r);await ctx.close()
                print(kind,rep,r,errs[:2],flush=True)
            print(kind,'SAME' if res[0]==res[1]==res[2] else 'DIFF',flush=True)
        await b.close()
if __name__=='__main__':asyncio.run(main())
