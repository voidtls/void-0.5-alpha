# 1.2.3 α · исправление облачного сохранения
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m36 FAIL count',n,'!=',cnt,'for',a[:100]);sys.exit(1)
    s=s.replace(a,b)
R("setTimeout(done,6000);","setTimeout(done,LS.getItem('void_world')?6000:15000);")
R("\ncloudInit();","\nqueueMicrotask(()=>cloudInit());")
R('  return `<div class="reset"><button class="rbtn" id="bReset">','  return cloudBestHTML()+`<div class="reset"><button class="rbtn" id="bReset">')
R('<dl class="kv"><dt>1.2.3 α</dt><dd>«Без позывного».','<dl class="kv"><dt>1.2.3 α</dt><dd>Исправлено сохранение: если облако отвечает медленно, новая пустая игра больше не перезаписывает облачный прогресс — он загружается при выходе в меню; лучшая облачная копия хранится в резерве (Настройки → «Вернуть сохранение»). «Без позывного».')
js=open('@@KIT@@/m36.js',encoding='utf8').read()
i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s);print('m36 ok')
