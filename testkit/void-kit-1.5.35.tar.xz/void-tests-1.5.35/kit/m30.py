# 1.2.0–1.2.1 α · m30: хоррор-миссия «Сторожевик «Изморозь»» поперёк прохода II–III; сектор III открывается после неё
import sys,os
P='@@KIT@@/home/void.html'
D=os.path.dirname(os.path.abspath(__file__))
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m30 FAIL count',n,'!=',cnt,'for',a[:100]);sys.exit(1)
    s=s.replace(a,b)
R("drawRocks(G.rocks);if(G.s1)s1DrawUnder(t);","drawRocks(G.rocks);if(G.s1)s1DrawUnder(t);if(G.post)postDrawUnder(t);")
R("  if(G.s1)s1DrawOver(t);\n","  if(G.s1)s1DrawOver(t);if(G.post)postDrawOver(t);\n")
# мир: пост рисуется рядом с объектами сектора
i=s.index('function renderWorld(now){');j=s.index('  drawRocks(G.rocks);',i)
s=s[:j]+'  drawRocks(G.rocks);try{postWorldDraw(t);}catch(e){}'+s[j+len('  drawRocks(G.rocks);'):]
# меню разработчика: только 50 миссий кампании
R("MISSIONS.map((M,i)=>","MISSIONS.slice(0,NM).map((M,i)=>")
# после миссии 10: сектор III закрыт льдом, курс — на пост
R("    else if(U.from===CORE){banner('АКТ I ЗАВЕРШЁН','ДОСТУПЕН НОВЫЙ ЦИКЛ · МАСТЕРСКАЯ ИЛИ УЗЕЛ 10');}",
  "    else if(U.from===CORE){if(!postGate()){banner('ПРОХОД ПЕРЕКРЫТ','В ЛЁД ВМЁРЗ СТОРОЖЕВИК «ИЗМОРОЗЬ»');const a=WORLD.nodes[CORE-1];G.unlockFx={x0:a.x,y0:a.y,x1:POST_HATCH.x,y1:POST_HATCH.y,t:0};G.course={x:POST_HATCH.x,y:POST_HATCH.y+150,label:'СТОРОЖЕВИК «ИЗМОРОЗЬ»'};setTimeout(()=>{try{radioSay('Х',0);}catch(e){}},2600);}else banner('АКТ I ЗАВЕРШЁН','ДОСТУПЕН НОВЫЙ ЦИКЛ · МАСТЕРСКАЯ ИЛИ УЗЕЛ 10');}")
js=open(os.path.join(D,'m30.js'),encoding='utf8').read()
i=s.rindex('</script>');s=s[:i]+js+'\n'+s[i:]
open(P,'w',encoding='utf8').write(s)
print('m30 ok')
