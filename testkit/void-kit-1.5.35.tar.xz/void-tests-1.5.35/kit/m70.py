# 1.5.10 α «Ровно» — ARCH·70: этап 2 (изоляция случайности и времени). Применяется поверх m69.
import sys,os
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt:print('m70 FAIL',n,a[:90]);sys.exit(1)
    s=s.replace(a,b)
R('<div class="ver" id="verTag">1.5.9 α</div>','<div class="ver" id="verTag">1.5.10 α</div>')
R("const VER_TAG='1.5.9 α';","const VER_TAG='1.5.10 α';")
J=open(D+'m70_journal1510.txt',encoding='utf8').read().strip()
R('<dl class="kv"><dt>1.5.9 α</dt>','<dl class="kv"><dt>1.5.10 α</dt><dd>'+J+'</dd><dt>1.5.9 α</dt>')
# блок ARCH·70 — сразу за блоком ARCH·69 в прелюдии главного скрипта
js=open(D+'m70.js',encoding='utf8').read()
R('/* ▲▲▲ ARCH·69 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */\n','/* ▲▲▲ ARCH·69 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */\n'+js+'\n')
# A-10 · A-12 · A-13 — предохранитель: переход на arch70Fault, сброс ARCH.first при восстановлении
R("function arch69Ok(){ARCH.err=0;}","function arch69Ok(){if(ARCH.err&&!ARCH.off['A-13']){ARCH.first=null;ARCH.last=null;}ARCH.err=0;ARCH.hudErr=null;}/* ARCH·70 A-13 */")
R("function arch69Fault(err){if(ARCH.off['A-4'])return;","function arch69Fault(err){if(!(ARCH.off['A-10']&&ARCH.off['A-12']&&ARCH.off['A-13']))return arch70Fault(err);/* ARCH·70 A-10 A-12 A-13 */if(ARCH.off['A-4'])return;")
# A-11 — резерв нечитаемого сохранения с защитой от перезаписи
R("function arch69Backup(){if(ARCH.off['A-2'])return;","function arch69Backup(){if(ARCH.off['A-2'])return;if(!ARCH.off['A-11'])return arch70Backup();/* ARCH·70 A-11 */")
# A-9 — ржавый контейнер на игровом времени
R("card=w58POI(card);if(card&&card.kind==='node'&&card.n.m===50&&zbOn())card=null;","card=arch70POI(card,dt);/* ARCH·70 A-9 */if(card&&card.kind==='node'&&card.n.m===50&&zbOn())card=null;")
R("if(d<70){f.rep=(f.rep||0)+1/60;G.w.boxing=true;","if(d<70){f.rep=(f.rep||0)+arch70Dt();/* ARCH·70 A-9 */G.w.boxing=true;")
R("else{f.rep=Math.max(0,(f.rep||0)-1/60);}","else{f.rep=Math.max(0,(f.rep||0)-arch70Dt());/* ARCH·70 A-9 */}")
# A-7 — отложенное эхо рывка после финала идёт через iso63, а не в обход
R("setTimeout(()=>{try{if(G.post)_sx30('dash');}catch(e){}}","setTimeout(()=>{try{if(G.post)(ARCH.off['A-7']||typeof iso63!=='function'?_sx30:iso63(_sx30))('dash');/* ARCH·70 A-7 */}catch(e){}}")
# A-5 · A-6 · A-8 · A-12 — установка обёрток после arch69Boot()
R("/* ARCH·69 A-2 · A-3 */arch69Boot();\n","/* ARCH·69 A-2 · A-3 */arch69Boot();\n/* ARCH·70 A-5 A-6 A-8 A-12 */arch70Boot();\n")
open(P,'w',encoding='utf8').write(s);print('m70 ok')
