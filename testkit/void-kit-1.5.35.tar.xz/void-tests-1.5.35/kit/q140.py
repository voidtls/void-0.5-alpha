# 1.1.0 α «Чистый интерфейс»: тексты без технического шума (m24). Исключения по замыслу: лор (записки, .lore, примечания бортовой системы),
# условия мастерства (это цель), счётчик груза «ГРУЗ 0/1» (решение «везти/собирать»). Каждый тест падает на сборке 1.0.0 (версия 17).
import asyncio,json,sys,os,re
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
NOISE=r"×\s?\d|\d+\s?%|\d+[,.]\d+\s?[сС](?![А-Яа-яЁё])|\{SPD\}|\{ATK\}|\{DMG\}"

@test('T01')
async def t01(b):
    # меню: правда о мире, без жанра и «пакета», версия в углу; меню разработчика скрыто и открывается пятью нажатиями по логотипу
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{const m=document.querySelector('#sMenu').innerText;const hid=$('#bDev').hidden;
      const L=document.querySelector('#sMenu .logo');for(let i=0;i<5;i++)L.dispatchEvent(new MouseEvent('click',{bubbles:true}));
      return {deep:m.includes('DEEP SPACE'),two:m.includes('Два сектора'),packet:m.includes('ПАКЕТ'),ver:$('#verTag')?$('#verTag').textContent:null,hid,after:$('#bDev').hidden,set:$('#bSettings').offsetParent!==null};}""")
    rec('T01 меню: без жанра, «пакета» и «двух секторов»; версия 1.1.1 α; разработка скрыта, но открывается',not r['deep'] and not r['two'] and not r['packet'] and r['ver']=='1.2.5 α' and r['hid'] and not r['after'] and r['set'],{**r,'errs':P.errs[:2]})

@test('T02')
async def t02(b):
    # HUD миссии: корпус числом «N/M», остальное — без процентов, секунд и номера миссии
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();const out={};for(const m of [3,7,9,14,23,42]){T.go(m);for(let i=0;i<240;i++)update(1/60);G.player.dashCd=1.3;G.player.en=47;updateHUD();
      out[m]={hp:$('#hpT').textContent,mis:$('#misT').textContent,sig:$('#sigT').textContent,chips:[...document.querySelectorAll('#hud .chip')].filter(e=>!e.hidden).map(e=>e.textContent).join('|'),bi:$('#biT').textContent};toMenu();T.fresh();T.openAll();}return out;}""")
    bad={m:v for m,v in r.items() if not re.fullmatch(r'\d+/\d+( · ИЗНОС)?',v['hp']) or 'МИССИЯ' in v['mis'] or re.search(NOISE,v['sig']+v['chips']+v['bi']) or re.search(r'\d',re.sub(r'ГРУЗ \d+/\d+','',v['chips']))}
    rec('T02 HUD: корпус «82/100», без «МИССИЯ 07/50», процентов, секунд и уровней',not bad and not P.errs,{'bad':bad,'sample':r.get(7),'errs':P.errs[:2]})

@test('T03')
async def t03(b):
    # всплывающие надписи и баннеры: длительность «· 5 С», множители и проценты в доп. частях не показываются
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();T.go(3);const f=t=>{G.float.length=0;floater(G.player.x,G.player.y,t,'#fff');return G.float[G.float.length-1].text;};
      const bn=s=>{banner('X',s);return $('#banS').textContent;};
      return [f('ЛЕДЯНОЙ ЩИТ РАСКОЛОТ · 5 С'),f('ПАРА РАЗОРВАНА · ×0,5'),f('В СПИНУ ×2'),f('РЫВОК НА ХРАНЕНИИ · 3.2 С'),bn('ЯДРО УЯЗВИМО · УРОН ×1,5'),bn('ЛОМ ×2'),bn('ВРАГИ СИЛЬНЕЕ · НАГРАДЫ ×1,25'),f('ПЕТЛЯ ВЕРНЁТСЯ · ДОБЕЙТЕ ЗА 2 С'),f('−12')];}""")
    want=['ЛЕДЯНОЙ ЩИТ РАСКОЛОТ','ПАРА РАЗОРВАНА','В СПИНУ','РЫВОК НА ХРАНЕНИИ','ЯДРО УЯЗВИМО','','ВРАГИ СИЛЬНЕЕ','ПЕТЛЯ ВЕРНЁТСЯ · ДОБЕЙТЕ ЗА 2 С','−12']
    rec('T03 надписи и баннеры без «· 5 С», «×1,5» и процентов; указания и урон остаются',r==want,{'got':r,'errs':P.errs[:2]})

@test('T04')
async def t04(b):
    # брифинг всех 50 миссий: надзаголовок без «/50», теги без «×N», подсказки и сложность без чисел
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();const out=[];for(let i=0;i<50;i++){try{openIntro(i);}catch(e){out.push([i+1,'EXC '+e]);continue;}
      out.push([i+1,$('#inSector').textContent,$('#inName').textContent,$('#inThreat').innerText,[...document.querySelectorAll('#inHint p:not(.note)')].map(e=>e.innerText).join(' '),$('#inDiffNote').textContent]);G.state='world';}return out;}""")
    bad=[x for x in r if len(x)<3 or '/50' in x[1] or re.search(NOISE,' '.join(x[3:]))]
    dup=[x for x in r if len(x)>2 and ' · ' in x[2] and x[2].split(' · ')[0].lower() in x[1].lower()]
    rec('T04 брифинги 1–50: без «/50», множителей, процентов и {SPD}; название без повтора сектора',not bad and not dup and len(r)==50,{'bad':bad[:3],'dup':dup[:3],'m23':r[22] if len(r)>22 else None,'errs':P.errs[:2]})

@test('T05')
async def t05(b):
    # справочник: семь разделов («Версии» — только в режиме разработчика); описания угроз без чисел
    P=await newpage(b)
    r=await P.js("""()=>{cxTab='ctrl';openCodex('menu');const tabs=[...document.querySelectorAll('#cxTabs .tab')].map(e=>e.dataset.t);
      REC.seen=Object.keys(EDEF);const txt={};for(const t of tabs){cxTab=t;renderCodex();const B=$('#cxBody').cloneNode(true);B.querySelectorAll('.lore').forEach(e=>e.remove());txt[t]=B.textContent;}
      const num=CODEX_ORDER.filter(k=>EDEF[k]&&/\\d/.test((EDEF[k].desc||'').replace(/VØID-000|VØID/g,''))).map(k=>k);
      window.__devUI=true;openCodex('menu');const tabs2=[...document.querySelectorAll('#cxTabs .tab')].map(e=>e.dataset.t);window.__devUI=false;
      return {tabs,tabs2,num,threat:txt.threat.length,world:txt.world.slice(0,80),noise:Object.entries(txt).filter(([k,v])=>k!=='chron'&&k!=='journals'&&/×\\s?\\d|\\d+\\s?%/.test(v)).map(([k])=>k)};}""")
    rec('T05 справочник: 7 разделов без «Версий», описания угроз без чисел, разделы без множителей и процентов',r['tabs']==['ctrl','world','threat','mods','endless','chron','journals'] and 'log' in r['tabs2'] and not r['num'] and not r['noise'] and r['threat']>2000,{**r,'errs':P.errs[:2]})

@test('T06')
async def t06(b):
    # настройки: кнопка и на ПК; в меню и паузе блока настроек нет; «ЭФФЕКТЫ» — один выбор из трёх
    P=await newpage(b)
    r=await P.js("""()=>{toMenu();const vis=$('#bSettings').offsetParent!==null;const box=document.querySelectorAll('#sMenu [data-settings],#sPause [data-settings]').length;
      openSettings('menu');const t=$('#setBody').innerText;document.querySelector('[data-fxl="less"]').click();const a=[SET.fx,SET.lessFx];document.querySelector('[data-fxl="off"]').click();const c=[SET.fx,SET.lessFx];document.querySelector('[data-fxl="full"]').click();
      return {vis,box,eff:t.includes('ЭФФЕКТЫ')||$('#setBody').textContent.includes('ЭФФЕКТЫ'),prefix:/ЭКРАН ·|УПРАВЛЕНИЕ ·|СРЕДА /.test(t),a,c,d:[SET.fx,SET.lessFx],manual:t.includes('ПРИЦЕЛ МЫШЬЮ')||$('#setBody').textContent.includes('ПРИЦЕЛ')};}""")
    rec('T06 настройки на ПК: отдельный экран, без префиксов и диагностики; эффекты — ПОЛНЫЕ/МЕНЬШЕ/ВЫКЛ',r['vis'] and r['box']==0 and r['eff'] and not r['prefix'] and r['a']==[True,True] and r['c']==[False,False] and r['d']==[True,False] and r['manual'],{**r,'errs':P.errs[:2]})

@test('T07')
async def t07(b):
    # итоги и поражение: короткие; выбор модуля без строки цифр
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();T.go(7);G.lvlQ=1;openLevelUp();const cards=$('#cards').innerText;G.state='play';missionComplete();
      const dn={stats:$('#dnStats').children.length,eb:$('#dnEyebrow').textContent,note:$('#dnNote').innerText};toMenu();T.fresh();T.openAll();T.go(3);gameOver();
      return {cards,dn,ov:[$('#ovEyebrow').textContent,$('#ovName').textContent,$('#ovStats').children.length]};}""")
    rec('T07 итоги: время и лом; поражение без таблицы; карточки модулей без цифр',r['dn']['stats']==2 and 'ЛЁГКАЯ' not in r['dn']['eb'] and not re.search(NOISE,re.sub(r'[●○] Мастерство[^\n]*','',r['dn']['note'])) and r['ov'][2]==1 and 'миссия' not in r['ov'][1] and not re.search(r'\d+[.,]\d|→',r['cards']),{**r,'errs':P.errs[:2]})

@test('T08')
async def t08(b):
    # сохранение: «СОХРАНИТЕ КОД» в меню только когда прогресс не держится; на телефоне в альбомной оно тоже видно
    P=await newpage(b,vw=844,vh=390,touch=True,alpha=False)
    r=await P.js("""()=>{T.fresh();toMenu();const a=$('#recLine').innerText;const LSok=LS.ok;LS.ok=()=>false;renderRecord();const b=$('#recLine').innerText;const w=document.querySelector('#recLine .warn');const vis=!!w&&w.offsetParent!==null;LS.ok=LSok;renderRecord();return {a,b,vis};}""")
    rec('T08 предупреждение о коде — только при риске потери, видно и на телефоне',('СОХРАНИТЕ' not in r['a']) and ('СОХРАНИТЕ КОД' in r['b']) and r['vis'],{**r,'errs':P.errs[:2]})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q140.json'))
