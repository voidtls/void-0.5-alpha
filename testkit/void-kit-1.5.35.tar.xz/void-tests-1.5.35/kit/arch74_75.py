# ---------- 75 · A-22 · визуальные таймеры отрисовки на реальном времени кадра ----------
PRE75="""/* ▼▼▼ ARCH·75 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.15 α · этап 4.4: визуальные таймеры)
   A-22 · 13 мест в рисовании, где вспышка, снег, дождь, подсветка удара или глитч убывали на 1/60 за каждую отрисовку
   (w58DrawTop, w58Screen ×4, sb74Draw, drawE90, lvTop95, heartUnder, zbDraw ×2, postDrawCrates, bg67Events), теперь убывают на
   настоящее время кадра VDT74. Симуляция эти поля не читает (перепись чтений в отчёте 4.4). Без A-22 VDT74 всегда ровно 1/60 —
   прежнее поведение побайтно. Работает только вместе с циклом A-20 (и A-19). Выключение: window.__archOff=['A-22'] до загрузки. */
ARCH.vdt=!ARCH.off['A-22']&&!ARCH.off['A-20']&&!ARCH.off['A-19'];let VDT74=1/60;
"""+END%75
S75=[
 ("  const dt0=Math.min(.05,Math.max(0,(now-last)/1000));last=now;\n  try{mobTick74(dt0,now);}",
  "  const dt0=Math.min(.05,Math.max(0,(now-last)/1000));last=now;if(ARCH.vdt)VDT74=dt0;/* ARCH·75 A-22 */\n  try{mobTick74(dt0,now);}"),
 ("if(F&&F.flash>0)F.flash-=1/60;ctx.restore();","if(F&&F.flash>0)F.flash-=VDT74;/* ARCH·75 A-22 */ctx.restore();"),
 ("f.x=(f.x+(inSnow>0?.25:.02)*(1/60)+.0003)%1;f.y=(f.y+(.04+f.s*.06)*(1/60))%1;",
  "f.x=(f.x+(inSnow>0?.25:.02)*(VDT74)+.0003)%1;f.y=(f.y+(.04+f.s*.06)*(VDT74))%1;/* ARCH·75 A-22 */"),
 ("f.x=(f.x-.1*(1/60))%1;if(f.x<0)f.x+=1;f.y=(f.y+(.6+f.s*.3)*(1/60))%1;",
  "f.x=(f.x-.1*(VDT74))%1;if(f.x<0)f.x+=1;f.y=(f.y+(.6+f.s*.3)*(VDT74))%1;/* ARCH·75 A-22 */"),
 ("const F=b.fx75;F.t-=1/60;","const F=b.fx75;F.t-=VDT74;/* ARCH·75 A-22 */"),
 ("if(b&&b.flashC95>0)b.flashC95-=1/60;","if(b&&b.flashC95>0)b.flashC95-=VDT74;/* ARCH·75 A-22 */"),
 ("if(X.glitch95>0){X.glitch95-=1/60;","if(X.glitch95>0){X.glitch95-=VDT74;/* ARCH·75 A-22 */"),
 ("if(b.whipT>0)b.whipT-=1/60;","if(b.whipT>0)b.whipT-=VDT74;/* ARCH·75 A-22 */"),
 ("const B=Z.beamFx;B.t-=1/60;","const B=Z.beamFx;B.t-=VDT74;/* ARCH·75 A-22 */"),
 ("const B=Z.ghostFx;B.t-=1/60;","const B=Z.ghostFx;B.t-=VDT74;/* ARCH·75 A-22 */"),
 ("if(j>0)P.jolt=Math.max(0,j-1/60);}","if(j>0)P.jolt=Math.max(0,j-VDT74);/* ARCH·75 A-22 */}"),
 ("const s=E.shoot;s.t+=1/60;","const s=E.shoot;s.t+=VDT74;/* ARCH·75 A-22 */"),
]
STAGES[75]=dict(vf='1.5.14 α',vt='1.5.15 α',J='m75_journal.txt',pre=PRE75,after=74,sites=S75)
