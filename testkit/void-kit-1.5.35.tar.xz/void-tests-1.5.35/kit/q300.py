# 1.4.0 α «Живые корпуса»: 16 поздних корпусов. K01–K04, K06, K08 падают на v36 (1.3.5); K05 и K07 — страховка, что игра и витрина не сломались.
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
LATE=['archive','rime','izmo','unborn','glyph','argument','shard85','serial013','silence85','callsign013','carrier85','ark90','dawn90','typo100','tidemark100','shore100s']
# отрисовка одного кадра корпуса на отдельном холсте → «отпечаток» пикселей
SNAP="""(id,t,k,e)=>{const c=document.createElement('canvas');c.width=c.height=180;const g=c.getContext('2d'),real=ctx;ctx=g;
  try{g.fillStyle='#070c16';g.fillRect(0,0,180,180);g.setTransform(2,0,0,2,90,90);if(typeof SK62!=='undefined')SK62.cur=k===null?null:{k,e};drawShip(id,t,200,{});}finally{ctx=real;if(typeof SK62!=='undefined')SK62.cur=null;}
  const d=g.getImageData(0,0,180,180).data;let h=0,sum=0;for(let i=0;i<d.length;i+=4){const v=d[i]+d[i+1]*3+d[i+2]*7;sum+=v;h=(h*31+v)>>>0;}return [h,sum];}"""

@test('K01')
async def k01(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("(L)=>{if(typeof SKFX==='undefined')return {none:true};const miss={};for(const id of L){const F=SKFX[id];const need=['under','over','dashStart','dash','dashEnd','pulse'];const m=need.filter(k=>!F||typeof F[k]!=='function');if(!F||!(F.trail||typeof F.move==='function'))m.push('move');if(m.length)miss[id]=m;}return {miss,n:L.filter(id=>SKFX[id]).length}}",LATE)
    rec('K01 у каждого из 16 поздних корпусов есть все слои: покой, двигатель, след, рывок (старт/полёт/финиш), импульс',r.get('n')==16 and not r.get('miss'),r)

@test('K02')
async def k02(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("async(L)=>{const S="+SNAP+";const out={};for(const id of L){const a=S(id,1,0,0),b=S(id,1.37,0,0),c=S(id,2.11,0,0);out[id]=(a[0]!==b[0])+(b[0]!==c[0])+(a[0]!==c[0]);}return out}",LATE)
    dead=[k for k,v in r.items() if v<3]
    rec('K02 покой живой у всех 16: три кадра в разное время — три разные картинки',not dead,{'dead':dead})

@test('K03')
async def k03(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("async(L)=>{const S="+SNAP+";const out={},dash={};for(const id of L){const idle=S(id,1,0,0),d=S(id,1,.6,0),post=S(id,1,0,.7);out[id]=[idle[0]!==d[0],idle[0]!==post[0]];dash[id]=d[0];}const base=[S('base',1,0,0)[0],S('base',1,.6,0)[0]];return {out,uniq:new Set(Object.values(dash)).size,baseSame:base[0]===base[1]}}",LATE)
    bad=[k for k,v in r['out'].items() if not (v[0] and v[1])]
    rec('K03 рывок у каждого свой: кадр полёта и кадр финиша отличаются от покоя у всех 16, все 16 кадров рывка разные; базовый корпус не тронут',not bad and r['uniq']==16 and r['baseSame'],{'bad':bad,'uniq':r['uniq'],'base':r['baseSame']})

@test('K04')
async def k04(b):
    out={}
    for where in ['world','mission']:
        P=await newpage(b,1100,700,alpha=False)
        out[where]=await P.js("""async([L,where])=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();G.save.tut.off=1;G.save.ownSkins=Object.keys(SKINS);$('#toast').hidden=true;if(where==='mission'){T.go(1);}await w8(400);
          const res={},errs0=window.__e62=[];const oe=console.error;console.error=(...a)=>{errs0.push(String(a[0]).slice(0,120));oe.apply(console,a);};let maxM=0;
          for(const id of L){G.save.skin=id;const p=G.player;p.hp=G.st.maxHp;p.dashCd=0;KEYS.KeyD=true;await w8(150);tryDash([1,0]);let m1=0;for(let i=0;i<8;i++){await w8(40);m1=Math.max(m1,SK62.marks.length);maxM=Math.max(maxM,SK62.marks.length);}
            p.en=100;tryPulse();await w8(120);const m2=SK62.marks.length;KEYS.KeyD=false;res[id]=[m1,m2];p.hp=G.st.maxHp;}
          await w8(2200);const left=SK62.marks.length;console.error=oe;return {res,maxM,left,errs:errs0.slice(0,3)}}""",[LATE,where])
        out[where]['pe']=P.errs[:3]
    ok=all(all(v[0]>0 and v[1]>0 for v in o['res'].values()) and o['maxM']<=40 and o['left']==0 and not o['errs'] and not o['pe'] for o in out.values())
    rec('K04 настоящий рывок и импульс всех 16 корпусов в секторе и в миссии: метки рывка и импульса есть, не больше 40, через 2 с исчезают, ошибок нет',ok,out)

@test('K05')
async def k05(b):
    out={}
    for id in ['base','rime','shard85','tidemark100']:
        P=await newpage(b,1100,700,alpha=False)
        out[id]=await P.js("""async(id)=>{T.fresh();G.save.tut.off=1;G.save.ownSkins=Object.keys(SKINS);G.save.skin=id;let s=12345;Math.random=()=>{s=(s*1103515245+12345)%2147483648;return s/2147483648;};T.go(2);const r=T.bot({maxSec:120});return [r.state,r.sec,r.taken,r.lvl,G.kills]}""",id)
    vals=list(out.values())
    rec('K05 игра не изменилась: одинаковый сид и бот в миссии 2 — одинаковый итог с базовым и с поздними корпусами (рывки и импульсы бота включены)',all(v==vals[0] for v in vals),out)

@test('K06')
async def k06(b):
    P=await newpage(b,1100,700,alpha=False)
    r=await P.js("""async(L)=>{T.fresh();G.save.tut.off=1;G.save.ownSkins=Object.keys(SKINS);await new Promise(r=>setTimeout(r,300));const p=G.player;const time=(id)=>{G.save.skin=id;p.dashT=.1;const t0=performance.now();for(let i=0;i<200;i++){ctx.save();drawPlayer(p,1+i/60);ctx.restore();}p.dashT=0;return (performance.now()-t0)/200;};
      const base=time('base');let worst=0,wid='';for(const id of L){/* 40 меток — худший случай */SK62.marks.length=0;G.save.skin=id;for(let i=0;i<14;i++){p.dashCd=0;SK62.now=1;try{SKFX[id].dashStart(p);SKFX[id].dashEnd(p,{x:p.x-200,y:p.y,a:0});SKFX[id].pulse(p,150);}catch(e){}}const v=time(id)-base;if(v>worst){worst=v;wid=id;}}return {base:+base.toFixed(3),worst:+worst.toFixed(3),wid}}""",LATE)
    rec('K06 производительность: добавка к отрисовке корабля в рывке при 40 метках — до 0,4 мс (ПК)',r['worst']<0.4,r)

@test('K07')
async def k07(b):
    P=await newpage(b,1280,800,alpha=False)
    r=await P.js("""async(L)=>{T.fresh();G.save.ownSkins=Object.keys(SKINS);openHangar();await new Promise(r=>setTimeout(r,400));const cs=[...document.querySelectorAll('canvas[data-prev]')];const out={};
      for(const id of L){const c=cs.find(x=>x.dataset.prev===id),i=cs.indexOf(c);const shot=ph=>{drawHangarPreviews((300+ph-i)*1000);return c.toDataURL();};out[id]=[shot(1.5)!==shot(.1),shot(1.5)!==shot(.45)];}
      return {out,errs:(window.__fzErr||[]).slice(0,2)}}""",LATE)
    bad=[k for k,v in r['out'].items() if not all(v)]
    rec('K07 «Хранилище корпусов»: карточка каждого позднего корпуса раз в 3 с показывает свой рывок и финиш',not bad and not P.errs,{'bad':bad,'pe':P.errs[:2]})

@test('K08')
async def k08(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("()=>({ver:VER_TAG,tag:$('#verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.4.0 α</dt>')})")
    rec('K08 версия 1.4.0 α и запись в журнале',r['ver']=='1.4.0 α' and r['tag']=='1.4.0 α' and r['log'],r)

if __name__=='__main__':
    sel=sys.argv[1:]
    if sel:TESTS=[t for t in TESTS if t[0] in sel]
    asyncio.run(run(TESTS,'q300'))
