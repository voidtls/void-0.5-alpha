
// ===== 0.7.4: сектора V–VI — механики, враги, события, боссы, открытый мир =====
const H74=new Set(['membrane','vent','turncoat','boarder','cocoon','absorber']);
const SB74T=new Set(['nurse','womb','flagship','fpart']);
const NU_PHASES=['КОЛЫБЕЛЬНАЯ','СХВАТКИ','ПОСЛЕДНИЙ РЕБЁНОК'],FL_PHASES=['БОРТОВОЙ ЗАЛП','БЕЗ ХОДА','РУБКА ОТКРЫТА'];
SB_NAMES.nurse='КОРМИЛИЦА';SB_NAMES.flag='ПОСЛЕДНИЙ ДОВОД';
SB_ESC.nurse={1:['unborn','unborn','pestun'],2:['unborn','singer','cord'],3:['unborn','unborn','membrane']};
SB_ESC.flag={1:['autopilot','autopilot','cadet'],2:['boarder','autopilot','fireship'],3:['autopilot','boarder','cadet','fireship']};
const SB_FLAG={inv:'inv14',obod:'obod18',nurse:'cradle22',flag:'fleet27'},SB_FLAG_M={14:'inv14',18:'obod18',22:'cradle22',27:'fleet27'};
const SB_DEATH={nurse:['КОЛЫБЕЛЬ ЗАСНУЛА','СЕКТОР V ПРОЙДЕН','Колыбели строили не мы. Мы только решали, чьи истории в них поместятся. Я ошибся с местом. И с тобой — тоже.'],
  flag:['ФЛОТ ЗАМОЛЧАЛ','СЕКТОР VI ПРОЙДЕН','Карр спрашивал, почему Стражи не стреляют по рубке. Я запретил им объяснять. Ему — тоже.']};
const SB_ESC_R={nurse:['КОРМИЛИЦА','#ff9fb8','…[дети]… проснитесь… [чужой] пришёл…'],flag:['ФЛАГМАН','#b8c4d6','Всем кораблям: к флагману. Держать строй.']};
Object.assign(SB_WRECK,{22:{cut:['ОБОЛОЧКА КОРМИЛИЦЫ','Кокон разбит. Внутри — контур корабля, ещё без номера. В скорлупе выцарапано на чужом языке одно слово, переводчик даёт: «следующий».'],keep:['ОБОЛОЧКА КОРМИЛИЦЫ','Пустой кокон. Младший вылупился и летит рядом. Колыбель спит. На стенке — отпечаток крыла, похожего на ваше.']},
  27:{bridge:['РУБКА «ПОСЛЕДНЕГО ДОВОДА»','Рубка пробита. Бортовой журнал адмирала Карра обрывается на вопросе: «Почему не в рубку?» Ответа он так и не получил.'],engine:['ДВИГАТЕЛИ «ПОСЛЕДНЕГО ДОВОДА»','Двигатели выбиты, рубка цела. Адмирал жив и молчит. В эфире флота иногда слышно: «Справа строй. Бери ниже».']}});
RADIO['С']={tag:'КОЛЫБЕЛЬ',col:'#ff9fb8',l:[{t:'…[место] освободилось. Выходите по одному…'},{t:'…ты пахнешь чужими [мирами]…'},{t:'…архив записал нас [чужим] почерком…'},{t:'…[дети] спят [сто двадцать семь] [сезонов]…'},{t:'…мы отдали им [имена] заранее. Имена живут дольше…'},{t:'…не стреляй в [кладку]. Она ещё не [знает], кто ты…'},{t:'…ты сжёг [память]. Теперь тут тесно…',c:'invcold'},{t:'…записи оттаяли. Они плачут сквозь [стену]…',c:'invmem'},{t:'…[Тала] считала нас. Нас было на одного больше…'},{t:'…ты выбрал [мёртвых]. Как тот, кто нас сохранил…',c:'dead33'},{t:'…ты выбрал [детей]. Тогда дослушай [колыбельную]…',c:'unborn33'},{t:'…[младший] летит рядом. Он помнит твой [запах]…',c:'keep22'}]};
RADIO['Т']={tag:'ФЛОТ',col:'#b8c4d6',l:[{t:'Фрегат «Северин»: экипаж 412, на связи 0.'},{t:'Крейсер «Ладога»: экипаж 980, на связи 0.'},{t:'Флагман — всем: держать строй.'},{t:'Это шлюпка 4. Нас трое. Мы видим вас. Вы — Страж?'},{t:'Курсант Тео, борт 12. Прошу разрешения вернуться в порт.'},{t:'…двигатели выбиты. Рубка цела. Почему рубка цела?…'},{t:'Не стрелять по рубке. Только по двигателям. Он не наш.'},{t:'VØID-013… на связи… — пауза в перекличке.'},{t:'Тео жив. Повторяю: Тео жив.',c:'teo'},{t:'Справа строй. Бери ниже.',c:'engine27'}]};
RADIO_SEC[4]='С';RADIO_SEC[5]='Т';
STORY_NORETREAT.add('cocoon');STORY_NORETREAT.add('vent');STORY_NORETREAT.add('womb');STORY_NORETREAT.add('nurse');STORY_NORETREAT.add('flagship');STORY_NORETREAT.add('fpart');STORY_NORETREAT.add('battery');STORY_NORETREAT.add('linkor');STORY_NORETREAT.add('lastkind');STORY_NORETREAT.add('membrane');
// --- утилиты ---
function x74(){return G.world?(G.w74r||(G.w74r={hulls:[],wells:[],strips:[],tracers:[],spores:[],milk:[],ev:{}})):(G.x74||(G.x74={hulls:[],wells:[],strips:[],tracers:[],spores:[],milk:[],ev:{}}));}
function sec74(){if(G.world){const p=G.player;return p&&inSectors(p.x,p.y)?sectorIdx(p.x,p.y):-1;}const M=MISSIONS[G.m-1];return inMission()&&M&&M.gen?M.sec:-1;}
function mercyHit(d){const p=G.player;if(!p||p.hp<=0||p.dashT>0||p.inv>0||G.deadT>0)return;if(p.shieldUp){damagePlayer(d);return;}
  damagePlayer(d*.4);G.eng74=Math.min(5,(G.eng74||0)+1);G.engT74=6;
  if(G.eng74>=5){G.eng74=0;G.lockDash=Math.max(G.lockDash||0,4);floater(p.x,p.y-30,'ДВИГАТЕЛИ ЗАГЛУШЕНЫ · РЫВОК 4 С','#b8c4d6');sfx('block');}
  else floater(p.x,p.y-30,'ДВИГАТЕЛЬ −'+Math.round(G.eng74*10)+'%','#b8c4d6');}
function shootM(x,y,a,spd,dmg){const q=shootE(x,y,a,spd,dmg,'#dfe8ff',5);if(q)q.mercy=true;return q;}
function hatchCocoon(e){if(!e.alive)return;e.alive=false;e.hatched=true;const pool=!G.world&&G.coPool74&&G.coPool74.length?G.coPool74:['unborn','gunner','phantom','shocker'];
  const t=pool[Math.floor(Math.random()*pool.length)];const n=spawnEnemy(t,e.x,e.y,{noAffix:true,spawnT:.35,zone:e.zone,escort:e.escort});
  if(n){n.hp*=1.3;n.maxHp=n.hp;if(AFX_OK.has(t)){const k=shuffle(Object.keys(AFX))[0];n.affix=[k];if(k==='armor')n.armor=3;if(k==='fast')n.spd*=1.35;}}
  explode(e.x,e.y,'#ff9fb8',14,.8);floater(e.x,e.y-20,'ВЫЛУПЛЕНИЕ','#ff9fb8');sfx('warn');if(G.x74&&!G.world)G.x74.hatched=(G.x74.hatched||0)+1;}
function memSeg(e){const a=e.wa||0,L=80;return [e.x-Math.cos(a)*L,e.y-Math.sin(a)*L,e.x+Math.cos(a)*L,e.y+Math.sin(a)*L];}
function hullLocal(h,x,y){const c=Math.cos(-h.ang),s=Math.sin(-h.ang),dx=x-h.x,dy=y-h.y;return [dx*c-dy*s,dx*s+dy*c];}
function hullIn(h,x,y,pad){const [lx,ly]=hullLocal(h,x,y);return Math.abs(lx)<h.L/2+pad&&Math.abs(ly)<h.T/2+pad;}
function hullAdd(i,n){const X=x74();const h={x:n===1?W*.5:(i?W*.72:W*.28),y:n===1?H*.36:(i?H*.58:H*.3),ang:rnd(-.4,.4),va:rnd(-.05,.05),vx:rnd(-14,14),vy:rnd(-10,10),L:Math.min(340,W*.3),T:64,cd:0};
  X.hulls.push(h);const b=spawnEnemy('battery',h.x,h.y,{noAffix:true,host74:h,ox:h.L*.22,oy:-h.T/2-4,fa:-Math.PI/2});if(b)b.cd=rnd(2,4);return h;}
// --- инициализация миссии ---
function t74Init(M){const sec=M&&M.gen?M.sec:-1;G.x74={sec,hulls:[],wells:[],strips:[],tracers:[],spores:[],milk:[],ev:{},stripT:rnd(26,38),hatched:0};G.lom74=0;G.latch74=null;G.flag74T=0;G.box74c=false;G.noEsc74=false;G.eng74=0;G.engT74=0;
  const C=SEC_WAVES[G.m];G.coPool74=C?C.nw.concat(C.old).filter(t=>!NO_BROOD.has(t)&&EDEF[t]):null;
  if(sec<4||!inMission()||G.mode==='endless')return;const m=G.m,ev=G.x74.ev;
  if(sec===5&&!M.bossRoom){const n=m>=25?2:1;for(let i=0;i<n;i++)hullAdd(i,n);}
  if(m===19)ev.birth={at:32};
  if(m===20||m===21)ev.grav={at:m===20?18:26};
  if(m>=19&&m<=21&&Math.random()<(m===21?.6:.4))ev.last={at:rnd(36,52)};
  if(m===24){ev.flag={at:28};ev.teo={};}
  if(m===25){ev.box={at:22};ev.mines={at:48};}
  if(m===26){ev.echo={at:18};ev.linkor={};}
  if(m===27)ev.order={};
  if(sec===5&&storyFlag('fleet27')==='engine'&&G.save&&G.save.medals[m]&&G.save.medals[m].clear)ev.admiral={at:rnd(14,26)};}
// --- ИИ новых врагов (из secEnemyUpdate; true = обработан) ---
function s74Update(e,dt,c){const r=s74Update0(e,dt,c);if(r&&!G.world&&e.alive&&!STATIC.has(e.type)&&e.type!=='lastkind'&&e.type!=='linkor'&&!e.retreat&&G.latch74!==e)edge74(e,dt);return r;}
function edge74(e,dt){const m=60,k=500*dt;if(e.x<m)e.vx+=k;else if(e.x>W-m)e.vx-=k;if(e.y<m)e.vy+=k;else if(e.y>H-m)e.vy-=k;}
function s74Update0(e,dt,c){const p=G.player,{ux,uy,d,sm,T,pd}=c,pdx=p.x-e.x,pdy=p.y-e.y;
  if(e.n74&&G.world){n74AI(e,dt,c);return true;}
  switch(e.type){
    case 'cocoon':{e.vx=e.vy=0;if(e.hatchT===undefined){const er=G.save&&G.save.story?clamp(erosion(),0,1):0;e.hatchT=e.hatch0||8-2*er;e.hatchMax=e.hatchT;}
      e.hatchT-=dt*(e.song>0?2:1);if(e.song>0)e.song-=dt;if(e.hatchT<=0)hatchCocoon(e);return true;}
    case 'unborn':{e.a74=(e.a74||0)+dt;e.ghost=e.a74<1;const w=Math.sin(e.t*4+e.seed)*.4;steer(e,pdx/pd-pdy/pd*w,pdy/pd+pdx/pd*w,e.spd*sm*(e.a74<1?.6:1),dt,4);return true;}
    case 'pestun':{if(e.carry===undefined){e.carry=2;e.cn=Math.floor(Math.random()*4);}
      if(e.carry>0){const m=90,C4=G.world?[[p.x-420,p.y-300],[p.x+420,p.y-300],[p.x+420,p.y+300],[p.x-420,p.y+300]]:[[m,m],[W-m,m],[W-m,H-m],[m,H-m]],q=C4[e.cn%4];
        if(!e.tg)e.tg=q.slice();steer(e,e.tg[0]-e.x,e.tg[1]-e.y,e.spd*sm,dt,2.5);
        if(Math.hypot(e.tg[0]-e.x,e.tg[1]-e.y)<50){spawnEnemy('cocoon',e.x,e.y,{noAffix:true,spawnT:.3,zone:e.zone,escort:e.escort});e.carry--;e.cn+=1+Math.floor(Math.random()*2);e.tg=null;floater(e.x,e.y-20,'КОКОН ПОСАЖЕН','#ff9fb8');}}
      else{const m=clamp((pd-300)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.6*e.dir,pdy/pd*m+pdx/pd*.6*e.dir,e.spd*sm,dt,2.5);
        e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0){e.cd=rnd(2.2,2.8);shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x),190,8,'#ff9fb8',6,!!T.isBc);}}return true;}
    case 'membrane':{let best=null,bd=1e9;for(const o of G.enemies){if(o===e||!o.alive||o.type==='membrane'||EDEF[o.type].passive||o.spawnT>0)continue;const q=Math.hypot(o.x-p.x,o.y-p.y);if(q<bd&&q<900){bd=q;best=o;}}
      let tx,ty;if(best){const k=Math.min(1,160/Math.max(1,bd));tx=best.x+(p.x-best.x)*k;ty=best.y+(p.y-best.y)*k;}else{tx=p.x-pdx/pd*260;ty=p.y-pdy/pd*260;}
      if(Math.hypot(tx-p.x,ty-p.y)<120){tx=p.x+(tx-p.x)/Math.max(1,Math.hypot(tx-p.x,ty-p.y))*120;ty=p.y+(ty-p.y)/Math.max(1,Math.hypot(tx-p.x,ty-p.y))*120;}
      const q=Math.hypot(tx-e.x,ty-e.y);if(q>8)steer(e,tx-e.x,ty-e.y,Math.min(e.spd*sm*2,q*2),dt,2);else{e.vx*=.9;e.vy*=.9;}
      const wa=Math.atan2(pdy,pdx)+Math.PI/2;e.wa=e.wa===undefined?wa:e.wa+clamp(angDiff(wa,e.wa),-1.2*dt,1.2*dt);return true;}
    case 'cord':{if(!e.paired){e.paired=1;if(!e.mateOf){const m=spawnEnemy('cord',e.x+rnd(-40,40),e.y+rnd(-40,40),{noAffix:true,zone:e.zone,mateOf:e,paired:1,spawnT:.3,escort:e.escort});if(m){e.mate=m;m.mate=e;e.ph=0;m.ph=Math.PI;}}}
      const R_=230,a=G.t*.6+(e.ph||0),tx=p.x+Math.cos(a)*R_,ty=p.y+Math.sin(a)*R_;steer(e,tx-e.x,ty-e.y,e.spd*sm,dt,2.5);
      const m=e.mate;if(m&&m.alive&&!e.cut){e.hp=Math.min(e.maxHp,e.hp+6*dt);
        if(e.uid<m.uid&&p.hp>0&&e.spawnT<=0&&m.spawnT<=0){const sd=segDistP(p.x,p.y,e.x,e.y,m.x,m.y);
          if(p.dashT>0&&segInter(p.px,p.py,p.x,p.y,e.x,e.y,m.x,m.y)){e.cut=m.cut=true;floater((e.x+m.x)/2,(e.y+m.y)/2-14,'СВЯЗЬ ПОРВАНА','#ff7fa0');sfx('boom');}
          else if(sd<p.r+6&&p.dashT<=0){e.tcd=(e.tcd||0)-dt;if(e.tcd<=0){e.tcd=1;damagePlayer(10);}}}}return true;}
    case 'singer':{const m=clamp((pd-380)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.5*e.dir,pdy/pd*m+pdx/pd*.5*e.dir,e.spd*sm,dt,2);if(Math.random()<dt*.2)e.dir*=-1;e.sing=(e.sing||0)+dt;return true;}
    case 'sporer':{const m=clamp((pd-300)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.6*e.dir,pdy/pd*m+pdx/pd*.6*e.dir,e.spd*sm,dt,2.5);if(Math.random()<dt*.2)e.dir*=-1;
      e.sp=(e.sp===undefined?3:e.sp)-dt;if(e.sp<=0&&onScreen(e)&&p.hp>0){e.sp=5*(G.atkK||1);const X=x74();if(X.spores.length<4){X.spores.push({x:p.x+rnd(-40,40),y:p.y+rnd(-40,40),r:90,t:8});sfx('warn');}}return true;}
    case 'absorber':{const m=clamp((pd-260)/120,-1,1);steer(e,pdx/pd*m,pdy/pd*m,e.spd*sm,dt,1.5);e.r=16+(e.ab||0)*.6;return true;}
    case 'embryo':{e.grow=(e.grow||0)+dt;const gm=e.fast?10:20;steer(e,pdx,pdy,e.spd*sm,dt,1.5);
      if(e.grow>=gm){e.alive=false;const g=spawnEnemy('guard',e.x,e.y,{noAffix:true,zone:e.zone,spawnT:.4,escort:e.escort});explode(e.x,e.y,'#ffb84d',16,.8);floater(e.x,e.y-24,'ДОРОС ДО СТРАЖА','#ffb84d');sfx('warn');}return true;}
    case 'lastkind':{e.lk=(e.lk||0)+dt;if(e.ex===undefined)e.ex=G.world?(e.x<p.x?-1:1):(e.x<W/2?-1:1);
      if(G.world){steer(e,-pdx/pd,-pdy/pd,e.spd,dt,1);if(e.lk>16)lastkindGone(e);}
      else{const tx=e.ex<0?-220:W+220;steer(e,tx-e.x,(H*.5-e.y)*.2,e.spd,dt,1);if(e.x<-60||e.x>W+60||e.lk>18)lastkindGone(e);}return true;}
    case 'vent':{e.vx=e.vy=0;e.vt=(e.vt===undefined?1.5:e.vt)-dt;e.life74=(e.life74===undefined?30:e.life74)-dt;
      if(e.vt<=0){e.vt=3.5;if(G.enemies.filter(o=>o.alive&&o.type==='unborn').length<10)spawnEnemy('unborn',e.x,e.y,{noAffix:true,spawnT:.3});}
      if(e.life74<=0){e.alive=false;explode(e.x,e.y,'#5a2030',10,.6);}return true;}
    case 'autopilot':{if(e.cx===undefined){e.cx=G.world?e.x:W/2+rnd(-W*.1,W*.1);e.cy=G.world?e.y:H/2+rnd(-H*.1,H*.1);e.ph=rnd(0,TAU);}
      const R_=G.world?260:Math.min(W,H)*.32,a=e.t*.9+e.ph,tx=e.cx+Math.cos(a)*R_*1.2,ty=e.cy+Math.sin(2*a)*R_*.5;steer(e,tx-e.x,ty-e.y,e.spd*sm,dt,3);
      e.cd-=dt;if(e.cd<=0&&onScreen(e)){e.cd=rnd(1.4,1.9);let tg=null,td=420;const peace=G.flag74T>0;
        if(!peace&&!e.rogue&&p.hp>0&&pd<td){tg=p;td=pd;}
        for(const o of G.enemies){if(o===e||!o.alive||o.spawnT>0||o.ghost||EDEF[o.type].passive||EDEF[o.type].sbp||(o.type==='autopilot'&&!e.rogue)||o.n74)continue;const q=Math.hypot(o.x-e.x,o.y-e.y);if(q<td){td=q;tg=o;}}
        if(tg===p)shootE(e.x,e.y,Math.atan2(p.y+p.vy*.15-e.y,p.x+p.vx*.15-e.x),330,9,'#c9d2de',4);
        else if(tg){const X=x74();X.tracers.push({x1:e.x,y1:e.y,x2:tg.x,y2:tg.y,t:.15});hurt(tg,14,{ap:true});}}return true;}
    case 'battery':{const h=e.host74;if(h){const c_=Math.cos(h.ang),s_=Math.sin(h.ang);e.x=h.x+e.ox*c_-e.oy*s_;e.y=h.y+e.ox*s_+e.oy*c_;e.face=h.ang+(e.fa||0);e.vx=e.vy=0;if(h.alive===false){kill(e,true);return true;}}
      else{e.vx=e.vy=0;e.face=Math.atan2(pdy,pdx);}if(e.eng)return true;
      const ap=Math.atan2(pdy,pdx),inArc=Math.abs(angDiff(ap,e.face))<Math.PI/4&&pd<720;
      if(e.ch>0){e.ch-=dt;if(e.ch<=0){for(let i=-2;i<=2;i++)shootE(e.x,e.y,e.face+i*.12+clamp(angDiff(ap,e.face),-.6,.6),240,10,'#c9d2de',5);sfx('shot');}}
      else{e.cd-=dt;if(e.cd<=0&&inArc&&p.hp>0){e.ch=.6;e.cd=4;}}return true;}
    case 'boarder':{if(G.latch74===e){e.la=(e.la||0)+dt*.6;e.x=p.x+Math.cos(e.la)*12;e.y=p.y+Math.sin(e.la)*12;e.vx=p.vx;e.vy=p.vy;e.bt=(e.bt||0)+dt;if(e.bt>=1){e.bt=0;damagePlayer(4);}
        if(p.dashT>0||p.hp<=0)boarderOff(e);return true;}
      if(G.latch74&&G.latch74.alive){const m=clamp((pd-90)/60,-1,1);steer(e,pdx/pd*m,pdy/pd*m,e.spd*sm,dt,3);return true;}
      steer(e,pdx,pdy,e.spd*sm,dt,3.5);if(pd<e.r+p.r+4&&p.dashT<=0&&p.inv<=0&&p.hp>0&&!(e.stun>0)&&!(e.offT>0)){G.latch74=e;e.la=Math.atan2(-pdy,-pdx);floater(p.x,p.y-30,'АБОРДАЖ · СБРОСЬТЕ РЫВКОМ','#ffb84d');sfx('block');}
      if(e.offT>0)e.offT-=dt;return true;}
    case 'fireship':{e.v74=Math.min(230,(e.v74||e.spd*.6)+dt*22);steer(e,pdx,pdy,e.v74*sm,dt,1.1);e.ft=(e.ft||0)+dt;e.face=Math.atan2(e.vy,e.vx);
      if((pd<64&&p.hp>0)||e.ft>15)fireBlast(e,false);return true;}
    case 'signaller':{const m=clamp((pd-420)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.5*e.dir,pdy/pd*m+pdx/pd*.5*e.dir,e.spd*sm,dt,2);
      e.sc=(e.sc===undefined?5:e.sc)-dt;if(e.sc<=0&&p.hp>0){e.sc=7*(G.atkK||1);let n=0;
        for(const o of G.enemies){if(n>=10)break;if(!o.alive||o===e||o.spawnT>0||o.ghost||EDEF[o.type].passive||EDEF[o.type].sbp||o.type==='cocoon'||!onScreen(o)||o.retreat)continue;shootE(o.x,o.y,Math.atan2(p.y-o.y,p.x-o.x),300,8,'#9fd8ff',4);n++;}
        floater(e.x,e.y-24,'ЗАЛП','#9fd8ff');sfx('shot');}return true;}
    case 'turncoat':{const ap=Math.atan2(pdy,pdx);e.face=(e.face||ap)+clamp(angDiff(ap,e.face||ap),-.6*dt,.6*dt);const m=clamp((pd-320)/120,-1,1);steer(e,Math.cos(e.face)*m,Math.sin(e.face)*m,e.spd*sm,dt,1.5);
      if(e.burst>0){e.bt-=dt;if(e.bt<=0){e.burst--;e.bt=.15;shootM(e.x+Math.cos(e.face)*24,e.y+Math.sin(e.face)*24,Math.atan2(p.y-e.y,p.x-e.x)+rnd(-.05,.05),290,18);}}
      else{e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0){e.cd=3;e.burst=3;e.bt=0;}}return true;}
    case 'cadet':{const m=clamp((d-280)/120,-1,1);steer(e,ux*m-uy*.6*e.dir,uy*m+ux*.6*e.dir,e.spd*sm,dt,3);if(Math.random()<dt*.25)e.dir*=-1;
      if(!e.cadR&&!e.retreat&&inMission()&&e.hp<=e.maxHp*.34){e.cadR=true;storyRetreat(e);return true;}
      e.cd-=dt;if(e.cd<=0&&onScreen(e)){e.cd=rnd(1.8,2.4);shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x)+rnd(-.35,.35),260,7,'#8fe9ff',4,!!T.isBc);}return true;}
    case 'linkor':return linkorAI(e,dt),true;
    case 'echoship':case 'echoguard':{e.ghost=false;const m=e.type==='echoship'?1:-1;steer(e,m*30,Math.sin(e.t+e.seed)*40,e.spd,dt,1);e.vx*=.98;e.ecd=(e.ecd===undefined?rnd(.5,1.5):e.ecd)-dt;
      if(e.ecd<=0){e.ecd=rnd(1.2,1.8);const foes=G.enemies.filter(o=>o.alive&&(o.type===(e.type==='echoship'?'echoguard':'echoship')));if(foes.length){const f=foes[Math.floor(Math.random()*foes.length)];x74().tracers.push({x1:e.x,y1:e.y,x2:f.x,y2:f.y,t:.18,c:EDEF[e.type].col});}}return true;}
    case 'nurse':case 'flagship':{if(!e.sbk&&!sb74Adopt(e))return true;if(e.sbk==='nurse')nuUpdate(e,dt);else flUpdate(e,dt);return true;}
    case 'womb':case 'fpart':e.vx=e.vy=0;return true;
  }
  return false;}
function lastkindGone(e){e.alive=false;e.spared=true;const S=G.save;if(S&&S.story&&G.mode==='world'){S.story.spared++;S.story.cyc.spared++;S.story.lastKind=(S.story.lastKind||0)+1;}
  floater(clamp(e.x,CX+40,CX+W-40),clamp(e.y,CY+40,CY+H-40),'ОТПУЩЕН · ПОСЛЕДНЯЯ КЛАДКА','#ffe0ea');radioLine('КОЛЫБЕЛЬ','#ff9fb8','…[спасибо]. Это слово мы не успели [перевести]…',.6);}
function boarderOff(e){if(G.latch74===e)G.latch74=null;e.stun=1.5;e.offT=3;e.hp=Math.max(1,e.hp*.5);const p=G.player,a=Math.atan2(e.y-p.y,e.x-p.x);e.vx=Math.cos(a)*320;e.vy=Math.sin(a)*320;floater(e.x,e.y-18,'СБРОШЕН','#ffb84d');sfx('block');}
function fireBlast(e,byPlayer){if(e.blasted)return;e.blasted=true;const p=G.player,R=180;explode(e.x,e.y,'#ff7a3d',40,1.3);G.shock.push({x:e.x,y:e.y,r:20,R,t:0,col:'#ff7a3d'});sfx('bigboom');shake(10);
  if(p&&p.hp>0&&Math.hypot(p.x-e.x,p.y-e.y)<R+p.r)damagePlayer(25);
  for(const o of G.enemies){if(o===e||!o.alive||o.spawnT>0||STATIC.has(o.type)||EDEF[o.type].sbp||o.type==='mine')continue;if(Math.hypot(o.x-e.x,o.y-e.y)<R+o.r)hurt(o,byPlayer?70:35,{fire:true});}
  if(e.alive){e.alive=false;}}
function linkorAI(e,dt){const p=G.player;if(!e.parts){e.parts=[];e.ang=0;e.wp=0;e.bsT=5;
    for(const [ox,oy,eng] of [[60,-30,0],[-20,-30,0],[60,30,0],[-20,30,0],[-90,-18,1],[-90,18,1]]){const q=spawnEnemy('battery',e.x,e.y,{noAffix:true,host74:e,ox,oy,fa:oy<0?-Math.PI/2:Math.PI/2,eng:!!eng,escort:true});if(q){if(eng){q.hp=q.maxHp=Math.round(q.maxHp*1.4);}q.cd=rnd(2,5);e.parts.push(q);}}}
  const engs=e.parts.filter(q=>q.alive&&q.eng).length;
  const WP=[[W*.3,H*.3],[W*.7,H*.3],[W*.7,H*.55],[W*.3,H*.55]],w=WP[e.wp%4],dx=w[0]-e.x,dy=w[1]-e.y;if(Math.hypot(dx,dy)<40)e.wp++;
  const ta=Math.atan2(dy,dx);e.ang+=clamp(angDiff(ta,e.ang),-.35*dt,.35*dt);const sp=e.spd*(engs/2);e.vx=Math.cos(e.ang)*sp;e.vy=Math.sin(e.ang)*sp;e.face=e.ang;
  if(e.bs){e.bs.t-=dt;if(e.bs.t<=0){const a=e.ang+e.bs.side*Math.PI/2;for(const ox of [-60,0,60]){const x=e.x+Math.cos(e.ang)*ox+Math.cos(a)*30,y=e.y+Math.sin(e.ang)*ox+Math.sin(a)*30;for(let i=-1;i<=1;i++)shootE(x,y,a+i*.16,210,12,'#d6dee8',6);}e.bs=null;sfx('bigboom');shake(5);}}
  else{e.bsT-=dt;if(e.bsT<=0&&p.hp>0){e.bsT=(engs?8:12)*atkK();const side=((p.x-e.x)*(-Math.sin(e.ang))+(p.y-e.y)*Math.cos(e.ang))>0?1:-1;e.bs={side,t:1};sfx('warn');}}}
function n74AI(e,dt,c){const p=G.player,z=e.zone;
  if(e.n74==='midwife'){let tg=null,td=1e9;for(const o of G.enemies){if(!o.alive||o.type!=='cocoon'||o.zone!==z)continue;const q=Math.hypot(o.x-e.x,o.y-e.y);if(q<td){td=q;tg=o;}}
    if(tg){steer(e,tg.x-e.x,tg.y-e.y,e.spd,dt,2);e.face=Math.atan2(tg.y-e.y,tg.x-e.x);if(td<46){tg.alive=false;explode(tg.x,tg.y,'#ffb84d',14,.7);floater(tg.x,tg.y-18,'КЛАДКА ВЫЖЖЕНА','#ffb84d');}}
    else{e.leaveT=(e.leaveT||0)+dt;steer(e,e.x-p.x,e.y-p.y,e.spd,dt,1);if(e.leaveT>4){e.alive=false;if(z)z.out74='helped';}}return;}
  if(e.n74==='tow'&&z&&z.dest){const tx=z.dest.x+(e.fo||0),ty=z.dest.y;steer(e,tx-e.x,ty-e.y,60,dt,1.5);e.face=Math.atan2(e.vy,e.vx);if(Math.hypot(tx-e.x,ty-e.y)<80){e.alive=false;if(z)z.out74='passed';}return;}}
// --- хуки урона и гибели ---
function s74Hurt(e,dmg,src){
  if(e.n74&&G.world){const z=e.zone;for(const o of G.enemies)if(o.zone===z&&o.n74)o.n74=null;if(z&&!z.prov74){z.prov74=1;if(z.k74==='midwife')radioLine('СТРАЖ','#ff6b8a','Ты опять на их стороне.',.3);if(z.k74==='funeral')radioLine('СТРАЖ','#ff6b8a','Ты не дал им даже этого.',.3);}}
  if(e.type==='absorber'){if(src.charged||src.pulse||src.ram||e.tired)return dmg*(src.pulse?3:1);e.shieldFlash=.1;return 0;}
  if(e.type==='membrane'){if(src.charged||src.blast||src.pulse||src.ram||e.tired)return dmg*(src.charged?1.5:1);e.shieldFlash=.1;return 0;}
  if(e.type==='vent'){if(src.charged||src.blast||src.pulse){e.vh=(e.vh||0)+(src.charged?1:.5);if(e.vh>=1)return e.hp+1;e.flash=.1;return 0;}e.shieldFlash=.1;sfx('block');return 0;}
  if(e.type==='turncoat'&&!src.pulse&&!src.blast&&!src.ap){const p=G.player;const a=Math.atan2(p.y-e.y,p.x-e.x);if(Math.abs(Math.sin(angDiff(a,e.face||0)))>.72){e.shieldFlash=.1;return dmg*.25;}}
  if(e.type==='boarder'&&G.latch74===e&&src.pulse){boarderOff(e);}
  return dmg;}
function s74Killed(e,silent){
  if(e.type==='cord'&&e.mate&&e.mate.alive&&!silent){const m=e.mate;m.hp=Math.max(1,m.hp*.5);m.maxHp*=.5;m.spd*=.7;m.cut=true;floater(m.x,m.y-20,'ПАРА РАЗОРВАНА · ×0,5','#ff7fa0');}
  if(e.type==='pestun'&&(e.carry||0)>0&&!silent)for(let i=0;i<e.carry;i++)spawnEnemy('cocoon',e.x+rnd(-30,30),e.y+rnd(-30,30),{noAffix:true,zone:e.zone,hatch0:3,spawnT:.2,escort:e.escort});
  if(e.type==='fireship'&&!e.blasted&&!silent)fireBlast(e,true);
  if(e.type==='boarder'&&G.latch74===e)G.latch74=null;
  if(e.type==='lastkind'&&!silent){if(G.world){for(let i=0;i<14;i++)G.pick.push({k:'lom',x:e.x+rnd(-20,20),y:e.y+rnd(-20,20),vx:rnd(-120,120),vy:rnd(-120,120),r:5,t:0,life:30,v:1});}else{G.lom74=(G.lom74||0)+60;for(let i=0;i<20;i++)G.pick.push({k:'xp',x:e.x+rnd(-12,12),y:e.y+rnd(-12,12),vx:rnd(-90,90),vy:rnd(-90,90),r:5,t:0,life:22});}
    floater(e.x,e.y-30,'ПОСЛЕДНЯЯ КЛАДКА УНИЧТОЖЕНА'+(G.world?'':' · +60 ЛОМА'),'#ffe0ea');}
  if(e.type==='linkor'&&e.parts)e.parts.forEach(q=>{if(q.alive)kill(q,true);});
  if(e.type==='battery'&&e.eng&&e.host74&&e.host74.alive&&!silent)floater(e.x,e.y-18,'ДВИГАТЕЛЬ ВЫБИТ','#d6dee8');
  if(e.type==='vent'&&!silent){G.lom74=(G.lom74||0)+15;floater(e.x,e.y-26,'УСТЬЕ ЗАКРЫТО · +15 ЛОМА','#ff9fb8');sfx('level');}
  if(e.type==='womb')sb74WombDied(e);
  if(e.type==='fpart')sb74PartDied(e);
  if(e.type==='cocoon'&&!silent&&!e.hatched)conEvent('cocoon');
  if(e.type==='echoship'||e.type==='echoguard'){const X=x74();X.echoK=X.echoK||{s:0,g:0};X.echoK[e.type==='echoship'?'s':'g']++;}
  if(e.teo&&!silent&&!e.spared){const S=G.save;if(S&&S.story&&G.mode==='world')S.story.teo=-1;}}
// --- баффы Певчих (из updateEnemies) ---
function s74Buffs(){for(const s of G.enemies){if(s.type!=='singer'||!s.alive||s.spawnT>0)continue;for(const o of G.enemies){if(o===s||!o.alive)continue;if(Math.hypot(o.x-s.x,o.y-s.y)<220){if(o.type==='cocoon')o.song=.3;else if(!HEAVY.has(o.type))o.buff=Math.max(o.buff,1.3);}}}}
// --- снаряды игрока: корпуса, мембраны, споры, воронки (true = снаряд поглощён) ---
function b74Hit(b){if(!G.world&&!inMission())return false;const X=G.world?G.w74r:G.x74;if(!X)return false;
  for(const h of X.hulls){if(hullIn(h,b.x,b.y,2)){b.life=0;if(SET.fx)part(b.x,b.y,rnd(-60,60),rnd(-60,60),.2,'#9fb0c4',2);return true;}}
  for(const e of G.enemies){if(e.type!=='absorber'||!e.alive||e.spawnT>0||b.charged||e.tired)continue;if(segDist(b.px,b.py,b.x,b.y,e.x,e.y)>e.r+3)continue;
    b.life=0;b.det=true;e.ab=(e.ab||0)+1;e.flash=.05;if(SET.fx)part(b.x,b.y,rnd(-30,30),rnd(-30,30),.25,'#ff9fe0',2);
    if(e.ab>=25){e.ab=0;for(let i=0;i<25;i++)shootE(e.x,e.y,i/25*TAU+rnd(-.05,.05),230,8,'#ff9fe0',5);explode(e.x,e.y,'#ff9fe0',20,.8);floater(e.x,e.y-26,'ПОГЛОТИТЕЛЬ ЛОПНУЛ','#ff9fe0');sfx('boom');}
    else if(e.ab===15)floater(e.x,e.y-e.r-12,'ПЕРЕПОЛНЕН · 15/25','#ff9fe0');return true;}
  for(const e of G.enemies){if(e.type!=='membrane'||!e.alive||e.spawnT>0||e.tired)continue;const s=memSeg(e);if(!segInter(b.px,b.py,b.x,b.y,s[0],s[1],s[2],s[3]))continue;
    if(b.blast){b.life=0;return true;}
    if(b.charged){if(!b.hit.includes(e)){b.hit.push(e);hurt(e,b.dmg,{charged:true});}continue;}
    b.life=0;e.shieldFlash=.08;if(SET.fx)part(b.x,b.y,rnd(-40,40),rnd(-40,40),.3,'#ff8fa8',2.5);return true;}
  for(const s of X.spores){if(Math.hypot(b.x-s.x,b.y-s.y)<s.r){b.vx*=.94;b.vy*=.94;const a=rnd(-.08,.08),c=Math.cos(a),sn=Math.sin(a),vx=b.vx*c-b.vy*sn;b.vy=b.vx*sn+b.vy*c;b.vx=vx;b.life-=.004;}}
  for(const w of X.wells){if(!w.on)continue;const dx=w.x-b.x,dy=w.y-b.y,d=Math.hypot(dx,dy);if(d<320&&d>1){const k=900*(1-d/320)/60;b.vx+=dx/d*k;b.vy+=dy/d*k;}}
  return false;}
// --- тик (миссия и мир) ---
function t74Tick(dt){const p=G.player;if(!p)return;const X=x74(),sec=sec74();
  if(G.engT74>0)G.engT74-=dt;else if(G.eng74>0)G.eng74=Math.max(0,G.eng74-dt*.5);
  if(G.flag74T>0)G.flag74T-=dt;
  if(G.latch74&&(!G.latch74.alive||p.hp<=0))G.latch74=null;
  for(const q of X.tracers)q.t-=dt;X.tracers=X.tracers.filter(q=>q.t>0);
  for(const s of X.spores)s.t-=dt;X.spores=X.spores.filter(s=>s.t>0);
  // молоко Кормилицы
  for(const m of X.milk){m.t-=dt;if(p.hp>0&&Math.hypot(p.x-m.x,p.y-m.y)<30){m.t=0;const h=Math.round(G.st.maxHp*.1);p.hp=Math.min(G.st.maxHp,p.hp+h);floater(p.x,p.y-26,'+'+h+' · МОЛОКО','#ffe0ea');sfx('cell');}}X.milk=X.milk.filter(m=>m.t>0);
  // мембраны: рывок насквозь
  if(p.dashT>0)for(const e of G.enemies){if(e.type!=='membrane'||!e.alive||e.spawnT>0||e.ramId===G.dashId)continue;const s=memSeg(e);if(segInter(p.px,p.py,p.x,p.y,s[0],s[1],s[2],s[3])){e.ramId=G.dashId;hurt(e,e.maxHp*.5,{ram:true});floater(e.x,e.y-20,'МЕМБРАНА ПОРВАНА','#ff8fa8');}}
  // корпуса
  for(const h of X.hulls){h.ang+=h.va*dt;h.x+=h.vx*dt;h.y+=h.vy*dt;const mx=h.L*.35,my=h.T+40;if(h.x<mx){h.x=mx;h.vx=Math.abs(h.vx);}if(h.x>W-mx){h.x=W-mx;h.vx=-Math.abs(h.vx);}if(h.y<my){h.y=my;h.vy=Math.abs(h.vy);}if(h.y>H-my){h.y=H-my;h.vy=-Math.abs(h.vy);}
    if(h.cd>0)h.cd-=dt;
    if(p.hp>0){const [lx,ly]=hullLocal(h,p.x,p.y),ex=h.L/2+p.r-Math.abs(lx),ey=h.T/2+p.r-Math.abs(ly);if(ex>0&&ey>0){let nx=lx,ny=ly;if(ex<ey)nx=Math.sign(lx||1)*(h.L/2+p.r+1);else ny=Math.sign(ly||1)*(h.T/2+p.r+1);
      const c=Math.cos(h.ang),s=Math.sin(h.ang);const wx=h.x+nx*c-ny*s,wy=h.y+nx*s+ny*c;const cx=clamp(wx,p.r,BW-p.r),cy=clamp(wy,p.r,BH-p.r);p.x=cx;p.y=cy;
      if((Math.abs(cx-wx)>2||Math.abs(cy-wy)>2)&&h.cd<=0&&p.dashT<=0){h.cd=1;damagePlayer(15);floater(p.x,p.y-26,'ЗАЖАТ КОРПУСОМ','#d6dee8');}}}
    for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||e.type==='battery'||e.type==='mine'||e.type==='linkor')continue;const [lx,ly]=hullLocal(h,e.x,e.y);if(Math.abs(lx)<h.L/2+e.r&&Math.abs(ly)<h.T/2+e.r){const ex=h.L/2+e.r-Math.abs(lx),ey=h.T/2+e.r-Math.abs(ly);let nx=lx,ny=ly;if(ex<ey)nx=Math.sign(lx||1)*(h.L/2+e.r+1);else ny=Math.sign(ly||1)*(h.T/2+e.r+1);const c=Math.cos(h.ang),s=Math.sin(h.ang);e.x=h.x+nx*c-ny*s;e.y=h.y+nx*s+ny*c;}}}
  if(X.hulls.length)for(const b of G.eb){if(b.life<=0||b.rift)continue;for(const h of X.hulls)if(hullIn(h,b.x,b.y,0)){b.life=0;break;}}
  // воронки чужой гравитации
  for(const w of X.wells){w.t+=dt;w.life-=dt;w.on=w.life>0&&(w.t%2)<.9;if(!w.on)continue;
    if(p.hp>0&&p.dashT<=0){const dx=w.x-p.x,dy=w.y-p.y,d=Math.hypot(dx,dy);if(d<320&&d>8){const k=380*(1-d/320)*dt;p.x+=dx/d*k;p.y+=dy/d*k;}}
    for(const e of G.enemies){if(!e.alive||HEAVY.has(e.type)||STATIC.has(e.type))continue;const dx=w.x-e.x,dy=w.y-e.y,d=Math.hypot(dx,dy);if(d<320&&d>8){e.vx+=dx/d*420*(1-d/320)*dt;e.vy+=dy/d*420*(1-d/320)*dt;}}}
  X.wells=X.wells.filter(w=>w.life>-1);
  // залпы мёртвого флота
  for(const s of X.strips){s.t+=dt;if(s.t>=0&&!s.fired){s.fired=true;sfx('bigboom');shake(6);
      const inS=(x,y)=>s.hor?Math.abs(y-s.pos)<s.w/2:Math.abs(x-s.pos)<s.w/2;
      if(p.hp>0&&inS(p.x,p.y)&&p.dashT<=0)damagePlayer(22);
      for(const e of G.enemies){if(!e.alive||e.spawnT>0||STATIC.has(e.type)||EDEF[e.type].sbp||EDEF[e.type].passive)continue;if(inS(e.x,e.y))hurt(e,120,{force:true,strip:true});}}}
  X.strips=X.strips.filter(s=>s.t<.4);
  jr74Tick(dt,sec);
  if(!G.world&&inMission()){t74Events(dt,X,sec);if(sec>=4)t74Rescue(dt);}}
// застрявшие за краем арены (держатели дистанции у стены): 4 с за кадром — возвращаются внутрь
function t74Rescue(dt){for(const e of G.enemies){if(!e.alive||e.spawnT>0||e.retreat||STATIC.has(e.type)||EDEF[e.type].passive||e.type==='lastkind'||e.type==='linkor')continue;
  const out=e.x<-20||e.x>W+20||e.y<-20||e.y>H+20;if(!out){e.off74=0;continue;}e.off74=(e.off74||0)+dt;
  if(e.off74>4){e.off74=0;e.x=clamp(e.x,50,W-50);e.y=clamp(e.y,50,H-50);e.vx=e.vy=0;e.spawnT=.4;}}}
function t74Events(dt,X,sec){const p=G.player,M=MISSIONS[G.m-1],ev=X.ev,mt=G.mT;if(!M||G.endT>0||G.deadT>0)return;
  if(sec===5&&!M.bossRoom&&!G.sb){X.stripT-=dt;if(X.stripT<=0&&p.hp>0){X.stripT=rnd(40,55);const n=3+Math.floor(Math.random()*3),hor=Math.random()<.5;const tele=G.noTele?1.6:3;
      for(let i=0;i<n;i++){const pos=hor?rnd(H*.08,H*.92):rnd(W*.08,W*.92);X.strips.push({hor,pos,w:46,t:-tele-i*.25,fired:false});}
      banner('ЗАЛП МЁРТВОГО ФЛОТА','ФЛОТ БЬЁТ ПО ПОЗИЦИЯМ СТРАЖЕЙ 127-ЛЕТНЕЙ ДАВНОСТИ');sfx('warn');}}
  if(ev.birth&&!ev.birth.done&&mt>=ev.birth.at){ev.birth.done=1;const m=60;for(const [x,y] of [[m,H*.5],[W-m,H*.5],[W*.5,m],[W*.5,H-m]])spawnEnemy('vent',x,y,{noAffix:true,spawnT:.6});
    banner('РОДЫ','УСТЬЯ КОЛЫБЕЛИ ОТКРЫТЫ · ЗАКРОЙТЕ ИХ ЗАРЯДОМ ИЛИ «РАЗРЫВОМ»');radioLine('КОЛЫБЕЛЬ','#ff9fb8','…[время]. Выходите. Он освободил [место]…',.5);sfx('warn');}
  if(ev.grav&&!ev.grav.done&&mt>=ev.grav.at){ev.grav.done=1;for(let i=0;i<3;i++){let x,y,k=0;do{x=rnd(W*.15,W*.85);y=rnd(H*.15,H*.85);}while(Math.hypot(x-p.x,y-p.y)<260&&++k<10);X.wells.push({x,y,t:rnd(0,2),life:40,on:false});}
    banner('ЧУЖАЯ ГРАВИТАЦИЯ','ВОРОНКИ ТЯНУТ В РИТМЕ СЕРДЦА · ЛЕТАЙТЕ МЕЖДУ УДАРАМИ');sfx('warn');}
  if(ev.last&&!ev.last.done&&mt>=ev.last.at){ev.last.done=1;const fromL=Math.random()<.5;spawnEnemy('lastkind',fromL?W*.25:W*.75,-50,{noAffix:true,spawnT:.8});banner('ПОСЛЕДНИЙ ИЗ ВИДА','НЕ АТАКУЕТ · УХОДИТ ЗА КРАЙ');}
  if(ev.flag){const F=ev.flag;if(!F.on&&!F.done&&mt>=F.at){F.on=1;F.x=rnd(W*.2,W*.8);F.y=rnd(H*.25,H*.75);F.p=0;banner('ПОДНЯТЬ ФЛАГ','ДЕРЖИТЕСЬ В КРУГЕ 12 С · АВТОПИЛОТЫ ПРИЗНАЮТ ВАС СВОИМ');}
    if(F.on&&!F.done){if(p.hp>0&&Math.hypot(p.x-F.x,p.y-F.y)<70)F.p+=dt;if(F.p>=12){F.done=1;F.on=0;G.flag74T=30;G.lom74+=30;banner('ФЛАГ ПОДНЯТ','30 С АВТОПИЛОТЫ БЬЮТ ТОЛЬКО ЧУЖИХ · +30 ЛОМА');sfx('level');radioLine('ФЛОТ','#b8c4d6','Флагман — всем: опознан свой. Держать строй.',.3);}}}
  if(ev.box){const B=ev.box;if(!B.on&&!B.done&&mt>=B.at){B.on=1;B.x=rnd(W*.15,W*.4);B.y=rnd(H*.2,H*.8);B.ex=W-80;B.ey=rnd(H*.25,H*.75);banner('ЧЁРНЫЙ ЯЩИК','ПОДБЕРИТЕ И ДОСТАВЬТЕ К ВЫХОДУ · ГРУЗ ЗАМЕДЛЯЕТ');}
    if(B.on&&!B.done){if(!B.got&&p.hp>0&&Math.hypot(p.x-B.x,p.y-B.y)<30){B.got=1;G.box74c=true;floater(p.x,p.y-26,'ЯЩИК НА БОРТУ · −15% СКОРОСТИ','#ffd36b');sfx('pick');}
      if(B.got){B.x=p.x;B.y=p.y;if(Math.hypot(p.x-B.ex,p.y-B.ey)<60){B.done=1;B.on=0;G.box74c=false;G.lom74+=60;sfx('level');banner('ДОКЛАД ДОСТАВЛЕН','+60 ЛОМА');
        toast('ЧЁРНЫЙ ЯЩИК · ПОСЛЕДНИЙ ДОКЛАД','«Флагман — штабу. Стражи бьют только по двигателям. Повторяю: только по двигателям. Рубки целы. Мы живы. Мы не понимаем, почему мы живы».');
        if(G.mode==='world'&&G.save&&G.save.story)G.save.story.box81=1;}}}}
  if(ev.mines&&!ev.mines.done&&mt>=ev.mines.at){ev.mines.done=1;let cx,cy,k=0;do{cx=rnd(W*.25,W*.75);cy=rnd(H*.25,H*.75);}while(Math.hypot(cx-p.x,cy-p.y)<300&&++k<10);
    for(let i=0;i<9;i++){const a=i/9*TAU,r=rnd(60,190);spawnEnemy('mine',cx+Math.cos(a)*r,cy+Math.sin(a)*r,{arm:.95,fuse:0,life:40,noAffix:true});}banner('МИННОЕ ПОЛЕ','ПОЛЕ СТАВИЛ ФЛОТ — ПРОТИВ СТРАЖЕЙ · «РАЗРЫВ» ПРОБИВАЕТ КОРИДОР');sfx('warn');}
  if(ev.echo){const E_=ev.echo;if(!E_.on&&!E_.done&&mt>=E_.at){E_.on=1;E_.t=0;for(let i=0;i<4;i++)spawnEnemy('echoship',W*.12,H*(.2+i*.2),{noAffix:true,spawnT:.8});for(let i=0;i<3;i++)spawnEnemy('echoguard',W*.88,H*(.3+i*.2),{noAffix:true,spawnT:.8});
      banner('БИТВА 127 ЛЕТ НАЗАД','ЭХО ФЛОТА И СТРАЖЕЙ · МОЖНО ПОМОЧЬ ЛЮБОЙ СТОРОНЕ');}
    if(E_.on){E_.t+=dt;if(E_.t>=20){E_.on=0;E_.done=1;const K=X.echoK||{s:0,g:0};G.enemies.forEach(o=>{if(o.alive&&(o.type==='echoship'||o.type==='echoguard')){o.alive=false;explode(o.x,o.y,EDEF[o.type].col,8,.6);}});
      if(K.g>K.s){G.lom74+=40;floater(W/2,H*.3,'ВЫ ПОМОГЛИ ФЛОТУ · +40 ЛОМА','#b8c4d6');}
      else if(K.s>K.g){floater(W/2,H*.3,'ВЫ ПОМОГЛИ СТРАЖАМ','#ffb84d');if(G.mode==='world'&&G.save&&G.save.story)G.save.story.echo127='guard';radioLine('СТРАЖ','#ff6b8a','Тогда ты был на нашей стороне. Ты этого не помнишь.',.5);}}}}
  if(ev.linkor&&!ev.linkor.done&&G.waveIdx>=3&&!G.spawnQ.length){ev.linkor.done=1;spawnEnemy('linkor',W/2,-90,{noAffix:true,spawnT:1.2});banner('СКЕЛЕТ ЛИНКОРА','ВЫБЕЙТЕ ДВИГАТЕЛИ · ДЕРЖИТЕСЬ У НОСА И КОРМЫ');sfx('warn');}
  if(ev.order){const O=ev.order;if(!O.start&&G.waves.length&&G.waveIdx>=G.waves.length){O.start=mt;banner('ПОСЛЕДНИЙ ПРИКАЗ','«ВСЕМ КОРАБЛЯМ: КУРС НА ФЛАГМАН» · РАЗБЕЙТЕ ВОЛНУ ЗА 25 С');radioLine('ФЛАГМАН','#b8c4d6','Всем кораблям: курс на флагман.',.2);}
    if(O.start&&!O.done){const alive=G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive).length+G.warns.length+G.spawnQ.length;if(alive===0){O.done=1;if(mt-O.start<25){G.noEsc74=true;floater(W/2,H*.35,'ФЛАГМАН ВЫХОДИТ БЕЗ ОХРАНЫ','#d6dee8');}}}}
  if(ev.teo&&!ev.teo.tagged){const c=G.enemies.find(e=>e.alive&&e.type==='cadet'&&e.spawnT<=0);if(c){c.teo=true;ev.teo.tagged=1;ev.teo.e=c;floater(c.x,c.y-22,'КУРСАНТ ТЕО','#8fe9ff');}}
  if(ev.teo&&ev.teo.e&&!ev.teo.done&&!ev.teo.e.alive){ev.teo.done=1;if(ev.teo.e.spared){if(G.mode==='world'&&G.save&&G.save.story)G.save.story.teo=1;radioLine('ФЛОТ','#b8c4d6','Курсант Тео, борт 12: вернулся. Спасибо, кто бы ты ни был.',.4);}}
  if(ev.admiral&&!ev.admiral.done&&mt>=ev.admiral.at){ev.admiral.done=1;radioLine('АДМИРАЛ КАРР','#b8c4d6',['Справа строй. Бери ниже.','Брандеры идут с кормы. Не стой на месте.','Связист за строем. Сними его первым.'][Math.floor(Math.random()*3)],0);}}
// --- спутник «Младший» (выбор «Выносить») ---
function jr74Tick(dt,sec){const p=G.player;if(storyFlag('cradle22')!=='keep'||(sec!==4&&sec!==5)||!p||p.hp<=0){G.jr74=null;return;}
  const J=G.jr74||(G.jr74={a:0,cd:1});J.a+=dt*1.4;J.x=p.x+Math.cos(J.a)*44;J.y=p.y+Math.sin(J.a)*44;J.cd-=dt;
  if(J.cd<=0){const t=nearestEnemy(J.x,J.y,420);if(t){J.cd=1.1;const an=Math.atan2(t.y-J.y,t.x-J.x);G.pb.push({x:J.x,y:J.y,px:J.x,py:J.y,vx:Math.cos(an)*760,vy:Math.sin(an)*760,dmg:G.st.dmg*.35,pierce:0,rico:0,life:.7,hit:[],drone:true,jr:true});}else J.cd=.25;}}
// --- «Милость» (выбор «По двигателям»): попадание по отступающему — сдача без смерти ---
function mercySurrender(e){if(storyFlag('fleet27')!=='engine'||!e.retreat)return false;e.alive=false;e.spared=true;const S=G.save;if(S&&S.story){S.story.spared++;S.story.cyc.spared++;}
  if(!G.world)G.lom74=(G.lom74||0)+5;floater(e.x,e.y-24,'СДАЛСЯ · МИЛОСТЬ'+(G.world?'':' · +5 ЛОМА'),'#dfe8ff');sfx('pick');return true;}
// --- отрисовка: под врагами ---
function d74Under(t){const X=G.world?G.w74r:G.x74;if(!X)return;
  for(const h of X.hulls){if(G.world&&!inView(h.x,h.y,h.L))continue;ctx.save();ctx.translate(h.x,h.y);ctx.rotate(h.ang);ctx.fillStyle='#121722';ctx.strokeStyle='#6b7688';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-h.L/2,-h.T/2);ctx.lineTo(h.L/2-18,-h.T/2);ctx.lineTo(h.L/2,0);ctx.lineTo(h.L/2-18,h.T/2);ctx.lineTo(-h.L/2,h.T/2);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.strokeStyle='rgba(155,170,190,.35)';ctx.lineWidth=1;for(let i=-3;i<=3;i++){ctx.beginPath();ctx.moveTo(i*h.L/8,-h.T/2+6);ctx.lineTo(i*h.L/8,h.T/2-6);ctx.stroke();}
    const bl=Math.sin(t*3+h.x)>.6;ctx.fillStyle=bl?'#ff4f6e':'#4a1a22';ctx.beginPath();ctx.arc(-h.L/2+14,0,3,0,TAU);ctx.fill();ctx.restore();}
  for(const w of X.wells){if(w.life<=0)continue;const k=w.on?1:.3;ctx.strokeStyle='#ff6b8a';ctx.lineWidth=1.5;ctx.globalAlpha=.07*k;ctx.setLineDash([4,10]);ctx.beginPath();ctx.arc(w.x,w.y,320,0,TAU);ctx.stroke();ctx.setLineDash([]);if(w.on)for(let i=0;i<2;i++){const r=320*((w.t*.9+i/2)%1);ctx.globalAlpha=.22*(r/320);ctx.beginPath();ctx.arc(w.x,w.y,r,0,TAU);ctx.stroke();}
    glow(w.x,w.y,40,'#ff6b8a',.5*k);ctx.fillStyle='#1a0812';ctx.globalAlpha=1;ctx.beginPath();ctx.arc(w.x,w.y,12,0,TAU);ctx.fill();ctx.strokeStyle='#ff9fb8';ctx.stroke();}
  ctx.globalAlpha=1;
  for(const s of X.spores){const k=Math.min(1,s.t/1);ctx.fillStyle='#ffd0e0';ctx.globalAlpha=.12*k;ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,TAU);ctx.fill();ctx.globalAlpha=.4*k;ctx.strokeStyle='#ffd0e0';ctx.setLineDash([3,6]);ctx.stroke();ctx.setLineDash([]);
    for(let i=0;i<6;i++){const a=t*.7+i;ctx.fillRect(s.x+Math.cos(a)*s.r*.6,s.y+Math.sin(a*1.3)*s.r*.6,2,2);}}
  ctx.globalAlpha=1;
  for(const m of X.milk){glow(m.x,m.y,22,'#ffe0ea',.6+.3*Math.sin(t*5));ctx.fillStyle='#ffe0ea';ctx.beginPath();ctx.arc(m.x,m.y,6,0,TAU);ctx.fill();}}
// --- отрисовка: над врагами ---
function d74Draw(t){const X=G.world?G.w74r:G.x74;if(!X)return;const p=G.player;
  for(const q of X.tracers){ctx.strokeStyle=q.c||'#e6eef8';ctx.globalAlpha=Math.min(1,q.t*6);ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(q.x1,q.y1);ctx.lineTo(q.x2,q.y2);ctx.stroke();}ctx.globalAlpha=1;
  for(const s of X.strips){const W_=s.hor?W:s.w,H_=s.hor?s.w:H,x0=s.hor?0:s.pos-s.w/2,y0=s.hor?s.pos-s.w/2:0;
    if(s.t<0){if(G.noTele&&s.t<-1)continue;ctx.fillStyle='#ff4f6e';ctx.globalAlpha=.08+.1*(Math.sin(t*16)>0?1:0);ctx.fillRect(x0,y0,W_,H_);ctx.globalAlpha=.6;ctx.strokeStyle='#ff4f6e';ctx.setLineDash([10,8]);ctx.strokeRect(x0,y0,W_,H_);ctx.setLineDash([]);}
    else{ctx.globalCompositeOperation='lighter';ctx.fillStyle='#ffd0a0';ctx.globalAlpha=.6*(1-s.t/.4);ctx.fillRect(x0,y0,W_,H_);ctx.globalCompositeOperation='source-over';}}
  ctx.globalAlpha=1;
  for(const e of G.enemies){if(!e.alive)continue;
    if(e.type==='membrane'&&e.spawnT<=0){const s=memSeg(e);ctx.strokeStyle=e.shieldFlash>0?'#ffffff':'#ff8fa8';ctx.globalAlpha=.75;ctx.lineWidth=7;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(s[0],s[1]);ctx.quadraticCurveTo(e.x+Math.cos(e.wa+Math.PI/2)*10*Math.sin(t*4),e.y+Math.sin(e.wa+Math.PI/2)*10*Math.sin(t*4),s[2],s[3]);ctx.stroke();ctx.lineWidth=2;ctx.strokeStyle='#ffe0ea';ctx.globalAlpha=.6;ctx.stroke();ctx.lineCap='butt';ctx.globalAlpha=1;}
    if(e.type==='cord'&&e.mate&&e.mate.alive&&!e.cut&&e.uid<e.mate.uid&&e.spawnT<=0){ctx.strokeStyle='#ff7fa0';ctx.globalAlpha=.7;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(e.x,e.y);const mx=(e.x+e.mate.x)/2+Math.sin(t*3)*14,my=(e.y+e.mate.y)/2+Math.cos(t*3)*14;ctx.quadraticCurveTo(mx,my,e.mate.x,e.mate.y);ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='singer'&&e.spawnT<=0){const r=220*((e.sing||0)%1.6)/1.6;ctx.strokeStyle='#ffd0e0';ctx.globalAlpha=.35*(1-r/220);ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,r,0,TAU);ctx.stroke();ctx.globalAlpha=.12;ctx.setLineDash([2,8]);ctx.beginPath();ctx.arc(e.x,e.y,220,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
    if(e.type==='cocoon'&&e.hatchMax){const k=1-Math.max(0,e.hatchT)/e.hatchMax;ctx.strokeStyle='#ffe0ea';ctx.lineWidth=2;ctx.globalAlpha=.8;ctx.beginPath();ctx.arc(e.x,e.y,e.r+6,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='embryo'){const k=(e.grow||0)/(e.fast?10:20);ctx.strokeStyle='#ffb84d';ctx.lineWidth=2;ctx.globalAlpha=.8;ctx.beginPath();ctx.arc(e.x,e.y,e.r+6,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='signaller'&&e.sc!==undefined&&e.sc<=3&&e.spawnT<=0){ctx.font='700 14px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#9fd8ff';ctx.fillText(String(Math.max(1,Math.ceil(e.sc))),e.x,e.y-e.r-12);}
    if(e.type==='fireship'&&p&&Math.hypot(p.x-e.x,p.y-e.y)<300&&!G.noTele){ctx.strokeStyle='#ff7a3d';ctx.globalAlpha=.25+.25*Math.sin(t*14);ctx.lineWidth=1.5;ctx.setLineDash([5,6]);ctx.beginPath();ctx.arc(e.x,e.y,180,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
    if(e.type==='battery'&&!e.eng&&e.ch>0&&!G.noTele){ctx.fillStyle='#ff4f6e';ctx.globalAlpha=.18;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.arc(e.x,e.y,260,e.face-Math.PI/4,e.face+Math.PI/4);ctx.closePath();ctx.fill();ctx.globalAlpha=1;}
    if(e.type==='linkor'&&e.bs&&!G.noTele){const a=e.ang+e.bs.side*Math.PI/2;ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.4+.4*Math.sin(t*20);ctx.lineWidth=3;ctx.beginPath();for(const ox of [-60,0,60]){const x=e.x+Math.cos(e.ang)*ox+Math.cos(a)*30,y=e.y+Math.sin(e.ang)*ox+Math.sin(a)*30;ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(a)*160,y+Math.sin(a)*160);}ctx.stroke();ctx.globalAlpha=1;}
    if(e.teo&&e.spawnT<=0)worldLabel(e.x,e.y-e.r-14,'ТЕО','#8fe9ff');
    if(e.n74&&e.spawnT<=0)worldLabel(e.x,e.y-e.r-14,e.n74==='tow'?'ПОХОРОННЫЙ КОНВОЙ':'ПОВИТУХА','#ffb84d');}
  if(!G.world&&G.x74){const ev=G.x74.ev;
    if(ev.flag&&ev.flag.on){const F=ev.flag;glow(F.x,F.y,70,'#b8c4d6',.35);ctx.strokeStyle='#d6dee8';ctx.lineWidth=2;ctx.setLineDash([6,6]);ctx.lineDashOffset=-t*20;ctx.beginPath();ctx.arc(F.x,F.y,70,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;
      ctx.lineWidth=4;ctx.beginPath();ctx.arc(F.x,F.y,78,-Math.PI/2,-Math.PI/2+TAU*F.p/12);ctx.stroke();ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(F.x,F.y+18);ctx.lineTo(F.x,F.y-22);ctx.stroke();ctx.fillStyle='#d6dee8';ctx.fillRect(F.x,F.y-22,16,10);worldLabel(F.x,F.y-34,'ФЛАГ · '+Math.ceil(12-F.p)+' С','#d6dee8');}
    if(ev.box&&ev.box.on){const B=ev.box;if(!B.got){glow(B.x,B.y,30,'#ffd36b',.6);ctx.fillStyle='#1a1408';ctx.strokeStyle='#ffd36b';ctx.lineWidth=2;ctx.fillRect(B.x-9,B.y-7,18,14);ctx.strokeRect(B.x-9,B.y-7,18,14);worldLabel(B.x,B.y-20,'ЧЁРНЫЙ ЯЩИК','#ffd36b');}
      ctx.strokeStyle='#ffd36b';ctx.globalAlpha=.6;ctx.setLineDash([5,5]);ctx.beginPath();ctx.arc(B.ex,B.ey,60,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;worldLabel(B.ex,B.ey-70,'ВЫХОД','#ffd36b');}}
  if(G.jr74&&p&&p.hp>0){const J=G.jr74;ctx.save();ctx.translate(J.x,J.y);ctx.rotate(J.a+Math.PI/2);glow(0,0,14,'#ff9fb8',.5);ctx.fillStyle='rgba(255,159,184,.35)';ctx.strokeStyle='#ff9fb8';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(8,0);ctx.lineTo(-6,-5);ctx.lineTo(-3,0);ctx.lineTo(-6,5);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
  sb74ExtraDraw(t);}
// --- рисунки новых врагов (default в drawEnemy, начало координат — центр врага) ---
function drawE74(e,t,icon,col,face,alpha,P){const r=e.r;
  switch(e.type){
    case 'cocoon':{const k=e.hatchMax?1-Math.max(0,e.hatchT)/e.hatchMax:0,s=1+.08*Math.sin(t*(4+k*8));ctx.scale(s,s*1.15);ctx.fillStyle='rgba(60,14,30,.9)';ctx.beginPath();ctx.ellipse(0,0,r*.8,r,0,0,TAU);ctx.fill();ctx.stroke();
      glow(0,0,r*1.2,'#ffe0ea',.25+.6*k);ctx.strokeStyle='rgba(255,224,234,.6)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-r*.5,-r*.4);ctx.quadraticCurveTo(0,0,r*.4,r*.5);ctx.stroke();break;}
    case 'unborn':ctx.rotate(face);ctx.beginPath();ctx.moveTo(r,0);ctx.quadraticCurveTo(0,-r,-r,-r*.3);ctx.quadraticCurveTo(-r*.4,0,-r,r*.3);ctx.quadraticCurveTo(0,r,r,0);ctx.closePath();ctx.fill();ctx.stroke();break;
    case 'pestun':{ctx.rotate(face);ctx.beginPath();ctx.ellipse(0,0,r,r*.7,0,0,TAU);ctx.fill();ctx.stroke();const n=e.carry===undefined?2:e.carry;ctx.fillStyle='#ff9fb8';for(let i=0;i<n;i++){ctx.beginPath();ctx.ellipse(-r*.3+i*r*.6,r*.75,4,6,0,0,TAU);ctx.fill();}
      ctx.strokeStyle=col;ctx.lineWidth=1.5;for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(-r*.2,s*r*.6);ctx.quadraticCurveTo(-r*.8,s*r*1.4*(1+.2*Math.sin(t*8)),-r*1.2,s*r*.7);ctx.stroke();}break;}
    case 'membrane':ctx.beginPath();ctx.arc(0,0,r*.7,0,TAU);ctx.fill();ctx.stroke();break;
    case 'cord':ctx.rotate(t*1.5);ctx.beginPath();for(let i=0;i<=12;i++){const a=i/12*TAU,rr=r*(1+.15*Math.sin(a*3+t*4));ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,3,0,TAU);ctx.fill();break;
    case 'singer':{ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();ctx.strokeStyle=col;ctx.lineWidth=1.2;for(let i=0;i<3;i++){const a=t*2+i*TAU/3;ctx.beginPath();ctx.arc(0,0,r*.55,a,a+.8);ctx.stroke();}glow(0,0,r,'#ffd0e0',.4+.3*Math.sin(t*6));break;}
    case 'sporer':{ctx.beginPath();for(let i=0;i<=10;i++){const a=i/10*TAU,rr=r*(i%2?.7:1.05);ctx.lineTo(Math.cos(a+t)*rr,Math.sin(a+t)*rr);}ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle=col;for(let i=0;i<3;i++){const a=t*2+i*2.1;ctx.fillRect(Math.cos(a)*r*1.3,Math.sin(a)*r*1.3,2,2);}break;}
    case 'absorber':{const rr=e.r||r,k=(e.ab||0)/25;ctx.fillStyle='#2a0a24';ctx.beginPath();ctx.arc(0,0,rr,0,TAU);ctx.fill();ctx.stroke();glow(0,0,rr*1.2,'#ff9fe0',.25+.6*k);ctx.strokeStyle='#ff9fe0';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,rr*.55,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();break;}
    case 'embryo':{const k=Math.min(1,(e.grow||0)/(e.fast?10:20));ctx.scale(1+k*.6,1+k*.6);ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();ctx.strokeStyle='#ffb84d';ctx.globalAlpha=alpha*(.3+.7*k);ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,r+3,-1,1);ctx.stroke();break;}
    case 'lastkind':{ctx.rotate(face);ctx.beginPath();ctx.ellipse(0,0,r*1.3,r*.8,0,0,TAU);ctx.fill();ctx.stroke();ctx.fillStyle='#ffe0ea';for(let i=0;i<5;i++){ctx.beginPath();ctx.ellipse(-r*.6+i*r*.3,0,4,6,0,0,TAU);ctx.fill();}glow(0,0,r*1.4,'#ffe0ea',.3);break;}
    case 'vent':{const k=.5+.5*Math.sin(t*5);ctx.fillStyle='#1a0812';ctx.beginPath();for(let i=0;i<=10;i++){const a=i/10*TAU,rr=r*(1+.2*Math.sin(a*4+t*3));ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();glow(0,0,r*1.6,'#ff6b8a',.3+.4*k);if(!icon&&e.vh>0){ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,r+6,-Math.PI/2,-Math.PI/2+TAU*e.vh);ctx.stroke();}break;}
    case 'womb':{const s=1+.1*Math.sin(t*5.2);ctx.scale(s,s);ctx.fillStyle='#2a0a16';ctx.beginPath();ctx.ellipse(0,0,r,r*.8,0,0,TAU);ctx.fill();ctx.stroke();glow(0,0,r,'#ff6b8a',.5);if(!icon&&e.cut>0){ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,r+6,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,e.cut/2));ctx.stroke();}break;}
    case 'nurse':{const b=!icon&&G.sb===e?e:null,open=b&&nuOpen(b);const k=icon?.55:1;ctx.scale(k,k);const R=r*(1+.05*Math.sin(t*TAU/1.2));
      ctx.fillStyle='#24060f';ctx.strokeStyle=open||e.flash>0?'#ffffff':col;ctx.lineWidth=3;ctx.beginPath();for(let i=0;i<=24;i++){const a=i/24*TAU,rr=R*(1+.07*Math.sin(a*5+t*2));ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle='#ff9fb8';ctx.lineWidth=1.5;for(let i=0;i<3;i++){ctx.beginPath();ctx.arc(0,0,R*(.35+i*.2),t*(i%2?1:-1),t*(i%2?1:-1)+4);ctx.stroke();}
      if(b&&(b.phase===3||b.st==='final')){glow(0,0,R*.6,'#8fe9ff',.7+.2*Math.sin(t*6));ctx.strokeStyle='#8fe9ff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(20,0);ctx.lineTo(-12,-12);ctx.lineTo(-6,0);ctx.lineTo(-12,12);ctx.closePath();ctx.stroke();}
      else{glow(0,0,R*.5,open?'#ffffff':'#ff6b8a',open?.9:.5);}
      if(b&&!open&&b.st!=='dying'){ctx.strokeStyle=e.domeFlash>0?'#ffffff':'#ff6b8a';ctx.globalAlpha=alpha*.4;ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,R+12,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}break;}
    case 'autopilot':ctx.rotate(face);ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(-r*.6,-r*.9);ctx.lineTo(-r*.2,0);ctx.lineTo(-r*.6,r*.9);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle=G.flag74T>0?'#7affc9':'#ff4f6e';ctx.fillRect(-r*.5,-1.5,3,3);break;
    case 'battery':{ctx.rotate(e.face||0);if(e.eng){ctx.fillRect(-r*.7,-r*.5,r*1.2,r);ctx.strokeRect(-r*.7,-r*.5,r*1.2,r);if(!icon){glow(-r,0,12,'#8fe9ff',.4+.3*Math.sin(t*20));}break;}
      ctx.beginPath();ctx.arc(0,0,r*.75,0,TAU);ctx.fill();ctx.stroke();ctx.fillStyle=e.ch>0?'#ffffff':col;for(const o of [-5,0,5])ctx.fillRect(4,o-1.5,r+4,3);break;}
    case 'boarder':ctx.rotate(face);ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(0,-r);ctx.lineTo(-r,0);ctx.lineTo(0,r);ctx.closePath();ctx.fill();ctx.stroke();ctx.strokeStyle=col;ctx.lineWidth=1.5;ctx.beginPath();for(const s of [-1,1]){ctx.moveTo(r*.5,s*r*.4);ctx.lineTo(r*1.3,s*r*.7);}ctx.stroke();break;
    case 'fireship':{ctx.rotate(e.face!==undefined?e.face:face);ctx.fillRect(-r,-r*.6,r*1.8,r*1.2);ctx.strokeRect(-r,-r*.6,r*1.8,r*1.2);glow(0,0,r*1.2,'#ff7a3d',.5+.3*Math.sin(t*(6+(e.ft||0))));ctx.fillStyle='#ffb07a';ctx.beginPath();ctx.arc(0,0,4,0,TAU);ctx.fill();
      if(!icon&&SET.fx&&Math.random()<.4)part(e.x,e.y,rnd(-30,30),rnd(-30,30),.4,'#ff7a3d',2);break;}
    case 'signaller':ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();ctx.strokeStyle=col;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,-r);ctx.lineTo(0,-r-10);ctx.stroke();for(let i=1;i<=2;i++){ctx.globalAlpha=alpha*(.6-i*.2+.2*Math.sin(t*6));ctx.beginPath();ctx.arc(0,-r-10,i*5,-2.4,-.7);ctx.stroke();}ctx.globalAlpha=alpha;break;
    case 'turncoat':{ctx.rotate(e.face||0);ctx.beginPath();ctx.moveTo(r*1.3,0);ctx.lineTo(r*.4,-r*.7);ctx.lineTo(-r,-r*.6);ctx.lineTo(-r,r*.6);ctx.lineTo(r*.4,r*.7);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle=e.shieldFlash>0?'#ffffff':'#ffb84d';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(-r*.8,-r*.75);ctx.lineTo(r*.3,-r*.85);ctx.moveTo(-r*.8,r*.75);ctx.lineTo(r*.3,r*.85);ctx.stroke();ctx.lineWidth=2;break;}
    case 'cadet':ctx.rotate(face);ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(-r*.7,-r*.6);ctx.lineTo(-r*.7,r*.6);ctx.closePath();ctx.fill();ctx.stroke();break;
    case 'linkor':{ctx.rotate(e.ang||0);ctx.fillStyle='#10151f';ctx.beginPath();ctx.moveTo(110,0);ctx.lineTo(70,-38);ctx.lineTo(-110,-34);ctx.lineTo(-120,0);ctx.lineTo(-110,34);ctx.lineTo(70,38);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle='rgba(214,222,232,.35)';ctx.lineWidth=1;for(let i=-4;i<=3;i++){ctx.beginPath();ctx.moveTo(i*24,-30);ctx.lineTo(i*24,30);ctx.stroke();}ctx.fillStyle=col;ctx.fillRect(-12,-12,24,24);break;}
    case 'echoship':case 'echoguard':ctx.globalAlpha=alpha*.45;ctx.rotate(e.type==='echoship'?0:Math.PI);ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(-r*.7,-r*.7);ctx.lineTo(-r*.7,r*.7);ctx.closePath();ctx.stroke();break;
    case 'fpart':{const h=e.host;ctx.rotate(h?h.ang:0);const ro=e.role;if(ro==='nose'){ctx.beginPath();ctx.moveTo(r*1.4,0);ctx.lineTo(-r,-r);ctx.lineTo(-r,r);ctx.closePath();ctx.fill();ctx.stroke();}
      else if(ro==='engL'||ro==='engR'){ctx.fillRect(-r,-r*.6,r*1.6,r*1.2);ctx.strokeRect(-r,-r*.6,r*1.6,r*1.2);if(!icon)glow(-r-4,0,16,'#8fe9ff',.6+.3*Math.sin(t*25));}
      else{ctx.beginPath();ctx.arc(0,0,r*.85,0,TAU);ctx.fill();ctx.stroke();const sd=ro==='batR'?1:-1;ctx.fillStyle=col;for(const o of [-8,0,8])ctx.fillRect(o-1.5,sd>0?4:-r-6,3,r+2);}
      break;}
    case 'flagship':{const b=!icon&&G.sb===e?e:null;ctx.rotate(icon?0:(e.ang||0));const k=icon?.18:1;ctx.scale(k,k);ctx.fillStyle='#0e131c';ctx.strokeStyle=col;ctx.lineWidth=3/k;
      ctx.beginPath();ctx.moveTo(150,0);ctx.lineTo(110,-46);ctx.lineTo(-130,-44);ctx.lineTo(-150,0);ctx.lineTo(-130,44);ctx.lineTo(110,46);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle='rgba(214,222,232,.3)';ctx.lineWidth=1;for(let i=-5;i<=4;i++){ctx.beginPath();ctx.moveTo(i*24,-38);ctx.lineTo(i*24,38);ctx.stroke();}
      const open=b&&b.phase>=3;ctx.fillStyle=open?'#ffffff':'#2a3446';ctx.strokeStyle=open||e.flash>0?'#ffffff':col;ctx.lineWidth=2;ctx.fillRect(-18,-18,36,36);ctx.strokeRect(-18,-18,36,36);glow(0,0,26,open?'#ffffff':'#b8c4d6',open?.8:.3);
      if(b&&(b.inv0>0||b.st==='enter'||b.st==='final')){ctx.strokeStyle=e.domeFlash>0?'#ffffff':'#b8c4d6';ctx.globalAlpha=alpha*.3;ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(0,0,170,64,0,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}break;}
    default:ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();}}
// ===== боссы секторов V–VI =====
function sb74Spawn(kind){ambSting('boss');radioClear();const type=kind==='nurse'?'nurse':'flagship';
  const b=spawnEnemy(type,kind==='nurse'?W/2:-170,kind==='nurse'?H/2:H*.32,{noAffix:true,noLoot:true});sb74Init(b,kind,2.6);
  if(kind==='nurse'){banner('КОРМИЛИЦА · ПОСЛЕДНЯЯ КОЛЫБЕЛЬ','ФАЗА 1 · '+NU_PHASES[0]);const s33=storyFlag('save33');
    radioLine('КОРМИЛИЦА','#ff9fb8',s33==='dead'?'Ты выбрал мёртвых. Как и тот, кто нас сохранил.':s33==='unborn'?'Ты выбрал детей. Тогда послушай колыбельную до конца.':'…ты пахнешь [пустым местом]. Ты пришёл за [кладкой]?…',1.5);}
  else{banner('«ПОСЛЕДНИЙ ДОВОД» · ФЛАГМАН ФЛОТА','ФАЗА 1 · '+FL_PHASES[0]);radioLine('ФЛАГМАН','#b8c4d6','Неопознанный корабль. Назовите себя.',1.5);radioLine('ФЛАГМАН','#b8c4d6','Корабль Стражей. Огонь по готовности.',6);}
  return b;}
function sb74Init(b,kind,enterT){b.hp=b.maxHp=Math.round(EDEF[b.type].hp*sbRank()*cycHp());b.th=[b.maxHp*.67,b.maxHp*.33,b.maxHp*.10];
  Object.assign(b,{sbk:kind,phase:1,st:'enter',timer:enterT,t:0,rot:0,flash:0,open:0,inv0:0,fails:0,choice:null,domeFlash:0,deathT:0,noAffix:true,noLoot:true,docks:null});
  if(kind==='nurse')nuInit(b);else flInit(b);G.sb=b;if(G.noEsc74)b.noEsc=true;}
function sb74Adopt(b){const kind=b.type==='nurse'?'nurse':'flag';if(G.sb&&G.sb!==b&&G.sb.alive){b.alive=false;return false;}sb74Init(b,kind,1);return true;}
function sb74Hurt(e,dmg,src){const b=G.sb;if(!b||!b.alive){if(e.type==='nurse'||e.type==='flagship')return 0;return dmg;}src=src||{};
  if(e.type==='nurse'){if(b.st!=='fight'||b.inv0>0||!nuOpen(b)){sbBlock(e);return 0;}return dmg;}
  if(e.type==='womb'){if(b.st!=='fight'){sbBlock(e);return 0;}const k=src.charged?1:src.blast?.67:src.pulse?1:.02;
    const c0=Math.floor((e.cut||0)*5);e.cut=(e.cut||0)+k;e.flash=.12;sfx('hit');if(e.cut>=2-1e-6)return e.hp+1;if(k>=.3||Math.floor(e.cut*5)>c0)floater(e.x,e.y-e.r-10,'ПУПОВИНА '+Math.round(Math.min(1,e.cut/2)*100)+'%','#ff9fb8');return 0;}
  if(e.type==='flagship'){if(b.st!=='fight'||b.inv0>0){sbBlock(e);return 0;}return dmg*(b.phase>=3?1.5:.35);}
  if(e.type==='fpart'){if(b.st!=='fight'||b.inv0>0||e.spawnT>0){sbBlock(e);return 0;}b.hp-=dmg*.45*(1-(e.secArm||0));b.flash=.07;sbCheckTh(b);return dmg;}
  return dmg;}
function sb74Targetable(e){const b=G.sb;if(!b)return false;
  if(e.type==='nurse')return b.st==='fight'&&nuOpen(b);if(e.type==='womb')return b.st==='fight';if(e.type==='flagship'||e.type==='fpart')return b.st==='fight';return true;}
function sb74Phase(b){ambSting('phase');b.phase++;b.open=0;b.inv0=2;G.eb=G.eb.filter(x=>x.rift);
  G.shock.push({x:b.x,y:b.y,r:20,R:Math.max(W,H),t:0,col:EDEF[b.type].col,slow:true});sfx('bigboom');shake(14);
  const names=b.sbk==='nurse'?NU_PHASES:FL_PHASES;banner(SB_NAMES[b.sbk]+' · ФАЗА '+b.phase,names[b.phase-1]);
  if(b.sbk==='nurse'){b.rings=[];b.cycle=0;b.breath=0;
    if(b.phase===2)radioLine('КОРМИЛИЦА','#ff9fb8','…[схватки]. Не мешай. Это не для тебя…',1);
    if(b.phase===3)radioLine('КОРМИЛИЦА','#ff9fb8','…последний. Его контур — твой. Номер — [следующий]…',1);}
  else{b.bs=null;
    if(b.phase===2)radioLine('АДМИРАЛ КАРР','#b8c4d6','Девять часов. Они били только в двигатели. Почему не в рубку?',1);
    if(b.phase===3)radioLine('АДМИРАЛ КАРР','#b8c4d6','Если ты Страж — ответь хоть раз.',1);}}
function sb74Final(b){b.st='final';b.timer=20;b.open=0;G.eb=G.eb.filter(x=>x.rift);
  if(b.sbk==='nurse'){b.rings=[];b.docks=[{kind:'cut',x:b.cx-140,y:b.cy+b.R0*.5,ch:0},{kind:'keep',x:b.cx+140,y:b.cy+b.R0*.5,ch:0}];
    banner('ПОСЛЕДНИЙ РЕБЁНОК','ПРЕРВАТЬ ИЛИ ВЫНОСИТЬ · 20 С');radioLine('КОРМИЛИЦА','#ff9fb8','…решай. Колыбель на одного. Как всегда.',.5);}
  else{b.bs=null;b.sal=[];b.docks=[{kind:'bridge',x:W/2-150,y:H*.78,ch:0},{kind:'engine',x:W/2+150,y:H*.78,ch:0}];
    banner('ПОСЛЕДНИЙ ВЫСТРЕЛ','ПО РУБКЕ ИЛИ ПО ДВИГАТЕЛЯМ · 20 С');radioLine('АДМИРАЛ КАРР','#b8c4d6','…ты не Страж. Ты похож на них. Но ты тонешь, как мы.',.5);}
  sfx('level');}
function sb74Timeout(b){b.fails++;if(b.fails>=2){sbChoose(b,null);return;}
  b.hp=Math.min(b.maxHp,b.hp+b.maxHp*.2);b.st='fight';b.inv0=1.5;b.docks=null;banner(b.sbk==='nurse'?'КОЛЫБЕЛЬ НЕ ЖДЁТ':'ПРИКАЗ НЕ ОТДАН','ПОВТОР · +20% ПРОЧНОСТИ');sfx('warn');}
function sb74Choose(b,ch){if(b.choice||(b.st!=='final'&&b.st!=='fight'))return;const S=G.save,world=G.mode==='world'&&S;
  if(!ch)ch=b.sbk==='nurse'?(Math.random()<.5?'cut':'keep'):(Math.random()<.5?'bridge':'engine');b.choice=ch;b.docks=null;
  if(ch==='cut'){G.sbLomK=2;G.sbChoiceTxt='Кокон разбит: лом ×2. Следующая копия не родится.';banner('СЛЕДУЮЩАЯ КОПИЯ НЕ РОДИТСЯ','ЛОМ ×2');}
  else if(ch==='keep'){G.sbLomK=.5;G.sbChoiceTxt='Кокон выношен: лом ×0,5. «Младший» летит с вами в секторах V–VI, скин «Нерождённый» в ангаре.';banner('МЛАДШИЙ ВЫЛУПИЛСЯ','ЛОМ ×0,5 · СПУТНИК В СЕКТОРАХ V–VI · СКИН «НЕРОЖДЁННЫЙ»');
    if(world&&!S.ownSkins.includes('unborn'))S.ownSkins.push('unborn');}
  else if(ch==='bridge'){G.sbLomK=2;G.sbChoiceTxt='Рубка пробита: лом ×2. Флот замолчал навсегда.';banner('ПО РУБКЕ','ЛОМ ×2 · ФЛОТ ЗАМОЛЧАЛ');}
  else{G.sbLomK=1;G.sbChoiceTxt='Выбиты двигатели, адмирал жив: перк «Милость» — отступающие враги сдаются от попадания и отдают лом.';banner('ПО ДВИГАТЕЛЯМ','КАК СТРАЖИ · ПЕРК «МИЛОСТЬ»');
    if(world&&S.story){S.story.spared++;S.story.cyc.spared++;}
    toast('ПРОТОКОЛ СТРАЖА · ДОПОЛНЕНИЕ 7','«Протокол „не объяснять“, дополнение 7. Людей не убивать. Людям не объяснять. Копию VØID — останавливать до вспоминания». Подпись: Э. В., бюро «Предел».');}
  if(b.sbk==='flag'&&world&&!S.ownSkins.includes('argument'))S.ownSkins.push('argument');
  sbDeath(b);}
function sb74Hud(b){const k=SB_NAMES[b.sbk];if(b.st==='dying')return k+' · '+(b.sbk==='nurse'?'ЗАСЫПАЕТ':'ТОНЕТ');if(b.st==='final')return k+' · ВЫБОР · '+Math.ceil(b.timer)+' С';if(b.st==='enter')return k;
  if(b.sbk==='nurse'){const al=(b.wombs||[]).filter(w=>w.alive).length;if(b.phase===1&&al)return 'ПУПОВИНЫ · '+al+'/4 · РВИТЕ ЗАРЯДОМ';if(b.phase===2)return b.inhale?'ВДОХ · УЯЗВИМА':'ВЫДОХ · ЖДИТЕ';return k+' · ФАЗА '+b.phase;}
  if(b.bs)return 'БОРТОВОЙ ЗАЛП · '+(b.bs.side>0?'ПРАВЫЙ':'ЛЕВЫЙ')+' БОРТ';if(b.phase<3)return k+' · РУБКА БРОНИРОВАНА';return k+' · РУБКА ОТКРЫТА';}
function sb74Docks(b,dt){const p=G.player;if(!b.docks||p.hp<=0)return false;for(const d of b.docks){if(Math.hypot(p.x-d.x,p.y-d.y)<44){d.ch+=dt;if(d.ch>=.6){sbChoose(b,d.kind);return true;}}else d.ch=0;}return false;}
// --- Кормилица ---
function nuInit(b){b.cx=W/2;b.cy=H/2;b.R0=Math.min(W,H)*.47;b.R=b.R0;b.wombs=[];b.ringT=3;b.rings=[];b.ubT=6;b.embT=5;b.sporeT=4;b.cycle=0;b.breath=0;b.inhale=false;b.wallCd=0;b.x=b.cx;b.y=b.cy;}
function nuOpen(b){if(!b||b.st!=='fight')return false;if(b.phase===1)return !b.wombs.some(w=>w.alive);if(b.phase===2)return !!b.inhale;return true;}
function nuSpawnWombs(b){b.wombs=[];for(let i=0;i<4;i++){const a=Math.PI/4+i*Math.PI/2;const w=spawnEnemy('womb',b.cx+Math.cos(a)*b.R*.78,b.cy+Math.sin(a)*b.R*.78,{noAffix:true,noLoot:true,spawnT:.8,wa:a});w.hp=w.maxHp=1000;b.wombs.push(w);}}
function nuPlace(b){for(const w of b.wombs){if(!w.alive)continue;w.x=b.cx+Math.cos(w.wa)*b.R*.78;w.y=b.cy+Math.sin(w.wa)*b.R*.78;}}
function nuWall(b,dt){const p=G.player;if(!p||p.hp<=0||b.st==='dying')return;b.wallCd-=dt;const dx=p.x-b.cx,dy=p.y-b.cy,d=Math.hypot(dx,dy)||1,lim=b.R-p.r;
  if(d>lim){p.x=b.cx+dx/d*(lim-1);p.y=b.cy+dy/d*(lim-1);p.vx*=.5;p.vy*=.5;if(b.wallCd<=0&&p.dashT<=0&&b.st==='fight'){b.wallCd=.6;damagePlayer(b.phase===2?10:5);hintOnce('nuwall','МЕМБРАНА УТРОБЫ · НЕ КАСАЙТЕСЬ СТЕНЫ','#ff9fb8');}}}
function nuUpdate(b,dt){const p=G.player;if(sbCommon(b,dt))return;sbEscort(b,dt);
  b.x+=(b.cx-b.x)*Math.min(1,dt*2);b.y+=(b.cy-b.y)*Math.min(1,dt*2);
  if(b.phase===2&&b.st==='fight'){b.cycle=(b.cycle+dt)%7;const k=b.cycle<3?Math.sin(Math.PI*b.cycle/3):0;b.R=b.R0*(1-.25*k);}else b.R=b.R0+(b.st==='fight'?12*Math.sin(b.t*TAU/1.2):0);
  nuWall(b,dt);
  if(b.st==='enter'){b.timer-=dt;if(b.timer<=0){b.st='fight';nuSpawnWombs(b);b.fight0=G.t;}return;}
  nuPlace(b);
  if(b.st==='final'){b.timer-=dt;if(sb74Docks(b,dt))return;if(b.timer<=0)sbTimeout(b);return;}
  const hard=sbHard();
  b.ringT-=dt;if(b.ringT<=0&&p.hp>0){b.ringT=(b.phase===1?4.5:b.phase===2?6:4.2)*atkK();b.rings.push({r:b.r+8,t:G.noTele?-.4:-.8,gap:Math.atan2(p.y-b.cy,p.x-b.cx)+rnd(-1.4,1.4),gw:b.phase===3?0:(hard?.6:.8),hit:false});sfx('warn');}
  for(const R_ of b.rings){R_.t+=dt;if(R_.t>0)R_.r+=170*dt;if(!R_.hit&&R_.t>0&&p.hp>0){const dd=Math.hypot(p.x-b.cx,p.y-b.cy);if(Math.abs(dd-R_.r)<9+p.r*.6){const a=Math.atan2(p.y-b.cy,p.x-b.cx);if(!(R_.gw>0&&Math.abs(angDiff(a,R_.gap))<R_.gw/2)){R_.hit=true;damagePlayer(12);}}}}
  b.rings=b.rings.filter(R_=>R_.r<b.R+20);
  if(b.phase===1){b.ubT-=dt;if(b.ubT<=0){b.ubT=7*atkK();if(G.enemies.filter(e=>e.alive&&e.type==='unborn').length<6)for(const w of b.wombs.filter(w=>w.alive).slice(0,2))spawnEnemy('unborn',w.x,w.y,{noAffix:true,spawnT:.3,escort:true});}}
  if(b.phase===2){b.breath=(b.breath+dt)%5;const inh=b.breath<2;if(inh!==b.inhale){b.inhale=inh;if(inh)floater(b.x,b.y-b.r-24,'ВДОХ · УЯЗВИМА','#ffe0ea');}
    b.embT-=dt;if(b.embT<=0){b.embT=6*atkK();if(G.enemies.filter(e=>e.alive&&e.type==='embryo').length<3){const a=rnd(0,TAU);spawnEnemy('embryo',b.cx+Math.cos(a)*b.r*1.5,b.cy+Math.sin(a)*b.r*1.5,{noAffix:true,spawnT:.4,fast:true,escort:true});}}}
  if(b.phase===3){b.sporeT-=dt;if(b.sporeT<=0&&p.hp>0){b.sporeT=4*atkK();x74().spores.push({x:p.x+rnd(-60,60),y:p.y+rnd(-60,60),r:95,t:6});}}}
function sb74WombDied(e){const b=G.sb;if(!b||b.sbk!=='nurse')return;explode(e.x,e.y,'#ff6b8a',30,1.1);sfx('boom');shake(6);x74().milk.push({x:e.x,y:e.y,t:25});
  floater(e.x,e.y-30,'ПУПОВИНА ПОРВАНА · МОЛОКО','#ff9fb8');
  if(!b.wombs.some(w=>w.alive&&w!==e)){banner('ПУПОВИНЫ ПОРВАНЫ','КОРМИЛИЦА ОТКРЫТА');if(G.mc)G.mc.cord74=G.t-(b.fight0||G.t);}}
// --- «Последний довод» ---
const FL_PARTS=[['nose',122,0],['batL',40,-36],['batR',40,36],['engL',-118,-26],['engR',-118,26]];
function flInit(b){b.ang=0;b.wp=0;b.bsT=4;b.bs=null;b.hgT=10;b.salT=4;b.sal=[];b.salQ=0;b.parts=[];b.drift=false;}
function flSpawnParts(b){for(const [role,ox,oy] of FL_PARTS){const q=spawnEnemy('fpart',b.x,b.y,{noAffix:true,noLoot:true,spawnT:.6,role,ox,oy,host:b});q.hp=q.maxHp=Math.round((role==='nose'?1300:900)*sbRank());b.parts.push(q);}flPlace(b);}
function flPlace(b){const c=Math.cos(b.ang),s=Math.sin(b.ang);for(const q of b.parts){if(!q.alive)continue;q.x=b.x+q.ox*c-q.oy*s;q.y=b.y+q.ox*s+q.oy*c;q.vx=q.vy=0;}}
function flRole(b,r){return b.parts.find(q=>q.role===r&&q.alive);}
function flUpdate(b,dt){const p=G.player,easy=(curDiff().rank||0)===0,hard=sbHard();if(sbCommon(b,dt))return;sbEscort(b,dt);
  if(b.st==='enter'){b.timer-=dt;b.x+=(W*.3-b.x)*Math.min(1,dt*.9);b.y+=(H*.32-b.y)*Math.min(1,dt*.9);flPlace(b);if(b.timer<=0){b.st='fight';flSpawnParts(b);}return;}
  if(b.st==='final'){b.timer-=dt;flPlace(b);if(sb74Docks(b,dt))return;if(b.timer<=0)sbTimeout(b);return;}
  b.resp=b.resp||{};for(const [role,ox,oy] of FL_PARTS){if(role==='engL'||role==='engR'||flRole(b,role))continue;b.resp[role]=(b.resp[role]===undefined?25:b.resp[role])-dt;
    if(b.resp[role]<=0){b.resp[role]=undefined;b.parts=b.parts.filter(q=>q.alive);const q=spawnEnemy('fpart',b.x,b.y,{noAffix:true,noLoot:true,spawnT:.8,role,ox,oy,host:b});q.hp=q.maxHp=Math.round((role==='nose'?1300:900)*sbRank()*.5);b.parts.push(q);floater(b.x,b.y-60,role==='nose'?'НОС ЗАЛАТАН':'БАТАРЕЯ ВОССТАНОВЛЕНА','#d6dee8');}}
  const engs=['engL','engR'].filter(r=>flRole(b,r)).length;if(engs<2&&b.phase>=2&&!b.drift){b.drift=true;banner('ФЛАГМАН ПОТЕРЯЛ УПРАВЛЕНИЕ','ЗАЛПЫ МЕТУТ АРЕНУ');}
  if(!b.drift){const WP=[[W*.28,H*.3],[W*.72,H*.3],[W*.72,H*.6],[W*.28,H*.6]],w=WP[b.wp%4],dx=w[0]-b.x,dy=w[1]-b.y;if(Math.hypot(dx,dy)<40)b.wp++;
    b.ang+=clamp(angDiff(Math.atan2(dy,dx),b.ang),-.5*dt,.5*dt);const sp=engs===2?45:engs===1?26:0;b.x+=Math.cos(b.ang)*sp*dt;b.y+=Math.sin(b.ang)*sp*dt;}
  else{b.ang+=.25*dt;b.x+=(W/2-b.x)*dt*.1;b.y+=(H*.45-b.y)*dt*.1;}
  b.x=clamp(b.x,110,W-110);b.y=clamp(b.y,100,H-100);flPlace(b);
  // бортовой залп
  if(!b.bs){b.bsT-=dt;if(b.bsT<=0&&p.hp>0){const s=((p.x-b.x)*(-Math.sin(b.ang))+(p.y-b.y)*Math.cos(b.ang))>0?1:-1;const bat=flRole(b,s>0?'batR':'batL')||flRole(b,s>0?'batL':'batR');
      if(bat){b.bs={side:bat.role==='batR'?1:-1,t:G.noTele?.6:1};sfx('warn');}b.bsT=(b.drift?3.4:6)*atkK();}}
  else{b.bs.t-=dt;if(b.bs.t<=0){const a=b.ang+b.bs.side*Math.PI/2,c=Math.cos(b.ang),s=Math.sin(b.ang);for(const ox of [-80,0,80]){const x=b.x+ox*c-b.bs.side*44*s,y=b.y+ox*s+b.bs.side*44*c;for(let i=-1;i<=1;i++){const q=shootE(x,y,a+i*.18,210,12,'#d6dee8',6);if(q)q.boss=true;}}b.bs=null;sfx('bigboom');shake(6);}}
  // ангар
  if(b.phase>=2&&!easy){b.hgT-=dt;if(b.hgT<=0){b.hgT=10*atkK();if(G.enemies.filter(e=>e.alive&&(e.type==='boarder'||e.type==='fireship')).length<4){spawnEnemy(Math.random()<.5?'boarder':'fireship',b.x,b.y,{noAffix:true,spawnT:.6,escort:true});floater(b.x,b.y-50,'АНГАР','#ffb84d');}}}
  // «Последний довод»: туда, где вы были секунду назад
  if(b.phase===3){b.salT-=dt;if(b.salT<=0&&p.hp>0&&!b.salQ){b.salT=5*atkK();b.salQ=easy?2:3;b.salN=0;banner('«ПОСЛЕДНИЙ ДОВОД»','ЗАЛП БЬЁТ ТУДА, ГДЕ ВЫ БЫЛИ');}
    if(b.salQ>0){b.salN-=dt;if(b.salN<=0){b.salQ--;b.salN=.6;const log=G.posLog.filter(q=>G.t-q.t>=.9&&G.t-q.t<=1.2),q=log.length?log[0]:{x:p.x,y:p.y};b.sal.push({x:q.x,y:q.y,t:1.5,mercy:hard});sfx('warn');}}}
  for(const s of b.sal){s.t-=dt;if(s.t<=0&&!s.done){s.done=true;explode(s.x,s.y,'#ffd0a0',26,1);G.shock.push({x:s.x,y:s.y,r:10,R:70,t:0,col:'#ffd0a0'});sfx('boom');shake(5);
      if(p.hp>0&&Math.hypot(p.x-s.x,p.y-s.y)<70+p.r*.5&&p.dashT<=0){if(s.mercy)mercyHit(25);else damagePlayer(25);}
      for(const e of G.enemies){if(!e.alive||e.sbk||EDEF[e.type].sbp||STATIC.has(e.type))continue;if(Math.hypot(e.x-s.x,e.y-s.y)<70)hurt(e,60,{});}}}
  b.sal=b.sal.filter(s=>s.t>-.3);}
function sb74PartDied(e){const b=G.sb;if(!b||b.sbk!=='flag'||b.st==='dying')return;explode(e.x,e.y,'#d6dee8',30,1.1);sfx('boom');shake(6);
  floater(e.x,e.y-26,e.role==='engL'||e.role==='engR'?'ДВИГАТЕЛЬ ВЫБИТ':e.role==='nose'?'НОС РАЗБИТ':'БАТАРЕЯ ВЫБИТА','#d6dee8');}
// --- общая отрисовка боссов V–VI (после врагов) ---
function sb74Draw(b,t){const p=G.player;
  if(b.sbk==='nurse'){
    // стена утробы
    ctx.fillStyle='rgba(40,6,18,.5)';ctx.beginPath();ctx.rect(-4000,-4000,8000+W,8000+H);ctx.arc(b.cx,b.cy,b.R,0,TAU,true);ctx.fill('evenodd');
    ctx.strokeStyle='#ff6b8a';ctx.globalAlpha=.7;ctx.lineWidth=5;ctx.beginPath();for(let i=0;i<=60;i++){const a=i/60*TAU,rr=b.R+4*Math.sin(a*9+t*3);ctx.lineTo(b.cx+Math.cos(a)*rr,b.cy+Math.sin(a)*rr);}ctx.closePath();ctx.stroke();ctx.globalAlpha=1;
    // пуповины
    for(const w of b.wombs||[]){if(!w.alive)continue;ctx.strokeStyle='#ff7fa0';ctx.globalAlpha=.75;ctx.lineWidth=5+2*Math.sin(t*5+w.wa);ctx.beginPath();ctx.moveTo(b.x,b.y);const mx=(b.x+w.x)/2+Math.cos(w.wa+Math.PI/2)*22*Math.sin(t*2),my=(b.y+w.y)/2+Math.sin(w.wa+Math.PI/2)*22*Math.sin(t*2);ctx.quadraticCurveTo(mx,my,w.x,w.y);ctx.stroke();ctx.globalAlpha=1;
      if(b.st==='fight'&&b.phase===1)worldLabel(w.x,w.y-w.r-16,'ЗАРЯД · РАЗРЫВ · ИМПУЛЬС','#ff9fb8');}
    // кольца песни
    for(const R_ of b.rings||[]){if(R_.t<0){if(G.noTele)continue;ctx.strokeStyle='#ffd0e0';ctx.globalAlpha=.25+.25*Math.sin(t*20);ctx.lineWidth=2;ctx.setLineDash([6,8]);ctx.beginPath();ctx.arc(b.cx,b.cy,b.r+30,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;continue;}
      ctx.strokeStyle='#ffd0e0';ctx.globalAlpha=.85;ctx.lineWidth=6;ctx.beginPath();if(R_.gw>0)ctx.arc(b.cx,b.cy,R_.r,R_.gap+R_.gw/2,R_.gap-R_.gw/2+TAU);else ctx.arc(b.cx,b.cy,R_.r,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
    if(b.phase===2&&b.st==='fight'){ctx.strokeStyle=b.inhale?'#ffffff':'#5a2030';ctx.globalAlpha=.6;ctx.lineWidth=3;ctx.beginPath();ctx.arc(b.x,b.y,b.r+18,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
  }else{
    if(b.bs&&!G.noTele){const a=b.ang+b.bs.side*Math.PI/2,c=Math.cos(b.ang),s=Math.sin(b.ang);ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.35+.4*Math.sin(t*22);ctx.lineWidth=3;ctx.beginPath();
      for(const ox of [-80,0,80]){const x=b.x+ox*c-b.bs.side*44*s,y=b.y+ox*s+b.bs.side*44*c;for(let i=-1;i<=1;i++){ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(a+i*.18)*220,y+Math.sin(a+i*.18)*220);}}ctx.stroke();ctx.globalAlpha=1;}
    for(const s of b.sal||[]){if(s.done)continue;ctx.strokeStyle=s.mercy?'#b8c4d6':'#ffd0a0';ctx.globalAlpha=.5+.4*Math.sin(t*20);ctx.lineWidth=2;ctx.beginPath();ctx.arc(s.x,s.y,70,0,TAU);ctx.stroke();ctx.lineWidth=4;ctx.beginPath();ctx.arc(s.x,s.y,70,-Math.PI/2,-Math.PI/2+TAU*(1-s.t/1.5));ctx.stroke();ctx.globalAlpha=1;}
  }
  if(b.st==='final'&&b.docks){for(const d of b.docks){const red=d.kind==='cut'||d.kind==='bridge',c_=red?'#ff4f6e':d.kind==='keep'?'#ff9fb8':'#9fd8ff';glow(d.x,d.y,46,c_,.5);ctx.strokeStyle=c_;ctx.lineWidth=2;ctx.setLineDash([5,5]);ctx.lineDashOffset=-t*15;ctx.beginPath();ctx.arc(d.x,d.y,34,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;
      if(d.ch>0){ctx.lineWidth=4;ctx.beginPath();ctx.arc(d.x,d.y,40,-Math.PI/2,-Math.PI/2+TAU*d.ch/.6);ctx.stroke();}
      const L={cut:['ПРЕРВАТЬ','ЛОМ ×2'],keep:['ВЫНОСИТЬ','ЛОМ ×0,5 · МЛАДШИЙ'],bridge:['ПО РУБКЕ','ЛОМ ×2'],engine:['ПО ДВИГАТЕЛЯМ','КАК СТРАЖИ · МИЛОСТЬ']}[d.kind];worldLabel(d.x,d.y-48,L[0],c_);worldLabel(d.x,d.y+54,L[1],c_);}
    ctx.strokeStyle='#ffffff';ctx.globalAlpha=.8;ctx.lineWidth=3;ctx.beginPath();ctx.arc(b.x,b.y,b.r+26,-Math.PI/2,-Math.PI/2+TAU*(b.timer/20));ctx.stroke();ctx.globalAlpha=1;}}
function sb74ExtraDraw(t){}
// ===== открытый мир секторов V–VI =====
const W74={gen:false,zones:[],pois:[]};
const W74_JR={j5a:['ЧУЖАЯ МАТЬ · ПЕРЕВОД 3/5','«Мы отдали им имена заранее. Имена живут дольше нас».'],j5b:['ТАЛА ОШ · ПОЛЕВОЙ ДНЕВНИК','«Считала коконы и цивилизации в каталоге Архива. Разница — ровно одна. Одна кладка лишняя. Или один из нас».'],j5c:['СТРАЖ-31 · ЖУРНАЛ ОТКАЗОВ','«Приказ: выжечь колыбель. Выполнено. Причина не запрашивалась. Причина не была бы дана».'],
  j6a:['КУРСАНТ ТЕО · ЗАПИСЬ 2','«Мне 19. Нас учили: Стражи — машины, машины не щадят. Сегодня Страж прошёл в метре от нашей шлюпки и не выстрелил. Я не знаю, кто из нас машина».'],j6b:['АДМИРАЛ И. КАРР · ЛИЧНОЕ','«Они могли уничтожить нас за минуту. Они потратили девять часов, выбивая только двигатели. Я приказал стрелять по ним до конца. Если они не хотят нашей смерти — чего они хотят?»']};
const W74_GLYPH=['…мы [сохранили]…','…мы сохранили [наших]…','…мы сохранили наших [мёртвых]…','…[цена] — наши…','…цена — наши [нерождённые]…'];
function w74S(){const S=G.save;return S.w74||(S.w74={pois:{},glyph:0,zd:{}});}
function w74Gen(){if(W74.gen||!WORLD.sectors[5]||!G.save)return;W74.gen=true;const N=WORLD.nodes;
  const okAt=(x,y,dn,dp)=>w58Far(x,y,N,dn)&&w58Far(x,y,W74.pois,dp)&&w58Far(x,y,W74.zones,dp)&&w58Far(x,y,WORLD.shops,dp)&&inSectors(x,y);
  const ZS=[[4,'ВЫВОДОК','brood'],[4,'ХОР','choir'],[4,'ПАСТУХИ','herd'],[4,'ПОВИТУХИ','midwife'],[5,'ЗВЕНО БЕЗ КОМАНДИРА','wing'],[5,'ПОХОРОННАЯ ПРОЦЕССИЯ','funeral'],[5,'БРАНДЕРНАЯ АТАКА','fireships'],[5,'СПАСАТЕЛЬНАЯ ШЛЮПКА','boat']];
  ZS.forEach(([sec,name,k],i)=>{const R=mulberry(7400+i*37);const q=w58Pt(sec,R,(x,y)=>okAt(x,y,1300,700)&&w58Far(x,y,W74.zones,1700)&&Math.hypot(x-WORLD.hangar.x,y-WORLD.hangar.y)>900&&Math.hypot(x-WORLD.arsenal.x,y-WORLD.arsenal.y)>900&&WORLD.sectors.every(sc=>!sc.bx||Math.hypot(x-sc.bx,y-sc.by)>900),500);const z={x:q.x,y:q.y,req:0,set:[],w58:1,sec,after:0,name,lead:null,reinf:{},idx:1100+i,k74:k,cool:0};W74.zones.push(z);WORLD.zones.push(z);W58.zones.push(z);});
  const P=(sec,id,kind,seed)=>{const R=mulberry(seed);const q=w58Pt(sec,R,(x,y)=>okAt(x,y,600,500),400);W74.pois.push({id,kind,sec,x:q.x,y:q.y});};
  P(4,'j5a','jr',7501);P(4,'j5b','jr',7502);P(4,'j5c','jr',7503);for(let i=0;i<5;i++)P(4,'g'+(i+1),'glyph',7510+i);P(4,'s33','save33',7520);P(5,'j6a','jr',7601);P(5,'j6b','jr',7602);}
function w74ZoneRadio(z){const L={brood:['КОЛЫБЕЛЬ','#ff9fb8','…[кладка] просыпается. Не смотри…'],choir:['КОЛЫБЕЛЬ','#ff9fb8','…слушай. Это не для тебя. Но слушай…'],herd:['КОЛЫБЕЛЬ','#ff9fb8','…[дети] идут к узлу. Им туда нельзя…'],midwife:['СТРАЖ','#ff6b8a','Колыбель подлежит зачистке. Объект 013 — не вмешиваться.'],
    wing:['ФЛОТ','#b8c4d6','Звено 7: ведущий на связи. Ведомые — на связи 0.'],funeral:['СТРАЖ','#ff6b8a','Конвой. Хороним по уставу. Не мешать.'],fireships:['ФЛОТ','#b8c4d6','Брандеры — к цели без опознавания.'],boat:['ФЛОТ','#b8c4d6','Это шлюпка 4. Нас трое. Мы видим вас. Вы — Страж?']}[z.k74];if(L)radioLine(L[0],L[1],L[2],.4);}
function w74Sp(z,t,x,y,o){const e=spawnEnemy(t,x,y,Object.assign({spawnT:.7,zone:z,noAffix:true},o||{}));if(e&&!(o&&o.full)){e.hp*=PATROL_HP_K;e.maxHp=e.hp;}z.n++;return e;}
function w74ZoneSpawn(z){const p=G.player,R=(r)=>[z.x+rnd(-r,r),z.y+rnd(-r,r)];z.t74=0;z.out74=null;z.prov74=0;z.solo=null;z.boat=null;
  switch(z.k74){
    case 'brood':for(let i=0;i<6;i++){const a=i/6*TAU;w74Sp(z,'cocoon',z.x+Math.cos(a)*200,z.y+Math.sin(a)*200);}for(let i=0;i<2;i++)w74Sp(z,'pestun',...R(160));break;
    case 'choir':for(let i=0;i<3;i++){const a=i/3*TAU,e=w74Sp(z,'singer',z.x+Math.cos(a)*160,z.y+Math.sin(a)*160);if(!i){z.solo=e;e.solo=true;}}for(let i=0;i<6;i++)w74Sp(z,'unborn',...R(220));break;
    case 'herd':for(let i=0;i<2;i++)w74Sp(z,'pestun',...R(160));for(let i=0;i<8;i++)w74Sp(z,'unborn',...R(240));break;
    case 'midwife':for(let i=0;i<4;i++){const a=i/4*TAU+.4;w74Sp(z,'cocoon',z.x+Math.cos(a)*230,z.y+Math.sin(a)*230,{hatch0:40});}for(let i=0;i<2;i++)w74Sp(z,'guard',z.x+(i?60:-60),z.y-60,{n74:'midwife'});break;
    case 'wing':{const a0=Math.atan2(p.y-z.y,p.x-z.x);for(let i=0;i<5;i++){const e=w74Sp(z,'autopilot',z.x-Math.cos(a0)*i*40+Math.sin(a0)*(i%2?1:-1)*i*30,z.y-Math.sin(a0)*i*40);if(!i){z.solo=e;e.solo=true;}}break;}
    case 'funeral':{const sc=WORLD.sectors[5].box;z.dest={x:z.x<(sc[0]+sc[2])/2?sc[0]+250:sc[2]-250,y:z.y};for(let i=0;i<2;i++){const e=w74Sp(z,'guard',z.x+(i?50:-50),z.y,{n74:'tow'});e.fo=i?50:-50;}z.wreck={x:z.x,y:z.y+70};break;}
    case 'fireships':for(let i=0;i<4;i++){const a=i/4*TAU;w74Sp(z,'fireship',p.x+Math.cos(a)*520,p.y+Math.sin(a)*520);}break;
    case 'boat':{const sc=WORLD.sectors[5].box;z.boat={x:z.x,y:z.y,hp:300,maxHp:300,alive:true,r:16,tx:clamp(z.x+(z.x<(sc[0]+sc[2])/2?1:-1)*1500,sc[0]+300,sc[2]-300),ty:z.y};G.w74b=z.boat;z.w2=0;
      for(let i=0;i<3;i++)w74Sp(z,'cadet',...R(380),{boatAtk:true});w74Sp(z,'gunner',...R(380),{boatAtk:true});break;}}}
function w74ZoneTick(dt){const p=G.player;for(const z of W74.zones){if(!z.active)continue;z.t74=(z.t74||0)+dt;
    if(z.k74==='choir'&&z.solo&&!z.solo.alive&&!z.broke){z.broke=1;for(const e of G.enemies)if(e.alive&&e.zone===z&&e.type==='singer'){e.alive=false;explode(e.x,e.y,'#ffd0e0',14,.7);}floater(p.x,p.y-40,'СОЛИСТ СНЯТ · ХОР РАСПАЛСЯ','#ffd0e0');}
    if(z.k74==='wing'&&z.solo&&!z.solo.alive&&!z.broke){z.broke=1;const left=G.enemies.filter(e=>e.alive&&e.zone===z);if(left.length===4){for(const e of left)e.rogue=true;floater(p.x,p.y-40,'ВЕДУЩИЙ СБИТ · ЗВЕНО СТРЕЛЯЕТ ДРУГ В ДРУГА','#c9d2de');}}
    if(z.k74==='funeral'&&z.wreck){const g=G.enemies.filter(e=>e.alive&&e.zone===z);if(g.length){const cx=g.reduce((a,e)=>a+e.x,0)/g.length,cy=g.reduce((a,e)=>a+e.y,0)/g.length;z.wreck.x+=(cx-z.wreck.x)*Math.min(1,dt*2);z.wreck.y+=(cy+70-z.wreck.y)*Math.min(1,dt*2);}}
    if(z.k74==='boat'&&z.boat){const B=z.boat;if(B.alive){const near=Math.hypot(p.x-B.x,p.y-B.y)<650;if(near){const dx=B.tx-B.x,dy=B.ty-B.y,d=Math.hypot(dx,dy);if(d>8){B.x+=dx/d*70*dt;B.y+=dy/d*70*dt;}}
        for(const b of G.eb){if(b.life>0&&Math.hypot(b.x-B.x,b.y-B.y)<B.r+4){b.life=0;B.hp-=b.dmg;}}
        if(z.t74>15&&!z.w2){z.w2=1;for(let i=0;i<2;i++)w74Sp(z,'cadet',B.x+rnd(-420,420),B.y+rnd(-420,420),{boatAtk:true});w74Sp(z,'autopilot',B.x+rnd(-420,420),B.y-400);}
        if(B.hp<=0){B.alive=false;z.out74='lost';explode(B.x,B.y,'#7affc9',30,1);floater(B.x,B.y-30,'ШЛЮПКА ПОТЕРЯНА','#ff4f6e');}
        else if(Math.hypot(B.tx-B.x,B.ty-B.y)<30){B.alive=false;z.out74='saved';for(const e of G.enemies)if(e.alive&&e.zone===z){e.alive=false;explode(e.x,e.y,EDEF[e.type].col,6,.4);}floater(B.x,B.y-30,'ШЛЮПКА В БЕЗОПАСНОСТИ','#7affc9');}}}}}
function w74ZoneDone(z){const S=G.save,p=G.player,ws=w74S(),first=!ws.zd[z.k74];ws.zd[z.k74]=1;z.active=false;z.cool=first?900:1200;let v=Math.round((first?10+z.n*3:3)*3),msg='ПАТРУЛЬ РАЗБИТ';
  if(z.k74==='brood'&&z.t74<12){v*=2;msg='ВЫВОДОК РАЗБИТ ЗА 12 С · ЛОМ ×2';}
  if(z.k74==='midwife'&&z.out74==='helped'){v=Math.round(v*.6);msg='ПОВИТУХИ УШЛИ · ВЫ НЕ ВМЕШАЛИСЬ';radioLine('СТРАЖ','#ff6b8a','Объект 013 не вмешался. Зафиксировано.',.4);}
  if(z.k74==='funeral'&&z.out74==='passed'){v=Math.round(v*.6);msg='ПРОЦЕССИЯ ПРОШЛА';if(!ws.pois.funeral){ws.pois.funeral=1;toast('ПРИКАЗ · ХОРОНИТЬ ПО УСТАВУ','«Корпус флагманского звена — к краю сектора. Рубку не вскрывать. Экипаж не тревожить». Стражи хоронят тех, кого не стали убивать.');}}
  if(z.k74==='boat'){if(z.out74==='saved'){v+=60;msg='ШЛЮПКА СПАСЕНА · ТРОЕ ЖИВЫ';if(!ws.pois.boat){ws.pois.boat=1;toast('ШЛЮПКА 4','«Нас трое. Вы не Страж — Стражи бы просто прошли мимо. Спасибо. Мы не знаем, куда теперь лететь, но мы живы».');}}else if(z.out74==='lost'){v=Math.round(v*.4);msg='ШЛЮПКА ПОТЕРЯНА';}G.w74b=null;}
  S.carry+=v;if(first)addPilotXP(25);floater(p.x,p.y-40,msg+' · +'+v+' ЛОМА'+(first?'':' · ПОВТОР'),'#c9d2de');sfx('level');conEvent('patrol');conEvent('patrol');if(G.event==='zone')G.event=null;saveWorld();return true;}
function w74WorldTick(dt){const S=G.save,p=G.player;if(!S||!p)return;w74Gen();const ws=w74S();w74ZoneTick(dt);t74Tick(dt);
  if(p.hp<=0)return;for(const q of W74.pois){if(ws.pois[q.id])continue;const d=Math.hypot(p.x-q.x,p.y-q.y);if(d>(q.kind==='save33'?140:70))continue;
    if(q.kind==='jr'){ws.pois[q.id]=1;const J=W74_JR[q.id];toast(J[0],J[1]+' (+20 ЛОМА)');S.lom+=20;sfx('pick');explode(q.x,q.y,q.sec===4?'#ff9fb8':'#b8c4d6',16,.7);saveWorld();}
    else if(q.kind==='glyph'){ws.pois[q.id]=1;ws.glyph=(ws.glyph||0)+1;S.lom+=15;sfx('pick');explode(q.x,q.y,'#ff9fb8',14,.7);
      if(ws.glyph>=5){toast('ПЕРЕВОД ЗАВЕРШЁН','«Мы сохранили наших мёртвых. Цена — наши нерождённые. Мы не жалеем. Мы просто считаем». Глиф найден: скин «Глиф» в ангаре.');if(!S.ownSkins.includes('glyph'))S.ownSkins.push('glyph');banner('СКИН НАЙДЕН · «ГЛИФ»','ПЯТЬ ГЛИФОВ · АНГАР «ЗЕРКАЛО»');}
      else toast('ГЛИФ '+ws.glyph+'/5',W74_GLYPH[ws.glyph-1]+' (+15 ЛОМА)');saveWorld();}
    else if(q.kind==='save33'&&!ws.save33){for(const [k,ox] of [['dead',-60],['unborn',60]]){if(Math.hypot(p.x-(q.x+ox),p.y-q.y)<40){ws.save33=k;ws.pois[q.id]=1;if(S.story)S.story.save33=k;
          banner(k==='dead'?'СОХРАНЕНА ЗАПИСЬ МЁРТВОГО ВИДА':'СОХРАНЁН ЗАРОДЫШ','ПИТАНИЯ ХВАТИЛО НА ОДНОГО · КОРМИЛИЦА ЗАПОМНИТ');sfx('level');saveWorld();break;}}}}}
function w74Draw(t){if(!W74.gen)return;const ws=w74S();
  for(const q of W74.pois){if(ws.pois[q.id]&&q.kind!=='save33')continue;if(!inView(q.x,q.y,160))continue;
    if(q.kind==='jr'){glow(q.x,q.y,30,q.sec===4?'#ff9fb8':'#b8c4d6',.5+.3*Math.sin(t*3));ctx.save();ctx.translate(q.x,q.y);ctx.rotate(Math.PI/4);ctx.strokeStyle=q.sec===4?'#ff9fb8':'#d6dee8';ctx.lineWidth=2;ctx.strokeRect(-8,-8,16,16);ctx.restore();worldLabel(q.x,q.y-24,'ЗАПИСЬ','#c9d2de');}
    else if(q.kind==='glyph'){glow(q.x,q.y,34,'#ff9fb8',.5+.3*Math.sin(t*2));ctx.save();ctx.translate(q.x,q.y);ctx.rotate(t*.5);ctx.strokeStyle='#ffd0e0';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,10,0,4.5);ctx.moveTo(-10,0);ctx.lineTo(10,0);ctx.moveTo(0,-14);ctx.lineTo(0,6);ctx.stroke();ctx.restore();worldLabel(q.x,q.y-26,'ГЛИФ','#ff9fb8');}
    else if(q.kind==='save33'){for(const [k,ox] of [['dead',-60],['unborn',60]]){const chosen=ws.save33===k,dim=ws.save33&&!chosen;const x=q.x+ox,y=q.y;ctx.globalAlpha=dim?.35:1;glow(x,y,30,k==='dead'?'#9fb0c4':'#ff9fb8',chosen?.8:.4);ctx.fillStyle='#0b0f18';ctx.strokeStyle=k==='dead'?'#c9d2de':'#ff9fb8';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y,12,20,0,0,TAU);ctx.fill();ctx.stroke();ctx.globalAlpha=1;
        worldLabel(x,y-32,k==='dead'?'ЗАПИСЬ МЁРТВОГО ВИДА':'ЗАРОДЫШ',k==='dead'?'#c9d2de':'#ff9fb8');}if(!ws.save33)worldLabel(q.x,q.y+40,'ПИТАНИЯ ХВАТИТ НА ОДНОГО','#9fb0c4');}}
  for(const z of W74.zones){if(!z.active)continue;if(z.k74==='funeral'&&z.wreck&&inView(z.wreck.x,z.wreck.y,80)){const w=z.wreck;ctx.save();ctx.translate(w.x,w.y);ctx.fillStyle='#10151f';ctx.strokeStyle='#6b7688';ctx.lineWidth=2;ctx.fillRect(-50,-14,100,28);ctx.strokeRect(-50,-14,100,28);ctx.restore();
      for(const e of G.enemies)if(e.alive&&e.zone===z){ctx.strokeStyle='#ffb84d';ctx.globalAlpha=.4;ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(w.x,w.y);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}}
    if(z.k74==='boat'&&z.boat&&z.boat.alive){const B=z.boat;ctx.save();ctx.translate(B.x,B.y);ctx.rotate(Math.atan2(B.ty-B.y,B.tx-B.x));glow(0,0,24,'#7affc9',.5);ctx.fillStyle='#0b1a14';ctx.strokeStyle='#7affc9';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(16,0);ctx.lineTo(-10,-9);ctx.lineTo(-10,9);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();
      ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(B.x-22,B.y+20,44,4);ctx.fillStyle='#7affc9';ctx.fillRect(B.x-22,B.y+20,44*B.hp/B.maxHp,4);worldLabel(B.x,B.y-26,'ШЛЮПКА 4 · ДЕРЖИТЕСЬ РЯДОМ','#7affc9');
      ctx.strokeStyle='#7affc9';ctx.globalAlpha=.3;ctx.setLineDash([6,8]);ctx.beginPath();ctx.moveTo(B.x,B.y);ctx.lineTo(B.tx,B.ty);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}}}
function w74DrawTop(t){d74Draw(t);}
function w74MapAdd(add,lod,S){w74Gen();if(!W74.gen)return;const ws=w74S();
  for(const q of W74.pois){if(ws.pois[q.id]||!revealedAt(q.x,q.y))continue;add(q.kind==='jr'?'j74':q.kind==='glyph'?'glyph74':'save74',q.x,q.y,{sec:q.sec},lod===2?{t:q.kind==='jr'?'ЗАПИСЬ':q.kind==='glyph'?'ГЛИФ':'ДВА КОНТЕЙНЕРА',p:6,c:q.sec===4?'#ff9fb8':'#b8c4d6'}:null);}}
function w74MapIcon(g,kind,o,t){switch(kind){
    case 'j74':g.strokeStyle=o.sec===4?'#ff9fb8':'#b8c4d6';g.rotate(Math.PI/4);g.strokeRect(-4,-4,8,8);return true;
    case 'glyph74':g.strokeStyle='#ff9fb8';g.beginPath();g.arc(0,0,5,0,4.5);g.moveTo(-5,0);g.lineTo(5,0);g.stroke();return true;
    case 'save74':g.strokeStyle='#ff9fb8';g.beginPath();g.ellipse(-4,0,3,5,0,0,TAU);g.stroke();g.strokeStyle='#c9d2de';g.beginPath();g.ellipse(4,0,3,5,0,0,TAU);g.stroke();return true;}
  return false;}
// --- скины ---
Object.assign(SKINS,{
  unborn:{name:'Нерождённый',col:'#ffc2d4',bul:'#ffe0ea',trail:'#ff9fb8',d:'Полупрозрачный корпус с розовым ядром. VØID-014б: номер следующего цикла.',unlock:0,find:'СЕКТОР V · ВЫНОСИТЬ'},
  glyph:{name:'Глиф',col:'#ff9fb8',bul:'#ffd0e0',trail:'#ff6b8a',d:'Корпус, расписанный чужими буквами. Пять слов, одна фраза.',unlock:0,find:'СЕКТОР V · ПЯТЬ ГЛИФОВ'},
  argument:{name:'Довод',col:'#d6dee8',bul:'#ffffff',trail:'#b8c4d6',d:'Тёмная броня флагмана с белой полосой. Последний аргумент флота.',unlock:0,find:'СЕКТОР VI · ФЛАГМАН'}});
STORY_HULL.unborn='VØID-014б. Выношен Кормилицей. Номер следующего цикла — его.';STORY_HULL.glyph='Корпус без номера. Пять чужих слов на броне: «мы сохранили наших мёртвых».';STORY_HULL.argument='Броня флагмана «Последний довод». Рубка цела — так решили вы.';
HULL_NUM.unborn='014б';HULL_NUM.glyph='∅';HULL_NUM.argument='Ф-1';
function w74DrawSkin(id,t,sp,o,A,fl,edge){
  if(id==='unborn'){glow(0,0,14,'#ff9fb8',.6);ctx.fillStyle='rgba(255,194,212,.28)';ctx.strokeStyle=edge;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(19,0);ctx.quadraticCurveTo(4,-12,-12,-9);ctx.quadraticCurveTo(-6,0,-12,9);ctx.quadraticCurveTo(4,12,19,0);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.fillStyle='#ff6b8a';ctx.beginPath();ctx.arc(2,0,3+.6*Math.sin(t*6),0,TAU);ctx.fill();return true;}
  if(id==='glyph'){ctx.fillStyle='#1a0812';ctx.strokeStyle=edge;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(18,0);ctx.lineTo(-12,-11);ctx.lineTo(-6,0);ctx.lineTo(-12,11);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.strokeStyle='#ffd0e0';ctx.lineWidth=1;ctx.beginPath();ctx.arc(-2,-4,3,0,4.5);ctx.moveTo(-6,3);ctx.lineTo(2,3);ctx.moveTo(6,-2);ctx.lineTo(6,3);ctx.stroke();return true;}
  if(id==='argument'){ctx.fillStyle='#0e131c';ctx.strokeStyle=edge;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(20,0);ctx.lineTo(10,-9);ctx.lineTo(-14,-9);ctx.lineTo(-18,0);ctx.lineTo(-14,9);ctx.lineTo(10,9);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.fillStyle='#ffffff';ctx.fillRect(-12,-1.5,26,3);glow(-18,0,fl,'#8fe9ff',.6);return true;}
  return false;}
