# 1.5.11 α — ARCH·71: этап 3 (изоляция игровой случайности от визуала). Применяется поверх m70.
# M71_GROUPS="1,2,…" — сборка только с частью групп (для пошаговой проверки); по умолчанию все пять.
import sys,os
P='@@KIT@@/home/void.html'
D='@@KIT@@/'
sys.path.insert(0,D);import m71_pairs as M
s=open(P,encoding='utf8').read()
J=open(D+'m71_journal1511.txt',encoding='utf8').read().strip()
G=set(int(x) for x in os.environ.get('M71_GROUPS','1,2,3,4,5').split(','))
base=M.pairs(J)[:5];sites=[(t[2],M.new(t)) for t in M.SITES if t[0] in G]
for a,b in base+sites:
    n=s.count(a)
    if n!=1:print('m71 FAIL',n,a[:100]);sys.exit(1)
    s=s.replace(a,b)
open(P,'w',encoding='utf8').write(s);print('m71 ok · групп',sorted(G),'· правок',len(sites))
