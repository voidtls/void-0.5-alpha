# 1.2.0 α «Без права на ремонт»: приёмка по мета-промпту. Каждый тест падает на сборке 1.1.1 (версия 20).
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
NEAR=lambda a,b,eps=.02:abs(a-b)<=eps
# вход на пост через мир, как игрок (релизный режим без альфа-флага)
POSTIN="""T.fresh();const S=G.save;S.cleared=10;for(let m=1;m<=10;m++)S.medals[m]={clear:1};S.gate=true;S.diff=o.diff||'mid';saveWorld();
 enterWorldAt(POST_HATCH.x,POST_HATCH.y+60);for(let i=0;i<30;i++)worldUpdate(1/60);updateWorldHUD();const card=G.card&&G.card.kind;
 cardAct('main');if(G.state==='intro')startMission();let n=0;while(G.state==='levelup'&&n++<40)choose(0);const P=G.post,p=G.player;"""
RUN="""const step=(sec,fn)=>{for(let i=0;i<60*sec;i++){if(G.state==='levelup'){choose(0);continue;}if(G.state!=='play')break;if(o.god)p.hp=Math.max(p.hp,G.st.maxHp*.8);if(fn)fn(i);update(1/60);}};
 const go=(x,y,sec)=>step(sec,()=>{p.x=x;p.y=y;p.vx=p.vy=0;});
 const clearAct=()=>{const P=G.post;for(const pn of P.panels)go(pn.x,pn.y,1.6);for(const c of P.cells)go(c.x,c.y,.6);for(const g of P.gens)go(g.x,g.y,6.6);if(P.core)go(P.core.x,P.core.y,4.4);if(P.trig)go(P.trig.x,P.trig.y,1.6);go(P.door.x,P.door.y,1.2);step(.2);};"""

# ---------- «Эхо» убрано ----------
@test('H01')
async def h01(b):
    # нет контракта «Эхо», медалей у миссии три, кнопки и тега ЭХО на карточке нет, R не запускает режим, нигде нет «режима «Эхо»»
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();const ids=CTPL.map(t=>t.id);const mc=medalCount({clear:1,clean:1,master:1,echo:1});
      const n=WORLD.nodes[2],p=G.player;p.x=n.x;p.y=n.y+100;p.vx=p.vy=0;for(let i=0;i<40;i++)worldUpdate(1/60);updateWorldHUD();const card=$('#wcard').innerHTML;
      window.dispatchEvent(new KeyboardEvent('keydown',{code:'KeyR',key:'r'}));const st=G.state,echo=!!G.echo;
      const all=document.documentElement.innerHTML;return {cEcho:ids.includes('c_echo'),mc,cardEcho:/ЭХО|Эхо/.test(card),st,echo,mode:/режим[а-я]* «Эхо»/.test(all)};}""")
    rec('H01 «Эхо» убрано: контракта нет, медалей три, на карточке и по R режима нет, в текстах не упоминается',
        not r['cEcho'] and r['mc']==3 and not r['cardEcho'] and r['st']=='world' and not r['echo'] and not r['mode'],{**r,'errs':P.errs[:2]})

@test('H02')
async def h02(b):
    # старое сохранение: медали «эхо» и контракт «Эхо» вычищаются, контрактов снова три; миссия 2 переименована
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();const S=G.save;S.medals[3]={clear:1,clean:1,echo:1};S.medals[4]={clear:1,echo:1};S.contracts.init=1;
      S.contracts.list=[{tid:'c_echo',n:1,p:0}];saveWorld();startWorld(false);const S2=G.save;
      return {m3:Object.keys(S2.medals[3]),m4:Object.keys(S2.medals[4]),con:S2.contracts.list.map(c=>c.tid),name:MISSIONS[1].name};}""")
    rec('H02 миграция: медали «эхо» и контракт «Эхо» удалены, контрактов три; миссия 2 — «Отзвук выстрелов»',
        'echo' not in r['m3'] and 'echo' not in r['m4'] and 'clean' in r['m3'] and 'c_echo' not in r['con'] and len(r['con'])==3 and r['name']=='Отзвук выстрелов',{**r,'errs':P.errs[:2]})

# ---------- без лечения в миссиях ----------
@test('H03')
async def h03(b):
    # вход в миссию — с полной прочностью; в бою ремкомплект не чинит, карточка «всё на пределе» не обещает ремонт
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();G.player.hp=20;T.go(3);const p=G.player,max=G.st.maxHp,hp0=p.hp;G.waveHold=999;
      p.hp=max*.5;G.pick.push({k:'rep',x:p.x,y:p.y,vx:0,vy:0,r:10,t:0,life:10});for(let i=0;i<60*6;i++){G.enemies=[];G.eb=[];update(1/60);}
      for(const k in MODS)G.mods[k]=MODS[k].max;openLevelUp();const card=$('#cards').textContent;
      return {hp0,max,hp1:p.hp,half:max*.5,card:card.slice(0,80),allowed:healAllowed()};}""")
    rec('H03 миссия: вход целым, ремкомплект не чинит, карточка «ЗАРЯД», healAllowed()=false',
        r['hp0']==r['max'] and r['hp1']<=r['half']+.01 and 'РЕМОНТ' not in r['card'] and 'ЗАРЯД' in r['card'] and r['allowed'] is False,{**r,'errs':P.errs[:2]})

@test('H04')
async def h04(b):
    # ремкомплекты не выпадают ни в одной миссии, даже из стражей на лёгкой сложности
    P=await newpage(b)
    r=await P.js("""()=>{const out={};for(const m of [2,6,8,12]){T.fresh();T.openAll();G.save.diff='easy';T.go(m);G.waveHold=999;let n=0;
      for(let i=0;i<300;i++){const e=spawnEnemy('guard',W/2+rnd(-100,100),H/2,{noAffix:true});e.spawnT=0;kill(e);}out[m]=G.pick.filter(k=>k.k==='rep').length;G.pick=[];}return out;}""")
    rec('H04 ремкомплекты в миссиях не выпадают (300 стражей в миссиях 2, 6, 8, 12)',all(v==0 for v in r.values()),{'reps':r,'errs':P.errs[:2]})

@test('H05')
async def h05(b):
    # модуль маяка «Укрытие»: в кольце корпус не растёт, а щит возвращается
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();T.go(7);const bc=G.bc,p=G.player;G.waveHold=999;bc.mods.repair=1;p.hp=G.st.maxHp*.5;const h0=p.hp;p.shieldUp=false;p.shieldT=0;
      for(let i=0;i<60*10;i++){p.x=bc.x+20;p.y=bc.y;p.vx=p.vy=0;G.enemies=[];G.eb=[];if(G.state==='levelup'){choose(0);continue;}update(1/60);}
      return {h0,h1:p.hp,sh:p.shieldUp,name:BMODS&&BMODS.repair?BMODS.repair.name:null};}""")
    rec('H05 модуль маяка «Укрытие»: за 10 с в кольце корпус не чинится, щит восстанавливается',
        r['h1']<=r['h0']+.01 and r['sh'] and r['name']=='Укрытие',{**r,'errs':P.errs[:2]})

@test('H06')
async def h06(b):
    # бывшие источники ремонта дают другое: молоко — темп, «Позывной» — щит, сегмент финального босса — оглушение
    P=await newpage(b)
    r=await P.js("""()=>{const src=[...document.scripts].map(s=>s.text).join('\\n');return {milk:src.includes("'МОЛОКО · ТЕМП ВЫШЕ'"),cs:src.includes("'ПОЗЫВНОЙ · ЩИТ'"),seg:src.includes("'/4 СНЯТ · ОН ОГЛУШЁН'"),
      oldSeg:src.includes("'/4 СНЯТ · КОРПУС +'"),oldMilk:src.includes("' · МОЛОКО · ТЕМП +20%'"),oldCs:src.includes("' КОРПУСА',C85.voidc")};}""")
    rec('H06 молоко → темп, «Позывной» → щит, сегмент финала → оглушение; старых ремонтов в коде нет',
        r['milk'] and r['cs'] and r['seg'] and not r['oldSeg'] and not r['oldMilk'] and not r['oldCs'],r)

@test('H07')
async def h07(b):
    # вне миссий ремонт остаётся: сектор (перк, мастерская) и Бесконечность
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();const a=healAllowed();const m0=G.mode;G.mode='endless';G.world=false;const e=healAllowed();G.mode=m0;G.world=true;T.go(4);const m=healAllowed();return {sector:a,endless:e,mission:m};}""")
    rec('H07 ремонт разрешён в секторе и в Бесконечности, запрещён в миссии',r['sector'] and r['endless'] and r['mission'] is False,{**r,'errs':P.errs[:2]})

# ---------- прибавки 6 и 8–10 ----------
@test('H08')
async def h08(b):
    # миссия 6 (средняя): темп атак ×1,25 и прочность ×1,25 поверх сложности; в брифинге тег УСИЛЕНА; у 5 и 7 — нет
    P=await newpage(b)
    r=await P.js("""()=>{const out={};for(const m of [5,6,7]){T.fresh();T.openAll();G.save.diff='mid';enterNode(m);const tag=$('#inThreat').innerHTML.includes('УСИЛЕНА');startMission();let n=0;while(G.state==='levelup'&&n++<40)choose(0);update(1/60);
      const e=spawnEnemy('guard',W/2,H/2,{noAffix:true}),h=e.maxHp;const k=MISSION_K[m];delete MISSION_K[m];const e2=spawnEnemy('guard',W/2,H/2,{noAffix:true}),h2=e2.maxHp;if(k)MISSION_K[m]=k;
      out[m]={tag,atk:+(atkK()/G.atkK).toFixed(3),hp:+(h/h2).toFixed(3),diff:G.diff,base:+atkK().toFixed(3)};}return out;}""")
    ok=r['6']['tag'] and NEAR(r['6']['atk'],1.25) and NEAR(r['6']['hp'],1.25) and r['6']['diff']=='mid' and all(not r[k]['tag'] and NEAR(r[k]['atk'],1) and NEAR(r[k]['hp'],1) for k in ('5','7'))
    rec('H08 миссия 6: темп атак и прочность ×1,25 поверх средней сложности, тег УСИЛЕНА; миссии 5 и 7 без прибавки',ok,{**r,'errs':P.errs[:2]})

@test('H09')
async def h09(b):
    # миссии 8–10 (хардкор): скорость, урон по кораблю и прочность ×1,25 поверх множителей сложности
    P=await newpage(b)
    r=await P.js("""()=>{const out={};for(const m of [7,8,9,10]){T.fresh();T.openAll();G.save.diff='hard';T.go(m);G.waveHold=999;update(1/60);const D=curDiff(),p=G.player;
      const e=spawnEnemy('scout',W/2,H/2,{noAffix:true}),h=e.maxHp;const k=MISSION_K[m];delete MISSION_K[m];const e2=spawnEnemy('scout',W/2,H/2,{noAffix:true}),h2=e2.maxHp;if(k)MISSION_K[m]=k;
      p.shieldUp=false;p.inv=0;p.dashT=0;G.insp80=0;const hp0=p.hp;damagePlayer(10);const loss=hp0-p.hp;
      out[m]={spd:+(G.eSpd/(D.spd||1)).toFixed(3),hp:+(h/h2).toFixed(3),dmg:+(loss/(10*(D.dmg||1))).toFixed(3),diff:G.diff};}return out;}""")
    ok=all(NEAR(r[k]['spd'],1.25) and NEAR(r[k]['hp'],1.25) and NEAR(r[k]['dmg'],1.25) and r[k]['diff']=='hard' for k in ('8','9','10')) and NEAR(r['7']['spd'],1) and NEAR(r['7']['dmg'],1)
    rec('H09 миссии 8–10 на хардкоре: скорость, урон и прочность врагов ×1,25 сверх сложности; миссия 7 без прибавки',ok,{**r,'errs':P.errs[:2]})

# ---------- сектор I ----------
@test('H10')
async def h10(b):
    # у каждой миссии 1–5 своя механика среды; вне сектора I её нет
    P=await newpage(b)
    r=await P.js("""()=>{const out={};for(const m of [1,2,3,4,5,7]){T.fresh();T.openAll();T.go(m);const S=G.s1;
      out[m]=S?{b:S.buoys.length,pl:S.plates.length,big:G.rocks.filter(r=>r.alive&&r.s1big).length,flow:!!S.flow,cl:S.clouds.length,fl:S.flares.length,tag:(MISSIONS[m-1].mech||[]).length}:null;}return out;}""")
    ok=r['1'] and r['1']['b']==3 and r['2']['pl']==3 and r['3']['big']==4 and r['4']['flow'] and r['5']['cl']==3 and r['5']['fl']==2 and r['7'] is None
    rec('H10 сектор I: буи (1), плиты (2), глыбы (3), течение (4), тёмные облака с ракетами (5); в миссии 7 механик нет',ok,{**r,'errs':P.errs[:2]})

@test('H11')
async def h11(b):
    # миссия 1: зажжённый буй метит врагов в радиусе, по меченым урон ×1,25
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();T.go(1);G.waveHold=999;G.enemies=[];const B=G.s1.buoys[0],p=G.player;
      const e=spawnEnemy('guard',B.x+150,B.y,{noAffix:true});e.spawnT=0;const f=spawnEnemy('guard',clamp(B.x+600,30,W-30),clamp(B.y+350,30,H-30),{noAffix:true});f.spawnT=0;
      for(let i=0;i<60;i++){p.x=B.x+20;p.y=B.y;p.vx=p.vy=0;e.x=B.x+150;e.y=B.y;e.vx=e.vy=0;update(1/60);}
      const mk=e.s1mark>G.t,fm=f.s1mark>G.t;e.shieldDown=9;f.shieldDown=9;const a0=e.hp;hurt(e,10,{});const a=a0-e.hp;const b0=f.hp;hurt(f,10,{});const bb=b0-f.hp;return {lit:B.lit>0,mk,fm,ratio:+(a/bb).toFixed(3)};}""")
    rec('H11 буй: метка на врагах в 300, не дальше; урон по меченым ×1,25',r['lit'] and r['mk'] and not r['fm'] and NEAR(r['ratio'],1.25),{**r,'errs':P.errs[:2]})

@test('H12')
async def h12(b):
    # миссия 2: плита гасит вражеские снаряды; рывок сквозь плиту разворачивает снаряды рядом во врагов
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();T.go(2);G.waveHold=999;G.enemies=[];const pl=G.s1.plates[0],p=G.player;pl.vr=0;pl.vx=pl.vy=0;
      const nx=-Math.sin(pl.a),ny=Math.cos(pl.a);G.eb=[{x:pl.x+nx*30,y:pl.y+ny*30,vx:-nx*200,vy:-ny*200,r:5,life:5,dmg:10}];p.x=pl.x+nx*300;p.y=pl.y+ny*300;
      for(let i=0;i<20;i++)update(1/60);const blocked=G.eb.filter(q=>q.life>0).length===0;
      const t=spawnEnemy('gunner',clamp(pl.x+nx*-350,30,W-30),clamp(pl.y+ny*-350,30,H-30),{noAffix:true});t.spawnT=0;pl.cd=0;
      G.eb=[{x:pl.x+nx*80,y:pl.y+ny*80,vx:0,vy:0,r:5,life:5,dmg:10},{x:pl.x-nx*90,y:pl.y-ny*90,vx:0,vy:0,r:5,life:5,dmg:10}];G.pb=[];
      p.x=pl.x;p.y=pl.y;p.dashT=.2;update(1/60);const refl=G.pb.filter(q=>q.refl).length;return {blocked,refl,left:G.eb.length};}""")
    rec('H12 плита: гасит снаряды; рывок сквозь неё превращает 2 снаряда рядом в выстрелы игрока',r['blocked'] and r['refl']==2,{**r,'errs':P.errs[:2]})

@test('H13')
async def h13(b):
    # миссия 3: таран, влетевший в глыбу, оглушён 2 с и получает двойной урон; глыбу не разбить
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();T.go(3);G.waveHold=999;G.enemies=[];const R=G.rocks.find(r=>r.alive&&r.s1big);R.vx=R.vy=0;
      const e=spawnEnemy('rammer',R.x-R.r-16,R.y,{noAffix:true});e.spawnT=0;e.st='charge';e.vx=300;e.vy=0;e.timer=1;G.player.x=R.x+400;G.player.y=R.y;
      for(let i=0;i<6&&e.st==='charge';i++)update(1/60);const st=e.st,dz=e.s1dz>G.t;const h0=e.hp;hurt(e,10,{});const d=h0-e.hp;
      for(let i=0;i<60;i++)update(1/60);return {st,dz,d,rock:R.alive&&R.hp>=1e8,stun:G.mc.s1stun||0};}""")
    rec('H13 глыба: таран оглушён, урон по нему ×2, счётчик мастерства растёт; глыба неразрушима',r['st']=='rest' and r['dz'] and NEAR(r['d'],20,.5) and r['rock'] and r['stun']>=1,{**r,'errs':P.errs[:2]})

@test('H14')
async def h14(b):
    # Страж: фаза 1 — связи делают пилоны неуязвимыми, рывок рвёт связь; фаза 2 — кольцо из 8 глыб; фаза 3 — два облака и спираль мин
    P=await newpage(b)
    r=await P.js("""()=>{T.fresh();T.openAll();T.go(6);G.waves=[];G.waveIdx=0;spawnBoss();const b=G.boss,p=G.player,S=G.s1;
      for(let i=0;i<60*5;i++){p.hp=G.st.maxHp;p.inv=1;if(G.state==='levelup'){choose(0);continue;}update(1/60);}
      const links=S.links.length,L=S.links[0];let inv=null,cut=null;if(L){const h0=L.a.hp;hurt(L.a,999,{});inv=L.a.alive&&L.a.hp===h0;
        p.x=(L.a.x+L.b.x)/2;p.y=(L.a.y+L.b.y)/2;p.dashT=.2;update(1/60);cut=L.cut;}
      b.st='fight';b.hp=b.th[0];phaseShift(b);for(let i=0;i<30;i++){p.inv=1;update(1/60);}const orb=G.rocks.filter(r=>r.alive&&r.s1orb).length;
      b.hp=b.th[1];phaseShift(b);let mines=0;for(let i=0;i<60*5;i++){p.hp=G.st.maxHp;p.inv=1;if(G.state==='levelup'){choose(0);continue;}b.over=0;update(1/60);mines=Math.max(mines,G.enemies.filter(e=>e.alive&&e.type==='mine').length);}
      return {links,inv,cut,orb,ph:b.phase,clouds:S.clouds.length,mines,orbAfter:G.rocks.filter(r=>r.alive&&r.s1orb).length};}""")
    ok=r['links']>=2 and r['inv'] and r['cut'] and r['orb']==8 and r['ph']==3 and r['clouds']==2 and r['mines']>=6 and r['orbAfter']==0
    rec('H14 Страж: связи пилонов и рывок-разрыв; пояс из 8 глыб; фаза 3 — 2 облака и спираль из 6 мин',ok,{**r,'errs':P.errs[:2]})

# ---------- пост «Изморозь» ----------
@test('H15')
async def h15(b):
    # после миссии 10 сектор III закрыт до поста; старое сохранение с пройденной 10 — проход открыт сразу
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{T.fresh();const S=G.save;S.cleared=10;for(let m=1;m<=10;m++)S.medals[m]={clear:1};S.gate=true;saveWorld();
      const a={sec3:secSeen(2),avail:postAvail(),gate:postGate(),v120:!!S.v120};
      const S1=G.save;delete S1.v120;delete S1.post;saveWorld();startWorld(false);const c={sec3:secSeen(2),open3:G.save.post&&G.save.post.open3};
      T.fresh();const S2=G.save;S2.cleared=9;for(let m=1;m<=9;m++)S2.medals[m]={clear:1};saveWorld();const d={avail:postAvail()};return {a,c,d};}""")
    ok=r['a']['sec3'] is False and r['a']['avail'] and not r['a']['gate'] and r['c']['sec3'] and r['c']['open3'] and r['d']['avail'] is False
    rec('H15 ворота: после 10 миссий сектор III закрыт, пост доступен; старое сохранение — проход открыт; до 10 поста нет',ok,{**r,'errs':P.errs[:2]})

@test('H16')
async def h16(b):
    # карточка поста ведёт в особую миссию: 4 отсека, стены, тьма; лечения нет
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""const M=MISSIONS[G.m-1];return {card,st:G.state,post:!!P,special:!!(M&&M.post),walls:P&&P.walls.length,acts:POST_ACTS.length,heal:healAllowed(),name:M&&M.name,mech:M&&M.mech};}""",{'diff':'mid'})
    rec('H16 пост: карточка «post», миссия особая, 4 отсека со стенами, ремонта нет',r['card']=='post' and r['st']=='play' and r['post'] and r['special'] and r['walls']>=3 and r['acts']==5 and r['heal'] is False,{**r,'errs':P.errs[:2]})

@test('H17')
async def h17(b):
    # лёд: на ледяной полосе корабль скользит дольше; холод вне тепла обрастает льдом и замораживает
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""postLoadAct(1,p.hp);const I=P.ice[0];const cx=(I.x0+I.x1)/2,cy=(I.y0+I.y1)/2;
      const glide=(x,y)=>{p.x=x;p.y=y;p.vx=300;p.vy=0;G.frozen=0;G.ice=0;for(let i=0;i<20;i++){p.hp=G.st.maxHp;update(1/60);}return Math.hypot(p.vx,p.vy);};
      const lamp=P.lamps[0];const vIce=glide(cx,cy);const W0=P.walls[0];let vDry=glide(lamp.x,lamp.y);
      postLoadAct(1,p.hp);let fz=0,iceMax=0;const sx=(I.x0+I.x1)/2,sy=I.y0+40;for(let i=0;i<60*16;i++){p.x=sx;p.y=sy;p.vx=p.vy=0;p.hp=G.st.maxHp;if(G.state==='levelup'){choose(0);continue;}update(1/60);iceMax=Math.max(iceMax,G.ice);if(G.frozen>0)fz++;}
      return {vIce:Math.round(vIce),vDry:Math.round(vDry),iceMax,frozenFrames:fz,freezes:P.freezes};}""",{'diff':'mid'})
    rec('H17 лёд: скольжение (скорость держится дольше, чем на сухом); холод даёт 3 слоя льда и заморозку',r['vIce']>r['vDry']*1.3 and r['iceMax']>=2 and r['freezes']>=1 and r['frozenFrames']>0,{**r,'errs':P.errs[:2]})

@test('H18')
async def h18(b):
    # Наблюдатель: телеграф ≥0,6 с перед броском; удар по стоящему в темноте; импульс рядом отгоняет
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""postLoadAct(3,p.hp);const O=P.O;const [x,y]=postXY(.3,.12);let tele=null,strike=null,hit=false;const hp0=p.hp;
      O.st='lurk';O.x=x+240;O.y=y;O.cd=0;O.oa=0;p.shieldUp=false;
      for(let i=0;i<60*4;i++){p.x=x;p.y=y;p.vx=p.vy=0;p.inv=0;p.shieldUp=false;G.enemies=[];G.eb=[];if(G.state==='levelup'){choose(0);continue;}update(1/60);
        if(O.st==='tele'&&tele===null)tele=G.t;if(O.st==='strike'&&strike===null)strike=G.t;if(p.hp<hp0){hit=true;break;}}
      O.st='lurk';O.x=p.x+200;O.y=p.y;O.cd=5;p.en=100;tryPulse();const rep=O.st;
      return {tw:tele!==null&&strike!==null?+(strike-tele).toFixed(2):null,hit,rep,lit:postLit(x,y,10)};}""",{'diff':'mid'})
    rec('H18 Наблюдатель: телеграф ≥0,6 с, бросок попадает по стоящему во тьме, импульс отгоняет',r['tw'] is not None and r['tw']>=.6 and r['hit'] and r['rep']=='flee' and not r['lit'],{**r,'errs':P.errs[:2]})

@test('H19')
async def h19(b):
    # прохождение (1.2.1): без экрана итогов — корабль выходит из шлюза прямо в сектор III; лом, курс на миссию 11, итоги сообщением, журнал
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+RUN+"""const lom0=G.save.lom;for(let act=0;act<POST_ACTS.length&&G.post;act++){const P=G.post;for(const w of P.wrecks)go(w.x,w.y,.3);clearAct();}
      const q=G.player;return {st:G.state,done:!$('#sDone').hidden,post:G.save.post,sec3:secSeen(2),lom:G.save.lom-lom0,skin:G.save.ownSkins.includes('izmo'),sec:sectorIdx(q.x,q.y),d:Math.round(Math.hypot(q.x-POST_EXIT.x,q.y-POST_EXIT.y))};}""",{'diff':'easy','god':True})
    await P.pg.wait_for_timeout(3600)
    r2=await P.js("()=>{return {st:G.state,course:G.course&&G.course.label,toast:$('#toast').hidden?'':$('#toast').textContent,jr:(()=>{try{openMap('jr');}catch(e){}const h=document.body.innerHTML.includes('СТОРОЖЕВИК «ИЗМОРОЗЬ» · ВАХТА 1');try{closeMap();}catch(e){}return h;})(),inv:T.inv()};}")
    ok=r['st']=='world' and not r['done'] and r['post']['done']==1 and r['sec3'] and r['sec']==2 and r['d']<200 and r['lom']>=180*.5 and r2['course']=='МИССИЯ 11' and 'СТОРОЖЕВИК ПРОЙДЕН' in r2['toast'] and r2['inv']=='ok'
    rec('H19 сторожевик пройден: сразу в сектор III у выходного шлюза, без экрана итогов; лом, курс на миссию 11, итоги сообщением',ok,{**r,**r2,'errs':P.errs[:2]})

@test('H20')
async def h20(b):
    # гибель на посту: на лёгкой и средней — точка возврата в начале отсека с ≥40% корпуса; на хардкоре до ядра — провал
    P=await newpage(b,alpha=False)
    out={}
    for d in ['mid','hard']:
        out[d]=await P.js("""(o)=>{"""+POSTIN+"""postLoadAct(3,p.hp);p.shieldUp=false;p.inv=0;p.dashT=0;p.hp=1;damagePlayer(50);
          for(let i=0;i<60*4&&G.state==='play';i++)update(1/60);return {st:G.state,act:G.post?G.post.act:null,deaths:G.post?G.post.deaths:null,hp:+(p.hp/G.st.maxHp).toFixed(2)};}""",{'diff':d})
    ok=out['mid']['st']=='play' and out['mid']['act']==3 and out['mid']['deaths']==1 and out['mid']['hp']>=.4 and out['hard']['st']!='play'
    rec('H20 точка возврата на средней (≥40% корпуса), на хардкоре до ядра — провал',ok,{**out,'errs':P.errs[:2]})

@test('H21')
async def h21(b):
    # «ЭФФЕКТЫ: МЕНЬШЕ» отключает затемнение-скример; скримеров не больше двух за проход
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""document.documentElement.classList.add('lessfx');postScare(2);const a=P.blackout;document.documentElement.classList.remove('lessfx');
      P.events={};P.scDone={};P.scares=0;postScare(2);const bl=P.blackout;P.events={};postScare(1);P.events={};postScare(1);return {less:a,full:bl,scares:P.scares};}""",{'diff':'mid'})
    rec('H21 при «меньше эффектов» затемнения нет; повтор скримера не срабатывает',r['less']==0 and r['full']>0 and r['scares']<=2,{**r,'errs':P.errs[:2]})

@test('H22')
async def h22(b):
    # телефон в книжной: отсеки поворачиваются, все объекты внутри экрана и не в стенах, отрисовка без ошибок
    P=await newpage(b,vw=390,vh=844,touch=True,alpha=False)
    r=await P.js("""(o)=>{setInput('touch');"""+POSTIN+"""const bad=[];for(let a=0;a<POST_ACTS.length;a++){postLoadAct(a,p.hp);const pts=[...P.panels,...P.cells,...P.gens,...(P.core?[P.core]:[]),P.door,{x:p.x,y:p.y}];
        for(const q of pts){if(q.x<0||q.x>W||q.y<0||q.y>H||postInWall(q.x,q.y))bad.push([a,Math.round(q.x),Math.round(q.y)]);}
        for(let i=0;i<60;i++){if(G.state==='levelup'){choose(0);continue;}update(1/60);}render(performance.now());}return {bad,W,H};}""",{'diff':'mid'})
    rec('H22 телефон (книжная): раскладка всех 4 отсеков внутри экрана, без объектов в стенах, без ошибок',not r['bad'] and r['H']>r['W'] and not P.errs,{**r,'errs':P.errs[:2]})

@test('H23')
async def h23(b):
    # версия 1.2.2 α; в хронике 1.2.0, 1.2.1 и 1.2.2; «Что нового» — о перестроенном сторожевике
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{toMenu();const v=$('#verTag').textContent;window.__devUI=true;cxTab='log';openCodex('menu');const log=$('#cxBody').textContent;window.__devUI=false;toMenu();
      const src=[...document.scripts].map(s=>s.text).join('');return {v,ver:VER_TAG,log:log.includes('1.2.2 α')&&log.includes('Поверка')&&log.includes('Сторожевик')&&log.includes('Без права на ремонт'),news:src.includes('своя музыка — «Пустота-12»')};}""")
    rec('H23 версия 1.2.2 α, хроника 1.2.0–1.2.2, «Что нового»',r['v']=='1.2.5 α' and r['ver']=='1.2.5 α' and r['log'] and r['news'],{**r,'errs':P.errs[:2]})

# ---------- 1.2.1 «Сторожевик» ----------
@test('H24')
async def h24(b):
    # корабль — у границы II–III, выше узла 10 и далеко от Бездны; шлюз не в зоне врагов; на карте есть; туман пишет, что пройти
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{T.fresh();const S=G.save;S.cleared=10;for(let m=1;m<=10;m++)S.medals[m]={clear:1};S.gate=true;saveWorld();
      const n10=WORLD.nodes[9],ab=WORLD.abyss,zd=Math.min(...WORLD.zones.map(z=>Math.hypot(z.x-POST_HATCH.x,z.y-POST_HATCH.y)));const items=[];w58MapAdd((k,x,y,o,l)=>items.push(k),2,S);
      return {sec:sectorIdx(POST_W.x,POST_W.y),hsec:sectorIdx(POST_HATCH.x,POST_HATCH.y),border:Math.round(10000-POST_W.x),above:Math.round(n10.y-POST_W.y),abyss:Math.round(Math.hypot(ab.x-POST_W.x,ab.y-POST_W.y)),zone:Math.round(zd),map:items.includes('post'),fog:fogHint(2),exit:sectorIdx(POST_EXIT.x,POST_EXIT.y)};}""")
    ok=r['sec']==1 and r['hsec']==1 and 0<r['border']<700 and r['above']>900 and r['abyss']>1800 and r['zone']>500 and r['map'] and 'СТОРОЖЕВИК' in r['fog'] and r['exit']==2
    rec('H24 сторожевик у границы II–III выше узла 10, далеко от Бездны, шлюз вне зоны врагов; на карте; выход — в секторе III',ok,{**r,'errs':P.errs[:2]})

@test('H25')
async def h25(b):
    # брифинг без жанровой плашки: нет тега ХОРРОР и надписи «ОСОБАЯ МИССИЯ»
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{T.fresh();const S=G.save;S.cleared=10;for(let m=1;m<=10;m++)S.medals[m]={clear:1};S.gate=true;saveWorld();enterWorldAt(POST_HATCH.x,POST_HATCH.y+60);for(let i=0;i<30;i++)worldUpdate(1/60);
      cardAct('main');return {st:G.state,th:$('#inThreat').textContent,sec:$('#inSector').textContent,name:$('#inName')?$('#inName').textContent:''};}""")
    rec('H25 вход: брифинг без плашки «ХОРРОР» и «ОСОБАЯ МИССИЯ»',r['st']=='intro' and 'ХОРРОР' not in r['th'] and 'ОСОБАЯ' not in r['sec'],{**r,'errs':P.errs[:2]})

@test('H26')
async def h26(b):
    # фонарь: переборка отбрасывает тень — за стеной Наблюдателя не видно; на виду он замирает, через ~0,6 с отступает
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""postLoadAct(1,p.hp);const [x,y]=postXY(.5,.46);p.x=x;p.y=y;const behind=postXY(.5,.14),open=postXY(.5,.33);const aim=Math.atan2(behind[1]-y,behind[0]-x);P.aim=aim;P.fl=1;P.flTarget=1;P.flT=99;P.flk=0;
      const sB=postSees(...behind),sO=postSees(...open);
      const O=P.O;O.st='lurk';O.cd=99;O.x=open[0];O.y=open[1];O.seen=0;const x0=O.x,y0=O.y;let moved=0,st=[];for(let i=0;i<60;i++){p.x=x;p.y=y;p.vx=p.vy=0;P.fl=1;P.flTarget=1;P.flT=99;P.flk=0;P.figT=99;P.strT=99;P.aim=aim;update(1/60);if(O.st==='lurk')moved=Math.max(moved,Math.hypot(O.x-x0,O.y-y0));st.push(O.st);}
      return {sB,sO,moved:Math.round(moved),fled:st.includes('flee'),firstFlee:st.indexOf('flee')};}""",{'diff':'mid'})
    ok=r['sB'] is False and r['sO'] is True and r['moved']<2 and r['fled'] and r['firstFlee']>=30
    rec('H26 тени от переборок; под лучом Наблюдатель замирает и через 0,5–1 с отступает',ok,{**r,'errs':P.errs[:2]})

@test('H27')
async def h27(b):
    # побег: ледяной фронт идёт от реактора к шлюзу, внутри него холод сильнее; аварийная переборка оставляет щель, пока корабль не прошёл
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""postLoadAct(4,p.hp);const c=P.core;for(let i=0;i<60*5;i++){p.x=c.x;p.y=c.y;p.vx=p.vy=0;p.hp=G.st.maxHp;update(1/60);}
      const f0=P.front;const [fx,fy]=postXY(.97,.5);for(let i=0;i<60*3;i++){p.x=fx;p.y=fy;p.vx=p.vy=0;p.hp=G.st.maxHp;G.frozen=0;update(1/60);}const f1=P.front,inF=P.inFront;
      const [mx,my]=postXY(.4,.5);for(let i=0;i<60*40;i++){p.x=mx;p.y=my;p.vx=p.vy=0;p.hp=G.st.maxHp;G.frozen=0;G.ice=0;P.cold=0;update(1/60);if(!G.post)break;}
      const E=P.edoor,vert=E.r.y1-E.r.y0>=E.r.x1-E.r.x0,gap=vert?(E.wb.y0-E.wa.y1):(E.wb.x0-E.wa.x1);const shut0=E.shut;
      const [ox,oy]=postXY(.12,.5);for(let i=0;i<60*14&&!E.shut;i++){p.x=ox;p.y=oy;p.vx=p.vy=0;p.hp=G.st.maxHp;update(1/60);}
      return {esc:P.escape>0,f0:+f0.toFixed(2),f1:+f1.toFixed(2),inF,gap:Math.round(gap),shipD:Math.round(p.r*2),shut0,shut:E.shut,klaxon:P.klT>0};}""",{'diff':'mid'})
    ok=r['esc'] and r['f1']<r['f0'] and r['inF'] and r['gap']>=r['shipD']+20 and not r['shut0'] and r['shut']
    rec('H27 побег: фронт наступает и накрывает; переборка держит щель шире корабля, пока он не прошёл, потом захлопывается',ok,{**r,'errs':P.errs[:2]})

@test('H28')
async def h28(b):
    # режиссёр: перед скримером — тишина (гул приглушён); стук после двух щитков; капсула разбивается и выпускает тень
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""const out={};for(const pn of P.panels.slice(0,2)){for(let i=0;i<100;i++){p.x=pn.x;p.y=pn.y;p.vx=p.vy=0;p.hp=G.st.maxHp;update(1/60);}}
      out.pend=!!P.pend;let duck=0;for(let i=0;i<60*2;i++){p.hp=G.st.maxHp;update(1/60);duck=Math.max(duck,P.duck);}out.duck=+duck.toFixed(2);out.knock=!!P.scDone.sc0;out.scrawl=(P.jolt||0)>0;
      postLoadAct(1,p.hp);const pd=P.pods.find(q=>q.scare);let sh=false;const sp0=spawnEnemy;spawnEnemy=function(t,x,y,o){const e=sp0(t,x,y,o);if(t==='shade'&&Math.hypot(x-pd.x,y-pd.y)<40)sh=true;return e;};for(let i=0;i<60*2;i++){p.x=pd.x+60;p.y=pd.y+60;p.vx=p.vy=0;p.hp=G.st.maxHp;update(1/60);}spawnEnemy=sp0;
      out.pod=pd.broken;out.shade=sh;out.scares=P.scares;return out;}""",{'diff':'mid'})
    ok=r['duck']>.5 and r['knock'] and r['scrawl'] and r['pod'] and r['shade'] and r['scares']==2
    rec('H28 тишина перед ударом; стук изнутри стены после двух щитков; капсула криосна разбивается и выпускает тень',ok,{**r,'errs':P.errs[:2]})

@test('H29')
async def h29(b):
    # фонарь сбоит: за минуту есть провалы света; рядом с Наблюдателем — чаще; при «меньше эффектов» свет не падает ниже 0,55
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""postLoadAct(1,p.hp);const [x,y]=postXY(.08,.4);const run=(near)=>{let dips=0,low=1,prev=1;for(let i=0;i<60*60;i++){p.x=x;p.y=y;p.vx=p.vy=0;p.hp=G.st.maxHp;G.frozen=0;G.ice=0;P.cold=0;
        if(near){P.O.st='lurk';P.O.x=x+200;P.O.y=y+200;P.O.cd=99;}else{P.O.st='off';P.O.cd=99;}update(1/60);low=Math.min(low,P.fl);if(prev>=.6&&P.fl<.6)dips++;prev=P.fl;}return {dips,low:+low.toFixed(2)};};
      const far=run(false),near=run(true);document.documentElement.classList.add('lessfx');const less=run(true);document.documentElement.classList.remove('lessfx');return {far,near,less};}""",{'diff':'mid'})
    ok=r['far']['dips']>=3 and r['near']['dips']>r['far']['dips'] and r['less']['low']>=.5
    rec('H29 фонарь сбоит, рядом с Наблюдателем — чаще; при «меньше эффектов» не гаснет',ok,{**r,'errs':P.errs[:2]})

@test('H30')
async def h30(b):
    # кадр палубы: пол темнее 12% яркости вне света, в луче фонаря — светлее; без ошибок на всех палубах на ПК и телефоне
    out={}
    for tag,vw,vh,t in [('pc',1280,760,False),('pp',390,844,True)]:
        P=await newpage(b,vw=vw,vh=vh,touch=t,alpha=False)
        if t:await P.js("()=>{setInput('touch');}")
        out[tag]=await P.js("""(o)=>{"""+POSTIN+"""const res=[];for(let a=0;a<POST_ACTS.length;a++){postLoadAct(a,p.hp);for(let i=0;i<90;i++){p.vx=p.vy=0;p.hp=G.st.maxHp;if(G.state==='levelup'){choose(0);continue;}update(1/60);}P.fl=1;P.flTarget=1;P.flT=99;P.flk=0;P.O.st='off';P.blackout=0;P.fade=0;render(performance.now());
          const c=cv.getContext('2d'),T_=c.getTransform();const px=(x,y)=>{const X=Math.round(T_.a*x+T_.e),Y=Math.round(T_.d*y+T_.f);const d=c.getImageData(clamp(X,0,cv.width-1),clamp(Y,0,cv.height-1),1,1).data;return (d[0]+d[1]+d[2])/3/255;};
          const a_=P.aim,R=postConeR()*.4,lit=px(p.x+Math.cos(a_)*R,p.y+Math.sin(a_)*R);let dark=1;for(const [u,v] of [[.3,.1],[.6,.9],[.15,.9],[.9,.3],[.5,.5],[.75,.65]]){const [x,y]=postXY(u,v);if(!postInWall(x,y))dark=Math.min(dark,px(x,y));}res.push([+lit.toFixed(3),+dark.toFixed(3)]);}return res;}""",{'diff':'mid'})
        out[tag+'_err']=P.errs[:2]
    ok=all(d<.12 for k in ('pc','pp') for _,d in out[k]) and sum(1 for k in ('pc','pp') for l,d in out[k] if l>d)>=6 and not out['pc_err'] and not out['pp_err']
    rec('H30 тьма: вне света пол почти чёрный, в луче — светлее; 4 палубы на ПК и телефоне без ошибок',ok,out)


# ---------- 1.2.2 «Поверка» ----------
NAVJS="""const out=[];"""+"\nfor(let a=0;a<POST_ACTS.length;a++){postLoadAct(a,p.hp);const A=POST_ACTS[a];const C=8,gw=Math.ceil(W/C),gh=Math.ceil(H/C),R=p.r+3;\n  const free=(x,y)=>{if(x<R||y<R||x>W-R||y>H-R)return false;for(const w of P.walls){if(w.x1-w.x0<1||w.y1-w.y0<1)continue;const cx=clamp(x,w.x0,w.x1),cy=clamp(y,w.y0,w.y1);if(Math.hypot(x-cx,y-cy)<R)return false;}return true;};\n  const seen=new Uint8Array(gw*gh);const sx=Math.round(p.x/C),sy=Math.round(p.y/C);const q=[[sx,sy]];seen[sy*gw+sx]=1;let minGap=1e9;\n  while(q.length){const [x,y]=q.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=gw||ny>=gh||seen[ny*gw+nx])continue;if(!free(nx*C,ny*C))continue;seen[ny*gw+nx]=1;q.push([nx,ny]);}}\n  const reach=(o)=>{const gx=Math.round(o.x/C),gy=Math.round(o.y/C);for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++){const i=(gy+dy)*gw+(gx+dx);if(i>=0&&i<seen.length&&seen[i])return true;}return false;};\n  const tg=[...P.panels.map(o=>['panel',o]),...P.cells.map(o=>['cell',o]),...P.gens.map(o=>['gen',o]),...(P.core?[['core',P.core]]:[]),['door',P.door],...(P.trig?[['trig',P.trig]]:[]),...P.wrecks.map(o=>['wreck',o])];\n  const bad=tg.filter(([k,o])=>!reach(o)).map(([k,o])=>k+'@'+Math.round(o.x)+','+Math.round(o.y));\n  out.push({a,key:A.key,bad,cells:seen.reduce((s,v)=>s+v,0)});}\nreturn out;\n"
@test('H31')
async def h31(b):
    # левел-дизайн: пять палуб (с повтором криопалубы); со старта достижимы все цели, дверь, записи — на 4 формах экрана
    out={}
    for tag,vw,vh,t in [('pc',1280,760,False),('wide',1600,700,False),('pp',390,844,True),('pl',844,390,True)]:
        P=await newpage(b,vw=vw,vh=vh,touch=t,alpha=False)
        if t:await P.js("()=>{setInput('touch');}")
        out[tag]=await P.js("""(o)=>{"""+POSTIN+NAVJS+"""}""",{'diff':'mid'})
    keys=[x['key'] for x in out['pc']] if isinstance(out['pc'],list) else []
    ok=keys==['lock','cryo','loop','eng','core'] and all(isinstance(v,list) and all(not a['bad'] for a in v) for v in out.values())
    rec('H31 пять палуб (шлюз, криопалуба, её повтор, машинное, реактор); всё достижимо кораблём на ПК, широком, книжной и альбомной',ok,{k:[(a['key'],a['bad']) for a in v] if isinstance(v,list) else v for k,v in out.items()})

@test('H32')
async def h32(b):
    # дешёвые надписи убраны: ни «кровавых» надписей на стенах, ни вспышки «ЭТО НЕ ТВОЙ ГОЛОС»; эфир — ровная автоматика
    P=await newpage(b,alpha=False)
    r=await P.js("""()=>{const src=[...document.scripts].map(s=>s.text).join('');const bad=['НЕ ОТВЕЧАЙ ЕМУ','ОБЕРНИСЬ','МЫ НЕ УМЕРЛИ','ЭТО НЕ ТВОЙ ГОЛОС','ОНО НЕ ЛЮБИТ СВЕТ','ТЫ ТОЖЕ VØID-013'].filter(t=>src.includes("'"+t)||src.includes(t+"'"));
      return {bad,scrawls:POST_ACTS.some(A=>A.scrawls&&A.scrawls.length),auto:RADIO['Х'].l.some(q=>q.t.includes('Без происшествий')),roster:POST_ACTS.some(A=>A.roster)};}""")
    rec('H32 без надписей-«кровью» и вспышки «ЭТО НЕ ТВОЙ ГОЛОС»; эфир — будничная автоматика, судовая роль у шлюза',not r['bad'] and not r['scrawls'] and r['auto'] and r['roster'],{**r,'errs':P.errs[:2]})

@test('H33')
async def h33(b):
    # неизвестные: за минуту на криопалубе появляются несколько раз, каждый — не дольше 1,2 с, со сбоем; вреда не наносят
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""postLoadAct(1,p.hp);const [x,y]=postXY(.5,.4);const seen=[];const f0=postFig;postFig=function(k,fx,fy,d){seen.push([k,+d.toFixed(2)]);return f0.apply(this,arguments);};
      const hp0=G.st.maxHp;p.hp=hp0;let gl=0;for(let i=0;i<60*60;i++){p.x=x;p.y=y;p.vx=p.vy=0;p.inv=1;G.enemies=[];G.eb=[];P.O.st='off';P.O.cd=99;G.frozen=0;G.ice=0;P.cold=0;update(1/60);gl=Math.max(gl,P.glitch);}postFig=f0;
      return {n:seen.length,kinds:[...new Set(seen.map(q=>q[0]))],maxD:Math.max(0,...seen.map(q=>q[1])),gl:+gl.toFixed(2),hp:p.hp===hp0};}""",{'diff':'mid'})
    rec('H33 неизвестные появляются 3+ раз в минуту, не дольше 1,2 с, со сбоем картинки и без урона',r['n']>=3 and r['maxD']<=1.2 and r['gl']>=.25 and r['hp'],{**r,'errs':P.errs[:2]})

@test('H34')
async def h34(b):
    # резкие мерцания: в машинном — серии вспышек с тёмными кадрами; при «меньше эффектов» их нет
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""postLoadAct(3,p.hp);const run=()=>{let n=0,dark=0,was=false;for(let i=0;i<60*70;i++){p.vx=p.vy=0;p.hp=G.st.maxHp;p.inv=1;G.enemies=[];P.O.st='off';P.O.cd=99;G.frozen=0;G.ice=0;P.cold=0;update(1/60);if(P.strobe&&!was)n++;was=!!P.strobe;if(P.strobe&&P.strobe.dark)dark++;}return {n,dark};};
      const a=run();document.documentElement.classList.add('lessfx');P.strobe=null;P.strT=1;const b=run();document.documentElement.classList.remove('lessfx');return {full:a,less:b};}""",{'diff':'mid'})
    rec('H34 резкие мерцания сериями в машинном; при «меньше эффектов» — нет',r['full']['n']>=2 and r['full']['dark']>0 and r['less']['n']==0,{**r,'errs':P.errs[:2]})

@test('H35')
async def h35(b):
    # помехи края карты: на двух последних палубах — слабые (0 < I < 0,4), на первых трёх — нет
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""const res=[];const d0=drawRiftFx;for(let a=0;a<POST_ACTS.length;a++){postLoadAct(a,p.hp);for(let i=0;i<20;i++){p.hp=G.st.maxHp;update(1/60);}P.glitch=0;P.figs=[];P.strobe=null;update(1/60);P.glitch=0;P.figs=[];
        let I=null;drawRiftFx=function(v,t){I=v;};render(performance.now());drawRiftFx=d0;res.push([POST_ACTS[a].key,I===null?0:+I.toFixed(2)]);}return res;}""",{'diff':'mid'})
    m=dict(r) if isinstance(r,list) else {}
    ok=m.get('lock')==0 and m.get('cryo')==0 and m.get('loop')==0 and 0<m.get('eng',0)<.4 and 0<m.get('core',0)<.4
    rec('H35 помехи края карты только на машинном и реакторе, слабые',ok,{'r':r,'errs':P.errs[:2]})

@test('H36')
async def h36(b):
    # повтор криопалубы: те же стены, почти весь свет погас, капсулы открыты, тишина; поверка в темноте открывает дверь
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""postLoadAct(1,p.hp);const w1=JSON.stringify(P.walls.map(w=>[w.x0,w.y0,w.x1,w.y1].map(Math.round)));postLoadAct(2,p.hp);const w2=JSON.stringify(P.walls.map(w=>[w.x0,w.y0,w.x1,w.y1].map(Math.round)));
      for(let i=0;i<90;i++){p.hp=G.st.maxHp;update(1/60);}const before={duck:+P.duck.toFixed(2),door:P.door.open,lamps:P.lamps.filter(l=>l.on).length,open:P.pods.every(q=>q.broken),key:POST_ACTS[P.act].key,name:POST_ACTS[P.act].name};
      let row=false;for(let i=0;i<60*3;i++){p.x=P.trig.x;p.y=P.trig.y;p.vx=p.vy=0;p.hp=G.st.maxHp;update(1/60);if(P.figs.some(f=>f.kind==='row'))row=true;}
      return {same:w1===w2,before,row,door:P.door.open};}""",{'diff':'mid'})
    bf=r['before'];ok=r['same'] and bf['key']=='loop' and bf['name']=='КРИОПАЛУБА' and bf['duck']>=.99 and not bf['door'] and bf['lamps']<=1 and bf['open'] and r['row'] and r['door']
    rec('H36 повтор палубы: те же стены, тьма, открытые капсулы, тишина; строй из тринадцати → дверь открывается',ok,{**r,'errs':P.errs[:2]})

@test('H37')
async def h37(b):
    # скафандры в шлюзе поворачиваются к вам, только когда вы не смотрите; один исчезает, когда вы прошли коридор
    P=await newpage(b,alpha=False)
    r=await P.js("""(o)=>{"""+POSTIN+"""const q=P.suits[2];const lookAt=(x,y)=>{P.aim=Math.atan2(y-p.y,x-p.x);P.fl=1;P.flTarget=1;P.flT=99;P.flk=0;};
      const [x0,y0]=postXY(.08,.5);p.x=x0;p.y=y0;const f0=q.f;for(let i=0;i<30;i++){p.x=x0;p.y=y0;lookAt(q.x,q.y);update(1/60);}const fSeen=q.f;
      for(let i=0;i<30;i++){p.x=x0;p.y=y0;P.aim=Math.atan2(y0-q.y,x0-q.x);P.fl=1;update(1/60);}const fUnseen=q.f,want=Math.atan2(y0-q.y,x0-q.x);
      const [x1,y1]=postXY(.62,.5);for(let i=0;i<60;i++){p.x=x1;p.y=y1;P.aim=0;update(1/60);}const gone=P.suits.filter(s=>s.gone).length;
      return {n:P.suits.length,still:Math.abs(fSeen-f0)<.01,turned:Math.abs(Math.atan2(Math.sin(fUnseen-want),Math.cos(fUnseen-want)))<.05&&Math.abs(fUnseen-f0)>.1,gone};}""",{'diff':'mid'})
    rec('H37 скафандры: под лучом неподвижны, без взгляда — повёрнуты к вам; после коридора одного нет',r['n']>=10 and r['still'] and r['turned'] and r['gone']==1,{**r,'errs':P.errs[:2]})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q160.json'))
