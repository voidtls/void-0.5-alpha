set -e
cd @@KIT@@
bash build151.sh >/dev/null
python3 mapply.py @@KIT@@/home/void_b151.html @@KIT@@/home/void_b156.html 72 73 74 75 76
node --check @@KIT@@/home/void_b156.html.js && echo BUILD_OK
