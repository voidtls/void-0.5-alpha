# 1.4.5 α «Верстак»: режим разработчика. DV01–DV07, DV09, DV10, DV12–DV16, DV18 падают на v39 (1.4.2); DV08, DV11, DV17 — страховка.
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
INIT='window.__devUI=true;'
W8="const w8=ms=>new Promise(r=>setTimeout(r,ms));"
SB=W8+"toMenu();openDev();await w8(150);DEVW.enter();await w8(400);$('#toast').hidden=true;const p=G.player;"
TK="const tick=(s)=>{for(let i=0;i<Math.round(s*60);i++){if(G.state==='world')worldUpdate(1/60);else if(G.state==='play')update(1/60);}};"

async def dpage(b,w=1280,h=800,touch=False):
    return await newpage(b,w,h,alpha=False,touch=touch,init=INIT)

@test('DV01')
async def dv01(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+TK+"const hints=[];const _h=hintOnce;hintOnce=function(k,t){hints.push(k+':'+t);return _h.apply(this,arguments);};"
        "p.x=38500;p.y=13200;p.px=p.x;p.py=p.y;p.vx=0;p.vy=0;camSnap();KEYS.KeyS=true;tick(2.5);KEYS.KeyS=false;const y=Math.round(p.y);"
        "const deny=typeof zeroJumpDeny110==='function'?zeroJumpDeny110({x:38500,y:16000}):'none';return {y,deny,open:zeroOpen110(),hints:hints.filter(h=>/ПРОЙДИТЕ|МИГ/.test(h))}}")
    rec('DV01 песочница: ворота XII открыты — корабль пролетает к боссу 50, прыжок в XII разрешён, «ПРОЙДИТЕ «МИГ»» не появляется',r['y']>13560 and r['deny'] is False and r['open'] and not r['hints'],r)

@test('DV02')
async def dv02(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+TK+"if(typeof dvGoNode!=='function')return {none:true};toggleDevPanel(true);await w8(100);const t=document.querySelector('#dvx .m65 [data-a=enter][data-v=\"50\"]');if(!t)return {tile:false};t.click();await w8(300);const k0=G.zb&&G.zb.k;"
        "let n=0;while(G.zb&&G.zb.k!=='pick'&&G.zb.k!=='fight'&&n++<700){p.hp=G.st.maxHp;worldUpdate(1/60);}return {k0,k:G.zb&&G.zb.k,state:G.state,errs:(window.__fzErr||[]).length}}")
    rec('DV02 панель: ▶ на плитке 50 — бой с боссом 50 в секторе XII, вход идёт до выбора комплекта',not r.get('none') and r.get('k0')=='silence' and r.get('k') in ('pick','fight'),r)

@test('DV03')
async def dv03(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+TK+"const hints=[];const _h=hintOnce;hintOnce=function(k,t){hints.push(String(t));return _h.apply(this,arguments);};"
        "for(let i=0;i<WORLD.sectors.length;i++){const s=WORLD.sectors[i];const x=s.bx||(s.box[0]+s.box[2])/2,y=(s.by||(s.box[1]+s.box[3])/2);enterWorldAt(x,y);tick(.6);}"
        "openMap('map');drawMap();const labs=(G.mapItems||[]).map(it=>(it.l&&it.l.t)||'').concat(...[]);closeMap();"
        "return {ars:arsOpen(),hints:hints.filter(h=>/ПРОЙДИТЕ|ЗАПЕЧАТАН|ЗАПЕРТ|СНАЧАЛА/.test(h)),labs:labs.filter(t=>/ПРОЙДИТЕ|ЗАПЕЧАТАН|ЗАПЕРТ/.test(t)).slice(0,4)}}")
    rec('DV03 песочница: арсенал открыт без медали 14; за облёт всех 12 секторов и на карте — ни одного «ПРОЙДИТЕ / ЗАПЕЧАТАН / ЗАПЕРТЫ»',r['ars'] and not r['hints'] and not r['labs'],r)

@test('DV04')
async def dv04(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+TK+"const av=postAvail();p.x=POST_HATCH.x;p.y=POST_HATCH.y-120;p.px=p.x;p.py=p.y;camSnap();tick(.4);const card=G.card&&G.card.kind;"
        "openMap('map');drawMap();const onMap=(G.mapItems||[]).some(it=>it.kind==='post');closeMap();postEnter();await w8(100);const intro=G.state==='intro'&&G.m===POST_I+1;startMission();await w8(100);tick(.5);"
        "return {av,card,onMap,intro,post:!!G.post,act:G.post&&G.post.act,sec3:secSeen(2)}}")
    rec('DV04 песочница: сторожевик на карте и у шлюза — карточка, брифинг, акт 1; сектор III открыт и без него',r['av'] and r['card']=='post' and r['onMap'] and r['intro'] and r['post'] and r['act']==0 and r['sec3'],r)

@test('DV05')
async def dv05(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+W8+"toMenu();G.dev.diff='mid';openDev();await w8(200);const L=[...document.querySelectorAll('#devGrid .devm')].map(x=>x.dataset.m);const i=L.indexOf('post');"
        "const t=document.querySelector('#devGrid .devm[data-m=\"post\"]');if(!t)return {L:L.slice(8,12)};t.click();await w8(500);return {pos:[L[i-1],L[i+1]],state:G.state,m:G.m,mode:G.mode,sb:DEVW.on(),diff:G.save&&G.save.diff,txt:t.textContent}}")
    rec('DV05 сетка миссий: плитка сторожевика между 10 и 11 — песочница и брифинг «Изморози» со сложностью из сетки',r.get('pos')==['10','11'] and r.get('state')=='intro' and r.get('m')==51 and r.get('sb') and r.get('diff')=='mid',r)

@test('DV06')
async def dv06(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+W8+"toMenu();openDev();await w8(200);const t=document.querySelector('#devGrid .devm[data-m=\"50\"]');t.click();await w8(500);return {zb:G.zb&&G.zb.k,state:G.state,mode:G.mode,waves:G.waves&&G.waves.length,lab:t.querySelector('small').textContent}}")
    rec('DV06 сетка миссий: плитка 50 — настоящий бой с боссом 50 в песочнице, а не пустая миссия с 0 волн',r['zb']=='silence' and r['mode']=='world' and r['state']=='world',r)

@test('DV07')
async def dv07(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+W8+TK+"T.fresh();G.save.cleared=10;saveWorld();await w8(100);toMenu();openDev();await w8(150);const real0=localStorage.getItem('void_world');"
        "devGo('post');await w8(200);if(G.state!=='intro')return {post:false,state:G.state};startMission();tick(.5);postWin();await w8(300);"
        "devGo('zb');await w8(300);if(!G.zb)return {zb:false};const Z=G.zb;let n=0;while(G.zb&&G.zb.k!=='fight'&&n++<900){if(G.state==='levelup'&&pickMode!=='zbChoice'){choose(0);continue;}G.player.hp=G.st.maxHp;worldUpdate(1/60);}"
        "if(!G.zb)return {zb2:false};Z.k='choice';zbOpenChoice(Z);zbChoose(0);n=0;while(G.zb&&n++<900){G.player.hp=G.st.maxHp;worldUpdate(1/60);}await w8(200);"
        "const sb=JSON.parse(localStorage.getItem('void_devworld')||'{}');DEVW.exit();await w8(200);const real1=localStorage.getItem('void_world');"
        "return {same:real0===real1,sbPost:!!(sb.post&&sb.post.done),sbZero:sb.story&&sb.story.zero50,warn:DEVW.stats().warn.length}}")
    rec('DV07 сторожевик и финал босса 50 из дева: результат в песочнице, в настоящем сохранении ни байта',r.get('same') is True and r.get('sbPost') and r.get('sbZero')==1,r)

@test('DV08')
async def dv08(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+W8+"T.fresh();const S=G.save;S.cleared=10;S.medals=S.medals||{};saveWorld();toMenu();openDev();await w8(150);DEVW.enter();await w8(300);const inSb=[zeroOpen110(),arsOpen()];DEVW.exit();await w8(200);"
        "startWorld(false);await w8(300);if(G.prologue)prologueEnd();return {inSb,dev:DEVW.on(),zero:zeroOpen110(),ars:arsOpen(),post:postAvail(),sec3:secSeen(2),deny:zeroJumpDeny110({x:38500,y:16000})}}")
    rec('DV08 настоящая игра после дева: ворота XII закрыты, арсенал запечатан, сторожевик перекрывает III — как в 1.4.2',r['dev'] is False and r['zero'] is False and r['ars'] is False and r['post'] is True and r['sec3'] is False and r['deny'] is True,r)

@test('DV09')
async def dv09(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+"G.dev.god=true;G.dev.god1=false;const hp0=p.hp;const out={};const chk=n=>{out[n]=[Math.round(p.hp),G.deadT>0];};"
        "p.inv=0;damagePlayer(40);chk('enemy');drain90(500);chk('drain');riftKill();chk('rift');p.hp=hp0;addIce(3);out.ice=[G.frozen>0,G.ice||0];"
        "const w0=G.wear||0;G.st.maxHp0=G.st.maxHp0||G.st.maxHp;addWear(40);out.wear=[(G.wear||0)-w0];"
        "devStart(14);await w8(100);if(G.state==='intro')startMission();await w8(100);const q=G.player;q.inv=0;damagePlayer(40);drain90(500);out.mis=[Math.round(q.hp),G.deadT>0];return {hp0:Math.round(hp0),out}}")
    o=r['out'];ok=all(v==[r['hp0'],False] for k,v in o.items() if k in('enemy','drain','rift')) and o['ice']==[False,0] and o['wear']==[0] and o['mis'][1] is False and o['mis'][0]>0
    rec('DV09 бессмертие «полное»: враг, дренаж (в т.ч. босса 50), разлом, лёд, износ, миссия — здоровье не меняется, гибели нет',ok,r)

@test('DV10')
async def dv10(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+"G.dev.god=false;G.dev.god1=true;const out={};const t0=G.taken||0;p.inv=0;damagePlayer(9999);out.enemy=[Math.round(p.hp),G.deadT>0,(G.taken||0)>t0];"
        "p.inv=0;drain90(9999);out.drain=[Math.round(p.hp),G.deadT>0];riftKill();out.rift=[Math.round(p.hp),G.deadT>0];return out}")
    ok=all(v[0]>=1 and v[1] is False for v in r.values()) and r['enemy'][2]
    rec('DV10 бессмертие «1 HP»: урон и счётчик урона идут как в игре, здоровье не ниже 1, гибели нет',ok,r)

@test('DV11')
async def dv11(b):
    out={}
    for g in [0,1,2]:
        P=await dpage(b,1100,700)
        out[str(g)]=await P.js("""async(g)=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));toMenu();openDev();await w8(80);DEVW.enter();await w8(300);G.dev.god=g===2;G.dev.god1=g===1;G.dev.seedOn=true;G.dev.seed=12345;
          enterNode(2);if(G.state==='intro')startMission();const k0=G.kills;const r=T.bot({maxSec:90});return [r.state,r.sec,r.lvl,G.kills-k0,r.taken]}""",g)
    a,b1,c=out['0'],out['1'],out['2']
    rec('DV11 бессмертие не меняет бой: один сид и бот в миссии 2 песочницы — одинаковые время, уровень и убийства при 0, «1 HP» и «полном»; урон считается при 0 и «1 HP»',a[:4]==b1[:4]==c[:4] and a[4]==b1[4] and c[4]==0,out)

@test('DV12')
async def dv12(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+"if(typeof dvGoNode!=='function')return {none:true};const bad=[];for(let m=1;m<=50;m++){dvGoNode(m,false);const n=WORLD.nodes[m-1];const d=Math.hypot(p.x-n.x,p.y-n.y);const inRock=(G.rocks||[]).some(r=>Math.hypot(r.x-p.x,r.y-p.y)<r.r);if(d>400||inRock||G.state!=='world')bad.push(m);}"
        "dvGoNode('post',false);const dp=Math.hypot(p.x-POST_HATCH.x,p.y-POST_HATCH.y);const ent={};for(const m of [1,14,27,49]){dvGoNode(m,true);await w8(60);ent[m]=G.state==='intro'&&G.m===m;$('#bIntroBack').click();await w8(80);}"
        "return {bad,dp:Math.round(dp),ent,state:G.state}}")
    ok=not r.get('none') and not r['bad'] and r['dp']<400 and all(r['ent'].values()) and r['state']=='world' and not P.errs
    rec('DV12 телепорт: все 51 плитка «к узлу» — в радиусе 400 от цели и не в скале; «войти сразу» → брифинг 01, 14, 27, 49',ok,{**r,'pe':P.errs[:2]})

@test('DV13')
async def dv13(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+TK+"if(typeof devJump!=='function')return {none:true};const out={};const H=WORLD.hangar;"
        "dvGoNode(3,true);await w8(60);startMission();tick(.5);devJump(H.x,H.y+150,'тест');out.mis=[G.state,T.inv(),!!G.post,inMission()];"
        "dvGoNode(50,true);await w8(200);out.zb0=!!G.zb;devJump(H.x,H.y+150,'тест');out.zb=[G.state,T.inv(),!!G.zb];"
        "dvGoNode('post',true);await w8(60);startMission();tick(.3);devJump(H.x,H.y+150,'тест');out.post=[G.state,T.inv(),!!G.post];"
        "const a=[Math.round(p.x),Math.round(p.y)];devJump(WORLD.abyss.x,WORLD.abyss.y+260,'тест');dvBack();out.back=Math.hypot(p.x-a[0],p.y-a[1])<5;"
        "out.screens=[...document.querySelectorAll('section.screen')].filter(e=>!e.hidden).map(e=>e.id);return out}")
    ok=not r.get('none') and r['mis']==['world','ok',False,False] and r['zb0'] and r['zb']==['world','ok',False] and r['post']==['world','ok',False] and r['back'] and not r['screens'] and not P.errs
    rec('DV13 прыжок из миссии, боя с боссом 50 и сторожевика — чистый выход в мир; «назад» возвращает на прежнюю точку',ok,{**r,'pe':P.errs[:2]})

@test('DV14')
async def dv14(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+TK+"if(typeof dvxOpen!=='function')return {none:true};dvxOpen(true);await w8(80);const tabs=[...document.querySelectorAll('#dvx .t65 [data-a=tab]')].map(x=>x.dataset.v);"
        "const fh=()=>{document.querySelector('#dvx [data-a=tab][data-v=fight]').click();return (document.querySelector('#dvx .g65 h4')||{}).textContent;};const ctx={world:fh()};"
        "dvGoNode(3,true);await w8(60);startMission();tick(.3);dvxOpen(true);await w8(80);ctx.mis=fh();devJump(p.x,p.y,'т');"
        "dvGoNode(50,true);await w8(200);dvxOpen(true);await w8(80);ctx.zb=fh();dvLeave();dvGoNode('post',true);await w8(60);startMission();tick(.3);dvxOpen(true);await w8(80);ctx.post=fh();dvLeave();"
        "const skip=new Set(['exit','close','tab','sandbox','reset','mine','snapL','enter','node','place','sec','near','back','bmgo','xy','zbchoice','pwin','leave','zbleave','zbagain','progq','prog','tutall','report','copypos','fog','w58']);"
        "const errs0=(window.__dverr=[]);const oe=console.error;console.error=(...a)=>{errs0.push(String(a[0]).slice(0,100));oe.apply(console,a);};let clicked=0,dead=[];"
        "for(const t of ['ship','world','prog','tut','dbg']){dvxOpen(true);document.querySelector('#dvx [data-a=tab][data-v='+t+']').click();await w8(30);"
        "  const L=[...document.querySelectorAll('#dvx .bd65 [data-a]')].filter(x=>!skip.has(x.dataset.a));for(const x0 of L){const sel='#dvx .bd65 [data-a=\"'+x0.dataset.a+'\"][data-v=\"'+x0.dataset.v+'\"]';const x=document.querySelector(sel);if(!x||x.disabled){if(x&&!x.querySelector('em')&&!x.title)dead.push(x.dataset.a);continue;}x.click();clicked++;await w8(5);}}"
        "console.error=oe;G.dev.tpause=false;G.dev.tscale=1;G.dev.freeze=false;dvSave();return {tabs,ctx,clicked,dead,errs:errs0.slice(0,3),state:G.state}}")
    ok=not r.get('none') and r['tabs']==['jump','ship','fight','world','prog','tut','dbg'] and r['ctx']['world']=='КОНТЕКСТ' and r['ctx']['mis']=='МИССИЯ' and r['ctx']['zb'].startswith('БОСС 50') and r['ctx']['post'].startswith('СТОРОЖЕВИК') and r['clicked']>=40 and not r['dead'] and not r['errs'] and not P.errs
    rec('DV14 панель: 7 вкладок; «Бой» меняется для сектора, миссии, босса 50 и сторожевика; все кнопки нажимаются без ошибок, серые — с причиной',ok,{**r,'pe':P.errs[:2]})

@test('DV15')
async def dv15(b):
    out={}
    for (w,h) in [(390,844),(844,390),(360,740)]:
        P=await dpage(b,w,h,True)
        out[f'{w}x{h}']=await P.js("async()=>{"+SB+"if(typeof dvxOpen!=='function')return {none:true};setInput('touch');const res={};for(const t of ['jump','ship','fight','prog','tut','dbg']){G.dev.dvTab=t;dvxOpen(true);await w8(60);const D=$('#dvx'),R=D.getBoundingClientRect(),tb=D.querySelector('.t65'),bd=D.querySelector('.bd65');"
            "const small=[...D.querySelectorAll('button,span,p,b,h4,kbd,li')].filter(e=>e.offsetParent&&e.textContent.trim()&&e.children.length===0&&parseFloat(getComputedStyle(e).fontSize)<11.9).map(e=>e.textContent.trim().slice(0,12));"
            "const lowBtn=[...D.querySelectorAll('.bd65 button')].filter(e=>e.offsetParent&&e.getBoundingClientRect().height<31.5&&!e.closest('.fl65')).map(e=>e.textContent.trim().slice(0,10));"
            "res[t]={inside:R.left>=-1&&R.right<=innerWidth+1&&R.bottom<=innerHeight+1&&R.top>=0,tabScroll:tb.scrollWidth>tb.clientWidth+1,bodyX:bd.scrollWidth>bd.clientWidth+1,rows:new Set([...tb.children].map(x=>Math.round(x.getBoundingClientRect().top))).size,small:small.slice(0,3),lowBtn:lowBtn.slice(0,3),paused:(()=>{const x=p.x;worldUpdate(1/60);return true;})()};}"
            "const bar=$('#devBar').getBoundingClientRect();return {res,bar:[Math.round(bar.left),Math.round(bar.right),Math.round(bar.top),Math.round(bar.bottom)]}}")
    ok=True
    for k,o in out.items():
        if o.get('none'):ok=False;continue
        land=k.startswith('844')
        for t,v in o['res'].items():
            if not v['inside'] or v['tabScroll'] or v['bodyX'] or v['small'] or v['lowBtn'] or v['rows']!=(1 if land else 2):ok=False
    rec('DV15 телефон 390×844, 360×740 и 844×390: лист панели в экране, вкладки без прокрутки вбок (2 ряда, в альбомной 1), шрифт ≥ 12 px, кнопки ≥ 32 px',ok,out)

@test('DV16')
async def dv16(b):
    P=await dpage(b)
    r=await P.js("async()=>{"+SB+"if(typeof dvSnapSave!=='function')return {none:true};"
        "const run=async(wait)=>{dvSnapLoad(2);await w8(3000);$('#toast').hidden=true;G.dev.seedOn=true;G.dev.seed=777;enterNode(2);await w8(wait);if(G.state==='intro')startMission();const k0=G.kills;const r=T.bot({maxSec:60});const o=[r.state,r.sec,r.taken,r.lvl,G.kills-k0];dvLeave();return o;};"
        "dvSnapSave(2);const s1=await run(0),s2=await run(700);G.dev.seedOn=false;"
        "const S=G.save;S.lom=1234;dvGoNode(20,false);const a=[Math.round(G.player.x),Math.round(G.player.y)];dvSnapSave(1);G.save.lom=99;dvGoNode(40,false);dvSnapLoad(1);await w8(400);const q=G.player;const snap=[Math.hypot(q.x-a[0],q.y-a[1])<40,G.save.lom];"
        "return {snap,s1,s2}}")
    ok=not r.get('none') and r['snap']==[True,1234] and r['s1']==r['s2']
    rec('DV16 снимок F5/F9 возвращает позицию и лом; снимок → миссия 2 с сидом 777 и ботом → тот же снимок → снова (с паузой на брифинге): итог совпадает',ok,r)

@test('DV17')
async def dv17(b):
    P=await newpage(b,1280,800,alpha=False)
    r=await P.js("async()=>{"+W8+"T.fresh();G.save.tut.off=1;$('#toast').hidden=true;await w8(200);const g0=JSON.stringify(G.dev);for(const k of ['Backquote','KeyG','KeyH','KeyK','KeyN','Period']){window.dispatchEvent(new KeyboardEvent('keydown',{code:k,key:k,bubbles:true}));window.dispatchEvent(new KeyboardEvent('keyup',{code:k,key:k,bubbles:true}));}await w8(100);"
        "return {dvx:!!document.getElementById('dvx'),dev:devAny(),same:g0===JSON.stringify(G.dev),bar:$('#devBar').hidden,bDev:$('#bDev').hidden}}")
    rec('DV17 без ?dev: панели нет в DOM, Ё/G/H/K/N/. ничего не делают, кнопки «Разработка» в меню нет',r['dvx'] is False and r['dev'] is False and r['same'] and r['bar'] and r['bDev'],r)

@test('DV18')
async def dv18(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("()=>({ver:VER_TAG,tag:$('#verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.4.5 α</dt>')})")
    rec('DV18 версия 1.4.5 α и запись в журнале',r['ver']=='1.4.5 α' and r['tag']=='1.4.5 α' and r['log'],r)

if __name__=='__main__':
    sel=sys.argv[1:]
    if sel:TESTS=[t for t in TESTS if t[0] in sel]
    asyncio.run(run(TESTS,'q330'))
