# python3 mstrip.py <candidate.html> <ref.html> <n> [<n>...] — снимает патчи в обратном порядке, сравнивает с эталоном
import sys,hashlib
sys.path.insert(0,'@@KIT@@')
import arch74 as A
s=open(sys.argv[1],encoding='utf8').read()
for n in reversed(sys.argv[3:]):s=A.strip(s,int(n))
b=open(sys.argv[2],encoding='utf8').read()
left=[k for k in ['ARCH·72','ARCH·73','ARCH·74','ARCH·75','A-19','A-20','A-21','A-22','A-23','ARCH.clk','frame74','step74'] if k in s]
print('равно эталону:',s==b,'sha:',hashlib.sha256(s.encode()).hexdigest()[:16],'остатки:',left)
