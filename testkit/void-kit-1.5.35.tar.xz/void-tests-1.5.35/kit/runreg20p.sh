# runreg20p.sh <имя-группы> <тесты...>
cd @@KIT@@
export GAME_URL=file://@@KIT@@/void_c160.html TMO=1500
g=$1;shift
for t in $*; do s=$(date +%s); timeout 3600 python3 $t.py > reg20/$t.log 2>&1; echo "$t exit $? $(( $(date +%s)-s ))s" >> reg20/done.txt; done
echo "GROUP $g END" >> reg20/done.txt
