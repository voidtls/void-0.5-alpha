# 0.7.4 · часть 13: сектора V–VI (враги, события, боссы, мир), сила пилота по открытому сектору, патрули III–IV, компактные монологи на телефоне
import sys,re
SP='@@KIT@@/'
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m13: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
D74=open(SP+'d74.js',encoding='utf8').read()
B74=open(SP+'b74.js',encoding='utf8').read()
# --- данные: после AFX_OK (до генерации миссий)
i=s.index('const AFX_OK=new Set(');j=s.index('\n',i)
s=s[:j+1]+D74+'\n'+s[j+1:]
# --- поведение: перед главным циклом
R('// ---------- Главный цикл ----------',B74+'\n// ---------- Главный цикл ----------')
# ===== A1: сила пилота не зависит от того, где корабль =====
R("{const SS=typeof secScale==='function'?(secScale()||(G.world&&typeof worldSS==='function'?worldSS():null)):null;if(SS)G.st.dmg*=SS.dmg;G.st.maxHp0=G.st.maxHp;if(SS&&G.wear>0)G.st.maxHp=Math.max(50,Math.round(G.st.maxHp-G.wear));}",
  "{G.st.dmg*=playerDmgK();G.st.maxHp0=G.st.maxHp;if(G.wear>0)G.st.maxHp=Math.max(50,Math.round(G.st.maxHp-G.wear));}/* 0.7.4: урон и максимум прочности — по силе пилота, а не по сектору под кораблём */")
R("return h.replace('{SPD}',","return h.replace('{DMG}',String(playerDmgK()).replace('.',',')).replace('{SPD}',")
R("ваш урон ×${String(SS.dmg).replace('.',',')}","ваш урон ×${String(playerDmgK()).replace('.',',')} (сила пилота)")
# ===== генерация миссий: боссы и механики секторов по таблицам =====
R("intro:((SEC_WAVES[m]&&SEC_WAVES[m].debut)?[SEC_WAVES[m].debut]:[]).concat(boss&&SEC_SCALE[si]?[si===2?'inventor':'obheart']:[])",
  "intro:((SEC_WAVES[m]&&SEC_WAVES[m].debut)?[SEC_WAVES[m].debut]:[]).concat(boss&&SEC_SCALE[si]&&SB_TYPE_OF_SEC[si]?[SB_TYPE_OF_SEC[si]]:[])")
R("sboss:boss&&SEC_SCALE[si]?(si===2?'inv':'obod'):null","sboss:boss&&SEC_SCALE[si]?(SB_OF_SEC[si]||null):null")
R("M_.mech=(boss?['БОСС СЕКТОРА · '+(si===2?'ИНВЕНТАРИЗАТОР':'ОБОД')]:[]).concat([SS.ice?'ЛЁД · ОБЛЕДЕНЕНИЕ':'РЖАВЧИНА · ИЗНОС КОРПУСА','ВРАГИ СЕКТОРА ×'+SS.hp]);",
  "M_.mech=(boss?['БОСС СЕКТОРА · '+(SB_NAME_OF_SEC[si]||'?')]:[]).concat([SEC_MECH[si]||'СЕКТОР','ВРАГИ СЕКТОРА ×'+SS.hp]);")
R("  if(C.debut)waves.unshift([C.debut]);\n  return waves;}",
  "  if(C.brood)for(const wv of waves){let n=0;for(let i=0;i<wv.length;i++){if(n>=4)break;if(!wv[i].startsWith('pack:')&&!NO_BROOD.has(wv[i])&&R()<C.brood){wv[i]='cocoon';n++;}}}/* 0.7.4: инкубация */\n  if(C.debut)waves.unshift([C.debut]);\n  return waves;}")
# ===== A2: патрули III–IV в альфе (мир открыт целиком — узлы могли быть не пройдены) =====
R("function w58ZoneReady(z){return w58After(z.after)&&","function w58ZoneReady(z){return (ALPHA_OPEN/* ВРЕМЕННО (альфа 0.7.4): мир открыт целиком — патрули III–IV не ждут прохождения своих узлов */||w58After(z.after))&&")
# ===== миссия: хуки =====
R("sbLomK:1,sbChoiceTxt:''","sbLomK:1,lom74:0,sbChoiceTxt:''")
R("  secReset();computeStats();\n}\nfunction updateWaves","  secReset();computeStats();t74Init(M);\n}\nfunction updateWaves")
R("lom=Math.round(lom*mul*(G.sbLomK||1));","lom=Math.round(lom*mul*(G.sbLomK||1))+Math.round(G.lom74||0);")
R("updatePlayer(dt);secTick(dt);tiredTick(dt);","updatePlayer(dt);secTick(dt);if(inMission())t74Tick(dt);tiredTick(dt);")
R("  secDraw(t);secDraw2(t);\n","  secDraw(t);secDraw2(t);if(inMission())d74Draw(t);\n")
R("  for(const e of G.enemies){if(e.type==='shade'&&G.dark&&!visibleAt(e.x,e.y)","  if(inMission())d74Under(t);\n  for(const e of G.enemies){if(e.type==='shade'&&G.dark&&!visibleAt(e.x,e.y)")
R("function secReset(){Object.assign(G,{ice:0,","function secReset(){Object.assign(G,{eng74:0,engT74:0,latch74:null,flag74T:0,box74c:false,ice:0,")
R("function iceSpeedK(){return G.frozen>0?0:1-.12*(G.ice||0);}",
  "function iceSpeedK(){return G.frozen>0?0:(1-.12*(G.ice||0))*(G.mode==='endless'?1:(1-.1*(G.eng74||0))*(G.latch74&&G.latch74.alive?.7:1)*(G.box74c?.85:1));}")
R("setT('hpT',Math.ceil(p.hp)+'/'+st.maxHp+(G.wear>0?' · ИЗНОС '+wearPct()+'%':'')+(noHeal()?' ⊘':''));",
  "setT('hpT',Math.ceil(p.hp)+'/'+st.maxHp+(G.wear>0?' · ИЗНОС '+wearPct()+'%':'')+((G.eng74||0)>=.5?' · ДВИГ −'+Math.round(G.eng74*10)+'%':'')+(noHeal()?' ⊘':''));")
R("g.addColorStop(1,SS.ice?`rgba(191,232,255,${.22*k*COLD_A})`:`rgba(138,58,18,${.18+.015*wearPct()})`);",
  "g.addColorStop(1,SS.ice?`rgba(191,232,255,${.22*k*COLD_A})`:SS.brood?`rgba(255,107,138,${.14+.04*Math.sin(G.t*TAU/1.2)})`:SS.mercy?'rgba(120,135,160,.2)':`rgba(138,58,18,${.18+.015*wearPct()})`);")
# враги
R("function secEnemyUpdate(e,dt,ctx_){const p=G.player,{ux,uy,d,sm,T,pd}=ctx_;","function secEnemyUpdate(e,dt,ctx_){const p=G.player,{ux,uy,d,sm,T,pd}=ctx_;if(s74Update(e,dt,ctx_))return true;")
R("for(const c of G.enemies){if(c.type!=='commander'||!c.alive||c.spawnT>0)continue;for(const o of G.enemies)if(o!==c&&o.alive&&!HEAVY.has(o.type)&&Math.hypot(o.x-c.x,o.y-c.y)<220)o.buff=1.25;}",
  "for(const c of G.enemies){if(c.type!=='commander'||!c.alive||c.spawnT>0)continue;for(const o of G.enemies)if(o!==c&&o.alive&&!HEAVY.has(o.type)&&Math.hypot(o.x-c.x,o.y-c.y)<220)o.buff=1.25;}s74Buffs();")
R("function hurt(e,dmg,src){\n  if(!e.alive||e.down>0)return;","function hurt(e,dmg,src){\n  if(!e.alive||e.down>0)return;if(e.retreat&&mercySurrender(e))return;")
R("  else if(EDEF[e.type].sbp){dmg=sbHurt(e,dmg,src);if(dmg<=0)return;}\n","  else if(EDEF[e.type].sbp){dmg=sbHurt(e,dmg,src);if(dmg<=0)return;}\n  if(H74.has(e.type)||e.n74){dmg=s74Hurt(e,dmg,src);if(dmg<=0)return;}\n")
R("  if(e.wander&&G.w)w58WanderDied(e);","  if(e.wander&&G.w)w58WanderDied(e);\n  s74Killed(e,silent);")
R("else if(p.dashT<=0&&e.contact>0){damagePlayer(e.contact);if(e.type==='seeker'){kill(e,true);continue;}",
  "else if(p.dashT<=0&&e.contact>0){if(e.type==='guard'&&SSW()&&SSW().mercy)mercyHit(e.contact);else damagePlayer(e.contact);if(e.type==='seeker'||e.type==='unborn'){kill(e,true);continue;}")
R("      damagePlayer(b.dmg);if(b.frost)addIce(1);b.life=0;}}","      if(b.mercy){mercyHit(b.dmg);b.life=0;continue;}damagePlayer(b.dmg);if(b.frost)addIce(1);b.life=0;}}")
R("    if(G.world&&G.w&&(w58TugHit(b)||","    if(b74Hit(b)&&b.life<=0)continue;\n    if(G.world&&G.w&&(w58TugHit(b)||")
R("    case 'jam':drawJam(e,t,icon);break;\n  }","    case 'jam':drawJam(e,t,icon);break;\n    default:drawE74(e,t,icon,col,face,alpha,P);\n  }")
R("const p=G.player,bc=G.bc;if(e.tugAtk&&","const p=G.player,bc=G.bc;if(e.boatAtk&&G.w74b&&G.w74b.alive)return G.w74b;if(e.tugAtk&&")
R("if(!targetable(e)||NOAUTO.has(e.type)||e.retreat)continue;","if(!targetable(e)||NOAUTO.has(e.type)||e.retreat||e.n74)continue;")
# боссы секторов: развилки
R("function spawnSB(kind){ambSting('boss');radioClear();","function spawnSB(kind){if(kind==='nurse'||kind==='flag')return sb74Spawn(kind);ambSting('boss');radioClear();")
R("function sbPhase(b){","function sbPhase(b){if(b.sbk==='nurse'||b.sbk==='flag')return sb74Phase(b);")
R("function sbHud(b){","function sbHud(b){if(b.sbk==='nurse'||b.sbk==='flag')return sb74Hud(b);")
R("function sbFinal(b){","function sbFinal(b){if(b.sbk==='nurse'||b.sbk==='flag')return sb74Final(b);")
R("function sbTimeout(b){","function sbTimeout(b){if(b.sbk==='nurse'||b.sbk==='flag')return sb74Timeout(b);")
R("function sbChoose(b,ch){","function sbChoose(b,ch){if(b.sbk==='nurse'||b.sbk==='flag')return sb74Choose(b,ch);")
R("function sbDraw(t){const b=G.sb;if(!b||!b.alive)return;const p=G.player;","function sbDraw(t){const b=G.sb;if(!b||!b.alive)return;const p=G.player;if(b.sbk==='nurse'||b.sbk==='flag')return sb74Draw(b,t);")
R("function sbHurt(e,dmg,src){","function sbHurt(e,dmg,src){if(SB74T.has(e.type))return sb74Hurt(e,dmg,src);")
R("function sbTargetable(e){","function sbTargetable(e){if(SB74T.has(e.type))return sb74Targetable(e);")
R("  banner(b.sbk==='inv'?'КАРТОТЕКА РАЗРУШЕНА':'ЗАКАЗ ЗАКРЫТ',b.sbk==='inv'?'СЕКТОР III ПРОЙДЕН':'СЕКТОР IV ПРОЙДЕН');",
  "  if(SB_DEATH[b.sbk])banner(SB_DEATH[b.sbk][0],SB_DEATH[b.sbk][1]);else banner(b.sbk==='inv'?'КАРТОТЕКА РАЗРУШЕНА':'ЗАКАЗ ЗАКРЫТ',b.sbk==='inv'?'СЕКТОР III ПРОЙДЕН':'СЕКТОР IV ПРОЙДЕН');")
R("S.story[b.sbk==='inv'?'inv14':'obod18']=b.choice;","S.story[SB_FLAG[b.sbk]]=b.choice;")
R("radioLine('Э. В.','#ffd36b',b.sbk==='inv'?","radioLine('Э. В.','#ffd36b',SB_DEATH[b.sbk]?SB_DEATH[b.sbk][2]:b.sbk==='inv'?")
R("function sbEscort(b,dt){const p=G.player;if(b.st!=='fight'&&b.st!=='final')return;","function sbEscort(b,dt){const p=G.player;if(b.st!=='fight'&&b.st!=='final')return;if(b.noEsc&&b.phase===1)return;")
R("  if(!b.escN)radioLine(b.sbk==='inv'?'ИНВЕНТАРИЗАТОР':'ОБОД',","  if(!b.escN&&SB_ESC_R[b.sbk])radioLine(SB_ESC_R[b.sbk][0],SB_ESC_R[b.sbk][1],SB_ESC_R[b.sbk][2],.3);else if(!b.escN)radioLine(b.sbk==='inv'?'ИНВЕНТАРИЗАТОР':'ОБОД',")
R("for(const m of [14,18]){const ch=S.story[m===14?'inv14':'obod18'];","for(const m of [14,18,22,27]){const ch=S.story[SB_FLAG_M[m]];",2)
R("ctx.strokeStyle=m===14?'#9fd8ff':'#c96a2a';","ctx.strokeStyle=m===14?'#9fd8ff':m===22?'#ff6b8a':m===27?'#b8c4d6':'#c96a2a';")
R("for(let m=11;m<=50;m++)MASTERY.push(MASTERY_GEN[m%4]);",
  "for(let m=11;m<=50;m++)MASTERY.push(MASTERY_GEN[m%4]);\nMASTERY[21]={t:'Порвать все четыре пуповины за 30 с',ok:()=>!!G.mc&&G.mc.cord74!==undefined&&G.mc.cord74<=30};MASTERY[26]={t:'Ни одного попадания «по двигателям»',ok:()=>!!G.mc&&!G.mc.eng74};")
R("  damagePlayer(d*.4);G.eng74=Math.min(5,(G.eng74||0)+1);G.engT74=6;","  damagePlayer(d*.4);G.eng74=Math.min(5,(G.eng74||0)+1);G.engT74=6;if(G.mc)G.mc.eng74=1;")
# мир
R("storyDrawWorld(t);w58Draw(t);","storyDrawWorld(t);w58Draw(t);w74Draw(t);d74Under(t);")
R("  w58DrawTop(t);\n","  w58DrawTop(t);w74DrawTop(t);\n")
R("secTick(dt);secWorldTick(dt);updateZones(dt);","secTick(dt);secWorldTick(dt);w74WorldTick(dt);updateZones(dt);")
R("  w58MapAdd(add,lod,S);","  w58MapAdd(add,lod,S);w74MapAdd(add,lod,S);")
R("if(w58MapIcon(g,kind,o,t)){","if(w58MapIcon(g,kind,o,t)||w74MapIcon(g,kind,o,t)){")
R("if(w58DrawSkin(id,t,sp,o,A,fl,edge)){","if(w58DrawSkin(id,t,sp,o,A,fl,edge)||w74DrawSkin(id,t,sp,o,A,fl,edge)){")
# патрули: состав, радио, итоги для зон секторов V–VI
a=s.index("{const pool=z.set.slice(),ne=w58RollEsc();");b=s.index("z.leader=L;z.n++;",a)+len("z.leader=L;z.n++;")
s=s[:a]+"if(z.k74)w74ZoneSpawn(z);else{"+s[a:b]+"}"+s[b:]
R("if(!ws[rk]){ws[rk]=1;radioLine(z.sec===2?","if(!ws[rk]){ws[rk]=1;if(z.k74)w74ZoneRadio(z);else radioLine(z.sec===2?")
R("const ws=w58S();const rk=z.sec===2?'radioZ3':'radioZ4';","const ws=w58S();const rk=z.k74?'radioZ'+z.k74:z.sec===2?'radioZ3':'radioZ4';")
R("      if(left===0){z.active=false;const first=!S.zonesDone['w'+z.idx];","      if(left===0&&z.k74&&w74ZoneDone(z)){}\n      else if(left===0){z.active=false;const first=!S.zonesDone['w'+z.idx];")
R("const R=G.st.pR;G.shock.push({x:p.x,y:p.y,r:10,R,t:0,col:'#ffb84d'});","const R=G.st.pR;G.shock.push({x:p.x,y:p.y,r:10,R,t:0,col:'#ffb84d'});if(G.world||inMission()){const X_=x74();X_.spores=X_.spores.filter(s=>Math.hypot(s.x-p.x,s.y-p.y)>R+s.r*.5);}")
# сохранение
R("if(st.obod18!==undefined&&!['scrap','service'].includes(st.obod18))delete st.obod18;",
  "if(st.obod18!==undefined&&!['scrap','service'].includes(st.obod18))delete st.obod18;if(st.cradle22!==undefined&&!['cut','keep'].includes(st.cradle22))delete st.cradle22;if(st.fleet27!==undefined&&!['bridge','engine'].includes(st.fleet27))delete st.fleet27;if(st.save33!==undefined&&!['dead','unborn'].includes(st.save33))delete st.save33;if(st.teo!==undefined&&![1,-1].includes(st.teo))delete st.teo;if(st.echo127!==undefined&&st.echo127!=='guard')delete st.echo127;if(st.lastKind!==undefined)st.lastKind=num(st.lastKind,0,0,1e4,true);")
R("  if(S.w58!==undefined){const w=S.w58=obj(S.w58);",
  "  if(S.w74!==undefined){const w=S.w74=obj(S.w74);w.pois=obj(w.pois);w.zd=obj(w.zd);w.glyph=num(w.glyph,0,0,5,true);if(w.save33!==undefined&&!['dead','unborn'].includes(w.save33))delete w.save33;}\n  if(S.w58!==undefined){const w=S.w58=obj(S.w58);")
# радио: условия
R("if(c==='m4')return G.m>=4;","if(c==='dead33')return storyFlag('save33')==='dead';if(c==='unborn33')return storyFlag('save33')==='unborn';if(c==='keep22')return storyFlag('cradle22')==='keep';if(c==='engine27')return storyFlag('fleet27')==='engine';if(c==='teo')return storyFlag('teo')===1;if(c==='m4')return G.m>=4;")
# Хроника
R("  if(s&&s.history.length)h+=`<dt>Отчёты</dt>",
  "  if(s&&s.cradle22)h+=`<dt>Кормилица</dt><dd>${s.cradle22==='cut'?'Кокон разбит. Следующая копия VØID не родилась в этой колыбели. Очередь копий: разрыв.':'Кокон выношен. Младший летит рядом в секторах V–VI. На его борту — номер следующего цикла.'}</dd>`;\n  if(s&&s.fleet27)h+=`<dt>«Последний довод»</dt><dd>${s.fleet27==='bridge'?'Рубка пробита. Адмирал Карр так и не узнал, почему Стражи не стреляли в неё.':'Двигатели выбиты, рубка цела — как сделали Стражи 127 лет назад. Протокол «не объяснять», дополнение 7: «Людей не убивать». Перк «Милость»: отступающие сдаются от попадания.'}</dd>`;\n  if(s&&s.save33)h+=`<dt>Выбор сохранения</dt><dd>${s.save33==='dead'?'Вы сохранили запись мёртвого вида. Зародышу питания не хватило.':'Вы сохранили зародыш. Запись мёртвого вида стёрлась.'}</dd>`;\n  if(s&&s.history.length)h+=`<dt>Отчёты</dt>")
# ===== A3: монологи на телефоне — вдвое компактнее, слева сверху под корпусом =====
CSS=r"""
/* --- 0.7.4: монологи (перехваты, журналы, фрагменты) на телефоне — вдвое меньше, слева сверху под полосой корпуса --- */
.mob #radio{max-width:min(230px,46vw);font-size:9px;line-height:1.35;padding:4px 7px 5px;background:rgba(4,8,16,.62);bottom:auto}
.mob #radio .rtag{font-size:7.5px;letter-spacing:.14em;margin-bottom:1px}
.mob #toast{transform:none!important;width:min(230px,46vw)!important;padding:6px 8px;gap:2px;z-index:6}
.mob #toast .eyebrow{font-size:7.5px;letter-spacing:.14em}
.mob #toast p{font-size:9.5px;line-height:1.35}
.mob #fragTxt{transform:none;width:min(240px,48vw);text-align:left;font-size:10px;line-height:1.45;text-shadow:0 0 10px rgba(255,255,255,.35)}
.mob #fragTxt small{font-size:7.5px;margin-bottom:3px}
"""
R("</style>",CSS+"</style>",1)
R("// ---------- Главный цикл ----------","""// 0.7.4: стопка монологов на телефоне — под полосой корпуса, друг под другом
function mobStack74(){if(!isMob())return;{const r_=document.getElementById('radio'),t_=document.getElementById('toast'),f_=document.getElementById('fragTxt');if((!r_||r_.hidden)&&(!t_||t_.hidden)&&(!f_||!f_.classList.contains('on')))return;}const hb=document.getElementById('hpB');let y=46,x=10;
  if(hb){let yb=0;for(const id of ['hpB','sigB','bcB','biB','jamB','bossB','enB']){const el=document.getElementById(id);if(!el)continue;const bar=el.closest('.bar')||el.parentElement,r=bar.getBoundingClientRect();
      if(r.height>0&&r.bottom>0&&r.left<innerWidth*.45&&r.top<innerHeight*.35){const lab=bar.previousElementSibling,lr=lab?lab.getBoundingClientRect():null;yb=Math.max(yb,r.bottom);if(id==='hpB')x=Math.max(8,Math.round(r.left));}}
    if(yb>0)y=Math.round(yb+8);}
  for(const id of ['radio','toast','fragTxt']){const el=document.getElementById(id);if(!el)continue;el.style.top=y+'px';el.style.left=x+'px';el.style.bottom='auto';
    const vis=!el.hidden&&el.offsetHeight>0&&+getComputedStyle(el).opacity>.05;if(vis)y+=el.offsetHeight+6;}}
setInterval(mobStack74,120);
// ---------- Главный цикл ----------""")
# ===== версия и хроника =====
R('<div class="eyebrow">АЛЬФА 0.7.0 · АРСЕНАЛ</div>','<div class="eyebrow">АЛЬФА 0.7.4 · КОЛЫБЕЛИ И ФЛОТ</div>')
R("if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.7.0 α</dt>",
  "if(cxTab==='log')B.innerHTML=`<dl class=\"kv\"><dt>0.7.4 α</dt><dd>«Колыбели и флот». Сектор V «Чужие колыбели» (миссии 19–22): инкубация — часть волн приходит коконами; Нерождённые, Пестуны, Мембраны, Пуповины, Певчие, Зародыши стража и Последний из вида; события «Роды» и «Чужая гравитация»; босс «Кормилица» с выбором «прервать или выносить». Сектор VI «Кладбище флота» (23–27): милость Стражей глушит двигатели, дрейфующие корпуса с батареями, залпы мёртвого флота; Автопилоты, Абордажники, Брандеры, Связисты, Крейсер-перебежчик, Курсанты и Скелет линкора; события «Поднять флаг», «Чёрный ящик», «Битва 127 лет назад», «Последний приказ»; босс «Последний довод» с выбором «по рубке или по двигателям». В открытом мире — восемь новых патрулей, журналы, пять глифов, «Выбор сохранения», радиоголоса КОЛЫБЕЛЬ и ФЛОТ, скины «Нерождённый», «Глиф», «Довод». Сила пилота больше не зависит от того, где корабль: урон и прочность — по максимальному открытому сектору (в альфе — уровень сектора IV). Патрули секторов III–IV снова появляются. На телефоне перехваты и журналы вдвое компактнее и стоят слева сверху под корпусом.</dd><dt>0.7.0 α</dt>")
open(P,'w',encoding='utf8').write(s)
print('m13 ok')
