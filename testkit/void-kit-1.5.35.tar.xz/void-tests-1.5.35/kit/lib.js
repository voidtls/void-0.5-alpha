// общие боты для тестов 0.3
window.KK=['KeyA','KeyD','KeyW','KeyS'];
window.steer2=(tx,ty)=>{const p=G.player;for(const k of KK)KEYS[k]=false;const dx=tx-p.x,dy=ty-p.y;if(Math.abs(dx)>8)KEYS[dx>0?'KeyD':'KeyA']=true;if(Math.abs(dy)>8)KEYS[dy>0?'KeyS':'KeyW']=true;};
// бот миссии: не бессмертный, корпус не падает ниже floor (урон считается), маяк — bcFloor
window.runMission=function(o){
  o=Object.assign({maxSec:420,floor:40,bcFloor:60,render:0,charge:false,picks:'rand'},o||{});
  let steps=0;const t0=G.taken;let maxAlive=0,sumAlive=0,spawned=0;const seen=new Set();
  while(steps<60*o.maxSec){
    if(G.state==='levelup'){if(G.briefQ>0&&o.picks==='auto')autoPick();else choose(Math.random()*choices.length|0);continue;}
    if(G.state==='intro'){startMission();continue;}
    if(G.state!=='play')break;
    const p=G.player,bc=G.bc;
    if(o.floor)p.hp=Math.max(p.hp,o.floor);
    if(bc&&o.bcFloor)bc.hp=Math.max(bc.hp,o.bcFloor);
    let tx,ty;
    if(bc){const cut=G.relays.find(r=>r.cut);
      if(cut&&(steps%1200)<300){tx=(cut.x+bc.x)/2;ty=(cut.y+bc.y)/2;}
      else{const a=steps/90;tx=bc.x+Math.cos(a)*75;ty=bc.y+Math.sin(a)*75;}
      const cell=G.pick.find(k=>k.k==='cell'&&!(k.stab>0));if(cell&&p.cargo<G.st.cargo&&(steps%600)<300){tx=cell.x;ty=cell.y;}}
    else{const a=steps/120;tx=W/2+Math.cos(a)*W*.3;ty=H/2+Math.sin(a)*H*.3;}
    steer2(tx,ty);
    if(steps%170===0)tryDash();if(p.en>=100)tryPulse();
    if(o.charge){KEYS.KeyQ=(steps%300)<80;}
    if(steps%200===0){const t=G.enemies.find(e=>targetable(e)&&(e.type==='pylon'||e.type==='jam'||e.type==='leech'||e.type==='antenna'||e.type==='decoy'));if(t)G.prio=t;}
    update(1/60);
    for(const e of G.enemies)if(!seen.has(e.uid)&&!EDEF[e.type].passive&&!['mite','seeker','antenna','decoy','pylon','cpart','shell','mine','crate'].includes(e.type)){seen.add(e.uid);spawned++;}
    const al=G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive).length;maxAlive=Math.max(maxAlive,al);sumAlive+=al;
    if(G.mode==='endless')updateEndlessHUD();else updateHUD();
    if(o.render&&steps%o.render===0)render(performance.now());
    steps++;
  }
  for(const k of KK)KEYS[k]=false;KEYS.KeyQ=false;
  return {m:G.m,state:G.state,sec:Math.round(steps/60),taken:Math.round(G.taken-t0),spawned,maxAlive,avgAlive:+(sumAlive/Math.max(1,steps)).toFixed(1),lvl:G.lvl,bc:G.bc?Math.round(G.bc.hp/G.bc.maxHp*100):null};
};
// полёт в мире (с обходом помех): возвращает число кадров или 'timeout'
window.flyTo=function(tx,ty,maxS,stopD){maxS=maxS||90;stopD=stopD||70;
  for(let i=0;i<maxS*60;i++){if(G.state==='levelup')choose(0);if(G.state!=='world')return 'st:'+G.state;const p=G.player;p.hp=Math.max(p.hp,40);
    const dx=tx-p.x,dy=ty-p.y;if(Math.hypot(dx,dy)<stopD){for(const k of KK)KEYS[k]=false;return i;}
    // обход закрытых узлов
    let ax=tx,ay=ty;for(const n of WORLD.nodes){if(nodeState(n.m)!=='locked')continue;const d=Math.hypot(p.x-n.x,p.y-n.y);if(d<560){const a=Math.atan2(p.y-n.y,p.x-n.x)+Math.PI/2*(((n.x-p.x)*(ty-p.y)-(n.y-p.y)*(tx-p.x))>0?-1:1);ax=p.x+Math.cos(a)*300;ay=p.y+Math.sin(a)*300;}}
    steer2(ax,ay);worldUpdate(1/60);updateWorldHUD();if(i%60===0)renderWorld(performance.now());}
  for(const k of KK)KEYS[k]=false;return 'timeout';};
window.waitWorld=function(sec){for(let i=0;i<sec*60;i++){if(G.state!=='world')return;G.player.hp=Math.max(G.player.hp,40);worldUpdate(1/60);}};
