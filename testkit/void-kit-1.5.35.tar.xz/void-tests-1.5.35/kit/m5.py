# 0.6.0 · часть 5: качество, жизненный цикл, звук, курс с карты, геймпад, обучение, подсказки iOS/WebView
import sys
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m5: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)

# переключатели — только с data-k (у «НА ВЕСЬ ЭКРАН» его нет)
R("document.addEventListener('click',e=>{const b=e.target.closest('.tog');if(!b)return;const k=b.dataset.k;",
  "document.addEventListener('click',e=>{const b=e.target.closest('.tog[data-k]');if(!b)return;const k=b.dataset.k;")

# ---------- качество ----------
R("function part(x,y,vx,vy,life,col,size){if(G.parts.length>=900||",
  "let PMAX=900,GLOWMAX=0;\nfunction part(x,y,vx,vy,life,col,size){if(G.parts.length>=PMAX||")
R("function glow(x,y,r,col,a=1){if((!SET.fx||G.lowFx)&&r>30)return;",
  "function glow(x,y,r,col,a=1){if((!SET.fx||G.lowFx)&&r>30||GLOWMAX&&r>GLOWMAX)return;")
R("function shake(v){if(SET.fx)G.shake=Math.max(G.shake,v);}",
  "function shake(v){if(SET.fx){if(isMob())v*=(RMQ&&RMQ.matches?.3:1)*[.3,.6,1][G.q];G.shake=Math.max(G.shake,v);}}")
R("  if(++miniT%2===0)drawMini();","  if(++miniT%(isMob()?[4,2,1][G.q]||2:2)===0)drawMini();")
QT=r"""
// ===== 0.6.0: адаптивное качество (только телефон и планшет; ПК — как было) =====
let qAcc=0,qN=0,qT=0,qChg=0,qGood=0;
function qStart(){return G.ff==='tablet'?2:1;}
function qApply(){if(!isMob()){PMAX=900;GLOWMAX=0;return;}PMAX=[250,500,900][G.q];GLOWMAX=G.q===2?0:G.q===1?60:0;G.lowFx=G.q===0;const d=Math.min(dprCap(),window.devicePixelRatio||1);if(Math.abs(d-DPR)>.01)resize();}
function qTick(dt,now){
  if(!isMob()){if(G.q!==2){G.q=2;qApply();}return;}
  if(SET.quality!=='auto'){const v=+SET.quality;if(G.q!==v){G.q=v;qApply();}return;}
  if(G.qInit!==G.ff){G.qInit=G.ff;G.q=qStart();qApply();}
  if(!(G.state==='play'||G.state==='world')){qAcc=qN=qT=0;return;}
  qAcc+=dt;qN++;qT+=dt;if(qT<2)return;const avg=qAcc/Math.max(1,qN);qAcc=qN=qT=0;if(G.lowFx!==(G.q===0))G.lowFx=G.q===0;
  if(now-qChg<8000)return;
  if(avg>1/50&&G.q>0){G.q--;qChg=now;qGood=0;qApply();}
  else if(avg<1/83){qGood+=2;if(qGood>=20&&G.q<qStart()){G.q++;qChg=now;qGood=0;qApply();}}else qGood=0;}
// ===== 0.6.0: сон экрана =====
let wakeL=null,wakeTry=0;
function wakeSync(now){const want=isMob()&&!document.hidden&&G.state!=='menu'&&G.state!=='pause'&&G.state!=='settings';
  if(want&&!wakeL&&navigator.wakeLock&&now-wakeTry>5000){wakeTry=now;try{navigator.wakeLock.request('screen').then(l=>{wakeL=l;l.addEventListener('release',()=>{wakeL=null;});},()=>{});}catch(e){}}
  else if(!want&&wakeL){try{wakeL.release();}catch(e){}wakeL=null;}}
"""
R("function camZTarget(){",QT+"function camZTarget(){")
R("  touchTick(dt);if(typeof qTick==='function')qTick(dt,now);}",
  "  touchTick(dt);qTick(dt,now);wakeSync(now);padTick(now);tutTick();}")

# ---------- жизненный цикл ----------
R("  if(AU.ctx){if(AU.ctx.state==='suspended')AU.ctx.resume();return;}",
  "  if(AU.ctx){if(AU.ctx.state!=='running'&&AU.ctx.state!=='closed'){try{AU.ctx.resume();}catch(e){}}return;}")
R("addEventListener('blur',()=>{for(const k in KEYS)KEYS[k]=false;CHG.m=false;CHG.t=false;MOUSE.down=false;pause();});","addEventListener('blur',()=>{for(const k in KEYS)KEYS[k]=false;CHG.m=false;CHG.t=false;MOUSE.down=false;pause();lifeSave();});")
R("document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});",
  "document.addEventListener('visibilitychange',()=>{if(document.hidden){pause();lifeSave();}});\n"
  "function lifeSave(){try{for(const k in KEYS)KEYS[k]=false;CHG.m=false;CHG.t=false;CHG.p=false;if(joy.on){joy.on=false;joy.id=null;joy.x=joy.y=0;$('#joy').style.display='none';}SW.clear();\n"
  "  if(G.mode==='world'&&G.world&&G.player&&G.save&&!(window.DEVW&&DEVW.on()))saveWorld();if(isMob()&&AU.ctx&&AU.ctx.state==='running'&&document.hidden)AU.ctx.suspend();}catch(e){console.error(e);}}\n"
  "addEventListener('pagehide',lifeSave);\n"
  "addEventListener('pointerdown',()=>{if(isMob())audioInit();},true);")

# ---------- курс с карты ----------
R("  if(jp)h+=`<button class=\"wbtn amber\" data-mjump=\"${jp.label}\">ПРЫЖОК</button>`;return h;}",
  "  {const lab=it.o.n?'МИССИЯ '+pad2(it.o.n.m):({shop:'МАСТЕРСКАЯ',hangar:'ХРАНИЛИЩЕ',beacon:'МАЯК',anom:'АНОМАЛИЯ',relay:'РЕТРАНСЛЯТОР',cache:'ТАЙНИК',journal:'ЖУРНАЛ',abyss:'БЕЗДНА',gate:'ВОРОТА',lost:'ЛОМ'})[it.kind]||'ЦЕЛЬ';h+=`<div class=\"wc-row\"><button class=\"wbtn\" data-mcourse=\"${Math.round(it.x)},${Math.round(it.y)},${lab}\">${G.course&&Math.abs(G.course.x-it.x)<2&&Math.abs(G.course.y-it.y)<2?'КУРС ПРОЛОЖЕН':'ПРОЛОЖИТЬ КУРС'}</button>`+(jp?`<button class=\"wbtn amber\" data-mjump=\"${jp.label}\">ПРЫЖОК</button>`:'')+'</div>';}return h;}")
R("$('#mapTip').addEventListener('click',e=>{const b=e.target.closest('[data-mjump]');if(!b)return;",
  "$('#mapTip').addEventListener('click',e=>{const c=e.target.closest('[data-mcourse]');if(c){const [x,y,...l]=c.dataset.mcourse.split(',');G.course={x:+x,y:+y,label:l.join(',')};$('#mapTip').hidden=true;G.mapTipPin=null;closeMap();if(G.player)floater(G.player.x,G.player.y-44,'КУРС · '+G.course.label,'#8fe9ff');return;}const b=e.target.closest('[data-mjump]');if(!b)return;")
R("  if(S.lost)arrow(S.lost.x,S.lost.y,'#ff4f6e','ЛОМ');",
  "  if(S.lost)arrow(S.lost.x,S.lost.y,'#ff4f6e','ЛОМ');\n  if(G.course){if(Math.hypot(G.course.x-p.x,G.course.y-p.y)<240){G.course=null;floater(p.x,p.y-44,'ВЫ НА МЕСТЕ','#8fe9ff');}else arrow(G.course.x,G.course.y,'#8fe9ff','КУРС · '+G.course.label);}")
R("  if(S.lost){const [x,y]=P(S.lost.x,S.lost.y);g.fillStyle='#ff4f6e';g.beginPath();g.arc(x,y,4,0,TAU);g.fill();}",
  "  if(S.lost){const [x,y]=P(S.lost.x,S.lost.y);g.fillStyle='#ff4f6e';g.beginPath();g.arc(x,y,4,0,TAU);g.fill();}\n  if(G.course){let [x,y]=P(G.course.x,G.course.y);const dx=x-s/2,dy=y-s/2,dl=Math.hypot(dx,dy),mr=s/2-6;if(dl>mr){x=s/2+dx/dl*mr;y=s/2+dy/dl*mr;}g.strokeStyle='rgba(143,233,255,.7)';g.lineWidth=2;g.setLineDash([4,4]);g.beginPath();g.moveTo(s/2,s/2);g.lineTo(x,y);g.stroke();g.setLineDash([]);}")
R("function toMenu(){unlockArena();riftReset();","function toMenu(){unlockArena();G.course=null;riftReset();")

# ---------- геймпад (все устройства; без геймпада ничего не меняется) ----------
R("  if(joy.on||joy.locked){x+=joy.x;y+=joy.y;}","  if(joy.on||joy.locked){x+=joy.x;y+=joy.y;}\n  if(G.padOn){x+=G.padX;y+=G.padY;}")
R("  const hold=(KEYS.KeyQ||CHG.m||CHG.t)&&chargeAllowed();","  const hold=(KEYS.KeyQ||CHG.m||CHG.t||CHG.p)&&chargeAllowed();")
PAD=r"""
// ===== 0.6.0: геймпад =====
const PADB={};
function padTick(now){const gp=navigator.getGamepads?[...navigator.getGamepads()].find(g=>g&&g.connected):null;if(!gp){if(G.padOn){G.padOn=false;G.padX=G.padY=0;CHG.p=false;}return;}
  const ax=gp.axes[0]||0,ay=gp.axes[1]||0,l=Math.hypot(ax,ay),dz=.18;G.padOn=l>dz;if(G.padOn){const k=Math.min(1,(l-dz)/(1-dz))/l;G.padX=ax*k;G.padY=ay*k;}else G.padX=G.padY=0;
  const pr=i=>!!(gp.buttons[i]&&(gp.buttons[i].pressed||gp.buttons[i].value>.5));const edge=i=>{const v=pr(i),o=PADB[i];PADB[i]=v;return v&&!o;};
  const any=[0,1,2,3,9,12,13].some(i=>pr(i))||G.padOn;if(any)setInput('pad');
  CHG.p=pr(7)||pr(5);
  const st=G.state;
  if(st==='play'||st==='world'){if(edge(0))tryDash();if(edge(2))tryPulse();if(edge(9))pause();if(st==='world'&&edge(3))openMap();if(st==='world'&&edge(1)&&G.card)cardAct('main');return;}
  if(st==='map'&&(edge(3)||edge(1))){closeMap();return;}
  if(st==='pause'&&edge(9)){resume();return;}
  if(edge(1)){escAction();return;}
  const sc=G.scrId&&$('#'+G.scrId);if(!sc)return;const bt=[...sc.querySelectorAll('button:not([disabled]),.card')].filter(b=>b.offsetParent!==null&&getComputedStyle(b).visibility!=='hidden');if(!bt.length)return;
  let i=bt.indexOf(document.activeElement);if(edge(13)){i=(i+1)%bt.length;bt[i].focus();}if(edge(12)){i=(i-1+bt.length)%bt.length;bt[i].focus();}
  if(edge(0)){if(i<0){bt[0].focus();}else bt[i].click();}}
addEventListener('gamepadconnected',()=>setInput('pad'));
// ===== 0.6.0: обучение на касаниях (миссии 1–2) =====
function tutTick(){if(!touchMode||!isMob()||G.state!=='play'||G.mode!=='world'||!G.player||G.m>2)return;const T=G.tut||(G.tut={});const p=G.player;
  if(!T['s'+G.m]){T['s'+G.m]=1;floater(p.x,p.y-46,G.m===1?'ВЕДИТЕ КОРАБЛЬ СТИКОМ СЛЕВА':'РЫВОК — УВОРОТ · КНОПКА ИЛИ СВАЙП ВПРАВО','#8fe9ff');}
  if(!T.en&&p.en>=100){T.en=1;floater(p.x,p.y-46,'ИМП ГОТОВ · КНОПКА СПРАВА','#ffb84d');}}
"""
R("// ===== 0.6.0: экранный слой для телефона =====",PAD+"// ===== 0.6.0: экранный слой для телефона =====")

# ---------- подсказки: iOS-хранилище и встроенные браузеры ----------
R('    <div class="rec" id="recLine"></div>',
  '    <div class="rec" id="recLine"></div>\n    <p class="note mobonly" id="wvNote" hidden>Игра открыта во встроенном браузере приложения: прогресс может не сохраниться. Откройте ссылку в Safari или Chrome.</p>')
R("function renderMenu(){","function renderMenu(){try{$('#wvNote').hidden=!/Telegram|FBAN|FBAV|Instagram|VKClient|WhatsApp|Line\\/|; wv\\)/i.test(navigator.userAgent);}catch(e){}")
R("  enterWorldAt(S.pos.x,S.pos.y);\n  const U=G.unlockPending;G.unlockPending=null;",
  "  enterWorldAt(S.pos.x,S.pos.y);\n  try{const ios=/iP(hone|ad|od)/.test(navigator.userAgent),sa=navigator.standalone||matchMedia('(display-mode: standalone)').matches;if(ios&&!sa&&!SET.iosHint&&doneCount()>=5){SET.iosHint=true;saveSet();setTimeout(()=>toast('СОХРАНИТЕ ПРОГРЕСС','Safari стирает данные сайтов, которые не открывали 7 дней. Добавьте игру на экран «Домой» («Поделиться» → «На экран Домой») или сохраните код в меню «ЕЩЁ» → «КОД СОХРАНЕНИЯ».'),900);}}catch(e){}\n  const U=G.unlockPending;G.unlockPending=null;")

# ---------- семантика ----------
R('<section class="screen dim" id="sPause" hidden>','<section class="screen dim" id="sPause" hidden role="dialog" aria-modal="true" aria-label="Пауза">')
R('<section class="screen" id="sSet" hidden>','<section class="screen" id="sSet" hidden role="dialog" aria-modal="true" aria-label="Настройки">')
R('<button id="btnMap">КАРТА [M]</button>','<button id="btnMap" aria-label="Карта">КАРТА [M]</button>')
R('<canvas id="mini" width="264" height="264"></canvas>','<canvas id="mini" width="264" height="264" aria-label="Миникарта"></canvas>')

open(P,'w',encoding='utf8').write(s)
print('m5 ok')
