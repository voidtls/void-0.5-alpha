# 1.2.5 α · «Пустота-12»: подложка открытого мира секторов I–II. Каждый тест падает на версии 26.
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
W="""async(si)=>{T.fresh();const S=G.save;S.cleared=4;for(let m=1;m<=4;m++)S.medals[m]={clear:1};saveWorld();SET.amb=true;SET.sfx=true;audioInit();await AU.ctx.resume();
  const sec=WORLD.sectors[si].box;enterWorldAt((sec[0]+sec[2])/2,(sec[1]+sec[3])/2);
  window.__calm=true;window.__step=async(ms)=>{const t0=performance.now();while(performance.now()-t0<ms){if(__calm){G.enemies=[];MUS.hostT=-99;}musicTick(.05);await new Promise(r=>setTimeout(r,50));}};return typeof V12!=='undefined';}"""

@test('A1')
async def a1(b):
    P=await newpage(b,alpha=False)
    r=await P.js("""async()=>{if(typeof V12==='undefined')return {ok:false};audioInit();await AU.ctx.resume();const out={};for(const n of V12.order){const bf=await v12Decode(n);out[n]=+(bf.duration).toFixed(3);delete V12.buf[n];}return {ok:true,out,sr:AU.ctx.sampleRate}}""")
    want=16+.25+.2
    ok=r.get('ok') and len(r['out'])==12 and all(abs(v-want)<.002 for v in r['out'].values())
    rec('A1 12 кусков по 16 с (+хвост 0,25 и поля 0,1) декодируются; петля 160 с',ok,r)

@test('A2')
async def a2(b):
    P=await newpage(b,alpha=False)
    r=await P.js("""async()=>{if(typeof V12==='undefined')return {ok:false};const sr=48000,C=new OfflineAudioContext(1,sr*4,sr);const dec=n=>{const s=v12Raw(n),u=Uint8Array.from(atob(s),c=>c.charCodeAt(0));return C.decodeAudioData(u.buffer);};
      const res={};for(const [a,bb,off] of [['loop9','loop0',14],['intro1','loop0',14],['loop3','loop4',14]]){const A=await dec(a),B=await dec(bb);const C2=new OfflineAudioContext(1,sr*4,sr);
        const s1=C2.createBufferSource();s1.buffer=A;const g1=C2.createGain();s1.connect(g1);g1.connect(C2.destination);const end=2,xf=V12.xf,pre=V12.pre;s1.start(0,pre+off);g1.gain.setValueAtTime(1,end-xf/2);g1.gain.linearRampToValueAtTime(0,end+xf/2);s1.stop(end+.25);
        const s2=C2.createBufferSource();s2.buffer=B;const g2=C2.createGain();g2.gain.setValueAtTime(0,end-xf/2);g2.gain.linearRampToValueAtTime(1,end+xf/2);s2.connect(g2);g2.connect(C2.destination);s2.start(end-xf/2,pre-xf/2);
        const d=(await C2.startRendering()).getChannelData(0);const w=240;const rms=i=>{let s=0;for(let k=i;k<i+w;k++)s+=d[k]*d[k];return 10*Math.log10(s/w+1e-12);};
        let jSeam=0,jBase=[];for(let i=0;i+2*w<d.length;i+=w){const j=Math.abs(rms(i+w)-rms(i));if(Math.abs(i-2*sr)<.03*sr)jSeam=Math.max(jSeam,j);else jBase.push(j);}
        jBase.sort((x,y)=>x-y);let pk=0,pkB=0;for(let i=0;i<d.length;i++){const v=Math.abs(d[i]);if(Math.abs(i-2*sr)<.03*sr)pk=Math.max(pk,v);else pkB=Math.max(pkB,v);}
        res[a+'>'+bb]=[+jSeam.toFixed(1),+jBase[Math.floor(jBase.length*.99)].toFixed(1),+(20*Math.log10(pk/pkB)).toFixed(1)];}
      return {ok:true,res}}""")
    ok=r.get('ok') and all(v[0]<=v[1]+3 and v[2]<6 for v in r['res'].values())
    rec('A2 стыки кусков и петли loop9→loop0 без щелчков: скачок RMS на стыке ≤ p99 вне стыка +3 дБ, пик не выше остального',ok,r)

@test('A3')
async def a3(b):
    P=await newpage(b,alpha=False);ok0=await P.js(W,0)
    r=await P.js("""async()=>{if(!__calm&&0)return;await __step(6000);const P=MUS.cur,now=AU.ctx.currentTime,B=V12.beatAt?V12.beatAt(now):null;if(!B)return {ok:false,id:P&&P.id};
      const g0=now-B.ph,sd=60/120/4,k=(P.next-g0)/sd;return {ok:true,dev:+(Math.abs(k-Math.round(k))*sd*1000).toFixed(2),bpm:SC_.belt.bpm,root:SC_.belt.root,id:P.id}}""")
    rec('A3 секвенсор пейзажа в такт подложки: 120 BPM, шестнадцатые на сетке (отклонение ≤ 5 мс), фа минор',ok0 and r.get('ok') and r['dev']<=5 and r['bpm']==120 and r['root']==41,r)

@test('A4')
async def a4(b):
    P=await newpage(b,alpha=False);out={}
    for si in [0,1]:
        await P.js(W,si)
        out[si]=await P.js("""async()=>{if(typeof V12==='undefined')return null;V12.on=false;v12Stop(.01);V12.cur=null;V12.introDone=true;V12.everIntro=1;V12.pos=null;await __step(7000);const an=AU.ctx.createAnalyser();an.fftSize=32768;AU.amb.connect(an);const buf=new Float32Array(an.fftSize);let s=0,n=0;
          const meas=async(ms)=>{s=0;n=0;const t0=performance.now();while(performance.now()-t0<ms){if(__calm){G.enemies=[];MUS.hostT=-99;}musicTick(.05);await new Promise(r=>setTimeout(r,250));an.getFloatTimeDomainData(buf);for(const v of buf)s+=v*v;n+=buf.length;}return 10*Math.log10(s/n);};
          const calm=await meas(6000);const g0=V12.lvl;__calm=false;MUS.cur.I=1;G.anom=null;const p=G.player;const e=spawnEnemy?null:null;MUS.hostT=G.t;await __step(2500);const gF=V12.lvl;__calm=true;MUS.hostT=-99;await __step(6000);
          G.state='pause';await __step(2500);const gP=V12.lvl;G.state='world';AU.amb.disconnect(an);
          return {calm:+calm.toFixed(1),fight:+(20*Math.log10(gF/g0)).toFixed(1),pause:+(20*Math.log10(gP/g0)).toFixed(1)}}""")
        await P.js("async()=>{V12.on=false;v12Stop(.05);return 1}")
    ok=all(o and -36.5<=o['calm']<=-32.5 and abs(o['fight']+5)<=1 and abs(o['pause'])<=1 for o in out.values())
    rec('A4 уровень шины музыки в секторах I и II ≈ −34 dBFS; бой −5 дБ; пауза — общая (1.2.6)',ok,out)

@test('A5')
async def a5(b):
    P=await newpage(b,alpha=False);await P.js(W,0)
    r=await P.js("""async()=>{if(typeof V12==='undefined')return {ok:false};await __step(5000);const b1=V12.beatAt(AU.ctx.currentTime),src1=V12.cur&&V12.cur.src;const s=WORLD.sectors[1].box;G.player.x=(s[0]+s[2])/2;G.player.y=(s[1]+s[3])/2;
      await __step(3000);const b2=V12.beatAt(AU.ctx.currentTime);return {ok:true,b1:b1&&b1.beat,b2:b2&&b2.beat,id:MUS.cur.id,sec:V12.sec,eq:+V12.nodes.hi.gain.value.toFixed(1),on:V12.on,live:V12.live}}""")
    ok=r.get('ok') and r['b2'] is not None and r['b1'] is not None and 2<=r['b2']-r['b1']<=4 and r['id']=='drift' and r['sec']==1 and r['live']==1
    rec('A5 перелёт I → II: подложка не перезапускается (доли идут дальше), окраска и пейзаж меняются',ok,r)

@test('A6')
async def a6(b):
    P=await newpage(b,alpha=False);await P.js(W,0)
    r=await P.js("""async()=>{if(typeof V12==='undefined')return {ok:false};await __step(4000);const pos1=V12.beatAt(AU.ctx.currentTime).beat;const out={};
      const s=WORLD.sectors[2].box;G.player.x=(s[0]+s[2])/2;G.player.y=(s[1]+s[3])/2;await __step(4500);out.s3=[V12.on,+V12.nodes.g.gain.value.toFixed(3)];
      const s0=WORLD.sectors[0].box;G.player.x=(s0[0]+s0[2])/2;G.player.y=(s0[1]+s0[3])/2;await __step(1500);const B=V12.beatAt(AU.ctx.currentTime);out.back=B&&B.beat;out.pos1=pos1;
      toMenu();await __step(4500);out.menu=[V12.on,+V12.nodes.g.gain.value.toFixed(3)];T.openAll();T.go(3);await __step(1000);out.mission=V12.on;return {ok:true,...out}}""")
    ok=r.get('ok') and r['s3'][0]==False and r['s3'][1]<.01 and r['menu'][0]==False and r['menu'][1]<.01 and r['mission']==False and r['back'] is not None and r['back']-r['pos1']<=12
    rec('A6 сектор III, меню и миссия — подложка молчит; вернулся в I быстрее 90 с — продолжение с того же места',ok,r)

@test('A7')
async def a7(b):
    P=await newpage(b,alpha=False)
    r=await P.js("""async()=>{if(typeof V12==='undefined')return {ok:false};T.fresh();const S=G.save;S.cleared=4;for(let m=1;m<=4;m++)S.medals[m]={clear:1};saveWorld();SET.amb=false;audioInit();await AU.ctx.resume();
      const s=WORLD.sectors[0].box;enterWorldAt((s[0]+s[2])/2,(s[1]+s[3])/2);for(let i=0;i<40;i++){musicTick(.05);await new Promise(r=>setTimeout(r,25));}const off={dec:Object.keys(V12.buf).length+Object.keys(V12.dec).length,on:V12.on};
      SET.amb=true;for(const n of V12.order){const el=document.getElementById('v12-'+n);el.textContent='AAAA';}V12.buf={};
      for(let i=0;i<60;i++){musicTick(.05);await new Promise(r=>setTimeout(r,25));}const P=MUS.cur;return {ok:true,off,fail:V12.fail,live:V12.live,root:SC_.belt.root,pad:+P.L.pad.gain.value.toFixed(2)}}""")
    ok=r.get('ok') and r['off']['dec']==0 and not r['off']['on'] and r['fail']>=1 and r['live']==0 and r['root']==40 and not P.errs
    rec('A7 «Музыка» выключена — ничего не декодируется; битый файл — пейзаж как в версии 26, без ошибок',ok,{**r,'errs':P.errs[:2]})

@test('A8')
async def a8(b):
    P=await newpage(b,alpha=False);await P.js(W,0)
    r=await P.js("""async()=>{if(typeof V12==='undefined')return {ok:false};V12.introDone=true;V12.everIntro=1;await __step(2000);const mx=[];for(let i=0;i<20;i++){await __step(1000);mx.push(Object.keys(V12.buf).length);}
      let bytes=0;for(const k in V12.buf){const b=V12.buf[k];bytes+=b.length*b.numberOfChannels*4;}return {ok:true,max:Math.max(...mx),mb:+(bytes/1e6).toFixed(1),cur:V12.cur&&V12.cur.n}}""")
    rec('A8 память: в живых не больше 3 декодированных кусков (≤ 20 МБ), пока петля идёт через стык кусков',r.get('ok') and r['max']<=3 and r['mb']<=20,r)

@test('A9')
async def a9(b):
    P=await newpage(b,alpha=False);await P.js(W,0)
    r=await P.js("""async()=>{if(typeof V12==='undefined')return {ok:false};await __step(4000);const on=PENTA.slice();const s=WORLD.sectors[2].box;G.player.x=(s[0]+s[2])/2;G.player.y=(s[1]+s[3])/2;await __step(1500);return {ok:true,on,off:PENTA.slice()}}""")
    F=[523.25,622.25,698.46,830.61,932.33];O=[523.25,587.33,659.25,783.99,880]
    rec('A9 звук убийства: при подложке — пентатоника фа минора, без неё — прежняя',r.get('ok') and r['on']==F and r['off']==O,r)

@test('A10')
async def a10(b):
    sz=os.path.getsize(os.environ.get('GAME_URL','file://@@KIT@@/home/void.html').replace('file://',''))
    P=await newpage(b,alpha=False)
    r=await P.js("()=>({name:typeof V12!=='undefined'&&V12.name,blocks:document.querySelectorAll('script[id^=\"v12-\"]').length})")
    rec('A10 размер игры ≤ 16 МБ, 12 аудиоблоков, трек «Пустота-12»',sz<=16e6 and r['blocks']==12 and r['name']=='Пустота-12',{'mb':round(sz/1e6,2),**r})

if __name__=='__main__':
    sel=sys.argv[1:]
    asyncio.run(run([t for t in TESTS if not sel or any(t[0].startswith(x) for x in sel)],'q190.json'))
