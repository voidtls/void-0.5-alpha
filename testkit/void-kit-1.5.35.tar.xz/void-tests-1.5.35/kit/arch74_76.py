# ---------- 76 · A-23 · визуальная интерполяция между шагами (этап 4.5) ----------
PRE76="""/* ▼▼▼ ARCH·76 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.16 α · этап 4.5: плавность 90/120/144 Гц)
   A-23 · после каждого шага step74 запоминаются x, y и ang всех объектов, достижимых из G (корабль, враги и их части, боссы,
   снаряды, подборы, частицы, «Ноль», сектора), и камера CX/CY. Перед отрисовкой кадра им на время рисования ставится положение
   между предыдущим и текущим шагом (доля = остаток накопителя / шаг), после рисования точные значения возвращаются на место.
   Игра, столкновения, ИИ, RNG и сохранения видят только настоящие значения. Скачок больше IP76CUT пикселей за шаг (телепорт,
   смена сцены, переиспользованный объект) не сглаживается. Новые объекты с vx/vy отодвигаются назад по своей скорости, чтобы
   снаряд не «опережал» корабль. Включается сама, только если экран заметно чаще 60 Гц (средний кадр < 0,8 шага): на 60 Гц и
   ниже картинка, задержка и нагрузка те же, что без патча (перепись объектов тоже не идёт). В плоских списках
   G.parts, G.pb, G.eb, G.pick, G.float, G.rocks берутся только x/y самих элементов, без захода в их поля. Работает только вместе с циклом A-20 (и A-19).
   Выключение: window.__archOff=['A-23'] до загрузки. Сравнение для владельца: window.__ip76mode='x' — экстраполяция вперёд. */
ARCH.vi=!ARCH.off['A-23']&&!ARCH.off['A-20']&&!ARCH.off['A-19'];
const IP76LEAF=new Set(['parts','pb','eb','pick','float','rocks','wrocks']),IP76CUT=80,IP76SKIP=new Set(['save','fog','fogT','wrocks','decor','zones','posLog','dashLog','trail','world','nodes','dev','mc','stat','ach','runStart','radio','x90','relays','hit']);
const IP76={A:{o:[],x:new Float64Array(4096),y:new Float64Array(4096),a:new Float64Array(4096),m:new Map(),n:0,cx:0,cy:0},
  B:{o:[],x:new Float64Array(4096),y:new Float64Array(4096),a:new Float64Array(4096),m:new Map(),n:0,cx:0,cy:0},
  ok:0,ema:STEP74,act:false,mode:(window.__ip76mode==='x'?'x':'i'),al:0,rx:new Float64Array(4096),ry:new Float64Array(4096),ra:new Float64Array(4096),rn:0,rcx:0,rcy:0,
  st:{fr:0,ip:0,obj:0,cut:0,born:0,postMs:0,applyMs:0},seen:new Set()};
function ip76Grow(L,n){if(n<L.x.length)return;const k=L.x.length*2,f=a=>{const b=new Float64Array(k);b.set(a);return b;};L.x=f(L.x);L.y=f(L.y);L.a=f(L.a);
  if(IP76.rx.length<k){IP76.rx=f(IP76.rx);IP76.ry=f(IP76.ry);IP76.ra=f(IP76.ra);}}
function ip76Walk(o,d,L,leaf){if(!o||typeof o!=='object'||IP76.seen.has(o))return;IP76.seen.add(o);
  if(Array.isArray(o)){if(!o.length||typeof o[0]!=='object')return;for(let i=0;i<o.length;i++)ip76Walk(o[i],d,L,leaf);return;}
  if(ArrayBuffer.isView(o)||o instanceof Node||o instanceof Map||o instanceof Set)return;
  if(typeof o.x==='number'&&typeof o.y==='number'){const n=L.n;ip76Grow(L,n);L.o[n]=o;L.x[n]=o.x;L.y[n]=o.y;L.a[n]=typeof o.ang==='number'?o.ang:NaN;L.m.set(o,n);L.n=n+1;}
  if(d>=2||leaf)return;for(const k in o){if(IP76SKIP.has(k))continue;const v=o[k];if(v&&typeof v==='object')ip76Walk(v,d+1,L);}}
function ip76Post(){const t0=performance.now();const P=IP76.A;IP76.A=IP76.B;IP76.B=P;const L=IP76.B;L.n=0;L.m.clear();IP76.seen.clear();
  for(const k in G){if(IP76SKIP.has(k))continue;const v=G[k];if(v&&typeof v==='object')ip76Walk(v,0,L,IP76LEAF.has(k));}
  for(let i=L.n;i<L.o.length;i++)L.o[i]=null;L.cx=CX;L.cy=CY;IP76.ok++;IP76.st.postMs+=performance.now()-t0;}
function ip76Apply(dt0){if(dt0>0&&dt0<.05)IP76.ema+=(dt0-IP76.ema)*.1;
  const was=IP76.act;IP76.act=IP76.act?IP76.ema<STEP74*.9:IP76.ema<STEP74*.8;if(IP76.act&&!was)IP76.ok=0;IP76.st.fr++;
  if(!IP76.act||IP76.ok<2||!live74())return false;
  const t0=performance.now(),al=Math.max(0,Math.min(1,ACC74/STEP74)),C=IP76.B,P=IP76.A,x=IP76.mode==='x',dts=STEP74*ARCH.sc74;IP76.al=al;
  let cut=0,born=0;for(let i=0;i<C.n;i++){const o=C.o[i];const ox=o.x,oy=o.y,oa=o.ang;IP76.rx[i]=ox;IP76.ry[i]=oy;IP76.ra[i]=typeof oa==='number'?oa:NaN;
    if(ox!==C.x[i]||oy!==C.y[i])continue;/* сдвинут вне шага (событие ввода) — рисуем как есть */
    const j=P.m.get(o);
    if(j===undefined){if(!x&&typeof o.vx==='number'&&typeof o.vy==='number'){const k=(1-al)*dts;o.x=ox-o.vx*k;o.y=oy-o.vy*k;born++;}continue;}
    const dx=ox-P.x[j],dy=oy-P.y[j];if(dx*dx+dy*dy>IP76CUT*IP76CUT){cut++;continue;}
    if(x){o.x=ox+dx*al;o.y=oy+dy*al;}else{o.x=P.x[j]+dx*al;o.y=P.y[j]+dy*al;}
    const pa=P.a[j];if(typeof oa==='number'&&pa===pa&&oa===C.a[i]){let da=oa-pa;da-=Math.round(da/(2*Math.PI))*2*Math.PI;o.ang=x?oa+da*al:pa+da*al;}}
  IP76.rn=C.n;IP76.rcx=CX;IP76.rcy=CY;
  if(CX===C.cx&&CY===C.cy){const dx=CX-P.cx,dy=CY-P.cy;if(dx*dx+dy*dy<=IP76CUT*IP76CUT){if(x){CX=CX+dx*al;CY=CY+dy*al;}else{CX=P.cx+dx*al;CY=P.cy+dy*al;}}}
  IP76.st.ip++;IP76.st.obj=C.n;IP76.st.cut+=cut;IP76.st.born+=born;IP76.st.applyMs+=performance.now()-t0;return true;}
function ip76Restore(){const C=IP76.B;for(let i=IP76.rn-1;i>=0;i--){const o=C.o[i];o.x=IP76.rx[i];o.y=IP76.ry[i];const a=IP76.ra[i];if(a===a)o.ang=a;}CX=IP76.rcx;CY=IP76.rcy;}
"""+END%76
S76=[
 ("while(ACC74>=STEP74-1e-9&&n<MAXN74&&live74()){ACC74-=STEP74;n++;step74();}",
  "while(ACC74>=STEP74-1e-9&&n<MAXN74&&live74()){ACC74-=STEP74;n++;step74();if(ARCH.vi&&IP76.act)ip76Post();/* ARCH·76 A-23: перепись только при активной интерполяции */}"),
 ("  try{if(G.world&&G.player)renderWorld(now);else{render(now);secVignette();}mobOverlay(now);drawDevOverlay();}catch(err){console.error(err);}\n  requestAnimationFrame(frame);}",
  "  const ip76=ARCH.vi&&ip76Apply(dt0);/* ARCH·76 A-23 */\n  try{if(G.world&&G.player)renderWorld(now);else{render(now);secVignette();}mobOverlay(now);drawDevOverlay();}catch(err){console.error(err);}\n  if(ip76)ip76Restore();/* ARCH·76 A-23 */\n  requestAnimationFrame(frame);}"),
]
STAGES[76]=dict(vf='1.5.15 α',vt='1.5.16 α',J='m76_journal.txt',pre=PRE76,after=75,sites=S76)
