# 0.9.9 · часть 21: сектор XII «Нулевой миг» — босс 50 VØID-000 (он выходит в сектор сам)
import sys
SP='@@KIT@@/'
P='@@KIT@@/home/void.html'
s=open(P,encoding='utf8').read()
def R(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit('m21: count %d != %d for: %s'%(n,cnt,a[:160]))
    s=s.replace(a,b)
B=open(SP+'b120.js',encoding='utf8').read()
R('// ---------- Главный цикл ----------',B+'\n// ---------- Главный цикл ----------')
# --- вход: кнопка узла 50 → босс выходит в сектор ---
R("function enterNode(m,echo){\n  const S=G.save,n=WORLD.nodes[m-1];if(!S||!n||!G.player)return;",
  "function enterNode(m,echo){\n  if(m===50&&G.mode==='world'&&G.world&&!echo&&typeof zbStart==='function'){zbStart();return;}\n  const S=G.save,n=WORLD.nodes[m-1];if(!S||!n||!G.player)return;")
R("if(card.kind==='node'&&card.n.m===50&&!devAny()){h=`<div class=\"eyebrow\">МИССИЯ 50/${pad2(NM)} · СЕКТОР XII</div><h3>Комната босса <span class=\"badge\" style=\"color:#ff9fe0\">СКОРО</span></h3><p class=\"note\">Комната подготовлена. Босс Нулевой точки будет описан в следующем обновлении.</p><div class=\"wc-row\"><button class=\"wbtn\" disabled style=\"opacity:.45\">ВХОД ЗАКРЫТ</button></div>`;}",
  "if(card.kind==='node'&&card.n.m===50){h=zbCard();}")
R("if(c.n.m===50&&!devAny()){hintOnce('n50','КОМНАТА БОССА · СКОРО','#ff9fe0');return;}enterNode(c.n.m,false);",
  "if(c.n.m===50){if(zbOn())return;if(!zbCanStart()){hintOnce('n50',G.zbCool>G.t?'ТОЧКА НЕВОЗВРАТА ЗАКРЫТА · '+Math.ceil(G.zbCool-G.t)+' С':'КНОПКА НЕ ОТВЕЧАЕТ','#ff9fe0');return;}zbStart();return;}enterNode(c.n.m,false);")
R("const key=card?card.key+'|'+G.save.cleared+'|'+G.save.lom:'';","const key=card?card.key+'|'+G.save.cleared+'|'+G.save.lom+(card.kind==='node'&&card.n.m===50?'|'+(zbOn()?'z':zbDone()?'d':G.zbCool>G.t?'c':'o'):''):'';")
R("function drawNode(n,t){\n  const st=nodeState(n.m),M=MISSIONS[n.m-1],S=G.save;","function drawNode(n,t){\n  if(n.m===50&&typeof zbDrawNode==='function'){zbDrawNode(n,t);return;}\n  const st=nodeState(n.m),M=MISSIONS[n.m-1],S=G.save;")
R("function bossLab90(m){if(m===50)return 'БОСС · СКОРО';","function bossLab90(m){if(m===50)return 'VØID-000';")
R("anom:null,calm:0,saveT:8,flare:0,cardKey:null,card:null,mc:null});","anom:null,calm:0,saveT:8,flare:0,cardKey:null,card:null,mc:null,zb:null,zbCool:0,zbAmb:null});")
# --- мир: обновление, гибель, рисунок ---
R("  updateFx(dt);camFollow(dt);\n  while(G.xp>=G.need&&p.hp>0){","  updateFx(dt);zbCamPre();camFollow(dt);zbTick(dt);\n  while(G.xp>=G.need&&p.hp>0){")
R("function worldRespawn(){\n  const S=G.save,p=G.player;","function worldRespawn(){\n  if(G.zb&&typeof zbAbort==='function')zbAbort('death');\n  const S=G.save,p=G.player;")
R("storyDrawWorld(t);w58Draw(t);w74Draw(t);d74Under(t);w80Draw(t);d80Under(t);","storyDrawWorld(t);w58Draw(t);w74Draw(t);d74Under(t);w80Draw(t);d80Under(t);zbUnder(t);zbWallsDraw(t);")
R("w58DrawTop(t);w74DrawTop(t);d80Draw(t);w80Mask(sx-CX,sy-CY);","w58DrawTop(t);w74DrawTop(t);zbDraw(t);d80Draw(t);w80Mask(sx-CX,sy-CY);")
R("drawRiftFx(Math.max(G.riftI||0,G.wakeI||0),t);w58Screen(t);","drawRiftFx(Math.max(G.riftI||0,G.wakeI||0),t);w58Screen(t);zbTop(t);")
R("G.wz95=sec===8&&SET.fx&&!SET.lessFx?1+.006*beat90(G.t*1.1/1.2):1;","G.wz95=(typeof zbZoom==='function'&&zbZoom())||(sec===8&&SET.fx&&!SET.lessFx?1+.006*beat90(G.t*1.1/1.2):1);")
# --- враги: ИИ, рисунок, урон, импульс ---
R("function secEnemyUpdate(e,dt,ctx_){const p=G.player,{ux,uy,d,sm,T,pd}=ctx_;","function secEnemyUpdate(e,dt,ctx_){if(e.zb){zbAI(e,dt,ctx_);return true;}const p=G.player,{ux,uy,d,sm,T,pd}=ctx_;")
R("function drawEnemy(e,t,icon){\n  const d=EDEF[e.type],","function drawEnemy(e,t,icon){\n  if(EDEF[e.type].zb){if(icon)zbIcon(e);else if(e.zb===2)zbDrawCopy(e,t);else zbDrawBoss(e,t);return;}\n  const d=EDEF[e.type],")
R("function hurt(e,dmg,src){\n  if(!e.alive||e.down>0)return;","function hurt(e,dmg,src){\n  if(!e.alive||e.down>0)return;if(e.zb){zbHurt(e,dmg,src);return;}")
R("pulse80(p,R);}sfx('pulse');shake(10);","pulse80(p,R);}sfx('pulse');shake(10);if(typeof zbPulse==='function')zbPulse(p,R);")
R("const sep=e=>e.alive&&!STATIC.has(e.type)&&e.type!=='mine'&&!(e.type==='leech'&&e.att)&&e.down<=0;","const sep=e=>e.alive&&!STATIC.has(e.type)&&e.type!=='mine'&&!(e.type==='leech'&&e.att)&&e.down<=0&&!e.zbHide;")
# --- карта, мини-карта, прыжок, интерфейс, музыка ---
R("const c=$('#mapC'),S=G.save;if(!c||!S)return;const t0=performance.now(),t=t0/1000;","const c=$('#mapC'),S=G.save;if(!c||!S)return;if(typeof zbMap==='function'&&zbMap())return;const t0=performance.now(),t=t0/1000;")
R("const c=$('#mini');if(!c)return;const g=c.getContext('2d'),s=c.width,R=2600,","const c=$('#mini');if(!c)return;if(typeof zbMini==='function'&&zbMini())return;const g=c.getContext('2d'),s=c.width,R=2600,")
R("if(zeroJumpDeny110(best)){deny('ПРЫЖОК НЕВОЗМОЖЕН · ВОРОТА НУЛЕВОЙ ТОЧКИ');return true;}","if(zeroJumpDeny110(best)){deny('ПРЫЖОК НЕВОЗМОЖЕН · ВОРОТА НУЛЕВОЙ ТОЧКИ');return true;}\n  if(zbOn()){deny('ПРЫЖОК НЕВОЗМОЖЕН · ТОЧКА НЕВОЗВРАТА');return true;}")
R("function choose(i){\n  if(G.state!=='levelup'||!choices[i])return;const k=choices[i];","function choose(i){\n  if(G.state!=='levelup'||!choices[i])return;if(pickMode==='zbChoice'){zbChoose(i);return;}const k=choices[i];")
R("setT('wSub',sub);setC('hud0','subimp',!!G.anom);","setT('wSub',sub);setC('hud0','subimp',!!G.anom);if(typeof zbHud==='function')zbHud();")
R("I=hostile||(G.t-(MUS.hostT||-9)<4)||G.anom?1:0;ext.anom=!!G.anom;}","I=hostile||(G.t-(MUS.hostT||-9)<4)||G.anom?1:0;ext.anom=!!G.anom;if(typeof zbMus==='function'){const q=zbMus();if(q){id=q.id;I=q.I;if(q.ext)Object.assign(ext,q.ext);}}}")
R("const nt=nextTarget();if(nt)arrow(nt.x,nt.y,nt.col,nt.label);","const nt=zbOn()?null:nextTarget();if(nt)arrow(nt.x,nt.y,nt.col,nt.label);")
R("  el.innerHTML=h;try{wreckIconsFill(el);}catch(e){console.error(e);}","  if(typeof zbJournalsHTML==='function')h+=zbJournalsHTML(S);el.innerHTML=h;try{wreckIconsFill(el);}catch(e){console.error(e);}")
R("  card=w58POI(card);\n  G.card=card;renderCard(card);","  card=w58POI(card);if(card&&card.kind==='node'&&card.n.m===50&&zbOn())card=null;\n  G.card=card;renderCard(card);")
# --- тексты 0.9.7 → 0.9.9 ---
R("open?'КОМНАТА БОССА · СКОРО':'ПРОЙДИТЕ «МИГ» (49)'","open?'НУЛЕВОЙ МИГ · КНОПКА ЕЩЁ ТЁПЛАЯ':'ПРОЙДИТЕ «МИГ» (49)'")
R("toast('ВОРОТА НУЛЕВОЙ ТОЧКИ ОТКРЫТЫ','СЕКТОР XII · КОМНАТА БОССА · СКОРО');","toast('ВОРОТА НУЛЕВОЙ ТОЧКИ ОТКРЫТЫ','СЕКТОР XII · НУЛЕВОЙ МИГ · ОН ЖДЁТ У КНОПКИ');")
R("t:zeroOpen110()?'ВОРОТА ОТКРЫТЫ · XII':'ВОРОТА · ПРОЙДИТЕ «МИГ»'","t:zeroOpen110()?'ВОРОТА ОТКРЫТЫ · НУЛЕВОЙ МИГ':'ВОРОТА · ПРОЙДИТЕ «МИГ»'")
R("(M.bossRoom?(i===49?'ЗАГОТОВКА · ':'БОСС · '):'')","(M.bossRoom?'БОСС · ':'')")
R("floater(p.x,p.y-40,'ЗАГОТОВКА · БОСС БУДЕТ ОПИСАН ОТДЕЛЬНО',C110.zero);radioLine('Э. В.','#ffd36b','Здесь пока тихо. Это ненадолго.',.3);","floater(p.x,p.y-40,'КОМНАТА ПУСТА · ОН ВЫХОДИТ В МИР, К КНОПКЕ',C110.zero);radioLine('Э. В.','#ffd36b','Здесь его нет. Он там, где кнопка.',.3);")
R("worldLabel(q.x,q.y-70*k,'КОМНАТА 50 · ЗАГОТОВКА',C110.zero);worldLabel(q.x,q.y+78*k,'БОСС БУДЕТ ОПИСАН ОТДЕЛЬНО',C110.dim);","worldLabel(q.x,q.y-70*k,'КОМНАТА 50 · ПУСТА',C110.zero);worldLabel(q.x,q.y+78*k,'ОН ЖДЁТ СНАРУЖИ, У КНОПКИ',C110.dim);")
R("return {l:'ЗАГОТОВКА · КОМНАТА 50',k:null,col:C110.zero,lc:C110.zero,r:'ВЫХОД — ПАУЗА'};","return {l:'КОМНАТА 50 · ПУСТА · БОЙ — ИЗ МИРА',k:null,col:C110.zero,lc:C110.zero,r:'ВЫХОД — ПАУЗА'};")
# справочник: заголовок группы врагов сектора XI–XII
R("act===5?'СЕКТОРА IX–X · СЕРДЦЕ КОВЧЕГА И СТЁРТЫЕ БЕРЕГА':","act===6?'СЕКТОРА XI–XII · НУЛЕВАЯ ТОЧКА И НУЛЕВОЙ МИГ':act===5?'СЕКТОРА IX–X · СЕРДЦЕ КОВЧЕГА И СТЁРТЫЕ БЕРЕГА':")
# --- хроника ---
R('<div class="eyebrow">АЛЬФА 0.9.7 · НУЛЕВАЯ ТОЧКА</div>','<div class="eyebrow">АЛЬФА 0.9.9 · НУЛЕВОЙ МИГ</div>')
R('<dl class="kv"><dt>0.9.7 α</dt>','<dl class="kv"><dt>0.9.9 α</dt><dd>Сектор XII «Нулевой миг» и босс 50 — VØID-000 «Нулевой», первая копия. Он не ждёт в комнате: по кнопке «Войти в комнату» две секунды ничего не происходит, потом у сектора вырастают стены, «комната» расширяется от узла до стен, игрока отбрасывает, карта глохнет в помехах, телепорт закрывается, на экране искажённое «ТОЧКА НЕВОЗВРАТА ОТКРЫТА». После выбора стартового комплекта он выходит из разлома. Его сигнатура — зеркало: он повторяет вас. Пространство сжимается сорока фигурами (круг, эллипс, кольцо, капсула, полоса, серп, две линзы, треугольник, шестиугольник, звезда, крест, спираль, осколки — телеграф 1,5 с, морф 1 с, снаружи через 1,2 с стирание и незаряжающийся рывок). Четыре стадии. «Зеркало»: он стоит в точке отражения через центр фигуры, каждая ваша пуля возвращается эхом, спереди он отражает всё; рывок рвёт зеркало на 1,4 с — шов открыт; на половине сегмента появляются два осевых отражения, эхо втрое; раз в 6,5 с — бросок сквозь центр. «Отсчёт»: он у стола под двумя вращающимися лучами, счёт 12→0; таран рывком или импульс в упор — +5 с и 2,2 с открыт, лучи ускоряются; ноль — фигура ×0,65, импульс, −10% корпуса и ещё луч (до четырёх). «Негатив»: внутри фигуры — стирание, фигура охотится за вами (150 px/с, быстрее с каждой вылазкой); он внутри неуязвим и бьёт веерами; подойдите к кромке — он выйдет за вами и 2,8 с будет открыт. «Кнопка»: рывок, веер, луч, импульс циклом, выпад на каждый четвёртый удар сердца, эхо; в такт — двойной урон; помилованные из «Мига» держат линии вокруг кнопки и стреляют; на 20% — гонка к кнопке, его касание — цикл заново с 60%. Корпус-негатив: тёмное тело со светлой кромкой, шов по оси, орбита осколков белеет, когда он открыт, послеобразы за ним. Контрольных точек нет: гибель — цикл заново. У кнопки — выбор: стереть, вспомнить или третий путь (если помилованных не меньше трёх). Три концовки, записи 64–65, мастерство «без единого повтора цикла».</dd><dt>0.9.7 α</dt>')
# --- 0.9.9 R4: в альфе (все уровни открыты) ворота Нулевой точки тоже открыты — к 50 можно пройти без 49 ---
R("function zeroOpen110(){return !!(G.save&&G.save.story&&G.save.story.zero49)||","function zeroOpen110(){return (typeof window!=='undefined'&&window.__alpha!==false)||!!(G.save&&G.save.story&&G.save.story.zero49)||")
# --- 0.9.9 R3: в бою с VØID-000 камера отъезжает (видно фигуру дыхания и его самого) ---
R("function zoomK(){return isMob()?(SET.zoom||1)*(G.camZ||1):1;}","function zoomK(){return (isMob()?(SET.zoom||1):1)*(G.camZ||1);}")
R("function camZTarget(){if(!isMob()||(RMQ&&RMQ.matches))return 1;","function camZTarget(){if(typeof zbCamZ==='function'){const z=zbCamZ();if(z)return z;}if(!isMob()||(RMQ&&RMQ.matches))return 1;")
open(P,'w',encoding='utf8').write(s)
print('m21 ok')
