# 1.3.2 α «Проверка»: исправления по прогонам сектора I. Каждый тест падает на v32 (1.3.1).
import asyncio,json,sys,os
from h import *
TESTS=[]
def test(name):
    def d(f):TESTS.append((name,f));return f
    return d
OV="""(ids)=>{const R=s=>{const e=document.querySelector(s);if(!e||e.hidden||getComputedStyle(e).display==='none'||+getComputedStyle(e).opacity<.05||e.style.opacity==='0')return null;const r=e.getBoundingClientRect();return r.width>0?[r.left,r.top,r.right,r.bottom]:null;};
  const a=R(ids[0]);const out=[];for(const s of ids.slice(1)){document.querySelectorAll(s).forEach(el=>{if(el.hidden||getComputedStyle(el).display==='none')return;const q=el.getBoundingClientRect();if(!a||q.width===0)return;const ix=Math.max(0,Math.min(a[2],q.right)-Math.max(a[0],q.left))*Math.max(0,Math.min(a[3],q.bottom)-Math.max(a[1],q.top));if(ix>4)out.push((el.id||s)+':'+Math.round(ix));});}return {a:a&&a.map(Math.round),hits:out};}"""
@test('X01')
async def x01(b):
    out={}
    for (w,h,hand,where) in [(640,360,'r','shop'),(844,390,'r','node'),(667,375,'l','shop'),(1024,1366,'r','node'),(768,1024,'r','node')]:
        P=await newpage(b,w,h,alpha=False,touch=True)
        await P.js("""async([h,where])=>{T.fresh();G.save.tut.off=true;SET.hand=h;setInput('touch');layoutTouch();const o=where==='shop'?WORLD.shops[0]:WORLD.nodes[0];G.player.x=o.x+70;G.player.y=o.y+70;
          for(let i=0;i<40;i++)worldUpdate(1/60);updateWorldHUD();await new Promise(r=>setTimeout(r,500));updateWorldHUD();await new Promise(r=>setTimeout(r,100));}""",[hand,where])
        out[f'{w}x{h}{hand}']=await P.js(OV,['#wcard','#touch .tbtn'])
    ok=all(v['a'] and not v['hits'] for v in out.values())
    rec('X01 телефон/планшет: карточка объекта не закрывает кнопки «ИМП»/«ДЕЙСТВИЕ»/«РЫВОК» (альбомная, левша, планшет)',ok,out)
@test('X02')
async def x02(b):
    out={}
    for (w,h) in [(390,844),(780,360),(360,640)]:
        P=await newpage(b,w,h,alpha=False,touch=True)
        await P.js("""async()=>{T.fresh();setInput('touch');layoutTouch();const n=WORLD.nodes[0];G.player.x=n.x+80;G.player.y=n.y+80;for(let i=0;i<30;i++)worldUpdate(1/60);updateWorldHUD();
          radioLine('ПЕРЕХВАТ · СТРАЖ','#ff4f6e','Он стреляет первым. Как только увидите вспышку — уходите в сторону.');tutSkillPop(['move','dash']);await new Promise(r=>setTimeout(r,900));}""")
        out[f'{w}x{h}']=await P.js(OV,['#tutSk','#radio','#wcard','#toast'])
    ok=all(not v['hits'] for v in out.values()) and out['390x844']['a']
    rec('X02 телефон: всплывающий «Допуск пилота» не ложится на радио и карточку объекта',ok,out)
@test('X03')
async def x03(b):
    out={}
    for hand in ['r','l']:
        for st in ['fixed','float']:
            P=await newpage(b,360,640,alpha=False,touch=True)
            out[hand+st]=await P.js("""async([h,st])=>{T.fresh();G.save.tut.off=true;SET.hand=h;SET.stick=st;setInput('touch');layoutTouch();await new Promise(r=>setTimeout(r,400));
              const I=$('#joyIdle').getBoundingClientRect();const J=joyFixed();const bs=[...document.querySelectorAll('#touch .tbtn')].filter(b=>getComputedStyle(b).display!=='none').map(b=>b.getBoundingClientRect());
              const ovI=bs.some(q=>!(I.right<=q.left||I.left>=q.right||I.bottom<=q.top||I.top>=q.bottom));const ovJ=Object.values(TBR).some(q=>Math.hypot(J.x-q.x,J.y-q.y)<J.R+q.r);return {ovI,ovJ,inside:I.left>=0&&I.right<=innerWidth}}""",[hand,st])
    ok=all(not v['ovI'] and not v['ovJ'] and v['inside'] for v in out.values())
    rec('X03 узкий телефон 360: стик и его подсказка не заходят на кнопки «КАРТА»/«ИМП» (правша/левша, закреплённый/плавающий)',ok,out)
@test('X04')
async def x04(b):
    P=await newpage(b,1280,720,alpha=False)
    r=await P.js("async()=>{T.fresh();tutSkillPop(['move']);await new Promise(r=>setTimeout(r,700));TUT.blk=null;const s=$('#tutSk').getBoundingClientRect();return tutBlockers().some(q=>Math.abs(q[0]-(s.left-6))<2&&Math.abs(q[1]-(s.top-6))<2)}")
    rec('X04 подсказки обучения обходят всплывающий «Допуск пилота»',r is True,r)
STRICT="""window.__gest=false;const _g=e=>{if(e.isTrusted)window.__gest=true;};addEventListener('pointerdown',_g,true);addEventListener('keydown',_g,true);addEventListener('mousedown',_g,true);
const A_=window.AudioContext;window.AudioContext=class extends A_{constructor(...a){super(...a);super.suspend();}resume(){return window.__gest?super.resume():Promise.resolve();}};"""
@test('X05')
async def x05(b):
    P=await newpage(b,1280,760,alpha=False,init=STRICT)
    await P.wait(2600)
    r=await P.js("()=>({n:G.autoClick132||0,st:G.state,scr:[...document.querySelectorAll('section.screen')].filter(s=>!s.hidden).map(s=>s.id).join(),fs:!!document.fullscreenElement,ctx:AU.ctx&&AU.ctx.state})")
    await P.pg.mouse.click(900,700);await P.wait(600)
    r2=await P.js("()=>AU.ctx&&AU.ctx.state")
    ok=r['n']>=1 and r['st']=='menu' and r['scr']=='sMenu' and not r['fs'] and r2=='running'
    rec('X05 музыка: игра сама кликает в свободную точку меню (браузер такой клик не засчитывает), меню не трогается; первое настоящее касание включает музыку',ok,{'auto':r,'real':r2})
@test('X06')
async def x06(b):
    P=await newpage(b,844,390,alpha=False,touch=True)
    r=await P.js("()=>getComputedStyle($('#sHangar')).overflowX")
    rec('X06 «Хранилище корпусов» на телефоне не прокручивается вбок',r=='hidden',r)
@test('X07')
async def x07(b):
    P=await newpage(b,1280,760,alpha=False)
    r=await P.js("()=>({ver:VER_TAG,tag:$('#verTag').textContent,log:document.documentElement.outerHTML.includes('<dl class=\"kv\"><dt>1.3.2 α</dt>')})")
    rec('X07 версия 1.3.2 α и запись в журнале',r['ver']=='1.3.2 α' and r['tag']=='1.3.2 α' and r['log'],r)
@test('X08')
async def x08(b):
    out={}
    for (w,h) in [(1024,640),(1280,720)]:
        P=await newpage(b,w,h,alpha=False)
        out[f'{w}x{h}']=await P.js("""async()=>{T.fresh();const p=G.player;p.x=60;for(let i=0;i<30;i++)worldUpdate(1/60);tutSkillPop(['move']);await new Promise(r=>setTimeout(r,900));
          const a=$('#tutSk').getBoundingClientRect(),m=$('#mini').getBoundingClientRect(),[X,Y]=tutSP(p.x,p.y);const ov=(q,r)=>!(q.right<=r.left||q.left>=r.right||q.bottom<=r.top||q.top>=r.bottom);
          return {ship:ov(a,{left:X-20,right:X+20,top:Y-20,bottom:Y+20}),mini:ov(a,m)}}""")
    ok=all(not v['ship'] and not v['mini'] for v in out.values())
    rec('X08 ПК: корабль у левого края мира — всплывающий «Допуск пилота» уходит вправо, не накрывая корабль и мини-карту',ok,out)
@test('X09')
async def x09(b):
    P=await newpage(b,844,390,alpha=False,touch=True)
    r=await P.js("async()=>{T.fresh();SET.textScale=1.3;applySettings();G.save.cleared=6;saveWorld();setInput('touch');openHangar();await new Promise(r=>setTimeout(r,600));const s=$('#sHangar');return {out:[...s.querySelectorAll('*')].filter(e=>{const q=e.getBoundingClientRect();return q.width>0&&q.right>innerWidth+1;}).length,btn:[...s.querySelectorAll('.wbtn')].filter(b=>b.scrollWidth>b.clientWidth+3).length}}")
    rec('X09 «Хранилище корпусов» на телефоне при крупном тексте: карточки и кнопки «НАЙТИ · …» не вылезают за край, текст не выходит из кнопок',r['out']==0 and r['btn']==0,r)
asyncio.run(run(TESTS,'q260'))
