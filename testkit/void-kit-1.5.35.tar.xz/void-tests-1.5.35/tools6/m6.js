// Этап 7 · аудит · m6 — какие соседние слои одной цепочки переустановок можно механически слить в один без изменения поведения.
//   node tools6/m6.js <сборка.html> <out.json>
// Слой пригоден, если он имеет вид  {const _p=f; f=function(…){ … const r=_p.apply(this,arguments) … return r; }}  — ровно один
// безусловный вызов прежней реализации на верхнем уровне тела с теми же this/arguments, _p больше нигде не используется, результат
// прежней возвращается без изменений (return r / return _p.apply(...)), нет раннего return до вызова, нет присваиваний параметрам.
// Два пригодных слоя f подряд сливаются, только если между ними на верхнем уровне нет ничего, что может вызвать f во время загрузки:
// допускаются объявления функций, такие же блоки-слои других имён, объявления переменных без вызовов в инициализаторе и
// регистрации обработчиков (addEventListener / setTimeout / setInterval / requestAnimationFrame / queueMicrotask с функцией-аргументом).
// Барьеры (не сливаются через них): фабрики iso63 / iso65 / arch70Hud, слои через dvRun, условные и смешанные слои, полные замены.
const path=require('path'),fs=require('fs');
process.on('uncaughtException',e=>{console.error('m6: внутренняя ошибка: '+(e&&e.stack||e));process.exit(3);});
const NM=path.join(__dirname,'..','node_modules');
const acorn=require(path.join(NM,'acorn')),walk=require(path.join(NM,'acorn-walk'));
const html=fs.readFileSync(process.argv[2],'utf8');const k=html.indexOf('<script>\n"use strict";');const src=html.slice(k+8,html.indexOf('</script>',k));
const ast=acorn.parse(src,{ecmaVersion:2022,sourceType:'script',ranges:true,locations:true});
const T=n=>src.slice(n.range[0],n.range[1]);const line=n=>n.loc.start.line;
const SAFE_REG=/^(addEventListener|setTimeout|setInterval|requestAnimationFrame|queueMicrotask)$/;
// статический граф вызовов по именам: имя функции → имена, на которые ссылается её тело (вызов или ссылка); слои переустановок
// добавляют рёбра своему имени. Ссылка на имя считается возможным вызовом (консервативно).
const GN=new Set();for(const s of ast.body)if(s.type==='FunctionDeclaration')GN.add(s.id.name);
const CG={};const addE=(a,n)=>{(CG[a]=CG[a]||new Set());walk.full(n,x=>{if(x.type==='Identifier'&&GN.has(x.name))CG[a].add(x.name);});};
for(const s of ast.body){if(s.type==='FunctionDeclaration')addE(s.id.name,s.body);}
walk.fullAncestor(ast,(n,st)=>{if(n.type==='AssignmentExpression'&&n.left.type==='Identifier'&&GN.has(n.left.name)&&!st.some(a=>/Function/.test(a.type)&&a!==n))addE(n.left.name,n.right);});
const reach=(from,to,seen=new Set())=>{if(from===to)return true;if(seen.has(from))return false;seen.add(from);for(const x of CG[from]||[])if(reach(x,to,seen))return true;return false;};
const BUILTIN_OBJ=/^(document|Math|JSON|Object|Array|console|Number|String|Promise|window|navigator|performance|Date|Symbol|Reflect|URL|Intl)$/;
// вызовы при загрузке в операторе s, которые могут дойти до f
function loadReach(s,f){let bad=null;
  const visit=(n,run)=>{if(!n||typeof n.type!=='string'||bad)return;
    if(/Function/.test(n.type)&&!run)return;
    if(n.type==='CallExpression'||n.type==='NewExpression'){const c=n.callee;
      const nm=c.type==='Identifier'?c.name:c.type==='MemberExpression'&&!c.computed?c.property.name:null;
      const reg=nm&&SAFE_REG.test(nm);
      if(c.type==='Identifier'&&GN.has(c.name)&&reach(c.name,f)){bad=T(n).slice(0,80);return;}
      if(c.type==='MemberExpression'&&!(c.object.type==='Identifier'&&BUILTIN_OBJ.test(c.object.name))&&!/^(map|forEach|filter|reduce|some|every|find|findIndex|join|push|concat|slice|includes|indexOf|keys|values|entries|set|get|has|add|replace|split|trim|toFixed|toLowerCase|toUpperCase|padStart|fill|sort|from|assign|freeze|apply|call|bind)$/.test(nm||'')){
        // метод неизвестного объекта — проверяем, не ведёт ли имя метода к f через объявленную функцию с тем же именем
        if(nm&&GN.has(nm)&&reach(nm,f)){bad=T(n).slice(0,80);return;}}
      if(/Function/.test(c.type)){visit(c.body,true);}// IIFE исполняется сейчас
      for(const a of n.arguments){if(/Function/.test(a.type)){if(!reg)visit(a.body,true);}else visit(a,false);}
      if(c.type==='MemberExpression')visit(c.object,false);
      return;}
    if(n.type==='Identifier'&&run===true){/* ссылка внутри исполняемого тела */}
    for(const key of Object.keys(n)){if(key==='loc'||key==='range')continue;const v=n[key];if(Array.isArray(v))v.forEach(x=>x&&visit(x,false));else if(v&&typeof v.type==='string')visit(v,false);}};
  visit(s,false);return bad;}
function hasLoadCall(s){let bad=null;
  const visit=(n,inFn)=>{if(!n||typeof n.type!=='string'||bad)return;
    if(/Function/.test(n.type))return;// тела функций при загрузке не исполняются
    if(n.type==='CallExpression'||n.type==='NewExpression'){const c=n.callee;const nm=c.type==='Identifier'?c.name:c.type==='MemberExpression'&&!c.computed?c.property.name:null;
      const regOK=nm&&SAFE_REG.test(nm)&&n.arguments.some(a=>/Function/.test(a.type));
      if(!regOK){bad=T(n).slice(0,80);return;}}
    if(n.type==='TaggedTemplateExpression'){bad=T(n).slice(0,60);return;}
    for(const key of Object.keys(n)){if(key==='loc'||key==='range')continue;const v=n[key];if(Array.isArray(v))v.forEach(x=>visit(x));else if(v&&typeof v.type==='string')visit(v);}};
  visit(s);return bad;}
// слои-блоки верхнего уровня: { const _p=f; f=function(){…}; }  (допускается несколько слоёв разных имён в одном блоке — тогда блок помечается как сложный)
const layers=[];
ast.body.forEach((s,idx)=>{if(s.type!=='BlockStatement')return;const b=s.body;
  const decl=b.filter(x=>x.type==='VariableDeclaration');const asg=b.filter(x=>x.type==='ExpressionStatement'&&x.expression.type==='AssignmentExpression'&&x.expression.left.type==='Identifier');
  for(const a of asg){const f=a.expression.left.name,rhs=a.expression.right;
    const cap=decl.flatMap(d=>d.declarations).find(d=>d.init&&d.init.type==='Identifier'&&d.init.name===f);
    const L={name:f,idx,line:line(a),ok:false,why:''};layers.push(L);
    if(!cap){L.why='нет захвата const _p=f';continue;}const p=cap.id.name;
    if(!/Function/.test(rhs.type)){L.why='не функция';continue;}
    if(b.length!==2){L.why='в блоке есть другой код ('+b.length+' операторов)';continue;}
    const body=rhs.body.type==='BlockStatement'?rhs.body.body:null;if(!body){L.why='тело-выражение';continue;}
    let uses=0,callTop=-1,callOK=false,retR=null;
    walk.full(rhs,n=>{if(n.type==='Identifier'&&n.name===p)uses++;});
    body.forEach((st,i)=>{const t=T(st);
      if(new RegExp('\\b'+p+'\\.apply\\(this,arguments\\)').test(t)){
        if(st.type==='VariableDeclaration'&&st.declarations.length===1&&st.declarations[0].init&&T(st.declarations[0].init)===p+'.apply(this,arguments)'){callTop=i;callOK=true;retR=st.declarations[0].id.name;}
        else if(st.type==='ReturnStatement'&&T(st.argument)===p+'.apply(this,arguments)'){callTop=i;callOK=true;retR='(прямо)';}
        else if(st.type==='ExpressionStatement'&&T(st.expression)===p+'.apply(this,arguments)'){callTop=i;callOK=true;retR='(без результата)';}}});
    if(uses!==1){L.why='_p используется '+uses+' раз';continue;}
    if(!callOK){L.why='вызов прежней не на верхнем уровне тела или не apply(this,arguments)';continue;}
    // ранний return до вызова, присваивания параметрам, return другого значения
    const pre=body.slice(0,callTop),post=body.slice(callTop+1);let bad='';
    const params=new Set(rhs.params.map(x=>x.name));
    const chk=(arr,where)=>{for(const st of arr)walk.full(st,n=>{if(bad)return;if(n.type==='ReturnStatement'&&!(where==='post'&&n.argument&&n.argument.type==='Identifier'&&n.argument.name===retR&&arr[arr.length-1]===st))bad='return '+where;
        if(n.type==='AssignmentExpression'&&n.left.type==='Identifier'&&(params.has(n.left.name)||n.left.name==='arguments'))bad='присваивание параметру';
        if(n.type==='Identifier'&&n.name===retR&&where==='post'&&!(arr[arr.length-1].type==='ReturnStatement'))bad='результат читается после вызова';},walk.base);};
    // вложенные функции внутри pre/post могут содержать return — разрешаем: ищем только return вне вложенных функций
    const chk2=(arr,where)=>{for(const st of arr){(function v(n,top){if(!n||bad)return;if(n!==st&&/Function/.test(n.type))return;
        if(n.type==='ReturnStatement'){const last=arr[arr.length-1]===st&&where==='post'&&n.argument&&n.argument.type==='Identifier'&&n.argument.name===retR&&n===st;if(!last)bad='return '+where;}
        if(n.type==='AssignmentExpression'&&n.left.type==='Identifier'&&params.has(n.left.name))bad='присваивание параметру';
        for(const key of Object.keys(n)){if(key==='loc'||key==='range')continue;const val=n[key];if(Array.isArray(val))val.forEach(x=>x&&typeof x.type==='string'&&v(x));else if(val&&typeof val.type==='string')v(val);}})(st);}};
    chk2(pre,'pre');chk2(post,'post');
    if(retR&&retR!=='(прямо)'&&retR!=='(без результата)'){const last=post[post.length-1];if(!last||last.type!=='ReturnStatement'||!last.argument||last.argument.name!==retR)bad=bad||'результат прежней не возвращается последним оператором';}
    if(retR==='(без результата)')bad=bad||'результат прежней отбрасывается';
    if(bad){L.why=bad;continue;}
    L.ok=true;L.pre=pre.length;L.post=post.length;L.ret=retR;}});
// барьеры: все прочие загрузочные записи имени (фабрики, полные замены, неблочные формы) — берём строки из простого поиска присваиваний
const otherW={};walk.fullAncestor(ast,(n,st)=>{if(n.type==='AssignmentExpression'&&n.left.type==='Identifier'){const inFn=st.some(a=>/Function/.test(a.type)&&a!==n);const top=ast.body.indexOf(st[1]);
  if(!inFn)(otherW[n.left.name]=otherW[n.left.name]||[]).push(top);}});
const byName={};for(const L of layers)(byName[L.name]=byName[L.name]||[]).push(L);
// вырезаемые блоки (CINE·PROTO, BG·PROTO, ARCH·N): слияние не пересекает их границ — иначе ломается вырезаемость и снятие патчей
const segs=[];for(const mk of ['CINE·PROTO','BG·PROTO']){const a=src.indexOf('▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ '+mk),z=src.indexOf('▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲ '+mk);if(a>0&&z>a)segs.push([mk,a,z]);}
{const re=/\/\* ▼▼▼ ARCH·(\d+)/g;let m;while((m=re.exec(src))){const z=src.indexOf('▲▲▲ ARCH·'+m[1]+' · КОНЕЦ',m.index);segs.push(['ARCH·'+m[1],m.index,z<0?src.length:z]);}}
const segOf=pos=>{let s='база';for(const [n,a,z] of segs)if(pos>a&&pos<z)s=n;return s;};
for(const L of layers)L.seg=segOf(ast.body[L.idx].range[0]);
const runs=[];let merged=0;
for(const [f,arr] of Object.entries(byName)){arr.sort((a,b)=>a.idx-b.idx);
  const barriers=(otherW[f]||[]).filter(i=>!arr.some(L=>L.idx===i));
  let cur=[];const flush=()=>{if(cur.length>=2){runs.push({name:f,layers:cur.map(L=>L.line),n:cur.length});merged+=cur.length-1;}cur=[];};
  for(const L of arr){if(!L.ok){flush();continue;}
    if(cur.length){const prev=cur[cur.length-1];let why=null;
      if(prev.seg!==L.seg)why='граница вырезаемого блока '+prev.seg+' → '+L.seg;
      else if(barriers.some(i=>i>prev.idx&&i<L.idx))why='барьер (фабрика/замена)';
      else for(let i=prev.idx+1;i<L.idx&&!why;i++){const s=ast.body[i];if(s.type==='FunctionDeclaration'||s.type==='EmptyStatement')continue;
        if(s.type==='BlockStatement'&&layers.some(x=>x.idx===i))continue;const c=loadReach(s,f);if(c)why='вызов при загрузке между слоями, достигающий '+f+': '+c;}
      if(why){L.gap=why;flush();}}
    cur.push(L);}
  flush();}
const notOk={};for(const L of layers)if(!L.ok)notOk[L.why]=(notOk[L.why]||0)+1;
const gaps={};for(const L of layers)if(L.gap)gaps[L.gap.split(':')[0]]=(gaps[L.gap.split(':')[0]]||0)+1;
fs.writeFileSync(process.argv[3],JSON.stringify({layers,runs,notOk,gaps},null,0));
console.log(`m6: слоёв-блоков ${layers.length}, пригодных ${layers.filter(l=>l.ok).length}; серий для слияния ${runs.length}, слоёв убирается ${merged}`);
console.log('непригодны:',JSON.stringify(notOk));console.log('разрывы серий:',JSON.stringify(gaps));
for(const r of runs.sort((a,b)=>b.n-a.n))console.log('  ',r.name,r.n,'слоёв · строки',r.layers.join(','));
