#!/usr/bin/env python3
# Корректирующее обновление · gkeys6 — порядок ключей G (st5 gkeys) с синхронизацией по таймеру autoClick132.
#   python3 tools6/gkeys6.py <эталон.html> <кандидат.html> <папка> [--reps 2] [--nosettle]
# Причина: autoClick132 (1.3.2) ставится setTimeout(…,500) и (…,1500) от начала скрипта и, пока игра в меню и звук не запущен,
# добавляет ключ G.autoClick132. Исходный стенд снимал ключи через ~470–1200 мс после навигации — до или после таймера, как повезёт.
# Здесь перед сценарием стенд ЖДЁТ СОБЫТИЯ: оба разовых таймера autoClick132 отработали (performance.now() ≥ 2600 мс от навигации,
# от навигации: второй таймер ставится через 1500 мс от НАЧАЛА СКРИПТА, а скрипт стартует через 100–400 мс после навигации; проверяется условием,
# а не паузой), и записывает, сработал ли клик. Ключ из сравнения НЕ исключается.
# Первый прогон (ожидание таймеров) показал, что одного ожидания мало: G.autoClick132 = 0 или 3 в A/A одной сборки — клик идёт,
# только пока звук ещё не запущен, а момент запуска AudioContext в безголовом браузере не детерминирован. Поэтому окружение стенда
# фиксируется так же для обеих сборок: --autoplay-policy=no-user-gesture-required (звук запускается без жеста, клик не нужен).
# Эталон и кандидат снимаются в одном запуске поочерёдно (A B A B …); A/A и B/B — повторы той же сборки.
# Итог: <папка>/gkeys6.json; выход 0 — A/B равны и A/A, B/B равны; 1 — расхождение; 3 — сбой стенда.
import sys,os,json,asyncio,subprocess,hashlib
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));sys.path.insert(0,os.path.join(R,'tools5'));sys.path.insert(0,os.path.join(R,'kit'))
import st5
from playwright.async_api import async_playwright
a=sys.argv[1:]
try:A,B,OUT=[os.path.abspath(x) for x in a[:3]]
except ValueError:print(open(__file__,encoding='utf8').read().split('import sys')[0]);sys.exit(3)
REPS=int(a[a.index('--reps')+1]) if '--reps' in a else 2;SETTLE='--nosettle' not in a
os.makedirs(OUT,exist_ok=True)
async def snap(b,build):
    res={'mode':'gkeys','build':os.path.basename(build),'sha':hashlib.sha256(open(build,'rb').read()).hexdigest()[:16],'a24':False,'off':'','pageFlags':None,'runs':{},'settle':{}}
    for enc,n,kind in [('m10',1200,'trace'),('world',900,'trace'),('m10',0,'probes')]:
        ctx,pg,errs=await st5.page(b,build)
        if SETTLE:
            await pg.wait_for_function("()=>performance.now()>=2600",polling=50,timeout=20000)  # rAF на стенде отключён — опрос по таймеру
            res['settle'][kind+'-'+enc]=await pg.evaluate("()=>({t:Math.round(performance.now()),autoClick132:G.autoClick132||0,state:G.state,ctx:AU.ctx?AU.ctx.state:null,amb:SET.amb})")
        await st5.pf(pg,res);await pg.evaluate(st5.COMMON);await pg.evaluate(st5.SCEN,{'enc':enc})
        k0=await pg.evaluate("()=>Object.keys(G)")
        await pg.evaluate({'trace':st5.TRACE_RUN,'probes':st5.PROBES_RUN}[kind],dict(n=n,names=st5.TRACE))
        k1=await pg.evaluate("()=>Object.keys(G)");res['runs'][kind+'-'+enc]={'log':[k0,k1],'errs':errs[:3]};await ctx.close()
    return res
async def main():
    files={}
    async with async_playwright() as pw:
        AR=['--no-sandbox']+([] if '--nosettle' in a else ['--autoplay-policy=no-user-gesture-required'])
        b=await pw.chromium.launch(executable_path=st5.CHROME,args=AR) if st5.CHROME else await pw.chromium.launch(args=AR)
        for i in range(REPS):
            for tag,bl in (('A',A),('B',B)):
                r=await snap(b,bl);f=os.path.join(OUT,f'gkeys_{tag}{i}.json');json.dump(r,open(f,'w'),ensure_ascii=False);files[f'{tag}{i}']=f
                print(tag,i,json.dumps(r['settle'],ensure_ascii=False),flush=True)
        await b.close()
    return files
try:files=asyncio.run(main())
except Exception as e:print('СБОЙ СТЕНДА',e);json.dump({'status':'ERROR','why':str(e)[:400]},open(os.path.join(OUT,'gkeys6.json'),'w'),ensure_ascii=False);sys.exit(3)
cmp={}
def c(x,y,aa):
    p=subprocess.run([sys.executable,os.path.join(R,'tools5','compare5.py'),files[x],files[y]]+(['--aa'] if aa else []),capture_output=True,text=True)
    cmp[f'{x}~{y}']={'rc':p.returncode,'out':p.stdout[-1200:]};return p.returncode
rc=[c('A0','B0',False)]+[c(f'A0',f'A{i}',True) for i in range(1,REPS)]+[c('B0',f'B{i}',True) for i in range(1,REPS)]+[c(f'A{i}',f'B{i}',False) for i in range(1,REPS)]
st='PASS' if all(x==0 for x in rc) else ('ERROR' if any(x not in (0,1) for x in rc) else 'FAIL')
json.dump({'status':st,'settle':SETTLE,'files':{k:os.path.basename(v) for k,v in files.items()},'cmp':cmp},open(os.path.join(OUT,'gkeys6.json'),'w'),ensure_ascii=False,indent=1)
for k,v in cmp.items():print(k,'rc',v['rc'],v['out'].strip().splitlines()[-1] if v['out'].strip() else '')
print('STATUS',st);sys.exit({'PASS':0,'FAIL':1,'ERROR':3}[st])
