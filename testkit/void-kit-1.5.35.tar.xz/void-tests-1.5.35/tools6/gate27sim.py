# Модель планировщика кадров gate27 (раздел 7 ТЗ) против прежнего правила «now-last<29 → пропуск».
# python3 tools6/gate27sim.py — печатает среднюю частоту обработанных кадров и разброс интервалов для частот экрана и пределов.
import random,statistics as st
def gate_new(cap):
    S={'next':0.0,'disp':0.0,'last':0.0}
    T=1000.0/cap
    def g(now):
        if S['last']:
            d=now-S['last']
            if 0<d<100:S['disp']+=(d-S['disp'])*.1 if S['disp'] else d
        S['last']=now
        tol=min(T*.5,max(1.0,S['disp']*.5))
        if not S['next'] or now<S['next']-T*4 or now-S['next']>T*2:S['next']=now+T;return True
        if now<S['next']-tol:return False
        S['next']+=T
        return True
    return g
def gate_old(cap):
    S={'last':0.0}
    def g(now):
        if now-S['last']<29 and now>=S['last'] and cap==30:return False
        S['last']=now;return True
    return g
def run(hz,cap,gate,sec=20,jit=.3,seed=1):
    random.seed(seed);vs=1000/hz;g=gate(cap);t=1000.0;pro=[]
    n=int(sec*hz)
    for i in range(n):
        now=t+i*vs+random.uniform(-jit,jit)
        if i==n//2:now+=0  # место для имитации провала
        if g(now):pro.append(now)
    iv=[b-a for a,b in zip(pro,pro[1:])]
    return len(pro)/sec,st.mean(iv),max(iv),min(iv)
print('экран Гц | предел | новый: кадр/с, интервал ср/мин/макс мс | прежний: кадр/с')
for hz in (60,59.94,75,90,120,144,165,240):
    for cap in (60,30):
        a=run(hz,cap,gate_new);b=run(hz,cap,gate_old)
        print(f'{hz:7} | {cap:3} | {a[0]:6.2f}  {a[1]:5.2f}/{a[3]:5.2f}/{a[2]:5.2f} | {b[0]:6.2f}')
# провал: вкладка в фоне 3 с, затем возврат
g=gate_new(60);vs=1000/144;t=0.0;cnt=0;burst=0
for i in range(2000):
    now=1000+i*vs+(3000 if i>1000 else 0)
    r=g(now);cnt+=r
    if 1000<i<1010 and r:burst+=1
print('после возврата из фона (144 Гц, предел 60): обработано за первые 10 вызовов',burst,'(без «догонки»: ≤ 5)')
