#!/usr/bin/env python3
# Этап 6+7 · save6 — совместимость настроек и сохранений между версиями (изолированные профили браузера; реальные сохранения
# игроков не затрагиваются: каждый сценарий — новый контекст Playwright с пустым localStorage).
#   python3 tools6/save6.py <новая.html> <1.5.24.html> <out.json>
import asyncio,json,sys,os
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','tools5'))
import st5
from playwright.async_api import async_playwright
NEW,OLD,OUT=[os.path.abspath(x) for x in sys.argv[1:4]]
async def ctxp(b,touch):
    ctx=await b.new_context(viewport={'width':390,'height':844} if touch else {'width':1280,'height':800},has_touch=touch,is_mobile=touch)
    pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:200]));return ctx,pg,errs
async def go(pg,f):await pg.goto('file://'+f);await pg.wait_for_timeout(500)
S=lambda k:"()=>localStorage.getItem('%s')"%k
async def main():
    R={}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path=st5.CHROME,args=['--no-sandbox'])
        async def scen(name,touch,fn):
            ctx,pg,errs=await ctxp(b,touch)
            try:r=await fn(pg)
            except Exception as e:r={'exc':str(e)[:300]}
            r['errs']=errs[:3];R[name]=r;await ctx.close();print(name,json.dumps(r,ensure_ascii=False)[:500],flush=True)
        async def s1(pg):
            await go(pg,NEW);a=await pg.evaluate("()=>({cap:SET.fpsCap,capD:SET.fpsCapD,fps:SET.fps,raw:localStorage.getItem('void_settings')})");return {'чистый профиль':a,'ok':a['cap']==0 and a['capD']==0 and a['raw'] is None}
        await scen('S01 чистый профиль: оба предела «без ограничения», при загрузке ничего не записано',True,s1)
        async def s2(pg):
            await go(pg,OLD);await pg.evaluate("()=>{SET.fps=60;saveSet();}");await go(pg,NEW)
            a=await pg.evaluate("()=>({cap:SET.fpsCap,fps:SET.fps,stored:'fpsCap' in (JSON.parse(localStorage.getItem('void_settings'))||{})})");return dict(a,ok=a['cap']==0 and a['fps']==60 and not a['stored'])
        await scen('S02 телефон, 1.5.24 с «60» → новая: без ограничения (как и было), запись при загрузке не делается',True,s2)
        async def s3(pg):
            await go(pg,OLD);await pg.evaluate("()=>{SET.fps=30;saveSet();}");await go(pg,NEW)
            a=await pg.evaluate("()=>({cap:SET.fpsCap,fps:SET.fps,gate:fpsCap27()})");return dict(a,ok=a['cap']==30 and a['gate']==30)
        await scen('S03 телефон, 1.5.24 с «30» → новая: предел 30',True,s3)
        async def s4(pg):
            await go(pg,NEW);await pg.evaluate("()=>{fpsPick27('30');}");await go(pg,OLD)
            o=await pg.evaluate("()=>({fps:SET.fps,raw:JSON.parse(localStorage.getItem('void_settings'))})")
            await pg.evaluate("()=>{SET.amb=!SET.amb;saveSet();}");keep=await pg.evaluate("()=>('fpsCap' in JSON.parse(localStorage.getItem('void_settings')))")
            await go(pg,NEW);n=await pg.evaluate("()=>({cap:SET.fpsCap,fps:SET.fps})")
            return {'в 1.5.24':o['fps'],'ключ сохранён после записи 1.5.24':keep,'снова новая':n,'ok':o['fps']==30 and keep and n['cap']==30}
        await scen('S04 откат: новая (30) → 1.5.24 (работает её «30», ключ fpsCap не теряется при её записи) → новая (30)',True,s4)
        async def s5(pg):
            await go(pg,NEW);await pg.evaluate("()=>{fpsPick27('0');}");await go(pg,OLD);o=await pg.evaluate("()=>SET.fps");await go(pg,NEW);n=await pg.evaluate("()=>SET.fpsCap")
            return {'1.5.24':o,'новая':n,'ok':o==60 and n==0}
        await scen('S05 откат: «без ограничения» → 1.5.24 видит «60» (у неё это и есть без ограничения) → обратно без ограничения',True,s5)
        async def s6(pg):
            await go(pg,NEW);await pg.evaluate("()=>{fpsPick27('60');}");a=await pg.evaluate("()=>({capD:SET.fpsCapD,cap:SET.fpsCap,fps:SET.fps})");return dict(a,ok=a['capD']==60 and a['cap']==0 and a['fps']==60)
        await scen('S06 ПК: выбор 60 меняет только предел ПК; ключ телефона и старый ключ fps не тронуты',False,s6)
        async def s7(pg):
            await go(pg,NEW);out={}
            for raw in ('{не json','[1,2]','{"fpsCap":"x","fpsCapD":45,"fps":30}','null'):
                await pg.evaluate("(r)=>localStorage.setItem('void_settings',r)",raw);await go(pg,NEW)
                out[raw]=await pg.evaluate("()=>({cap:SET.fpsCap,capD:SET.fpsCapD,ok:G.state==='menu'})")
            ok=all(v['ok'] for v in out.values()) and out['{"fpsCap":"x","fpsCapD":45,"fps":30}']=={'cap':0,'capD':0,'ok':True}
            return {'варианты':out,'ok':ok}
        await scen('S07 повреждённые настройки: игра загружается, недопустимые значения пределов → без ограничения',True,s7)
        async def s8(pg):
            await go(pg,OLD);await pg.evaluate("()=>{startWorld(true);saveWorld();toMenu();}")
            w0=await pg.evaluate(S('void_world'));await go(pg,NEW);w1=await pg.evaluate(S('void_world'));ok_load=await pg.evaluate("()=>!!G.save")
            return {'void_world не изменён загрузкой новой версии':w0==w1,'прогресс загружен':ok_load,'длина':len(w0 or ''),'ok':w0 is not None and w0==w1 and ok_load}
        await scen('S08 прогресс 1.5.24: новая версия загружает его и не переписывает при загрузке',True,s8)
        async def s9(pg):
            await go(pg,NEW);await pg.evaluate("()=>{localStorage.setItem('void_world_bad','{\"x\":1}');}");await go(pg,NEW)
            a=await pg.evaluate("()=>({bad:localStorage.getItem('void_world_bad'),state:G.state})");return dict(a,ok=a['bad']=='{"x":1}' and a['state']=='menu')
        await scen('S09 void_world_bad сохраняется как есть',True,s9)
        async def s10(pg):
            await go(pg,NEW);await pg.evaluate("()=>{localStorage.setItem('void_settings',JSON.stringify({autoFs:true,fps:30}));}");await go(pg,NEW)
            a=await pg.evaluate("()=>({fsMode:SET.fsMode,cap:SET.fpsCap,state:G.state})");return dict(a,ok=a['cap']==30 and a['state']=='menu')
        await scen('S10 настройки 0.6.x (autoFs) загружаются; «30» → предел 30',True,s10)
        async def s11(pg):
            await go(pg,NEW);await pg.evaluate("()=>{fpsPick27('30');}")
            st=await pg.evaluate("()=>JSON.parse(localStorage.getItem('void_settings'))")
            ctx2=await b.new_context(viewport={'width':1280,'height':800});pg2=await ctx2.new_page();await pg2.goto('file://'+NEW);await pg2.wait_for_timeout(300)
            await pg2.evaluate("(s)=>{localStorage.setItem('void_settings',JSON.stringify(s));cloudReloadState();}",st);a=await pg2.evaluate("()=>({cap:SET.fpsCap,capD:SET.fpsCapD,gate:fpsCap27()})");await ctx2.close()
            return dict(a,ok=a['cap']==30 and a['capD']==0 and a['gate']==0)
        await scen('S11 телефон выбрал 30 → настройки через облако на ПК: предел ПК не меняется',True,s11)
        async def s13(pg):
            await go(pg,NEW);await pg.evaluate("()=>{fpsPick27('60');}");await go(pg,OLD);await pg.evaluate("()=>{SET.fps=30;saveSet();}")
            await go(pg,NEW);a=await pg.evaluate("()=>({cap:SET.fpsCap,fps:SET.fps,gate:fpsCap27(),seg:[...document.querySelectorAll('[data-seg=fps] [data-v]')].map(b=>b.dataset.v)})")
            await pg.evaluate("()=>openSettings&&openSettings()");on=await pg.evaluate("()=>{const b=document.querySelector('[data-seg=fps] .on');return b?b.dataset.v:null;}")
            return dict(a,on=on,ok=a['gate']==30 and a['fps']==30 and on=='30')
        await scen('S13 новая (60) → 1.5.24, игрок выбрал там «30» → новая: действует 30 и на экране выбрано 30 (последний выбор игрока)',True,s13)
        async def s14(pg):
            await go(pg,NEW);await pg.evaluate("()=>{fpsPick27('30');}");await go(pg,OLD);await pg.evaluate("()=>{SET.fps=60;saveSet();}")
            await go(pg,NEW);a=await pg.evaluate("()=>({cap:SET.fpsCap,fps:SET.fps,gate:fpsCap27()})")
            await pg.evaluate("()=>{fpsPick27('60');}");b2=await pg.evaluate("()=>({cap:SET.fpsCap,fps:SET.fps,gate:fpsCap27()})")
            return dict(a,после_выбора_60=b2,ok=a['gate']==0 and b2['gate']==60 and b2['cap']==60)
        await scen('S14 новая (30) → 1.5.24, игрок выбрал там «60» → новая: без ограничения (как «60» в 1.5.24); новый выбор снова действует',True,s14)
        S12JS="""async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));const o={};
          localStorage.clear();startWorld(true);if(G.prologue)prologueEnd();G.save.lom=777;G.save.cleared=3;saveWorld();toMenu();await w8(200);
          const real0=localStorage.getItem('void_world');o.real0=!!real0;
          const k=G.save;const bad=new Proxy({},{get(){throw new Error('проба');}});let ex=null;
          try{doneCountS(bad);}catch(e){ex=String(e&&e.message);}o.swapException=ex;o.swapRestoredAfterException=G.save===k;if(G.save!==k)G.save=k;
          const n=doneCountS(JSON.parse(real0));o.swapRestored=G.save===k;o.swapCount=n;
          dvCopyMine();await w8(300);o.devOn=dvOn();o.realIntactAfterCopy=localStorage.getItem('void_world')===real0;o.sandboxLom=G.save&&G.save.lom;o.sandboxIsOtherObject=G.save!==k;
          G.save.lom=111;dvSnapSave(1);const s1=JSON.parse(localStorage.getItem('void_devsnap1')||'null');o.snapLom=s1&&s1.save.lom;o.snapVer=!!(s1&&s1.ver);
          G.save.lom=222;const s2=JSON.parse(localStorage.getItem('void_devsnap1')||'null');o.snapIndependentOfLive=!!s2&&s2.save.lom===111;
          const before=G.save;dvSnapLoad(1);await w8(300);o.loadedLom=G.save&&G.save.lom;o.loadedIsNewObject=G.save!==before;o.devOnAfterLoad=dvOn();
          o.realIntactAfterLoad=localStorage.getItem('void_world')===real0;
          DEVW.exit();await w8(300);o.devOnAfterExit=dvOn();o.realLomAfterExit=G.save&&G.save.lom;o.realIntactAfterExit=localStorage.getItem('void_world')===real0;
          o.realLsLom=JSON.parse(localStorage.getItem('void_world')).lom;return o;}"""
        S12={}
        async def s12(pg,which):
            await go(pg,which);return await pg.evaluate(S12JS)
        for tag,f in (('1.5.24',OLD),('новая',NEW)):
            ctx,pg,errs=await ctxp(b,False)
            try:S12[tag]=await s12(pg,f)
            except Exception as e:S12[tag]={'exc':str(e)[:300]}
            S12[tag]['errs']=errs[:3];await ctx.close()
        n,o=S12['новая'],S12['1.5.24']
        need=['real0','swapRestored','devOn','realIntactAfterCopy','sandboxIsOtherObject','snapVer','snapIndependentOfLive','loadedIsNewObject','devOnAfterLoad','realIntactAfterLoad','realIntactAfterExit']
        okn='exc' not in n and all(n.get(x) is True for x in need) and n.get('swapRestoredAfterException') is True and n['sandboxLom']==777 and n['snapLom']==111 and n['loadedLom']==111 and n['devOnAfterExit'] is False and n['realLomAfterExit']==777 and n['realLsLom']==777 and not n['errs']
        same={k:(o.get(k),n.get(k)) for k in set(o)|set(n) if k not in ('errs',) and o.get(k)!=n.get(k)}
        R['S12 песочница разработчика: копия прогресса, снимок (копия, не ссылка), загрузка снимка, выход; временная подмена G.save с исключением; настоящее сохранение не тронуто']={
          'новая':n,'1.5.24':o,'отличия 1.5.24 → новая':same,
          'ожидаемое отличие':'swapRestoredAfterException: 1.5.24 при исключении внутри временной подмены (doneCountS) оставляла G.save подменённым; ARCH·89 (saveWith6, finally) восстанавливает',
          'ok':okn and set(same)<= {'swapRestoredAfterException'} and o.get('swapRestoredAfterException') is False}
        print('S12',json.dumps(R[list(R)[-1]],ensure_ascii=False)[:900],flush=True)
        await b.close()
    json.dump(R,open(OUT,'w'),ensure_ascii=False,indent=1)
    print('save6:',sum(1 for v in R.values() if v.get('ok')),'из',sum(1 for v in R.values() if v.get('ok') is not None),'сценариев выполнены; не проверено:',sum(1 for v in R.values() if v.get('ok') is None))
asyncio.run(main())
