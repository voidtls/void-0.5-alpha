#!/usr/bin/env python3
# Корректирующее обновление 1.5.35 · accept6 — итоговая приёмка (замена stage6/final6.sh).
#   python3 tools6/accept6.py                    — все шаги по порядку (полная приёмка)
#   python3 tools6/accept6.py --steps a,b,…      — только эти шаги (ЧАСТИЧНЫЙ прогон: успехом приёмки не считается)
#   python3 tools6/accept6.py --group fps,k      — только группы
#   python3 tools6/accept6.py --list             — список шагов и групп
#   python3 tools6/accept6.py --selftest         — самопроверка механизма приёмки (попытки получить ложный PASS)
#   --out <папка>  — папка прогона (должна быть новой или пустой); по умолчанию out7/accept/<дата-время>
#   --keep-going   — не останавливаться после ERROR в шаге сборки (по умолчанию без сборки остальные шаги не запускаются)
# Статусы шага: PASS — проверка выполнена и прошла; FAIL — выполнена и выявила отклонение; ERROR — не выполнена достоверно
# (нет инструмента, тайм-аут, нет или устарел результат, сбой стенда); KNOWN — выполнена, найденное отклонение ТОЧНО совпадает
# с записью реестра ref6/known6.json (любое другое отклонение — FAIL). KNOWN не прячется под PASS и печатается отдельно.
# Коды выхода: 0 — полный прогон, все шаги PASS/KNOWN; 1 — есть FAIL (и нет ERROR); 2 — есть ERROR; 3 — ошибка вызова
# (неизвестный шаг/группа/аргумент, папка прогона занята); 4 — частичный прогон, выбранные шаги PASS/KNOWN (приёмка не завершена).
# «ПРИЁМКА ПРОЙДЕНА» печатается только при коде 0. Все команды — списки аргументов без shell: пути с пробелами и кириллицей допустимы.
# Каждый шаг пишет журналы в <папка>/steps/<шаг>/; результаты старых прогонов не читаются: каждый файл-результат проверяется на
# существование и на время записи не раньше начала шага.
import sys,os,json,time,subprocess,hashlib,shutil,re,traceback,tempfile,glob,statistics
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY=sys.executable;T5=os.path.join(R,'tools5');T6=os.path.join(R,'tools6');KIT=os.path.join(R,'kit');K6=os.path.join(R,'kit6');REF=os.path.join(R,'ref6')
FROZEN={'1.5.24':'76753e3338ab36eefe8e6e5f945428a341de27b8e0f29b4fd8235ef0ad897776','1.5.35':'b936a549366321b63b8f0c6ac5a8c34013150cffac9ea584b71d3c09c7f4c034',
        'chain':[('85','1ccfbc01e1716fbc'),('86','5d240a4b3c25ed3a'),('87','1322deff8c5e347a'),('88','0a10696778185013'),('89','52e33e418ef9bdd7'),('89b','984ed836fc856f93'),
                 ('90a','7f155537b54a43c5'),('90b','26fddb1e33937ae3'),('91','8317d6ebbbde5cf4'),('92','f859dc1d40f847ed'),('93','b936a549366321b6')]}
KEYS=[k for k,_ in FROZEN['chain']]
class Infra(Exception):pass
class Usage(Exception):pass
def sha(p):
    with open(p,'rb') as f:return hashlib.sha256(f.read()).hexdigest()
class Ctx:
    def __init__(s,run,known):s.run=run;s.known=known;s.B0=os.path.join(R,'builds5','void_b164.html');s.B=None;s.bld={};s.step=None;s.t0=0;s.logs=[]
    def d(s,*p):x=os.path.join(s.run,'steps',s.step,*p);os.makedirs(os.path.dirname(x) if p else x,exist_ok=True);return x
    def sh(s,label,argv,cwd=R,env=None,timeout=3600,ok=(0,)):
        """запуск без shell; журнал — steps/<шаг>/<label>.log; нет программы/тайм-аут → Infra; возвращает код выхода"""
        log=s.d(label+'.log');e=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');e.update(env or {})
        if not shutil.which(argv[0]) and not os.path.isfile(argv[0]):raise Infra(f'нет программы: {argv[0]}')
        for a in argv[1:2]:
            if a.endswith(('.py','.js')) and not os.path.isfile(a):raise Infra(f'нет инструмента: {os.path.relpath(a,R)}')
        t=time.time()
        with open(log,'w',encoding='utf8') as L:
            L.write('# '+json.dumps({'argv':argv,'cwd':cwd,'env':env or {},'start':time.strftime('%F %T')},ensure_ascii=False)+'\n');L.flush()
            try:p=subprocess.run(argv,cwd=cwd,env=e,stdout=L,stderr=subprocess.STDOUT,timeout=timeout);rc=p.returncode
            except subprocess.TimeoutExpired:L.write(f'\n# ТАЙМ-АУТ {timeout} с\n');raise Infra(f'{label}: тайм-аут {timeout} с')
            except OSError as x:raise Infra(f'{label}: не запускается: {x}')
            L.write(f'\n# код выхода {rc}, {round(time.time()-t)} с\n')
        s.logs.append(os.path.relpath(log,s.run));return rc
    def text(s,label):return open(s.d(label+'.log'),encoding='utf8',errors='replace').read()
    def fresh(s,p):
        if not os.path.exists(p):raise Infra('нет результата: '+os.path.relpath(p,s.run) if p.startswith(s.run) else 'нет результата: '+p)
        if os.path.getmtime(p)<s.t0-1:raise Infra('результат старше начала шага (не свежий): '+p)
        return p
    def J(s,p):return json.load(open(s.fresh(p),encoding='utf8'))
    def need_B(s):
        if s.B:return s.B
        raise Infra('нет собранной 1.5.35: шаг build не выполнен в этом прогоне')
# ---------------------------------------------------------------- шаги
def st_env(c):
    det={};bad=[];pins=json.load(open(os.path.join(REF,'deps6.json'),encoding='utf8'))
    det['python']=sys.version.split()[0]
    if sys.version_info<(3,10):bad.append('python < 3.10')
    try:
        import importlib.metadata as im;det['playwright']=im.version('playwright')
        if det['playwright']!=pins['playwright']:bad.append(f"playwright {det['playwright']} ≠ {pins['playwright']}")
    except Exception as e:raise Infra('playwright для Python не установлен: '+str(e)[:200])
    if not shutil.which('node'):raise Infra('нет node')
    det['node']=subprocess.run(['node','--version'],capture_output=True,text=True).stdout.strip()
    if int(det['node'].lstrip('v').split('.')[0])<18:bad.append('node < 18')
    for m,v in pins['node_modules'].items():
        pj=os.path.join(R,'node_modules',m,'package.json')
        if not os.path.exists(pj):raise Infra('нет node_modules/'+m)
        got=json.load(open(pj))['version'];det[m]=got
        if got!=v:bad.append(f'{m} {got} ≠ {v}')
    kp=os.path.join(R,'.kitpaths.json')
    if not os.path.exists(kp):raise Infra('комплект не настроен: python3 setup6.py')
    k=json.load(open(kp));det['chrome']=k['chrome']
    if os.path.realpath(k['kit'])!=os.path.realpath(KIT):raise Infra('комплект перенесён после настройки: снова python3 setup6.py')
    if not os.path.exists(k['chrome']):raise Infra('браузер не найден: '+k['chrome'])
    rc=c.sh('browser',[PY,'-c',"import sys,asyncio\nfrom playwright.async_api import async_playwright\nasync def m():\n async with async_playwright() as p:\n  b=await p.chromium.launch(executable_path=sys.argv[1],args=['--no-sandbox']);pg=await b.new_page();print('2+2=',await pg.evaluate('2+2'),b.version);await b.close()\nasyncio.run(m())",k['chrome']],timeout=120)
    if rc or '2+2= 4' not in c.text('browser'):raise Infra('браузер не запускается (см. browser.log)')
    det['chromium']=c.text('browser').split('2+2= 4')[1].split()[0]
    if pins.get('chromium') and not det['chromium'].startswith(pins['chromium']):bad.append(f"chromium {det['chromium']} ≠ {pins['chromium']}")
    if bad:raise Infra('окружение не соответствует закреплённым версиям: '+'; '.join(bad))
    return 'PASS',det
def norm_text(p,kp):
    t=open(p,'rb').read()
    try:s=t.decode('utf8');return s.replace(kp['kit'],'@@KIT@@').replace(kp['chrome'],'@@CHROME@@').encode('utf8')
    except UnicodeDecodeError:return t
def kit_manifest(kp):
    out={}
    for base in ('kit','kit6'):
        for r_,ds,fs in os.walk(os.path.join(R,base)):
            ds[:]=[d for d in ds if d not in('__pycache__','out')]
            for f in fs:
                p=os.path.join(r_,f);rel=os.path.relpath(p,R)
                if not(f.endswith(('.py','.js','.html')) or re.match(r'arch_.*\.json$',f) or re.match(r'jobs_.*\.json$',f) or f in('k80.jsonl','e24.jsonl') or ('reg20' in rel and f.endswith('.log')) or rel.startswith('kit6'+os.sep+'data')):continue
                if f.endswith('.js') and os.path.exists(p[:-3]) and p[:-3].endswith('.html'):continue  # .html.js — производные
                out[rel]=hashlib.sha256(norm_text(p,kp)).hexdigest()[:16]
    return out
def st_kit(c):
    kp=json.load(open(os.path.join(R,'.kitpaths.json')));ref=json.load(open(os.path.join(REF,'kit_manifest.json')))
    cur=kit_manifest(kp);ch=sorted(k for k in ref if cur.get(k)!=ref[k]);extra=sorted(set(cur)-set(ref))
    rc=c.sh('mkkit6_check',[PY,os.path.join(T6,'mkkit6.py'),'--check'])
    det={'файлов':len(ref),'изменено_или_нет':ch[:20],'лишние':extra[:20],'mkkit6':rc}
    return ('PASS' if not ch and not extra and rc==0 else 'FAIL'),det
def st_build(c):
    if sha(c.B0)!=FROZEN['1.5.24']:raise Infra('исходная сборка builds5/void_b164.html не 1.5.24 (SHA)')
    out=c.d('b');rc=c.sh('chain',[PY,os.path.join(R,'stage6','s6.py'),'chain',c.B0,out]+KEYS)
    if rc:return 'FAIL',{'s6 chain':rc}
    got=[l.split()[:2] for l in c.text('chain').splitlines() if l and not l.startswith('#')]
    got=[(a,b) for a,b in got if a in KEYS];bad=[(k,g,w) for (k,w),(k2,g) in zip(FROZEN['chain'],got) if g!=w or k!=k2]
    for k in KEYS:c.bld[k]=c.fresh(os.path.join(out,'b%s.html'%k))
    fin=c.bld['93'];same=open(fin,'rb').read()==open(os.path.join(R,'builds6','void_b175.html'),'rb').read()
    det={'шаги':dict(got),'расхождения SHA':bad,'1.5.35 SHA':sha(fin)[:16],'= builds6/void_b175.html побайтно':same}
    if not bad and len(got)==len(KEYS) and same and sha(fin)==FROZEN['1.5.35']:c.B=fin;return 'PASS',det
    return 'FAIL',det
def st_strip(c):
    B=c.need_B();res={}
    res['все 93…85 → 1.5.24']=c.sh('strip_all',[PY,os.path.join(R,'stage6','s6.py'),'strip',B,c.B0]+KEYS)
    prev=c.B0
    for k in KEYS:res[k]=c.sh('strip_'+k,[PY,os.path.join(R,'stage6','s6.py'),'strip',c.bld[k],prev,k]);prev=c.bld[k]
    return ('PASS' if all(v==0 for v in res.values()) else 'FAIL'),{'код выхода':res}
def st_rollback(c):
    B=c.need_B();o=c.d('void_1.5.24_restored.html');rc=c.sh('rollback',[PY,os.path.join(T6,'rollback6.py'),B,o])
    ok=rc==0 and open(c.fresh(o),'rb').read()==open(c.B0,'rb').read()
    return ('PASS' if ok else 'FAIL'),{'rollback6':rc,'= 1.5.24 побайтно':ok}
def st_static(c):
    B=c.need_B();det={};bad=[]
    det['own6']=c.sh('own6',['node',os.path.join(T6,'own6.js'),B,'--json',c.d('own6.json')])
    det['selftest6']=c.sh('selftest6',[PY,os.path.join(T6,'selftest6.py'),B],timeout=1800)
    det['tdep6']=c.sh('tdep6',[PY,os.path.join(T6,'tdep6.py'),c.B0,B,'--json',c.d('tdep6.json')])
    for k in ('own6','selftest6','tdep6'):
        if det[k]:bad.append(k)
    for t,ref in (('g6','g6.json'),('w6','w6.json'),('chains6','chains6.json'),('init6','init6.json')):
        o=c.d(t+'.json');rc=c.sh(t,['node',os.path.join(T6,t+'.js'),B,o])
        def L(p):j=json.load(open(p,encoding='utf8'));j.pop('build',None) if isinstance(j,dict) else None;return j  # поле build — имя файла сборки
        same=rc==0 and L(c.fresh(o))==L(os.path.join(REF,'static175',ref));det[t]='равно эталону' if same else f'код {rc}, ОТЛИЧАЕТСЯ'
        if not same:bad.append(t)
    return ('PASS' if not bad else 'FAIL'),dict(det,нарушения=bad)
def st_arch(c):
    B=c.need_B();det={};bad=[]
    D=os.path.join(K6,'data');AC=[PY,os.path.join(T6,'archcheck6.py'),'diff']
    for tag,b in (('1.5.24',c.B0),('1.5.35',B)):
        det[f'archcheck6 v1 {tag}']=c.sh(f'ac1_{tag}',AC+[os.path.join(KIT,'arch_fp_v46.json'),b,os.path.join(KIT,'arch_allow_74.json'),'--exact',os.path.join(D,'arch_exact86.json')])
        det[f'archcheck6 v2 {tag}']=c.sh(f'ac2_{tag}',AC+[os.path.join(KIT,'arch_fp_v47v2.json'),b,os.path.join(KIT,'arch_allow_70_74.json'),'--exact',os.path.join(D,'arch_exact86v2.json')],env={'ARCHCHECK_V2':'1'})
    det['merge86 1.5.25→1.5.26→1.5.35']=c.sh('merge86_pair',['node',os.path.join(T6,'merge86.js'),c.bld['85'],c.bld['86'],B,'--json',c.d('merge86_pair.json')])
    det['merge86 1.5.24→1.5.35']=c.sh('merge86_full',['node',os.path.join(T6,'merge86.js'),c.B0,B,'--json',c.d('merge86_full.json')])
    bad+=[k for k,v in det.items() if v]
    # прежний archcheck (исторический допуск по именам): что именно он видит в 1.5.35
    c.sh('archcheck_hist',[PY,os.path.join(KIT,'archcheck.py'),'diff',os.path.join(KIT,'arch_fp_v46.json'),B,os.path.join(KIT,'arch_allow_74.json')],ok=(0,1))
    try:det['исторический archcheck видит']=json.loads(c.text('archcheck_hist').splitlines()[1])['violations']
    except Exception:det['исторический archcheck видит']='?'
    # мутанты: обязаны быть отвергнуты
    md=c.d('mut');rc=c.sh('mut86',[PY,os.path.join(T6,'mut86.py'),B,md])
    if rc:raise Infra('мутанты не созданы (mut86)')
    M=json.loads(c.text('mut86').splitlines()[1]);mres={}
    for m,p in M.items():
        a1=c.sh(f'{m}_ac1',AC+[os.path.join(KIT,'arch_fp_v46.json'),p,os.path.join(KIT,'arch_allow_74.json'),'--exact',os.path.join(D,'arch_exact86.json')])
        a2=c.sh(f'{m}_ac2',AC+[os.path.join(KIT,'arch_fp_v47v2.json'),p,os.path.join(KIT,'arch_allow_70_74.json'),'--exact',os.path.join(D,'arch_exact86v2.json')],env={'ARCHCHECK_V2':'1'})
        g=c.sh(f'{m}_merge86',['node',os.path.join(T6,'merge86.js'),c.B0,p]);mres[m]={'archcheck6 v1':a1,'v2':a2,'merge86':g}
    det['мутанты (1 = отвергнут)']=mres
    need_ac={'m86_merged','m86_other','m86_behav'}
    if set(mres)!={'m86_merged','m86_other','m86_post','m86_behav'}:bad.append('набор мутантов не тот')
    if not(all(v['merge86']==1 for v in mres.values()) and all(mres[m]['archcheck6 v1']==1 and mres[m]['v2']==1 for m in need_ac)):bad.append('мутант не отвергнут')
    for f in glob.glob(os.path.join(md,'*.html')):os.remove(f)
    return ('PASS' if not bad else 'FAIL'),dict(det,нарушения=bad)
def st_trace(c):
    c.need_B();o={}
    for tag,b in (('A',c.bld['85']),('B',c.bld['86']),('A2',c.bld['85'])):
        o[tag]=c.d(f'tr_{tag}.json');rc=c.sh(f'run_{tag}',[PY,os.path.join(T6,'trace86.py'),'run',b,o[tag]],timeout=1800)
        if rc:raise Infra(f'trace86 run {tag}: код {rc}')
        c.fresh(o[tag])
    rc=c.sh('cmp',[PY,os.path.join(T6,'trace86.py'),'cmp',o['A'],o['B'],o['A2'],'--json',c.d('cmp.json')])
    # положительный контроль: мутант m86_behav 1.5.26 (испорчено условие слоя «прыжок» в tutEmit) обязан дать расхождение в слитой функции
    md=c.d('mut');c.sh('mut86',[PY,os.path.join(T6,'mut86.py'),c.bld['86'],md]);mp=os.path.join(md,'m86_behav.html')
    mo=c.d('tr_mut.json');c.sh('run_mut',[PY,os.path.join(T6,'trace86.py'),'run',c.fresh(mp),mo],timeout=1800)
    rcm=c.sh('cmp_mut',[PY,os.path.join(T6,'trace86.py'),'cmp',o['A'],c.fresh(mo),o['A2'],'--json',c.d('cmp_mut.json')])
    for f in glob.glob(os.path.join(md,'*.html')):os.remove(f)
    JM=c.J(c.d('cmp_mut.json'));caught=rcm==1 and bool(JM['merged_diffs'])
    J=c.J(c.d('cmp.json'));det={'вызовов':J['calls'],'вложенных':J['nested'],'вызовов слитых':J['merged_calls'],'A/B по полям':J['A/B'],'A/A по полям':J['A/A'],'мутант пойман в слитой функции':caught,'мутант: расхождения':JM['merged_diffs'][:4]}
    return ('PASS' if rc==0 and caught else ('FAIL' if rc in(0,1) else 'ERROR')),det
def boot_judge(c,ref,new,known):
    A=json.load(open(ref));Bj=c.J(new);fa,fb=A['fns'],Bj['fns']
    got={'changed':sorted(k for k in fa if k in fb and fa[k]!=fb[k]),'new':sorted(set(fb)-set(fa)),'gone':sorted(set(fa)-set(fb))}
    fl={k:[A['pageFlags'].get(k),Bj['pageFlags'].get(k)] for k in set(A['pageFlags'])|set(Bj['pageFlags']) if A['pageFlags'].get(k)!=Bj['pageFlags'].get(k)}
    probs=[]
    for k in('changed','new','gone'):
        if got[k]!=known[k]:probs.append(f"{k}: лишние {sorted(set(got[k])-set(known[k]))[:8]}, недостающие {sorted(set(known[k])-set(got[k]))[:8]}")
    if fl!=known['flags']:probs.append(f'флаги {fl}')
    if A['ael']!=Bj['ael']:probs.append('обработчики событий различаются')
    if Bj.get('errs'):probs.append('ошибки страницы')
    return probs,{k:len(v) for k,v in got.items()}
def stands_common(c,ref,env):
    B=c.need_B();o=c.d('s');rc=c.sh('stands',[PY,os.path.join(T6,'run6.py'),'stands',B,o,'--ref',ref],env=env,timeout=3600)
    if rc not in(0,1):raise Infra(f'run6 stands: код {rc}')
    J=c.J(os.path.join(o,'run.json'));det={};probs=[]
    for m,v in J['stands'].items():
        if not v.get('ok'):raise Infra(f'стенд {m} не выполнен')
        if m=='boot':continue
        det[m]=v.get('cmp')
        if v.get('cmp')!=0:probs.append(f'{m}: расхождение с эталоном')
    bp,cnt=boot_judge(c,os.path.join(ref,'boot.json'),os.path.join(o,'boot.json'),c.known['stands.boot']);det['boot']=cnt;det['boot vs реестр']=bp or 'точно как в реестре'
    if probs or bp:return 'FAIL',dict(det,нарушения=probs+bp)
    return 'KNOWN',dict(det,известное='stands.boot')
def st_stands(c):return stands_common(c,os.path.join(R,'out5','p84','s164'),{})
def st_a24(c):return stands_common(c,os.path.join(R,'out5','p84','s164a24'),{'VOID_A24':'1'})
def st_gkeys(c):
    B=c.need_B();o=c.d('g');rc=c.sh('gkeys6',[PY,os.path.join(T6,'gkeys6.py'),c.B0,B,o,'--reps','2'],timeout=2400)
    J=c.J(os.path.join(o,'gkeys6.json'))
    if rc==3 or J['status']=='ERROR':raise Infra('gkeys6: сбой стенда')
    return ('PASS' if rc==0 and J['status']=='PASS' else 'FAIL'),{'сравнения':{k:v['rc'] for k,v in J['cmp'].items()}}
def st_st6(c):
    B=c.need_B();det={}
    for m in('trans','saveid'):
        for tag,b in(('164',c.B0),('175',B)):
            rc=c.sh(f'{m}_{tag}',[PY,os.path.join(T6,'st6.py'),m,b,c.d(f'{m}_{tag}.json')],timeout=1800)
            if rc:raise Infra(f'st6 {m} {tag}: код {rc}')
            c.fresh(c.d(f'{m}_{tag}.json'))
        det[m]=c.sh(f'{m}_cmp',[PY,os.path.join(T6,'st6.py'),'cmp',c.d(f'{m}_164.json'),c.d(f'{m}_175.json')])
    return ('PASS' if all(v==0 for v in det.values()) else 'FAIL'),det
def st_c5(c):
    B=c.need_B();o=c.d('c5probe.json');rc=c.sh('c5probe',[PY,os.path.join(T6,'c5probe.py'),B,o],timeout=900)
    if rc:raise Infra(f'c5probe: код {rc}')
    J=c.J(o);ok=all(all(v==0 for v in d['beforeReplace'].values()) and not d['afterLoad'] and not d['afterUse'] and not d['errs'] for d in J.values())
    return ('PASS' if ok else 'FAIL'),J
def st_save(c):
    B=c.need_B();o=c.d('save6.json');rc=c.sh('save6',[PY,os.path.join(T6,'save6.py'),B,c.B0,o],timeout=1800)
    if rc:raise Infra(f'save6: код {rc}')
    J=c.J(o);notrun=[k[:3] for k,v in J.items() if v.get('ok') is None];bad=[k[:3] for k,v in J.items() if v.get('ok') is False]
    if notrun:raise Infra('не выполнены сценарии: '+', '.join(notrun))
    return ('PASS' if not bad else 'FAIL'),{'сценариев':len(J),'не прошли':bad}
def kit6_suite(c,name,b,label):
    n_tests=len(re.findall(r"^@test\('",open(os.path.join(K6,name+'.py'),encoding='utf8').read(),re.M))
    rc=c.sh(label,[PY,os.path.join(K6,name+'.py')],cwd=KIT,env={'GAME_URL':'file://'+b,'PYTHONPATH':KIT},timeout=3600)
    t=c.text(label);ok=len(re.findall(r'^OK\s',t,re.M));fl=re.findall(r'^FAIL\s+(\S+)',t,re.M)
    if rc!=0 or ok+len(fl)!=n_tests or 'Traceback' in t:raise Infra(f'{name}: выполнено {ok+len(fl)} из {n_tests} (код {rc})')
    return ok,fl,n_tests
def st_q390(c):
    B=c.need_B();ok,fl,n=kit6_suite(c,'q390',B,'q390')
    return ('PASS' if not fl else 'FAIL'),{'тестов':n,'OK':ok,'FAIL':fl}
def st_shots(c):
    B=c.need_B();o=c.d('shots');rc=c.sh('shots6',[PY,os.path.join(T6,'shots6.py'),B,o],timeout=900)
    if rc:raise Infra(f'shots6: код {rc}')
    J=c.J(os.path.join(o,'shots.json'));pngs=[c.fresh(os.path.join(o,f'set_{k}.png')) for k in J]
    bad=[k for k,v in J.items() if not v.get('seg') or not v.get('inView') or any(x.get('over') for x in v.get('bs',[]))]
    return ('PASS' if len(pngs)==6 and not bad else 'FAIL'),{'снимков':len(pngs),'строка «КАДРЫ» не помещается':bad,'примечание':'снимки — эмуляция размеров в безголовом Chromium; глазами смотреть по инструкции ручной проверки'}
def fps_expect(r):
    hz,cap=r['hz'],r['cap']
    return hz if cap==0 or hz<cap+0.5 else cap
def st_fps(c):
    B=c.need_B();o={}
    for tag,b in(('164',c.B0),('175',B)):
        o[tag]=c.d(f'fps_{tag}.json');rc=c.sh(f'fps_{tag}',[PY,os.path.join(T6,'fps6.py'),'run',b,o[tag]],timeout=3600)
        if rc:raise Infra(f'fps6 {tag}: код {rc}')
    c.sh('sum',[PY,os.path.join(T6,'fps6.py'),'sum',c.fresh(o['164']),c.fresh(o['175'])])
    J=c.J(o['175']);J0=c.J(o['164']);bad=[];known=[];K=[tuple(x) for x in c.known['fps.false_drop_30hz']['rows']]
    drop0={('mob' if r['mob'] else 'pc',r['hz'],r['cap']):bool(r['qc'] or r['low']) for r in J0['runs'] if r['noise']=='ровно'}
    grp={}
    for r in J['runs']:grp.setdefault((r['mob'],r['hz'],r['noise']),[]).append(r)
    for k,v in grp.items():
        n=min(len(x['H']) for x in v)
        if len({tuple(x['H'][:n]) for x in v})!=1:bad.append(f'состояние зависит от предела: {k}')
    for r in J['runs']:
        lab=f"{'ТЕЛ' if r['mob'] else 'ПК'} {r['hz']} Гц предел {r['cap']} {r['noise']}"
        if r['errs']:bad.append(lab+': ошибки страницы')
        if r['noise']=='ровно':
            e=fps_expect(r)
            if abs(r['fpsAvg']-e)>0.5:bad.append(f"{lab}: {r['fpsAvg']} к/с, ожидалось {e}")
            rate=r['stepsWin']/r['winSec']
            if abs(rate-60)>0.75:bad.append(f'{lab}: {rate:.2f} шагов/с')
            drop=bool(r['qc'] or r['low'])
            key=('mob' if r['mob'] else 'pc',r['hz'],r['cap'])
            if drop and r['hz']>=30:
                (known if key in K and drop0.get(key) else bad).append(f'{lab}: снижение качества (q {r["qc"]}, lowFx {r["low"]})'+('' if drop0.get(key) else ' — на 1.5.24 его нет'))
            if not drop and key in K:bad.append(f'{lab}: в реестре известное снижение, а его нет — реестр устарел')
        if 'перегрузка' in r['noise'] and not(r['qc'] and r['low']):bad.append(f'{lab}: настоящая перегрузка не распознана')
    det={'прогонов 1.5.35':len(J['runs']),'нарушения':bad[:20],'известные':known}
    if bad:return 'FAIL',det
    return ('KNOWN' if known else 'PASS'),dict(det,известное='fps.false_drop_30hz' if known else None)
def st_fpsx(c):
    B=c.need_B();o={}
    for tag,b,only in(('175',B,'switch,long,bg,cap30,loops'),('164',c.B0,'long,bg,cap30')):
        o[tag]=c.d(f'fpsx_{tag}.json');rc=c.sh(f'fpsx_{tag}',[PY,os.path.join(T6,'fpsx6.py'),'run',b,o[tag],'--only',only],timeout=5400)
        if rc:raise Infra(f'fpsx6 {tag}: код {rc}')
    c.sh('sum',[PY,os.path.join(T6,'fpsx6.py'),'sum',c.fresh(o['175']),c.fresh(o['164'])])
    J=c.J(o['175']);J0=c.J(o['164']);bad=[];known=[];hs={}
    drop0={r['cap']:bool(r['qDrop'] or r['low']) for r in J0['runs'] if r['kind']=='cap30'}
    for r in J['runs']:
        lab=f"{r['kind']} {'ТЕЛ' if r['mob'] else 'ПК'} {r['hz']} Гц предел {r['cap']}"
        if r['errs']:bad.append(lab+': ошибки страницы')
        if r['kind']=='switch':
            for s in r['segs']:
                e=fps_expect(dict(hz=r['hz'],cap=s['cap']))
                if abs(s['fps']-e)>1:bad.append(f"{lab} → {s['cap']}: {s['fps']} к/с, ожидалось {e}")
                if abs(s['steps']-60)>1.5:bad.append(f"{lab} → {s['cap']}: {s['steps']} шагов/с")
                if s['maxSteps']>3:bad.append(f"{lab} → {s['cap']}: {s['maxSteps']} шагов в одном кадре (рывок)")
        elif r['kind']=='long':
            if abs(r['stepsTotal']-7200)>2:bad.append(f"{lab}: шагов за 120 с {r['stepsTotal']}")
            e=fps_expect(r)   # накопление ошибки: средняя за 120 с против цели (±0,05 к/с = ±6 кадров), окна по 10 с — в пределах квантования ±1 кадр
            if abs(r['all']['fps']-e)>0.05:bad.append(f"{lab}: за 120 с {r['all']['fps']} к/с, цель {e}")
            if abs(r['first10']['fps']-r['last10']['fps'])>0.25:bad.append(f"{lab}: уход частоты {r['first10']['fps']} → {r['last10']['fps']}")
            hs.setdefault(r['hz'],set()).add(r['h7000'])
        elif r['kind']=='bg':
            f=r['firstAfter']
            if not f or f[0][1]>3:bad.append(f'{lab}: после возврата из фона {f[:1]} (шагов в первом кадре > 3)')
            if r['stepsAfter2s'] is None or abs(r['stepsAfter2s']-120)>4:bad.append(f"{lab}: шагов за 2 с после возврата {r['stepsAfter2s']}")
        elif r['kind']=='cap30':
            drop=bool(r['qDrop'] or r['low']);key=('mob',30,r['cap'])
            if drop:(known if key in [tuple(x) for x in c.known['fps.false_drop_30hz']['rows']] and drop0.get(r['cap']) else bad).append(f'{lab}: снижение качества'+('' if drop0.get(r['cap']) else ' — на 1.5.24 его нет'))
    for hz,v in hs.items():
        if len(v)!=1:bad.append(f'{hz} Гц: состояние на шаге 7000 различается между пределами 30 и 60')
    det={'сценариев':len(J['runs']),'нарушения':bad[:20],'известные':known,'циклы rAF (сведения)':J.get('loops')}
    if bad:return 'FAIL',det
    return ('KNOWN' if known else 'PASS'),det
def st_a23v(c):
    B=c.need_B();v=c.d('void_1.5.35_a23v.html');rc=c.sh('a23v6',[PY,os.path.join(T6,'a23v6.py'),B,v])
    if rc:raise Infra('вариант A-23 не создан')
    o={}
    for tag,b in(('base',B),('a23v',c.fresh(v))):
        o[tag]=c.d(f'{tag}.json');rc=c.sh(tag,[PY,os.path.join(T6,'fps6.py'),'run',b,o[tag],'--hz','72,75,90','--caps','30,60,0'],timeout=3600)
        if rc:raise Infra(f'fps6 {tag}: код {rc}')
    A,Bv=c.J(o['base']),c.J(o['a23v']);rows=[]
    for x,y in zip(A['runs'],Bv['runs']):
        if x['noise']!='ровно':continue
        rows.append({'устр':'ТЕЛ' if x['mob'] else 'ПК','Гц':x['hz'],'предел':x['cap'],'A-23 доля':[x['ipa'],y['ipa']],'дрожание':[x['jit'],y['jit']],'к/с':[x['fpsAvg'],y['fpsAvg']],'h600 равен':x['h600']==y['h600']})
    sim_same=all(r['h600 равен'] for r in rows)
    return ('PASS' if sim_same else 'FAIL'),{'вариант':'предложение, в игру НЕ внесено','сравнение (было, вариант)':rows,'симуляция не изменилась':sim_same}
def st_perf(c):
    B=c.need_B();o=c.d('perf6.json');rc=c.sh('perf6',[PY,os.path.join(T6,'perf6.py'),c.B0,B,o,'--reps','6'],timeout=5400)
    if rc:raise Infra(f'perf6: код {rc}')
    J=c.J(o);bad=[]
    if J['errors']:raise Infra(f"perf6: ошибок в прогонах {J['errors']}")
    for cell,row in J['summary'].items():
        for k in('msFrame','p95','p99'):
            v=row.get(k)
            if not v:continue
            lim=max(1.10,(v['A2/A пары'][1] if v['A2/A пары'] else 1)*1.02)
            if v['B/A'] and v['B/A']>lim:bad.append(f"{cell} {k}: B/A {v['B/A']} > {round(lim,3)} (A/A {v['A2/A']})")
        a=row.get('allocKB')
        if a and a['A'] and a['B']>a['A']*1.25+1:bad.append(f"{cell} выделения: {a['A']} → {a['B']} КБ/кадр")
    return ('PASS' if not bad else 'FAIL'),{'сводка':J['summary'],'нарушения':bad}
def k_judge(c,label,known):
    t=c.text(label);m=re.search(r'совпало побитно (\d+) из (\d+)',t)
    if not m:raise Infra('K: нет итоговой строки сравнения')
    diffs={a:eval(b) for a,b in re.findall(r'^\s+- (\S+): различаются (\[.*\])$',t,re.M)}
    st=re.search(r'STATUS (\w+) \(строк (\d+)/(\d+), ошибок (\d+)\)',t)
    if not st or st.group(1)!='COMPLETE' or st.group(2)!=st.group(3) or st.group(4)!='0':raise Infra('K-стенд неполный: '+(st.group(0) if st else 'нет STATUS'))
    det={'побитно':f'{m.group(1)} из {m.group(2)}','расхождения':diffs,'строк':st.group(2)}
    if not diffs:return 'PASS',det
    if known is not None and diffs==known:return 'KNOWN',det
    return 'FAIL',det
def st_k(c):
    B=c.need_B();o=c.d('k.jsonl');rc=c.sh('k',[PY,os.path.join(T6,'run6.py'),'k',B,os.path.join(KIT,'t72','jobs_k80.json'),o,'--ref',os.path.join(KIT,'t72','k80.jsonl')],timeout=7200)
    if rc not in(0,1):raise Infra(f'run6 k: код {rc}')
    c.fresh(o);st,det=k_judge(c,'k',c.known['k']['jobs'])
    if st=='KNOWN':det['известное']='k'
    return st,det
def st_e24(c):
    B=c.need_B();v=c.d('void_1.5.35_a24v.html');rc=c.sh('variant',[PY,os.path.join(T5,'variant5.py'),B,v,'--a24'])
    if rc:raise Infra('variant5 --a24: код %d'%rc)
    o=c.d('e24.jsonl');rc=c.sh('e24',[PY,os.path.join(T6,'run6.py'),'k',c.fresh(v),os.path.join(KIT,'t72','jobs_e24.json'),o,'--ref',os.path.join(KIT,'t72','e24.jsonl')],timeout=3600)
    if rc not in(0,1):raise Infra(f'run6 k e24: код {rc}')
    c.fresh(o);return k_judge(c,'e24',None)
def st_arct(c):
    B=c.need_B();det={}
    for tag,b in(('164',c.B0),('175',B)):
        rc=c.sh(f'ast_{tag}',['node',os.path.join(T6,'arct6.js'),b,'--json',c.d(f'ast_{tag}.json')])
        if rc:raise Infra('arct6.js: код %d'%rc)
    a,b=c.J(c.d('ast_164.json')),c.J(c.d('ast_175.json'))
    det['arcT: функции']=b['arcTfns'];det['ветка']=b['branch'];det['вызовы ветки']=b['branchCalls'];det['читатели Z.fx']=b['fxReaders'];det['читатели G.parts']=b['partsReaders']
    det['статически как в 1.5.24']=all(a[k]==b[k] for k in('arcTfns','branch','branchCalls','fxReaders','partsReaders'))
    # глубокие снимки двух заданий K на обеих сборках (тот же стенд, deepDump=1)
    J=[dict(j,deepDump=1) for j in json.load(open(os.path.join(KIT,'t72','jobs_k80.json'))) if j['id'] in c.known['k']['jobs']]
    jf=c.d('deep_jobs.json');json.dump(J,open(jf,'w'))
    rows={}
    for tag,bb in(('164',c.B0),('175',B)):
        o=c.d(f'deep_{tag}.jsonl');rc=c.sh(f'deep_{tag}',[PY,os.path.join(T6,'run6.py'),'k',bb,jf,o,'--ref',os.path.join(KIT,'t72','k80.jsonl')],timeout=1800)
        if rc not in(0,1):raise Infra(f'deep {tag}: код {rc}')
        rows[tag]={r['id']:r for r in (json.loads(l) for l in open(c.fresh(o)))}
    NAMES=['player','enemies','eb','pb','pick','boss','zb','post','CX','CY','camZ']
    def walk(x,y,p,out):
        if type(x)!=type(y):out.append(p);return
        if isinstance(x,dict):
            for k in set(x)|set(y):
                if k not in x or k not in y:out.append(p+'.'+k)
                else:walk(x[k],y[k],p+'.'+k,out)
        elif isinstance(x,list):
            if len(x)!=len(y):out.append(p+'[len]');return
            for i,(u,v) in enumerate(zip(x,y)):walk(u,v,(NAMES[i] if p=='' else p+f'[{i}]'),out)
        elif x!=y:out.append(p)
    dd={};same_other={}
    for jid in J:
        x,y=rows['164'].get(jid['id']),rows['175'].get(jid['id'])
        if not x or not y or not x.get('deepS') or not y.get('deepS'):raise Infra('нет глубокого снимка '+jid['id'])
        out=[];walk(json.loads(x['deepS']),json.loads(y['deepS']),'',out);dd[jid['id']]=sorted(set(out))
        same_other[jid['id']]={k:x.get(k)==y.get(k) for k in('fp','steps','rng','kills','taken','frames','zero','two','simT','st')}
    det['глубокий снимок: различающиеся пути']=dd;det['прочие поля равны']=same_other
    exp=set(c.known['k']['deepKeys'])
    ok=det['статически как в 1.5.24'] and set(det['arcT: функции'])=={'zbFxTick'} and any('!G.lowFx' in x for x in det['ветка']) and all(set(v)<=exp and v for v in dd.values()) and all(all(v.values()) for v in same_other.values())
    det['вердикт']='ожидаемое визуальное отличие (arcT только в zbFxTick за SET.fx&&!G.lowFx, визуальный ГСЧ; симуляция, урон, исход равны)' if ok else 'НЕ ПОДТВЕРЖДЕНО'
    return ('KNOWN' if ok else 'FAIL'),dict(det,известное='k')
OV=['q130','q170','q220','q310','q370','q380']
def st_regbase(c):
    o=c.d('reg');rc=c.sh('reg',[PY,os.path.join(T6,'run6.py'),'reg',c.B0,o,'--overlay',K6,'--suites',','.join(OV),'--base',os.path.join(R,'out5','p84','reg24'),'--aa',os.path.join(R,'baseline','reg20_aa')],timeout=7200)
    J=c.J(os.path.join(o,'run.json'))
    if J['status']!='COMPLETE':raise Infra('kit6 на 1.5.24: прогон неполный '+json.dumps({k:v['status'] for k,v in J['suites'].items()},ensure_ascii=False))
    full=os.path.join(c.run,'regbase_full');os.makedirs(full,exist_ok=True)
    for f in glob.glob(os.path.join(R,'out5','p84','reg24','q*.log')):shutil.copy(f,full)
    for s in OV:shutil.copy(c.fresh(os.path.join(o,s+'.log')),os.path.join(full,s+'.log'))
    open(os.path.join(full,'ИСТОЧНИК.txt'),'w',encoding='utf8').write('Эталон регрессии для kit6: журналы out5/p84/reg24 (1.5.24, исторический kit), кроме '+', '.join(OV)+' — они из прогона kit6 на 1.5.24 в этом же запуске приёмки.\n')
    return ('PASS' if rc==0 else 'FAIL'),{'cmpExit (kit6 на 1.5.24 против исторического kit на 1.5.24)':J['cmpExit'],'источники':J['source']}
def st_reg(c):
    B=c.need_B();base=os.path.join(c.run,'regbase_full')
    if not os.path.isdir(base):raise Infra('нет эталона kit6 на 1.5.24: шаг regbase не выполнен в этом прогоне')
    o=c.d('reg');rc=c.sh('reg',[PY,os.path.join(T6,'run6.py'),'reg',B,o,'--overlay',K6,'--solo','q340s,q350','--base',base,'--aa',os.path.join(R,'baseline','reg20_aa')],timeout=14400)
    J=c.J(os.path.join(o,'run.json'))
    if J['status']!='COMPLETE':raise Infra('регрессия неполная: '+json.dumps({k:v['status'] for k,v in J['suites'].items() if v['status']!='OK'},ensure_ascii=False))
    cmp=c.J(os.path.join(o,'cmp.json'));new=sorted([t[:-4],k] for t,v in cmp['rep'].items() for k in v['new']);gone=sorted([t[:-4],k] for t,v in cmp['rep'].items() for k in v['gone'])
    det={'наборов':len(J['suites']),'итог сравнения':cmp['tot'],'новые падения':new,'ушедшие падения эталона':gone,'из kit6':[k for k,v in J['source'].items() if v.startswith('kit6')],'одиночно':J['solo']}
    if J['cmpExit']==0 and not new:return 'PASS',det
    if cmp['tot']['det'] or cmp['tot']['miss'] or new!=c.known['reg.C11']['new']:return 'FAIL',det
    fj=os.path.join(c.run,'steps','flaky','c11.json')   # условие известного отклонения — замер C11 этого же прогона
    if not os.path.exists(fj) or os.path.getmtime(fj)<c.t_run:return 'FAIL',dict(det,известное='C11 — нет замера c11ab6 в этом прогоне (шаг flaky)')
    C=json.load(open(fj));cond=C['verdict']=='нет регрессии' and C['summary']['FAIL']['A']+C['summary']['FAIL']['A2']>0
    return ('KNOWN' if cond else 'FAIL'),dict(det,C11=C['summary'],известное='reg.C11' if cond else 'условие reg.C11 не выполнено')
def st_regsave(c):
    B=c.need_B();o=c.d('reg');rc=c.sh('reg',[PY,os.path.join(T6,'run6.py'),'reg',B,o,'--suites','q71save,q73save','--base',os.path.join(R,'out5','p84','reg24_save'),'--aa',os.path.join(R,'baseline','reg20_save')],timeout=3600)
    J=c.J(os.path.join(o,'run.json'))
    if J['status']!='COMPLETE':raise Infra('неполный прогон')
    return ('PASS' if rc==0 else 'FAIL'),{'cmpExit':J['cmpExit']}
def st_flaky(c):
    B=c.need_B();o=c.d('thrab.json');rc=c.sh('thrab6',[PY,os.path.join(T6,'thrab6.py'),c.B0,B,o,'2','q130:Q06:8','q220:U05:16','q220:U07:16'],timeout=7200)
    if rc:raise Infra('thrab6: код %d'%rc)
    T=c.J(o)['tally'];bad=[]
    for k,v in T.items():
        for tag in('A','B'):
            if v['kit6'][tag]['FAIL'] or v['kit6'][tag]['NONE']:bad.append(f'{k} kit6 {tag}: {v["kit6"][tag]}')
    o2=c.d('c11.json');rc2=c.sh('c11ab',[PY,os.path.join(T6,'c11ab6.py'),c.B0,B,o2,'--reps','8'],timeout=3600)
    if rc2:raise Infra('c11ab6: код %d'%rc2)
    C=c.J(o2)
    if C['verdict']=='регрессия':bad.append('C11: B медленнее A сверх разброса A/A')
    return ('PASS' if not bad else 'FAIL'),{'замедление ЦП':T,'C11':C['summary'],'нарушения':bad}
STEPS=[('env','env',st_env,'окружение: версии Python/Playwright/Node/модулей, браузер запускается'),
 ('kit','kit',st_kit,'исторический kit не изменён (манифест), kit6 = генератор mkkit6'),
 ('build','build',st_build,'сборка 1.5.25…1.5.35 из 1.5.24 патчами 85–93, SHA каждого шага'),
 ('strip','build',st_strip,'снятие патчей побайтно: все сразу и каждый по одному'),
 ('rollback','build',st_rollback,'скрипт отката rollback6: 1.5.35 → 1.5.24 побайтно'),
 ('static','static',st_static,'own6, selftest6, tdep6; g6/w6/chains6/init6 воспроизводятся побайтно'),
 ('arch','arch',st_arch,'archcheck6 (точный допуск 4 цепочек), merge86, мутанты'),
 ('trace','arch',st_trace,'trace86: порядок, аргументы, результаты, эффекты, состояние — A/B против A/A; мутант пойман'),
 ('stands','stands',st_stands,'стенды boot/trace/aimman/prio/probes против 1.5.24'),
 ('a24','stands',st_a24,'те же стенды при A-24'),
 ('gkeys','state',st_gkeys,'порядок ключей G, синхронизация autoClick132, A/B и A/A'),
 ('st6','state',st_st6,'переходы G.state и смены G.save: 1.5.24 и 1.5.35 в одном прогоне'),
 ('c5','state',st_c5,'класс 5: исходные тела замещённых объявлений не исполняются'),
 ('save','state',st_save,'save6: настройки и сохранения между версиями, S12 песочница'),
 ('q390','kit6',st_q390,'новый набор FPS q390'),
 ('shots','visual',st_shots,'снимки строки «КАДРЫ» на 6 размерах'),
 ('fps','fps',st_fps,'fps6: матрица частот × пределов, окно измерения отдельно от разгона'),
 ('fpsx','fps',st_fpsx,'смена предела в бою, 120 с, фон, экран 30 Гц, циклы меню/карты'),
 ('a23v','fps',st_a23v,'предложение для 75 Гц (A-23 0.84) — отдельное измерение, в игру не вносится'),
 ('perf','perf',st_perf,'perf6: стоимость кадра, p95/p99/максимум, выделения памяти; A/B и A/A'),
 ('k','k',st_k,'K-стенд 429 заданий против 1.5.24'),
 ('e24','k',st_e24,'35 заданий A-24'),
 ('arct','k',st_arct,'arcT: чтения/записи, ветка lowFx, глубокие снимки 1.5.24/1.5.35'),
 ('flaky','flaky',st_flaky,'нестабильные: kit/kit6 под замедлением ЦП, C11 ABAB'),
 ('regbase','reg',st_regbase,'kit6 на 1.5.24 — эталон для новых версий наборов'),
 ('reg','reg',st_reg,'полная регрессия 1.5.35 (kit + kit6, q340s и q350 одиночно)'),
 ('regsave','reg',st_regsave,'q71save/q73save')]
ORDER_NOTE='Шаги без сборки build получают ERROR (сборка не подставляется из старых прогонов).'
def execute(steps,run,known,full,keep_going=False):
    c=Ctx(run,known);res=[];t_all=time.time();c.t_run=t_all
    print(f'Прогон: {run}\nШагов: {len(steps)}{" (полный)" if full else " (ЧАСТИЧНЫЙ)"}',flush=True)
    for name,group,fn,desc in steps:
        c.step=name;c.t0=time.time();c.logs=[];os.makedirs(os.path.join(run,'steps',name),exist_ok=True)
        print(f'— {name}: {desc}',flush=True)
        try:st,det=fn(c)
        except Infra as e:st,det='ERROR',{'причина':str(e)}
        except Exception as e:
            st,det='ERROR',{'причина':'сбой шага: '+repr(e)[:300]}
            open(os.path.join(run,'steps',name,'traceback.txt'),'w').write(traceback.format_exc())
        if st not in('PASS','FAIL','KNOWN','ERROR'):st,det='ERROR',{'причина':f'шаг вернул недопустимый статус {st!r}'}
        r={'step':name,'group':group,'status':st,'sec':round(time.time()-c.t0),'detail':det,'logs':c.logs};res.append(r)
        json.dump({'run':run,'steps':res},open(os.path.join(run,'accept.partial.json'),'w'),ensure_ascii=False,indent=1,default=str)
        print(f'  {st}  ({r["sec"]} с) '+json.dumps(det,ensure_ascii=False,default=str)[:600],flush=True)
        if name=='build' and st!='PASS' and not keep_going:
            for n2,g2,_,d2 in steps[steps.index((name,group,fn,desc))+1:]:res.append({'step':n2,'group':g2,'status':'ERROR','sec':0,'detail':{'причина':'не запускался: сборка 1.5.35 не получена в этом прогоне'},'logs':[]})
            break
    sts=[r['status'] for r in res]
    code=2 if 'ERROR' in sts else 1 if 'FAIL' in sts else (0 if full else 4)
    verdict={0:'ПРИЁМКА ПРОЙДЕНА',1:'ПРИЁМКА НЕ ПРОЙДЕНА: есть FAIL',2:'ПРИЁМКА НЕ ЗАВЕРШЕНА: есть ERROR',4:'ЧАСТИЧНЫЙ ПРОГОН: выбранные шаги PASS/KNOWN, приёмка не завершена'}[code]
    out={'run':run,'full':full,'code':code,'verdict':verdict,'counts':{s:sts.count(s) for s in('PASS','KNOWN','FAIL','ERROR')},'sec':round(time.time()-t_all),
         'started':time.strftime('%F %T',time.localtime(t_all)),'tools':{os.path.relpath(p,R):sha(p)[:16] for p in sorted(glob.glob(os.path.join(T6,'*.py'))+glob.glob(os.path.join(T6,'*.js')))},
         'python':sys.version.split()[0],'steps':res}
    json.dump(out,open(os.path.join(run,'accept.json'),'w'),ensure_ascii=False,indent=1,default=str)
    if os.path.exists(os.path.join(run,'accept.partial.json')):os.remove(os.path.join(run,'accept.partial.json'))
    L=['ИТОГ ПРИЁМКИ 1.5.35 (корректирующее обновление)',f'прогон {run}',f'{"полный" if full else "ЧАСТИЧНЫЙ"}; шагов {len(res)}; '+', '.join(f'{k} {v}' for k,v in out['counts'].items()),'']
    for r in res:L.append(f"{r['status']:6s} {r['step']:9s} {r['sec']:6d} с  "+json.dumps(r['detail'],ensure_ascii=False,default=str)[:300])
    L+=['','KNOWN — найденное отклонение точно совпало с записью ref6/known6.json (не PASS).','',verdict]
    open(os.path.join(run,'ИТОГ.txt'),'w',encoding='utf8').write('\n'.join(L)+'\n')
    print('\n'.join(L[2:]));return code
# ---------------------------------------------------------------- самопроверка механизма приёмки
def selftest():
    tmp=tempfile.mkdtemp(prefix='accept6_self_');ok=True;rows=[]
    def mk(f):return f
    def s_pass(c):p=c.d('o.json');json.dump({'x':1},open(p,'w'));c.J(p);return 'PASS',{}
    def s_fail(c):rc=c.sh('false',[PY,'-c','import sys;sys.exit(1)']);return ('PASS' if rc==0 else 'FAIL'),{}
    def s_notool(c):c.sh('x',['нет_такой_программы_123']);return 'PASS',{}
    def s_noscript(c):c.sh('x',[PY,os.path.join(tmp,'нет.py')]);return 'PASS',{}
    def s_stale(c):
        p=os.path.join(tmp,'старый.json');json.dump({},open(p,'w'));os.utime(p,(time.time()-3600,)*2);c.J(p);return 'PASS',{}
    def s_noout(c):c.sh('ok',[PY,'-c','pass']);c.J(c.d('не_записан.json'));return 'PASS',{}
    def s_timeout(c):c.sh('t',[PY,'-c','import time;time.sleep(5)'],timeout=1);return 'PASS',{}
    def s_crash(c):raise ValueError('ошибка в коде шага')
    def s_badstatus(c):return 'OK',{}
    def s_known_exact(c):
        Kn={'a/b':['deep']};return ('KNOWN' if {'a/b':['deep']}==Kn else 'FAIL'),{}
    def s_known_near(c):
        Kn={'a/b':['deep']};got={'a/b':['deep'],'c/d':['deep']};return ('KNOWN' if got==Kn else 'FAIL'),{}
    def s_space(c):
        d=os.path.join(tmp,'папка с пробелом ü');os.makedirs(d,exist_ok=True);p=os.path.join(d,'файл «x».json')
        rc=c.sh('write',[PY,'-c','import json,sys;json.dump({"ok":1},open(sys.argv[1],"w"))',p]);return ('PASS' if rc==0 and c.J(p)['ok']==1 else 'FAIL'),{}
    def s_needB(c):c.need_B();return 'PASS',{}
    cases=[('провал команды → FAIL',[('a','g',s_fail,'')],True,1,{'a':'FAIL'}),
           ('нет программы → ERROR',[('a','g',s_notool,'')],True,2,{'a':'ERROR'}),
           ('нет скрипта → ERROR',[('a','g',s_noscript,'')],True,2,{'a':'ERROR'}),
           ('старый результат → ERROR',[('a','g',s_stale,'')],True,2,{'a':'ERROR'}),
           ('результат не записан → ERROR',[('a','g',s_noout,'')],True,2,{'a':'ERROR'}),
           ('тайм-аут → ERROR',[('a','g',s_timeout,'')],True,2,{'a':'ERROR'}),
           ('исключение в шаге → ERROR',[('a','g',s_crash,'')],True,2,{'a':'ERROR'}),
           ('недопустимый статус → ERROR',[('a','g',s_badstatus,'')],True,2,{'a':'ERROR'}),
           ('известное точно → KNOWN, полный → 0',[('a','g',s_known_exact,''),('b','g',s_pass,'')],True,0,{'a':'KNOWN','b':'PASS'}),
           ('известное + лишнее → FAIL',[('a','g',s_known_near,'')],True,1,{'a':'FAIL'}),
           ('пробелы и кириллица в путях',[('a','g',s_space,'')],True,0,{'a':'PASS'}),
           ('без сборки → ERROR',[('a','g',s_needB,'')],True,2,{'a':'ERROR'}),
           ('частичный прогон, всё PASS → 4',[('a','g',s_pass,'')],False,4,{'a':'PASS'}),
           ('FAIL и ERROR вместе → 2',[('a','g',s_fail,''),('b','g',s_notool,'')],True,2,{'a':'FAIL','b':'ERROR'}),
           ('сборка не получена → остальные ERROR',[('build','g',s_fail,''),('b','g',s_pass,'')],True,2,{'build':'FAIL','b':'ERROR'})]
    import io,contextlib
    for i,(lab,steps,full,want,wst) in enumerate(cases):
        run=os.path.join(tmp,f'run{i}');os.makedirs(run)
        buf=io.StringIO()
        with contextlib.redirect_stdout(buf):code=execute(steps,run,{},full)
        out=json.load(open(os.path.join(run,'accept.json')));got={r['step']:r['status'] for r in out['steps']}
        txt=buf.getvalue()+open(os.path.join(run,'ИТОГ.txt'),encoding='utf8').read()
        good=code==want and got==wst and (('ПРИЁМКА ПРОЙДЕНА' in txt)==(want==0))
        ok&=good;rows.append((lab,code,got,good));print(('ok   ' if good else 'FAIL ')+lab+f' → код {code}, {got}')
    # разбор аргументов: неизвестный шаг / группа / аргумент → код 3
    for args in (['--steps','нет_шага'],['--group','нет_группы'],['--непонятно'],['--steps','']):
        p=subprocess.run([PY,os.path.abspath(__file__)]+args+['--out',os.path.join(tmp,'u'+str(len(rows)))],capture_output=True,text=True)
        good=p.returncode==3 and 'ПРИЁМКА ПРОЙДЕНА' not in p.stdout;ok&=good;rows.append((str(args),p.returncode,None,good));print(('ok   ' if good else 'FAIL ')+f'аргументы {args} → код {p.returncode}')
    # занятая папка прогона → код 3
    busy=os.path.join(tmp,'занято');os.makedirs(busy);open(os.path.join(busy,'x'),'w').write('1')
    p=subprocess.run([PY,os.path.abspath(__file__),'--steps','env','--out',busy],capture_output=True,text=True);good=p.returncode==3;ok&=good;print(('ok   ' if good else 'FAIL ')+f'занятая папка прогона → код {p.returncode}')
    shutil.rmtree(tmp,ignore_errors=True)
    print('САМОПРОВЕРКА ПРИЁМКИ:','пройдена' if ok else 'НЕ ПРОЙДЕНА');return 0 if ok else 1
def main(argv):
    a=list(argv);known=json.load(open(os.path.join(REF,'known6.json'),encoding='utf8'))
    def opt(n):
        if n in a:
            i=a.index(n)
            if i+1>=len(a) or a[i+1].startswith('--'):raise Usage(f'{n}: нет значения')
            v=a[i+1];del a[i:i+2];return v
        return None
    try:
        if '--selftest' in a:return selftest()
        if '--list' in a:
            for n,g,_,d in STEPS:print(f'{n:9s} [{g}] {d}')
            print(ORDER_NOTE);return 0
        out=opt('--out');steps=opt('--steps');groups=opt('--group');kg='--keep-going' in a
        if kg:a.remove('--keep-going')
        if a:raise Usage('неизвестные аргументы: '+' '.join(a))
        names=[n for n,*_ in STEPS];gnames={g for _,g,*_ in STEPS}
        if steps is not None:
            sel=[x for x in steps.split(',') if x]
            if not sel:raise Usage('пустой список шагов')
            unk=[x for x in sel if x not in names]
            if unk:raise Usage('неизвестные шаги: '+', '.join(unk)+' (см. --list)')
            S=[s for s in STEPS if s[0] in sel]
        elif groups is not None:
            sel=[x for x in groups.split(',') if x];unk=[x for x in sel if x not in gnames]
            if not sel or unk:raise Usage('неизвестные группы: '+', '.join(unk or ['(пусто)']))
            S=[s for s in STEPS if s[1] in sel]
        else:S=list(STEPS)
        full=len(S)==len(STEPS)
        if S and S[0][0]!='build' and any(s[0]=='build' for s in STEPS) and not any(s[0]=='build' for s in S):
            S=[s for s in STEPS if s[0]=='build']+S  # сборка всегда выполняется в том же прогоне — без неё нет 1.5.35
        run=os.path.abspath(out or os.path.join(R,'out7','accept',time.strftime('%Y%m%d-%H%M%S')))
        if os.path.exists(run) and os.listdir(run):raise Usage('папка прогона не пуста: '+run)
        os.makedirs(run,exist_ok=True)
    except Usage as e:print('ОШИБКА ВЫЗОВА:',e);return 3
    return execute(S,run,known,full,kg)
if __name__=='__main__':sys.exit(main(sys.argv[1:]))
