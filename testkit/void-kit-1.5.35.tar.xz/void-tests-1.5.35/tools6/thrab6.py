#!/usr/bin/env python3
# Корректирующее обновление · проверка исправленного ожидания: исторический тест (kit) и новая версия (kit6) на двух сборках
# поочерёдно (A B A B …) при замедлении процессора страницы.  python3 tools6/thrab6.py A.html B.html out.json REPS q130:Q06:8 q220:U05:32 …
import sys,os,subprocess,json,re
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));KIT=os.path.join(R,'kit')
A,B,OUT,N=os.path.abspath(sys.argv[1]),os.path.abspath(sys.argv[2]),sys.argv[3],int(sys.argv[4]);items=[x.split(':') for x in sys.argv[5:]]
T={};rows=[]
for i in range(N):
    for q,t,thr in items:
        for kd in ('kit','kit6'):
            for tag,b in (('A',A),('B',B)):
                env=dict(os.environ,GAME_URL='file://'+b,THR=thr,PYTHONPATH=KIT,PYTHONDONTWRITEBYTECODE='1')
                if kd=='kit6':env['KDIR']=os.path.join(R,'kit6')
                p=subprocess.run([sys.executable,os.path.join(R,'tools6','diag','qthr6.py'),q,t],cwd=KIT,env=env,capture_output=True,text=True,timeout=900)
                m=re.search(r'^(OK|FAIL)\s+'+re.escape(t)+r'\b(.*)$',p.stdout,re.M);st=m.group(1) if m else 'NONE'
                k=f'{q}:{t}@x{thr}';T.setdefault(k,{}).setdefault(kd,{'A':{'OK':0,'FAIL':0,'NONE':0},'B':{'OK':0,'FAIL':0,'NONE':0}})[kd if False else tag][st]+=1
                rows.append({'test':k,'kit':kd,'build':tag,'rep':i,'status':st,'tail':(m.group(2)[-220:] if m else p.stdout[-300:]+p.stderr[-300:])})
                print(k,kd,tag,i,st,flush=True)
        json.dump({'A':A,'B':B,'reps':N,'tally':T,'rows':rows},open(OUT,'w'),ensure_ascii=False,indent=1)
print(json.dumps(T,ensure_ascii=False))
