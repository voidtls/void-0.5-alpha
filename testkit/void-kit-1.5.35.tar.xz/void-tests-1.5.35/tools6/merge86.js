// Корректирующее обновление · merge86 — независимая структурная проверка слияния ARCH·86 (не использует генератор dump86/gen86).
//   node tools6/merge86.js <до.html> <после.html> [<итоговая.html>] [--json out.json]
// Для каждой из 4 слитых цепочек (renderSettings, renderSetScreen, tutEmit, tutMapDraw):
//  1. в «до» находятся все слои-переустановки вида {const _x=NAME; NAME=function(…){…}} верхнего уровня, в «после» — все слои той же цепочки;
//  2. слои, оставшиеся без изменений, сопоставляются по тексту; исчезнувшие слои должны быть смежной серией, на месте последнего — один
//     объединённый слой с _p86;
//  3. тело каждого слоя делится на «до вызова прежней» (pre), сам вызов и «после» (post). Ожидается:
//     pre объединённого = pre слоёв от внешнего (позднего) к внутреннему, post = post от внутреннего к внешнему;
//     параметры слоя k в объединённом слое — либо параметры функции, либо const X_86k=arguments[i], локальные имена — с суффиксом _86k;
//  4. между слоями серии в «до» нет других записей в NAME (иначе порядок вызова мог зависеть от них);
//  5. в итоговой сборке объединённый слой совпадает с «после» побайтно (или указывается, чем отличается).
// Любая другая цепочка, изменённая между «до» и «после», — ошибка. Выход: 0 — доказано; 1 — расхождение; 3 — внутренняя ошибка.
const path=require('path'),fs=require('fs');
process.on('uncaughtException',e=>{console.error('merge86: внутренняя ошибка: '+(e&&e.stack||e));process.exit(3);});
const NM=path.join(__dirname,'..','node_modules');
const acorn=require(path.join(NM,'acorn'));
const NAMES=['renderSettings','renderSetScreen','tutEmit','tutMapDraw'];
const args=process.argv.slice(2);const jo=args.indexOf('--json');const JOUT=jo>=0?args.splice(jo,2)[1]:null;
const [A,B,C]=args;
function load(f){const html=fs.readFileSync(f,'utf8');const k=html.indexOf('<script>\n"use strict";');const src=html.slice(k+8,html.indexOf('</script>',k));
  return {src,ast:acorn.parse(src,{ecmaVersion:2022,sourceType:'script',ranges:true})};}
// слои: верхний уровень (и вложенные блоки верхнего уровня) {const _x=NAME; NAME=function(){}}; плюс все прочие записи NAME= на верхнем уровне
function layers(P,name){
  const out=[],writes=[];
  function visitStmts(body){for(const s of body){
    if(s.type==='BlockStatement'){const b=s.body;
      if(b.length>=2&&b[0].type==='VariableDeclaration'&&b[0].declarations.length===1&&b[0].declarations[0].init&&b[0].declarations[0].init.type==='Identifier'&&b[0].declarations[0].init.name===name
         &&b[1].type==='ExpressionStatement'&&b[1].expression.type==='AssignmentExpression'&&b[1].expression.left.type==='Identifier'&&b[1].expression.left.name===name
         &&/Function/.test(b[1].expression.right.type)){
        out.push({start:s.start,end:s.end,prev:b[0].declarations[0].id.name,fn:b[1].expression.right,text:P.src.slice(s.start,s.end),extra:b.length-2});continue;}
      visitStmts(b);continue;}
    if(s.type==='ExpressionStatement'&&s.expression.type==='AssignmentExpression'&&s.expression.left.type==='Identifier'&&s.expression.left.name===name)writes.push(s.start);
  }}
  visitStmts(P.ast.body);return {layers:out,writes};
}
const ws=t=>t.replace(/\s+/g,'');
// разбор тела слоя: pre / call / post; resVar — имя результата прежней
function split(P,L){
  const body=L.fn.body.body;const prev=L.prev;const isCall=s=>new RegExp('(?<![\\w$])'+prev.replace('$','\\$')+'\\s*\\.\\s*(apply|call)\\s*\\(|(?<![\\w$.])'+prev.replace('$','\\$')+'\\s*\\(').test(P.src.slice(s.start,s.end));
  const idx=body.map(isCall);const ci=idx.indexOf(true);if(ci<0||idx.lastIndexOf(true)!==ci)return {err:'вызов прежней не найден или не один: '+idx.filter(x=>x).length};
  const cs=body[ci];let res=null,post=body.slice(ci+1);
  if(cs.type==='ReturnStatement')res='<ret>';
  else if(cs.type==='VariableDeclaration'&&cs.declarations.length===1){res=cs.declarations[0].id.name;
    const last=post[post.length-1];if(!last||last.type!=='ReturnStatement'||!last.argument||last.argument.type!=='Identifier'||last.argument.name!==res)return {err:'после вызова нет «return '+res+'» последним'};post=post.slice(0,-1);}
  else return {err:'вызов прежней не в форме return/const: '+cs.type};
  const params=L.fn.params.map(p=>p.type==='Identifier'?p.name:null);if(params.includes(null))return {err:'параметр-шаблон'};
  return {pre:body.slice(0,ci),post,res,params,call:P.src.slice(cs.start,cs.end)};
}
// нормализация текста оператора: параметры → $Pi, результат → $R, суффиксы _86k → снимаются (с проверкой номера слоя k)
function norm(P,stmts,map,k,bad){return stmts.map(s=>{let t=P.src.slice(s.start,s.end);
  t=t.replace(/(?<![\w$.])([A-Za-z_$][\w$]*)/g,(m,id)=>{
    let mm=id.match(/^(.*)_86(\d+)$/);if(mm&&k!=null){if(+mm[2]!==k)bad.push(`имя ${id} в части слоя ${k}`);id=mm[1];if(map[id+'_86'+k])return map[id+'_86'+k];}
    return map[id]||id;});return ws(t);});}
const R={pairs:{},ok:true,errs:[]};
function fail(n,m){R.ok=false;R.errs.push(n+': '+m);}
const PA=load(A),PB=load(B);
for(const name of NAMES){
  const a=layers(PA,name),b=layers(PB,name);const rec={before:a.layers.length,after:b.layers.length};R.pairs[name]=rec;
  const bt=new Set(b.layers.map(l=>ws(l.text)));const gone=a.layers.map((l,i)=>bt.has(ws(l.text))?-1:i).filter(i=>i>=0);
  const at=new Set(a.layers.map(l=>ws(l.text)));const added=b.layers.filter(l=>!at.has(ws(l.text)));
  rec.merged=gone.length;
  if(added.length!==1||!/_p86/.test(added[0].text)){fail(name,'в «после» ожидался ровно один новый слой с _p86, найдено '+added.length);continue;}
  if(gone.length<2)fail(name,'исчезло слоёв '+gone.length);
  for(let i=1;i<gone.length;i++)if(gone[i]!==gone[i-1]+1)fail(name,'исчезнувшие слои не смежны: '+gone.join(','));
  const s0=a.layers[gone[0]].start,s1=a.layers[gone[gone.length-1]].start;const between=a.writes.filter(w=>w>s0&&w<s1);
  if(between.length)fail(name,'между слоями серии есть другие записи '+name+': '+between.length);
  for(const i of gone)if(a.layers[i].extra)fail(name,'в блоке слоя '+i+' есть другие операторы');
  const M=split(PB,added[0]);if(M.err){fail(name,'объединённый: '+M.err);continue;}
  // параметры объединённого: const X_86k=arguments[i] в начале pre
  const map={};let pre=M.pre.slice();M.params.forEach((p,i)=>map[p]='$P'+i);
  while(pre.length&&pre[0].type==='VariableDeclaration'&&pre[0].declarations.every(d=>d.init&&d.init.type==='MemberExpression'&&d.init.object.name==='arguments'&&d.init.computed&&d.init.property.type==='Literal')){
    for(const d of pre[0].declarations)map[d.id.name]='$P'+d.init.property.value;pre=pre.slice(1);}
  if(M.res!=='<ret>')map[M.res]='$R';
  // ожидаемое
  const L=gone.map(i=>split(PA,a.layers[i]));const le=L.findIndex(x=>x.err);if(le>=0){fail(name,'слой '+gone[le]+': '+L[le].err);continue;}
  const n=gone.length;const bad=[];
  // слой с номером k (1 — самый внутренний = первый в исходнике)
  const exp={pre:[],post:[]};const segPre=[],segPost=[];
  for(let k=n;k>=1;k--){const l=L[k-1];const m={};l.params.forEach((p,i)=>m[p]='$P'+i);if(l.res!=='<ret>')m[l.res]='$R';const e=norm(PA,l.pre,m,null,bad);exp.pre.push(...e);segPre.push([k,e.length]);}
  for(let k=1;k<=n;k++){const l=L[k-1];const m={};l.params.forEach((p,i)=>m[p]='$P'+i);if(l.res!=='<ret>')m[l.res]='$R';const e=norm(PA,l.post,m,null,bad);exp.post.push(...e);segPost.push([k,e.length]);}
  // фактическое: нормализуем по сегментам, чтобы проверить номер слоя в суффиксах
  const got={pre:[],post:[]};let j=0;
  for(const [k,c] of segPre){got.pre.push(...norm(PB,pre.slice(j,j+c),map,k,bad));j+=c;}
  if(j!==pre.length)fail(name,`в pre объединённого ${pre.length} операторов, ожидалось ${j}`);
  j=0;for(const [k,c] of segPost){got.post.push(...norm(PB,M.post.slice(j,j+c),map,k,bad));j+=c;}
  if(j!==M.post.length)fail(name,`в post объединённого ${M.post.length} операторов, ожидалось ${j}`);
  rec.pre=got.pre.length;rec.post=got.post.length;rec.suffixErr=bad.slice(0,5);
  for(const part of ['pre','post'])for(let i=0;i<Math.max(exp[part].length,got[part].length);i++)if(exp[part][i]!==got[part][i]){fail(name,`${part}[${i}] отличается:\n  ожидалось ${String(exp[part][i]).slice(0,160)}\n  есть      ${String(got[part][i]).slice(0,160)}`);break;}
  if(bad.length)fail(name,'суффиксы: '+bad.slice(0,3).join('; '));
  // вызов прежней: та же форма apply(this,arguments)
  if(!/_p86\.apply\(this,arguments\)/.test(ws(M.call)))fail(name,'вызов прежней в объединённом слое не _p86.apply(this,arguments): '+M.call);
  L.forEach((l,ii)=>{const pv=a.layers[gone[ii]].prev;if(!new RegExp(pv.replace('$','\\$')+'\\.apply\\(this,arguments\\)').test(ws(l.call)))rec.note=(rec.note||'')+' слой вызывал прежнюю не через apply(this,arguments): '+l.call;});
  if(C){const PC=load(C);const c=layers(PC,name);const m=c.layers.filter(l=>/_p86/.test(l.text));rec.final=m.length===1&&m[0].text===added[0].text?'побайтно как в «после»':'ОТЛИЧАЕТСЯ';
    if(rec.final!=='побайтно как в «после»')fail(name,'объединённый слой в итоговой сборке отличается от «после»');}
}
// другие цепочки не должны меняться: все блоки-слои прочих имён в «до» и «после» совпадают по тексту
{const all=P=>{const s=new Map();for(const st of P.ast.body){if(st.type==='BlockStatement'&&st.body.length>=2&&st.body[0].type==='VariableDeclaration'&&st.body[0].declarations[0]&&st.body[0].declarations[0].init&&st.body[0].declarations[0].init.type==='Identifier'){const nm=st.body[0].declarations[0].init.name;if(NAMES.includes(nm))continue;const t=ws(P.src.slice(st.start,st.end));s.set(t,(s.get(t)||0)+1);}}return s;};
 const sa=all(PA),sb=all(PB);let diffN=0;for(const [t,c] of sa)if(sb.get(t)!==c)diffN++;for(const [t,c] of sb)if(sa.get(t)!==c)diffN++;R.otherBlocksChanged=diffN;if(diffN)fail('прочие','изменены другие блоки-слои: '+diffN);}
console.log(JSON.stringify(R,null,1));if(JOUT)fs.writeFileSync(JOUT,JSON.stringify(R,null,1));process.exit(R.ok?0:1);
