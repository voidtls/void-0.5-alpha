# Диагностика (не тест регрессии): один тест набора с замедлением процессора страницы (CDP Emulation.setCPUThrottlingRate).
#   cd kit && GAME_URL=… THR=4 [KDIR=../kit6] PYTHONPATH=. python3 ../tools6/diag/qthr6.py q220 U07
# KDIR — папка набора (kit6 — новые версии); по умолчанию исторический kit. Результат JSON пишется в out7/thr_tmp/.
import os,sys,importlib,asyncio
K=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if os.environ.get('KDIR'):sys.path.insert(0,os.path.abspath(os.environ['KDIR']))
sys.path.append(os.path.join(K,'kit'))
mod,tn=sys.argv[1],sys.argv[2];sys.argv=[sys.argv[0],tn]
M=importlib.import_module(mod)
_np=M.newpage
async def newpage(b,*a,**kw):
    P=await _np(b,*a,**kw)
    s=await P.pg.context.new_cdp_session(P.pg);await s.send('Emulation.setCPUThrottlingRate',{'rate':float(os.environ.get('THR','4'))});return P
M.newpage=newpage
os.makedirs(os.path.join(K,'out7','thr_tmp'),exist_ok=True)
asyncio.run(M.run([t for t in M.TESTS if t[0]==tn],'../out7/thr_tmp/%s_%s.json'%(mod,os.getpid())))
