# Диагностика (не тест): скорость симуляции и стоимость кадра в мире с обучением (как q220 U05/U07) при замедлении ЦП страницы.
#   python3 tools6/diag/simrate6.py A.html B.html out.json --thr 1,32 --reps 3 [--sec 10]
# Поочерёдно A B A B; на каждой странице: NEW (как q220), затем за SEC секунд настоящего времени — кадров rAF, обработанных кадров,
# шагов симуляции (step74), средняя/медиана/p95 длительности frame() (performance.now внутри страницы, с учётом замедления).
import asyncio,json,sys,os,time
R=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))));sys.path.insert(0,os.path.join(R,'kit'))
_A=[os.path.abspath(x) for x in sys.argv[1:4]];os.chdir(os.path.join(R,'kit'))
import h,q220
from playwright.async_api import async_playwright
a=sys.argv[1:];A,B,OUT=_A;THR=[float(x) for x in a[a.index('--thr')+1].split(',')];REPS=int(a[a.index('--reps')+1]);SEC=float(a[a.index('--sec')+1]) if '--sec' in a else 10
M=r"""async(sec)=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));let nf=0,np=0,ns=0;const D=[];const f0=frame;
 frame=function(){nf++;const l0=last,t0=performance.now();const r=f0.apply(this,arguments);D.push(performance.now()-t0);if(last!==l0)np++;return r;};
 const s0=step74;step74=function(){ns++;return s0.apply(this,arguments);};
 const t0=performance.now();await w8(sec*1000);const T=(performance.now()-t0)/1000;D.sort((a,b)=>a-b);
 return {wall:+T.toFixed(2),raf:+(nf/T).toFixed(2),processed:+(np/T).toFixed(2),steps:+(ns/T).toFixed(2),simSpeed:+(ns/60/T).toFixed(3),
   frameMs:{mean:+(D.reduce((a,b)=>a+b,0)/Math.max(1,D.length)).toFixed(2),med:+(D[D.length>>1]||0).toFixed(2),p95:+(D[Math.floor(D.length*.95)]||0).toFixed(2)},cur:TUT.cur&&TUT.cur.k};}"""
async def main():
    res=[]
    async with async_playwright() as pw:
        br=await pw.chromium.launch(args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
        for thr in THR:
            for i in range(REPS):
                for tag,b in (('A',A),('B',B)):
                    P=await h.newpage(br,1600,900,url='file://'+b,alpha=False)
                    if thr!=1:
                        s=await P.pg.context.new_cdp_session(P.pg);await s.send('Emulation.setCPUThrottlingRate',{'rate':thr})
                    ok=await P.js(q220.NEW,{});await P.js("async()=>{await waitCur('calib',30000);}")
                    r=await P.js(M,SEC);r.update(build=tag,thr=thr,rep=i,new=ok);res.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
                    await P.pg.context.close();json.dump(res,open(OUT,'w'),ensure_ascii=False,indent=1)
        await br.close()
asyncio.run(main())
