#!/usr/bin/env python3
# Корректирующее обновление · kit6 — новые версии исторических наборов, выведенные из kit/ ТОЧНЫМИ заменами (исторические файлы не трогаются).
#   python3 tools6/mkkit6.py            — пересоздать kit6/q130.py, q220.py, q310.py, q370.py, q380.py и kit6/DIFF.md
#   python3 tools6/mkkit6.py --check    — убедиться, что kit6 совпадает с тем, что даёт генератор (выход 1 при расхождении)
# Каждая замена обязана найтись ровно столько раз, сколько указано; иначе выход 3 (исходный набор изменился — генератор устарел).
# Наборы kit6 запускаются из kit/ (cwd=kit, PYTHONPATH=kit), импортируют h.py оттуда; результаты пишут в kit6/out/, а не в kit/.
import sys,os,difflib,hashlib
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));KIT=os.path.join(R,'kit');K6=os.path.join(R,'kit6')
WAITFOR='''
async def waitFor(P,cond,ms):
    # kit6: ожидание УСЛОВИЯ (опрос каждые 50 мс) вместо фиксированной паузы; возвращает мс до выполнения или None (не дождались)
    import time as _t
    t0=_t.time()
    while (_t.time()-t0)*1000<ms:
        if await P.js(cond):return round((_t.time()-t0)*1000)
        await P.wait(50)
    return None
'''
CLOUD49="()=>{const b=(window.__fake||{})['data/users/u_test/save'];return !!b&&b.done===49;}"
CLOUD0="()=>{const b=(window.__fake||{})['data/users/u_test/save'];return !!b&&b.done===0;}"
READY="()=>typeof CLOUD!=='undefined'&&CLOUD.state==='ready'&&!CLOUD.waiters.length"
ARCH6=r'''
# kit6: точный допуск ARCH·86 — только доказанное слияние 4 цепочек (tools6/archcheck6.py) и структурное доказательство (tools6/merge86.js
# против 1.5.24 builds5/void_b164.html); мутанты tools6/mut86.py обязаны быть отвергнуты. Без метки ARCH·86 — прежняя проверка.
R6=os.path.normpath(os.path.join(SP,'..'))
def arch86(html,v2):
    import tempfile
    env=dict(os.environ,ARCHCHECK_V2='1') if v2 else {k:v for k,v in os.environ.items() if k!='ARCHCHECK_V2'}
    base=SP+('arch_fp_v47v2.json' if v2 else 'arch_fp_v46.json');ex=os.path.join(R6,'kit6','data','arch_exact86v2.json' if v2 else 'arch_exact86.json')
    al=SP+('arch_allow_70_74.json' if v2 else 'arch_allow_74.json');A6=[sys.executable,os.path.join(R6,'tools6','archcheck6.py'),'diff',base]
    r=subprocess.run(A6+[html,al,'--exact',ex],capture_output=True,text=True,env=env)
    mg=subprocess.run(['node',os.path.join(R6,'tools6','merge86.js'),os.path.join(R6,'builds5','void_b164.html'),html],capture_output=True,text=True)
    td=tempfile.mkdtemp(prefix='mut86_');mk=subprocess.run([sys.executable,os.path.join(R6,'tools6','mut86.py'),html,td],capture_output=True,text=True)
    mut={}
    if mk.returncode==0:
        for m,p in json.loads(mk.stdout).items():
            a=subprocess.run(A6+[p,al,'--exact',ex],capture_output=True,text=True,env=env).returncode
            g=subprocess.run(['node',os.path.join(R6,'tools6','merge86.js'),os.path.join(R6,'builds5','void_b164.html'),p],capture_output=True,text=True).returncode
            mut[m]={'archcheck6':a,'merge86':g}
    import shutil;shutil.rmtree(td,ignore_errors=True)
    # archcheck видит только начало строки слоя: m86_post (перенос вызова внутри слоя) ловит merge86, не отпечаток — это ожидаемо
    mok=mk.returncode==0 and set(mut)=={'m86_merged','m86_other','m86_post','m86_behav'} and all(mut[m]['archcheck6']==1 for m in ('m86_merged','m86_other','m86_behav')) and all(v['merge86']==1 for v in mut.values())
    return {'archcheck6':r.returncode,'нарушения':r.stdout.strip()[:400],'merge86':mg.returncode,'merge86_err':mg.stdout[-300:] if mg.returncode else '','мутанты':mut,'мутанты_ok':mok},(r.returncode==0 and mg.returncode==0 and mok)
'''
EDITS={
 'q170.py':[
   ("@test('C03')\nasync def c03(b):\n    # после гибели двойника патруль разворачивается на игрока\n    P=await newpage(b)\n",
    "@test('C03')\nasync def c03(b):\n    # после гибели двойника патруль разворачивается на игрока\n    # kit6: игровой Math.random засеян (seed 2) до загрузки страницы. Состав патруля выбирается случайно (chaseDev); на 10 семенах обе сборки\n    # дают побитно одинаковый исход, а 3 из 10 составов не проходят условие на обеих (out7/c03seed). Без семени тест был лотереей.\n    P=await newpage(b,init=SEED6)\n",1),
   ("from h import *\n","from h import *\nSEED6=\"(()=>{let a=2;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};})();\"\n",1),
   ("'q170.json'))","'../kit6/out/q170.json'))",1)],
 'q130.py':[
   ("from h import *\n","from h import *\n"+WAITFOR,1),
   ("    P=await P0(b,init=FAKE(store),alpha=False);await P.wait(400);await P.js(LOADUI,C49);await P.wait(500)\n",
    "    P=await P0(b,init=FAKE(store),alpha=False);await P.wait(400);await P.js(LOADUI,C49);w1=await waitFor(P,\"%s\",15000)  # kit6: облако получило 49\n"%CLOUD49,1),
   ("    P2=await P0(b,init=FAKE(st),alpha=False);await P2.wait(700)\n    a=await P2.js(\"()=>doneCount()\")\n",
    "    P2=await P0(b,init=FAKE(st),alpha=False);await P2.wait(700);w2=await waitFor(P2,\"%s\",15000)  # kit6: начальная синхронизация облака завершена\n    a=await P2.js(\"()=>doneCount()\")\n"%READY,1),
   ("    await P2.js(\"()=>{toMenu();$('#bWorldNew').click();$('#bWorldNew').click();return G.state;}\");await P2.wait(500)\n",
    "    await P2.js(\"()=>{toMenu();$('#bWorldNew').click();$('#bWorldNew').click();return G.state;}\");w3=await waitFor(P2,\"%s\",15000);await P2.wait(500)  # kit6: запись «новый полёт» дошла до облака, затем прежние 500 мс — ничего не воскресло\n"%CLOUD0,1),
   ("    P3=await P0(b,init=FAKE(st2),alpha=False);await P3.wait(700)\n    c=await P3.js(\"()=>({done:G.save?doneCount():0,lab:$('#bWorld').textContent})\")\n",
    "    P3=await P0(b,init=FAKE(st2),alpha=False);await P3.wait(700);w4=await waitFor(P3,\"%s\",15000)\n    c=await P3.js(\"()=>({done:G.save?doneCount():0,lab:$('#bWorld').textContent})\")\n"%READY,1),
   ("**c,'errs':P3.errs[:2]})","**c,'errs':P3.errs[:2],'kit6_wait_ms':[w1,w2,w3,w4]})",1),
   ("'q130.json'))","'../kit6/out/q130.json'))",1)],
 'q220.py':[
   ("for(let i=0;i<40&&(G.prologue||G.state!=='world');i++)await w8(100);TUT.hist=[];",
    "for(let i=0;i<200&&(G.prologue||G.state!=='world');i++)await w8(100);TUT.hist=[];",1),
   ("if(TUT.cur&&TUT.cur.k===k)return true;",
    "if(TUT.cur&&TUT.cur.k===k&&(k!=='calib'||(TUT.cal&&TUT.cal.pts&&TUT.cal.pts.length))){window.__wc=performance.now()-t0;return true;}",1),
   ("return false;};return true;}\"\"\"",
    "return false;};\n  window.w8s=async ms=>{const n0=ARCH.steps74,need=Math.round(ms*60/1000),t0=performance.now();while(ARCH.steps74-n0<need&&performance.now()-t0<120000)await w8(10);};/* kit6: ожидание в ШАГАХ игры (ms·60/1000), а не в мс настоящего времени */\n  return true;}\"\"\"",1),
   ("waitCur('calib',4000)","waitCur('calib',20000)",4),
   ("'q220.json'))","'../kit6/out/q220.json'))",1)],
 'q310.py':[
   ("    ok=out[1280]==[False,False,False] and out[390]==[True,True,True]\n    rec('L03 «Масштаб», «Качество», «Кадры» работают только на телефоне — на ПК их нет, на телефоне есть',ok,out)\n",
    "    # kit6: с ARCH·90b (1.5.32, решение владельца Р2) «Кадры» есть и на ПК; без него — прежнее ожидание (проверка 1.5.24 не меняется)\n"
    "    v90b='ARCH·90b' in open(GAME.replace('file://',''),encoding='utf8').read()\n"
    "    ok=out[1280]==[False,False,v90b] and out[390]==[True,True,True]\n"
    "    rec('L03 «Масштаб», «Качество» только на телефоне; «Кадры» — только на телефоне до ARCH·90b, с ARCH·90b и на ПК',ok,{**out,'ARCH·90b':v90b})\n",1),
   ("run(TESTS,'q310'))","run(TESTS,'../kit6/out/q310'))",1)],
 'q370.py':[
   ("import asyncio,json,sys,os,subprocess\nfrom h import *\n","import asyncio,json,sys,os,subprocess\nfrom h import *\n"+ARCH6,1),
   ("    html=NEW.replace('file://','')\n    r=subprocess.run(['python3',SP+'archcheck.py'",
    "    html=NEW.replace('file://','')\n    if 'ARCH·86' in open(html,encoding='utf8').read():\n        info,ok=arch86(html,False)\n        rec('A02 (kit6) отпечаток цепочек и владельцев G: изменены только 4 цепочки ARCH·86 и ровно доказанным слиянием (archcheck6 + merge86 против 1.5.24); мутанты слияния и посторонней цепочки отвергнуты',ok,info);return\n    r=subprocess.run(['python3',SP+'archcheck.py'",1),
   ("'res370.json'))","'../kit6/out/res370.json'))",1)],
 'q380.py':[
   ("import asyncio,json,sys,os,subprocess\nfrom h import *\n","import asyncio,json,sys,os,subprocess\nfrom h import *\n"+ARCH6,1),
   ("    rec('B10 T1: archcheck — изменены ровно 8 ожидаемых цепочек",
    "    if 'ARCH·86' in s:  # kit6: 4 цепочки ARCH·86 — только доказанное слияние; прежние 11 — как раньше\n"
    "        got=[g for g in got if g not in ('renderSettings','renderSetScreen','tutEmit','tutMapDraw')];info,ok86=arch86(html,True)\n"
    "        rec('B10 (kit6) T1: archcheck v2 — прежние ожидаемые цепочки и 4 цепочки ARCH·86 ровно доказанным слиянием, новых владельцев G нет, новых генераторов нет',got==want and not newgen and ok86,{'прежние':got,'новые генераторы':newgen,**info});return\n"
    "    rec('B10 T1: archcheck — изменены ровно 8 ожидаемых цепочек",1),
   ("'res380.json'))","'../kit6/out/res380.json'))",1)],
}
def segedit(s,start,end,pairs):
    i=s.index(start);j=s.index(end,i);b=s[i:j]
    for o,n,c in pairs:
        if b.count(o)!=c:print(f'{start}: образец найден {b.count(o)} раз, ожидалось {c}: {o!r}');sys.exit(3)
        b=b.replace(o,n)
    return s[:i]+b+s[j:]
SEG={'q220.py':[("@test('U05')","@test('U06')",[('await w8(','await w8s(',5)]),
                ("@test('U07')","@test('U08')",[("const t0=performance.now();while(performance.now()-t0<14000&&!G.save.tut.done.calib){await w8(200);}",
                                                 "const s0=ARCH.steps74,t0=performance.now();while(ARCH.steps74-s0<14*60&&performance.now()-t0<180000&&!G.save.tut.done.calib){await w8(50);}/* kit6: 14 с игры, не настоящего времени */",1)])]}
SEG['q370.py']=[("@test('A13')","@test('A14')",[
   ("let n=0;const dm=drawMap;drawMap=function(){n++;return dm.apply(this,arguments);};",
    "let n=0,tk=0;const dm=drawMap;drawMap=function(){n++;return dm.apply(this,arguments);};const RAF=window.requestAnimationFrame;(function tick(){tk++;RAF(tick);})();/* kit6: тики rAF */",1),
   ("openMap('map');await w8(1000);const a=n;n=0;for(let i=0;i<4;i++)mapTab('map');await w8(1000);const b_=n;n=0;",
    "openMap('map');await w8(1000);const a=n,ta=tk;n=0;tk=0;for(let i=0;i<4;i++)mapTab('map');const s4=n;await w8(1000);const b_=n,tb=tk;n=0;",1),
   ("return {once:a,after4:b_,afterSwitch:c,afterClose:n};}",
    "return {once:a,after4:b_,afterSwitch:c,afterClose:n,perTickOnce:+(a/Math.max(1,ta)).toFixed(2),perTickAfter4:+((b_-s4)/Math.max(1,tb)).toFixed(2),syncDraws:s4};}",1),
   ("    good=lambda r:abs(r['after4']-r['once'])<=r['once']*.25+2 and r['afterClose']==0\n",
    "    good=lambda r:r['perTickAfter4']<=1.3 and r['afterClose']==0  # kit6: отрисовок карты на тик rAF после 4 нажатий (без синхронных отрисовок самих нажатий); второй цикл даёт ≈2 и больше\n",1)])]
def build():
    out={}
    for f,ed in EDITS.items():
        s=open(os.path.join(KIT,f),encoding='utf8').read();o=s
        for old,new,n in ed:
            c=s.count(old)
            if c!=n:print(f'{f}: образец найден {c} раз, ожидалось {n}:\n  {old[:120]!r}');sys.exit(3)
            s=s.replace(old,new)
        for st,en,pairs in SEG.get(f,[]):s=segedit(s,st,en,pairs)
        hdr='# kit6 · новая версия набора kit/%s (корректирующее обновление 1.5.35); исторический файл не изменён. Отличия — kit6/DIFF.md.\n'%f
        out[f]=(o,hdr+s)
    return out
if __name__=='__main__':
    out=build();os.makedirs(os.path.join(K6,'out'),exist_ok=True);bad=[]
    D=['# kit6 — отличия от исторических наборов kit/\n','Сгенерировано tools6/mkkit6.py. Исторические наборы в kit/ не изменены и остаются проверкой прежних сборок.\n']
    for f,(o,n) in out.items():
        p=os.path.join(K6,f)
        if '--check' in sys.argv:
            if not os.path.exists(p) or open(p,encoding='utf8').read()!=n:bad.append(f)
            continue
        open(p,'w',encoding='utf8').write(n)
        D.append('\n## %s\nисходный kit/%s sha256 %s → kit6/%s sha256 %s\n```diff\n'%(f,f,hashlib.sha256(o.encode()).hexdigest()[:16],f,hashlib.sha256(n.encode()).hexdigest()[:16]))
        D+=list(difflib.unified_diff(o.splitlines(True),n.splitlines(True),'kit/'+f,'kit6/'+f,n=1));D.append('```\n')
    if '--check' in sys.argv:print('kit6 соответствует генератору' if not bad else 'РАСХОЖДЕНИЕ: '+', '.join(bad));sys.exit(1 if bad else 0)
    open(os.path.join(K6,'DIFF.md'),'w',encoding='utf8').write(''.join(D));print('kit6:',', '.join(out))
