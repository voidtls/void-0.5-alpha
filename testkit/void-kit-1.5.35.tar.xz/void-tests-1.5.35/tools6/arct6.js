// Корректирующее обновление · arct6 — все чтения и записи G.zb.arcT и того, что пишет ветка дуги в zbFxTick (только чтение сборки).
//   node tools6/arct6.js <сборка.html> [--json out.json]
// Ищет по AST: (1) каждое обращение к свойству arcT — функция, чтение/запись; (2) условие ветки в zbFxTick, внутри которой пишется arcT;
// (3) что вызывает эта ветка (zbArc, part, zbFx, ГСЧ); (4) кто ЧИТАЕТ то, что ветка пишет: Z.fx / G.zb.fx (список эффектов босса),
// G.parts (частицы) — с именами функций, чтобы проверить, что это только отрисовка и ограничения числа эффектов.
const path=require('path'),fs=require('fs');
process.on('uncaughtException',e=>{console.error('arct6: внутренняя ошибка: '+(e&&e.stack||e));process.exit(3);});
const NM=path.join(__dirname,'..','node_modules');const acorn=require(path.join(NM,'acorn')),walk=require(path.join(NM,'acorn-walk'));
const a=process.argv.slice(2);const jo=a.indexOf('--json');const JOUT=jo>=0?a.splice(jo,2)[1]:null;
const html=fs.readFileSync(a[0],'utf8');const k=html.indexOf('<script>\n"use strict";');const src=html.slice(k+8,html.indexOf('</script>',k));
const ast=acorn.parse(src,{ecmaVersion:2022,sourceType:'script',ranges:true,locations:true});
// имя ближайшей функции верхнего уровня (или объявленной) для позиции
const fns=[];walk.full(ast,n=>{if(n.type==='FunctionDeclaration'&&n.id)fns.push([n.start,n.end,n.id.name]);});
const fnAt=p=>{let best=null;for(const f of fns)if(f[0]<=p&&p<f[1]&&(!best||f[0]>best[0]))best=f;return best?best[2]:'(верхний уровень)';};
const R={arcT:[],branch:null,branchCalls:[],fxReaders:{},partsReaders:{},lowFxReaders:{}};
walk.ancestor(ast,{MemberExpression(n,anc){
  const p=anc[anc.length-2];const prop=!n.computed&&n.property.name;
  const isW=p&&((p.type==='AssignmentExpression'&&p.left===n)||(p.type==='UpdateExpression'));
  if(prop==='arcT')R.arcT.push({fn:fnAt(n.start),line:n.loc.start.line,kind:isW?'запись':'чтение',obj:src.slice(n.object.start,n.object.end)});
  if(prop==='fx'&&(n.object.type==='Identifier'&&n.object.name==='Z'||src.slice(n.object.start,n.object.end)==='G.zb')){const f=fnAt(n.start);R.fxReaders[f]=(R.fxReaders[f]||0)+1;}
  if(prop==='parts'&&n.object.type==='Identifier'&&n.object.name==='G'&&!isW){const f=fnAt(n.start);R.partsReaders[f]=(R.partsReaders[f]||0)+1;}
  if(prop==='lowFx'&&n.object.type==='Identifier'&&n.object.name==='G'){const f=fnAt(n.start);const kk=isW?'w':'r';R.lowFxReaders[f]=R.lowFxReaders[f]||{r:0,w:0};R.lowFxReaders[f][kk]++;}
}});
// ветка в zbFxTick
walk.full(ast,n=>{if(n.type==='FunctionDeclaration'&&n.id&&n.id.name==='zbFxTick'){
  walk.ancestor(n,{AssignmentExpression(x,anc){if(x.left.type==='MemberExpression'&&x.left.property.name==='arcT'){
    const ifs=anc.filter(y=>y.type==='IfStatement').map(y=>src.slice(y.test.start,y.test.end));R.branch=ifs;}}});
  const top=n.body.body.find(s=>s.type==='IfStatement'&&/SET\.fx&&!G\.lowFx/.test(src.slice(s.test.start,s.test.end)));
  if(top){const calls={};walk.full(top.consequent,c=>{if(c.type==='CallExpression'){const nm=c.callee.type==='Identifier'?c.callee.name:src.slice(c.callee.start,c.callee.end);calls[nm]=(calls[nm]||0)+1;}});R.branchCalls=calls;}}});
R.arcTfns=[...new Set(R.arcT.map(x=>x.fn))];
console.log(JSON.stringify(R,null,1));if(JOUT)fs.writeFileSync(JOUT,JSON.stringify(R,null,1));
