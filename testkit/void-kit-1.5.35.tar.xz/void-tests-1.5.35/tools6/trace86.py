#!/usr/bin/env python3
# Корректирующее обновление · trace86 — поведенческое доказательство слияния ARCH·86 с РАЗДЕЛЁННЫМИ полями (замена вывода trace7).
#   python3 tools6/trace86.py run <сборка.html> <out.json>
#   python3 tools6/trace86.py cmp <A.json> <B.json> <A2.json> [--json out.json]   — A/B против A/A (A2 — второй прогон сборки A)
# Сценарии и обёртка всех глобальных функций — как в trace7 (тот же набор вызовов: 4 слитые цепочки и соседние функции).
# Для КАЖДОГО вызова сценария отдельно записываются:
#   order   — порядок вызванных глобальных функций (все уровни вложенности);
#   args    — аргументы каждого вложенного вызова (примитивы — значения, объекты — порядковый номер объекта);
#   results — результат каждого вложенного вызова (то же кодирование; «throw», если вызов не вернулся);
#   effects — какие поля G изменились за вызов и их новые хэши (глубокая сериализация, циклы и DOM-узлы заменены метками),
#             и какие таймеры вызов поставил (задержки; сами таймеры не исполняются — до сценария все прежние таймеры сняты);
#   state   — G.state, хэш состояния stH, исключение и результат самого вызова;
#   visual  — хэш DOM (без версии/исходника): недетерминированные видимые данные, в доказательство НЕ входит, только показывается.
# Окружение закреплено одинаково для обеих сборок: время виртуальное, RNG засеян (init st5), звук запускается без жеста
# (--autoplay-policy=no-user-gesture-required — убирает гонку autoClick132/applyAudio, найденную в trace7); часы звука
# (AudioContext.currentTime) детерминированы — шаг 1 мс на обращение: иначе секвенсор музыки (mzChain/mzNext, vStart) идёт по настоящему
# времени и даёт расхождения даже в A/A.
# Вердикт cmp: для слитых функций (renderSettings, renderSetScreen, tutEmit, tutMapDraw) — ни одного расхождения ни в одном поле,
# кроме visual; для остальных вызовов — расхождения A/B допускаются только там же и того же вида, что и в A/A. Выход 0/1; 3 — сбой.
import asyncio,json,sys,os
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','tools5'));sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import st5,trace7
from playwright.async_api import async_playwright
MERGED=('renderSettings','renderSetScreen','tutEmit','tutMapDraw')
WRAP=r"""(names)=>{window.__L=null;let n=0;Date.now=()=>1.7e12+performance.now();
 {let at=0;try{Object.defineProperty(BaseAudioContext.prototype,'currentTime',{configurable:true,get(){return at+=0.001;}});}catch(e){}}/* часы звука — по числу обращений, не по настоящему времени */
 if(typeof mzDecode==='function')mzDecode=function(){return new Promise(()=>{});};/* новые дорожки музыки не декодируются: готовность декодирования
   (асинхронный decodeAudioData) — недетерминированный момент, от него зависело, вызывается ли mzChain в кадре; на обеих сборках одинаково */
 {const hi=setTimeout(()=>{},0);for(let i=1;i<=hi+50;i++){clearTimeout(i);clearInterval(i);}}/* все таймеры, поставленные до сценария (autoClick132, секвенсор музыки, опросы), сняты */
 window.__TQ=[];window.setTimeout=(f,ms)=>{if(window.__L)window.__TQ.push('t'+(ms|0));return 0;};window.setInterval=(f,ms)=>{if(window.__L)window.__TQ.push('i'+(ms|0));return 0;};
 /* таймеры, которые ставят вызовы сценария, не исполняются, а записываются (задержка) — сравнивается синхронное поведение и то, что оно запланировало */
 const VH=v=>v===undefined?'u':v===null?'n':typeof v==='function'?'fn':typeof v==='object'?('o'+oid(v)):(typeof v)[0]+':'+String(v).slice(0,60);
 const AH=a=>Array.prototype.map.call(a,VH).join('|');
 window.SJ=v=>{const seen=new WeakSet();try{return JSON.stringify(v,(k,x)=>{if(x&&typeof x==='object'){if(x instanceof Node)return '#N';if(seen.has(x))return '~';seen.add(x);}if(typeof x==='function')return '#f';if(typeof x==='number'&&!isFinite(x))return String(x);return x;})||'u';}catch(e){return 'ERR';}};
 window.GH=()=>{const h={};for(const k of Object.keys(G))h[k]=fnv(SJ(G[k]));return h;};
 for(const nm of names){let f;try{f=eval(nm);}catch(e){continue;}if(typeof f!=='function')continue;
   const w=function(){if(!window.__L)return f.apply(this,arguments);const e=[nm,AH(arguments),'throw'];window.__L.push(e);const r=f.apply(this,arguments);e[2]=VH(r);return r;};
   try{eval(nm+'=w');n++;}catch(e){}}
 window.domH=()=>{const c=document.body.cloneNode(true);c.querySelectorAll('script,style,dl.kv,#verTag').forEach(e=>e.remove());return fnv(c.innerHTML.split(VER_TAG).join('V').split(VER_TAG.split(' ')[0]).join('V'));};
 window.CALL2=(label,code)=>{const g0=GH();window.__L=[];window.__TQ=[];let ex=null,rv;try{rv=eval(code);}catch(e){ex=String(e&&e.message||e).slice(0,120);}const L=window.__L;window.__L=null;const g1=GH();
   const eff={};for(const k of new Set([...Object.keys(g0),...Object.keys(g1)]))if(g0[k]!==g1[k])eff[k]=g1[k]||'удалён';
   eff['(таймеры)']=window.__TQ.join(',');return {label,order:L.map(e=>e[0]),args:L.map(e=>e[1]),results:L.map(e=>e[2]),effects:eff,state:[G.state,stH(),ex,VH(rv)],visual:domH()};};
 return n;}"""
async def run(build,out):
    names=st5.gnames(build);res={'build':os.path.basename(build),'runs':{}}
    async with async_playwright() as pw:
        AR=['--no-sandbox','--autoplay-policy=no-user-gesture-required']
        b=await pw.chromium.launch(executable_path=st5.CHROME,args=AR) if st5.CHROME else await pw.chromium.launch(args=AR)
        for key,enc,steps,dev,touch in [('menu','menu',trace7.MENU,False,False),('menu-dev','menu',trace7.MENU,True,False),('play','m10',trace7.PLAY,False,False),('play-dev','m10',trace7.PLAY,True,False),
                                        ('play-touch','m10',trace7.PLAY,False,True),('world','world',trace7.WORLD,False,False),('world-dev','world',trace7.WORLD,True,False)]:
            ctx,pg,errs=await (st5.page(b,build,390,844,True) if touch else st5.page(b,build))
            await pg.wait_for_function("()=>performance.now()>=2600",polling=50,timeout=20000)  # оба разовых таймера autoClick132 отработали
            await pg.evaluate(st5.COMMON)
            if dev:await pg.evaluate("()=>{try{localStorage.setItem('void_dev','1');G.dev=Object.assign(G.dev||{},{on:true});if(typeof devUnlock==='function')devUnlock();}catch(e){}}")
            if enc=='menu':await pg.evaluate("()=>{let now=50000;performance.now=()=>now;window.__now=()=>now;window.__tick=()=>{now+=1000/60;frame(now);};}")
            else:await pg.evaluate(st5.SCEN,{'enc':enc})
            await pg.wait_for_function("()=>typeof MZ==='undefined'||Object.values(MZ.pl||{}).every(P=>!P.dec||!Object.keys(P.dec).length)",polling=50,timeout=20000)  # начатые декодирования завершены
            n=await pg.evaluate(WRAP,names);log=[]
            for lab,code in steps:log.append(await pg.evaluate("([l,c])=>CALL2(l,c)",[lab,code]))
            res['runs'][key]={'wrapped':n,'log':log,'errs':errs[:5]};await ctx.close()
            print(key,'обёрнуто',n,'вызовов',len(log),'вложенных',sum(len(r['order']) for r in log),errs[:1],flush=True)
        await b.close()
    json.dump(res,open(out,'w'),ensure_ascii=False)
FIELDS=('order','args','results','effects','state','visual')
def diffs(X,Y):
    out=[]
    for k in X['runs']:
        la=X['runs'][k]['log'];lb=Y['runs'].get(k,{}).get('log') or []
        if len(la)!=len(lb):out.append((k,'*','длина',None));continue
        for i,(x,y) in enumerate(zip(la,lb)):
            for f in FIELDS:
                if x[f]!=y[f]:
                    det=None
                    if f=='order':det=sorted(set(x[f])^set(y[f]))[:8]
                    elif f=='effects':det=sorted(k2 for k2 in set(x[f])|set(y[f]) if x[f].get(k2)!=y[f].get(k2))[:8]
                    out.append((k,f'{i}:{x["label"]}',f,det))
    return out
def cmp(a,b,a2,jout):
    A,B,A2=[json.load(open(p)) for p in (a,b,a2)]
    ab,aa=diffs(A,B),diffs(A,A2)
    aaset={(k,lab,f) for k,lab,f,_ in aa}
    merged=[d for d in ab if d[2]!='visual' and d[1].split(':',1)[1].split('-')[0].rstrip('0123456789?') in MERGED]
    unexplained=[d for d in ab if d[2]!='visual' and (d[0],d[1],d[2]) not in aaset]
    tot=sum(len(A['runs'][k]['log']) for k in A['runs']);nested=sum(len(r['order']) for k in A['runs'] for r in A['runs'][k]['log'])
    cnt=lambda L:{f:sum(1 for d in L if d[2]==f) for f in FIELDS}
    R={'calls':tot,'nested':nested,'A/B':cnt(ab),'A/A':cnt(aa),'merged_calls':sum(1 for k in A['runs'] for r in A['runs'][k]['log'] if r['label'].split('-')[0].rstrip('0123456789?') in MERGED),
       'merged_diffs':merged,'unexplained':unexplained,'ab':ab[:60],'aa':aa[:60],'ok':not merged and not unexplained}
    if jout:json.dump(R,open(jout,'w'),ensure_ascii=False,indent=1)
    print(f"trace86: вызовов {tot}, вложенных {nested}; из них вызовов слитых функций {R['merged_calls']}")
    for f in FIELDS:print(f'  {f:8s} расхождений A/B {R["A/B"][f]:3d} · A/A {R["A/A"][f]:3d}'+('  (видимые данные — не доказательство)' if f=='visual' else ''))
    for d in merged:print('  СЛИТАЯ ФУНКЦИЯ, расхождение:',d)
    for d in unexplained:print('  НЕОБЪЯСНЁННОЕ (нет в A/A):',d)
    print('ВЕРДИКТ:', 'поведение слитых цепочек совпадает по всем полям; прочие расхождения — только те, что есть в A/A' if R['ok'] else 'РАСХОЖДЕНИЕ')
    sys.exit(0 if R['ok'] else 1)
if __name__=='__main__':
    a=sys.argv[1:]
    if a and a[0]=='run':asyncio.run(run(a[1],a[2]))
    elif a and a[0]=='cmp':cmp(a[1],a[2],a[3],a[a.index('--json')+1] if '--json' in a else None)
    else:print(open(__file__,encoding='utf8').read().split('import asyncio')[0]);sys.exit(3)
