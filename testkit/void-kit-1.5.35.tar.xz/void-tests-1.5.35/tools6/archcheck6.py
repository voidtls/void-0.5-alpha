#!/usr/bin/env python3
# Корректирующее обновление · archcheck6 — archcheck (kit/archcheck.py, не изменён) с точным допуском для ARCH·86.
#   python3 tools6/archcheck6.py diff <base.json> <сборка.html> [allow.json] --exact <exact86.json>
#   python3 tools6/archcheck6.py mkexact <до.html> <после.html> <exact86.json>     (ARCHCHECK_V2=1 — для отпечатка v2)
# Прежний допуск allow.json разрешает изменение цепочки ПО ИМЕНИ (любое). Для 4 цепочек ARCH·86 этого мало: разрешено только
# доказанное преобразование —
#   1. цепочка в базе равна exact.from (ровно тот набор слоёв, что был до слияния);
#   2. цепочка в сборке равна exact.to (ровно объединённый слой, побайтно по отпечатку тела);
#   3. форма: to = from, в котором одна смежная серия из ≥2 слоёв заменена одним новым слоем, прочие слои и их порядок сохранены;
#   4. в сборке с меткой ARCH·86 все 4 цепочки обязаны быть изменены (отсутствие изменения — тоже нарушение).
# Любая другая изменённая цепочка, другое изменение этих 4 цепочек, новый владелец G — нарушение (как в archcheck).
# Структурное содержание объединённого слоя доказывает tools6/merge86.js; здесь — что в сборке стоит именно он.
# Выход: 0 — нет нарушений; 1 — нарушения; 3 — ошибка вызова.
import sys,os,json
sys.path.insert(0,os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),'kit'))
import archcheck
NAMES=['renderSettings','renderSetScreen','tutEmit','tutMapDraw']
def fp(p):return archcheck.fingerprint(archcheck.main_script(open(p,encoding='utf8').read()))
def shape_ok(a,b):
    if len(b)>=len(a) or b==a:return False
    k=len(a)-len(b)+1
    for i in range(len(b)):
        if a[:i]==b[:i] and a[i+k:]==b[i+1:] and b[i] not in a:return True
    return False
def diff(base,cur,allow,exact,has86):
    names=set(exact['chains']) if has86 else set()
    out=archcheck.diff(base,cur,{**allow,'chains':[c for c in allow.get('chains',[]) if c not in NAMES]})  # имена 86 прежним допуском не разрешаются
    keep=[]
    for v in out:
        if v[0]=='chain' and v[1] in names:
            n=v[1];e=exact['chains'][n];a=base['chains'].get(n,[]);b=cur['chains'].get(n,[])
            why=[]
            if a!=e['from']:why.append('база не равна exact.from')
            if b!=e['to']:why.append('сборка не равна exact.to')
            if not shape_ok(a,b):why.append('не замена одной смежной серии одним слоем')
            if why:keep.append(('chain',n,len(a),len(b),'вне доказанного преобразования: '+'; '.join(why)))
        else:keep.append(v)
    if has86:
        for n in names:
            if base['chains'].get(n,[])==cur['chains'].get(n,[]):keep.append(('chain',n,0,0,'ожидаемое изменение ARCH·86 отсутствует'))
    return keep
if __name__=='__main__':
    a=sys.argv[1:]
    try:
        if a[0]=='mkexact':
            A,B=fp(a[1]),fp(a[2]);ex={'chains':{n:{'from':A['chains'][n],'to':B['chains'][n]} for n in NAMES},
                'v2':bool(os.environ.get('ARCHCHECK_V2')),'src':[os.path.basename(a[1]),os.path.basename(a[2])],
                'why':'ARCH·86: 4 серии одной подсистемы слиты в один слой; содержание объединённого слоя доказано tools6/merge86.js'}
            for n in NAMES:assert shape_ok(ex['chains'][n]['from'],ex['chains'][n]['to']),n
            json.dump(ex,open(a[3],'w'),ensure_ascii=False,indent=1);print('ok',a[3]);sys.exit(0)
        if a[0]!='diff':raise IndexError
        ei=a.index('--exact');exact=json.load(open(a[ei+1]));a=a[:ei]+a[ei+2:]
        base=json.load(open(a[1]));html=open(a[2],encoding='utf8').read();cur=archcheck.fingerprint(archcheck.main_script(html))
        allow=json.load(open(a[3])) if len(a)>3 else {}
        d=diff(base,cur,allow,exact,'ARCH·86' in html)
        print(json.dumps({'violations':d[:40],'n':len(d)},ensure_ascii=False));sys.exit(1 if d else 0)
    except (IndexError,ValueError):
        print(open(__file__,encoding='utf8').read().split('import sys')[0]);sys.exit(3)
