#!/usr/bin/env python3
# Корректирующее обновление · упаковка переносимого комплекта 1.5.35: tar.xz с метками @@KIT@@/@@CHROME@@ вместо путей + inventory6.json.
#   python3 tools6/mkpack6.py <архив.tar.xz>
# Входит всё, что нужно приёмке tools6/accept6.py с нуля: исходные сборки (builds5 — 1.5.20…1.5.24, builds6 — 1.5.35 и прежние
# редакции v1/v2), патчи 81–84 (stage5) и 85–93 (stage6) с генераторами, сборщик kit/arch74.py, исторический kit (q90…q380, стенды t72,
# эталоны reg20, k80/e24), kit6 (новые версии наборов), инструменты tools5/tools6, node_modules (закреплённые версии), эталоны 1.5.24
# (out5/p84: стенды, регрессия, gkeys), baseline (A/A), реестр известных отклонений и закреплённые версии (ref6), настройка setup6.py.
# Не входят: производные файлы (*.html.js, варианты _a24v/_o26 — воспроизводятся), выходы прогонов kit/q*.json, kit6/out, кэши,
# одноразовые сценарии с путями к старому черновику (tools5/mkkit.py, tools5/rw_all.py — история этапа 5, не нужны для проверки).
import os,sys,json,hashlib,shutil,subprocess,re
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));OUT=os.path.abspath(sys.argv[1]);P=json.load(open(os.path.join(R,'.kitpaths.json')))
TXT=('.py','.js','.sh','.json','.txt','.md','.jsonl','.log')
INCL=['README_KIT6.md','setup6.py','setup_kit.py','setup5.py','runreg.sh','kit','kit6','tools5','tools6','node_modules','baseline','stage5','stage6','builds5','builds6','ref6',
      'out5/p84/s164','out5/p84/s164a24','out5/p84/reg24','out5/p84/reg24_save','out5/p84/gkeys_164.json','out5/p84/rollback.txt']
SKIP=re.compile(r'(\.html\.js$)|(_a24v|_o26|_a24o26)\.html$|^tools5/(mkkit|rw_all)\.py$|^kit6/out/|__pycache__|\.pyc$|^kit/(q\w+|res\d+)\.json$|^stage6/kit_orig/')
TPL=('kit/','kit6/','tools6/diag/')
def tmpl(rel,b):
    if rel.startswith(TPL) and rel.endswith(TXT) and len(b)<3_000_000:
        return b.decode('utf8','surrogateescape').replace(P['kit'],'@@KIT@@').replace(P['chrome'],'@@CHROME@@').encode('utf8','surrogateescape')
    return b
files=[]
for top in INCL:
    p=os.path.join(R,top)
    if not os.path.exists(p):print('нет',top);sys.exit(3)
    if os.path.isfile(p):files.append(top);continue
    for r,ds,fs in os.walk(p):
        ds[:]=sorted(d for d in ds if d!='__pycache__')
        for f in sorted(fs):
            rel=os.path.relpath(os.path.join(r,f),R).replace(os.sep,'/')
            if not SKIP.search(rel):files.append(rel)
ST=os.path.join(os.path.dirname(OUT),'pack6_stage');D=os.path.join(ST,'void-tests-1.5.35');shutil.rmtree(ST,ignore_errors=True);inv=[];leak=[]
for rel in files:
    b=tmpl(rel,open(os.path.join(R,rel),'rb').read());inv.append([rel,len(b),hashlib.sha256(b).hexdigest()])
    if rel.endswith(('.py','.js','.sh')) and not rel.startswith(('out5/','baseline/')) and (P['kit'].encode() in b or ('/home/'+'claude').encode() in b or P['chrome'].encode() in b):leak.append(rel)  # исполняемое — без путей; журналы прогонов хранят пути как запись истории
    d=os.path.join(D,rel);os.makedirs(os.path.dirname(d),exist_ok=True);open(d,'wb').write(b)
    if os.access(os.path.join(R,rel),os.X_OK):os.chmod(d,0o755)
json.dump({'files':inv,'note':'SHA-256 файлов в упакованном виде (пути заменены метками @@KIT@@/@@CHROME@@).'},open(os.path.join(D,'inventory6.json'),'w'),ensure_ascii=False,indent=0)
if leak:print('АБСОЛЮТНЫЕ ПУТИ в файлах (проверить):',leak[:20])
env=dict(os.environ,XZ_OPT='-9e --lzma2=preset=9e,dict=192MiB -T1')
subprocess.run(['tar','-C',ST,'-cJf',OUT,'void-tests-1.5.35'],check=True,env=env)
shutil.rmtree(ST,ignore_errors=True)
print('файлов',len(inv),'· архив',round(os.path.getsize(OUT)/1e6,1),'МБ','· абсолютных путей:',len(leak));sys.exit(1 if leak else 0)
