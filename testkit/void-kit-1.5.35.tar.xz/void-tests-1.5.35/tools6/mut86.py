#!/usr/bin/env python3
# Корректирующее обновление · мутанты для проверки точного допуска ARCH·86 (archcheck6, q370 A02 / q380 B10 в kit6) и merge86.
#   python3 tools6/mut86.py <сборка.html> <папка>  → пишет мутанты и печатает их список (JSON)
# Каждый мутант — одна текстовая правка, которую проверка обязана отвергнуть:
#   m86_merged  — в объединённом слое renderSettings переставлены два оператора pre (изменено слитое сверх доказанного);
#   m86_other   — в посторонней цепочке toMenu (не из 4) в начало тела слоя добавлен оператор;
#   m86_post    — в объединённом слое tutMapDraw вызов прежней перенесён после post (нарушен порядок исполнения);
#   m86_behav   — в объединённом слое tutEmit условие слоя «прыжок» испорчено ('jump' → 'jump_'): меняется ПОВЕДЕНИЕ (положительный
#                 контроль для trace86: такое изменение поведенческий стенд обязан увидеть).
# Если правку не удаётся применить ровно в одном месте — выход 3 (мутант не создан — проверка не может считаться выполненной).
import sys,os,json,re
src,out=sys.argv[1],sys.argv[2];os.makedirs(out,exist_ok=True)
s=open(src,encoding='utf8').read();made={}
def mk(name,old,new,count=1):
    n=s.count(old)
    if n!=count:print(json.dumps({'error':f'{name}: образец найден {n} раз, ожидалось {count}'},ensure_ascii=False));sys.exit(3)
    p=os.path.join(out,name+'.html');open(p,'w',encoding='utf8').write(s.replace(old,new,1));made[name]=p
mk('m86_merged','renderSettings=function(){const was_861={};let foc_861=null;','renderSettings=function(){let foc_861=null;const was_861={};')
m=re.search(r'\{const (_\w+)=toMenu;toMenu=function\(([^)]*)\)\{',s)
if not m or '_p86' in m.group(1):print(json.dumps({'error':'m86_other: слой toMenu не найден'},ensure_ascii=False));sys.exit(3)
mk('m86_other',m.group(0),m.group(0)+'void 0;')
i=s.index('{const _p86=tutMapDraw;tutMapDraw=function(');j=s.index('};}',i)+3;L=s[i:j]
call='const r86=_p86.apply(this,arguments);'
if L.count(call)!=1:print(json.dumps({'error':'m86_post: вызов не найден'},ensure_ascii=False));sys.exit(3)
k=L.index(call);rest=L[k+len(call):];ret=rest.rindex('return r86;')
L2=L[:k]+rest[:ret]+call+rest[ret:]
mk('m86_post',L,L2)
mk('m86_behav',"{const _p86=tutEmit;tutEmit=function(ev_862){const ev_861=arguments[0];if(ev_862==='jump')","{const _p86=tutEmit;tutEmit=function(ev_862){const ev_861=arguments[0];if(ev_862==='jump_')")
print(json.dumps(made,ensure_ascii=False))
