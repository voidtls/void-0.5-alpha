#!/usr/bin/env python3
# Корректирующее обновление 1.5.35 · run6 = run5 (tools5/run5.py, не изменён) + наборы kit6 поверх kit и одиночный прогон замеров.
#   reg … [--overlay kit6]   — набор, для которого есть kit6/<имя>.py, берётся оттуда (cwd=kit, PYTHONPATH=kit); в run.json — откуда взят каждый;
#   reg … [--solo q340s]     — перечисленные наборы идут ПОСЛЕ параллельных цепочек, по одному (замеры времени без параллельной нагрузки).
#   reg … [--base-overlay папка] — ожидаемое число записей для наборов kit6 берётся из этой папки (прогон kit6 на эталонной сборке).
#   python3 tools5/run5.py reg    <сборка.html> <папка> [--suites q90,q96] [--chains 2] [--base kit/reg20] [--aa baseline/reg20_aa]
#        (q71save/q73save: --suites q71save,q73save --base baseline/reg20_save --aa baseline/reg20_save)
#   python3 tools5/run5.py k      <сборка.html> <jobs.json> <out.jsonl> [--par 2] [--ref kit/t72/k80.jsonl] [--off A-26]
#        (--off добавляет флаги к флагам каждого задания; доставка проверяется kflags5.py перед прогоном)
#   python3 tools5/run5.py stands <сборка.html> <папка> [--ref папка-эталона] [--a24] [--allow f1,f2]
#   python3 tools5/run5.py investigate <A.html> <B.html> <папка> <повторов> q170:C03 [q270:Y09 …]
# Итог каждого запуска — run.json в папке результата и строка STATUS. Коды выхода:
#   0 — COMPLETE и нет новых расхождений; 1 — COMPLETE, но есть расхождения; 2 — PARTIAL (неполный/упавший набор);
#   3 — INFRA_FAIL (нет сборки, браузера, кит не настроен, недопустимый путь).
import sys,os,json,subprocess,hashlib,time,threading,re,shutil
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));KIT=os.path.join(R,'kit');T5=os.path.join(R,'tools5')
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=KIT)
def sha(p):
    with open(p,'rb') as f:return hashlib.sha256(f.read()).hexdigest()
def die(msg,out=None):
    print('STATUS INFRA_FAIL:',msg)
    if out:os.makedirs(out,exist_ok=True);json.dump({'status':'INFRA_FAIL','why':msg},open(os.path.join(out,'run.json'),'w'),ensure_ascii=False,indent=1)
    sys.exit(3)
def absbuild(p,out=None):
    a=os.path.abspath(p)
    if not os.path.isfile(a):die('нет сборки '+a,out)
    if "'" in a or '\\' in a or '"' in a:die('путь содержит кавычку или обратную черту — тесты подставляют его в строковые литералы: '+a,out)
    return a
def precheck(out):
    if not os.path.exists(os.path.join(R,'.kitpaths.json')):die('комплект не настроен: python3 setup_kit.py',out)
    kp=json.load(open(os.path.join(R,'.kitpaths.json')))
    if os.path.realpath(kp['kit'])!=os.path.realpath(KIT):die('комплект перенесён после настройки: снова python3 setup_kit.py',out)
    if not os.path.exists(kp['chrome']):die('браузер не найден: '+kp['chrome'],out)
    return kp
def tool_shas(files):return {os.path.relpath(f,R):sha(f)[:16] for f in files if os.path.exists(f)}
REC=re.compile(r'^\s*(OK|FAIL)\s',re.M)
def records(log):
    try:t=open(log,encoding='utf8',errors='replace').read()
    except FileNotFoundError:return -1,False
    return len(REC.findall(t)),('Traceback' in t)
def expected_counts():
    d=os.path.join(KIT,'reg20');return {f[:-4]:records(os.path.join(d,f))[0] for f in os.listdir(d) if f.endswith('.log')}
CHAIN=[['q340s','q210','q160','q190','q270','q130','q150','q110','q96','q290','q240','q370','q300','q320'],
       ['q350','q200','q180','q220','q330','q120','q95','q90','q280','q250','q260','q170','q140','q310','q360','q380']]
def cmd_reg(a):
    build=absbuild(a[0]);out=os.path.abspath(a[1]);os.makedirs(out,exist_ok=True);precheck(out)
    suites=a[a.index('--suites')+1].split(',') if '--suites' in a else None
    chains=int(a[a.index('--chains')+1]) if '--chains' in a else 2
    tmo=int(a[a.index('--timeout')+1]) if '--timeout' in a else 3600
    base=os.path.abspath(a[a.index('--base')+1]) if '--base' in a else os.path.join(KIT,'reg20')
    exp={f[:-4]:records(os.path.join(base,f))[0] for f in os.listdir(base) if f.endswith('.log')}
    ov=os.path.abspath(a[a.index('--overlay')+1]) if '--overlay' in a else None
    solo=a[a.index('--solo')+1].split(',') if '--solo' in a else []
    if ov and not os.path.isdir(ov):die('нет папки наборов '+ov,out)
    plan=[[s for s in c if not suites or s in suites] for c in CHAIN] if not suites else [suites[i::chains] for i in range(chains)]
    plan=[[s for s in c if s not in solo] for c in plan];solo=[s for s in solo if not suites or s in suites]
    src={}
    res={};lock=threading.Lock()
    def run_chain(c):
        for s in c:
            f=os.path.join(ov,s+'.py') if ov and os.path.exists(os.path.join(ov,s+'.py')) else os.path.join(KIT,s+'.py')
            src[s]=os.path.relpath(f,R)
            if not os.path.exists(f):
                with lock:res[s]={'status':'MISSING'};continue
            t0=time.time();log=os.path.join(out,s+'.log')
            try:
                with open(log,'w') as L:p=subprocess.run([sys.executable,f],cwd=KIT,env=dict(ENV,GAME_URL='file://'+build,TMO=ENV.get('TMO','1500')),stdout=L,stderr=subprocess.STDOUT,timeout=tmo);rc=p.returncode
            except subprocess.TimeoutExpired:rc='TIMEOUT'
            n,tb=records(log);e=exp.get(s)
            st='TIMEOUT' if rc=='TIMEOUT' else ('CRASH' if rc!=0 else ('INCOMPLETE' if (e is not None and n!=e) else ('UNKNOWN_EXPECT' if e is None else 'OK')))
            if tb and st=='OK':st='OK_WITH_TRACEBACK' if n==e else 'INCOMPLETE'
            with lock:res[s]={'status':st,'rc':rc,'records':n,'expected':e,'sec':round(time.time()-t0)}
            print(f'{s}: {st} (записей {n}/{e}, {round(time.time()-t0)} с)',flush=True)
    th=[threading.Thread(target=run_chain,args=(c,)) for c in plan if c];[x.start() for x in th];[x.join() for x in th]
    if solo:print('одиночные наборы (без параллельной нагрузки):',','.join(solo),flush=True);run_chain(solo)
    complete=all(v['status'] in('OK','OK_WITH_TRACEBACK') for v in res.values())
    cmp=None
    if complete:
        aa=a[a.index('--aa')+1] if '--aa' in a else os.path.join(R,'baseline','reg20_aa')
        args=[sys.executable,os.path.join(T5,'cmpreg5.py'),base,out,'--aa',aa,'--json',os.path.join(out,'cmp.json')]
        if suites:args+=['--only',','.join(suites)]
        p=subprocess.run(args,capture_output=True,text=True);open(os.path.join(out,'cmp.txt'),'w').write(p.stdout);cmp=p.returncode;print(p.stdout[-1500:])
    status='COMPLETE' if complete else 'PARTIAL'
    J={'status':status,'build':build,'buildSha':sha(build),'suites':res,'source':src,'solo':solo,'overlay':os.path.relpath(ov,R) if ov else None,'cmpExit':cmp,'nproc':os.cpu_count(),'tools':tool_shas([__file__,os.path.join(T5,'cmpreg5.py')]+[os.path.join(R,src.get(s,'kit/'+s+'.py')) for s in res])}
    json.dump(J,open(os.path.join(out,'run.json'),'w'),ensure_ascii=False,indent=1)
    print('STATUS',status,'· расхождения' if cmp else '');sys.exit(2 if not complete else (1 if cmp else 0))
def cmd_k(a):
    build=absbuild(a[0]);jobs=a[1];outf=os.path.abspath(a[2]);od=os.path.dirname(outf);os.makedirs(od,exist_ok=True);precheck(od)
    par=a[a.index('--par')+1] if '--par' in a else '2';ref=a[a.index('--ref')+1] if '--ref' in a else os.path.join(KIT,'t72','k80.jsonl')
    st74=open(os.path.join(KIT,'t72','st74.py'),encoding='utf8').read()
    if st74.count('window.requestAnimationFrame=()=>0;')<2:die('st74.py: не найдено место подстановки флагов',od)
    J=json.load(open(jobs));
    add=a[a.index('--off')+1].split(',') if '--off' in a else []
    if '<script>window.__archOff' in open(build,encoding='utf8').read(4000):die('сборка-вариант с __archOff несовместима с K-стендом: st74 сам задаёт __archOff из поля flags (флаги задания потеряются); используйте --off',od)
    k=subprocess.run([sys.executable,os.path.join(T5,'kflags5.py'),build],capture_output=True,text=True,env=ENV)
    if k.returncode:die('флаги не доходят до страницы в K-стенде: '+k.stdout[-300:],od)
    for j in J:
        if add:j['flags']=sorted(set(j.get('flags',[]))|set(add))
        if j.get('url','').endswith(('/t72/g160.html','/t72/g160a24.html')):j['url']='file://'+build
    jf=outf+'.jobs.json';json.dump(J,open(jf,'w'));
    if os.path.exists(outf):os.remove(outf)
    p=subprocess.run([sys.executable,'st74.py',jf,outf,par],cwd=os.path.join(KIT,'t72'),env=ENV,capture_output=True,text=True)
    open(outf+'.log','w').write(p.stdout+p.stderr)
    rows=[json.loads(l) for l in open(outf)] if os.path.exists(outf) else []
    ids={r['id'] for r in rows};miss=[j['id'] for j in J if j['id'] not in ids];errs=[r['id'] for r in rows if r.get('err') or r.get('nerr')]
    complete=not miss and not errs and p.returncode==0
    cmp=subprocess.run([sys.executable,os.path.join(T5,'cmpk5.py'),ref,outf],capture_output=True,text=True)
    print(cmp.stdout[-1200:])
    status='COMPLETE' if complete else 'PARTIAL'
    json.dump({'status':status,'build':build,'buildSha':sha(build),'addFlags':add,'jobs':len(J),'rows':len(rows),'missing':miss[:50],'errors':errs[:50],'rc':p.returncode,'cmpExit':cmp.returncode,
               'tools':tool_shas([__file__,os.path.join(KIT,'t72','st74.py'),os.path.join(T5,'cmpk5.py')])},open(outf+'.run.json','w'),ensure_ascii=False,indent=1)
    print('STATUS',status,f'(строк {len(rows)}/{len(J)}, ошибок {len(errs)})');sys.exit(2 if not complete else (1 if cmp.returncode else 0))
def cmd_stands(a):
    build=absbuild(a[0]);out=os.path.abspath(a[1]);os.makedirs(out,exist_ok=True);precheck(out)
    ref=a[a.index('--ref')+1] if '--ref' in a else None;allow=a[a.index('--allow')+1] if '--allow' in a else ''
    env=dict(ENV);res={};bad=0
    for m in ['boot','trace','aimman','prio','probes']:
        f=os.path.join(out,m+'.json');p=subprocess.run([sys.executable,os.path.join(T5,'st5.py'),m,build,f],env=env,capture_output=True,text=True)
        ok=p.returncode==0 and os.path.exists(f)
        r={'rc':p.returncode,'ok':ok}
        if ok:
            d=json.load(open(f));r['pageFlags']=d.get('pageFlags');errs=d.get('errs') or [e for v in d.get('runs',{}).values() for e in v.get('errs',[])]
            if errs:r['pageErrors']=errs[:3]
            if ref:
                rf=os.path.join(ref,m+'.json')
                if not os.path.exists(rf):r['cmp']='нет эталона';bad+=1
                else:
                    c=subprocess.run([sys.executable,os.path.join(T5,'compare5.py'),rf,f]+(['--allow',allow] if m=='boot' and allow else []),capture_output=True,text=True)
                    r['cmp']=c.returncode;r['cmpOut']=c.stdout[-800:];bad+=c.returncode!=0
        else:r['err']=(p.stderr or p.stdout)[-600:]
        res[m]=r;print(m,'OK' if ok else 'СБОЙ',r.get('cmp',''),flush=True)
    complete=all(v['ok'] for v in res.values())
    status='COMPLETE' if complete else 'PARTIAL'
    json.dump({'status':status,'build':build,'buildSha':sha(build),'a24env':ENV.get('VOID_A24')=='1','pageFlags':next((v.get('pageFlags') for v in res.values() if v.get('pageFlags')),None),'stands':res,'tools':tool_shas([__file__,os.path.join(T5,'st5.py'),os.path.join(T5,'compare5.py')])},open(os.path.join(out,'run.json'),'w'),ensure_ascii=False,indent=1)
    print('STATUS',status);sys.exit(2 if not complete else (1 if bad else 0))
def cmd_investigate(a):
    A=absbuild(a[0]);B=absbuild(a[1]);out=os.path.abspath(a[2]);n=int(a[3]);items=[x.split(':') for x in a[4:]];os.makedirs(out,exist_ok=True);precheck(out)
    tally={}
    for i in range(n):
        for q,c in items:
            for tag,b in (('A',A),('B',B)):
                log=os.path.join(out,f'{q}_{c}_{tag}_{i}.log')
                with open(log,'w') as L:subprocess.run([sys.executable,os.path.join(KIT,q+'.py'),c],cwd=KIT,env=dict(ENV,GAME_URL='file://'+b),stdout=L,stderr=subprocess.STDOUT,timeout=3600)
                t=open(log,encoding='utf8',errors='replace').read();m=re.search(r'^\s*(OK|FAIL)\s+'+re.escape(c)+r'\b',t,re.M)
                k=f'{q}:{c}';tally.setdefault(k,{'A':{'OK':0,'FAIL':0,'NONE':0},'B':{'OK':0,'FAIL':0,'NONE':0}})[tag][m.group(1) if m else 'NONE']+=1
        print(i+1,json.dumps(tally,ensure_ascii=False),flush=True)
    verdict={k:('только кандидат' if v['B']['FAIL'] and not v['A']['FAIL'] else ('обе сборки' if v['B']['FAIL'] else 'не воспроизводится')) for k,v in tally.items()}
    json.dump({'A':A,'B':B,'shaA':sha(A),'shaB':sha(B),'reps':n,'tally':tally,'verdict':verdict},open(os.path.join(out,'run.json'),'w'),ensure_ascii=False,indent=1)
    print('ВЕРДИКТ',verdict);sys.exit(1 if any(v=='только кандидат' for v in verdict.values()) else 0)
if __name__=='__main__':
    if len(sys.argv)<2:print(open(__file__).read().split('import sys')[0]);sys.exit(3)
    {'reg':cmd_reg,'k':cmd_k,'stands':cmd_stands,'investigate':cmd_investigate}[sys.argv[1]](sys.argv[2:])
