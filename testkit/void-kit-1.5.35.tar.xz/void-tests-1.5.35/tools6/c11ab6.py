#!/usr/bin/env python3
# Корректирующее обновление · C11 (q340s, время слоёв режиссёра < 0,3 мс) — замер БЕЗ параллельной нагрузки, порядок A B A′ в каждом
# повторе (A′ — та же сборка A ещё раз: A/A при той же нагрузке).  python3 tools6/c11ab6.py A.html B.html out.json [--reps 8]
# Тест не меняется (исторический kit/q340s.py C11), запускается по одному; значения tick+lay берутся из его записи.
# Вердикт: «регрессия», только если медиана B/A выше 1.10 И выше наибольшего A′/A; иначе «нет регрессии»; FAIL самого теста
# считается отдельно (порог 0,3 мс — абсолютный, под нагрузкой машины он нарушается на обеих сборках).
import sys,os,subprocess,json,re,statistics as S
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));KIT=os.path.join(R,'kit')
a=sys.argv[1:];A,B,OUT=os.path.abspath(a[0]),os.path.abspath(a[1]),a[2];N=int(a[a.index('--reps')+1]) if '--reps' in a else 8
rows=[]
for i in range(N):
    for tag,b in(('A',A),('B',B),('A2',A)):
        p=subprocess.run([sys.executable,os.path.join(KIT,'q340s.py'),'C11'],cwd=KIT,env=dict(os.environ,GAME_URL='file://'+b,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True,timeout=900)
        m=re.search(r'^(OK|FAIL)\s+C11\b.*?·\s*(\{.*\})\s*$',p.stdout,re.M)
        if not m:print('нет записи C11',tag,i,p.stdout[-300:],p.stderr[-300:]);sys.exit(3)
        v=json.loads(m.group(2));rows.append(dict(tag=tag,rep=i,status=m.group(1),ms=round(v['tick']+v['lay'],4),**v));print(json.dumps(rows[-1]),flush=True)
g={t:[r['ms'] for r in rows if r['tag']==t] for t in('A','B','A2')}
ab=[b/a for a,b in zip(g['A'],g['B'])];aa=[b/a for a,b in zip(g['A'],g['A2'])]
summ={'медиана мс':{t:round(S.median(v),4) for t,v in g.items()},'B/A медиана':round(S.median(ab),3),'B/A пары':[round(min(ab),3),round(max(ab),3)],
      'A′/A медиана':round(S.median(aa),3),'A′/A пары':[round(min(aa),3),round(max(aa),3)],'FAIL':{t:sum(1 for r in rows if r['tag']==t and r['status']=='FAIL') for t in g}}
verdict='регрессия' if summ['B/A медиана']>1.10 and summ['B/A медиана']>summ['A′/A пары'][1] else 'нет регрессии'
json.dump({'A':A,'B':B,'reps':N,'rows':rows,'summary':summ,'verdict':verdict},open(OUT,'w'),ensure_ascii=False,indent=1)
print(json.dumps(summ,ensure_ascii=False));print('ВЕРДИКТ',verdict)
