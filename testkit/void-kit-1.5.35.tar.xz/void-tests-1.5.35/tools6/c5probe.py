#!/usr/bin/env python3
# Этап 7 · класс 5 (замещённые объявления): исполняется ли исходное тело функции до её замены при загрузке и после неё.
#   python3 tools6/c5probe.py <сборка.html> <out.json>
# Инструментированная копия (в /tmp): в начало исходного объявления вставляется счётчик, перед оператором замены — снимок счётчиков.
import sys,os,re,json,asyncio,tempfile
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','tools5'))
import st5
from playwright.async_api import async_playwright
NAMES=['togHTML','cloudWinner','tutTick','toggleDevPanel']
async def main(b_,out):
    h=open(b_,encoding='utf8').read()
    for n in NAMES:
        m=re.search(r'\nfunction '+n+r'\(([^)]*)\)\{',h);assert m,n
        h=h[:m.end()]+"(window.__c5o=window.__c5o||{})['%s']=(window.__c5o['%s']||0)+1;"%(n,n)+h[m.end():]
        m2=re.search(r'\n'+n+r'=function',h);assert m2,n
        h=h[:m2.start()+1]+"(window.__c5at=window.__c5at||{})['%s']=(window.__c5o||{})['%s']||0;"%(n,n)+h[m2.start()+1:]
    d=tempfile.mkdtemp();f=os.path.join(d,'probe.html');open(f,'w',encoding='utf8').write(h)
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path=st5.CHROME,args=['--no-sandbox'])
        res={}
        for w,hh,t in ((1280,760,False),(390,844,True)):
            ctx,pg,errs=await (st5.page(b,f,w,hh,t))
            await pg.wait_for_timeout(600)
            r=await pg.evaluate("()=>{const a=Object.assign({},window.__c5at||{}),o0=Object.assign({},window.__c5o||{});try{T.fresh();openSettings('menu');toggleDevPanel&&0;}catch(e){}return {beforeReplace:a,afterLoad:o0,afterUse:Object.assign({},window.__c5o||{})};}")
            res['ПК' if not t else 'тел']=dict(r,errs=errs[:2])
        await b.close()
    json.dump(res,open(out,'w'),ensure_ascii=False,indent=1);print(json.dumps(res,ensure_ascii=False))
asyncio.run(main(sys.argv[1],sys.argv[2]))
