# Этап 6, корректирующее обновление · исследование нестабильных проверок q130 Q06 и q220 U05/U07.
# Повторяет шаги исходных тестов на двух сборках поочерёдно (A B A B …) при одинаковых начальных условиях и замедлении процессора
# страницы (CDP Emulation.setCPUThrottlingRate), но вместо одного фиксированного ожидания измеряет момент наступления события:
#   Q06 — состояние облака (CLOUD.state) в момент нажатия «Новый полёт», когда в облаке появляется прогресс 0 (мс после нажатий),
#         и что видел исходный тест через 500 мс;
#   U05/U07 — через сколько мс после NEW() урок «calib» стал текущим и появился TUT.cal.pts (исходный тест ждёт 4000 мс).
#   python3 tools6/flaky6.py A.html B.html out.json --reps 5 --thr 1,4,8 [--only q06|cal]
import asyncio,json,os,sys,time
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));KIT=os.path.join(R,'kit');sys.path.insert(0,KIT)
a=sys.argv[1:];A,B,OUT=[os.path.abspath(x) for x in a[:3]]
REPS=int(a[a.index('--reps')+1]) if '--reps' in a else 5
THR=[float(x) for x in a[a.index('--thr')+1].split(',')] if '--thr' in a else [1.0]
ONLY=a[a.index('--only')+1] if '--only' in a else None
os.chdir(KIT)
import h,q130,q220
from playwright.async_api import async_playwright
async def page(b,url,thr,**kw):
    P=await h.newpage(b,url=url,**kw)
    if thr!=1:
        s=await P.pg.context.new_cdp_session(P.pg);await s.send('Emulation.setCPUThrottlingRate',{'rate':thr})
    return P
async def q06(b,url,thr):
    store={}
    P=await page(b,url,thr,init=q130.FAKE(store),alpha=False);await P.js(q130.QA_JS);await P.wait(400);await P.js(q130.LOADUI,q130.C49);await P.wait(500)
    st=await P.js("()=>window.__fake");await P.pg.context.close()
    P2=await page(b,url,thr,init=q130.FAKE(st),alpha=False);await P2.js(q130.QA_JS);await P2.wait(700)
    pre=await P2.js("()=>({done:doneCount(),cloud:CLOUD.state,waiters:CLOUD.waiters.length})")
    t0=time.time()
    await P2.js("()=>{toMenu();$('#bWorldNew').click();$('#bWorldNew').click();return G.state;}")
    seen=None;at500=None;gate=await P2.js("()=>({cloud:CLOUD.state,waiters:CLOUD.waiters.length})")
    for i in range(160):
        await P2.wait(50);ms=round((time.time()-t0)*1000)
        d=await P2.js("()=>{const b=(window.__fake||{})['data/users/u_test/save'];return {done:b?b.done:null,cloud:CLOUD.state};}")
        if at500 is None and ms>=500:at500=d
        if d['done']==0 and seen is None:seen=ms
        if seen is not None and at500 is not None:break
    await P2.pg.context.close()
    return {'pre':pre,'afterClick':gate,'cloudDoneAt500ms':at500,'done0AfterMs':seen,'origOk':bool(pre['done']==49 and at500 and at500['done']==0)}
async def cal(b,url,thr):
    P=await page(b,url,thr,vw=1600,vh=900,alpha=False)
    ok0=await P.js(q220.NEW,{});t0=time.time();ready=None
    for i in range(400):
        r=await P.js("()=>!!(TUT.cur&&TUT.cur.k==='calib'&&TUT.cal&&TUT.cal.pts&&TUT.cal.pts.length)")
        if r:ready=round((time.time()-t0)*1000);break
        await P.wait(50)
    st=await P.js("()=>({cur:TUT.cur&&TUT.cur.k,prologue:!!G.prologue,state:G.state})")
    await P.pg.context.close()
    return {'new':ok0,'calReadyMs':ready,'state':st,'origOk':bool(ok0 and ready is not None and ready<=4000)}
async def main():
    res=[]
    async with async_playwright() as pw:
        br=await pw.chromium.launch(args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
        for thr in THR:
            for i in range(REPS):
                for tag,bld in (('A',A),('B',B)):
                    url='file://'+bld
                    for name,fn in (('Q06',q06),('CAL',cal)):
                        if ONLY=='q06' and name!='Q06':continue
                        if ONLY=='cal' and name!='CAL':continue
                        try:r=await fn(br,url,thr)
                        except Exception as e:r={'exc':str(e)[:300],'origOk':False}
                        r.update(test=name,build=tag,thr=thr,rep=i);res.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
                        json.dump(res,open(OUT,'w'),ensure_ascii=False,indent=1)
        await br.close()
asyncio.run(main())
