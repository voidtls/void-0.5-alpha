#!/usr/bin/env python3
# Корректирующее обновление · perf6 — стоимость кадра frame() (как perf5) с p95/p99/максимумом и оценкой выделений памяти.
#   python3 tools6/perf6.py <A.html> <B.html> <out.json> [--reps 6] [--sec 8]
# Порядок в каждом повторе: A, B, A′ (A′ — та же сборка A ещё раз) → в одном прогоне и A/B, и A/A при одинаковой нагрузке машины.
# Ячейки: 60 и 144 Гц × миссии 10 и 46 (как perf5). Время игры виртуальное, время ЦП — настоящее (performance.now до подмены).
# Первая секунда кадров — разгон (генерация, JIT), не измеряется. Время — только окно измерения (SEC секунд).
# Память: выделения за окно — выборочный профилировщик кучи V8 (CDP HeapProfiler.startSampling, шаг 4 КБ): число выборок × 4 КБ /
# число кадров ≈ КБ на кадр (статистическая оценка, включает объекты, уже собранные сборщиком мусора);
# удержание — разница занятой кучи после принудительной сборки мусора до и после окна (CDP HeapProfiler.collectGarbage).
# Итог — out.json (все прогоны) и сводка: медианы A, B, A′ и отношения B/A и A′/A по повторам (медиана и разброс пар).
import asyncio,json,sys,os,statistics as S
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));sys.path.insert(0,os.path.join(R,'kit'))
from h import *
a=sys.argv[1:]
try:UA,UB,OUT=['file://'+os.path.abspath(x) for x in a[:2]]+[a[2]]
except ValueError:print(open(__file__,encoding='utf8').read().split('import asyncio')[0]);sys.exit(3)
REPS=int(a[a.index('--reps')+1]) if '--reps' in a else 6;SEC=float(a[a.index('--sec')+1]) if '--sec' in a else 8;SI=4096
INIT="""(()=>{let a=5;Math.random=function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
window.requestAnimationFrame=()=>0;window.__RN=performance.now.bind(performance);})();"""
RUN=r"""(J)=>{T.fresh();G.save.tut.off=1;const G0=G.save;G0.cleared=Math.max(G0.cleared,J.m-1);for(let k=1;k<J.m;k++)G0.medals[k]={clear:1};
 enterNode(J.m);if(G.state==='intro')startMission();
 let now=50000;performance.now=()=>now;last=now;const dt=1000/J.hz;let i=0;
 window.__run=(N,meas)=>{let cpu=0;const fr=[];
  for(let k2=0;k2<N;k2++,i++){let k=0;while(G.state==='levelup'&&k++<20)choose(0);const p=G.player;if(p&&p.hp<G.st.maxHp*.4)p.hp=G.st.maxHp*.4;
   if(p)steer2(W/2+Math.cos(i*dt/1500)*Math.min(W,H)*.3,H/2+Math.sin(i*dt/1500)*Math.min(W,H)*.3);
   now+=dt;const t0=window.__RN();frame(now);const c=window.__RN()-t0;cpu+=c;fr.push(c);}
  if(!meas)return {N};fr.sort((x,y)=>x-y);const q=f=>+fr[Math.min(N-1,Math.floor(N*f))].toFixed(3);
  return {N,msFrame:+(cpu/N).toFixed(3),p50:q(.5),p95:q(.95),p99:q(.99),max:+fr[N-1].toFixed(3),simT:+G.t.toFixed(2),st:G.state,ver:VER_TAG};};
 return true;}"""
async def one(b,u,hz,m):
    P=await newpage(b,1280,760,url=u,init=INIT,clear=False);cdp=await P.pg.context.new_cdp_session(P.pg)
    await cdp.send('HeapProfiler.enable')
    try:
        await P.js(RUN,dict(hz=hz,m=m));await P.js("(n)=>__run(n,false)",hz)        # 1 с разгона (генерация, JIT) — не измеряется
        await cdp.send('HeapProfiler.collectGarbage');h0=(await cdp.send('Runtime.getHeapUsage'))['usedSize']
        await cdp.send('HeapProfiler.startSampling',{'samplingInterval':SI})
        r=await P.js("(n)=>__run(n,true)",int(SEC*hz))
        prof=await cdp.send('HeapProfiler.stopSampling')
        await cdp.send('HeapProfiler.collectGarbage');h1=(await cdp.send('Runtime.getHeapUsage'))['usedSize']
        ns=len(prof['profile'].get('samples',[]));r['allocKB']=round(ns*SI/1024/r['N'],2);r['retainKB']=round((h1-h0)/1024,1)
    except Exception as e:r={'err':str(e)[:300]}
    r['nerr']=len(P.errs);await P.pg.context.close();return r
async def main():
    res=[]
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path=json.load(open(os.path.join(R,'.kitpaths.json')))['chrome'],args=['--no-sandbox'])
        for hz in (60,144):
            for m in (10,46):
                for rep in range(REPS):
                    for tag,u in (('A',UA),('B',UB),('A2',UA)):
                        x=await one(b,u,hz,m);x.update(tag=tag,hz=hz,m=m,rep=rep);res.append(x);print(json.dumps(x,ensure_ascii=False),flush=True)
        await b.close()
    return res
res=asyncio.run(main())
summ={};bad=[]
for hz in (60,144):
    for m in (10,46):
        C=[r for r in res if r['hz']==hz and r['m']==m and 'err' not in r];bad+=[r for r in res if r['hz']==hz and r['m']==m and ('err' in r or r.get('nerr'))]
        row={}
        for k in ('msFrame','p95','p99','max','allocKB','retainKB'):
            g={t:[r[k] for r in sorted(C,key=lambda r:r['rep']) if r['tag']==t and r.get(k) is not None] for t in ('A','B','A2')}
            if not all(g.values()):continue
            pr=lambda x,y:[round(b_/a_,3) for a_,b_ in zip(x,y) if a_]
            ab,aa=pr(g['A'],g['B']),pr(g['A'],g['A2'])
            row[k]={'A':round(S.median(g['A']),3),'B':round(S.median(g['B']),3),'A2':round(S.median(g['A2']),3),
                    'B/A':round(S.median(ab),3) if ab else None,'B/A пары':[min(ab),max(ab)] if ab else None,'A2/A':round(S.median(aa),3) if aa else None,'A2/A пары':[min(aa),max(aa)] if aa else None}
        summ[f'{hz}Гц м{m}']=row
json.dump({'A':UA,'B':UB,'reps':REPS,'sec':SEC,'runs':res,'summary':summ,'errors':len(bad)},open(OUT,'w'),ensure_ascii=False,indent=1)
for c,row in summ.items():
    for k,v in row.items():print(c.ljust(10),k.ljust(8),'A',v['A'],'B',v['B'],'A′',v['A2'],'· B/A',v['B/A'],v['B/A пары'],'· A′/A',v['A2/A'],v['A2/A пары'])
print('ошибок',len(bad))
