#!/usr/bin/env python3
# Корректирующее обновление · fpsx6 — дополнительные сценарии FPS (стенд; НЕ реальные устройства и НЕ реальные мониторы).
#   python3 tools6/fpsx6.py run <сборка.html> <out.json> [--only switch,long,bg,cap30,loops] [--a23v]
#   python3 tools6/fpsx6.py sum <out.json> [<ещё.json> …]
# Виртуальный экран как в fps6 (rAF отключён, время — подменённое performance.now, отрисовка — заглушка, RNG засеян init st5):
#   switch — смена предела во время боя: 60 → 30 → без ограничения → 60 (по 4 с), 60 и 144 Гц, телефон и ПК; по отрезкам —
#            кадров/с, шагов/с, наибольшее число шагов в одном кадре и наибольший интервал между обработанными кадрами сразу после смены;
#   long   — 120 с подряд на 59.94 / 60 / 75 / 144 Гц при пределах 30 и 60 (телефон): уход частоты кадров (первые 10 с против последних 10 с),
#            шагов за 120 с (ожидается 7200 ± 2), хэш состояния на одинаковом шаге при разных пределах и частотах (события от частоты не зависят);
#   bg     — уход в фон на 3 с и 30 с при пределах 30 / 60 / 0: шагов в первом кадре после возврата, кадров/с в первую секунду, шагов за 2 с;
#   cap30  — экран сам отдаёт 30 Гц (энергосбережение, самоограничение браузера) при пределах 60 и 0 на телефоне: смена качества, lowFx;
#   loops  — НАСТОЯЩИЙ rAF безголового Chromium (≈60 Гц): сколько раз в секунду обрабатываются frame (игра) и mapLoop (карта) в меню
#            и на карте при пределе 30 — у карты собственный цикл rAF.
# --a23v: сборка — вариант с порогом A-23 0.84 шага (предложение для 75 Гц, tools6/a23v6.py); меряется отдельно, в игру не вносится.
import asyncio,json,sys,os,math
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','tools5'));sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import st5,fps6
from playwright.async_api import async_playwright
DRIVE=r"""(J)=>{const P=1000/J.hz;let t=50000+P;const T0=50000;let lastP=last;const out={fr:[],ev:[],steps0:__N,q0:null};/* качество в начале — после 1 с: первый qTick ставит стартовое qStart() (не снижение) */
 const ev=(J.ev||[]).slice().sort((a,b)=>a.at-b.at);let gapAt=J.gapAt?T0+J.gapAt:-1;
 while(t<T0+J.dur*1000){if(G.state==='levelup'){let n=0;while(G.state==='levelup'&&n++<20)choose(0);}
   while(ev.length&&t>=T0+ev[0].at){const e=ev.shift();if(typeof fpsPick27==='function')fpsPick27(String(e.cap));else{SET.fps=e.cap===30?30:60;}out.ev.push([Math.round(t-T0),e.cap]);}
   if(out.q0===null&&t>=T0+1000)out.q0=G.q;__setNow(t);const n0=__N;frame(t);if(last!==lastP){out.fr.push([+(t-T0).toFixed(3),__N-n0]);lastP=last;}
   let d=P;if(gapAt>0&&t>=gapAt){d+=J.gap;gapAt=-1;out.ret=+(t+d-T0).toFixed(3);}t+=d;if(G.state!=='play'&&G.state!=='levelup')break;}
 out.steps=__N;out.h7000=__H.length>=7000?__H[6999]:null;out.qEnd=G.q;out.low=!!G.lowFx;out.h=__H.length?__H[__H.length-1]:null;out.hN=__H.length;out.state=G.state;return out;}"""
LOOPS=r"""async(J)=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));audioWake();localStorage.removeItem('void_world');startWorld(true);if(G.prologue)prologueEnd();G.save.tut.off=1;
 if(typeof fpsPick27==='function')fpsPick27('30');else SET.fps=30;
 let nf=0,np=0,nm=0;const f0=frame;frame=function(){nf++;const l0=last;const r=f0.apply(this,arguments);if(last!==l0)np++;return r;};const m0=mapLoop;mapLoop=function(){nm++;return m0.apply(this,arguments);};
 const res={};toMenu();await w8(500);nf=0;np=0;nm=0;const t0=performance.now();await w8(3000);const d0=(performance.now()-t0)/1000;res.menu={raf:+(nf/d0).toFixed(1),processed:+(np/d0).toFixed(1),map:+(nm/d0).toFixed(1)};
 startWorld(false);if(G.prologue)prologueEnd();await w8(500);openMap();await w8(500);nf=0;np=0;nm=0;const t1=performance.now();await w8(3000);const d1=(performance.now()-t1)/1000;
 res.map={raf:+(nf/d1).toFixed(1),processed:+(np/d1).toFixed(1),map:+(nm/d1).toFixed(1),state:G.state,tab:G.mapTab};
 closeMap();await w8(300);nf=0;np=0;const t2=performance.now();await w8(3000);const d2=(performance.now()-t2)/1000;res.world={raf:+(nf/d2).toFixed(1),processed:+(np/d2).toFixed(1),state:G.state};
 return res;}"""
def jobs(only):
    J=[]
    if 'switch' in only:
        for mob in (True,False):
            for hz in (60,144):J.append(dict(kind='switch',mob=mob,hz=hz,cap=60,dur=16,ev=[dict(at=4000,cap=30),dict(at=8000,cap=0),dict(at=12000,cap=60)]))
    if 'long' in only:
        for hz in (59.94,60,75,144):
            for cap in (30,60):J.append(dict(kind='long',mob=True,hz=hz,cap=cap,dur=120))
    if 'bg' in only:
        for cap in (30,60,0):
            for gap in (3000,30000):J.append(dict(kind='bg',mob=True,hz=60,cap=cap,dur=4+gap//1000+5,gapAt=4000,gap=gap))
    if 'cap30' in only:
        for cap in (60,0,30):J.append(dict(kind='cap30',mob=True,hz=30,cap=cap,dur=20))
    return J
def seg(fr,a,b):
    F=[x for x in fr if a<=x[0]<b];n=sum(x[1] for x in F);iv=[q[0]-p[0] for p,q in zip(F,F[1:])]
    return dict(fps=round(len(F)/((b-a)/1000),2),steps=round(n/((b-a)/1000),2),maxSteps=max([x[1] for x in F] or [0]),maxIv=round(max(iv or [0]),2))
async def run(build,out,only):
    build=os.path.abspath(build);res={'build':os.path.basename(build),'runs':[]}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path=st5.CHROME,args=['--no-sandbox']) if st5.CHROME else await pw.chromium.launch(args=['--no-sandbox'])
        for j in jobs(only):
            ctx,pg,errs=await (st5.page(b,build,390,844,True) if j['mob'] else st5.page(b,build))
            await pg.evaluate(st5.COMMON);info=await pg.evaluate(fps6.INIT,{'cap':j['cap'],'mob':j['mob'],'steps':7300,'endless':False})
            r=await pg.evaluate(DRIVE,j);fr=r.pop('fr');row=dict(j,has=info['has'],steps0=r['steps0'],stepsTotal=r['steps']-r['steps0'],q0=r['q0'],qEnd=r['qEnd'],qDrop=r['qEnd']!=r['q0'],low=r['low'],h=r['h'],hN=r['hN'],h7000=r['h7000'],state=r['state'],errs=errs[:2])
            if j['kind']=='switch':
                cuts=[0]+[e['at'] for e in j['ev']]+[j['dur']*1000]
                row['segs']=[dict(cap=c,**seg(fr,a+1000 if i else 1000,bnd)) for i,(c,a,bnd) in enumerate(zip([j['cap']]+[e['cap'] for e in j['ev']],cuts,cuts[1:]))]
                row['afterSwitch']=[dict(at=e['at'],first=[[round(x[0]-e['at'],2),x[1]] for x in fr if x[0]>=e['at']][:4]) for e in j['ev']]
            elif j['kind']=='long':
                row['first10']=seg(fr,1000,11000);row['last10']=seg(fr,j['dur']*1000-10000,j['dur']*1000);row['all']=seg(fr,0,j['dur']*1000)
                row['frames']=len(fr)
            elif j['kind']=='bg':
                rt=r.get('ret');A=[x for x in fr if x[0]>=rt] if rt else []
                row['ret']=rt;row['firstAfter']=A[:3];row['sec1']=seg(fr,rt,rt+1000) if rt else None;row['stepsAfter2s']=sum(x[1] for x in A if x[0]<rt+2000) if rt else None
                row['before']=seg(fr,1000,4000)
            else:
                row['all']=seg(fr,1000,j['dur']*1000)
            res['runs'].append(row);await ctx.close();print(json.dumps({k:v for k,v in row.items() if k not in('ev',)},ensure_ascii=False)[:600],flush=True)
        if 'loops' in only:
            ctx=await b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:200]))
            await pg.goto('file://'+build);await pg.wait_for_timeout(800)
            try:r=await pg.evaluate(LOOPS,{})
            except Exception as e:r={'exc':str(e)[:300]}
            res['loops']=dict(r,errs=errs[:2],note='настоящий rAF безголового Chromium; предел 30; телефон (эмуляция)');print('loops',json.dumps(res['loops'],ensure_ascii=False),flush=True);await ctx.close()
        await b.close()
    json.dump(res,open(out,'w'),ensure_ascii=False,indent=1)
def summ(files):
    for f in files:
        d=json.load(open(f));print('##',d['build'])
        for r in d['runs']:
            k=r['kind'];dev='ТЕЛ' if r['mob'] else 'ПК '
            if k=='switch':print(' смена',dev,r['hz'],'Гц:',' | '.join(f"{s['cap']}: {s['fps']} к/с {s['steps']} ш/с макс.шагов {s['maxSteps']} макс.инт {s['maxIv']}" for s in r['segs']))
            elif k=='long':print(' 120 с',dev,str(r['hz']).rjust(6),'Гц предел',str(r['cap']).rjust(2),'шагов',r['stepsTotal'],'к/с первые 10 с',r['first10']['fps'],'последние 10 с',r['last10']['fps'],'весь',r['all']['fps'],'шаг/кадр макс',r['all']['maxSteps'],'h',r['h'],r['hN'])
            elif k=='bg':print(' фон',r['gap']//1000,'с предел',str(r['cap']).rjust(2),'до',r['before']['fps'],'к/с; первые кадры после [мс от возврата, шагов]',r['firstAfter'],'1-я с',r['sec1'],'шагов за 2 с',r['stepsAfter2s'])
            else:print(' экран 30 Гц предел',str(r['cap']).rjust(2),'к/с',r['all']['fps'],'шагов/с',r['all']['steps'],'качество',r['q0'],'→',r['qEnd'],'lowFx',r['low'])
        if d.get('loops'):print(' циклы (настоящий rAF):',json.dumps(d['loops'],ensure_ascii=False))
if __name__=='__main__':
    a=sys.argv[1:]
    if a and a[0]=='run':asyncio.run(run(a[1],a[2],(a[a.index('--only')+1] if '--only' in a else 'switch,long,bg,cap30,loops').split(',')))
    elif a and a[0]=='sum':summ(a[1:])
    else:print(open(__file__,encoding='utf8').read().split('import asyncio')[0]);sys.exit(3)
