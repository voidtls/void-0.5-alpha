#!/usr/bin/env python3
# Этап 6 · динамические стенды состояния (Playwright; сборка не меняется, всё — в копии страницы).
#   python3 tools6/st6.py trans  <сборка.html> <out.json>  — журнал переходов G.state (из → в, кто), сценарии миссии/мира/потоков экранов
#   python3 tools6/st6.py saveid <сборка.html> <out.json>  — смены объекта G.save: кто и какой класс; после смены прежний объект не должен
#                                                           меняться (иначе — запись через устаревшую ссылку); временные подмены восстановлены
#   python3 tools6/st6.py cmp <a.json> <b.json>             — сравнение журналов двух сборок (выход 1 при расхождении)
# Ловушки — Object.defineProperty на G.state / G.save (работают на любой сборке, с scr6/saveSet6 и без).
import asyncio,json,sys,os
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','tools5'))
import st5
from playwright.async_api import async_playwright
TRAP=r"""(J)=>{const skip=new Set(['scr6','saveSet6','saveWith6','set','who']);const names=new Set(J.names);
 const who=()=>{const st=(new Error().stack||'').split('\n').slice(2);for(const l of st){const m=l.match(/at (?:Object\.|Function\.|HTMLButtonElement\.|HTMLElement\.)?([\w$]+) \(/);if(m&&names.has(m[1])&&!skip.has(m[1]))return m[1];}return '(?)';};
 window.__TR=[];window.__SV=[];window.__OLD=[];
 let s=G.state;Object.defineProperty(G,'state',{configurable:true,enumerable:true,get(){return s;},set(x){if(x!==s||J.all)__TR.push([s,x,who()]);s=x;}});
 const snap=o=>{try{return fnv(JSON.stringify(o));}catch(e){return 'x';}};
 let v=G.save;Object.defineProperty(G,'save',{configurable:true,enumerable:true,get(){return v;},set(x){if(x!==v){const w=who();__SV.push([w,x===null?'null':typeof x,v===null?'null':typeof v]);
   if(v&&typeof v==='object'){const i=__OLD.findIndex(o=>o.o===x);if(i>=0)__OLD.splice(i,1);__OLD.push({o:v,h:snap(v),by:w,n:__SV.length});}}v=x;}});
 window.__SVCHK=()=>__OLD.filter(o=>o.o!==v).map(o=>[o.by,o.n,snap(o.o)===o.h?'цел':'ИЗМЕНЁН ПОСЛЕ СМЕНЫ']);
 return 1;}"""
FLOWS=r"""()=>{const out=[];const t=(k,f)=>{try{f();out.push([k,G.state]);}catch(e){out.push([k,'ERR '+String(e.message).slice(0,60)]);}};
 t('settings',()=>openSettings('pause'));t('closeSettings',()=>closeSettings());t('codex',()=>openCodex());t('closeCodex',()=>closeCodex());
 t('resume',()=>resume());t('pause',()=>pause());t('resume2',()=>resume());t('toMenu',()=>toMenu());
 t('world',()=>T.fresh());t('map',()=>openMap());t('closeMap',()=>closeMap());t('hangar',()=>openHangar());t('closeHangar',()=>closeHangar());
 t('arsenal',()=>{openHangar();openArsenal();});t('closeArsenal',()=>closeArsenal());t('shop',()=>openShop());t('cycle',()=>openCycle());t('closeCycle',()=>closeCycle());t('closeShop',()=>closeShop());
 t('pauseW',()=>pause());t('resumeW',()=>resume());t('saveScreen',()=>{toMenu();openSaveScreen();});t('menu2',()=>toMenu());
 t('endless',()=>{startEndless();if(G.state==='intro')startMission();});t('pauseE',()=>pause());t('resumeE',()=>resume());t('over',()=>{G.player.hp=0;for(let i=0;i<400&&G.state==='play';i++)__tick();});
 t('menu3',()=>toMenu());t('report',()=>{if(typeof openReport==='function')openReport();});t('menu4',()=>toMenu());
 return out;}"""
SAVEFLOWS=r"""()=>{const out=[];const t=(k,f)=>{try{f();out.push([k,G.state,!!G.save]);}catch(e){out.push([k,'ERR '+String(e.message).slice(0,60)]);}};
 t('fresh',()=>T.fresh());t('steps',()=>{for(let i=0;i<120;i++)__tick();});t('menu',()=>toMenu());t('renderMenu',()=>renderMenu());
 t('cloudReload',()=>{saveWorld&&saveWorld();cloudReloadState();});t('continue',()=>startWorld(false));t('steps2',()=>{for(let i=0;i<60;i++)__tick();});
 t('menu2',()=>toMenu());t('renderMenu2',()=>renderMenu());t('dbgLoad',()=>{if(window.DBG&&DBG.load)DBG.load(DBG.save());});
 t('newWorld',()=>startWorld(true));t('menu3',()=>toMenu());t('reset',()=>{if(typeof fullReset==='function')fullReset();});t('after',()=>T.fresh());
 return out;}"""
async def run(mode,build,out):
    names=st5.gnames(build);res={'mode':mode,'build':os.path.basename(build),'runs':{}}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path=st5.CHROME,args=['--no-sandbox']) if st5.CHROME else await pw.chromium.launch(args=['--no-sandbox'])
        jobs=[('m10',900,'trace',False),('world',900,'trace',False),('post',600,'trace',False),('m10',0,'flows',False),('m10',0,'flows',True)] if mode=='trans' else [('world',0,'save',False),('m10',600,'trace',False)]
        for enc,n,kind,touch in jobs:
            ctx,pg,errs=await (st5.page(b,build,390,844,True) if touch else st5.page(b,build))
            await pg.evaluate(st5.COMMON);await pg.evaluate(TRAP,{'names':names,'all':False});st=await pg.evaluate(st5.SCEN,{'enc':enc})
            r={}
            if kind=='trace':r=await pg.evaluate(st5.TRACE_RUN,dict(n=n,names=[]));r.pop('log',None)
            elif kind=='flows':r['flows']=await pg.evaluate(FLOWS)
            else:r['flows']=await pg.evaluate(SAVEFLOWS)
            r['tr']=await pg.evaluate("()=>__TR");r['sv']=await pg.evaluate("()=>__SV");r['old']=await pg.evaluate("()=>__SVCHK()");r['errs']=errs[:3];r['start']=st
            key=enc+'-'+kind+('-touch' if touch else '');res['runs'][key]=r;await ctx.close()
            print(mode,key,'переходов',len(r['tr']),'смен save',len(r['sv']),'изменённых прежних',sum(1 for o in r['old'] if o[2]!='цел'),errs[:1],flush=True)
        await b.close()
    pairs={};[pairs.__setitem__(f'{a}→{c}',pairs.get(f'{a}→{c}',0)+1) for v in res['runs'].values() for a,c,w in v['tr']]
    res['pairs']=dict(sorted(pairs.items()));json.dump(res,open(out,'w'),ensure_ascii=False)
def cmp(a,b):
    A=json.load(open(a));B=json.load(open(b));bad=0
    for k in A['runs']:
        x=A['runs'][k];y=B['runs'].get(k)
        if not y:print('нет прогона',k);bad+=1;continue
        for f in ('tr','sv','old','flows','st','steps'):
            if x.get(f)!=y.get(f):bad+=1;print('РАСХОЖДЕНИЕ',k,f);print('   A',json.dumps(x.get(f),ensure_ascii=False)[:600]);print('   B',json.dumps(y.get(f),ensure_ascii=False)[:600])
    print(f"st6: прогонов {len(A['runs'])}; пар переходов A {len(A.get('pairs',{}))}, B {len(B.get('pairs',{}))}; расхождений {bad}");sys.exit(1 if bad else 0)
if __name__=='__main__':
    if sys.argv[1]=='cmp':cmp(sys.argv[2],sys.argv[3])
    else:asyncio.run(run(sys.argv[1],sys.argv[2],sys.argv[3]))
