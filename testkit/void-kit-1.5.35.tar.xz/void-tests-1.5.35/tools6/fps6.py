#!/usr/bin/env python3
# FPS · fps6 — виртуальный экран: в страницу (rAF отключён, RNG засеян — init st5) подаются отметки времени vsync с заданной
# частотой, дрожанием, единичными задержками и уходом в фон; каждая отметка — вызов frame(t) (как из rAF). Сборка не меняется.
#   python3 tools6/fps6.py run <сборка.html> <out.json> [--quick]   — матрица: частоты × пределы × телефон/ПК × помехи
#   python3 tools6/fps6.py sum <out.json> [<ещё.json> …]           — сводная таблица
# Для каждого прогона (10 с виртуального времени после 1 с разгона): частота обработанных кадров (средняя, p95 интервала),
# шагов симуляции: ОТДЕЛЬНО разгон (до начала окна), окно измерения (шагов, длительность окна по меткам кадров, шагов/с) и всего
# (корректирующее обновление: прежняя сводка печатала «шагов» вместе с разгоном — 658–660 за 11 с, а не за 10), хэш состояния на шаге 600 (st5 stH) и хэш всей последовательности, смены качества qTick (G.q),
# включение облегчённых эффектов (G.lowFx), доля кадров с интерполяцией A-23 и «дрожание» отображаемого времени:
# RMS изменения (t_кадра − время показанного состояния) от кадра к кадру, где показанное время = шаги·STEP, а при A-23 — (шаги − 1 + α)·STEP.
# Отрисовка заменена заглушкой (как noRender K-стенда); A-23 при этом работает (ip78Apply/Restore вызываются frame74).
# Старые сборки (без fpsCap) получают SET.fps=30/60 — их прежнее правило; «без ограничения» у них не существует.
import asyncio,json,sys,os,math,statistics as stt
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','tools5'))
import st5
from playwright.async_api import async_playwright
INIT=r"""(J)=>{audioWake();T.fresh();G.save.tut.off=1;SET.fx=true;const S=G.save;S.cleared=Math.max(S.cleared,9);for(let k=1;k<10;k++)S.medals[k]={clear:1};
 if(J.endless){startEndless();if(G.state==='intro')startMission();}else{enterNode(10);if(G.state==='intro')startMission();}
 let now=50000;performance.now=()=>now;Date.now=()=>1.7e12+now;window.__setNow=t=>{now=t;};last=now;
 render=function(){};renderWorld=function(){};secVignette=function(){};mobOverlay=function(){};drawDevOverlay=function(){};
 const has=typeof fpsCap27==='function';if(has){SET.fpsCap=J.cap;SET.fpsCapD=J.cap;}SET.fps=J.cap===30?30:60;if(J.mob){SET.quality='auto';}
 window.__H=[];window.__N=0;const s=step74;step74=function(){const p=G.player;if(p){p.hp=Math.max(p.hp,G.st.maxHp*.5);const A=__N/90;steer2(p.x+Math.cos(A)*300,p.y+Math.sin(A)*300);}/* ввод — по номеру шага, не по кадру: иначе симуляция зависела бы от группировки шагов */
   const r=s.apply(this,arguments);__N++;if(__N<=J.steps)__H.push(stH());return r;};
 window.__IPA=null;if(typeof ip78Apply==='function'){const a=ip78Apply;ip78Apply=function(){const r=a.apply(this,arguments);window.__IPA=r?IP76.al:null;return r;};}
 return {has,state:G.state,mob:isMob(),q:G.q};}"""
DRIVE=r"""(J)=>{const P=1000/J.hz;let t=50000+P,k=0;let rng=J.seed|0;const rnd=()=>{rng=(rng*1103515245+12345)%2147483648;return rng/2147483648;};
 const out={fr:[],q:[],low:0,ipa:0,lat:[],n0:null,t0w:null,init:null};let q0=G.q,qc=0,lastP=last;const T0=50000,warm=1000,end=warm+J.dur*1000;
 let hitchAt=J.hitch?T0+warm+3000:-1,bgAt=J.bg?T0+warm+4000:-1;
 while(t<T0+end){if(G.state==='levelup'){let n=0;while(G.state==='levelup'&&n++<20)choose(0);}const p=G.player;
   if(out.n0===null&&t>T0+warm){out.n0=__N;out.t0w=t;out.init={q:G.q,lowFx:!!G.lowFx,state:G.state};}/* начало окна: шагов до него — разгон */
   __setNow(t);window.__IPA=null;const st0=__N;frame(t);out.tEnd=t;
   if(last!==lastP){if(t>T0+warm){out.fr.push(t);if(window.__IPA!==null)out.ipa++;const sim=window.__IPA!==null?(__N-1+window.__IPA)*STEP74*1000:__N*STEP74*1000;out.lat.push(t-sim);}lastP=last;}
   if(t<=T0+warm)q0=G.q;else if(G.q!==q0){qc++;out.q.push([Math.round(t-T0),q0,G.q]);q0=G.q;}if(G.lowFx)out.low=1;
   let d=P;if(J.jit)d+=(rnd()-.5)*2*J.jit;
   if(hitchAt>0&&t>=hitchAt){d+=J.hitch;hitchAt=-1;}
   if(bgAt>0&&t>=bgAt){d+=3000;bgAt=-1;out.bgT=t+d;}
   t+=d;k++;if(G.state!=='play'&&G.state!=='levelup')break;}
 out.state=G.state;out.steps=__N;out.h600=__H.length>=600?__H[599]:null;out.hseq=fnv(__H.join(','));out.H=__H.slice();out.qc=qc;out.qEnd=G.q;
 return out;}"""
HZ=[30,48,59.94,60,75,90,120,144,165,240];CAPS=[30,60,0]
def jobs(quick=False):
    J=[]
    if '--hz' in sys.argv:  # корректирующее обновление: выборочная матрица (только «ровно») — для отдельного замера варианта A-23
        hz=[float(x) if '.' in x else int(x) for x in sys.argv[sys.argv.index('--hz')+1].split(',')];caps=[int(x) for x in sys.argv[sys.argv.index('--caps')+1].split(',')] if '--caps' in sys.argv else CAPS
        return [dict(mob=m,hz=h,cap=c,noise='ровно') for m in (True,False) for h in hz for c in caps]
    for mob in (True,False):
        for hz in ([60,90,144] if quick else HZ):
            for cap in CAPS:J.append(dict(mob=mob,hz=hz,cap=cap,noise='ровно'))
        for hz in ([60,144] if quick else [60,120,144]):
            for cap in CAPS:
                J.append(dict(mob=mob,hz=hz,cap=cap,noise='дрожание ±0.5 мс',jit=.5,seed=7))
                J.append(dict(mob=mob,hz=hz,cap=cap,noise='задержка 250 мс',hitch=250))
                J.append(dict(mob=mob,hz=hz,cap=cap,noise='фон 3 с',bg=1))
    # облегчённые эффекты бесконечного режима (fpsLow) и автокачество в бою
    for cap in CAPS:J.append(dict(mob=True,hz=60,cap=cap,noise='бесконечный',endless=True,dur=12))
    for cap in CAPS:J.append(dict(mob=True,hz=144,cap=cap,noise='бесконечный',endless=True,dur=12))
    # настоящая нехватка производительности: экран (или устройство) успевает только 20 / 25 кадров в секунду
    for cap in (30,0):
        for hz in (20,25):
            J.append(dict(mob=True,hz=hz,cap=cap,noise='перегрузка (%d к/с)'%hz,dur=20))
            J.append(dict(mob=True,hz=hz,cap=cap,noise='перегрузка, бесконечный',endless=True,dur=12))
    return J
async def run(build,out,quick):
    res={'build':os.path.basename(build),'runs':[]}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path=st5.CHROME,args=['--no-sandbox']) if st5.CHROME else await pw.chromium.launch(args=['--no-sandbox'])
        for j in jobs(quick):
            ctx,pg,errs=await (st5.page(b,build,390,844,True) if j['mob'] else st5.page(b,build))
            await pg.evaluate(st5.COMMON);info=await pg.evaluate(INIT,{'cap':j['cap'],'mob':j['mob'],'steps':600,'endless':j.get('endless',False)})
            r=await pg.evaluate(DRIVE,dict(hz=j['hz'],dur=j.get('dur',10),jit=j.get('jit',0),seed=j.get('seed',1),hitch=j.get('hitch',0),bg=j.get('bg',0)))
            fr=r.pop('fr');iv=[b2-a for a,b2 in zip(fr,fr[1:])];lat=r.pop('lat')
            dur=j.get('dur',10)+(3 if j.get('bg') else 0)
            row=dict(j,has=info['has'],mobPage=info['mob'],frames=len(fr),fps=round(len(fr)/(dur if not j.get('bg') else j.get('dur',10)),2) if not j.get('bg') else None,
                     fpsAvg=round((len(fr)-1)/((fr[-1]-fr[0])/1000),2) if len(fr)>2 else None,p95=round(sorted(iv)[int(len(iv)*.95)],2) if iv else None,
                     maxIv=round(max(iv),1) if iv else None,steps=r['steps'],stepsWarm=r['n0'],stepsWin=(r['steps']-r['n0']) if r['n0'] is not None else None,
                     winSec=round((r['tEnd']+1000/j['hz']-r['t0w'])/1000,3) if r['n0'] is not None else None,init=r['init'],h600=r['h600'],hseq=r['hseq'],H=r['H'],qc=r['qc'],q=r['q'][:6],qEnd=r['qEnd'],low=r['low'],
                     ipa=round(r['ipa']/max(1,len(fr)),3),jit=(round(math.sqrt(sum((b2-a)**2 for a,b2 in zip(lat,lat[1:]))/(len(lat)-1)),3) if len(lat)>2 and not (j.get('hitch') or j.get('bg')) else None),state=r['state'],errs=errs[:2])
            if j.get('bg'):
                bt=r.get('bgT');after=[x for x in fr if bt and x>=bt][:12];row['afterBg']=[round(x-bt,1) for x in after[:6]]
                row['fpsAvg']=round(len([x for x in fr if not bt or x<bt-3000])/ (4.0),2)
            res['runs'].append(row);await ctx.close()
            print(('ТЕЛ' if j['mob'] else 'ПК '),str(j['hz']).rjust(6),'Гц','предел',str(j['cap']).rjust(2),j['noise'].ljust(18),'кадров/с',row['fpsAvg'],'p95',row['p95'],'шагов: разгон',row['stepsWarm'],'окно',row['stepsWin'],'за',row['winSec'],'с',
                  'q',row['qc'],row['q'][:2],'lowFx',row['low'],'A-23',row['ipa'],'дрож',row['jit'],errs[:1],flush=True)
        await b.close()
    json.dump(res,open(out,'w'),ensure_ascii=False)
if __name__=='__main__':
    if sys.argv[1]=='run':asyncio.run(run(sys.argv[2],sys.argv[3],'--quick' in sys.argv))
def summ(files):
    for f in files:
        d=json.load(open(f));R=d['runs'];print('##',d['build'],'прогонов',len(R))
        # равенство симуляции: на одинаковой частоте и помехах хэш шага 600 и последовательности одинаков при всех пределах
        grp={}
        for r in R:grp.setdefault((r['mob'],r['hz'],r['noise']),[]).append(r)
        def pre(v):n=min(len(x['H']) for x in v);return len({tuple(x['H'][:n]) for x in v})==1,n
        neq=[(k,pre(v)[1]) for k,v in grp.items() if not pre(v)[0]]
        print('  групп (частота × помехи), где состояние после одинакового числа шагов различается между пределами:',len(neq),neq[:6],
              '· сравнено шагов (минимум по группе):',min(pre(v)[1] for v in grp.values()))
        for r in R:
            if r['noise'] in('ровно',) or 'перегрузка' in r['noise'] or r['noise']=='бесконечный':
                print('  ',('ТЕЛ' if r['mob'] else 'ПК '),str(r['hz']).rjust(6),'предел',str(r['cap']).rjust(2),r['noise'].ljust(24),'к/с',r['fpsAvg'],'p95',r['p95'],'шагов окно',(str(r['stepsWin'])+'/'+str(r['winSec'])+'с='+str(round(r['stepsWin']/r['winSec'],2))+'/с') if r.get('stepsWin') is not None else '—','разгон',r.get('stepsWarm'),'всего',r['steps'],'q',r['qc'],'lowFx',r['low'],'A-23',r['ipa'],'дрож',r['jit'])
if __name__=='__main__' and sys.argv[1]=='sum':summ(sys.argv[2:])
