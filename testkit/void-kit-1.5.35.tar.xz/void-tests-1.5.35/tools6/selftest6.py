#!/usr/bin/env python3
# Самопроверка инструментов этапа 6+7 на испорченных копиях сборки (сборки в /tmp, исходники не меняются).
#   python3 tools6/selftest6.py <сборка-1.5.30+.html>
# Каждый случай — минимальная порча; ожидаемый код выхода own6 (1 — нарушение) и фрагмент сообщения.
import sys,os,subprocess,tempfile
B=sys.argv[1];h=open(B,encoding='utf8').read();K='<script>\n"use strict";'
T=os.path.dirname(os.path.abspath(__file__))
def ins(code):i=h.index(K)+len(K);return h[:i]+'\n'+code+'\n'+h[i:]
CASES=[('S0 чистая сборка',h,0,'нарушений нет'),
 ('S1 прямая запись G.state вне scr6',ins("function __s1(){G.state='menu';}"),1,'screen: state: запись (w) в __s1'),
 ('S2 смена G.save вне saveSet6',ins("function __s2(){G.save={};}"),1,'save: save: запись (w) в __s2'),
 ('S3 запись поля прокачки вне блока',ins("function __s3(){G.lvl=3;}"),1,'runlvl: lvl: запись (w) в __s3'),
 ('S4 групповая запись поля прокачки',ins("function __s4(){Object.assign(G,{xp:0,score:1});}"),1,'runlvl: xp: запись (bulk) в __s4'),
 ('S5 изменённое тело API',h.replace('function runXp6(v){G.xp+=v;}','function runXp6(v){G.xp+=v*2;}',1),1,'runXp6: текст функции-владельца отличается'),
 ('S6 обёртка над владельцем',ins("{const _w=scr6;scr6=function(t){G.state=t;return _w(t);};}"),1,'scr6~w1'),
 ('S7 вычисляемый ключ G',ins("function __s7(k){G[k]=1;}"),1,'незарегистрированная вычисляемая'),
 ('S8 псевдоним G',ins("function __s8(){const g=G;g.state='x';}"),1,'псевдонимы G'),
 ('S9 запись поля наведения вне подсистемы',ins("function __s9(){G.prio=null;}"),1,'targeting: prio: запись (w) в __s9'),
 ('S10 исключение перестало писать',h.replace("Object.assign(G,{world:true,state:'world',","Object.assign(G,{world:true,",1),1,'исключение enterWorldAt больше не пишет')]
bad=0
with tempfile.TemporaryDirectory() as d:
    for name,src,code,frag in CASES:
        f=os.path.join(d,'c.html');open(f,'w',encoding='utf8').write(src)
        p=subprocess.run(['node',os.path.join(T,'own6.js'),f],capture_output=True,text=True)
        ok=p.returncode==code and frag in p.stdout
        bad+=not ok;print(('OK  ' if ok else 'FAIL'),name,'· выход',p.returncode,'·',(frag if ok else p.stdout[-300:]))
print('selftest6:', 'все случаи пойманы' if not bad else f'{bad} случаев не пойманы');sys.exit(1 if bad else 0)
