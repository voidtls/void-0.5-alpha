#!/usr/bin/env python3
# Этап 7 · trace7 — проверка слияния слоёв по поведению: одинаковые сценарии на двух сборках, после загрузки КАЖДАЯ глобальная
# функция оборачивается регистратором (имя → журнал), затем вызываются функции слитых цепочек. Для каждого вызова пишутся:
# последовательность вызванных глобальных функций (все уровни), исключение, тип результата, G.state, хэш состояния, хэш DOM.
#   python3 tools6/trace7.py run <сборка.html> <out.json>
#   python3 tools6/trace7.py cmp <a.json> <b.json>       — побитное сравнение журналов (выход 1 при расхождении)
# Регистратор не меняет поведение (вызывает исходную функцию с теми же this/arguments). RNG и время детерминированы (init st5).
import asyncio,json,sys,os
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','tools5'))
import st5
from playwright.async_api import async_playwright
WRAP=r"""(names)=>{window.__L=null;let n=0;Date.now=()=>1.7e12+performance.now();/* настенные часы — от того же детерминированного времени */
 for(const nm of names){let f;try{f=eval(nm);}catch(e){continue;}if(typeof f!=='function')continue;
   const w=function(){if(window.__L)window.__L.push(nm);return f.apply(this,arguments);};try{eval(nm+'=w');n++;}catch(e){}}
 window.domH=()=>{const c=document.body.cloneNode(true);c.querySelectorAll('script,style,dl.kv,#verTag').forEach(e=>e.remove());return fnv(c.innerHTML.split(VER_TAG).join('V').split(VER_TAG.split(' ')[0]).join('V'));};/* без исходника, номера версии и хроники */
 window.CALL=(label,code)=>{window.__L=[];let ex=null,rv;try{rv=eval(code);}catch(e){ex=String(e&&e.message||e).slice(0,120);}const L=window.__L;window.__L=null;
   return [label,L.length,fnv(L.join(',')),(window.__FULL?L:L.slice(0,60)).join(','),ex,rv===undefined?'u':rv===null?'n':typeof rv==='object'?('o:'+fnv(JSON.stringify(rv)||'')):typeof rv+':'+String(rv).slice(0,40),G.state,stH(),domH()];};
 return n;}"""
# сценарии: [метка, JS-выражение]
MENU=[('renderSettings','renderSettings()'),('renderSetScreen','renderSetScreen()'),('openSettings?','typeof openSettings==="function"?openSettings():0'),('renderSetScreen2','renderSetScreen()'),
      ('toMenu','toMenu()'),('renderSettings2','renderSettings()')]
PLAY=[('banner1',"banner('ПРЫЖОК')"),('banner2',"banner('ЗАГОЛОВОК','строка')"),('tutEmit-dash',"tutEmit('dash')"),('tutEmit-jump',"tutEmit('jump')"),('tutEmit-x',"tutEmit('act')"),
      ('tryDash',"tryDash()"),('tick1',"(__tick(),0)"),('tryDash-dir',"tryDash({x:1,y:0})"),('pulse-en',"(G.player.en=100,tryPulse())"),('tick2',"(__tick(),0)"),('tryPulse-low',"(G.player.en=10,tryPulse())"),
      ('mobOverlay',"mobOverlay(__now())"),('mobOverlay0',"mobOverlay()"),('tutStart-calib',"tutStart('calib')"),('tutStart-dash',"tutStart('dash')"),('tutTick2',"tutTick2(1/60,__now())"),
      ('pause',"pause()"),('pause2',"pause()"),('resume',"resume()"),('toMenu',"toMenu()")]
WORLD=[('enterNode?',"0"),('openMap',"openMap()"),('tutMapDraw',"tutMapDraw(__now())"),('openMap2',"openMap()"),('closeMap',"closeMap()"),('closeMap2',"closeMap()"),
       ('tick',"(__tick(),0)"),('banner',"banner('ПРЫЖОК')"),('mobOverlay',"mobOverlay(__now())"),('tutTick2',"tutTick2(1/60,__now())"),('pause',"pause()"),('resume',"resume()"),
       ('enterNode1',"enterNode(1)"),('st',"G.state"),('toMenu',"toMenu()"),('enterNode2',"(T.fresh(),enterNode(2))"),('toMenu2',"toMenu()")]
async def run(build,out):
    names=st5.gnames(build);res={'build':os.path.basename(build),'runs':{}}
    async with async_playwright() as pw:
        b=await pw.chromium.launch(executable_path=st5.CHROME,args=['--no-sandbox']) if st5.CHROME else await pw.chromium.launch(args=['--no-sandbox'])
        for key,enc,steps,dev,touch in [('menu','menu',MENU,False,False),('menu-dev','menu',MENU,True,False),('play','m10',PLAY,False,False),('play-dev','m10',PLAY,True,False),
                                        ('play-touch','m10',PLAY,False,True),('world','world',WORLD,False,False),('world-dev','world',WORLD,True,False)]:
            ctx,pg,errs=await (st5.page(b,build,390,844,True) if touch else st5.page(b,build))
            await pg.wait_for_timeout(2000)  # таймеры autoClick132 (500/1500 мс от загрузки) успевают сработать на обеих сборках — иначе гонка с состоянием звука
            await pg.evaluate(st5.COMMON)
            if dev:await pg.evaluate("()=>{try{localStorage.setItem('void_dev','1');G.dev=Object.assign(G.dev||{},{on:true});if(typeof devUnlock==='function')devUnlock();}catch(e){}}")
            if enc=='menu':await pg.evaluate("()=>{let now=50000;performance.now=()=>now;window.__now=()=>now;window.__tick=()=>{now+=1000/60;frame(now);};}")
            else:await pg.evaluate(st5.SCEN,{'enc':enc})
            n=await pg.evaluate(WRAP,names);log=[]
            for lab,code in steps:log.append(await pg.evaluate("([l,c])=>CALL(l,c)",[lab,code]))
            res['runs'][key]={'wrapped':n,'log':log,'errs':errs[:5]};await ctx.close()
            print(key,'обёрнуто',n,'вызовов',len(log),'исключений',sum(1 for r in log if r[4]),errs[:1],flush=True)
        await b.close()
    json.dump(res,open(out,'w'),ensure_ascii=False)
def cmp(a,b):
    A=json.load(open(a));B=json.load(open(b));bad=0;tot=0
    for k in A['runs']:
        la=A['runs'][k]['log'];lb=B['runs'].get(k,{}).get('log')
        if lb is None:print('нет прогона',k);bad+=1;continue
        for x,y in zip(la,lb):
            tot+=1
            if x!=y:bad+=1;print('РАСХОЖДЕНИЕ',k,x[0]);print('   A',x[1:3],x[4:],x[3][:200]);print('   B',y[1:3],y[4:],y[3][:200])
        if len(la)!=len(lb):bad+=1;print('длина',k,len(la),len(lb))
    calls=sum(r[1] for k in A['runs'] for r in A['runs'][k]['log'])
    print(f'trace7: вызовов {tot}, вложенных вызовов глобальных функций всего {calls}; расхождений {bad}');sys.exit(1 if bad else 0)
if __name__=='__main__':
    if sys.argv[1]=='run':asyncio.run(run(sys.argv[2],sys.argv[3]))
    else:cmp(sys.argv[2],sys.argv[3])
