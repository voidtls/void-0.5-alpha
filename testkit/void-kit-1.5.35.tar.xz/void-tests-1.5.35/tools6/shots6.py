#!/usr/bin/env python3
# Снимки экрана настроек со строкой «КАДРЫ» на 6 размерах (стенд headless, не реальные устройства).
#   python3 tools6/shots6.py <сборка.html> <папка>
import asyncio,sys,os,json
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','kit'))
from h import newpage
from playwright.async_api import async_playwright
SIZES=[(320,568,True),(390,844,True),(844,390,True),(768,1024,True),(1280,760,False),(1920,1080,False)]
OPEN="async()=>{const w8=ms=>new Promise(r=>setTimeout(r,ms));T.fresh();G.save.tut.off=1;$('#toast').hidden=true;await w8(250);pause();await w8(150);$('#bPauseSet').click();await w8(300);"
async def main(b_,out):
    os.makedirs(out,exist_ok=True);os.environ['GAME_URL']='file://'+os.path.abspath(b_);res={}
    async with async_playwright() as pw:
        kp=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','.kitpaths.json');ch=os.environ.get('CHROME') or (json.load(open(kp))['chrome'] if os.path.exists(kp) else None)  # корректирующее обновление: без абсолютного пути
        b=await pw.chromium.launch(executable_path=ch,args=['--no-sandbox']) if ch else await pw.chromium.launch(args=['--no-sandbox'])
        for w,h,t in SIZES:
            P=await newpage(b,w,h,url='file://'+os.path.abspath(b_),alpha=False,touch=t,dsf=2)
            r=await P.js(OPEN+"const tab=document.querySelector('#sSet button[data-tab63=\"scr\"]');if(tab){tab.click();await w8(200);}const s=document.querySelector('#setBody [data-seg=\"fps\"]');if(!s)return {seg:false};s.scrollIntoView({block:'center'});await w8(150);"
                         "const r=s.getBoundingClientRect(),bs=[...s.querySelectorAll('[data-v]')].map(x=>{const q=x.getBoundingClientRect();return {t:x.textContent.trim(),w:Math.round(q.width),h:Math.round(q.height),over:x.scrollWidth>x.clientWidth+1};});"
                         "return {seg:true,w:Math.round(r.width),right:Math.round(r.right),vw:innerWidth,bs,inView:r.right<=innerWidth+1&&r.left>=-1}}")
            f=os.path.join(out,f'set_{w}x{h}.png');await P.pg.screenshot(path=f);res[f'{w}x{h}']=r
            print(w,h,json.dumps(r,ensure_ascii=False)[:300],flush=True)
        await b.close()
    json.dump(res,open(os.path.join(out,'shots.json'),'w'),ensure_ascii=False,indent=1)
asyncio.run(main(sys.argv[1],sys.argv[2]))
