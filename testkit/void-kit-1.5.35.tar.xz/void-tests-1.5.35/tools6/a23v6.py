#!/usr/bin/env python3
# Корректирующее обновление · ПРЕДЛОЖЕНИЕ для 75 Гц (A-23), не вносится в игру: вариант сборки с порогом включения интерполяции
# 0.84 шага (14,0 мс) вместо 0.8 (13,33 мс). На 75 Гц период экрана 13,333 мс ровно на прежнем пороге: средняя длина кадра (ema)
# не опускается строго ниже 13,333, и A-23 не включается — в отличие от 72/90/120 Гц. Правка — два числа:
#   ip76Apply: IP76.ema<STEP74*.8   → IP76.ema<STEP74*.84      (включение; выключение по-прежнему при ≥ 0.9 шага)
#   ip27fast : FC27.disp<STEP74*800 → FC27.disp<STEP74*840     (то же при действующем пределе, ARCH·92)
#   python3 tools6/a23v6.py <сборка.html> <вариант.html>   — выход 3, если образец найден не ровно один раз
import sys
s=open(sys.argv[1],encoding='utf8').read()
E1=('IP76.act=IP76.act?IP76.ema<STEP74*.9||ip27fast():IP76.ema<STEP74*.8||ip27fast();','IP76.act=IP76.act?IP76.ema<STEP74*.9||ip27fast():IP76.ema<STEP74*.84||ip27fast();')
E2=('FC27.disp<STEP74*800;}','FC27.disp<STEP74*840;}')
for o,n in (E1,E2):
    if s.count(o)!=1:print('образец найден %d раз: %s'%(s.count(o),o));sys.exit(3)
    s=s.replace(o,n)
open(sys.argv[2],'w',encoding='utf8').write(s);print('вариант A-23 0.84:',sys.argv[2])
