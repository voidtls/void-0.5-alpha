#!/usr/bin/env python3
# Этап 6+7 · текстовые зависимости тестов от исходника сборки (только чтение).
#   python3 tools6/tdep6.py <старая.html> <новая.html> [--json out.json]
# Собирает все строковые литералы (≥ 6 символов) из тестов kit/q*.py, kit/h.py и стендов kit/t72 (st74, a24route), которые встречаются в тексте старой сборки,
# и сообщает те, что исчезли или изменили число вхождений в новой. Падение теста из-за правки текста видно до запуска.
# Выход 0 — потерь нет; 1 — есть исчезнувшие литералы (их надо разобрать: допустимо только для объявленных правок).
import ast,os,sys,json,glob
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));KIT=os.path.join(R,'kit')
a=open(sys.argv[1],encoding='utf8').read();b=open(sys.argv[2],encoding='utf8').read()
lits={}
for f in sorted(glob.glob(os.path.join(KIT,'q*.py'))+[os.path.join(KIT,x) for x in ('h.py','t72/st74.py','t72/a24route.py') if os.path.exists(os.path.join(KIT,x))]):
    try:t=ast.parse(open(f,encoding='utf8').read())
    except SyntaxError:continue
    for n in ast.walk(t):
        if isinstance(n,ast.Constant) and isinstance(n.value,str) and len(n.value)>=6:
            lits.setdefault(n.value,set()).add(os.path.relpath(f,KIT))
lost=[];changed=[]
for s,fs in lits.items():
    ca=a.count(s)
    if not ca:continue
    cb=b.count(s)
    if cb==0:lost.append({'lit':s[:160],'files':sorted(fs),'was':ca})
    elif cb!=ca:changed.append({'lit':s[:160],'files':sorted(fs),'was':ca,'now':cb})
print(f'tdep6: литералов тестов, найденных в старой сборке: {sum(1 for s in lits if a.count(s))}; исчезли: {len(lost)}; изменилось число вхождений: {len(changed)}')
for x in lost:print('  ИСЧЕЗ',x['files'],repr(x['lit'][:100]))
for x in changed[:40]:print('  ЧИСЛО',x['was'],'→',x['now'],x['files'],repr(x['lit'][:100]))
if '--json' in sys.argv:json.dump({'lost':lost,'changed':changed},open(sys.argv[sys.argv.index('--json')+1],'w'),ensure_ascii=False,indent=1)
sys.exit(1 if lost else 0)
