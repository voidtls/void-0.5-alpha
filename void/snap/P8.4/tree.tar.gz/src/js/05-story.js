// ===================== 0.5 «Не дайте ему вспомнить»: сюжет =====================
const FRAG_SHIFT=20,FRAG_SHIFT_MAX=300,EROSION_FULL=25000;
const STORY_OFF={};
// [№, сектор(0..10), корпус, подпись, текст, текст цикла II+ (необяз.)]
const STORY_W=[
[1,0,'base','«ИНЕЙ-4» · ЗАПИСЬ 112','Мы приняли сигнал за маяк и шли на свет. Поняли слишком поздно: он светил не нам.','Мы приняли сигнал за маяк и шли на свет. Поняли слишком поздно: он светил тебе.'],
[2,0,'base','ПИЛОТ СОРЕЛЬ','Разведчики почти не стреляют. Они считают. Каждый наш манёвр куда-то уходит — к ядру.'],
[3,0,'base','ИНЖЕНЕР ВАРГА','Заряды Стража — не броня, а предохранители. Не понимаю только, кого они предохраняют.'],
[4,1,'base','ПОГРАНИЧНЫЙ БУЙ','Ворота держат два замка. Ставили их не мы. Открываются только тем, кто прошёл ядро.'],
[5,1,'base','СМОТРИТЕЛЬ «ГОРИЗОНТА»','Маяк не гаснет. Он просто перестал быть нужен — некому было слушать.'],
[6,1,'base','ПОСЛЕДНЯЯ ЗАПИСЬ СТАНЦИИ','Глушитель — не корабль. Это тишина, которой придали форму. Если ты это слышишь, значит, у тебя получилось.'],
[7,2,'base','АРХИВАРИУС «ХОЛОДНОГО АРХИВА»','Каталог: 41 цивилизация. Все изобрели одно и то же. Все записаны одним почерком.'],
[8,2,'base','КОЛОНИСТКА ИДА РЕН','Я пишу имена на корпусе гвоздём. Металл помнит дольше, чем люди.'],
[9,2,'guard','СТРАЖ-4 · ЖУРНАЛ ОТКАЗОВ','Запрос: объяснить объекту 013 причину. Отказано. Причина засекречена создателем.'],
[10,3,'base','VØID-013 · ЦИКЛ 31','Страж не добил меня. Сказал: «Опять рано». Что значит — опять?'],
[11,3,'base','ТЕХНИК А. ЛОРАН','Мой сын был в списке колонии «Тихая». Сегодня списка нет. Почему я до сих пор помню, что он был?','Не помню, был ли у меня сын. Почерк в журнале мой.'],
[12,3,'base','АВТОМАТ «ОБОД» · КОПИЯ ЛОГА','Клиент 013. Посещений: 4 102. Износ корпуса при поступлении: всегда 12%.','@obod'],
[13,4,'base','ЗАПИСЬ ЧУЖОГО ВИДА · ПЕРЕВОД НЕПОЛНЫЙ','Мы сохранили наших мёртвых. Цена — наши нерождённые.'],
[14,4,'base','УЧЁНАЯ ТАЛА ОШ','Предел — не в технологиях. В пространстве есть место только для конечного числа историй.'],
[15,5,'base','ФЛАГМАН «ПОСЛЕДНИЙ ДОВОД»','Флот вышел против Стражей. Стражи стреляли по двигателям, не по рубкам. Мы не поняли этой милости.'],
[16,5,'falcon','КУРСАНТ ТЕО','Мама обещала встретить в порту. Порта нет на картах. Мамы — в списках.'],
[17,6,'base','«АВРОРА-2» · НОМЕР НЕ ВЫДАН','Нас ещё не построили. Верфь заложит киль через сорок лет.'],
[18,6,'pulsar','VØID-012 · ЦИКЛ 1','Последний перед тобой. Если ты здесь, моя попытка тоже засчитана.'],
[19,6,'hornet','VØID-005 · ЦИКЛ 12','Собрал себя из трёх чужих корпусов. Один из них ещё не построен.'],
[20,6,'prism','VØID-009 · ЦИКЛ 140','В архиве есть запись о моей смерти. Датирована завтрашним днём.'],
[21,6,'base','ПАССАЖИРКА БЕЗ ДАТЫ','В моих документах дата рождения — через двести лет. А я уже старая.'],
[22,6,'base','@next','Этот корпус — мой. Номер цикла — следующий после твоего.'],
[23,6,'guard','СТРАЖ-19','Мы помним предыдущие прохождения. Он — нет. Так задумано.','@s19'],
[24,6,'base','МИРА СЕН · ЗАПИСЬ А','Не пиши его имя целиком. Если система увидит его полностью, она вспомнит за него.'],
[25,7,'guard','СБОРОЧНЫЙ УЗЕЛ СТРАЖЕЙ','Протокол 0: держать границу. Протокол 1: не объяснять. Подпись: Э. В.'],
[26,7,'guard','СТРАЖ-0 · ПЕРВАЯ ЗАПИСЬ','Меня собрали, чтобы я остановил того, кто меня собрал. Он попросил об этом сам.'],
[27,7,'base','НЕИЗВЕСТНЫЙ ПИЛОТ','Гвардия стоит лицом не к нам. Мы долго не понимали, от чего она нас загораживает.'],
[28,7,'base','ИНЖЕНЕР БЮРО «ПРЕДЕЛ» КОРВИН','Мы дали им щиты спереди, а не сзади. Сзади у них то, что они охраняют.'],
[29,7,'guard','СПИСАННЫЙ СТРАЖ С-0/41','Меня списали за один вопрос: «Почему мы защищаем его от него самого?»'],
[30,7,'manta','VØID-006 · ЦИКЛ 413','Отпустил троих. Один вернулся и встал между мной и Стражем.'],
[31,7,'falcon','VØID-004 · ЦИКЛ 902','Страж-0 назвал моё имя. Я его не запомнил. Он сказал: «Так и должно быть».'],
[32,7,'guard','СТРАЖ-11','Объект 013 снова у границы. Напоминание всем узлам: не дайте ему вспомнить.','@s11'],
[33,7,'base','ИСПЫТАТЕЛЬНИЦА БЮРО «ПРЕДЕЛ» АДА МЭЙ','Первый страж открыл глаза и прицелился в того, кто стоял рядом. Тот улыбнулся и сказал: «Хорошо».'],
[34,7,'obsidian','VØID-010 · ЦИКЛ 51','Спрятался в тени конвейера. Они нашли меня по тому, чего во мне нет.'],
[35,7,'reaper','МИРА СЕН · ЗАПИСЬ Б','Мы назвали его Ковчегом. Ковчег берёт с собой не всех. Мы знали это с первого дня.','Мы назвали его Ковчегом. Ковчег берёт с собой всех, кого мы помним.'],
[36,8,'base','ГРУЗОВОЙ ДРОН Т-9','Пиявки пришли после третьей вспышки. Металл им не нужен. Они не едят свет — они несут его обратно.'],
[37,8,'base','СМОТРИТЕЛЬ КОВЧЕГА · ВАХТА 9','Счётчик историй сегодня показал минус одну. Я записал. Через час не мог вспомнить какую.','Счётчик показал минус две. Вчера было минус одна. Или это было в другой раз.'],
[38,8,'base','СОХРАНЁННАЯ · ЛИА, 9 ЛЕТ','Здесь тепло и тихо. Мне сказали, что снаружи тоже кто-то был. Я их не помню.'],
[39,8,'sail','VØID-003 · ЦИКЛ 1200','Сердце Ковчега бьётся ровно. Каждый удар — чей-то мир.'],
[40,8,'prism','VØID-009 · ЦИКЛ 990','Видел его. Он старше всех звёзд вокруг. Он улыбнулся так, как улыбаюсь я.'],
[41,8,'base','Э. В.','Каждая копия знает кусок. Ни одна — целое. Целое делает тебя частью машины.'],
[42,8,'base','МИРА СЕН · ЗАПИСЬ В','Ковчег спасает всех. Я проверяла. Никто не исчез. Никто.'],
[43,8,'base','ОПЕРАТОР КОНТУРА «УДЕРЖАНИЕ»','Сегодня удержали двенадцать систем. Сколько стёрли — не знаю. Нам не показывают вторую колонку.','@op'],
[44,8,'base','Н.','Ты думаешь, я тебя веду. Я просто иду первым. Я всегда шёл первым.','Ты думаешь, я тебя веду. В прошлый раз ты думал так же.'],
[45,8,'reaper','VØID-011 · ЦИКЛ 9','Я забрал всё, что лежало вокруг. Стал сильнее. Пришли все Стражи сразу.'],
[46,9,'base','БОРТОВОЙ ЖУРНАЛ БЕЗ ВЛАДЕЛЬЦА','[ЗАПИСЬ УДАЛЕНА ВМЕСТЕ С ВЛАДЕЛЬЦЕМ]'],
[47,9,'halo','VØID-002 · ЦИКЛ 2','Мы, первая серия, помнили всё. Каждое воспоминание откусывало кусок берега.'],
[48,9,'obsidian','VØID-010 · ЦИКЛ 777','За берегом не пустота. Там всё, чего не случилось. Оно смотрит.'],
[49,9,'base','МИРА СЕН · ЗАПИСЬ Г','Я — та Мира, которой не было. Меня сохранили по ошибке. Спасибо.','Я — та Мира, которой не было. В этот раз меня тоже не будет.'],
[50,9,'base','СОЛ ВЕДЕРН · ЧЕЛОВЕК, КОТОРОГО НЕ БЫЛО','Меня стёрли до рождения. Странно так говорить. Но здесь, у берега, все такие.'],
[51,9,'hornet','VØID-005 · ЦИКЛ 1500','Собирал фрагменты памяти. С каждым Разлом подходил ближе. Знание чего-то стоит.'],
[52,9,'base','КОЛОНИЯ «ТИХАЯ»','Нас нет ни в одной истории. Но мы здесь, на берегу, и ждём, когда кто-нибудь вспомнит.'],
[53,9,'comet','VØID-007 · ЦИКЛ 203','Ушёл в Разлом дальше всех. Там стреляют такие же, как я. Целятся так же, как я.'],
[54,9,'base','СИГНАТУРА НЕ ОПРЕДЕЛЕНА','013, разворачивайся. Мы уже пробовали.','013, разворачивайся. Ты уже пробовал. Это был ты.'],
[55,10,'pulsar','VØID-012 · ЦИКЛ 3001','Нулевая точка — не место. Это миг, когда он впервые нажал кнопку.'],
[56,10,'comet','VØID-007 · ЦИКЛ 3002','Отсюда видны все копии сразу. Мы похожи на созвездие. Без имени.'],
[57,10,'base','Н.','«Не дайте ему вспомнить» писал не я. Но я с ними согласен.'],
[58,10,'base','Э. В.','Если нашёл это — значит, сработало хотя бы частично. Не ищи меня. Ищи третий путь.'],
[59,10,'halo','VØID-002 · ЦИКЛ 1','Первая копия. Я открыл глаза и спросил его имя. Он не ответил. Теперь я знаю почему.'],
[60,10,'reaper','VØID-011 · ЦИКЛ 10','Снова забрал всё. Здесь нечего забирать. Впервые мне легко.'],
[61,10,'sail','VØID-003 · ЦИКЛ 77','Долетел без двигателей. Ничего не взял. Они пропустили меня — сюда, где нечего охранять.'],
[62,10,'manta','VØID-006 · ЦИКЛ 88','Выключил орудия у самой точки. Здесь тихо, как до первого запуска.'],
[63,10,'base','VØID-013 · ЦИКЛ —','Если ты читаешь это — ты дошёл дальше меня. Значит, мы уже чуть больше, чем копии.','Ты снова дошёл дальше. Нас становится больше.']];
const STORY_OLDID={1:'j1',2:'j2',3:'j3',4:'j5',5:'j6',6:'j8',27:'j4',36:'j7'};
const STORY_FRAG=['Лаборатория пахнет озоном. Кто-то смеётся у меня за спиной. Мира?',
 'Я держу модель: кольцо внутри кольца. Говорю: «Оно ничего не будет стирать».',
 'Первый запуск. Стрелки приборов стоят. Потом исчезает соседний корпус. Никто не замечает, что его не было.',
 'Я подписываю протокол. Две буквы: Э. В. Рука дрожит.',
 'Мира спрашивает, сколько историй мы можем себе позволить. Я называю число. Она плачет.',
 'Я проектирую стража. Даю ему один запрет: никогда не объяснять мне, зачем он стреляет.',
 'Я записываю себя в первую копию. Она открывает глаза и спрашивает моё имя. Я не отвечаю.',
 'Первая серия помнила всё. Через неделю половина секторов исчезла с карт.',
 'Я учусь забывать нарочно. Это сложнее, чем помнить.',
 'Сигнал в пустоту. Я отправляю его сам. Или кто-то, кто раньше был мной.',
 'Тринадцатая серия. Я говорю: «Пусть они будут пустыми. Пустое нельзя стереть».',
 'Я стою в сердце машины. Каждый удар — чей-то мир. Я считаю удары, чтобы не слышать.',
 'Мира уходит. В одной истории — к звёздам. В другой — в машину. Я не знаю, какая настоящая.',
 'Я оставляю на обломках свои инициалы. Если копия найдёт их — она сможет решить без меня.',
 '«Не дайте ему вспомнить». Я сам их об этом попросил.'];
// группы перехватов; c — условие
const RADIO={
 'А':{tag:'СТРАЖ',col:'#ff6b8a',l:[{t:'Объект в секторе. Вести, не вступать.'},{t:'Он стреляет первым. Как всегда.'},{t:'Держать строй. Граница за спиной.'},{t:'Не дайте ему вспомнить.',c:'force'},{t:'Потери допустимы. Его воспоминания — нет.'},{t:'Он снова поглощает. Эрозия растёт.'},{t:'Отходите к маяку. Маяк важнее нас.'},{t:'Не отвечать на его частоту.'},{t:'Цель повторяет маршрут. Предсказуемо.'},{t:'Он не знает, что ищет. Пусть так и остаётся.'},{t:'Узел семь потерян. Узел семь будет восстановлен.'},{t:'Цель приближается к ядру. Будите Стража-0.',c:'m4'},{t:'Не стрелять по рубке. Только по двигателям.'},{t:'Он спросит — не отвечать.'},{t:'Ещё одна копия. Протокол тот же.',c:'m7'}]},
 'В':{tag:'М. СЕН',col:'#c9a6ff',l:[{t:'…если кто-то слышит — мы почти закончили калибровку…'},{t:'…он не спит третьи сутки. Говорит, что спать — значит забывать…'},{t:'…Ковчег держит. Ковчег держит. Не смотри на карту…'},{t:'…я не помню, как выглядела моя сестра. Её фотографии пустые…'},{t:'…он запретил стражам объяснять. Даже мне не объяснил…'},{t:'…эта запись из другой версии. Если в твоей я жива — передай мне…'},{t:'…тринадцатая серия будет пустой. Он называет это милосердием…'},{t:'…я голосовала против. В другой истории — за…'},{t:'…если ты копия — ты не виноват. Если ты оригинал — виноват…'},{t:'…не ищи меня в списках. Меня в них сохранили неправильно…'},{t:'…он сказал: «Пусть кто-то другой найдёт третий путь». Он имел в виду тебя…'},{t:'…выключи приёмник. Если слушать меня долго, начнёшь вспоминать…'}]},
 'Г':{tag:'ЭФИР',col:'#9fb0c4',l:[{t:'…«Горизонт», ответьте. «Горизонт»…'},{t:'…двигатель держит, корпус нет. Скажите дочери…'},{t:'…я вижу свой корабль. Он летит мне навстречу…'},{t:'…не стреляйте, мы гражданские… мы были гражданскими…'},{t:'…здесь была планета. Я точно помню, здесь была планета…'},{t:'…топливо на нуле, летаю кругами. Гвардия не трогает…'},{t:'…кто-нибудь помнит колонию «Тихая»? Хоть кто-нибудь?…'},{t:'…маяк светит. Мы идём. Мы идём…'},{t:'…странно: мне не страшно. Будто уже было…'},{t:'…«НЕ ДАЙТЕ ЕМУ ВСПОМНИТЬ» на всех частотах. Кому — ему?…'},{t:'…меня зовут… меня звали…'},{t:'…если найдёте это — не сдавайте корпус на лом…'},{t:'…счётчик лет сломался. Показывает 127…'},{t:'…слышу стрельбу. Это VØID? Опять VØID?…'},{t:'…на моём корпусе чужие инициалы. Не мои…'}]},
 'Д':{tag:'Н.',col:'#ffd36b',l:[{t:'Координаты подтверждены. Продолжайте.',c:'force'},{t:'Вы ближе, чем в прошлый раз.',c:'cyc2'},{t:'Не слушайте Стражей. Они помнят за вас.'},{t:'Контракт выдан. Оплата — тем, что останется.'},{t:'Я посылал этот сигнал до того, как вы родились. Вы тоже.'},{t:'Ищите там, где карта молчит.'},{t:'Когда дойдёте до Нулевой точки — узнаете голос.'},{t:'Не торопитесь. Вы опоздали на сто двадцать семь лет. Ещё минута ничего не изменит.'}]},
 'Е':{tag:'?',col:'#ff4f6e',rift:1,l:[{t:'013, разворачивайся. Мы уже пробовали.'},{t:'Здесь нет сектора. Здесь нет тебя.'},{t:'Мы стреляем, как ты. Потому что мы — ты.'},{t:'Вернись. Нам не нужна компания.'},{t:'Какой у тебя цикл? У меня кончились числа.'},{t:'Слышишь свой голос? Привыкай.'},{t:'Мы были дальше. Здесь нечего искать.'},{t:'Не пытайся увернуться. Мы знаем твой рывок.'},{t:'Ещё шаг — и тебя никто не вспомнит. Даже ты.'},{t:'Помехи — это мы. Мы кричим.'},{t:'Твой корпус уже лежит здесь. Хочешь посмотреть?',c:'rwreck'},{t:'Уходи, пока помнишь дорогу назад.'}]},
 'Ж':{tag:'ОТСТУПАЮЩИЙ',col:'#dfe8ff',l:[{t:'Не стреляй. Я ухожу.'},{t:'Достаточно. Граница удержана.'},{t:'Ты отпускал меня раньше. Я помню.',c:'cyc2'},{t:'Мне нужно донести запись.'},{t:'Отступаю. Сохрани заряд для Стража.'},{t:'Это не трусость. Это протокол.'},{t:'Спасибо. Это не входит в протокол.',c:'force'},{t:'Мы ещё встретимся. В другом цикле.'}]},
 'З':{tag:'БОРТ',col:'#8fe9ff',l:[{t:'Цель экспедиции: установить источник сигнала. Цель экспедиции: установить источ…'},{t:'Сверка памяти: расхождение 3%. Игнорировать.'},{t:'Обнаружена запись с вашей подписью. Доступ запрещён.'},{t:'Внимание: эрозия в радиусе корабля. Источник: корабль.',c:'eros'},{t:'Восстановление связи с человечеством: адресат не найден.'},{t:'Пилот опознан. Пилот опознан. Пилот оп…'},{t:'Рекомендация: не задерживаться у обломков.'},{t:'Модули установлены. Происхождение модулей: не указано.'},{t:'Ошибка: экспедиция 013 зарегистрирована 4 102 раза.'},{t:'Сон пилота: не требуется. Сон пилота: запрещён.'},{t:'Архив молчит. Запросов не поступало. Запросов больше не будет.',c:'invcold'},{t:'Корпус восстановлен до заводского. Происхождение корпуса: не указано.',c:'observ'}]},
 'И':{tag:'ЭФИР',col:'#c9a6ff',l:[{t:'…приём. Это «Аврора-2». Мы ещё не вылетели. Почему вы нас слышите?…'},{t:'…сигнал пришёл раньше, чем был отправлен. Отправитель — вы…'},{t:'…не стреляйте в этот корабль, его ещё не построили…'},{t:'…вы уже прошли здесь. Через минуту. Я видел обломки…'},{t:'…наши часы показывают завтра. Завтра нас нет…'},{t:'…если вы слышите это до своей гибели — сверните левее…'}]},
 'К':{tag:'БЮРО «ПРЕДЕЛ»',col:'#6b8cff',l:[{t:'…бюро «Предел», испытание 12. Страж отказался стрелять в макет. Макет был в форме создателя…'},{t:'…протокол «не объяснять» прошит в ядро. Удалить невозможно. Он так хотел…'},{t:'…сборка партии сорок. В базе угроз у каждого одно и то же лицо…'},{t:'…мы делаем их честными. Им будет больно врать. Поэтому им запрещено говорить…'},{t:'…списанный страж просится обратно. Говорит, без границы ему нечего помнить…'},{t:'…он стоял у конвейера и смотрел, как они учатся его узнавать…'}]},
 'Л':{tag:'КОВЧЕГ',col:'#ffd36b',l:[{t:'…удержание: двенадцать систем. Вторая колонка скрыта…'},{t:'…сохранённые спрашивают, есть ли снаружи кто-нибудь. Инструкция: отвечать «нет»…'},{t:'…сердцебиение машины ровное. Шестьдесят ударов. Шестьдесят миров…'},{t:'…смотритель, вахта девять. Я снова забыл, что записал…'},{t:'…внимание, в контуре чужая копия. Код доступа совпадает с кодом создателя…'},{t:'…девочка из сектора сохранения рисует корабль. Ваш корабль…'}]},
 'М':{tag:'БЕРЕГ',col:'#7affc9',l:[{t:'…мы те, кого не случилось. Мы не злимся. Мы просто здесь…'},{t:'…колония «Тихая» вызывает. Нас никто не помнит, но мы всё ещё вызываем…'},{t:'…берег осыпается каждый раз, когда кто-то вспоминает лишнее…'},{t:'…ты оставил здесь след в прошлый раз. Он ещё тёплый…'},{t:'…с этой стороны ваша карта выглядит как остров…'},{t:'…не оборачивайся. За спиной — твоя другая жизнь…'}]},
 'П':{tag:'АРХИВ',col:'#8fd8ff',l:[{t:'Запись 4 117 принята. Источник: 013. Дубликат.'},{t:'Каталог цивилизаций закрыт для дополнений. Исключение: сорок вторая.'},{t:'Расхождение почерка с эталоном: ноль.'},{t:'Посетителю 013: ваш маршрут уже хранится. Повторный ввод не требуется.'},{t:'Температура хранения в норме. Записи не меняются. Записи не должны меняться.'},{t:'Запрос Стража-4 на объяснение отклонён. Основание: засекречено создателем.'},{t:'Обнаружена попытка импровизации. Классифицировано как шум.'},{t:'Сорок одна история. Один почерк. Вопросов не поступало.'},{t:'Дубликат 013 обнаружен в собственном каталоге. Удалять не предписано.'},{t:'Каталог оттаял. Тридцать одна запись читает друг друга. Шум, похожий на хор.',c:'invmem'},{t:'Эталон утрачен. Сверять не с чем. Архив продолжает принимать.',c:'invmem'}]},
 'Р':{tag:'ТИХАЯ',col:'#ffa66b',l:[{t:'…третьей очереди на высадку нет. Список пустой. Список был…'},{t:'…ремонтный автомат «Обод»: клиент 013, посещение 4 103, износ 12%…'},{t:'…папа, ты где? …папа?…'},{t:'…мы грузили тягачи три дня. Куда — не помню. Тягачи помнят…'},{t:'…колония «Тихая» вызывает порт. Порт не отвечает. Порта нет на карте…'},{t:'…ржавчина не на корпусе. Ржавчина — это и есть корпус…'},{t:'…«Обод» чинит всех. Он не спрашивает, кого чинит. Ему запретили…'},{t:'…я нацарапал имена на листе обшивки. Лист ржавеет быстрее, чем я забываю…'},{t:'…если слышишь это, сын, я всё ещё помню, что ты был…'},{t:'…«Обод» списан. Тягачи стоят. Некому сказать им, что везти…',c:'obscrap'},{t:'…кольцо не вращается. Впервые за сто двадцать семь лет тихо…',c:'obscrap'},{t:'…заказ 4 103 закрыт. Клиент восстановлен до заводского. Следующих не будет…',c:'observ'},{t:'…в списке колонистов снова есть строки. Одна — моя…',c:'observ'}]},
 'Н':{tag:'0',col:'#ff9fe0',l:[{t:'…здесь всё начиналось. Здесь всё начнётся снова, если ты захочешь…'},{t:'…я узнаю твой маршрут. Я летал им первым…'},{t:'…все копии сразу на одной частоте. Шум, похожий на хор…'},{t:'…кнопка ещё тёплая…'},{t:'…не дайте ему вспомнить. Не дайте ему вспомнить. Не дай… себе…'},{t:'…сигнал отправлен. Получатель: VØID-013. Отправитель: VØID-000…'}]}};
const RADIO_SEC={2:'П',3:'Р',6:'И',7:'К',8:'Л',9:'М',10:'Н'};
const STORY_NOTES={2:'Зафиксированы следы выстрелов вашего типа. Время: до вашего прибытия.',5:'Связь с экспедицией: нет ответа. Последний ответ получен 127 лет назад.',8:'Ретрансляторы передают голос, совпадающий с вашим на 100%.',10:'Передача адресована VØID-013. Отправитель — тоже.'};
const STORY_SHOP=[{t:'Добро пожаловать. Корпус изношен на 12%. Как обычно.',c:'first'},{t:'Вы платите ломом. Я не спрашиваю, чьим.'},{t:'Модули на складе. Их снимали с таких же, как вы.'},{t:'Протокол обслуживания написан Э. В. Он просил не задавать вопросов.'},{t:'Стражи сюда не заходят. Это часть договора.'},{t:'Скидок нет. Цена не менялась 127 лет.'},{t:'Предыдущий клиент выбрал тот же модуль. Он не вернулся.',c:'bought'},{t:'Вы уже покупали это. В другой раз.',c:'cyc2'},{t:'Клиент 013 опознан. Повторно. Повторно. Повторно.',c:'cyc2'},{t:'Если найдёте Э. — передайте, что автомат всё ещё работает.',c:'cyc3'}];
const STORY_WARDEN=['Опять рано.','Ты снова здесь?','На этот раз ты добрался дальше.','Мы не враги. Ты просил нас остановить тебя.'];
const STORY_HULL={base:'VØID-013. Текущая копия. Состояние: цел.',falcon:'VØID-004. Найден у Пояса Стража. Двигатели работали до конца.',manta:'VØID-006. Найден в Дрейфе. Пилот выключил оружие сам.',prism:'VØID-009. Найден у края Разлома. Внутри — только свет.',reaper:'VØID-011. Поглотил больше всех. Стражи пришли за ним все сразу.',halo:'VØID-002. Старейший корпус. Кольцо — часть первого Ковчега.',comet:'VØID-007. Ушёл дальше всех в Разлом. Хвост светится до сих пор.',hornet:'VØID-005. Собран из деталей трёх других копий.',obsidian:'VØID-010. Пытался спрятаться от Стражей. Они запомнили форму.',sail:'VØID-003. Летел без двигателей, чтобы ничего не поглощать. Не долетел.',pulsar:'VØID-012. Последний перед вами. Сигнал ещё пульсирует.'};
const STORY_LORE={scout:'Считывает ваш маршрут и передаёт ядру.',gunner:'Стреляет на поражение, потому что предупреждения вы уже слышали.',rammer:'Жертвует собой. Его запись уже сохранена где-то ещё.',splitter:'Одна запись, разделённая на три, чтобы её труднее было поглотить.',mite:'Одна запись, разделённая на три, чтобы её труднее было поглотить.',miner:'Расставляет мины там, где вы пролетали в прошлый раз.',shielder:'Защищает других ценой себя. Странно для машины.',lancer:'Его луч достаёт до края наблюдаемого. Дальше стрелять не в кого.',guard:'Держит строй лицом к Разлому, а не к вам. Разворачивается неохотно.',pylon:'Сдерживает не вас, а Стража.',seeker:'Наводится не на корпус, а на подпись вашего сознания.',boss:'Первый защитник. Знает, кто вы. Ему запрещено сказать.',moth:'Летит на свет маяка, как летели все до него.',leech:'Тянет заряд не для себя: пытается вернуть стёртое.',carrier:'Внутри — не дроны, а копии одного и того же дрона.',cutter:'Режет пространство по швам, оставленным Ковчегом.',tug:'Уводит маяк туда, где его никто не запомнит.',mortar:'Бьёт по площади: без разницы, что там было.',phantom:'Остаток корабля, которого никогда не было.',shade:'Повторяет ваши манёвры с опозданием в один цикл.',mirror:'Возвращает вам то, что вы в него вложили.',hive:'Восстанавливает своих из записей. Как и Ковчег.',shocker:'Разряд стирает последние доли секунды из памяти систем.',vortex:'Место, где пространство начало забывать себя.',twin:'Две версии одного корабля из разных историй. Спорят, кто настоящий.',thief:'Забирает ячейки, чтобы их не поглотили вы.',hunter:'Идёт по следу вашей эрозии.',commander:'Отдаёт приказы на языке, который писали вы.',cruiser:'Последний корабль флота, перешедший на сторону Стражей.',antenna:'Передаёт одну фразу. Вы её знаете.',decoy:'Светит так же, как сигнал, который привёл вас сюда.',jam:'Тишина, которой придали форму. Заглушает не связь, а вашу память.'};
const STORY_NORETREAT=new Set(['boss','jam','guard','pylon','cruiser','cpart','antenna','decoy','lock','mine','mite','shell','seeker','crate','twin','thief','leech','moth','hive','icecopy','hull','rustcopy','inventor','invcell','invcore','obheart','obseg']);

// ---------- переименования (сектора — в SECTORS_NEW) ----------
(function storyRename(){
  const R=(k,n)=>{if(EDEF[k])EDEF[k].name=n;};R('mirror','Отражение');R('thief','Сборщик');R('guard','Гвардия Стража');R('pylon','Предохранитель');R('boss','Страж-0');
  for(const k in STORY_LORE)if(EDEF[k])EDEF[k].lore=STORY_LORE[k];
  STORY_HULL.archive='VØID-013. Выкопан из обломка Инвентаризатора. Инвентарный номер, который никто не выдавал.';STORY_HULL.rime='VØID-014. Собран у Холодного ядра. Тонкий лёд на каркасе — держится, пока ты движешься.';
  for(const k in STORY_HULL)if(SKINS[k])SKINS[k].d=STORY_HULL[k];
  const M=MISSIONS;M[0].name='Пробуждение';M[5].name='Страж-0';M[5].sector='ЯДРО · ТОТ, КТО ПОМНИТ';M[7].name='Голоса ретрансляторов';
  for(let i=6;i<10;i++)M[i].sector=M[i].sector.replace('АКТ II','АКТ I');
  WORLD.hangar.name='ХРАНИЛИЩЕ КОРПУСОВ';
  const a3=WORLD.anomalies.find(a=>a.id==='a3');if(a3)a3.d=a3.d.replace('Похититель','Сборщик');
})();

// ---------- обломки: расстановка ----------
function storyObstacles(){const o=[...WORLD.nodes,...WORLD.shops,...WORLD.anomalies,...WORLD.caches,...WORLD.relays,WORLD.hangar,WORLD.arsenal,WORLD.abyss,WORLD.gate];
  for(const s of WORLD.sectors)if(s.bx)o.push({x:s.bx,y:s.by});return o;}
function segDistP(px,py,ax,ay,bx,by){const dx=bx-ax,dy=by-ay,L=dx*dx+dy*dy||1;let u=((px-ax)*dx+(py-ay)*dy)/L;u=u<0?0:u>1?1:u;return Math.hypot(px-ax-dx*u,py-ay-dy*u);}
function storyBuild(){
  WORLD.journals0=WORLD.journals.map(j=>({x:j.x,y:j.y}));const old={};for(const j of WORLD.journals)old[j.id]=j;
  const obs=storyObstacles(),N=WORLD.nodes,placed=[],warn=[];
  for(const j of Object.values(old))if(['j1','j2','j3','j5','j6','j8'].includes(j.id))placed.push(j);
  const lineOk=(x,y)=>{for(let i=0;i<N.length-1;i++)if(segDistP(x,y,N[i].x,N[i].y,N[i+1].x,N[i+1].y)<160)return false;return true;};
  const okAt=(x,y,k)=>obs.every(q=>Math.hypot(q.x-x,q.y-y)>350*k)&&placed.every(q=>Math.hypot(q.x-x,q.y-y)>250*k)&&lineOk(x,y)&&
    WORLD.fields2.every(f=>Math.hypot(f.x-x,f.y-y)>f.r*.6)&&(STORY_EXTRA_ZONES||[]).every(z=>Math.hypot(z.x-x,z.y-y)>500);
  const pick=(sec,R,fn,n)=>{const b=WORLD.sectors[sec].box;for(let pass=0;pass<3;pass++){const k=[1,.8,.6][pass];
      for(let i=0;i<400;i++){let x,y;if(fn){[x,y]=fn(R);}else{x=b[0]+400+R()*(b[2]-b[0]-800);y=b[1]+400+R()*(b[3]-b[1]-800);}
        if(x<b[0]+400||x>b[2]-400||y<b[1]+400||y>b[3]-400)continue;if(okAt(x,y,k))return [x,y];}
      warn.push('wreck '+n+' pass '+(pass+1));}
    return [(b[0]+b[2])/2,(b[1]+b[3])/2];};
  const out=[];
  for(const w of STORY_W){const [n,sec,skin,sign,text,text2]=w,oid=STORY_OLDID[n];
    let x,y;
    if(oid&&old[oid]&&sec<=1){x=old[oid].x;y=old[oid].y;if(oid==='j5'){x=5300;}}
    else{const R=mulberry(7000+sec*97+n*13),S_=WORLD.sectors[sec],b=S_.box;let fn=null;
      if(n===35)fn=R=>[b[2]-800+R()*400,b[1]+400+R()*(b[3]-b[1]-800)];
      if(n===42){const p35=out.find(q=>q.n===35);fn=R=>[b[0]+400+R()*400,clamp(p35.y+(R()-.5)*700,b[1]+400,b[3]-400)];}
      if(n===22){const n0=N.find(q=>q.m===S_.lv[0]);fn=R=>{const f=.35+R()*.3;return [S_.bx+(n0.x-S_.bx)*f+(R()-.5)*500,S_.by+(n0.y-S_.by)*f+(R()-.5)*500];};}
      if(n===63){const a=N[48],c=N[49];fn=R=>{const dx=c.x-a.x,dy=c.y-a.y,l=Math.hypot(dx,dy)||1,d=380+R()*300,s=(R()-.5)*600;return [c.x+dx/l*d-dy/l*s,c.y+dy/l*d+dx/l*s];};}
      [x,y]=pick(sec,R,fn,n);}
    const j={id:oid||('w'+n),n,sec,skin,sign,t1:text,t2:text2,x:Math.round(x),y:Math.round(y)};
    Object.defineProperty(j,'title',{get(){return wreckTitle(this);}});Object.defineProperty(j,'text',{get(){return wreckText(this);}});
    out.push(j);if(!(oid&&sec<=1))placed.push(j);}
  WORLD.journals=out;STORY_WARN.push(...warn);
}
const STORY_WARN=[];
// 3 трудные зоны с патрулями для фрагментов (сектора VIII, IX, X)
const STORY_EXTRA_ZONES=[];
(function storyZones(){[7,8,9].forEach((sec,k)=>{const sc=WORLD.sectors[sec],f=WORLD.fields2.filter(q=>q.x>=sc.box[0]&&q.x<=sc.box[2]).find(q=>WORLD.nodes.every(n=>Math.hypot(n.x-q.x,n.y-q.y)>600))
    ||{x:(sc.box[0]+sc.box[2])/2,y:sc.box[1]+900};
  const z={x:Math.round(f.x),y:Math.round(f.y),req:10,set:[{hunter:1,gunner:3,scout:3},{mirror:1,phantom:2,gunner:2,scout:2},{shocker:2,hunter:1,rammer:2,scout:2}][k],story:1};
  STORY_EXTRA_ZONES.push(z);WORLD.zones.push(z);});})();
function cycN(){return (G.save&&G.save.cycle)||1;}
function wreckTitle(j){if(j.sign==='@next')return 'VØID-013 · ЦИКЛ '+roman(cycN()+1);return j.sign;}
function wreckText(j){const c=cycN();let t=c>1&&j.t2?j.t2:j.t1;
  if(t==='@obod')t='Клиент 013. Посещений: '+fmtN(4102+c*37)+'. Износ всё так же 12%.';
  else if(t==='@s19')t='Мы помним предыдущие прохождения. Их '+fmtN(1903+c)+'. Он — нет.';
  else if(t==='@s11')t='Объект 013 снова у границы. Попытка № '+fmtN(1903+c)+'. Не дайте ему вспомнить.';
  else if(t==='@op')t='Удержали двенадцать систем. Вторую колонку нам по-прежнему не показывают. Цикл '+roman(c)+'.';
  return t;}
storyBuild();

// ---------- фрагменты ----------
const STORY_FRAGS=[];
(function fragBuild(){const N=WORLD.nodes;
  [14,22,31,38,42,46].forEach(m=>{const c=N[m-1],a=N[m-2],b=N[m]||c,dx=b.x-a.x,dy=b.y-a.y,l=Math.hypot(dx,dy)||1;let x=c.x-dy/l*260,y=c.y+dx/l*260;
    const box=WORLD.sectors[c.sec].box;if(y<box[1]+350||y>box[3]-350){x=c.x+dy/l*260;y=c.y-dx/l*260;}
    STORY_FRAGS.push({id:'fb'+m,kind:'boss',m,x:Math.round(x),y:Math.round(y)});});
  [5,6,7,8,9,10].forEach(sec=>{const b=WORLD.sectors[sec].box;let best=null,bs=-1;
    for(const s of riftEdges()){const mx=(s[0]+s[2])/2,my=(s[1]+s[3])/2;if(mx<b[0]-1||mx>b[2]+1||my<b[1]-1||my>b[3]+1)continue;
      const ox=mx+s[4]*900,oy=my+s[5]*900;if(ox<300||oy<300||ox>WW-300||oy>WH-300||inSectors(ox,oy))continue;
      let dmin=1e9;WORLD.sectors.forEach((o,i)=>{if(i===sec)return;const q=o.box,dx=Math.max(q[0]-ox,0,ox-q[2]),dy=Math.max(q[1]-oy,0,oy-q[3]);dmin=Math.min(dmin,Math.hypot(dx,dy));});
      const sc=dmin+Math.abs(((s[0]+s[2])/2-(b[0]+b[2])/2))*0+((s[1]===s[3])?200:0);if(sc>bs){bs=sc;best={ex:mx,ey:my,nx:s[4],ny:s[5]};}}
    if(best)STORY_FRAGS.push({id:'fr'+(sec+1),kind:'rift',sec,...best});});
  STORY_EXTRA_ZONES.forEach((z,k)=>STORY_FRAGS.push({id:'fh'+(k+8),kind:'hard',x:z.x,y:z.y}));})();
function fragCount(){const S=G.save;return S&&S.story?Object.keys(S.story.frags).length:0;}
function riftShift(){return Math.min(FRAG_SHIFT_MAX,FRAG_SHIFT*fragCount());}
function fragPos(f){if(f.kind!=='rift')return f;const off=Math.max(140,520-riftShift());return {x:f.ex+f.nx*off,y:f.ey+f.ny*off};}
function fragAvail(f){const S=G.save;if(!S||!S.story||S.story.frags[f.id])return false;if(f.kind==='boss')return !!(S.medals[f.m]&&S.medals[f.m].clear);return true;}

// ---------- сохранение ----------
function storyInit(S){if(!S)return S;const s=S.story||(S.story={});
  if(s.absorbed===undefined)s.absorbed=(S.lom||0)+(S.carry||0);
  for(const k of ['spared','fleeKilled','wardenMeets'])s[k]=s[k]||0;
  s.frags=s.frags||{};s.riftWrecks=s.riftWrecks||[];s.seen=s.seen||{};s.secSeen=s.secSeen||{};s.history=s.history||[];
  s.cyc=s.cyc||{absorbed:0,spared:0,fleeKilled:0,deaths:0,riftDeaths:0,warden:0};s.shopN=s.shopN||0;
  // журналы: оставить только существующие id
  if(S.journals){for(const k in S.journals)if(!WORLD.journals.some(j=>j.id===k))delete S.journals[k];}
  if(Array.isArray(S.jOrder))S.jOrder=S.jOrder.filter(k=>WORLD.journals.some(j=>j.id===k));
  return S;}
function storyTick(){const S=G.save;if(!S||!S.story)return;const tot=(S.lom||0)+(S.carry||0)+(S.lost?S.lost.v:0);
  if(G.lomPrev===undefined||G.lomPrevSave!==S){G.lomPrev=tot;G.lomPrevSave=S;return;}
  if(tot>G.lomPrev){const d=tot-G.lomPrev;S.story.absorbed+=d;S.story.cyc.absorbed+=d;}G.lomPrev=tot;}
function erosion(){const S=G.save;return S&&S.story?Math.min(1,S.story.absorbed/EROSION_FULL):0;}

// ---------- радио ----------
function radioEl(){return document.getElementById('radio');}
function radioClear(){const el=radioEl();if(el){el.hidden=true;el.classList.remove('rift');}if(G.radio)G.radio.cur=null;}
function radioState(){return G.radio||(G.radio={t:20,cur:null,q:[],n:0});}
function radioCond(c){const S=G.save;if(!c)return true;
  if(c==='force')return false;if(c==='cyc2')return cycN()>1;if(c==='cyc3')return cycN()>2;if(c==='eros')return erosion()>=.2;
  if(c==='invcold')return storyFlag('inv14')==='cold';if(c==='invmem')return storyFlag('inv14')==='memory';if(c==='obscrap')return storyFlag('obod18')==='scrap';if(c==='observ')return storyFlag('obod18')==='service';
  if(c==='rwreck')return !!(S&&S.story&&S.story.riftWrecks.length);if(c==='dead33')return storyFlag('save33')==='dead';if(c==='unborn33')return storyFlag('save33')==='unborn';if(c==='keep22')return storyFlag('cradle22')==='keep';if(c==='engine27')return storyFlag('fleet27')==='engine';if(c==='teo')return storyFlag('teo')===1;if(c==='m4')return G.m>=4;if(c==='m7')return G.m>=7;return true;}
function radioPick(g){const S=G.save,R=RADIO[g];if(!R||!S||!S.story)return null;if(g==='П'&&S.story.inv14==='cold')return null;const seen=S.story.seen;
  const av=R.l.map((q,i)=>({q,i})).filter(o=>!seen[g+(o.i+1)]&&radioCond(o.q.c));if(!av.length)return null;const o=av[Math.floor(Math.random()*av.length)];return {g,i:o.i};}
function radioSay(g,i){const S=G.save;if(!S||!S.story||!SET.radio||STORY_OFF.radio)return;const R=RADIO[g],q=R.l[i];if(!q)return;S.story.seen[g+(i+1)]=1;
  const st=radioState();st.cur={g,txt:q.t,tag:R.tag,col:R.col,rift:!!R.rift,t:0,len:q.t.length};st.n++;
  const el=radioEl();if(!el)return;el.hidden=false;el.style.opacity='1';el.style.borderColor=R.col;el.classList.toggle('rift',!!R.rift);
  el.querySelector('.rtag').textContent='ПЕРЕХВАТ · '+R.tag;el.querySelector('.rtag').style.color=R.col;el.querySelector('.rtxt').textContent='';
  if(AU.ctx&&SET.sfx){try{const c=AU.ctx,t=c.currentTime,n=c.createBufferSource(),b=c.createBuffer(1,c.sampleRate*.25,c.sampleRate),d=b.getChannelData(0);for(let k=0;k<d.length;k++)d[k]=(Math.random()*2-1)*(1-k/d.length);
    n.buffer=b;const f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=1600;f.Q.value=1.5;const gg=c.createGain();gg.gain.value=.05;n.connect(f);f.connect(gg);gg.connect(AU.sfx);n.start(t);}catch(e){}}}
function radioForce(g,i,delay){const st=radioState();st.q.push({g,i,d:delay||0});}
function radioCtxGroups(sec,rift){if(rift)return [['Е',1]];
  if(!RADIO_SEC[sec])return [['Г',.7],['З',.3]];const gs=[[RADIO_SEC[sec],.5],['В',.2],['З',.15]];if(sec>=7)gs.push(['Д',.15]);if(sec<=3)gs.push(['Г',.15]);return gs;}
function radioTick(dt,mode){if(STORY_OFF.radio)return;try{
  const st=radioState(),el=radioEl(),S=G.save;if(!S||!S.story)return;
  // показ текущей
  if(st.cur){const c=st.cur;c.t+=dt;const n=Math.min(c.len,Math.floor(c.t/.03));
    if(el&&n!==c.shown){c.shown=n;let s=c.txt.slice(0,n);if(c.rift)s=s.replace(/[^\s]/g,ch=>Math.random()<.08?'▒':ch);el.querySelector('.rtxt').textContent=s;}
    const end=c.len*.03+4;if(c.t>end&&el)el.style.opacity=String(Math.max(0,1-(c.t-end)/.5));if(c.t>end+.5){radioClear();}return;}
  // принудительные
  for(const q of st.q)q.d-=dt;const qi=st.q.findIndex(q=>q.d<=0);if(qi>=0){const q=st.q.splice(qi,1)[0];if(q.txt){radioSayTxt(q);return;}if(q.i<0){const p=radioPick(q.g);if(p)radioSay(p.g,p.i);}else radioSay(q.g,q.i);return;}
  st.t-=dt;if(st.t>0)return;
  if(mode==='mission'){const mg=G.m<=10?'А':RADIO_SEC[secOfLevel(G.m)];if(!mg||G.mode!=='world'){st.t=999;return;}
    if((G.boss&&G.boss.alive)||(G.jam&&G.jam.alive)||G.sb||(G.m===1&&G.mT<30)||st.mN>=3){st.t=5;return;}
    const p=radioPick(mg);if(p&&!(mg==='А'&&p.i===3)){radioSay(mg,p.i);st.mN=(st.mN||0)+1;}st.t=45+Math.random()*25;return;}
  // мир
  const p=G.player,rift=(G.riftI||0)>=.35;
  if(G.anom||G.deadT>0||G.enemies.some(e=>e.alive&&e.type!=='mine'&&e.type!=='lock'&&Math.hypot(e.x-p.x,e.y-p.y)<900)){st.t=4;return;}
  const sec=sectorIdx(p.x,p.y),gs=radioCtxGroups(sec,rift);let r=Math.random()*gs.reduce((a,b)=>a+b[1],0),g=gs[0][0];for(const [k,w] of gs){r-=w;if(r<=0){g=k;break;}}
  const pk=radioPick(g)||gs.map(x=>radioPick(x[0])).find(Boolean);if(pk)radioSay(pk.g,pk.i);
  st.t=rift?9+Math.random()*5:sec<=1?70+Math.random()*30:sec<=5?50+Math.random()*20:25+Math.random()*15;
 }catch(err){STORY_OFF.radio=1;console.error(err);radioClear();}}
function radioWorldEnter(){const S=G.save,p=G.player;if(!S||!S.story||!p)return;const sec=sectorIdx(p.x,p.y);
  if(RADIO_SEC[sec]&&!S.story.secSeen[sec]){S.story.secSeen[sec]=1;radioForce(RADIO_SEC[sec],-1,8);}}

// ---------- пробуждение ----------
function prologueStart(long){const el=document.getElementById('wake');if(!el)return;G.prologue={t:0,len:long?5:1.2,long,hb:0};el.hidden=false;
  el.querySelector('.wtxt').textContent='';el.querySelector('.wmsg').textContent='';el.querySelector('.wbot').textContent='';radioClear();
  if(G.save&&G.save.story)G.save.story.prologue=1;}
function prologueEnd(){const el=document.getElementById('wake');if(el)el.hidden=true;cv.style.filter='';const hd=document.getElementById('hud');if(hd)hd.style.opacity='';
  G.prologue=null;G.wakeI=0;for(const k in KEYS)KEYS[k]=false;if(typeof MOUSE!=='undefined')MOUSE.down=false;}
function prologueSkip(){const P=G.prologue;if(P&&P.t<P.len-.3)P.t=P.len-.3;}
function thump(f,v,at){if(!AU.ctx||!SET.sfx)return;try{const c=AU.ctx,t=c.currentTime+(at||0),o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(f*.6,t+.25);
  g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+.02);g.gain.exponentialRampToValueAtTime(.0001,t+.3);o.connect(g);g.connect(AU.sfx);o.start(t);o.stop(t+.35);}catch(e){}}
function prologueTick(dt){const P=G.prologue;if(!P)return;P.t+=dt;const t=P.t,el=document.getElementById('wake');if(!el){prologueEnd();return;}
  const lin=(a,b,x)=>clamp((x-a)/(b-a),0,1),ease=x=>1-Math.pow(1-x,3);let o,blur,br;
  const S=G.save,c=cycN(),mem=c<=1?'ПАМЯТЬ: ПОВРЕЖДЕНА':c===2?'ПАМЯТЬ: ПОВРЕЖДЕНА ПОВТОРНО':c===3?'ПАМЯТЬ: СТЁРТА НАРОЧНО':'ПАМЯТЬ: НЕ ВАША';
  const T=el.querySelector('.wtxt'),Mg=el.querySelector('.wmsg'),B=el.querySelector('.wbot');
  if(P.long){
    o=t<.8?0:t<1.2?.3*lin(.8,1.2,t):t<1.45?.3*(1-lin(1.2,1.45,t)):t<2?.6*lin(1.45,2,t):t<2.6?.6:t<3.8?.6+.4*ease(lin(2.6,3.8,t)):1;
    blur=t<2.6?18:18*(1-ease(lin(2.6,3.8,t)));br=t<2.6?.55:.55+.45*lin(2.6,3.8,t);
    const s1='ВОССТАНОВЛЕНИЕ СОЗНАНИЯ…';T.textContent=t<2?s1.slice(0,Math.floor(lin(0,.7,t)*s1.length))+(t>.8?'\nV∅ID-013 · '+mem:''):'';
    Mg.textContent=t>=2&&t<2.35?'НЕ ДАЙТЕ ЕМУ ВСПОМНИТЬ':t>=2.35&&t<2.6?'ПЕРЕДАЧА ОБОРВАНА':'';G.wakeI=t>=2&&t<2.6?.8:0;
    B.textContent=t>3.8?'КООРДИНАТЫ ПРИНЯТЫ · ИСТОЧНИК: Н.':'';
    const hd=document.getElementById('hud');if(hd)hd.style.opacity=t<3.8?'0':String(Math.min(1,(t-3.8)/1)*(Math.sin(t*40)>-.3?1:.3));
    if(P.hb===0&&t>.05){P.hb=1;thump(55,.5);thump(52,.45,.38);}if(P.hb===1&&t>1){P.hb=2;thump(60,.4);thump(58,.35,.3);}if(P.hb===2&&t>2.6){P.hb=3;thump(180,.08);}}
  else{o=t<.3?0:t<.55?.3*lin(.3,.55,t):t<.7?.3*(1-lin(.55,.7,t)):ease(lin(.7,1.2,t));blur=10*(1-lin(.6,1.2,t));br=.6+.4*lin(.5,1.2,t);T.textContent='';Mg.textContent='';B.textContent='';}
  el.querySelector('.lid.t').style.transform=`translateY(${-o*100}%)`;el.querySelector('.lid.b').style.transform=`translateY(${o*100}%)`;
  cv.style.filter=SET.fx&&blur>.2?`blur(${blur.toFixed(1)}px) brightness(${br.toFixed(2)})`:`brightness(${br.toFixed(2)})`;
  if(t>=P.len)prologueEnd();}

// ---------- смерть ----------
function memoFlash(txt){const el=document.getElementById('memo');if(!el)return;el.textContent=txt;el.classList.remove('on');void el.offsetWidth;el.classList.add('on');}
function storyDeath(rift){const S=G.save;if(!S||!S.story||G.mode!=='world')return;S.story.cyc.deaths++;if(rift){S.story.cyc.riftDeaths++;const p=G.player;
    S.story.riftWrecks.push({x:Math.round(p.x),y:Math.round(p.y),skin:curSkin(),c:cycN(),id:Date.now()%1e9});while(S.story.riftWrecks.length>12)S.story.riftWrecks.shift();}
  memoFlash(rift?'ВОСПОМИНАНИЕ ИЗЪЯТО':'ВОСПОМИНАНИЕ НЕ СОХРАНЕНО');}

// ---------- отступающие ----------
function storyRetreatRoll(e){if(e.rolledR||e.retreat||e.hp<=0||e.hp>e.maxHp*.35)return;e.rolledR=true;
  if(STORY_OFF.flee||G.mode!=='world'||G.world||G.m<3||STORY_NORETREAT.has(e.type)||STATIC.has(e.type)||e.elite||e.zone)return;
  if((G.retreatN||0)>=2||G.enemies.some(o=>o.alive&&o.retreat))return;if(Math.random()>=.07)return;storyRetreat(e);}
function storyRetreat(e){e.retreat=true;e.retreatT=0;e.contact=0;e.charging=false;G.retreatN=(G.retreatN||0)+1;prioClear(e);
  floater(e.x,e.y-26,'ОТСТУПАЕТ','#dfe8ff');if(Math.random()<.5){const p=radioPick('Ж');if(p&&p.i!==6)radioSay('Ж',p.i);}}
function storyRetreatMove(e,dt){e.retreatT+=dt;const tx=e.x<W/2?-240:W+240,ty=e.y+(e.y<H/2?-60:60);steer(e,tx-e.x,ty-e.y,e.spd*1.15+40,dt,3);e.x+=e.vx*dt;e.y+=e.vy*dt;
  if(SET.fx&&vR2()<.25)part(e.x,e.y,vrnd2(-40,40),vrnd2(-40,40),.4,'#dfe8ff',1.5);
  if(e.x<-70||e.x>W+70||e.y<-70||e.y>H+70||e.retreatT>8)storySpare(e);}
function storySpare(e){e.alive=false;e.spared=true;const S=G.save;if(S&&S.story){S.story.spared++;S.story.cyc.spared++;}
  floater(clamp(e.x,30,W-30),clamp(e.y,30,H-30),'ОТПУЩЕН','#dfe8ff');if(Math.random()<.4&&S&&S.story&&!S.story.seen['Ж7'])radioSay('Ж',6);}
function storyRetreatKilled(e){const S=G.save;if(e.retreat&&S&&S.story){S.story.fleeKilled++;S.story.cyc.fleeKilled++;}}

// ---------- Страж ----------
function storyWarden(){const S=G.save;if(G.mode!=='world'||!S||!S.story)return;S.story.wardenMeets++;S.story.cyc.warden++;
  if(G.mode==='world'&&!G.world&&G.m===6){banner('СТРАЖ-0 ПРОБУЖДАЕТСЯ',STORY_WARDEN[Math.min(3,cycN()-1)].toUpperCase());}}
function storyEchoLine(){const S=G.save;if(!S||!S.story)return null;S.story.wardenMeets++;const n=S.story.wardenMeets;
  return n<=1?'ТЫ ЗДЕСЬ ВПЕРВЫЕ. ТАК ТЫ ДУМАЕШЬ.':n<=4?'ВСТРЕЧА '+n+'. ТЫ СНОВА НЕ ПОМНИШЬ.':n+'. Я ПЕРЕСТАЛ СЧИТАТЬ. НЕТ — НЕ ПЕРЕСТАЛ.';}

// ---------- мастерская ----------
function shopLine(){const S=G.save;if(!S||!S.story)return '';const s=S.story;s.shopN++;
  const pool=STORY_SHOP.filter(q=>q.c==='first'?s.shopN===1:q.c==='bought'?!!s.bought:q.c==='cyc2'?cycN()>1:q.c==='cyc3'?cycN()>2:true);
  let q=pool[Math.floor(Math.random()*pool.length)];if(s.shopN===1)q=STORY_SHOP[0];if(q.t===s.lastShop&&pool.length>1)q=pool.find(x=>x.t!==q.t);s.lastShop=q.t;return q.t;}
function shopType(txt){const el=document.getElementById('shopBot');if(!el)return;clearInterval(G.shopTm);let i=0;el.textContent='';
  G.shopTm=setInterval(()=>{i++;el.textContent='АВТОМАТ: '+txt.slice(0,i);if(i>=txt.length)clearInterval(G.shopTm);},25);}

// ---------- сводка цикла ----------
function cycleReport(){const S=G.save,s=S.story,c=s.cyc,fr=Object.keys(s.frags).length;
  return {cyc:cycN(),missions:doneCount(),abs:Math.round(c.absorbed),spared:c.spared,fk:c.fleeKilled,read:journalIds().length,frags:fr,deaths:c.deaths,rd:c.riftDeaths,warden:c.warden,
    fin:fr<3?'ВОСПОМИНАНИЕ НЕ СОХРАНЕНО':'КОПИЯ ПЕРЕДАНА СЛЕДУЮЩЕЙ'};}
function reportHTML(r){return `<div class="rep">${[['Миссий пройдено',r.missions+'/'+NM],['Поглощено записей',fmtN(r.abs)],['Отпущено / добито отступавших',r.spared+' / '+r.fk],['Записей прочитано',r.read+'/63'],['Фрагментов памяти',r.frags+'/15'],['Смертей / из них в Разломе',r.deaths+' / '+r.rd],['Встреч со Стражем',r.warden]]
  .map(([k,v],i)=>`<div style="animation-delay:${i*.15}s"><span>${k}</span><b>${v}</b></div>`).join('')}</div><p class="repfin" style="animation-delay:1.2s">${r.fin}</p>`;}
function openReport(){const S=G.save;if(!S||!S.story)return newCycle();const r=cycleReport();S.story.history.push(r);while(S.story.history.length>10)S.story.history.shift();
  scr6('report');$('#repEyebrow').textContent='ОТЧЁТ ЭКСПЕДИЦИИ · V∅ID-013 · ЦИКЛ '+roman(r.cyc);$('#repBody').innerHTML=reportHTML(r);store(saveKey(),S);show('sReport');(touchMode||$('#bRepGo').focus());}
function storyNewCycle(S){const s=S.story;if(!s)return;s.seen={};s.secSeen={};s.frags={};s.riftWrecks=[];s.cyc={absorbed:0,spared:0,fleeKilled:0,deaths:0,riftDeaths:0,warden:0};}

// ---------- меню ----------
let menuGT=8;
function menuGlitch(dt){const el=document.querySelector('#sMenu .sub');if(!el)return;const S=G.save;
  if(!(S&&(S.cycle||1)>1)){if(el.dataset.g){el.textContent='ПОСЛЕДНИЙ СИГНАЛ';el.classList.remove('glt');delete el.dataset.g;}return;}
  menuGT-=dt;if(el.dataset.g){if(menuGT<=0){el.textContent='ПОСЛЕДНИЙ СИГНАЛ';el.classList.remove('glt');delete el.dataset.g;menuGT=9+Math.random()*7;}return;}
  if(menuGT<=0){el.dataset.g=1;el.textContent='НЕ ДАЙТЕ ЕМУ ВСПОМНИТЬ';el.classList.add('glt');menuGT=.18+Math.random()*.12;if(AU.ctx&&SET.sfx)thump(900,.03);}}
function menuGlitchOff(){const el=document.querySelector('#sMenu .sub');if(el&&el.dataset.g){el.textContent='ПОСЛЕДНИЙ СИГНАЛ';el.classList.remove('glt');delete el.dataset.g;}}

// ---------- мир: обломки, фрагменты, эрозия ----------
// ---------- 0.5.3: обломки — разбитые корпуса VØID и чужие корабли ----------
const HULL_NUM={base:'013',falcon:'004',manta:'006',prism:'009',reaper:'011',halo:'002',comet:'007',hornet:'005',obsidian:'010',sail:'003',pulsar:'012'};
const DMG_NAME=['','подбит','пробит','выгорел','разорван','стёрт'];
const SEC_DMG=[1,1,2,2,3,3,4,4,5,5,5];
// * — запись «в трюме» (автор не VØID), # — номер на борту стёрт
const WRECK_P={2:'base*',3:'base*',6:'base*',8:'base*',10:'base',14:'base*',16:'falcon*',18:'pulsar',19:'hornet',20:'prism',22:'base',30:'manta',31:'falcon',34:'obsidian',35:'reaper*',
  39:'sail',40:'prism',44:'base#',45:'reaper',47:'halo',48:'obsidian',51:'hornet',53:'comet',54:'base',55:'pulsar',56:'comet',57:'base#',59:'halo',60:'reaper',61:'sail',62:'manta',63:'base'};
const WRECK_O={1:['transport','','гражданский транспорт'],4:['station','buoy','пограничный буй'],5:['station','ring','сегмент кольца станции'],7:['barge','','архивная баржа'],9:['barge','guard','шасси Гвардии во льду'],
  11:['tug','','колониальный тягач'],12:['tug','robot','ремонтный автомат'],13:['shell','','раковина чужого вида'],15:['flagship','','флагман'],
  17:['blueprint','cruiser','чертёж крейсера'],21:['blueprint','liner','чертёж лайнера'],23:['blueprint','guard','чертёж Гвардии'],24:['blueprint','scout','чертёж исследовательского катера'],
  25:['cradle','frame','рама конвейера'],26:['cradle','guard','шасси Стража'],27:['cradle','shuttle','челнок'],28:['cradle','bureau','челнок бюро «Предел»'],29:['cradle','guardShot','шасси Гвардии · выстрел в ядро'],
  32:['cradle','guard','шасси Гвардии'],33:['cradle','stand','испытательный стенд'],
  36:['ark','drone','сервисный дрон'],37:['ark','console','пульт-модуль'],38:['ark','pod','капсула сохранения'],41:['ark','consoleP','личная капсула-пульт'],42:['ark','pod','капсула сохранения'],43:['ark','console','пульт-модуль'],
  46:['erased','transport','транспорт'],49:['erased','scout','исследовательский катер'],50:['erased','liner','лайнер'],52:['erased','tug','колониальный тягач'],58:['proto','','прототип-кольцо']};
const WCLS={transport:{sz:1.2,st:'лёгкое'},station:{sz:1.6,st:'разлом по стыку'},barge:{sz:1.8,st:'замёрзший'},tug:{sz:1.5,st:'коррозия'},shell:{sz:2,st:'расколотая скорлупа'},
  flagship:{sz:3.2,st:'тяжёлое боевое'},blueprint:{sz:1.8,st:'недостроен'},cradle:{sz:1.6,st:'разобран'},ark:{sz:1.4,st:'«выпит»'},erased:{sz:1.6,st:'стёрт'},proto:{sz:2.4,st:'осколки света'}};
const WSIZE={4:1.3,9:1.4,12:1.2,25:1.8,26:2,27:1.4,28:1.4,29:1.5,32:1.5,33:1.8,36:1.2,37:1.5,38:1.3,41:1.4,42:1.3,43:1.5,52:2};
function wreckSpec(j){if(j._spec)return j._spec;let s;
  if(j.rift)s={own:'player',skin:SKINS[j.skin]?j.skin:'base',hull:'013',dmg:5,rift:1,size:1};
  else if(WRECK_P[j.n]){const v=WRECK_P[j.n],skin=v.replace(/[*#]/g,'');s={own:'player',skin,hull:v.includes('#')?'':HULL_NUM[skin],hold:v.includes('*'),dmg:SEC_DMG[j.sec]||3,size:1};}
  else{const o=WRECK_O[j.n]||['transport','','обломок'];s={own:'other',cls:o[0],variant:o[1],nm:o[2],size:WSIZE[j.n]||WCLS[o[0]].sz,st:WCLS[o[0]].st};}
  try{Object.defineProperty(j,'_spec',{value:s,enumerable:false,configurable:true});}catch(e){}return s;}
function wreckR(j){const s=wreckSpec(j);return s.own==='player'?110:Math.min(200,110*s.size);}
function hullLine(j){const s=wreckSpec(j);
  if(s.own==='player'){const nm=SKINS[s.skin].name;if(!s.hull)return 'Корпус: VØID · номер стёрт · '+DMG_NAME[s.dmg];
    return (s.hold?'Найдено в трюме VØID-'+s.hull:'Корпус: VØID-'+s.hull)+' · '+nm+' · '+DMG_NAME[s.dmg];}
  return 'Обломок: '+s.nm+' · '+s.st;}

// --- рисунки чужих кораблей (единицы корабля игрока, нос по +x, радиус ≤ 24) ---
function wPoly(g,p){g.beginPath();g.moveTo(p[0][0],p[0][1]);for(let i=1;i<p.length;i++)g.lineTo(p[i][0],p[i][1]);g.closePath();}
function wFS(g,f,s,lw){g.fillStyle=f;g.fill();if(s){g.strokeStyle=s;g.lineWidth=lw||1.2;g.stroke();}}
const W_SHAPES={
  transport(g){g.fillStyle='#141a24';g.strokeStyle='#7a8ea5';g.lineWidth=1;g.fillRect(-19,-4,5,8);g.strokeRect(-19,-4,5,8);
    for(const y of [-12.5,5.5]){g.fillStyle='#232c3a';g.fillRect(-12,y,15,7);g.strokeStyle='#7a8ea5';g.strokeRect(-12,y,15,7);g.strokeStyle='#4a5a70';g.lineWidth=.8;g.beginPath();for(let i=1;i<4;i++){g.moveTo(-12+i*3.75,y);g.lineTo(-12+i*3.75,y+7);}g.stroke();g.lineWidth=1;}
    wPoly(g,[[-14,-5],[8,-5],[12,-3],[12,3],[8,5],[-14,5]]);wFS(g,'#1a2433','#9fb4c8',1.4);
    g.beginPath();g.arc(12,0,4.5,-1.4,1.4);g.closePath();wFS(g,'#2a4a60','#cfe6ff',1);
    g.fillStyle='#ffd23d';for(const [x,y] of [[-11,-11.5],[-11,11.5],[1.5,-11.5],[1.5,11.5]])g.fillRect(x-.9,y-.9,1.8,1.8);return {cock:[12,0]};},
  ring(g,R){const cx=-6;g.beginPath();g.arc(cx,0,22,-1.05,1.05);g.arc(cx,0,14,1.05,-1.05,true);g.closePath();wFS(g,'#1c2028','#dfe6ee',1.3);
    g.strokeStyle='#dfe6ee';g.lineWidth=1.6;g.beginPath();for(const a of [-.35,.35]){g.moveTo(cx+Math.cos(a)*14,Math.sin(a)*14);g.lineTo(cx+Math.cos(a)*22,Math.sin(a)*22);}g.stroke();
    for(let a=-.95;a<=.96;a+=.12){g.fillStyle=R()<.65?'#ffcf7a':'#3a4558';g.fillRect(cx+Math.cos(a)*18-.8,Math.sin(a)*18-.8,1.6,1.6);}
    return {light:[cx+Math.cos(-.75)*22,Math.sin(-.75)*22],ctr:[cx,0],joints:[-.35,.35]};},
  buoy(g){wPoly(g,[[-17,-3],[-12,-7],[-12,7],[-17,3]]);wFS(g,'#14181e','#9fb4c8',1);
    wPoly(g,[[-12,-5],[6,-5],[9,-3],[9,3],[6,5],[-12,5]]);wFS(g,'#1c2028','#dfe6ee',1.3);
    g.strokeStyle='rgba(255,184,77,.8)';g.lineWidth=1.5;g.beginPath();g.moveTo(-6,-5);g.lineTo(-6,5);g.moveTo(0,-5);g.lineTo(0,5);g.stroke();
    g.strokeStyle='#dfe6ee';g.lineWidth=1;g.beginPath();g.moveTo(9,0);g.lineTo(19,0);g.moveTo(19,-4);g.quadraticCurveTo(22,0,19,4);g.stroke();return {light:[19.5,0]};},
  barge(g){g.fillStyle='#10161e';g.fillRect(-24,-3.5,2.5,7);
    wPoly(g,[[-22,-6],[14,-6],[20,-2],[20,2],[14,6],[-22,6]]);wFS(g,'#141c26','#bfe0ff',1.2);
    g.strokeStyle='rgba(107,184,255,.7)';g.lineWidth=.7;for(let i=0;i<8;i++)for(const y of [-4.6,.6])g.strokeRect(-20.5+i*4.25,y,3.4,4);
    wPoly(g,[[12,-6],[15,-9.5],[19,-9.5],[17,-6]]);wFS(g,'#1a2430','#bfe0ff',1);return {};},
  guard(g){g.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;g.lineTo(Math.cos(a)*18,Math.sin(a)*18);}g.closePath();wFS(g,'#2a1a10','#ffb84d',1.8);
    g.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;g.lineTo(Math.cos(a)*9,Math.sin(a)*9);}g.closePath();g.strokeStyle='#ffb84d';g.lineWidth=1.2;g.stroke();
    g.strokeStyle='rgba(255,184,77,.45)';g.lineWidth=.8;g.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;g.moveTo(Math.cos(a)*9,Math.sin(a)*9);g.lineTo(Math.cos(a)*18,Math.sin(a)*18);}g.stroke();
    g.fillStyle='#ffb84d';g.beginPath();g.arc(0,0,3,0,TAU);g.fill();return {core:[0,0]};},
  tug(g){g.fillStyle='#1a120a';for(const y of [-7,3])g.fillRect(-18,y,4,4);
    wPoly(g,[[-14,-10],[4,-10],[4,10],[-14,10]]);wFS(g,'#24160c','#c96a2a',1.4);
    g.strokeStyle='rgba(201,106,42,.55)';g.lineWidth=.7;g.beginPath();g.moveTo(-8,-10);g.lineTo(-8,10);g.moveTo(-2,-10);g.lineTo(-2,10);g.moveTo(-14,0);g.lineTo(4,0);g.stroke();
    g.fillStyle='#e08a4a';for(let x=-13;x<4;x+=3)for(const y of [-9,9])g.fillRect(x-.4,y-.4,.8,.8);
    g.strokeStyle='#c96a2a';g.lineWidth=1.2;g.beginPath();g.moveTo(4,-6);g.lineTo(19,-6);g.moveTo(4,6);g.lineTo(19,6);for(let x=4;x<19;x+=3){g.moveTo(x,-6);g.lineTo(x+3,6);}g.stroke();
    g.fillStyle='#2e1c0e';g.fillRect(18,-8,3,16);g.strokeRect(18,-8,3,16);return {};},
  robot(g){g.strokeStyle='#c96a2a';g.lineWidth=1.6;g.beginPath();for(const s of [-1,1]){g.moveTo(7,s*5);g.lineTo(13,s*9);g.lineTo(19,s*6);g.moveTo(19,s*6);g.lineTo(21,s*8);g.moveTo(19,s*6);g.lineTo(21,s*4);}g.stroke();
    wPoly(g,[[-9,-8],[7,-8],[7,8],[-9,8]]);wFS(g,'#24160c','#c96a2a',1.4);
    g.fillStyle='#1a120a';g.fillRect(-13,-9,4,18);g.strokeRect(-13,-9,4,18);
    g.fillStyle='#ffb84d';g.beginPath();g.arc(3,0,2,0,TAU);g.fill();g.fillStyle='#e08a4a';for(const [x,y] of [[-7,-6],[5,-6],[-7,6],[5,6]])g.fillRect(x-.5,y-.5,1,1);return {};},
  shell(g){const P=[];for(let th=0;th<=11.3;th+=.14){const r=2.2*Math.exp(.205*th);P.push([r*Math.cos(th),r*Math.sin(th)]);}
    wPoly(g,P);const gr=g.createRadialGradient(0,0,1,0,0,22);gr.addColorStop(0,'#3a2a3a');gr.addColorStop(1,'#1e1622');g.fillStyle=gr;g.fill();
    g.strokeStyle='#f0d8e8';g.lineWidth=1.1;g.beginPath();P.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.stroke();
    g.strokeStyle='rgba(201,166,200,.6)';g.lineWidth=.7;g.beginPath();for(let th=6.3;th<=11.3;th+=.5){const r1=2.2*Math.exp(.205*(th-TAU)),r2=2.2*Math.exp(.205*th);g.moveTo(r1*Math.cos(th),r1*Math.sin(th));g.lineTo(r2*Math.cos(th),r2*Math.sin(th));}g.stroke();return {ctr:[0,0]};},
  cruiser(g){g.fillStyle='#3a4558';for(const y of [-6,-1,4])g.fillRect(-23.5,y,2.5,2);
    wPoly(g,[[22,0],[8,-6],[-6,-11],[-18,-10],[-21,-5],[-21,5],[-18,10],[-6,11],[8,6]]);wFS(g,'#10151c','#8a9ab0',1);
    g.strokeStyle='rgba(138,154,176,.5)';g.lineWidth=.6;g.beginPath();g.moveTo(18,0);g.lineTo(-18,0);g.moveTo(-6,-11);g.lineTo(-6,11);g.stroke();
    g.fillStyle='#1a222c';g.fillRect(-13,-3,7,6);g.strokeStyle='#8a9ab0';g.lineWidth=.8;g.strokeRect(-13,-3,7,6);
    for(const [x,y] of [[8,0],[-1,-5.5],[-1,5.5]]){g.beginPath();g.arc(x,y,2.1,0,TAU);wFS(g,'#202a36','#a8b8cc',.7);g.beginPath();g.moveTo(x+1.5,y);g.lineTo(x+5,y);g.stroke();}
    g.strokeStyle='#ff4f6e';g.lineWidth=1.1;g.beginPath();g.moveTo(-17,-8.7);g.lineTo(-10,-9.6);g.moveTo(-17,8.7);g.lineTo(-10,9.6);g.moveTo(14,-2.3);g.lineTo(17,-1.2);g.stroke();return {};},
  liner(g){for(const s of [-1,1]){wPoly(g,[[-14,s*5],[-20,s*10],[-22,s*9],[-19,s*4]]);wFS(g,'#141a22','#9fb4c8',.9);}
    wPoly(g,[[18,0],[14,-5],[-16,-5],[-20,-3],[-20,3],[-16,5],[14,5]]);wFS(g,'#161c26','#dfe6ee',1.2);
    g.fillStyle='#ffe6a3';for(let x=-14;x<12;x+=2.6)for(const y of [-2.5,2.5])g.fillRect(x,y-.5,1.3,1);return {};},
  scout(g){wPoly(g,[[20,0],[4,-4],[-12,-5],[-16,-9],[-18,-8],[-15,-3],[-18,0],[-15,3],[-18,8],[-16,9],[-12,5],[4,4]]);wFS(g,'#141a24','#cfe6ff',1.2);
    g.strokeStyle='#cfe6ff';g.lineWidth=.8;g.beginPath();g.moveTo(-4,-4.5);g.lineTo(-8,-12);g.stroke();g.fillStyle='#8fe9ff';g.beginPath();g.arc(9,0,1.8,0,TAU);g.fill();return {};},
  frame(g){g.strokeStyle='#ffb84d';g.lineWidth=2;g.beginPath();g.moveTo(-22,-12);g.lineTo(22,-12);g.moveTo(-22,12);g.lineTo(22,12);g.stroke();
    g.lineWidth=.9;g.strokeStyle='rgba(255,184,77,.6)';g.beginPath();for(let x=-20;x<=20;x+=5){g.moveTo(x,-12);g.lineTo(x,12);}g.stroke();
    g.beginPath();for(let i=0;i<=4;i++){const a=i/6*TAU-1;g.lineTo(Math.cos(a)*9,Math.sin(a)*9);}g.strokeStyle='#ffd27a';g.lineWidth=1.4;g.stroke();
    g.fillStyle='#ffb84d';for(const x of [-14,14])for(const y of [-12,12])g.fillRect(x-1.5,y-2,3,4);return {};},
  stand(g){g.strokeStyle='#dfe6ee';g.lineWidth=1.3;g.strokeRect(-15,-13,30,26);g.lineWidth=.7;g.beginPath();g.moveTo(-15,-13);g.lineTo(15,13);g.moveTo(15,-13);g.lineTo(-15,13);g.stroke();
    g.beginPath();g.ellipse(0,0,8,4.5,0,0,TAU);wFS(g,'#e8eef4','#ffffff',1);g.fillStyle='#ffb84d';for(const s of [-1,1])g.fillRect(s*8-1,-1.5,2,3);return {};},
  shuttle(g,R,o){wPoly(g,[[18,0],[12,-4],[-14,-4],[-17,-2],[-17,2],[-14,4],[12,4]]);wFS(g,'#161c24','#dfe6ee',1.2);
    const lab=o&&o.bureau;wPoly(g,[[-10,-4],[-10,-9],[3,-9],[5,-4]]);wFS(g,lab?'#e8eef4':'#20262e',lab?'#ffffff':'#9fb4c8',1);
    g.fillStyle=lab?'#6bb8ff':'#8fe9ff';for(let x=-8;x<2;x+=3)g.fillRect(x,-7.5,1.6,1.6);
    if(lab){g.fillStyle='#ffb84d';g.beginPath();g.moveTo(8,-1.5);g.lineTo(11,0);g.lineTo(8,1.5);g.fill();}return {};},
  drone(g){g.strokeStyle='#ffd27a';g.lineWidth=1.3;g.beginPath();for(const [x,y] of [[10,10],[10,-10],[-10,10],[-10,-10]]){g.moveTo(0,0);g.lineTo(x,y);}g.stroke();
    for(const [x,y] of [[10,10],[10,-10],[-10,10],[-10,-10]]){g.beginPath();g.arc(x,y,4,0,TAU);g.strokeStyle='rgba(255,210,122,.7)';g.lineWidth=1;g.stroke();}
    g.beginPath();g.arc(0,0,6.5,0,TAU);wFS(g,'#1e1a10','#ffd27a',1.3);g.beginPath();g.arc(1.5,0,2.8,0,TAU);wFS(g,'#4a3a1a','#fff2c9',.8);return {win:[1.5,0,2.8]};},
  console(g){wPoly(g,[[-12,-8],[12,-8],[12,8],[-12,8]]);wFS(g,'#1e1a10','#ffd27a',1.3);
    g.fillStyle='#4a3a1a';g.fillRect(-8,-6,16,5);g.strokeStyle='#fff2c9';g.lineWidth=.7;g.strokeRect(-8,-6,16,5);
    for(let i=0;i<6;i++)for(let r=0;r<2;r++){g.fillStyle=(i+r)%3?'#3a3020':'#ffe6a3';g.fillRect(-10+i*3.6,1+r*3,2.4,2);}return {win:[0,-3.5,6]};},
  consoleP(g){wPoly(g,[[-21,-6],[-9,-6],[-9,6],[-21,6]]);wFS(g,'#1e1a10','#ffd27a',1.1);
    for(let i=0;i<3;i++){g.fillStyle=i%2?'#3a3020':'#ffe6a3';g.fillRect(-19+i*3.4,2,2.2,2);}
    g.beginPath();g.ellipse(4,0,13,7,0,0,TAU);wFS(g,'#1e1a10','#ffd27a',1.3);g.beginPath();g.ellipse(4,0,7.5,3.8,0,0,TAU);wFS(g,'#4a3a1a','#fff2c9',.9);return {win:[4,0,7]};},
  pod(g){g.fillStyle='#2a2414';for(const s of [-1,1])g.fillRect(s*16-(s>0?0:3),-3,3,6);
    g.beginPath();g.ellipse(0,0,16,8,0,0,TAU);wFS(g,'#1e1a10','#ffd27a',1.3);g.beginPath();g.ellipse(0,0,9,4.5,0,0,TAU);wFS(g,'#4a3a1a','#fff2c9',.9);
    g.strokeStyle='rgba(255,210,122,.5)';g.lineWidth=.6;g.beginPath();g.moveTo(-12,-5);g.lineTo(-12,5);g.moveTo(12,-5);g.lineTo(12,5);g.stroke();return {win:[0,0,8]};}
};
function wShapeKey(s){const v=s.variant;
  if(s.cls==='station')return v==='buoy'?'buoy':'ring';if(s.cls==='barge')return v==='guard'?'guard':'barge';if(s.cls==='tug')return v==='robot'?'robot':'tug';
  if(s.cls==='flagship')return 'cruiser';if(s.cls==='blueprint'||s.cls==='erased')return v||'transport';
  if(s.cls==='cradle')return v==='guardShot'?'guard':v==='bureau'?'shuttle':v;if(s.cls==='ark')return v;return s.cls;}

// --- примитивы повреждений (координаты холста, px) ---
function wkCv(w,h,rd){const c=document.createElement('canvas');c.width=Math.max(1,w);c.height=Math.max(1,h||w);c._g=c.getContext('2d',rd?{willReadFrequently:true}:undefined);return c;}
function wkScan(g,S){const im=g.getImageData(0,0,S,S),d=im.data,pts=[],edge=[];let x0=S,y0=S,x1=0,y1=0,cnt=0;
  for(let y=0;y<S;y++)for(let x=0;x<S;x++){if(d[(y*S+x)*4+3]>24){cnt++;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}}
  for(let y=3;y<S-3;y+=3)for(let x=3;x<S-3;x+=3){const a=d[(y*S+x)*4+3];if(a<90)continue;pts.push([x,y]);
    if(d[(y*S+x-3)*4+3]<20||d[(y*S+x+3)*4+3]<20||d[((y-3)*S+x)*4+3]<20||d[((y+3)*S+x)*4+3]<20)edge.push([x,y]);}
  return {pts,edge,bb:cnt?[x0,y0,x1+1,y1+1]:[0,0,1,1],cnt,im};}
const wkPick=(a,R)=>a.length?a[Math.floor(R()*a.length)]:[0,0];
const wkRng=(R,a,b)=>a+R()*(b-a);
const wkInt=(R,v)=>Array.isArray(v)?v[0]+Math.floor(R()*(v[1]-v[0]+1)):(v||0);
function wkDark(g,S,a,col){g.globalCompositeOperation='source-atop';g.fillStyle=col||`rgba(4,6,12,${a})`;g.fillRect(0,0,S,S);g.globalCompositeOperation='source-over';}
function wkDarkIn(g,base,S,a,er){const m=wkCv(S);m._g.drawImage(base,0,0);const e=wkCv(S),r=e._g;r.drawImage(base,0,0);r.globalCompositeOperation='destination-in';
  for(const [dx,dy] of [[er,0],[-er,0],[0,er],[0,-er]])r.drawImage(m,dx,dy);r.globalCompositeOperation='source-in';r.fillStyle=`rgba(4,6,12,${a})`;r.fillRect(0,0,S,S);g.drawImage(e,0,0);}
function wkBurns(g,sc,R,n,r0,r1){g.globalCompositeOperation='source-atop';for(let i=0;i<n;i++){const [x,y]=wkPick(sc.pts,R),r=wkRng(R,r0,r1),gr=g.createRadialGradient(x,y,0,x,y,r);
  gr.addColorStop(0,'rgba(0,0,0,.9)');gr.addColorStop(.6,'rgba(10,6,4,.5)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2);}g.globalCompositeOperation='source-over';}
function wkJag(R,x,y,r,n){const p=[];for(let i=0;i<n;i++){const a=i/n*TAU,q=r*(.55+R()*.6);p.push([x+Math.cos(a)*q,y+Math.sin(a)*q]);}return p;}
function wkHoles(g,sc,R,n,r0,r1,rim,rimW){const hs=[];for(let i=0;i<n;i++){const [x,y]=wkPick(sc.pts,R),p=wkJag(R,x,y,wkRng(R,r0,r1),7+Math.floor(R()*4));hs.push(p);
    g.globalCompositeOperation='destination-out';wPoly(g,p);g.fillStyle='#000';g.fill();
    if(rim){g.globalCompositeOperation='source-atop';wPoly(g,p);g.strokeStyle=rim;g.lineWidth=rimW||2;g.stroke();}}
  g.globalCompositeOperation='source-over';return hs;}
function wkCracks(g,sc,R,n,col,lw,len,blur){g.globalCompositeOperation=col?'source-atop':'destination-out';g.strokeStyle=col||'#000';g.lineCap='round';
  if(blur&&col){g.shadowColor=col;g.shadowBlur=blur;}
  for(let i=0;i<n;i++){let [x,y]=wkPick(sc.pts,R),a=R()*TAU;const L=wkRng(R,len*.5,len);g.lineWidth=lw*(.7+R()*.6);g.beginPath();g.moveTo(x,y);
    for(let s=0;s<5;s++){a+=(R()-.5)*1.1;x+=Math.cos(a)*L/5;y+=Math.sin(a)*L/5;g.lineTo(x,y);
      if(R()<.25){const b=a+(R()<.5?1:-1)*(.6+R()*.6);g.lineTo(x+Math.cos(b)*L/6,y+Math.sin(b)*L/6);g.moveTo(x,y);}}g.stroke();}
  g.shadowBlur=0;g.globalCompositeOperation='source-over';}
function wkGrid(g,base,sc,R,n,r0,r1){const S=base.width,mask=wkCv(S);mask._g.drawImage(base,0,0);
  for(let i=0;i<n;i++){const [x,y]=wkPick(sc.pts,R),r=wkRng(R,r0,r1);
    g.globalCompositeOperation='destination-out';g.beginPath();g.arc(x,y,r,0,TAU);g.fillStyle='#000';g.fill();
    const t=wkCv(S),q=t._g;q.save();q.beginPath();q.arc(x,y,r,0,TAU);q.clip();q.strokeStyle='#4a5870';q.lineWidth=1.2;q.beginPath();
    for(let k=-r;k<=r;k+=4.5){q.moveTo(x+k,y-r);q.lineTo(x+k,y+r);q.moveTo(x-r,y+k);q.lineTo(x+r,y+k);}q.stroke();q.restore();
    q.globalCompositeOperation='destination-in';q.drawImage(mask,0,0);g.globalCompositeOperation='source-over';g.drawImage(t,0,0);}
  g.globalCompositeOperation='source-over';}
function wkEraseEdge(g,sc,R,n,r0,r1,C){const e=sc.edge.slice().sort((a,b)=>Math.hypot(b[0]-C,b[1]-C)-Math.hypot(a[0]-C,a[1]-C)),top=e.slice(0,Math.max(1,Math.floor(e.length*.45)));
  g.globalCompositeOperation='destination-out';for(let i=0;i<n;i++){const [x,y]=wkPick(top,R),r=wkRng(R,r0,r1),gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,'rgba(0,0,0,1)');gr.addColorStop(.7,'rgba(0,0,0,.8)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2);}
  g.globalCompositeOperation='source-over';}
function wkNoise(g,S,C,seed,pmax,desat,rmax){const im=g.getImageData(0,0,S,S),d=im.data;
  for(let y=0;y<S;y++)for(let x=0;x<S;x++){const o=(y*S+x)*4;if(!d[o+3])continue;
    const dd=Math.hypot(x-C,y-C)/rmax,q=dd<.3?0:Math.min(1,Math.pow((dd-.3)/.7,1.2))*pmax;
    let h=Math.imul((x>>1)*73856093^(y>>1)*19349663^seed,0x45d9f3b);h^=h>>>16;h=Math.imul(h,0x45d9f3b);h^=h>>>16;
    if((h>>>0)/4294967296<q){d[o+3]=0;continue;}
    if(desat){const l=d[o]*.3+d[o+1]*.59+d[o+2]*.11;d[o]=d[o]+(l-d[o])*desat;d[o+1]=d[o+1]+(l-d[o+1])*desat;d[o+2]=d[o+2]+(l-d[o+2])*desat;}}
  g.putImageData(im,0,0);}
function wkFrost(g,sc,R,n){g.strokeStyle='rgba(232,246,255,.9)';g.lineWidth=.9;g.beginPath();
  for(let i=0;i<n;i++){const [x,y]=wkPick(sc.edge,R),L=wkRng(R,2,4.5),a0=R()*TAU;for(let k=0;k<3;k++){const a=a0+k*TAU/3;g.moveTo(x,y);g.lineTo(x+Math.cos(a)*L,y+Math.sin(a)*L);}}g.stroke();}
function wkRust(g,sc,R,n,C){g.globalCompositeOperation='source-atop';const dir=Math.PI/2+(R()-.5)*.6;
  for(let i=0;i<n;i++){const [x,y]=wkPick(sc.pts,R),L=wkRng(R,6,18);g.strokeStyle=`rgba(${120+Math.floor(R()*50)},${50+Math.floor(R()*20)},18,.55)`;g.lineWidth=wkRng(R,1,2.2);g.beginPath();g.moveTo(x,y);g.lineTo(x+Math.cos(dir)*L,y+Math.sin(dir)*L);g.stroke();}
  g.globalCompositeOperation='source-over';
  for(let i=0;i<4;i++){const [x,y]=wkPick(sc.edge,R),a=Math.atan2(y-C,x-C)+(R()-.5)*.8,L=wkRng(R,5,9);
    g.beginPath();g.moveTo(x+Math.cos(a+1.6)*3,y+Math.sin(a+1.6)*3);g.lineTo(x+Math.cos(a)*L,y+Math.sin(a)*L);g.lineTo(x+Math.cos(a-1.6)*3,y+Math.sin(a-1.6)*3);g.closePath();
    g.fillStyle='#3a2010';g.fill();g.strokeStyle='#c96a2a';g.lineWidth=1;g.stroke();}}
// контур по маске (для чертежа и стёртых)
function wkOutline(src,S,col,w){const o=wkCv(S),q=o._g;for(const [dx,dy] of [[-w,0],[w,0],[0,-w],[0,w],[-w,-w],[w,w],[w,-w],[-w,w]])q.drawImage(src,dx,dy);
  q.globalCompositeOperation='source-in';q.fillStyle=col;q.fillRect(0,0,S,S);q.globalCompositeOperation='destination-out';q.drawImage(src,0,0);q.globalCompositeOperation='source-over';return o;}

// --- нарезка ---
function wkWedges(cx,cy,ang,S){const out=[];for(let i=0;i<ang.length;i++){const a1=ang[i],a2=i+1<ang.length?ang[i+1]:ang[0]+TAU,p=[[cx,cy]],st=Math.max(2,Math.ceil((a2-a1)/(Math.PI/4)));
  for(let k=0;k<=st;k++){const a=a1+(a2-a1)*k/st;p.push([cx+Math.cos(a)*S*1.5,cy+Math.sin(a)*S*1.5]);}out.push(p);}return out;}
// полосы между линиями разреза; ось x (поперёк корпуса) или y; jag — изломанность
function wkStrips(S,cuts,R,jag,tilt,horiz){const lines=[[[-S,-S],[-S,2*S]]];
  for(const c of cuts){const L=[],tl=(R()-.5)*(tilt||0),n=jag?9:1;for(let k=0;k<=n;k++){const v=-S*.2+S*1.4*k/n;L.push([c+tl*(v-S/2)+(jag&&k&&k<n?(R()-.5)*jag:0),v]);}lines.push(L);}
  lines.push([[2*S,-S],[2*S,2*S]]);const out=[];
  for(let i=0;i<lines.length-1;i++){const p=lines[i].concat(lines[i+1].slice().reverse());out.push(horiz?p.map(([a,b])=>[b,a]):p);}return out;}
function wkPip(p,x,y){let c=false;for(let i=0,j=p.length-1;i<p.length;j=i++){const [xi,yi]=p[i],[xj,yj]=p[j];if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)c=!c;}return c;}
function wkCut(base,S,polys,bb,mot){const C=S/2,out=[];
  polys.forEach((p,i)=>{let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const [x,y] of p){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}
    x0=Math.max(Math.floor(x0),bb[0]-1);y0=Math.max(Math.floor(y0),bb[1]-1);x1=Math.min(Math.ceil(x1),bb[2]+1);y1=Math.min(Math.ceil(y1),bb[3]+1);if(x1-x0<2||y1-y0<2)return;
    const c=wkCv(x1-x0,y1-y0),q=c._g;q.translate(-x0,-y0);wPoly(q,p);q.clip();q.drawImage(base,0,0);
    const m=mot(i,p)||{};out.push({c,poly:p,ox:x0-C,oy:y0-C,px:(x0+x1)/2-C,py:(y0+y1)/2-C,dx:m.dx||0,dy:m.dy||0,rot:m.rot||0,dr:m.dr||0,ph:m.ph||0,per:m.per||3});});
  return out;}

// --- сборка обломка ---
const WRECK_SPR={},WRK={n:0,frame:0,budget:1,ms:[],icons:{}};
function wreckSprite(j,force){const id=j.id,c=WRECK_SPR[id];if(c){c.use=WRK.frame;return c;}
  if(!force){if(WRK.budget<=0)return null;WRK.budget--;}
  const t0=performance.now();let s;try{s=wkBuild(j);}catch(e){console.error(e);s={pieces:[],col:'#8fe9ff',bits:[],base:0,sz:1,rv:40,fx:{},spec:wreckSpec(j)};}
  s.ms=performance.now()-t0;WRK.ms.push(s.ms);if(WRK.ms.length>200)WRK.ms.shift();s.use=WRK.frame;WRECK_SPR[id]=s;WRK.n++;
  const keys=Object.keys(WRECK_SPR);if(keys.length>28){keys.sort((a,b)=>WRECK_SPR[a].use-WRECK_SPR[b].use);for(const k of keys.slice(0,keys.length-28))if(WRECK_SPR[k].use<WRK.frame-1)delete WRECK_SPR[k];}
  return s;}
function wkBuild(j){const sp=wreckSpec(j),R=mulberry(j.n*7919+(j.rift?101:3)),k=2.6*(sp.size||1),S=Math.ceil(52*k+24),C=S/2;
  const base=wkCv(S,S,true),g=base._g,fx={},o={pieces:[],bits:[],base:R()*TAU,sz:sp.size||1,fx,spec:sp,S};
  let info={};g.setTransform(k,0,0,k,C,C);
  if(sp.own==='player'){const oc=ctx,og=glow,of=flameTri;ctx=g;glow=()=>{};flameTri=()=>{};try{drawShip(sp.skin,0,0,{});}finally{ctx=oc;glow=og;flameTri=of;}}
  else if(sp.cls!=='proto'){const key=wShapeKey(sp);info=(W_SHAPES[key]||W_SHAPES.transport)(g,R,{bureau:sp.variant==='bureau'})||{};}
  g.setTransform(1,0,0,1,0,0);g.lineCap='butt';
  const P=(x,y)=>[C+x*k,C+y*k];let sc=sp.cls==='proto'?{pts:[[C,C]],edge:[[C,C]],bb:[C-1,C-1,C+1,C+1]}:wkScan(g,S);
  const mot=(f)=>f;let polys,motion;
  if(sp.own==='player'){const L=sp.dmg,col=SKINS[sp.skin].col;o.col=sp.rift?'#ff4f6e':col;
    const Q=[null,{np:2,sp:[6,10],rot:.25,dr:.01,burn:2,dark:.35,hole:0,bits:3},{np:3,sp:[10,18],rot:.45,dr:.015,burn:[3,4],dark:.45,hole:[2,3],bits:5},
      {np:[3,4],sp:[14,22],rot:.6,dr:.02,burn:[3,4],dark:.6,hole:[1,2],crack:[4,6],grid:2,bits:7},{np:4,sp:[20,34],rot:.9,dr:.06,burn:3,dark:.6,hole:2,crack:[3,5],grid:2,erase:1,bits:[12,16]},
      {np:[4,5],sp:[26,42],rot:.9,dr:.03,burn:1,dark:.5,hole:1,crack:[2,3],noise:.42,desat:.45,bits:6}][L];
    const cnt0=sc.cnt;wkDarkIn(g,base,S,Q.dark,2.5);wkBurns(g,sc,R,wkInt(R,Q.burn),6,14);
    if(Q.hole)wkHoles(g,sc,R,wkInt(R,Q.hole),3,6,L>=3?null:'rgba(255,140,60,.8)',1.4);
    if(Q.crack)wkCracks(g,sc,R,wkInt(R,Q.crack),col,1.6,26,6);
    if(Q.grid)wkGrid(g,base,sc,R,Q.grid,7,11);
    if(Q.erase)wkEraseEdge(g,sc,R,5,7,12,C);
    if(Q.noise){const rm=Math.max(...sc.edge.map(([x,y])=>Math.hypot(x-C,y-C)),20);wkNoise(g,S,C,j.n*131+7,Q.noise,Q.desat,rm);}
    if(sp.rift){wkDark(g,S,0,'rgba(255,40,70,.18)');}
    sc=wkScan(g,S);o.keep=sc.cnt/cnt0;
    // разрез: центр к корме, носовой клин — первый и самый большой
    const np=wkInt(R,Q.np),h=wkRng(R,.95,1.2),cx=C-5*k,cy=C+(R()-.5)*6,ang=[h];
    for(let i=1;i<np-1;i++)ang.push(h+(TAU-2*h)*i/(np-1)+(R()-.5)*.35);if(np>1)ang.push(TAU-h);
    polys=np>1?wkWedges(cx,cy,ang,S):[[[0,0],[S,0],[S,S],[0,S]]];if(np>1)polys.unshift(polys.pop());
    motion=(i,p)=>{const nose=i===0;let mx=0,my=0;for(const q of p.slice(1)){mx+=q[0];my+=q[1];}mx=mx/(p.length-1)-cx;my=my/(p.length-1)-cy;const l=Math.hypot(mx,my)||1,d=wkRng(R,Q.sp[0],Q.sp[1])*(nose?.3:1);
      return {dx:mx/l*d,dy:my/l*d,rot:(R()-.5)*2*Q.rot*(nose?.3:1),dr:(R()-.5)*2*Q.dr*(nose?.3:1),ph:R()*3,per:2+R()*2};};
    o.pieces=wkCut(base,S,polys,sc.bb,motion);
    if(L<=2){const ex=C-10*k,ey=C;fx.ember={x:ex-C,y:ey-C,pi:o.pieces.findIndex(p=>wkPip(p.poly,ex,ey))};}
    fx.spark=[0,.006,.01,.012,.02,0][L];if(L===5){fx.glitch=1;fx.noisePx=1;}if(sp.rift)fx.red=1;
    o.bits=wkBits(R,wkInt(R,Q.bits),k,['#3a4558','#3a4558',col]);}
  else{const cls=sp.cls;o.col={transport:'#9fb4c8',station:'#ffcf7a',barge:'#bfe0ff',tug:'#c96a2a',shell:'#ffc2ec',flagship:'#ff4f6e',blueprint:'#6bb8ff',cradle:'#ffb84d',ark:'#ffd27a',erased:'#9fffe0',proto:'#ffffff'}[cls];
    const all=[[[0,0],[S,0],[S,S],[0,S]]],bb=sc.bb,bw=bb[2]-bb[0];let nb=4,bcol=['#3a4558','#4a5870'];
    if(cls==='transport'){wkDark(g,S,.35);wkBurns(g,sc,R,2,6,12);const [qx,qy]=P(12,0);g.globalCompositeOperation='destination-out';g.strokeStyle='#000';g.lineWidth=1.2;g.beginPath();for(let i=0;i<4;i++){const a=R()*TAU;g.moveTo(qx,qy);g.lineTo(qx+Math.cos(a)*3.5*k,qy+Math.sin(a)*3.5*k);}g.stroke();g.globalCompositeOperation='source-over';
      polys=wkStrips(S,[C-5.3*k],R,0,0,true);const up=R()<.5;motion=(i)=>((i===0)===up?{dx:wkRng(R,-5,5),dy:(i===0?-1:1)*wkRng(R,10,16),rot:(R()-.5)*.7,dr:(R()-.5)*.03}:{rot:(R()-.5)*.1});
      if(!up)polys=wkStrips(S,[C+5.3*k],R,0,0,true);}
    else if(cls==='station'){wkDark(g,S,.3);wkBurns(g,sc,R,2,6,12);wkHoles(g,sc,R,1,3,5);
      if(info.joints){const [cx,cy]=P(info.ctr[0],info.ctr[1]);polys=wkWedges(cx,cy,[-.35,.35,Math.PI],S);motion=(i,p)=>{const a=i===0?0:i===1?.75:-.75,d=wkRng(R,6,12);return {dx:Math.cos(a)*d,dy:Math.sin(a)*d,rot:(R()-.5)*.35,dr:(R()-.5)*.02};};}
      else{polys=wkStrips(S,[C+wkRng(R,-2,2)*k],R,4,.3);motion=i=>({dx:(i?1:-1)*wkRng(R,6,10),dy:wkRng(R,-3,3),rot:(R()-.5)*.6,dr:(R()-.5)*.02});}
      if(info.light){const [lx,ly]=P(info.light[0],info.light[1]);fx.beacon={x:lx-C,y:ly-C,ph:R()*2};}fx.spark=.004;}
    else if(cls==='barge'){wkDark(g,S,.3);wkDark(g,S,0,'rgba(170,220,255,.18)');wkCracks(g,sc,R,10,'rgba(232,246,255,.85)',.8,22);wkCracks(g,sc,R,3,null,.9,18);wkFrost(g,sc,R,26);
      polys=sp.variant==='guard'?wkWedges(C,C,[.3+R(),3.2+R()],S):wkStrips(S,[C-8*k,C+6*k],R,3,.25);motion=()=>({dx:wkRng(R,-3,3),dy:wkRng(R,-3,3),rot:(R()-.5)*.08});
      if(sp.variant!=='guard'){const ps=polys;motion=(i)=>({dx:(i-1)*wkRng(R,3,5),dy:wkRng(R,-1.5,1.5),rot:(R()-.5)*.06});}bcol=['#bfe0ff','#e8f6ff'];}
    else if(cls==='tug'){wkDark(g,S,.3);wkDark(g,S,0,'rgba(150,70,20,.22)');wkHoles(g,sc,R,wkInt(R,[3,5]),3,7,'#c96a2a',2);wkRust(g,sc,R,9,C);
      polys=wkStrips(S,[sp.variant==='robot'?C+7.5*k:C+wkRng(R,-4,0)*k],R,6,.3);motion=i=>({dx:(i?1:-1)*wkRng(R,8,14),dy:wkRng(R,-5,5),rot:(R()-.5)*.6,dr:(R()-.5)*.02});bcol=['#5a3418','#c96a2a'];}
    else if(cls==='shell'){wkDark(g,S,.25);wkCracks(g,sc,R,5,null,1,24);
      polys=wkStrips(S,[C-7*k+wkRng(R,-2,2)*k,C+5*k+wkRng(R,-2,2)*k],R,9,.4);motion=i=>({dx:(i-1)*wkRng(R,8,14),dy:wkRng(R,-6,6),rot:(R()-.5)*.8,dr:(R()-.5)*.015});fx.bio={x:0,y:0,r:12*k};bcol=['#c9a6c8','#f0d8e8'];nb=6;}
    else if(cls==='flagship'){wkDark(g,S,.3);wkBurns(g,sc,R,5,8,18);wkHoles(g,sc,R,3,4,8,'rgba(255,140,60,.7)',2);
      const [bx,by]=P(-9,(R()-.5)*8),br=8*k,gr=g.createRadialGradient(bx,by,0,bx,by,br);g.globalCompositeOperation='source-atop';gr.addColorStop(0,'rgba(0,0,0,1)');gr.addColorStop(.7,'rgba(10,4,2,.85)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(bx-br,by-br,br*2,br*2);
      const hp=wkJag(R,bx,by,4*k,10);g.globalCompositeOperation='destination-out';wPoly(g,hp);g.fill();g.globalCompositeOperation='source-atop';wPoly(g,hp);g.strokeStyle='rgba(255,150,60,.95)';g.lineWidth=3;g.stroke();g.globalCompositeOperation='source-over';
      polys=wkStrips(S,[C+wkRng(R,-1,3)*k],R,10,.35);motion=i=>({dx:(i?1:-1)*wkRng(R,12,18),dy:wkRng(R,-6,6),rot:(R()-.5)*.4,dr:(R()-.5)*.006});fx.spark=.02;nb=14;bcol=['#3a4558','#8a9ab0','#ff4f6e'];}
    else if(cls==='blueprint'){wkDark(g,S,.2);const sil=wkCv(S);sil._g.drawImage(base,0,0);
      const bp=wkCv(S),q=bp._g;q.strokeStyle='rgba(107,184,255,.45)';q.lineWidth=1;q.beginPath();for(let x=bb[0];x<bb[2];x+=6){q.moveTo(x,bb[1]);q.lineTo(x,bb[3]);}for(let y=bb[1];y<bb[3];y+=6){q.moveTo(bb[0],y);q.lineTo(bb[2],y);}q.stroke();
      q.globalCompositeOperation='destination-in';q.drawImage(sil,0,0);q.globalCompositeOperation='source-over';q.drawImage(wkOutline(sil,S,'#6bb8ff',1.2),0,0);
      q.strokeStyle='rgba(180,140,255,.8)';q.lineWidth=1;q.setLineDash([3,3]);q.beginPath();const yb=bb[3]+8,xr=bb[2]+8;q.moveTo(bb[0],yb);q.lineTo(bb[2],yb);q.moveTo(xr,bb[1]);q.lineTo(xr,bb[3]);q.stroke();q.setLineDash([]);
      q.beginPath();for(const x of [bb[0],bb[2]]){q.moveTo(x,yb-3);q.lineTo(x,yb+3);}for(const y of [bb[1],bb[3]]){q.moveTo(xr-3,y);q.lineTo(xr+3,y);}q.stroke();
      fx.bp={mat:base,bp,C,bb,ph:R()*TAU,sp:.25+R()*.2};o.pieces=[];o.bits=[];o.rv=Math.hypot(bw,bb[3]-bb[1])/2+10;return o;}
    else if(cls==='cradle'){wkDark(g,S,.2);if(sp.variant==='guardShot'){const r=7*k,gr=g.createRadialGradient(C,C,0,C,C,r);g.globalCompositeOperation='source-atop';gr.addColorStop(0,'rgba(0,0,0,1)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(C-r,C-r,r*2,r*2);
        const hp=wkJag(R,C+1,C-1,3.2*k,9);g.globalCompositeOperation='destination-out';wPoly(g,hp);g.fill();g.globalCompositeOperation='source-atop';wPoly(g,hp);g.strokeStyle='rgba(255,150,60,.95)';g.lineWidth=2.5;g.stroke();g.globalCompositeOperation='source-over';}
      const nk=sp.variant==='frame'||sp.variant==='stand'?3:R()<.5?3:4,cuts=[];for(let i=1;i<nk;i++)cuts.push(bb[0]+bw*i/nk);polys=wkStrips(S,cuts,R,0,0);
      const gap=wkRng(R,10,16);motion=i=>({dx:(i-nk/2)*gap,dy:0});fx.apart=1;nb=3;bcol=['#ffb84d','#3a4558'];}
    else if(cls==='ark'){wkDark(g,S,.15);if(info.win){const [wx,wy]=P(info.win[0],info.win[1]);const sc2={pts:sc.pts.filter(([x,y])=>Math.hypot(x-wx,y-wy)<info.win[2]*k),edge:[]};if(sc2.pts.length)wkCracks(g,sc2,R,4,'rgba(255,255,255,.9)',.8,info.win[2]*k);
        fx.heart={x:wx-C,y:wy-C,r:info.win[2]*k*1.4,ph:R()*2};}polys=all;motion=()=>({});nb=2;bcol=['#ffd27a','#3a3020'];}
    else if(cls==='erased'){const sil=wkCv(S);sil._g.drawImage(base,0,0);const ol=wkOutline(sil,S,'#9fffe0',1.4);g.clearRect(0,0,S,S);g.globalAlpha=.25;g.drawImage(wkOutline(sil,S,'#9fffe0',3),0,0);g.globalAlpha=1;g.drawImage(ol,0,0);
      sc=wkScan(g,S);const a0=R()*TAU,ang=[];for(let i=0;i<6;i++)ang.push(a0+i*TAU/6+(R()-.5)*.3);polys=wkWedges(C,C,ang,S);motion=()=>({ph:R()*TAU,per:1.5+R()*2.5});fx.flick=1;nb=0;}
    else if(cls==='proto'){const arcs=[];for(const [r,n,w] of [[20,4,2.6],[15.5,2,1.4],[11,3,2]])for(let i=0;i<n;i++)arcs.push({r:r*k,a:i/n*TAU+R(),len:TAU/n*(.55+R()*.3),w:w*k*.5,sp:(R()<.5?-1:1)*(.08+R()*.18),dr:R()*TAU});
      fx.proto={arcs,k};o.pieces=[];o.bits=wkBits(R,10,k,['#ffffff','#ffc2ec']);o.rv=24*k;return o;}
    if(cls!=='erased')sc=wkScan(g,S);
    o.pieces=wkCut(base,S,polys||all,sc.bb,motion||(()=>({})));o.bits=wkBits(R,nb,k,bcol);}
  let rv=10;for(const p of o.pieces){rv=Math.max(rv,Math.hypot(p.px+p.dx,p.py+p.dy)+Math.hypot(p.c.width,p.c.height)/2);}o.rv=rv;
  return o;}
function wkBits(R,n,k,cols){const b=[];for(let i=0;i<n;i++){const a=R()*TAU,r=(14+R()*12)*k;b.push({x:Math.cos(a)*r,y:Math.sin(a)*r,s:1.5+R()*2.5,a:R()*TAU,w:(R()-.5)*.8,c:cols[Math.floor(R()*cols.length)]});}return b;}
function wkTint(p){if(p.tint)return p.tint;p.tint=['#ff3d5a','#6bf0ff'].map(col=>{const c=wkCv(p.c.width,p.c.height),q=c._g;q.drawImage(p.c,0,0);q.globalCompositeOperation='source-in';q.fillStyle=col;q.fillRect(0,0,c.width,c.height);return c;});return p.tint;}

// --- отрисовка (в текущем ctx, начало — центр обломка) ---
function wreckBody(s,t,read,still){const fx=s.fx,A=read?.72:1,ef=SET.fx&&!still;
  if(fx.bio){glow(0,0,fx.bio.r,'#ffc2ec',(.35+.15*Math.sin(t*1.3))*A);}
  if(fx.bp){const B=fx.bp,lim=(B.bb[2]-B.bb[0])/2,cxb=(B.bb[0]+B.bb[2])/2-B.C,bx=cxb+Math.sin(t*B.sp+B.ph)*lim*.55;
    ctx.globalAlpha=A;ctx.save();ctx.beginPath();ctx.rect(-B.C,-B.C,bx+B.C,B.C*2);ctx.clip();ctx.drawImage(B.mat,-B.C,-B.C);ctx.restore();
    ctx.save();ctx.beginPath();ctx.rect(bx,-B.C,B.C*2,B.C*2);ctx.clip();ctx.globalAlpha=A*(.75+.25*Math.sin(t*3));ctx.drawImage(B.bp,-B.C,-B.C);ctx.restore();
    ctx.globalAlpha=A*.7;ctx.strokeStyle='#6bf0ff';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(bx,B.bb[1]-B.C-4);ctx.lineTo(bx,B.bb[3]-B.C+4);ctx.stroke();ctx.globalAlpha=1;}
  if(fx.proto){const k=fx.proto.k;glow(0,0,26*k,'#ffc2ec',.35*A);glow(0,0,8*k,'#ffffff',.6*A);ctx.lineCap='round';
    for(const a of fx.proto.arcs){const ang=a.a+a.sp*t,rr=a.r*(1+.04*Math.sin(t*.7+a.dr));ctx.strokeStyle='rgba(255,194,236,.35)';ctx.globalAlpha=A;ctx.lineWidth=a.w*3;ctx.beginPath();ctx.arc(0,0,rr,ang,ang+a.len);ctx.stroke();
      ctx.strokeStyle='#ffffff';ctx.lineWidth=a.w;ctx.beginPath();ctx.arc(0,0,rr,ang,ang+a.len);ctx.stroke();}ctx.lineCap='butt';ctx.globalAlpha=1;}
  for(const b of s.bits){ctx.save();ctx.translate(b.x,b.y);ctx.rotate(b.a+b.w*t);ctx.fillStyle=b.c;ctx.globalAlpha=A*.9;ctx.fillRect(-b.s,-b.s*.6,b.s*2,b.s*1.2);ctx.restore();}
  ctx.globalAlpha=1;
  if(fx.apart&&s.pieces.length>1){ctx.strokeStyle='rgba(255,184,77,.35)';ctx.lineWidth=1;ctx.setLineDash([3,4]);ctx.beginPath();for(let i=0;i<s.pieces.length-1;i++){const p=s.pieces[i],q=s.pieces[i+1];ctx.moveTo(p.px+p.dx,p.py-s.S*.12);ctx.lineTo(q.px+q.dx,q.py-s.S*.12);}ctx.stroke();ctx.setLineDash([]);}
  s.pieces.forEach((p,i)=>{let a=A,jx=0,jy=0,gl=false;
    if(fx.flick){const v=Math.sin(t*(TAU/p.per)+p.ph)+Math.sin(t*1.7+p.ph*2)*.5;a*=v>-.4?1:.12;}
    if(fx.glitch&&ef&&((t+p.ph)%p.per)<.15){gl=true;jx=(Math.random()-.5)*5;jy=(Math.random()-.5)*3;}
    ctx.save();ctx.translate(p.px+p.dx+jx,p.py+p.dy+jy);ctx.rotate(p.rot+p.dr*t);ctx.globalAlpha=a;
    if(gl){const T=wkTint(p);ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.55;ctx.drawImage(T[0],p.ox-p.px-3,p.oy-p.py);ctx.drawImage(T[1],p.ox-p.px+3,p.oy-p.py);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=a;}
    ctx.drawImage(p.c,p.ox-p.px,p.oy-p.py);
    if(fx.ember&&fx.ember.pi===i){ctx.globalAlpha=1;glow(fx.ember.x-p.px,fx.ember.y-p.py,10+3*Math.sin(t*4),'#ff8a3d',(.45+.2*Math.sin(t*7))*A);}
    ctx.restore();});
  ctx.globalAlpha=1;
  if(fx.beacon){const q=(t+fx.beacon.ph)%2.4,a=q<.18?1:q<.5?.5*(1-(q-.18)/.32):.08;glow(fx.beacon.x,fx.beacon.y,14,'#ffb84d',a*A);}
  if(fx.heart){const q=(t+fx.heart.ph)%1.7,hb=Math.exp(-q*q*60)+.6*Math.exp(-(q-.28)*(q-.28)*60),fade=.45+.55*(.5+.5*Math.sin(t*.23+fx.heart.ph));glow(fx.heart.x,fx.heart.y,fx.heart.r,'#ffd27a',(.15+.75*hb)*fade*A);}
  if(fx.red)glow(0,0,s.rv*.9,'#ff4f6e',.25+.1*Math.sin(t*2));
  if(fx.noisePx&&ef&&Math.random()<.35){ctx.fillStyle='#ffffff';for(let i=0;i<3;i++){const a=Math.random()*TAU,r=Math.random()*s.rv;ctx.globalAlpha=.4+Math.random()*.5;ctx.fillRect(Math.cos(a)*r,Math.sin(a)*r,2,2);}ctx.globalAlpha=1;}}
function drawWreck(j,t,read,label){const s=wreckSprite(j),sp=wreckSpec(j),sz=Math.min(sp.size||1,2.2);
  if(s){ctx.save();ctx.translate(j.x,j.y);const gr=46*Math.max(1,sz),gl=ctx.createRadialGradient(0,0,0,0,0,gr);gl.addColorStop(0,hexA(s.col&&s.col.length===7?s.col:'#8fe9ff',read?.06:.14));gl.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=gl;ctx.fillRect(-gr,-gr,gr*2,gr*2);
    ctx.rotate(s.base);wreckBody(s,t,read);ctx.restore();
    if(s.fx.spark&&SET.fx&&Math.random()<s.fx.spark*(1+sz)){const r=s.rv*.5;part(j.x+rnd(-r,r),j.y+rnd(-r,r),rnd(-80,80),rnd(-80,80),.5,Math.random()<.5?'#ffd27a':s.col,1.5);}}
  if(!read){const q=(t*.9)%1,R0=30*Math.max(1,sz*.8);ctx.strokeStyle=hexA('#8fe9ff',(1-q)*.6);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(j.x,j.y,R0+q*26,0,TAU);ctx.stroke();if(label)worldLabel(j.x,j.y-48*Math.max(1,sz*.85),label,'#7a8ea5');}}
// иконка 48 px (журнал)
function wreckIcon(j){const id=j.id;if(WRK.icons[id])return WRK.icons[id];const s=wreckSprite(j,true),c=wkCv(96),oc=ctx;ctx=c._g;
  try{const k=44/Math.max(20,s.rv);ctx.translate(48,48);ctx.scale(k,k);ctx.rotate(-.5);wreckBody(s,2,false,true);}catch(e){console.error(e);}finally{ctx=oc;}
  return WRK.icons[id]=c;}
function wreckIconsFill(el){el.querySelectorAll('canvas[data-wr]').forEach(cv=>{const j=WORLD.journals.find(q=>q.id===cv.dataset.wr);if(!j)return;const g=cv.getContext('2d');g.clearRect(0,0,cv.width,cv.height);g.drawImage(wreckIcon(j),0,0,cv.width,cv.height);});}
function skinWrecks(k){const all=WORLD.journals.filter(j=>{const s=wreckSpec(j);return s.own==='player'&&s.skin===k;}),S=G.save;return [all.filter(j=>S&&S.journals[j.id]).length,all.length];}
// отладка: сетка всех обломков
function wreckGrid(on){let el=document.getElementById('wrkGrid');if(on===false){if(el)el.remove();return 0;}
  if(!el){el=document.createElement('canvas');el.id='wrkGrid';el.style.cssText='position:fixed;inset:0;z-index:99;background:#04060c;width:100vw;height:100vh';document.body.appendChild(el);}
  const W_=el.width=innerWidth,H_=el.height=innerHeight,cols=9,rows=7,cw=W_/cols,ch=H_/rows,g=el.getContext('2d'),oc=ctx,t=performance.now()/1000,out=[];
  ctx=g;try{WORLD.journals.forEach((j,i)=>{const s=wreckSprite(j,true),sp=wreckSpec(j),x=(i%cols+.5)*cw,y=(Math.floor(i/cols)+.45)*ch,kk=Math.min(cw,ch)*.42/Math.max(20,s.rv);
    g.save();g.translate(x,y);g.scale(kk,kk);g.rotate(-.35);wreckBody(s,t,false,true);g.restore();
    g.font='10px monospace';g.textAlign='center';g.fillStyle=sp.own==='player'?SKINS[sp.skin].col:'#9fb0c4';g.fillText(j.n+' '+roman(j.sec+1)+' '+(sp.own==='player'?sp.skin+' '+sp.dmg:sp.cls+(sp.variant?'/'+sp.variant:'')),x,y+ch*.47);
    out.push({n:j.n,own:sp.own,k:sp.own==='player'?sp.skin:sp.cls,ms:+(s.ms||0).toFixed(1)});});}finally{ctx=oc;}
  return out;}

function storyDrawWorld(t){if(STORY_OFF.wrecks)return;try{const S=G.save;
  WRK.frame++;WRK.budget=1;sbWorldDraw(t);
  for(const j of WORLD.journals){const m=70*(wreckSpec(j).size||1)+40;if(!inView(j.x,j.y,m)){if(!WRECK_SPR[j.id]&&inView(j.x,j.y,m+Math.max(W,H)*.75))wreckSprite(j);continue;}drawWreck(j,t,!!S.journals[j.id],'СИГНАЛ БОРТЖУРНАЛА');}
  for(const w of S.story.riftWrecks){if(!inView(w.x,w.y,110))continue;drawWreck({id:'rw'+w.id,n:w.id%997,skin:w.skin,x:w.x,y:w.y,rift:1},t,!!w.read,'V∅ID-013 · ЦИКЛ '+roman(w.c));}
  for(const f of STORY_FRAGS){if(!fragAvail(f))continue;const p=fragPos(f);if(!inView(p.x,p.y,60))continue;const pu=.6+.4*Math.sin(t*3+p.x);
    ctx.save();ctx.translate(p.x,p.y);ctx.rotate(t*.6);const gr=ctx.createRadialGradient(0,0,0,0,0,34);gr.addColorStop(0,`rgba(255,255,255,${.35*pu})`);gr.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=gr;ctx.fillRect(-34,-34,68,68);
    ctx.fillStyle='#ffffff';ctx.globalAlpha=.85;ctx.beginPath();ctx.moveTo(0,-11);ctx.lineTo(6,0);ctx.lineTo(0,11);ctx.lineTo(-5,2);ctx.closePath();ctx.fill();ctx.restore();ctx.globalAlpha=1;worldLabel(p.x,p.y-34,'ФРАГМЕНТ ПАМЯТИ','#dfe8ff');}
 }catch(err){STORY_OFF.wrecks=1;console.error(err);}}
function storyPOI(){const S=G.save,p=G.player;if(!S||!S.story||p.hp<=0)return;sbWorldPOI();
  for(const w of S.story.riftWrecks){if(w.read)continue;if(Math.hypot(p.x-w.x,p.y-w.y)<110){w.read=1;toast('V∅ID-013 · ЦИКЛ '+roman(w.c),'ВОСПОМИНАНИЕ ИЗЪЯТО. Корпус ещё тёплый.');sfx('pick');}}
  for(const f of STORY_FRAGS){if(!fragAvail(f))continue;const q=fragPos(f);if(Math.hypot(p.x-q.x,p.y-q.y)<75){const n=Object.keys(S.story.frags).length+1;S.story.frags[f.id]=n;
    fragShow(STORY_FRAG[n-1]||'',n);G.lightFull=Math.max(G.lightFull||0,.6);thump(55,.5);thump(52,.4,.35);sfx('level');MAPC.rift=null;MAPC.riftKey=null;storyFixLast();saveWorld();}}}
function fragShow(txt,n){const el=document.getElementById('fragTxt');if(!el)return;el.innerHTML=`<small>ФРАГМЕНТ ПАМЯТИ · ${n}/15</small>${txt}`;el.classList.remove('on');void el.offsetWidth;el.classList.add('on');}
function storyFixLast(){const S=G.save;if(!S)return;const I=x=>riftTarget(riftInfo(x.x,x.y).d+riftShift());if(I(S.last)>=.2){let bn=WORLD.nodes[0],bd=1e12;for(const q of WORLD.nodes){const d=Math.hypot(q.x-S.last.x,q.y-S.last.y);if(d<bd&&nodeState(q.m)!=='locked'){bd=d;bn=q;}}S.last={x:bn.x,y:bn.y+150};}}
function storyWorldTick(dt){storyTick();radioTick(dt,'world');storyPOI();
  const e=erosion();if(e>0&&SET.fx&&G.riftD>-400&&G.riftD<0&&G.parts.length<300&&vR2()<e*dt*6){const p=G.player;part(p.x+vrnd2(-300,300),p.y+vrnd2(-200,200),vrnd2(-20,20),vrnd2(10,40),1.2,'#6b4a8c',1.5);}
  if(!G.secChk||G.secChk<=0){G.secChk=1;radioWorldEnter();}else G.secChk-=dt;}

// ---------- кодекс «Хроника» ----------
function chronicleHTML(){const S=G.save,s=S&&S.story,e=erosion();
  let h=`<dl class="kv"><dt>Лом</dt><dd>Остаточные записи. Энергия, извлечённая из того, что перестало существовать. Система не хранит источники.</dd>
  <dt>Маяк</dt><dd>Узел сети, которая удерживает реальность на месте. Заряженный маяк сохраняет одну историю. Остальные он не спрашивает.</dd>
  <dt>Разлом</dt><dd>За пределами секторов пространство не держит форму: помехи нарастают, а в глубине стреляют Неизвестные — их выстрелы убивают сразу. Спасает только рывок.</dd>`;
  if(e>=.2)h+=`<dt>Эрозия</dt><dd>Края секторов осыпаются. Причина: не установлена.</dd>`;
  if(s&&s.inv14==='memory')h+=`<dt>Циклы I–XXXI</dt><dd>Записи Инвентаризатора оттаяли. Тридцать одна копия VØID-013, один почерк. На полях трёх записей — рука Э. В.: «Ты снова выбрал холод. Не выбирай». «Третий путь — не вперёд и не назад». «Если читаешь это оттаявшим — значит, впервые не повторил».</dd>`;
  if(s&&s.inv14==='cold')h+=`<dt>Картотека</dt><dd>Ядро памяти сожжено. Тридцать одна запись исчезла вместе с тем, как именно они ошиблись. Архив молчит.</dd>`;
  if(s&&s.obod18)h+=`<dt>Обод</dt><dd>${s.obod18==='scrap'?'Станция списана. Кольцо не вращается, фонового износа в Хрониках больше нет; мастерские сектора IV восстанавливают корпус только до 80%.':'Заказ закрыт: корабль восстановлен до заводского. Перк «Заводской корпус»: фоновый износ вдвое медленнее, ремкомплект возвращает 10% износа. На листе обшивки — копия списка колонистов «Тихой».'}</dd>`;
  if(s&&s.arcAll)h+=`<dt>Каталог циклов</dt><dd>Шесть записей Архива собраны. Тридцать один цикл до этого: кто-то летел слишком быстро, кто-то отказался от щита, кто-то спросил, сколько их было. Э. В. правил их все на полях.</dd>`;
  if(s&&s.arcSilence)h+=`<dt>Тишина в Архиве</dt><dd>Три радиомаяка снесены. Холодный архив больше не слышит сектор, и Инвентаризатор начинает сверку с опозданием.</dd>`;
  if(s&&s.conveyor)h+=`<dt>Колыбельная</dt><dd>Баржа с тремя криокапсулами выведена с линии утилизации «Обода». Трое живы. Они не знают, кто вы, но запомнят.</dd>`;
  if(s&&s.cradle22)h+=`<dt>Кормилица</dt><dd>${s.cradle22==='cut'?'Кокон разбит. Следующая копия VØID не родилась в этой колыбели. Очередь копий: разрыв.':'Кокон выношен. Младший летит рядом в секторах V–VI. На его борту — номер следующего цикла.'}</dd>`;
  if(s&&s.fleet27)h+=`<dt>«Последний довод»</dt><dd>${s.fleet27==='bridge'?'Рубка пробита. Адмирал Карр так и не узнал, почему Стражи не стреляли в неё.':'Двигатели выбиты, рубка цела — как сделали Стражи 127 лет назад. Протокол «не объяснять», дополнение 7: «Людей не убивать». Перк «Милость»: отступающие сдаются от попадания.'}</dd>`;
  if(s&&s.save33)h+=`<dt>Выбор сохранения</dt><dd>${s.save33==='dead'?'Вы сохранили запись мёртвого вида. Зародышу питания не хватило.':'Вы сохранили зародыш. Запись мёртвого вида стёрлась.'}</dd>`;
  if(s&&s.history.length)h+=`<dt>Отчёты</dt><dd>${s.history.slice().reverse().map(r=>`Цикл ${roman(r.cyc)}: миссий ${r.missions}, поглощено ${fmtN(r.abs)}, отпущено ${r.spared}, записей ${r.read}/63, фрагментов ${r.frags}/15 — ${r.fin.toLowerCase()}.`).join('<br>')}</dd>`;
  return h+chron85(s)+chron90(s)+'</dl>';}

// ---------- отладка ----------
window.VOID_DBG={
  story(){const S=G.save;if(!S)return null;const s=S.story,bySec={};for(const j of WORLD.journals){bySec[j.sec]=bySec[j.sec]||[0,0];bySec[j.sec][1]++;if(S.journals[j.id])bySec[j.sec][0]++;}
    const seen={};for(const k in s.seen){const g=k[0];seen[g]=(seen[g]||0)+1;}return {abs:Math.round(s.absorbed),eros:+erosion().toFixed(2),spared:s.spared,fk:s.fleeKilled,warden:s.wardenMeets,frags:Object.keys(s.frags).length,rw:s.riftWrecks.length,bySec,seen,off:{...STORY_OFF},warn:STORY_WARN.slice()};},
  check(){const out={n:WORLD.journals.length,errs:[]};const cnt={};let skins={};const W_=WORLD.journals;
    W_.forEach(j=>{cnt[j.sec]=(cnt[j.sec]||0)+1;if(j.skin!=='base'&&j.skin!=='guard')skins[j.skin]=(skins[j.skin]||0)+1;if(!inSectors(j.x,j.y)||sectorIdx(j.x,j.y)!==j.sec)out.errs.push('sec '+j.id);});
    out.dist=Object.keys(cnt).sort((a,b)=>a-b).map(k=>cnt[k]).join('/');out.skins=skins;out.ids=new Set(W_.map(j=>j.id)).size;
    const obs=storyObstacles();W_.forEach(j=>{if(j.sec<=1)return;const d=Math.min(...obs.map(q=>Math.hypot(q.x-j.x,q.y-j.y)));if(d<200)out.errs.push('near '+j.id+' '+Math.round(d));
      W_.forEach(k=>{if(k!==j&&k.sec>1&&Math.hypot(k.x-j.x,k.y-j.y)<150)out.errs.push('pair '+j.id+'/'+k.id);});});
    out.frags=STORY_FRAGS.length;out.radio=Object.values(RADIO).reduce((a,g)=>a+g.l.length,0);out.fragTexts=STORY_FRAG.length;
    out.fullName=document.documentElement.innerHTML.includes(String.fromCharCode(1069,1083,1080,1072,1089));return out;},
  tp(k){const p=G.player;let q=null;if(k[0]==='w'||k[0]==='j')q=WORLD.journals.find(j=>j.id===k||('w'+j.n)===k);else if(k[0]==='f'){const f=STORY_FRAGS.find(f=>f.id===k);q=f&&fragPos(f);}
    else if(k[0]==='n')q=WORLD.nodes[+k.slice(1)-1];else if(k[0]==='s'){const s=WORLD.sectors[+k.slice(1)-1];q={x:s.bx||(s.box[0]+s.box[2])/2,y:(s.by||(s.box[1]+s.box[3])/2)+150};}
    if(q&&p){p.x=q.x;p.y=q.y+(k[0]==='n'?160:0);p.vx=p.vy=0;camSnap();}return q;},
  cycle(n){G.save.cycle=n;return n;},frags(n){const S=G.save;S.story.frags={};STORY_FRAGS.slice(0,n).forEach((f,i)=>S.story.frags[f.id]=i+1);MAPC.rift=null;storyFixLast();return n;},
  erosion(x){G.save.story.absorbed=x*EROSION_FULL;G.lomPrev=undefined;MAPC.rift=null;return x;},radio(g){const p=radioPick(g);if(p)radioSay(p.g,p.i);return p;},
  readAll(){WORLD.journals.forEach(j=>{G.save.journals[j.id]=1;if(!G.save.jOrder.includes(j.id))G.save.jOrder.push(j.id);});return journalIds().length;},
  prologue(l){prologueStart(l!==false);},flee(){const e=G.enemies.filter(o=>o.alive&&!STORY_NORETREAT.has(o.type)&&!STATIC.has(o.type)).sort((a,b)=>Math.hypot(a.x-G.player.x,a.y-G.player.y)-Math.hypot(b.x-G.player.x,b.y-G.player.y))[0];if(e)storyRetreat(e);return e&&e.type;},
  wrecks(on){return wreckGrid(on);},wreck(n){const j=WORLD.journals.find(q=>q.n===n);if(!j)return null;const p=G.player;if(p){p.x=j.x;p.y=j.y+180;p.vx=p.vy=0;camSnap();}const s=wreckSprite(j,true),sp=wreckSpec(j);
    return {n,id:j.id,sec:j.sec+1,own:sp.own,skin:sp.skin,hull:sp.hull,dmg:sp.dmg,cls:sp.cls,variant:sp.variant,size:sp.size,seed:j.n*7919+3,pieces:s.pieces.length,rv:Math.round(s.rv),ms:+(s.ms||0).toFixed(2),line:hullLine(j)};},
  wreckStats(){return {built:WRK.n,cached:Object.keys(WRECK_SPR).length,maxMs:+Math.max(0,...WRK.ms).toFixed(2),avgMs:+(WRK.ms.reduce((a,b)=>a+b,0)/(WRK.ms.length||1)).toFixed(2)};},
  off(k){STORY_OFF[k]=1;},on(k){delete STORY_OFF[k];},save(){return JSON.stringify(G.save);},load(s){store(saveKey(),JSON.parse(s));saveSet6(migrateSave(store(saveKey())),'load');return true;}};

