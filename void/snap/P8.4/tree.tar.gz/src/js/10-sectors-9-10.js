// ===== 0.9 «Сердце Ковчега и Стёртые берега»: общий каркас и сектор IX — механики миссий =====
const S90T=new Set(['clot90','valve90','keeper90','phago90','neuron90','embryo90','pass90','eraser100','hollow100','witness100','typo100','fixer100','echo100','tide100','noname100']);
S90T.forEach(k=>{H74.add(k);STORY_NORETREAT.add(k);});
const D90T=new Set([...S90T,'heart90','hvalve90','hkey90','thromb90','shore100','beacon100']);
function sec90(){const s=sec74();return s===8||s===9?s:-1;}
function rk90(){return curDiff().rank||0;}
function pk90(a,b,c){const r=rk90();return r<=0?a:r===1?b:c;}
function m90(){return inMission()&&G.mode!=='endless'?G.m:0;}
function ark90(){const S=G.save;if(!S||!S.story)return {woke:0,slept:0,lost:0,pods:{}};const a=S.story.ark||(S.story.ark={pods:{}});if(!a.pods)a.pods={};let w=0,s=0,l=0;for(const k in a.pods){const v=a.pods[k];if(v==='w')w++;else if(v==='s')s++;else if(v==='l')l++;}a.woke=w;a.slept=s;a.lost=l;return a;}
function podSet90(id,v){const S=G.save;if(!S||!S.story||G.mode!=='world')return;const a=ark90();const cur=a.pods[id];if(cur==='l'||cur==='w'&&v==='s')return;a.pods[id]=v;ark90();}
// --- геометрия арены, пересчитывается при смене размера окна ---
function geo90(X){if(X.gw===W&&X.gh===H)return;X.gw=W;X.gh=H;
  for(const f of X.flows){const P=f.p.map(([x,y])=>{const q=typeof rot95==='function'?rot95(x,y):{x:x*W,y:y*H};return [q.x,q.y];}),pts=[];let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
    for(let i=0;i<=32;i++){const t=i/32,u=1-t,x=u*u*u*P[0][0]+3*u*u*t*P[1][0]+3*u*t*t*P[2][0]+t*t*t*P[3][0],y=u*u*u*P[0][1]+3*u*u*t*P[1][1]+3*u*t*t*P[2][1]+t*t*t*P[3][1];pts.push({x,y});x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}
    for(let i=0;i<pts.length;i++){const a=pts[Math.max(0,i-1)],b=pts[Math.min(pts.length-1,i+1)],l=Math.hypot(b.x-a.x,b.y-a.y)||1;pts[i].tx=(b.x-a.x)/l;pts[i].ty=(b.y-a.y)/l;}
    f.pts=pts;f.bb=[x0-70,y0-70,x1+70,y1+70];}
  {const hz=H>W*1.15;for(const L of X.locks){L.hz=hz;L.pos=L.nx*(hz?H:W);L.door=L.ny*(hz?W:H);L.len=hz?W:H;L.x=hz?L.door:L.pos;L.dy=hz?L.pos:L.door;}}
  for(const q of X.pods){const P=typeof rot95==='function'?rot95(q.nx,q.ny):{x:q.nx*W,y:q.ny*H};q.x=P.x;q.y=P.y;}
  if(X.locks.length&&G.player&&X.gwInit90){const p=G.player;p.inv=Math.max(p.inv,1);for(const L of X.locks){const u=lu90(L,p.x,p.y);if(Math.abs(u-L.pos)<12+p.r+4)lockSet90(L,p,L.pos+(u<L.pos?-1:1)*(12+p.r+6));}}X.gwInit90=1;}
// --- поток: ближайшая точка ленты, направление и сила ---
function flowQ(x,y,X){X=X||G.x90;if(!X||!X.flows.length)return null;let best=null,bk=0;
  for(const f of X.flows){if(!f.pts||f.shut>0||f.closed)continue;const b=f.bb;if(x<b[0]||x>b[2]||y<b[1]||y>b[3])continue;const P=f.pts,hw=f.w/2;
    for(let i=0;i<P.length-1;i++){const a=P[i],c=P[i+1],dx=c.x-a.x,dy=c.y-a.y,L2=dx*dx+dy*dy||1;const t=clamp(((x-a.x)*dx+(y-a.y)*dy)/L2,0,1),qx=a.x+dx*t,qy=a.y+dy*t,d=Math.hypot(x-qx,y-qy);
      if(d<hw){const k=1-(d/hw)*(d/hw);if(k>bk){bk=k;const sg=f.rev95?-1:1,sk=(f.spd95||1)*(f.k95===undefined?1:f.k95);best={tx:(a.tx+(c.tx-a.tx)*t)*sg,ty:(a.ty+(c.ty-a.ty)*t)*sg,k:k*sk,f};}}}}
  return best;}
function beat90(t){const ph=(t*50/60)%1;return Math.pow(Math.max(0,1-ph*3.2),2);}
// --- миссия ---
function t90Init(M){G.x110=null;const sec=M&&M.gen?M.sec:-1;
  G.x90={sec,alarm:0,alarmV:0,alarmOn:false,alarmK:1,stage:0,al90T:0,flows:[],locks:[],pods:[],pud:[],nets:[],nid:0,hint:{},tel:{},atk:{},first:{},newT:{},wave:-1,t:0,quietT:0,hudFx:0,trauma:0,
    er:null,ez:[],hud:null,wit:[],witN:0,witT:0,tide:null,shadT:0,shad:[],echoP:[],echoRec:[],echoRecT:0,frag:0,born:G.t,phago90T:0,pass:[],karr:0};
  G.hs90=null;clearHud100(true);if(typeof t95Init==='function')t95Init(null,null);
  if(G.mode==='endless'||!M||!M.gen)return;const m=G.m,X=G.x90;
  if(sec===8&&!M.bossRoom){
    const F={39:[[[-.05,.28],[.35,.02],[.62,.6],[1.05,.36]],[[.12,1.05],[.32,.58],[.74,.9],[.92,-.05]],[[-.05,.82],[.38,.74],[.6,.3],[1.05,.74]]],
      40:[[[-.05,.3],[.3,.1],[.7,.55],[1.05,.25]],[[-.05,.78],[.4,.95],[.65,.55],[1.05,.82]]],41:[[[.5,-.05],[.15,.35],[.85,.6],[.5,1.05]],[[-.05,.55],[.35,.4],[.65,.75],[1.05,.45]]]}[m];
    if(F)X.flows=F.map(p=>({p,w:120,shut:0,closed:false,valve:null}));
    if(m===40||m===41){X.alarmOn=true;X.alarmK=pk90(.7,1,1.3)*(storyFlag('well38')==='silence'?.8:1);
      X.locks=[{nx:1/3,ny:m===40?.5:.32,ph:0,st:'open',t:0},{nx:2/3,ny:m===40?.5:.68,ph:7,st:'open',t:0}];}
    const PODS={39:[[.18,.24],[.82,.3]],40:[[.15,.22],[.86,.78]],41:[[.5,.16],[.84,.5]]}[m]||[];
    const ids='abc';PODS.forEach((q,i)=>X.pods.push({id:'m'+m+ids[i],nx:q[0],ny:q[1],st:'sleep',ch:0,kch:0,kby:null}));
    if(storyFlag('well38')==='third'){const extra={39:[.5,.12],40:[.5,.86],41:[.16,.5]}[m];if(extra)X.pods.push({id:'m'+m+'t',nx:extra[0],ny:extra[1],st:'sleep',ch:0,kch:0,kby:null});}
    if(m===41&&storyFlag('cradle22')==='keep')X.pods.push({id:'m41k',nx:.32,ny:.84,st:'sleep',ch:0,kch:0,kby:null,child:1});
    const A=ark90();for(const q of X.pods){const v=A.pods[q.id];if(v==='w')q.st='open';else if(v==='l')q.st='lost';}
    geo90(X);}
  if(sec===9&&typeof t100Init==='function')t100Init(M,X);
  if(typeof t95Init==='function')t95Init(M,X);if(typeof t110Init==='function')t110Init(M,X);}
function done90(M){const X=G.x90;if(!X||!M||!M.gen)return;
  for(const q of X.pods)if(q.st==='sleep')podSet90(q.id,'s');
  if(M.sec===9&&typeof done100==='function')done100(M,X);if(M.sec>=10&&typeof done110==='function')done110(M,X);
  if(M.sec===8&&G.mc&&X.alarmOn&&!G.mc.alarm60)conEvent('calm90');}
function r90Reset(){G.x90=null;G.x110=null;G.hs90=null;G.ol95=0;G.mark95=null;G.slow95=null;G.fq95=null;G.slowP95=0;clearHud100(true);const el=document.getElementById('x90G');if(el)el.hidden=true;}
// --- Тревога ---
// непрерывный урон (стирание, пустота): идёт мимо неуязвимости после удара, но не мимо рывка
function drain90(d){const p=G.player;if(!p||p.hp<=0||p.dashT>0||G.deadT>0||(devAny()&&G.dev.god)||(G.x85&&G.x85.calm>0&&inMission()))return;if(inMission())d*=curDiff().dmg||1;if(G.st&&p.hp<G.st.maxHp*.1)d*=.3;p.hp-=d;G.taken+=d;G.hurtV=Math.max(G.hurtV,.3);p.hitT=G.t;if(p.hp<=0){p.hp=.01;p.inv=0;p.shieldUp=false;damagePlayer(1);}}
function alarm90(v,why,x,y,aP){const X=G.x90;if(!X||!X.alarmOn||G.endT>0||!inMission())return;const a0=aP!==undefined?aP:X.alarm;X.alarm=clamp(X.alarm+(v>0?v*X.alarmK:v),0,100);
  if(why&&Math.abs(v)>=3&&x!==undefined)floater(x,y-26,(v>0?'ТРЕВОГА +':'ТРЕВОГА ')+Math.round(v>0?v*X.alarmK:v),v>0?C90.red:C90.warm);
  if(X.alarm>60&&G.mc)G.mc.alarm60=1;if(a0<30&&X.alarm>=30&&X.stage<1){X.stage=1;X.ph30=1;floater(G.player.x,G.player.y-46,'ТРЕВОГА 30 · КЛЕТКИ ПРОСНУЛИСЬ',C90.ark);}
  if(a0<60&&X.alarm>=60&&X.stage<2){X.stage=2;banner('ТРЕВОГА 60','ВРАГИ БЫСТРЕЕ · КОВЧЕГ ИЩЕТ ВАС');snd90('alarm');}
  if(X.alarm>=90&&!(X.al90T>0)){X.al90T=30;X.alarm=55;banner('ТРЕВОГА 90','ОБЛАВА · СБЕЙТЕ ИХ — СТАНЕТ ТИШЕ');snd90('alarm');trauma90(.25);{const n=Math.max(0,Math.min(3,6-G.enemies.filter(o=>o.alive&&o.type==='phago90').length));for(let i=0;i<n;i++)edgeSpawn('phago90',{delay:i*.25,ob96:1});}}}
function alarmCol90(k){return k<.5?mix90('#ffd36b','#ff9a4d',k*2):mix90('#ff9a4d','#d8364a',(k-.5)*2);}
// --- шлюзы ---
const LOCK90={open:14,warn:3,closed:8};
function lockCyc90(L){const E=G.x90&&G.x90.ev95;if(G.x90&&G.x90.fin96)return 'open';if(E&&E.k==='quar'&&E.t>0)return 'closed';const per=LOCK90.open+LOCK90.warn+LOCK90.closed,u=((G.x90.t+L.ph)%per+per)%per;return u<LOCK90.open?'open':u<LOCK90.open+LOCK90.warn?'warn':'closed';}
function lockGapOpen90(L){return L.st!=='closed';}
// стена шлюза: на ПК — вертикальная, на телефоне в портрете — горизонтальная; u — поперёк стены, v — вдоль
function lu90(L,x,y){return L.hz?y:x;}function lv90(L,x,y){return L.hz?x:y;}
function lockCross90(L,x0,y0,x1,y1){const u0=lu90(L,x0,y0),u1=lu90(L,x1,y1);if((u0-L.pos)*(u1-L.pos)>0)return false;const t=(L.pos-u0)/((u1-u0)||1e-6),v=lv90(L,x0,y0)+(lv90(L,x1,y1)-lv90(L,x0,y0))*t;if(lockGapOpen90(L)&&Math.abs(v-L.door)<90)return false;return true;}
function lockBlock90(a,b){const X=G.x90;if(!X||!X.locks.length||!a||!b||!inMission())return false;for(const L of X.locks)if(lockCross90(L,a.x,a.y,b.x,b.y))return true;return false;}
// враги обходят стену через дверь: цель — проём со своей стороны, у проёма — точка по ту сторону
function door90(e){const X=G.x90;if(!X||!inMission()||!X.locks.length||STATIC.has(e.type)||e.sbk||EDEF[e.type].passive)return null;const p=G.player;if(!p)return null;
  for(const L of X.locks){const ue=lu90(L,e.x,e.y),up=lu90(L,p.x,p.y);if((ue-L.pos)*(up-L.pos)>=0)continue;const side=ue<L.pos?-1:1,ve=lv90(L,e.x,e.y);
    const near=Math.abs(ue-(L.pos+side*34))<40&&Math.abs(ve-L.door)<60,tu=near?L.pos-side*60:L.pos+side*34;return L.hz?{x:L.door,y:tu}:{x:tu,y:L.door};}
  return null;}
function lockSet90(L,o,u){if(L.hz)o.y=u;else o.x=u;}
function lockPush90(o,px,py){const X=G.x90;if(!X)return;for(const L of X.locks){const hw=12+o.r,u=lu90(L,o.x,o.y),v=lv90(L,o.x,o.y);if(Math.abs(u-L.pos)>=hw)continue;const inGap=Math.abs(v-L.door)<90-o.r*.4;
    if(lockGapOpen90(L)&&inGap)continue;const pu=px!==undefined?lu90(L,px,py):u,side=pu<L.pos?-1:1;lockSet90(L,o,L.pos+side*hw);if(L.hz){if(o.vy&&Math.sign(o.vy)===-side)o.vy=0;}else if(o.vx&&Math.sign(o.vx)===-side)o.vx=0;}}
function lockTick90(X,dt){const p=G.player;for(const L of X.locks){const st=lockCyc90(L);
    if(st!==L.st){if(st==='warn'){snd90('lockw');if(!X.hint.lock){X.hint.lock=1;floater(L.x,L.dy-(L.hz?40:110),'ШЛЮЗ ЗАКРЫВАЕТСЯ · 3 С',C90.ark);}}
      if(st==='closed'){snd90('lock');trauma90(.08);
        if(p&&p.hp>0&&Math.abs(lu90(L,p.x,p.y)-L.pos)<12+p.r&&Math.abs(lv90(L,p.x,p.y)-L.door)<100){const side=lu90(L,p.x,p.y)<L.pos?-1:1;lockSet90(L,p,L.pos+side*(12+p.r+4));if(p.dashT<=0){damagePlayer(10);floater(p.x,p.y-30,'ЗАЖАЛО ШЛЮЗОМ',C90.red);}}
        for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||EDEF[e.type].passive||e.sbk)continue;if(Math.abs(lu90(L,e.x,e.y)-L.pos)<12+e.r&&Math.abs(lv90(L,e.x,e.y)-L.door)<100){const side=lu90(L,e.x,e.y)<L.pos?-1:1;lockSet90(L,e,L.pos+side*(14+e.r));hurt(e,e.maxHp*.25,{pulse:true});}}}
      if(st==='open')snd90('locko');L.st=st;}}
  for(const b of G.eb){if(b.life<=0||b.rift)continue;const px=b.x-b.vx*dt,py=b.y-b.vy*dt;for(const L of X.locks)if(lockCross90(L,px,py,b.x,b.y)){b.life=0;if(SET.fx)part(b.x,b.y,rnd(-40,40),rnd(-40,40),.2,C90.ark,2);break;}}
  for(const q of G.pick){if(q.px90!==undefined)for(const L of X.locks){if(lockCross90(L,q.px90,q.py90,q.x,q.y)){q.x=q.px90;q.y=q.py90;q.vx=q.vy=0;}}q.px90=q.x;q.py90=q.y;}}
// --- капсулы ---
function podTick90(X,dt){const p=G.player;if(!p)return;const wakeT=storyFlag('well38')==='silence'?2:1.5;
  for(const q of X.pods){if(q.st!=='sleep')continue;const d=Math.hypot(p.x-q.x,p.y-q.y);
    if(d<60&&p.hp>0){q.ch+=dt;if(q.ch>=wakeT)podWake90(q,'player');}else q.ch=Math.max(0,q.ch-dt*1.5);
    if(q.kby){const k=q.kby;if(!k.alive||k.wk90!==q){q.kby=null;q.kch=0;}else{q.kch+=dt;if(q.kch>=3)podWake90(q,'keeper');}}}}
function podWake90(q,by){const X=G.x90,p=G.player;if(q.st!=='sleep')return;q.ch=0;
  if(by==='player'){q.st='open';q.wakeT=G.t;podSet90(q.id,'w');const S=G.save;if(S&&G.mode==='world')S.lom+=60;floater(q.x,q.y-40,(q.child?'РЕБЁНОК ПРОСНУЛСЯ':'ПРОСНУЛСЯ')+' · +60 ЛОМА',C90.pil);sfx('cell');snd90('wake');conEvent('wake90');
    alarm90(15,1,q.x,q.y);hs90(.06,0);for(let i=0;i<(SET.fx?18:6);i++){const a=rnd(0,TAU);part(q.x,q.y,Math.cos(a)*rnd(40,140),Math.sin(a)*rnd(40,140),rnd(.4,.9),i%2?C90.pil:C90.ark,2);}
    if(!X.hint.pod){X.hint.pod=1;radioLine('КОВЧЕГ',C90.ark,'Пассажир '+q.id.slice(1).toUpperCase()+' проснулся раньше прибытия. Нарушение протокола.',.4);}}
  else{q.st='taken';const e=spawnEnemy('pass90',q.x,q.y+10,{noAffix:true,noLoot:true,spawnT:.5});e.pod90=q;e.life90=60;e.hostT=0;e.cd=1.2;X.pass.push(e);
    alarm90(6,1,q.x,q.y);floater(q.x,q.y-40,'РАЗБУЖЕН СИЛОЙ · ПАССАЖИР',C90.pil);snd90('wake');if(!X.hint.pass){X.hint.pass=1;floater(p.x,p.y-60,'ПАССАЖИР НА ВАШЕЙ СТОРОНЕ · НЕ ПОПАДИТЕ В НЕГО','#ffffff');}}}
// --- лужи Тромбов ---
function pud90K(e){const X=G.x90;if(!X||!X.pud.length)return 1;for(const q of X.pud)if((e.x-q.x)*(e.x-q.x)+(e.y-q.y)*(e.y-q.y)<q.r*q.r)return .65;return 1;}
function inPud90(x,y){const X=G.x90;if(!X)return false;for(const q of X.pud)if((x-q.x)*(x-q.x)+(y-q.y)*(y-q.y)<q.r*q.r)return true;return false;}
// --- нейросеть: минимальное остовное дерево по живым узлам ---
function net90(n){const nodes=n.nodes.filter(e=>e.alive);const key=nodes.map(e=>e.uid).join(',');if(key===n.key)return;n.key=key;const old=n.beams||[];n.beams=[];if(nodes.length<2)return;
  const inT=[nodes[0]];const rest=nodes.slice(1);while(rest.length){let bi=-1,bj=-1,bd=1e9;for(let i=0;i<inT.length;i++)for(let j=0;j<rest.length;j++){const d=Math.hypot(inT[i].x-rest[j].x,inT[i].y-rest[j].y);if(d<bd){bd=d;bi=i;bj=j;}}
    const a=inT[bi],b=rest[bj];const o=old.find(q=>q.a===a&&q.b===b||q.a===b&&q.b===a);n.beams.push({a,b,cut:o?o.cut:0});inT.push(b);rest.splice(bj,1);}}
function netTick90(X,dt){for(const n of X.nets){net90(n);for(const q of n.beams)if(q.cut>0)q.cut-=dt;if(typeof netImp95==='function')netImp95(n,dt);let w=null;for(const e of n.nodes)if(e.alive&&(!w||e.hp<w.hp))w=e;for(const e of n.nodes)e.weak90=e===w&&n.nodes.filter(o=>o.alive).length>1;}
  X.nets=X.nets.filter(n=>n.nodes.some(e=>e.alive));}
function buffs90(){const N=nets90();if(!N||!N.length)return;const B=[];for(const n of N)for(const q of n.beams)if(!(q.cut>0)&&q.a.alive&&q.b.alive&&q.a.spawnT<=0&&q.b.spawnT<=0)B.push(q);if(!B.length)return;
  for(const o of G.enemies){if(!o.alive||o.type==='neuron90'||STATIC.has(o.type)||EDEF[o.type].passive||o.sbk)continue;for(const q of B){if(segDist(q.a.x,q.a.y,q.b.x,q.b.y,o.x,o.y)<220){o.buff=Math.max(o.buff,1.2);o.nb90=.2;break;}}}}
// --- тик миссии ---
function t90Tick(dt){const X=G.x90;if(!X||!inMission())return;const p=G.player;X.t+=dt;feel90(dt);mod90Tick(dt);capEarly96();rescue96(dt);fin96Tick(X);
  if(G.state!=='play'){clearHud100();return;}
  if(X.sec===8)ark90Tick(X,dt);else if(X.sec===9&&typeof t100Tick==='function')t100Tick(X,dt);else if(X.sec>=10&&typeof t110Tick==='function')t110Tick(X,dt);
  if(X.nets.length)netTick90(X,dt);
  for(const e of G.enemies){if(!e.alive)continue;if(e.nb90>0){e.nb90-=dt;if(e.cd>0)e.cd-=dt*.25;}}
  if(typeof t95Tick==='function')t95Tick(dt);capEarly96();
  seen90Tick(dt);hud90();}
function ark90Tick(X,dt){const p=G.player;geo90(X);
  for(const f of X.flows){if(f.shut>0)f.shut-=dt;f.closed=!!(f.valve&&f.valve.alive&&f.valve.vi===3);}
  if(X.flows.length){const str=.85+.15*beat90(G.t);for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||EDEF[e.type].passive||e.sbk||e.spawnT>0)continue;const q=flowQ(e.x,e.y,X);if(q){e.x+=q.tx*120*q.k*str*dt;e.y+=q.ty*120*q.k*str*dt;}}
    for(const it of G.pick){if(it.story||it.k==='frag100')continue;const q=flowQ(it.x,it.y,X);if(q){it.x+=q.tx*90*q.k*dt;it.y+=q.ty*90*q.k*dt;it.x=clamp(it.x,10,W-10);it.y=clamp(it.y,10,H-10);}}}
  for(const q of X.pud)q.t-=dt;X.pud=X.pud.filter(q=>q.t>0);
  if(X.locks.length){lockTick90(X,dt);for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||e.sbk)continue;lockPush90(e,e.x-e.vx*dt,e.y-e.vy*dt);}}
  if(X.pods.length)podTick90(X,dt);
  if(X.alarmOn&&G.endT<=0&&p&&p.hp>0){const quiet=G.t-(G.lastFire90||-9)>1.5,calm=quiet&&!G.enemies.some(e=>e.alive&&!EDEF[e.type].passive&&targetable(e));const aP=X.alarm;X.alarm=clamp(X.alarm+(calm?-5:quiet?-2.5:.5*X.alarmK)*dt,0,100);if(X.al90T>0)X.al90T-=dt;alarm90(0,0,undefined,undefined,aP);
    if(X.ph30&&G.waveIdx<G.waves.length){X.ph30=0;const nx=G.waves[G.waveIdx];if(nx)nx.push('phago90');}
    const sp=X.stage>=2&&X.alarm>=60;for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||EDEF[e.type].passive||e.sbk)continue;e.tK=sp?1.1:(e.tK===1.1?1:e.tK);}
    X.alarmV+=(X.alarm-X.alarmV)*Math.min(1,dt*4);}}
// --- движение корабля: поток, лужи, шлюзы ---
function drift90(p,dt){const X=G.x90;if(!X||!inMission()){if(G.world&&typeof drift95==='function')drift95(p,dt);return;}
  if(X.sec===8){geo90(X);
    if(X.flows.length){const q=flowQ(p.x,p.y,X);
      if(G.dashId!==X.dashId){X.dashId=G.dashId;if(p.dashT>0&&q&&p.dx*q.tx+p.dy*q.ty>.6){p.dashT*=1.5;p.dashCd*=.8;if(!X.hint.flowDash){X.hint.flowDash=1;floater(p.x,p.y-36,'ПО ТЕЧЕНИЮ · РЫВОК ×1,5',C90.ark);}snd90('flow');}}
      if(q&&p.dashT<=0){const s=160*q.k*(.85+.15*beat90(G.t));p.x+=q.tx*s*dt;p.y+=q.ty*s*dt;if(!X.hint.flow){X.hint.flow=1;floater(p.x,p.y-36,'КРОВОТОК · СНОСИТ',C90.ark);}}}
    if(X.pud.length&&p.dashT<=0&&inPud90(p.x,p.y)){p.x=p.px+(p.x-p.px)*.6;p.y=p.py+(p.y-p.py)*.6;if(!X.hint.pud2){X.hint.pud2=1;floater(p.x,p.y-30,'ЛУЖА · ВЯЗКО',C90.red);}}
    if(X.locks.length)lockPush90(p,p.px,p.py);
    if(p.dashT>0&&X.nets.length){for(const n of X.nets)for(const q of n.beams){if(q.cut>0||!q.a.alive||!q.b.alive)continue;if(segInter(p.px,p.py,p.x,p.y,q.a.x,q.a.y,q.b.x,q.b.y)){q.cut=4;if(G.mc)G.mc.cut90=(G.mc.cut90||0)+1;floater((q.a.x+q.b.x)/2,(q.a.y+q.b.y)/2-20,'СВЯЗЬ ПОРВАНА · 4 С',C90.ark);snd90('cut');hs90(.06,0);}}}}
  else if(X.sec===9&&typeof drift100==='function')drift100(X,p,dt);
  if(typeof drift95==='function')drift95(p,dt);
  p.x=clamp(p.x,p.r,BW-p.r);p.y=clamp(p.y,p.r,BH-p.r);}
// --- снаряды игрока (true — поглощён) ---
function b90Hit(b){if(typeof b95Hit==='function'&&b95Hit(b))return true;const X=G.x90;if(!X||!inMission())return false;
  if(X.locks.length){for(const L of X.locks)if(lockCross90(L,b.px,b.py,b.x,b.y)){b.life=0;sfx('block');if(SET.fx)part(b.x,b.y,rnd(-60,60),rnd(-60,60),.2,C90.ark,2);return true;}}
  a90Pass(b);
  if(!b.charged&&!b.blast&&!b.al90){for(const e of G.enemies){if(e.type!=='phago90'||!e.alive||e.spawnT>0||e.burst90||e.spir95||e.nos95>0||b.hit.includes(e))continue;if(segDist(b.px,b.py,b.x,b.y,e.x,e.y)<e.r+3){b.life=0;b.hit.push(e);phagoEat90(e,b.dmg);return true;}}}
  if(X.sec===9&&typeof b100Hit==='function'&&b100Hit(b,X))return true;
  return false;}
function a90Pass(bu){if(!bu.al90&&!bu.a85)return;for(const e of G.enemies){if(!e.alive||(e.type!=='pass90'&&e.type!=='witness100')||bu.hit.includes(e))continue;if(segDist(bu.px,bu.py,bu.x,bu.y,e.x,e.y)<e.r+8)bu.hit.push(e);}}
function phagoEat90(e,dmg){e.fed=(e.fed||0)+1;e.r=Math.min(30,EDEF.phago90.r+e.fed*1.5);(e.eat95||(e.eat95=[])).push({a:rnd(0,TAU),d:rnd(.2,.6)});e.flash=.06;sfx('hit');snd90('blop',e.fed);hurt(e,dmg*.5,{phago:true});
  if(e.alive&&e.fed>=10&&!e.burst90){e.burst90=.5*tel90('phago90');floater(e.x,e.y-e.r-12,'ЛОПНЕТ!',C90.blood);}
  if(!G.x90.hint.phago){G.x90.hint.phago=1;floater(e.x,e.y-e.r-26,'ГЛОТАЕТ СНАРЯДЫ · ЗАРЯД ×1,5','#ff8a5c');}}
// --- импульс ---
function pulse90(p,R){const X=G.x90;if(!X||!inMission()){if(G.world&&typeof pulse95==='function')pulse95(p,R);return;}
  if(X.sec===8){for(const v of G.enemies){if(v.type!=='valve90'||!v.alive)continue;if(Math.hypot(v.x-p.x,v.y-p.y)<160+R*.2){if(v.flow90){v.flow90.shut=8;floater(v.x,v.y-36,'ПОТОК ЗАГЛУШЁН · 8 С',C90.ark);}v.vb=(v.vb||0)+.6;v.vi=0;snd90('valve');}}}
  for(const e of G.enemies){if(!e.alive)continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(d>R+e.r)continue;
    if(e.type==='clot90'){clotDissolve90(e);continue;}
    if(e.type==='phago90'&&!e.spir95){e.fed=0;e.r=EDEF.phago90.r;e.burst90=0;const a=Math.atan2(e.y-p.y,e.x-p.x);e.vx=Math.cos(a)*420;e.vy=Math.sin(a)*420;e.orbK=0;}
    if(e.type==='echo100'){kill(e);floater(e.x,e.y-20,'ЭХО СТЁРТО',C90.sh);}
    if(e.type==='hollow100'){e.rev100=4;}
    if(e.type==='witness100'){e.sh100=3;floater(e.x,e.y-24,'ЩИТ · 3 С','#ffffff');}}
  for(const q of X.pud)if(Math.hypot(q.x-p.x,q.y-p.y)<R+q.r){q.t=Math.min(q.t,.4);conEvent('drain90');}
  if(X.sec>=9&&typeof pulse100==='function')pulse100(X,p,R);
  if(typeof pulse95==='function')pulse95(p,R);}
function clotDissolve90(e){if(!e.alive)return;e.dis90=1;kill(e);floater(e.x,e.y-20,'РАСТВОРЁН',C90.warm);if(G.mc)G.mc.clot90=(G.mc.clot90||0)+1;conEvent('drain90');snd90('dissolve');}
// --- автоприцел и цели ---
function targ90(e){if(e.hid90&&!(e.rev100>0)&&!(e.vis100>0)&&!(G.player&&Math.hypot(e.x-G.player.x,e.y-G.player.y)<220))return false;const X=G.x90;if(!X||!inMission())return true;
  if(X&&X.locks.length&&G.player&&lockBlock90(G.player,e))return false;
  if(X&&X.sec===9&&typeof targ100==='function'&&!targ100(e,X))return false;
  if(typeof targ95==='function'&&!targ95(e))return false;
  return true;}
function aw90(e){switch(e.type){case 'neuron90':return e.weak90?1/1.35:1/1.2;case 'fixer100':return 1/1.4;case 'noname100':return (e.look||0)>3?1/.6:1;case 'keeper90':return e.st==='alert'?.9:1;}return 1;}

// ===== 0.9 → 0.9.5: враги сектора IX — ИИ, урон, гибель (переработка атак) =====
function nets90(){const X=G.x90;if(X&&inMission())return X.nets;return G.wn90||(G.wn90=[]);}
function nearLock90(x,y){const X=G.x90;if(!X||!inMission()||!X.locks.length)return false;for(const L of X.locks)if(Math.abs(lu90(L,x,y)-L.pos)<60)return true;return false;}
function comp90(x,y){const X=G.x90;if(!X||!inMission()||!X.locks.length)return true;for(const L of X.locks)if((lu90(L,x,y)-L.pos)*(lu90(L,W/2,H/2)-L.pos)<=0)return false;return true;}
function place90(e,fn,minP){const p=G.player,m=90;let best=null,bd=-1;const R=Math.random;
  for(let i=0;i<40;i++){const x=G.world?e.x+rnd(-260,260):m+R()*(W-2*m),y=G.world?e.y+rnd(-260,260):m+R()*(H-2*m);if(fn&&!fn(x,y))continue;if(nearLock90(x,y)||!comp90(x,y)||blocked95(x,y,40))continue;const dp=p?Math.hypot(x-p.x,y-p.y):999;if(dp<(minP||220))continue;
    let dn=1e9;for(const o of G.enemies)if(o!==e&&o.alive&&STATIC.has(o.type))dn=Math.min(dn,Math.hypot(o.x-x,o.y-y));const sc=Math.min(dn,400)+Math.min(dp,500)*.3;if(sc>bd){bd=sc;best={x,y};}}
  if(!best&&!G.world)best={x:W/2+rnd(-W*.12,W*.12),y:H/2+rnd(-H*.25,H*.25)};if(best){e.x=best.x;e.y=best.y;}e.vx=e.vy=0;e.spawnT=Math.max(e.spawnT||0,.6);}
const CAP90={neuron90:8,typo100:4,phago90:6,echo100:4,noname100:2,fixer100:3,eraser100:4,hollow100:4,keeper90:4,clot90:5,hunt95:6,spasm95:2,cell95:5,guard95:2,blot95:3,scribe95:3,ebb95:2,lost95:1};
function cap90(e){if(e.cap90||e.zone||G.world||e.elite95||e.host85||e.pack95||e.noCap95||e.net90)return;e.cap90=1;const L=G.x110&&inMission()&&CAP110[e.type]!==undefined?CAP110[e.type]:CAP90[e.type];if(L===undefined)return;let n=0;for(const o of G.enemies)if(o!==e&&o.alive&&o.type===e.type)n++;if(n<L)return;
  // замена — враг того же сектора, у которого есть место (а не безликий стрелок)
  let nt=e.type==='gunner'?'phantom':'gunner';const X=G.x90,FB=X&&inMission()?FB95[X.sec]:null;if(FB){for(const t of shuffle(FB.slice())){if(t===e.type)continue;const c=G.x110&&inMission()&&CAP110[t]!==undefined?CAP110[t]:CAP90[t];let m=0;for(const o of G.enemies)if(o.alive&&o.type===t)m++;if(c===undefined||m<c){nt=t;break;}}}
  const k=e.maxHp/EDEF[e.type].hp;e.type=nt;e.maxHp=e.hp=EDEF[nt].hp*k;e.r=EDEF[nt].r;e.contact=EDEF[nt].contact;e.spd=EDEF[nt].spd*rnd(.92,1.08);e.noBar90=0;e.hid90=false;}
const FB95={8:['clot90','phago90','cell95','keeper90'],9:['blot95','eraser100','hollow100','typo100']};
function s90Update(e,dt,c){cap90(e);if(e.weak95>0)e.weak95-=dt;if(e.inv95>0)e.inv95-=dt;switch(e.type){
    case 'clot90':clotAI90(e,dt,c);return true;
    case 'valve90':valveAI90(e,dt);return true;
    case 'keeper90':keeperAI90(e,dt,c);return true;
    case 'phago90':phagoAI90(e,dt,c);return true;
    case 'neuron90':neuronAI90(e,dt);return true;
    case 'embryo90':embryoAI90(e,dt);return true;
    case 'pass90':passAI90(e,dt);return true;}
  if(typeof ai95==='function'&&ai95(e,dt,c))return true;
  return typeof ai100==='function'?ai100(e,dt,c):false;}
// --- Тромб: прыжок-слитие с тенью на полу, лужа на месте приземления, слияние в Сгусток ---
function clotAI90(e,dt,c){const p=G.player,X=G.x90;const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;
  if(e.lp===undefined)e.lp=rnd(1.2,2.4);if(e.cs===undefined)e.cs='crawl';
  if(e.cs==='squat'){e.vx*=.8;e.vy*=.8;e.st95-=dt;e.sq95=Math.min(1,e.sq95+dt/.6);if(e.st95<=0){e.cs='air';e.ax0=e.x;e.ay0=e.y;e.at95=0;snd95('leap',e.x);}return;}
  if(e.cs==='air'){e.at95+=dt;const u=clamp(e.at95/.5,0,1);e.x=e.ax0+(e.lx-e.ax0)*u;e.y=e.ay0+(e.ly-e.ay0)*u;e.hz95=Math.sin(u*Math.PI)*(e.big95?70:50);e.vx=e.vy=0;if(u>=1){e.cs='crawl';e.hz95=0;e.sq95=0;e.lp=rnd(3.6,4.8);}return;}
  steer(e,pdx,pdy,e.spd*c.sm,dt,2);e.lp-=dt;const R=e.big95?420:300;
  if(e.lp<=0&&pd<R&&p.hp>0){e.cs='squat';e.st95=.6*tel90('clot90');e.sq95=0;let tx=p.x+p.vx*.3,ty=p.y+p.vy*.3;if(!G.world){tx=clamp(tx,40,W-40);ty=clamp(ty,40,H-40);}e.lx=tx;e.ly=ty;
    tg95({k:'zone',x:tx,y:ty,r:e.big95?60:46,T:e.st95+.5,dmg:16,col:C90.red,src:e,key:'clot90',snd:'tlZone',telK:false,on:()=>{clotLand95(e,tx,ty);}});}
  // слияние: два Тромба рядом — один Сгусток
  if(!e.big95&&e.cs==='crawl'&&!G.world&&Math.random()<dt*2)for(const o of G.enemies){if(o===e||!o.alive||o.type!=='clot90'||o.big95||o.cs!=='crawl'||o.spawnT>0)continue;if(Math.hypot(o.x-e.x,o.y-e.y)<e.r+o.r+14){clotMerge95(e,o);break;}}}
function clotLand95(e,x,y){const X=G.x90;snd95('land',x);trauma90(.12);if(G.shock.length<60)G.shock.push({x,y,r:10,R:e.big95?70:56,t:0,col:C90.red,thin:true});
  if(X&&inMission()){if(X.pud.length>=5)X.pud.shift();X.pud.push({x,y,r:e.big95?58:46,t:10,t0:10,bub:[]});if(!X.hint.pud){X.hint.pud=1;floater(x,y-36,'ЛУЖА · ВЯЗКО · ИМПУЛЬС РАСТВОРЯЕТ',C90.red);}}
  else{const P=G.wpud95||(G.wpud95=[]);if(P.length>=5)P.shift();P.push({x,y,r:46,t:8,t0:8});}}
function clotMerge95(e,o){const hp=(e.hp+o.hp)*.8,mx=(e.maxHp+o.maxHp)*.8;o.alive=false;e.big95=1;e.r=26;e.hp=hp;e.maxHp=mx;e.contact=Math.round((e.contact||14)*1.3);e.x=(e.x+o.x)/2;e.y=(e.y+o.y)/2;explode(e.x,e.y,C90.red,14,.7);floater(e.x,e.y-34,'СЛИЯНИЕ · СГУСТОК',C90.red);snd95('squeeze',e.x);}
// --- Клапан: тельца вдоль потока на открытых тактах, волна с двумя проходами, окно ✦ ---
function valveAI90(e,dt){const X=G.x90,p=G.player;e.vx=e.vy=0;
  if(!e.v90){e.v90=1;e.vb=rnd(0,.6);e.vi=0;
    if(X&&inMission()&&X.flows.length){let cand=[];for(const f of X.flows){if(f.valve&&f.valve.alive)continue;for(let i=7;i<=25;i+=2){const q=f.pts[i];if(q&&q.x>70&&q.x<W-70&&q.y>70&&q.y<H-70&&Math.hypot(q.x-p.x,q.y-p.y)>260&&!blocked95(q.x,q.y,30))cand.push([f,q,i]);}}
      if(cand.length){const [f,q,i]=cand[Math.random()*cand.length|0];e.x=q.x;e.y=q.y;f.valve=e;e.flow90=f;e.fi95=i;e.spawnT=Math.max(e.spawnT,.6);}else place90(e,null,260);}
    else if(inMission())place90(e,null,260);}
  if(e.spawnT>0)return;const T=1.2;e.vb+=dt;
  if(e.vb>=T){e.vb-=T;e.vi=(e.vi+1)%4;
    if(e.vi===3){const g=e.gap95||valveGaps95();wv95({x:e.x,y:e.y,v:320,w:12,dmg:15*first90(e),col:C90.ark,gaps:g,R:118});snd90('valve');trauma90(.06);tel90use('valve90');e.gap95=null;}
    else{if(e.vi===0)weak95(e,.4,2);
      // три кровяных тельца вдоль потока
      let a=Math.atan2(p.y-e.y,p.x-e.x),sp=320;const f=e.flow90;if(f&&f.pts&&e.fi95!==undefined){const q=f.pts[e.fi95];a=Math.atan2(q.ty,q.tx);if(f.rev95)a+=Math.PI;sp=120*(f.spd95||1)+200;}
      if(G.world||onScreen(e))for(let i=0;i<3;i++)eb95(e.x+Math.cos(a)*e.r,e.y+Math.sin(a)*e.r,a+(i-1)*.09,sp*(1-.06*Math.abs(i-1)),8*first90(e),C90.blood,6,'cell');snd95('spit',e.x);
      if(e.vi===2)e.gap95=valveGaps95();}}
  e.tele90=e.vi===2&&e.vb>T-.45*tel90('valve90');e.tl95=e.vi===2?1:0;}
function valveGaps95(){const a=rnd(0,TAU),w=50*Math.PI/180;return [{a,w},{a:a+Math.PI,w}];}
// --- Смотритель: маршрут из трёх точек, прожектор, метка «ЦЕЛЬ», иглы-седативы ---
function keeperRoute95(e){const pts=[];for(let i=0;i<3;i++){let x,y,k=0;do{x=G.world?e.x+rnd(-320,320):rnd(90,W-90);y=G.world?e.y+rnd(-320,320):rnd(90,H-90);}while(++k<10&&!G.world&&(blocked95(x,y,30)||!comp90(x,y)));pts.push({x,y});}return pts;}
function keeperAI90(e,dt,c){const p=G.player,X=inMission()?G.x90:null;const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;
  if(!e.st90){e.st90=1;e.st='patrol';e.fa=Math.atan2(pdy,pdx)+Math.PI;e.see=0;e.rt95=keeperRoute95(e);e.ri95=0;e.cd=2.5;}
  const sm=c.sm;
  if(e.st==='patrol'||e.st==='wake'){
    if(e.st==='wake'){const q=e.wk90;if(!q||q.st!=='sleep'){e.st='patrol';e.wk90=null;}else{const d=Math.hypot(q.x-e.x,q.y-e.y);if(d>60)steer(e,q.x-e.x,q.y-e.y,e.spd*.6*sm,dt,3);else{e.vx*=.85;e.vy*=.85;if(!q.kby){q.kby=e;q.kch=0;}}}}
    else{if(G.world&&(!e.rt95||Math.hypot(e.rt95[0].x-e.x,e.rt95[0].y-e.y)>900))e.rt95=keeperRoute95(e);const w=e.rt95[e.ri95%3];if(Math.hypot(w.x-e.x,w.y-e.y)<40){e.ri95++;e.pause95=.8;}
      if(e.pause95>0){e.pause95-=dt;e.vx*=.9;e.vy*=.9;e.fa+=Math.sin(G.t*1.6+e.seed)*dt*.9;}else steer(e,w.x-e.x,w.y-e.y,e.spd*.55*sm,dt,2);
      if(X&&X.pods&&Math.random()<dt*.12)for(const q of X.pods){if(q.st==='sleep'&&!q.kby&&Math.hypot(q.x-e.x,q.y-e.y)<300){e.st='wake';e.wk90=q;break;}}}
    const sp=Math.hypot(e.vx,e.vy);if(sp>8&&!(e.pause95>0))e.fa+=clamp(angDiff(Math.atan2(e.vy,e.vx),e.fa),-4*dt,4*dt);
    const inCone=pd<240&&Math.abs(angDiff(Math.atan2(pdy,pdx),e.fa))<35*Math.PI/180&&p.hp>0&&!lockBlock90(e,p)&&!wallBlock95(e,p);
    if(inCone)e.see+=dt;else e.see=Math.max(0,e.see-dt*1.5);
    if(e.see>=.6)keeperAlert90(e);}
  else{e.fa+=clamp(angDiff(Math.atan2(pdy,pdx),e.fa),-6*dt,6*dt);const m=clamp((pd-320)/100,-1,1);steer(e,pdx/pd*m-pdy/pd*.5*e.dir,pdy/pd*m+pdx/pd*.5*e.dir,e.spd*sm,dt,3);if(Math.random()<dt*.3)e.dir*=-1;
    if(e.bn>0){e.bt-=dt;if(e.bt<=0){e.bn--;e.bt=.16;const a=Math.atan2(pdy,pdx),lt=pd/330*.9;let a2=Math.atan2(p.y+(p.vy||0)*lt-e.y,p.x+(p.vx||0)*lt-e.x);if(Math.abs(angDiff(a2,a))<.06)a2=a+(e.uid%2?.06:-.06);for(const q of [a,a2]){const b=eb95(e.x,e.y,q,330,10*first90(e),'#fff2c0',4,'needle');if(b)b.slow95=1.5;}snd95('needle',e.x);}}
    else{e.cd-=dt;e.charging=e.cd<.45;if(e.cd<=0&&pd<700){e.bn=1;e.bt=0;e.cd=2.4;}}
    if(pd>700||lockBlock90(e,p))e.lost90=(e.lost90||0)+dt;else e.lost90=0;if(e.lost90>5){e.st='patrol';e.see=0;e.lost90=0;}}}
function keeperAlert90(e){if(e.st==='alert')return;const X=G.x90,p=G.player;e.st='alert';e.see=0;e.cd=1.4;if(e.wk90){const q=e.wk90;if(q.kby===e){q.kby=null;q.kch=0;}e.wk90=null;}
  if(X&&X.alarmOn&&!(storyFlag('well38')==='answer'&&G.t-X.born<10)&&(!e.spotT||G.t-e.spotT>6)){e.spotT=G.t;alarm90(5,1,e.x,e.y);}
  // вспышка-прожектор: конус горит 0,5 с — 15 урона, затем метка «ЦЕЛЬ»
  const fa=e.fa;tg95({k:'cone',x:e.x,y:e.y,a:fa,arc:70*Math.PI/180,len:260,T:.5,dmg:15,col:'#fff2c0',src:e,key:'keeper90',snd:'spot',on:()=>{snd95('flash',e.x);if(p&&Math.hypot(p.x-e.x,p.y-e.y)<300&&Math.abs(angDiff(Math.atan2(p.y-e.y,p.x-e.x),fa))<.7)mark95('ЦЕЛЬ',6);}});
  floater(e.x,e.y-e.r-14,'ЗАМЕЧЕН','#ffe9b0');snd90('spot');if(X&&!X.hint.keep){X.hint.keep=1;floater(p.x,p.y-56,'БЕЙТЕ СМОТРИТЕЛЕЙ В СПИНУ — ТИХО','#ffe9b0');}}
// --- Фагоцит: выпад псевдоподией, видимые проглоченные снаряды, спираль на десятом ---
function phagoAI90(e,dt,c){const p=G.player;if(e.orbA===undefined){e.orbA=Math.atan2(e.y-p.y,e.x-p.x);e.orbK=1;e.lunge95=rnd(1.5,3);}
  e.orbK=Math.min(1,(e.orbK||0)+dt*.6);if(e.nos95>0)e.nos95-=dt;
  if(e.burst90>0){e.burst90-=dt;e.vx*=.9;e.vy*=.9;
    if(e.burst90<=0){const n=Math.max(8,6+Math.floor((e.fed||0)/2)*2),col=shipCol();e.spir95={i:0,n,a:e.seed,t:0,col};e.burst90=-1;snd90('burst');trauma90(.2);}return;}
  if(e.spir95){const S=e.spir95;S.t-=dt;e.vx*=.9;e.vy*=.9;while(S.t<=0&&S.i<S.n){S.t+=.045;const a=S.a+S.i*.62;eb95(e.x,e.y,a,230,9*first90(e),S.col,5,'needle');S.i++;}if(S.i>=S.n){explode(e.x,e.y,'#ff8a5c',18,.7);e.burstDone=1;kill(e);}return;}
  if(e.lg95){const L=e.lg95;e.vx*=.85;e.vy*=.85;L.t-=dt;if(L.t<=0){e.lg95=null;e.nos95=.8;weak95(e,.8,1.5);}return;}
  e.lunge95-=dt;const pd=Math.hypot(p.x-e.x,p.y-e.y);
  if(e.lunge95<=0&&pd<240&&p.hp>0){e.lunge95=3;const a=Math.atan2(p.y-e.y,p.x-e.x),T=.5*tel90('phago90');e.lg95={t:T+.15,a};tg95({k:'line',x:e.x,y:e.y,x2:e.x+Math.cos(a)*140,y2:e.y+Math.sin(a)*140,w:22,T,dmg:12,col:'#ff8a5c',src:e,key:'phago90',snd:'tlLine',telK:false,track:o=>{o.x=e.x;o.y=e.y;o.x2=e.x+Math.cos(e.lg95?e.lg95.a:0)*140;o.y2=e.y+Math.sin(e.lg95?e.lg95.a:0)*140;},on:()=>snd95('lash',e.x)});return;}
  e.orbA+=1.4*e.dir*dt;const R=90+(e.fed||0)*2,tx=p.x+Math.cos(e.orbA)*R,ty=p.y+Math.sin(e.orbA)*R;steer(e,tx-e.x,ty-e.y,e.spd*c.sm*(Math.hypot(tx-e.x,ty-e.y)>160?1.4:1),dt,3*e.orbK+.5);}
// --- Нейрон: импульс бежит по лучам, жжёт на луче, узел выпускает кольцо ---
function neuronAI90(e,dt){e.vx=e.vy=0;const N=nets90();
  if(!e.n90){e.n90=1;if(!e.net90){if(inMission())place90(e,null,240);const n={nodes:[e],beams:[],key:'',impT:rnd(3,5)};e.net90=n;N.push(n);
      const alive=G.enemies.filter(o=>o.alive&&o.type==='neuron90').length,k=Math.min(rk90()>=1?3:2,8-alive);
      for(let i=0;i<k;i++){let x=e.x,y=e.y;for(let t=0;t<12;t++){const a=rnd(0,TAU),d=rnd(180,300);x=e.x+Math.cos(a)*d;y=e.y+Math.sin(a)*d;if(G.world||x>70&&x<W-70&&y>70&&y<H-70&&!nearLock90(x,y)&&comp90(x,y)&&!blocked95(x,y,30))break;}
        if(!G.world){x=clamp(x,70,W-70);y=clamp(y,70,H-70);}const s=spawnEnemy('neuron90',x,y,{net90:n,n90:1,spawnT:.8,noAffix:true,zone:e.zone});n.nodes.push(s);}}
    else if(!e.net90.nodes.includes(e))e.net90.nodes.push(e);}}
function netImp95(n,dt){const p=G.player;if(!n.beams.length)return;if(n.impT===undefined)n.impT=4;
  if(!n.imp){n.impT-=dt;const live=n.nodes.filter(o=>o.alive&&o.spawnT<=0);if(n.impT<=.5&&!n.chg95&&live.length>1){n.chg95=live[Math.random()*live.length|0];snd95('impulse',n.chg95.x);}
    if(n.impT<=0&&n.chg95){const s=n.chg95;n.chg95=null;n.impT=5;if(!s.alive)return;n.imp={front:[],done:new Set([s]),hit:new Set()};for(const q of n.beams)if(!(q.cut>0)&&(q.a===s||q.b===s))n.imp.front.push({q,from:s,to:q.a===s?q.b:q.a,u:0});tel90use('neuron90');tlog95('neuron90',.5);}return;}
  const I=n.imp,nf=[];for(const f of I.front){const q=f.q;if(q.cut>0||!f.to.alive||!f.from.alive)continue;const L=Math.hypot(f.to.x-f.from.x,f.to.y-f.from.y)||1;f.u+=260*dt/L;
    if(p&&p.hp>0&&p.dashT<=0&&!I.hit.has(q)&&segDist(q.a.x,q.a.y,q.b.x,q.b.y,p.x,p.y)<6+p.r*.55){I.hit.add(q);damagePlayer(8);floater(p.x,p.y-30,'РАЗРЯД −8','#ffe47a');}
    if(f.u>=1){const nd=f.to;if(!I.done.has(nd)){I.done.add(nd);if(G.world||onScreen(nd)){for(let i=0;i<6;i++)shootE(nd.x,nd.y,i/6*TAU+G.t,210,7,'#ffe47a',5);snd95('zap',nd.x);}nd.flash=.12;for(const q2 of n.beams)if(q2!==q&&!(q2.cut>0)&&(q2.a===nd||q2.b===nd)){const to=q2.a===nd?q2.b:q2.a;if(!I.done.has(to))nf.push({q:q2,from:nd,to,u:0});}}}else nf.push(f);}
  I.front=nf;if(!nf.length)n.imp=null;}
// --- Эмбрион: пульс чаще к вылуплению, силуэт за 3 с, брызги при раннем разрыве, окно у Перерождённого ---
function embryoAI90(e,dt){e.vx=e.vy=0;if(e.hatch===undefined){if(inMission())place90(e,null,220);e.hatch=pk90(18,15,12);e.hatch0=e.hatch;
    if(G.enemies.filter(o=>o.alive&&o.type==='embryo90').length>4){e.type='clot90';e.r=EDEF.clot90.r;e.contact=EDEF.clot90.contact;return;}}
  if(e.spawnT>0)return;e.hatch-=dt;if(e.hatch<3&&!e.hTy){e.hTy=embryoPick95(e);snd95('silhouette',e.x);e.tl95=3;}if(e.hatch<=0)embryoHatch90(e);}
function embryoPick95(e){let best=null,bd=500;for(const o of G.enemies){if(o===e||!o.alive||o.spawnT>0||STATIC.has(o.type)||EDEF[o.type].passive||o.sbk||EDEF[o.type].sbp||['embryo90','neuron90','pass90','witness100','tide100','echo100','lost95','gclot95'].includes(o.type))continue;const d=Math.hypot(o.x-e.x,o.y-e.y);if(d<bd){bd=d;best=o;}}return best?best.type:'clot90';}
function embryoHatch90(e){const ty=e.hTy||embryoPick95(e);e.alive=false;explode(e.x,e.y,'#ff9fb0',12,.6);snd90('hatch');
  const n=spawnEnemy(ty,e.x,e.y,{noAffix:true,noLoot:true,reborn90:1,spawnT:.4,zone:e.zone});n.hp*=1.4;n.maxHp=n.hp;n.dmgK90=1.2;n.contact=Math.round((n.contact||0)*1.2);n.weak95=2.4;n.weakK95=1.5;
  floater(e.x,e.y-24,'ПЕРЕРОЖДЁННЫЙ · '+EDEF[ty].name.toUpperCase(),'#ff9fb0');}
// --- Пассажир ---
function passAI90(e,dt){const p=G.player,X=G.x90;if(e.life90===undefined){e.life90=60;e.hostT=0;e.cd=1.2;}
  e.life90-=dt;if(e.hostT>0)e.hostT-=dt;if(e.pull95>0)e.pull95-=dt;
  if(e.life90<=0||e.leave90){if(!e.leave90){e.leave90=1;floater(e.x,e.y-26,'ПАССАЖИР УЛЕТАЕТ В ГЛУБИНУ',C90.pil);}
    const ex=e.x<W/2?-80:W+80;steer(e,ex-e.x,(H/2-e.y)*.2,240,dt,3);if(e.x<-60||e.x>W+60){e.alive=false;passSaved90(e);}return;}
  if(!e.oa)e.oa=rnd(0,TAU);e.oa+=dt*.5;const R=e.pull95>0?58:150,tx=p.x+Math.cos(e.oa)*R,ty=p.y+Math.sin(e.oa)*R;steer(e,tx-e.x,ty-e.y,e.spd*(e.pull95>0?2.2:1),dt,e.pull95>0?3.5:2.2);
  e.cd-=dt;if(e.cd>0)return;
  if(e.hostT>0&&p.hp>0){e.cd=1;shootE(e.x,e.y,Math.atan2(p.y-e.y,p.x-e.x),260,5,C90.pil,4);return;}
  let t_=null,bd=420;for(const o of G.enemies){if(!o.alive||o===e||EDEF[o.type].passive||NOAUTO.has(o.type)||!targetable(o))continue;const d=Math.hypot(o.x-e.x,o.y-e.y);if(d<bd){bd=d;t_=o;}}
  if(t_){const q=aimPt(t_),a=Math.atan2(q.y-e.y,q.x-e.x);e.face90=a;G.pb.push({x:e.x,y:e.y,px:e.x,py:e.y,vx:Math.cos(a)*760,vy:Math.sin(a)*760,dmg:(G.st?G.st.dmg:10)*.6,pierce:0,rico:0,life:.8,hit:[e],drone:true,al90:1,pas95:1});e.cd=.55;}else e.cd=.3;}
function passSaved90(e){const q=e.pod90;if(q&&!e.saved90){e.saved90=1;podSet90(q.id,'w');}}
// --- урон ---
function s90Hurt(e,dmg,src){src=src||{};const p=G.player;dmg*=weakK95(e);
  switch(e.type){
    case 'clot90':e.ut=0;if(src.charged&&!src.drone){clotDissolve90(e);return 0;}return dmg;
    case 'valve90':if(e.vi===3){sbBlock(e);e.inv95=.15;if(G.x90&&!G.x90.hint.valveC){G.x90.hint.valveC=1;floater(e.x,e.y-34,'ЗАКРЫТ · ЖДИТЕ ТАКТ',C90.ark);}return 0;}return dmg;
    case 'keeper90':{const back=Math.abs(angDiff(Math.atan2(p.y-e.y,p.x-e.x),e.fa||0))>110*Math.PI/180;e.patK=e.st!=='alert';e.back90=back;
      if(back){dmg*=2;if(G.x90&&!G.x90.hint.back){G.x90.hint.back=1;floater(e.x,e.y-26,'В СПИНУ ×2','#ffe9b0');}}
      if(e.wk90){const q=e.wk90;if(q.kby===e){q.kby=null;q.kch=0;}e.wk90=null;e.st='patrol';}
      if(!back&&e.st!=='alert'&&e.hp-dmg>0)keeperAlert90(e);else if(back&&e.hp-dmg>0&&e.st!=='alert')e.see=Math.max(e.see,.45);return dmg;}
    case 'phago90':return src.charged||src.blast?dmg*1.5:dmg;
    case 'pass90':if(src.pulse)return 0;if(!src.al90){if(!(e.hostT>0))floater(e.x,e.y-26,'ПАССАЖИР РАНЕН · ОН ВАС НЕ УЗНАЁТ',C90.red);e.hostT=4;}return dmg;}
  if(typeof hurt95==='function'){const r=hurt95(e,dmg,src);if(r!==undefined)return r;}
  return typeof hurt100==='function'?hurt100(e,dmg,src):dmg;}
// --- гибель ---
function s90Killed(e,silent){const X=G.x90;if(e.ob96&&!silent&&X&&X.alarmOn&&inMission()){alarm90(-4);floater(e.x,e.y-26,'ТИШЕ · −4',C90.warm);}
  switch(e.type){
    case 'keeper90':if(!silent&&e.back90&&e.patK){alarm90(-8);floater(e.x,e.y-26,'ТИХО',C90.warm);hs90(.06,0);snd90('quiet');conEvent('quiet90');if(G.mc)G.mc.quiet90=(G.mc.quiet90||0)+1;}
      if(e.wk90&&e.wk90.kby===e){e.wk90.kby=null;e.wk90.kch=0;}break;
    case 'valve90':if(e.flow90)e.flow90.valve=null;if(!silent)alarm90(3,1,e.x,e.y);break;
    case 'neuron90':if(!silent)alarm90(3,0);break;
    case 'embryo90':if(!silent&&e.hatch>0){for(let i=0;i<3;i++)eb95(e.x,e.y,rnd(0,TAU),170,7,'#ff9fb0',5,'cell',{life:.8});}break;
    case 'pass90':if(silent){passSaved90(e);break;}{const q=e.pod90;if(q&&!e.saved90){podSet90(q.id,'l');q.st='lost';}if(G.mc)G.mc.passKill90=1;floater(e.x,e.y-28,'ПАССАЖИР ПОГИБ',C90.red);snd90('lost');radioLine('КОВЧЕГ',C90.ark,'Пассажир '+(q?q.id.slice(1).toUpperCase():'')+': жизненные показатели — ноль. Причина: ваш огонь.',.3);}break;}
  if(typeof kill95==='function')kill95(e,silent);
  if(typeof kill100==='function')kill100(e,silent);
  if(typeof death95==='function')death95(e,silent);}
// --- «первая встреча»: первые две атаки нового врага — вполсилы; первые два телеграфа — в полтора раза дольше ---
function first90(e){const X=G.x90;if(!X||!inMission()||!e||!X.newT||!X.newT[e.type])return 1;const k=e.type,A=X.atk,slot=Math.floor(G.t*2);if(e.lastAtk90!==slot){e.lastAtk90=slot;A[k]=(A[k]||0)+1;}return A[k]<=2?.5:1;}
function tel90(k){const X=G.x90;if(!X||!inMission())return 1;return (X.tel[k]||0)<2&&X.newT&&X.newT[k]?1.5:1;}
function tel90use(k){const X=G.x90;if(X)X.tel[k]=(X.tel[k]||0)+1;}

// ===== 0.9 → 0.9.5: сектор X «Стёртые берега» — стирание, интерфейс, память, Свидетели, Прилив, враги =====
function ez100(){const X=G.x90;if(X&&inMission())return X.ez;return G.wez100||(G.wez100=[]);}
function sh100(){const S=G.save;if(!S||!S.story)return {frag:0,lostFrag:0};return S.story.shore||(S.story.shore={frag:0,lostFrag:0});}
function fragN100(v){let n=0;for(let i=0;i<12;i++)if(v&(1<<i))n++;return n;}
const FRAG100=['«…мы назвали его Ковчегом, потому что на нём было тесно и тепло…»','«…у пилота 013 была привычка: перед прыжком считать до трёх вслух…»','«…Э. В. рисовал корабли на полях отчётов. Всегда — с людьми в иллюминаторах…»',
  '«…здесь был берег. Настоящий: песок, вода, кто-то бросал камни…»','«…последний, кто помнил имена спящих, записал их на обшивке. Обшивку стёрли…»','«…мы не боялись темноты. Мы боялись, что нас забудут раньше, чем найдут…»',
  '«…первый цикл длился сорок лет. Последний — одиннадцать минут…»','«…если найдёшь это — значит, хоть что-то осталось…»','«…ребёнок спросил, почему звёзды не стираются. Никто не ответил…»',
  '«…мы оставили свет включённым — на случай, если кто-то вернётся…»','«…имя корабля было не VØID. Его стёрли первым…»','«…ты не первый, кто дочитал до конца. Но первый, кто собрал всё…»'];
// --- стирание с краёв: 12 с наползает, 6 держит, 12 отступает (Отливник может очистить края на 6 с) ---
function erW100(){const w=[rnd(.4,1),rnd(.4,1),rnd(.4,1),rnd(.4,1)];w[Math.random()*4|0]=1;return w;}
function erEase100(u){return u<.5?4*u*u*u:1-Math.pow(-2*u+2,3)/2;}
function erK100(E){const u=((E.t%30)+30)%30;return u<12?erEase100(u/12):u<18?1:1-erEase100((u-18)/12);}
function erD100(E){const k=(E.t<0?0:erK100(E))*(1-clamp(E.clr95||0,0,1));const D=E.D*k;return [D*E.w[0],D*E.w[1],D*E.w[2],D*E.w[3]];}
function erJit100(s,pos){return 7*Math.sin(pos*.021+s*1.7)+4*Math.sin(pos*.057+s*3.1)+2*Math.sin(pos*.13+G.t*.6+s);}
function capD95(x,y,x1,y1,x2,y2,w){return w/2-segDist(x1,y1,x2,y2,x,y);}
function voidDepth100(x,y,X){X=X||G.x90;if(!X||!inMission())return 0;let best=0;const E=X.er;
  if(E&&E.t>=0){const d=erD100(E);if(d[0]>2)best=Math.max(best,d[0]+erJit100(0,y)-x);if(d[1]>2)best=Math.max(best,x-(W-d[1]-erJit100(1,y)));if(d[2]>2)best=Math.max(best,d[2]+erJit100(2,x)-y);if(d[3]>2)best=Math.max(best,y-(H-d[3]-erJit100(3,x)));}
  for(const z of X.ez){if(z.tele>0)continue;const q=z.r-Math.hypot(x-z.x,y-z.y);if(q>best)best=q;}
  if(X.estr95)for(const s of X.estr95){if(s.tele>0)continue;const q=capD95(x,y,s.x1,s.y1,s.x2,s.y2,s.w);if(q>best)best=q;}
  if(X.strip95)for(const s of X.strip95){if(y<s.y0||s.t>s.t0-.05)continue;const q=s.w/2-Math.abs(x-s.x);if(q>best)best=q;}
  if(X.spits95)for(const s of X.spits95){const q=capD95(x,y,s.x1,s.y1,s.x2,s.y2,s.w);if(q>best)best=q;}
  if(X.poly95)for(const P of X.poly95){const q=polyD95(x,y,P);if(q>best)best=q;}
  if(X.tongue95)for(const s of X.tongue95){const q=capD95(x,y,s.x1,s.y1,s.x2,s.y2,s.w);if(q>best)best=q;}
  const b=typeof sb100==='function'?sb100():null;if(b&&b.hz100&&(b.st==='fight'||b.st==='enter')){const q=hzAt100(b,x)-y;if(q>best)best=q;}
  return best;}
function inVoid100(x,y,X){return voidDepth100(x,y,X)>0;}
function t100Init(M,X){const m=G.m;X.sh=sh100();X.estr95=[];X.tongue95=[];X.pulseLog95=[];
  if(!M.bossRoom){X.er={t:-6,w:erW100(),wn:erW100(),D:.18*Math.min(W,H),cyc:0};
    const S=X.sh,slots=[0,1].map(i=>(m-43)*2+i);X.witPlan=slots.filter(b=>!(S.frag&(1<<b))&&!(S.lostFrag&(1<<b))).map((b,i)=>({bit:b,at:i?62:24,done:false}));
    if(m>=44&&rk90()>=1){X.hud={t:pk90(28,24,22),cur:null,last:null};}
    if(m>=44)mem100Waves(X);
    if(m===45){X.tide={next:16,band:null,n:0,hit:0,diag:1};X.shadT=20;}
    if(m===43&&storyFlag('line31')==='write'&&G.mode==='world'){const p=G.player;x85().ally={kind:'appr',x:p.x-60,y:p.y+40,a:0,cd:1,t:90};radioLine('УЧЕНИК',C85.lek,'Я помню, как ты летаешь. Здесь это пригодится.',1);}}
  X.echoSaved=echoLoad100(m);X.typoSer=storyFlag('line31')==='write'&&typeof serialNo85==='function'?1:0;}
function done100(M,X){if(X.echoRec&&X.echoRec.length>40)echoSave100(G.m,X.echoRec);}
// --- память: во второй половине волн — враги прошлых секторов (белый список MEM95, X07) ---
const MEM95=['gunner','phantom','hunter','defect','loop','labrat','shocker','stamp','inspector','echo80','scout','rammer','splitter','lancer','clot90','keeper90','phago90','hunt95'];
function mem100Pool(){const S=G.save,out=new Set();for(let m=11;m<=41;m++){const C=SEC_WAVES[m];if(!C)continue;if(!ALPHA_OPEN&&!(S&&S.medals&&S.medals[m]&&S.medals[m].clear))continue;for(const t of C.nw.concat(C.old||[]))if(MEM95.includes(t)&&EDEF[t])out.add(t);}
  return out.size?[...out]:['gunner','phantom','hunter','defect','loop','clot90','keeper90'];}
function mem100Waves(X){const pool=mem100Pool(),n=G.waves.length;for(let w=Math.floor(n/2);w<n;w++){const wv=G.waves[w];for(let i=0;i<wv.length;i++){if(typeof wv[i]!=='string'||wv[i].includes(':'))continue;if(Math.random()<.3)wv[i]='mem:'+pool[Math.random()*pool.length|0];}}}
function mem100Spawn(ty){edgeSpawn(EDEF[ty]&&MEM95.includes(ty)?ty:'gunner',{mem100:1});}
// --- след прошлого прохождения (для Эха-призрака) ---
const ECH64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
function echoLoad100(m){try{const v=JSON.parse(LS.getItem('void_echo100')||'{}');const s=v&&typeof v==='object'?v[m]:null;if(typeof s!=='string'||s.length<20)return null;const out=[];for(let i=0;i+1<s.length;i+=2){const a=ECH64.indexOf(s[i]),b=ECH64.indexOf(s[i+1]);if(a<0||b<0)return null;out.push([a/63,b/63]);}return out;}catch(e){return null;}}
function echoSave100(m,rec){try{const v=JSON.parse(LS.getItem('void_echo100')||'{}');const o=v&&typeof v==='object'&&!Array.isArray(v)?v:{};let s='';for(const [x,y] of rec.slice(0,450))s+=ECH64[clamp(Math.round(x*63),0,63)]+ECH64[clamp(Math.round(y*63),0,63)];o[m]=s.slice(0,2000);for(const k of Object.keys(o))if(!/^4[3-6]$/.test(k))delete o[k];LS.setItem('void_echo100',JSON.stringify(o));}catch(e){}}
// --- тик миссии сектора X ---
function t100Tick(X,dt){const p=G.player;if(!p)return;
  if(X.er){const E=X.er,u0=((E.t%30)+30)%30;E.t+=dt;const u1=((E.t%30)+30)%30;if(E.t>=0&&u1<u0){E.w=E.wn;E.wn=erW100();E.cyc++;}E.D=.18*Math.min(W,H);E.tele=E.t<0?clamp(1+E.t,0,1):u1>29?u1-29:0;if(E.clrT95>0){E.clrT95-=dt;E.clr95=clamp(E.clrT95,0,1);}else E.clr95=0;}
  for(const z of X.ez){if(z.tele>0){z.tele-=dt;if(z.tele<=0)snd90('erase');}else z.t-=dt;}X.ez=X.ez.filter(z=>z.tele>0||z.t>0);
  if(X.estr95.length){for(const s of X.estr95){if(s.tele>0)s.tele-=dt;else s.t-=dt;}X.estr95=X.estr95.filter(s=>s.tele>0||s.t>0);}
  // эффекты пустоты: стирание не добивает (ниже 10% — урон ×0,3)
  const pd=voidDepth100(p.x,p.y,X);
  if(pd>0&&p.hp>0){X.vT=(X.vT||0)+dt;if(G.mc)G.mc.void100=1;if(!X.hint.void){X.hint.void=1;floater(p.x,p.y-40,'СТЁРТО · 6 УРОНА В СЕКУНДУ',C90.sh);}
    drain90(6*dt);X.vAcc=(X.vAcc||0)+dt;if(X.vAcc>=.5){X.vAcc=0;if(p.dashT<=0)sfx('hurt');}}else X.vAcc=0;
  for(const e of G.enemies){if(!e.alive||e.spawnT>0||STATIC.has(e.type)||EDEF[e.type].passive||e.sbk||EDEF[e.type].sbp||e.type==='eraser100'||e.type==='ebb95'||e.type==='blot95')continue;if(voidDepth100(e.x,e.y,X)>0){e.hp-=e.maxHp*.04*dt;if(e.hp<=0)kill(e);}}
  for(const it of G.pick){const d=voidDepth100(it.x,it.y,X);if(d<=0){it.v100=0;continue;}if(it.story||it.k==='frag100'||it.quest||it.anom||it.k==='chest95'||it.k==='tag95'){const a=Math.atan2(H/2-it.y,W/2-it.x);it.x+=Math.cos(a)*160*dt;it.y+=Math.sin(a)*160*dt;continue;}it.v100=(it.v100||0)+dt;if(it.v100>=2){it.life=0;if(SET.fx)part(it.x,it.y,0,-30,.5,C90.sh,2);}}
  // запись пути (и рывков — для эха)
  if(G.t-X.born<90){X.echoRecT-=dt;if(X.echoRecT<=0){X.echoRecT=.2;X.echoRec.push([p.x/W,p.y/H]);}}
  X.echoP.push({x:p.x,y:p.y,t:G.t});while(X.echoP.length&&G.t-X.echoP[0].t>24)X.echoP.shift();
  if(X.pulseLog95.length&&G.t-X.pulseLog95[0].t>26)X.pulseLog95.shift();
  if(X.hud)hudTick100(X,dt);
  if(X.witPlan)witTick100(X,dt);
  if(X.tide)tideTick100(X,dt);
  if(X.shadT>0&&G.endT<=0){X.shadT-=dt;if(X.shadT<=0){X.shadT=20;shadow100(X);}}
  shadTick100(X,dt);
  for(const e of G.enemies)if(e.alive&&e.mem100&&!e.memK){e.memK=1;e.hp*=.8;e.maxHp=e.hp;}}
// --- потеря интерфейса (X11: только 44–45 и Берег, не корпус ниже 30%, на «Лёгкой» — нет) ---
const HUD100={hp:['#hpT','#hpB'],en:['#enT','#enBar'],wave:['#misT','#sigBar'],mark:['#mini']};
const HUD100N={hp:'КОРПУС',en:'НАКОПИТЕЛЬ',wave:'ВОЛНА',mark:'КАРТА'};
function hudEls100(k){const out=[];for(const s of HUD100[k]){const el=document.querySelector(s);if(!el)continue;out.push(el.id==='hpT'||el.id==='enT'||el.id==='misT'||el.id==='hpB'?el.parentElement:el);}return out;}
function hudVis100(k){return hudEls100(k).some(el=>el.offsetParent!==null);}
function hudCss100(){if(document.getElementById('er100css'))return;const st=document.createElement('style');st.id='er100css';
  st.textContent='.er100{animation:er100o .6s forwards;pointer-events:none}.er100s{opacity:.6!important;filter:grayscale(1)}.er100r{animation:er100i .4s}@keyframes er100o{0%{opacity:1;filter:none;transform:none}55%{opacity:.5;filter:blur(1px);transform:translateX(2px)}100%{opacity:0;filter:blur(3px);transform:translateY(-4px)}}@keyframes er100i{from{opacity:0;filter:blur(2px)}to{opacity:1;filter:none}}';document.head.appendChild(st);}
function hudErase100(k){hudCss100();const soft=!!SET.noErase;for(const el of hudEls100(k)){el.classList.remove('er100r');el.classList.add(soft?'er100s':'er100');}snd90('crumble');}
function hudBack100(k){for(const el of hudEls100(k)){const was=el.classList.contains('er100');el.classList.remove('er100','er100s');if(was){el.classList.add('er100r');setTimeout(()=>el.classList.remove('er100r'),450);}}}
function clearHud100(force){const X=G.x90;let any=false;for(const k in HUD100){for(const el of hudEls100(k))if(el.classList.contains('er100')||el.classList.contains('er100s')){el.classList.remove('er100','er100s');any=true;}}
  if(X&&X.hud&&X.hud.cur){X.hud.cur=null;}if(X&&X.hudAll){X.hudAll=0;}return any;}
function hudTick100(X,dt){const H_=X.hud,p=G.player;if(G.endT>0||p.hp<=0){if(H_.cur){hudBack100(H_.cur);H_.cur=null;}return;}
  if(H_.cur==='hp'&&p.hp<G.st.maxHp*.3){hudBack100('hp');H_.cur=null;H_.t=8;return;}
  if(X.hudAll&&p.hp<G.st.maxHp*.3)hudBack100('hp');
  if(H_.cur){H_.left-=dt;if(H_.cur==='en'&&p.en>=100&&!(H_.chime>0)){H_.chime=1;snd90('chime');}if(p.en<100)H_.chime=0;if(H_.left<=0){hudBack100(H_.cur);H_.cur=null;H_.t=H_.per?H_.per-12:rnd(35,55);}return;}
  H_.t-=dt;if(H_.t<=0){const ks=['hp','en','wave','mark'].filter(k=>k!==H_.last&&hudVis100(k)&&(k!=='hp'||p.hp>=G.st.maxHp*.3));if(!ks.length){H_.t=5;return;}const k=ks[Math.random()*ks.length|0];H_.cur=H_.last=k;H_.left=12;hudErase100(k);
    floater(p.x,p.y-48,'СТЁРТО: '+HUD100N[k]+' · 12 С',C90.sh);if(!X.hint.hud){X.hint.hud=1;radioLine('БЕРЕГ',C90.sh,'Вы забываете, сколько вам осталось. Это нормально. Здесь все забывают.',.3);}}}
// --- Свидетели: держитесь рядом — летят за вами и быстрее (X13: обходят зоны стирания) ---
function witTick100(X,dt){const p=G.player;for(const q of X.witPlan){if(q.done||G.t-X.born<q.at||G.endT>0)continue;q.done=true;const L=Math.random()<.5,y=rnd(.3,.7)*H;
    const e=spawnEnemy('witness100',L?-24:W+24,y,{noAffix:true,noLoot:true,spawnT:.4,bit:q.bit,ex:L?W+40:-40,ey:rnd(.3,.7)*H});X.wit.push(e);floater(clamp(e.x,60,W-60),y-30,'СВИДЕТЕЛЬ · ДЕРЖИТЕСЬ РЯДОМ','#ffffff');snd90('frag');
    if(!X.hint.wit){X.hint.wit=1;radioLine('СВИДЕТЕЛЬ','#ffffff','Я несу то, что вы забыли. Летите рядом — я полечу за вами.',.4);}}
  X.wit=X.wit.filter(e=>e.alive);
  for(const w of X.wit){if(w.sh100>0)w.sh100-=dt;if(w.spawnT>0)continue;
    for(const b of G.eb){if(b.life<=0||b.rift)continue;if(Math.hypot(b.x-w.x,b.y-w.y)<w.r+5){b.life=0;if(w.sh100>0){w.flash=.05;continue;}witHurt100(w,b.dmg);}}
    for(const e of G.enemies){if(!e.alive||e===w||!(e.contact>0)||EDEF[e.type].passive||e.spawnT>0)continue;if(Math.hypot(e.x-w.x,e.y-w.y)<e.r+w.r&&!(e.wc100>G.t)){e.wc100=G.t+.8;if(!(w.sh100>0))witHurt100(w,e.contact);}}}}
function witHurt100(w,d){w.hp-=d;w.flash=.08;if(w.hp<=0&&w.alive){kill(w);}else if(!w.hurtHint){w.hurtHint=1;floater(w.x,w.y-24,'СВИДЕТЕЛЬ ПОД ОГНЁМ','#ffffff');}}
function witArrive100(w){const S=G.save,X=G.x90;if(!w.alive||w.arrived)return;w.arrived=1;w.alive=false;const sh=sh100();
  if(G.mode==='world'&&S&&S.story){if(w.bit>=0&&w.bit<12)sh.frag|=1<<w.bit;S.lom+=30;}const n=fragN100(sh.frag);
  floater(clamp(w.x,80,W-80),w.y-30,'ОБРЫВОК ПАМЯТИ · '+n+'/12 · +30 ЛОМА','#ffffff');snd90('fragGet');hs90(.06,0);conEvent('escort100');radioLine('ОБРЫВОК',C90.sh,FRAG100[w.bit]||'«…»',.3);}
function witAI100(e,dt){if(e.ex===undefined){e.ex=e.x<W/2?W+40:-40;e.ey=e.y;}if(e.bit===undefined)e.bit=-1;if(e.spawnT>0)return;const p=G.player;let tx=e.ex,ty=e.ey;
  const pd=Math.hypot(p.x-e.x,p.y-e.y),lead=pd<120&&p.hp>0;e.lead95=lead?Math.min(1,(e.lead95||0)+dt*3):Math.max(0,(e.lead95||0)-dt);
  if(lead){const ex=e.ex>W/2?1:-1;tx=p.x-ex*40;ty=p.y;}
  let dx=tx-e.x,dy=ty-e.y;const dl=Math.hypot(dx,dy)||1;
  // обход зон стирания по касательной
  const ahead=voidDepth100(e.x+dx/dl*70,e.y+dy/dl*70);if(ahead>0){const X=G.x90;let zx=null,zy=null,bd=1e9;for(const z of (X?X.ez:[])){const d=Math.hypot(z.x-e.x,z.y-e.y);if(d<bd){bd=d;zx=z.x;zy=z.y;}}
    if(zx!==null&&bd<260){const ax=e.x-zx,ay=e.y-zy,al=Math.hypot(ax,ay)||1,s=(ax/al)*(-dy/dl)+(ay/al)*(dx/dl)>0?1:-1;dx=-ay/al*s*dl+ax/al*dl*.4;dy=ax/al*s*dl+ay/al*dl*.4;}else dy+=(H/2-e.y)*2;}
  steer(e,dx,dy,e.spd*(e.sh100>0?1.25:1)*(1+.25*e.lead95),dt,2);if(voidDepth100(e.x,e.y)>0){const a=Math.atan2(H/2-e.y,W/2-e.x);e.x+=Math.cos(a)*90*dt;e.y+=Math.sin(a)*90*dt;}
  if(e.ex>W&&e.x>W+20||e.ex<0&&e.x<-20)witArrive100(e);}
function witT100(e){const X=G.x90;if(!X||X.sec!==9||!X.wit||!X.wit.length||!inMission()||EDEF[e.type].passive||STATIC.has(e.type)||e.sbk)return null;const p=G.player;let best=null,bd=Math.hypot(p.x-e.x,p.y-e.y);
  if(e.uid%2)return null;for(const w of X.wit){if(!w.alive||w.spawnT>0||w.sh100>0)continue;const d0=Math.hypot(w.x-e.x,w.y-e.y);if(d0>380)continue;const d=d0*.66;if(d<bd){bd=d;best=w;}}return best;}
// --- Прилив: полоса пустоты в любом направлении (в 45 — по диагонали); X03 — толкает не дольше 1,2 с и выбрасывает в проход ---
function tideFrame95(dir){let dx=0,dy=1;if(dir==='h'){dx=1;dy=0;}else if(dir==='v'){dx=0;dy=1;}else if(dir&&dir.dx!==undefined){dx=dir.dx;dy=dir.dy;}const l=Math.hypot(dx,dy)||1;dx/=l;dy/=l;const nx=-dy,ny=dx;
  const C=[[0,0],[W,0],[0,H],[W,H]];let s0=1e9,s1=-1e9,u0=1e9,u1=-1e9;for(const [x,y] of C){const s=x*dx+y*dy,u=x*nx+y*ny;s0=Math.min(s0,s);s1=Math.max(s1,s);u0=Math.min(u0,u);u1=Math.max(u1,u);}
  return {dx,dy,nx,ny,s0,s1,u0,u1};}
function tideMake95(dir,gapPt,boss){const F=tideFrame95(dir),U=F.u1-F.u0;let c;if(gapPt){c=gapPt.x*F.nx+gapPt.y*F.ny;}else c=F.u0+U*rnd(.22,.78);return Object.assign(F,{pos:-80,hit:false,c,gw:140,th:160,full:F.s1-F.s0+160,pushT:0});}
function tideIn95(B,x,y,pad){pad=pad||0;const s=x*B.dx+y*B.dy-B.s0,u=x*B.nx+y*B.ny;if(s<B.pos-B.th-pad||s>B.pos+pad)return false;if(Math.abs(u-B.c)<B.gw/2-pad)return false;return true;}
function tideTick100(X,dt){const T=X.tide,p=G.player;if(G.endT>0){T.band=null;T.bands=null;return;}
  if(!T.bands){T.next-=dt;if(T.next<=3&&!T.warn){let dirs;if(T.diag){const d1={dx:1,dy:H/W},d2={dx:-1,dy:-H/W};dirs=T.wave9?[d1,d2]:[Math.random()<.5?d1:d2];}else dirs=[Math.random()<.5?'v':'h'];
      const sb_=typeof sb100==='function'?sb100():null,hz_=sb_&&sb_.hz100&&sb_.alive?hzAt100(sb_,W/2):0;const gp=T.wave9?{x:W*rnd(.35,.65),y:H*rnd(.35,.65)}:hz_>0?{x:W*rnd(.25,.75),y:rnd(Math.min(H-110,hz_+100),H-90)}:null;T.warn={bands:dirs.map(d=>tideMake95(d,gp))};snd90('tideW');banner(T.wave9?'ДЕВЯТЫЙ ВАЛ':'ПРИЛИВ',T.wave9?'ДВА ПРИЛИВА НАВСТРЕЧУ · ОДИН ОБЩИЙ ПРОХОД':'ИЩИТЕ ПРОХОД · ИЛИ РЫВОК СКВОЗЬ');}
    if(T.next<=0&&T.warn){T.bands=T.warn.bands;T.band=T.bands[0];T.warn=null;T.n++;T.wave9=0;snd90('tide');trauma90(.35);}return;}
  let alive=0;for(const B of T.bands){B.pos+=70*dt;if(B.pos>B.full)continue;alive++;
    for(const b of G.eb)if(b.life>0&&!b.rift&&tideIn95(B,b.x,b.y))b.life=0;
    for(const b of G.pb)if(b.life>0&&tideIn95(B,b.x,b.y))b.life=0;
    if(p.hp>0&&tideIn95(B,p.x,p.y,p.r*.6)){if(p.dashT<=0){if(!T.hitN){T.hitN=1;damagePlayer(12);if(G.mc)G.mc.tide100=1;floater(p.x,p.y-34,'ПРИЛИВ · −12',C90.sh);trauma90(.2);}
        B.pushT+=dt;if(B.pushT<1.2){p.x+=B.dx*70*1.6*dt;p.y+=B.dy*70*1.6*dt;}
        else{const s=p.x*B.dx+p.y*B.dy;p.x=B.dx*s+B.nx*B.c;p.y=B.dy*s+B.ny*B.c;B.pushT=0;floater(p.x,p.y-30,'ВЫБРОШЕНО В ПРОХОД',C90.sh);snd95('fade95',p.x);if(SET.fx)for(let i=0;i<12;i++)part(p.x,p.y,vrnd3(-120,120),vrnd3(-120,120),.4,C90.sh,2);}}}
    else B.pushT=Math.max(0,B.pushT-dt*.25);
    for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||EDEF[e.type].passive||e.sbk)continue;if(tideIn95(B,e.x,e.y)){e.x+=B.dx*70*1.4*dt;e.y+=B.dy*70*1.4*dt;}}}
  if(!alive){if(!T.hitN){conEvent('tide100');if(G.mc)G.mc.tideN100=(G.mc.tideN100||0)+1;}T.bands=null;T.band=null;T.hitN=0;T.next=T.boss?16:40;}}
// совместимость с 0.9: прямоугольник полосы (для старых проверок)
function tideRect100(B){return {x:0,y:0,w:W,h:H};}
function inTide100(B,r,x,y,pad){return tideIn95(B,x,y,pad);}
// --- тени прошлых боссов в миссии 45 (X06: только ниже горизонта + 40) ---
const SHAD100=[['lek','ЛЕКАЛО','#e8d27a'],['well','ПЕРВЫЙ СИГНАЛ','#6b8cff'],['heart','СЕРДЦЕ','#ffd36b'],['flag','ПОСЛЕДНИЙ ДОВОД','#b8c4d6']];
function shadTop95(){const b=typeof sb100==='function'?sb100():null;return b?hzAt100(b,W/2)+40:0;}
function shadow100(X,pick){const p=G.player,[k,name,col]=pick||SHAD100[Math.random()*SHAD100.length|0];const tk=1.2*tl85();const q={k,name,col,t:0,tele:Math.max(.7,1.1*tk),done:false};const top=shadTop95();
  if(k==='lek'){q.x=clamp(p.x+p.vx*.5,80,W-80);q.w=130;q.y0=top;}
  if(k==='well'){q.x=Math.random()<.5?40:W-40;q.y=Math.max(top+40,rnd(.2,.8)*H);q.gaps=[rnd(0,TAU),rnd(0,TAU)];q.R=0;}
  if(k==='heart'){q.x=W/2;q.y=Math.max(top+60,H/2);q.R=0;}
  if(k==='flag'){q.x=clamp(p.x,120,W-120);q.y=Math.max(top+40,-20);}
  X.shad.push(q);snd90('shadow');tlog95('shadow100',q.tele);}
function shadTick100(X,dt){const p=G.player;for(const q of X.shad){q.t+=dt;if(q.t<q.tele)continue;const u=q.t-q.tele;
    if(q.k==='lek'){if(!q.done){q.done=true;trauma90(.25);sfx('boom');if(p.hp>0&&p.dashT<=0&&Math.abs(p.x-q.x)<q.w/2+p.r*.5&&p.y>(q.y0||0))damagePlayer(14);}if(u>.5)q.dead=1;}
    else if(q.k==='well'||q.k==='heart'){const R0=q.R;q.R+=300*dt;const d=Math.hypot(p.x-q.x,p.y-q.y);
      if(p.hp>0&&p.dashT<=0&&!q.hit&&d>R0-p.r-7&&d<q.R+p.r+7){let gap=false;if(q.gaps){const a=Math.atan2(p.y-q.y,p.x-q.x);for(const g of q.gaps)if(Math.abs(angDiff(a,g))<.3)gap=true;}if(!gap){q.hit=true;damagePlayer(q.k==='well'?10:7);}}
      if(q.R>Math.hypot(W,H))q.dead=1;}
    else if(q.k==='flag'){if(!q.done){q.done=true;const a0=Math.atan2(p.y-q.y,p.x-q.x);for(let i=0;i<9;i++)shootE(q.x,q.y+30,a0+(i-4)*.12,260,8.4,'#b8c4d6',5);}q.dead=1;}}
  X.shad=X.shad.filter(q=>!q.dead);}
// --- движение корабля ---
function drift100(X,p,dt){if(p.dashT<=0&&voidDepth100(p.x,p.y,X)>0){p.x=p.px+(p.x-p.px)*.7;p.y=p.py+(p.y-p.py)*.7;}
  if(p.dashT>0)for(const e of G.enemies){if(e.type!=='eraser100'||!e.alive||e.spawnT>0||e.ramId100===G.dashId)continue;if(segDist(p.px,p.py,p.x,p.y,e.x,e.y)<e.r+p.r){e.ramId100=G.dashId;e.stun=1.5;floater(e.x,e.y-24,'ЛАСТИК ОГЛУШЁН',C90.sh);hs90(.06,0);}}
  if(p.dashT>0)for(const e of G.enemies){if(e.type!=='fixer100'||!e.alive||!e.fx||e.cutId===G.dashId)continue;const T=e.fx;if(T.alive&&segInter(p.px,p.py,p.x,p.y,e.x,e.y,T.x,T.y)){e.cutId=G.dashId;fixCut100(e,true);}}}
// --- снаряды игрока ---
function b100Hit(b,X){if(!b.charged){for(const z of X.ez){if(z.tele>0)continue;if(Math.hypot(b.x-z.x,b.y-z.y)<z.r){b.life=0;if(SET.fx)part(b.x,b.y,0,0,.25,C90.sh,2);return true;}}
    if(X.estr95)for(const s of X.estr95){if(s.tele>0)continue;if(capD95(b.x,b.y,s.x1,s.y1,s.x2,s.y2,s.w)>0){b.life=0;return true;}}}
  return false;}
function pulse100(X,p,R){if(X.pulseLog95)X.pulseLog95.push({t:G.t,x:p.x,y:p.y});}
function targ100(e,X){if(e.hid90&&!(e.rev100>0)&&!(e.vis100>0)&&!(G.player&&Math.hypot(e.x-G.player.x,e.y-G.player.y)<220))return false;if(voidDepth100(e.x,e.y,X)>40)return false;return true;}
// --- Опечатка: нос, орудие и крылья от разных врагов; раз в 8 с переписывает часть (×2) ---
const TYPO_MV=[['ТАРАН','ram',.45],['ВЕЕР','weave',.3],['КРУГ','orbit',.35],['СКАЧОК','blink',.4],['СТРОЙ','strafe',.3],['СПИРАЛЬ','spiral',.35],['ДРЕЙФ','drift',.2],['РЫВОК','jink',.4]];
const TYPO_GUN=[['ОДИН','single',.3],['ТРОЙКА','fan3',.4],['ВЕНОК','ring',.45],['КОПЬЁ','lance',.45],['МИНА','mine',.35],['БУМЕРАН','boom',.4],['ОРБИТА','orb',.4],['ЛОКОТЬ','none',.1]];
const TYPO_HAB=[['БРОНЯ','armor',.35],['РАСКОЛ','split',.3],['ЛЕКАРЬ','heal',.4],['РЫСЬ','fast',.3],['ВЗРЫВ','boom',.25],['ЗАТЯЖКА','regen',.35],['ТЕНЬ','fade',.3],['ДВОЙНИК','twin',.35],['ЗЕРКАЛО','mirror',.35],['ЯКОРЬ','anchor',.4]];
function typoGen100(e){for(let t=0;t<20;t++){const a=TYPO_MV[Math.random()*TYPO_MV.length|0],b=TYPO_GUN[Math.random()*TYPO_GUN.length|0],c=TYPO_HAB[Math.random()*TYPO_HAB.length|0];if(a[2]+b[2]+c[2]<=1.3||t===19){e.tp={mv:a[1],gun:b[1],hab:c[1]};e.tpN=[a[0],b[0],c[0]];break;}}
  typoName95(e);typoHab95(e);e.gcd=rnd(1,2);e.hl=0;e.rwT95=8;
  const X=G.x90;if(X&&X.typoSer&&!X.typoSerDone){X.typoSerDone=1;e.tpSer=' · №'+String(serialNo85()).padStart(3,'0');typoName95(e);}}
function typoName95(e){e.tpName=e.tpN.join('-')+(e.tpSer||'');}
function typoHab95(e){if(e.tp.hab==='armor')e.armor=3;if(e.tp.hab==='fast'&&!e.fastK95){e.fastK95=1;e.spd*=1.3;}}
function typoRewrite95(e){const k=Math.random()*3|0;const L=[TYPO_MV,TYPO_GUN,TYPO_HAB][k],key=['mv','gun','hab'][k];let q;for(let i=0;i<8;i++){q=L[Math.random()*L.length|0];if(q[1]!==e.tp[key])break;}
  if(e.tp.hab==='fast'&&key==='hab'&&e.fastK95){e.fastK95=0;e.spd/=1.3;}e.tp[key]=q[1];e.tpN[k]=q[0];typoName95(e);typoHab95(e);e.glitch95=.5;weak95(e,.5,2);e.orb95=null;snd95('glitch',e.x);glyph95(e.x,e.y,5,'#b8ffe0');floater(e.x,e.y-e.r-22,'ПРАВКА · '+q[0],'#b8ffe0');}
function typoAI100(e,dt,c){const p=G.player;if(!e.tp)typoGen100(e);const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,sm=c.sm;
  if(e.glitch95>0)e.glitch95-=dt;e.rwT95-=dt;if(e.rwT95<=0){e.rwT95=8;typoRewrite95(e);}
  switch(e.tp.mv){
    case 'ram':if(e.rs==='aim'){e.vx*=.88;e.vy*=.88;e.rt-=dt;if(e.rt<=0){e.rs='go';e.rt=.5;e.vx=Math.cos(e.aim)*600;e.vy=Math.sin(e.aim)*600;}}else if(e.rs==='go'){e.rt-=dt;if(e.rt<=0)e.rs=null;}else{steer(e,pdx,pdy,e.spd*sm,dt,3);e.rc=(e.rc||2)-dt;if(e.rc<=0&&pd<450){e.rc=3;e.rs='aim';e.rt=.7*tel90('typo100');e.aim=Math.atan2(pdy,pdx);e.tl95=e.rt;tlog95('typoRam',e.rt);}}break;
    case 'weave':{const w=Math.sin(e.t*3+e.seed)*.6;steer(e,pdx/pd-pdy/pd*w,pdy/pd+pdx/pd*w,e.spd*sm,dt,3);break;}
    case 'orbit':{e.oa=(e.oa===undefined?Math.atan2(-pdy,-pdx):e.oa)+dt*e.dir*.9;const tx=p.x+Math.cos(e.oa)*220,ty=p.y+Math.sin(e.oa)*220;steer(e,tx-e.x,ty-e.y,e.spd*sm,dt,3);break;}
    case 'blink':e.bk=(e.bk||2.5)-dt;steer(e,pdx,pdy,e.spd*.6*sm,dt,2);if(e.bk<=0){e.bk=3;const a=rnd(0,TAU);explode(e.x,e.y,EDEF.typo100.col,6,.3);e.x=clamp(p.x+Math.cos(a)*240,40,W-40);e.y=clamp(p.y+Math.sin(a)*240,40,H-40);e.spawnT=.3;}break;
    case 'spiral':{e.oa=(e.oa===undefined?Math.atan2(-pdy,-pdx):e.oa)+dt*e.dir*1.4;e.sr95=Math.max(120,(e.sr95||360)-dt*40);if(e.sr95<=125)e.sr95=360;const tx=p.x+Math.cos(e.oa)*e.sr95,ty=p.y+Math.sin(e.oa)*e.sr95;steer(e,tx-e.x,ty-e.y,e.spd*sm,dt,3);break;}
    case 'drift':{const m=clamp((pd-400)/120,-1,1);steer(e,pdx/pd*m,pdy/pd*m,e.spd*.55*sm,dt,1.5);break;}
    case 'jink':{e.jk=(e.jk||1.4)-dt;const m=clamp((pd-260)/120,-1,1);steer(e,pdx/pd*m,pdy/pd*m,e.spd*sm,dt,2.5);if(e.jk<=0){e.jk=rnd(1.2,1.8);const s=Math.random()<.5?-1:1;e.vx=-pdy/pd*s*480;e.vy=pdx/pd*s*480;}break;}
    default:{const m=clamp((pd-280)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.6*e.dir,pdy/pd*m+pdx/pd*.6*e.dir,e.spd*sm,dt,3);if(Math.random()<dt*.25)e.dir*=-1;}}
  e.gcd-=dt;const a=Math.atan2(pdy,pdx);e.charging=e.gcd<.45;
  if(e.gcd<=0&&pd<720){const k=first90(e);switch(e.tp.gun){case 'single':shootE(e.x,e.y,a,280,10*k,'#b8ffe0',5);e.gcd=1.8;break;case 'fan3':for(let i=-1;i<=1;i++)shootE(e.x,e.y,a+i*.18,260,8*k,'#b8ffe0',5);e.gcd=2.2;break;
      case 'ring':for(let i=0;i<8;i++)shootE(e.x,e.y,i/8*TAU+e.t,220,7*k,'#b8ffe0',5);e.gcd=4;break;case 'lance':if(!e.ln){e.ln=.6*tel90('typo100');e.la=a;e.tl95=e.ln;}e.gcd=9;break;
      case 'mine':{inkMine95(e.x,e.y);e.gcd=4.5;break;}
      case 'boom':{const b=shootE(e.x,e.y,a,340,9*k,'#b8ffe0',6);if(b){b.boom95={t:.9,o:e};}e.gcd=2.6;break;}
      case 'orb':{if(!e.orb95)e.orb95={n:3,a:0,fl:3};e.gcd=1;break;}
      default:e.gcd=9;}}
  if(e.ln>0){e.ln-=dt;e.la+=clamp(angDiff(a,e.la),-1.2*dt,1.2*dt);if(e.ln<=0){e.ln=0;shootE(e.x,e.y,e.la,520,13*first90(e),'#ffffff',4);e.gcd=2.6;}}
  if(e.orb95){const O=e.orb95;O.a+=dt*2.6;O.fl-=dt;if(O.fl<=0&&O.n>0&&pd<500){O.fl=2.2;O.n--;const q=O.a+O.n*TAU/3;shootE(e.x+Math.cos(q)*30,e.y+Math.sin(q)*30,a,300,9*first90(e),'#b8ffe0',6);snd95('fling',e.x);if(O.n<=0){e.orb95=null;e.gcd=2;}}
    if(p.hp>0&&p.dashT<=0)for(let i=0;i<O.n;i++){const q=O.a+i*TAU/3,x=e.x+Math.cos(q)*30,y=e.y+Math.sin(q)*30;if(Math.hypot(p.x-x,p.y-y)<p.r*.6+6&&!(e.ohit95>G.t)){e.ohit95=G.t+.8;damagePlayer(8);}}}
  if(e.tp.hab==='heal'){e.hl-=dt;if(e.hl<=0){e.hl=1;for(const o of G.enemies)if(o.alive&&o!==e&&!o.sbk&&!STATIC.has(o.type)&&Math.hypot(o.x-e.x,o.y-e.y)<200)o.hp=Math.min(o.maxHp,o.hp+o.maxHp*.02);}}
  if(e.tp.hab==='regen'&&G.t-(e.hitT100||-9)>2)e.hp=Math.min(e.maxHp,e.hp+e.maxHp*.05*dt);
  if(e.tp.hab==='fade'){e.fade100=(Math.sin(e.t*1.3+e.seed)>.6);}
  if(e.tp.hab==='anchor'){e.anc95=(e.anc95||4)-dt;if(e.anc95<=.7&&!e.ancW){e.ancW=1;e.tl95=.7;snd95('tlDash',e.x);}if(e.anc95<=0){e.anc95=5;e.ancW=0;e.ancP=.8;}if(e.ancP>0){e.ancP-=dt;if(p.dashT<=0&&pd<420){p.x-=pdx/pd*120*dt;p.y-=pdy/pd*120*dt;}}}}
// бумеранг: снаряд Опечатки возвращается
function boomTick95(dt){for(const b of G.eb){if(!b.boom95)continue;const B=b.boom95;B.t-=dt;if(B.t<=0&&!B.back){B.back=1;const o=B.o;if(o&&o.alive){const a=Math.atan2(o.y-b.y,o.x-b.x),s=Math.hypot(b.vx,b.vy);b.vx=Math.cos(a)*s;b.vy=Math.sin(a)*s;b.life=Math.max(b.life,2);}}}}
// чернильные мины (X12): свои, в цвете сектора
function inkMine95(x,y){const X=G.x90;const L=X&&inMission()?(X.ink95||(X.ink95=[])):(G.wink95||(G.wink95=[]));if(L.length>=6)return;L.push({x,y,arm:.9,t:13,fuse:0});snd95('splat',x);}
function inkTick95(dt){const X=G.x90,p=G.player;const L=X&&inMission()?X.ink95:G.wink95;if(!L||!L.length||!p)return;for(const m of L){m.t-=dt;if(m.arm>0){m.arm-=dt;continue;}if(!m.fuse&&p.hp>0&&Math.hypot(p.x-m.x,p.y-m.y)<72){m.fuse=1;m.t=0;tg95({k:'zone',x:m.x,y:m.y,r:64,T:.45,dmg:12,col:C90.sh,key:'inkMine',snd:'tlZone',hitE:20});}}
  for(let i=L.length-1;i>=0;i--)if(L[i].t<=0)L.splice(i,1);}
// --- Корректор: опасный луч, рывок переворачивает ремонт, «правка» снарядов ---
function dl100(e,d){const L=e.dl||(e.dl=[]);L.push({t:G.t,d});if(L.length>8)L.shift();}
function dlSum100(e){if(!e.dl)return 0;let s=0;for(const q of e.dl)if(G.t-q.t<=3)s+=q.d;return s;}
function fixCut100(e,rev){if(!e.fx)return;const T=e.fx;if(rev&&T.alive){const h=Math.min(T.hp-1,dlSum100(T)*clamp((e.fxT||0)/1.5,.4,1));if(h>0){T.hp-=h;T.flash=.12;floater(T.x,T.y-T.r-14,'РЕМОНТ ПЕРЕВЁРНУТ · −'+Math.round(h),C90.sh);hs90(.07,0);}T.dl=[];}
  e.fx=null;e.fxT=0;e.fcd=3;e.chDmg=0;floater(e.x,e.y-24,'РЕМОНТ ПРЕРВАН',C90.sh);if(G.mc)G.mc.fixCut100=(G.mc.fixCut100||0)+1;snd90('cut');}
function fixerAI100(e,dt,c){const p=G.player;if(e.fcd>0)e.fcd-=dt;if(e.edT===undefined)e.edT=rnd(2,3.5);
  if(!e.fx&&!(e.fcd>0)){let best=null,bk=.95;for(const o of G.enemies){if(!o.alive||o===e||o.spawnT>0||o.sbk||EDEF[o.type].sbp||EDEF[o.type].passive||o.type==='fixer100')continue;const k=o.hp/o.maxHp;if(k<bk&&dlSum100(o)>0&&Math.hypot(o.x-e.x,o.y-e.y)<500){bk=k;best=o;}}if(best){e.fx=best;e.fxT=0;e.chDmg=0;}}
  if(e.fx){const T=e.fx;if(!T.alive){e.fx=null;return;}const d=Math.hypot(T.x-e.x,T.y-e.y);steer(e,T.x-e.x,T.y-e.y,e.spd*c.sm*(d>140?1.35:.25),dt,3);
    // луч жжёт
    if(d<=225&&p.hp>0&&p.dashT<=0&&segDist(e.x,e.y,T.x,T.y,p.x,p.y)<5+p.r*.55&&!(e.bh95>G.t)){e.bh95=G.t+.8;damagePlayer(10);floater(p.x,p.y-30,'ЛУЧ КОРРЕКТОРА −10',C90.sh);}
    if(d>220)e.fxT=Math.max(0,e.fxT-dt*2);
    else{e.fxT+=dt;if(e.fxT>=1.5){const h=Math.min(T.maxHp-T.hp,dlSum100(T));if(h>0){T.hp+=h;floater(T.x,T.y-22,'ИСПРАВЛЕНО',C90.sh);snd90('fix');}T.dl=[];e.fx=null;e.fcd=3;}}return;}
  // без цели — «правка»: снаряды рядом замирают и доворачивают к вам
  e.edT-=dt;if(e.edT<=0){e.edT=4;let n=0;for(const b of G.eb){if(b.rift||b.k95==='word'||b.hold95>0||b.frz95>0)continue;if(Math.hypot(b.x-e.x,b.y-e.y)<200){b.frz95=.45;b.rv95=1;b.vx0=b.vx;b.vy0=b.vy;n++;}}if(n){snd95('rewrite',e.x);floater(e.x,e.y-e.r-14,'ПРАВКА · '+n,C90.sh);tlog95('fixEdit',.45);}}
  const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,m=clamp((pd-280)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.5*e.dir,pdy/pd*m+pdx/pd*.5*e.dir,e.spd*c.sm,dt,2.5);}
// --- Эхо-призрак: путь, рывки и импульсы игрока; очереди в стиле вашего оружия ---
function echoAI100(e,dt){const X=G.x90,p=G.player;let tx=e.x,ty=e.y;const tPast=G.t-20;
  if(e.dz95>0){e.dz95-=dt;e.x+=e.vx*dt;e.y+=e.vy*dt;e.x=clamp(e.x,20,W-20);e.y=clamp(e.y,20,H-20);if(SET.fx)part(e.x,e.y,vrnd3(-30,30),vrnd3(-30,30),.3,'#e0fff4',2);return;}
  if(e.path100&&e.path100.length){const L=e.path100,i=(e.pi100+Math.floor(e.t*5))%L.length,q=L[i];tx=q.x*W;ty=q.y*H;e.src100='boss';if(q.d&&e.lastI95!==i){e.lastI95=i;echoDash95(e,tx,ty);}}
  else if(X&&X.echoSaved&&X.echoSaved.length){const i=Math.floor(e.t*5)%X.echoSaved.length,q=X.echoSaved[i];tx=q[0]*W;ty=q[1]*H;e.src100='saved';e.sd95=(e.sd95||3.5)-dt;if(e.sd95<=0){e.sd95=rnd(3.5,5);const j=(i+3)%X.echoSaved.length,q2=X.echoSaved[j];echoDash95(e,q2[0]*W,q2[1]*H);}}
  else if(X&&X.echoP.length){let q=null;for(const s of X.echoP){if(s.t<=tPast)q=s;else break;}if(q){tx=q.x;ty=q.y;e.src100='past';}
    const last=e.tp95===undefined?tPast:e.tp95;for(const ev of G.dashLog){if(ev.t>last&&ev.t<=tPast){echoDash95(e,ev.x,ev.y);break;}}if(X.pulseLog95)for(const ev of X.pulseLog95){if(ev.t>last&&ev.t<=tPast){echoPulse95(e);break;}}e.tp95=tPast;}
  const dx=tx-e.x,dy=ty-e.y,d=Math.hypot(dx,dy);if(d>2){const s=Math.min(d*4,320);e.vx=dx/d*s;e.vy=dy/d*s;e.face=Math.atan2(dy,dx);}else{e.vx*=.8;e.vy*=.8;}
  e.x+=e.vx*dt;e.y+=e.vy*dt;e.x=clamp(e.x,20,W-20);e.y=clamp(e.y,20,H-20);
  e.cd-=dt;e.charging=e.cd<.4;if(e.cd<=0&&p.hp>0){e.cd=1.7;e.bq95=3;e.bqT=0;}
  if(e.bq95>0){e.bqT-=dt;if(e.bqT<=0){e.bq95--;e.bqT=.13;const n=Math.min(3,G.st?G.st.shots:1),a=Math.atan2(p.y-e.y,p.x-e.x);for(let i=0;i<n;i++)shootE(e.x,e.y,a+(i-(n-1)/2)*.11,320,6*first90(e),'#a8b4b0',4);}}}
function echoDash95(e,tx,ty){const a=Math.atan2(ty-e.y,tx-e.x);e.vx=Math.cos(a)*1400;e.vy=Math.sin(a)*1400;e.dz95=.16;snd95('pilotDash',e.x);}
function echoPulse95(e){wv95({x:e.x,y:e.y,v:520,w:10,dmg:12,col:'#e0fff4',R:150});snd95('pilotPulse',e.x);}
// --- Пустотник: дрожание пустоты, красные глаза, три рывка зигзагом, окно ×2, охота парами ---
function hollowAI100(e,dt,c){const p=G.player;if(e.lt===undefined){e.lt=rnd(2.5,4);e.oa=Math.atan2(e.y-p.y,e.x-p.x);}
  if(e.rev100>0)e.rev100-=dt;if(e.vis100>0)e.vis100-=dt;e.hid90=!(e.rev100>0||e.vis100>0||e.ls==='go'||e.ls==='zig'||e.ls==='stop'||e.spawnT>0);
  if(e.ls==='zig'){e.zt95-=dt;if(e.zt95<=0){if(e.zn95>=3){e.ls='stop';e.stT95=1.5;e.vx=e.vy=0;weak95(e,1.5,2);e.vis100=1.6;return;}e.zn95++;const base=Math.atan2(p.y-e.y,p.x-e.x),off=e.zn95===1?0:(e.zn95%2?1:-1)*.6;e.za95=base+off;e.vx=Math.cos(e.za95)*620;e.vy=Math.sin(e.za95)*620;e.zt95=.22;e.zp95=.12;snd95('zig',e.x);}
    else if(e.zp95>0){e.zp95-=dt;if(e.zp95<=0){e.vx*=.15;e.vy*=.15;e.zt95=Math.min(e.zt95,.14);}}return;}
  if(e.ls==='stop'){e.stT95-=dt;e.vx*=.8;e.vy*=.8;if(e.stT95<=0){e.ls=null;e.lt=4;}return;}
  e.lt-=dt;const tk=.6*tel90('hollow100');
  if(e.lt<=tk&&!e.inh){e.inh=1;e.tl95=tk;snd90('inhale',clamp((e.x-p.x)/400,-1,1));e.la=Math.atan2(p.y-e.y,p.x-e.x);tlog95('hollow100',tk);}
  if(e.lt<=0){e.inh=0;e.ls='zig';e.zn95=0;e.zt95=0;tel90use('hollow100');return;}
  // пара: один отвлекает спереди, второй заходит сзади
  let R=400,ang=e.oa+dt*.6*e.dir;const mate=G.enemies.find(o=>o!==e&&o.alive&&o.type==='hollow100');if(mate){const pf=Math.hypot(p.vx,p.vy)>40?Math.atan2(p.vy,p.vx):ARCH.a24?a24Hull(p):p.ang;/* ARCH·80 A-24 */const role=e.uid<mate.uid;ang=role?pf+Math.sin(G.t*.7)*.4:pf+Math.PI+Math.sin(G.t*.5)*.5;R=role?320:280;e.oa+=angDiff(ang,e.oa)*Math.min(1,dt*1.5);}else e.oa=ang;
  const tx=p.x+Math.cos(e.oa)*R,ty=p.y+Math.sin(e.oa)*R;steer(e,tx-e.x,ty-e.y,e.spd*c.sm,dt,2.4);}
// --- Ластик: «чирк» через арену со стёртой полосой, зоны на пути игрока, окно ×1,8 ---
function eraserAI100(e,dt,c){const p=G.player,Z=ez100(),X=G.x90;const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,m=clamp((pd-250)/120,-1,1);
  if(e.sk95){const S=e.sk95;if(S.st==='warn'){e.vx*=.8;e.vy*=.8;S.t-=dt;if(S.t<=0){S.st='go';S.u=0;snd95('streak',e.x);}return;}
    S.u+=900*dt/S.L;const u=Math.min(1,S.u);e.x=S.x1+(S.x2-S.x1)*u;e.y=S.y1+(S.y2-S.y1)*u;e.vx=(S.x2-S.x1)/S.L*900;e.vy=(S.y2-S.y1)/S.L*900;if(SET.fx&&vR3()<.7)glyph95(e.x,e.y,1,C90.sh,1);
    if(X&&inMission()&&X.pil95)for(const q of X.pil95){if(q.alive&&!q.core&&Math.hypot(q.x-e.x,q.y-e.y)<q.r+e.r){pilBreak95(X,q);floater(q.x,q.y-q.r-26,'СТЁРТО ЛАСТИКОМ',C90.sh);}}
    if(u>=1){e.sk95=null;e.vx*=.1;e.vy*=.1;weak95(e,1,1.8);if(X&&inMission())X.estr95.push({x1:S.x1,y1:S.y1,x2:S.x2,y2:S.y2,w:60,t:4,tele:0});else{const L=G.wez100||(G.wez100=[]);for(let i=0;i<=4;i++){const q=i/4;L.push({x:S.x1+(S.x2-S.x1)*q,y:S.y1+(S.y2-S.y1)*q,r:32,tele:0,t:4,by:e});}}}
    return;}
  steer(e,pdx/pd*m-pdy/pd*.6*e.dir,pdy/pd*m+pdx/pd*.6*e.dir,e.spd*c.sm,dt,2.5);if(Math.random()<dt*.3)e.dir*=-1;
  e.skT95=(e.skT95===undefined?rnd(3,5):e.skT95)-dt;
  if(e.skT95<=0&&pd<640&&p.hp>0){e.skT95=6.5;const a=Math.atan2(pdy,pdx),L=Math.min(700,pd+260);let x2=e.x+Math.cos(a)*L,y2=e.y+Math.sin(a)*L;if(!G.world){x2=clamp(x2,30,W-30);y2=clamp(y2,30,H-30);}
    const T=.7*tel90('eraser100');e.sk95={st:'warn',t:T,x1:e.x,y1:e.y,x2,y2,L:Math.hypot(x2-e.x,y2-e.y)||1};tg95({k:'line',x:e.x,y:e.y,x2,y2,w:60,T,dmg:0,noHit:true,col:C90.sh,src:e,key:'eraser100',telK:false,fx:false});return;}
  e.zt=(e.zt===undefined?rnd(1.5,3):e.zt)-dt;if(e.zt<=0){e.zt=5;if(Z.filter(z=>z.by&&z.by.type==='eraser100').length<3&&pd<700){const x=G.world?p.x+p.vx*.5:clamp(p.x+p.vx*.5,60,W-60),y=G.world?p.y+p.vy*.5:clamp(p.y+p.vy*.5,60,H-60);
      Z.push({x,y,r:110,tele:Math.max(.45,.6*tel90('eraser100')*tl85()*1.2),t:3,by:e});tel90use('eraser100');snd90('eraseT');}}}
// --- Безымянный: «взгляд» в ответ — луч по линии прицела, «стёртая подпись», окно без брони ---
// буквы «стёртой подписи» — штрихами: снаряды стоят в вершинах, между ними тянется гаснущая чернильная линия
const SIGN95={Ж:[[[0,-1],[0,0],[0,1]],[[-1,-1],[-.5,-.5],[0,0]],[[-1,1],[-.5,.5],[0,0]],[[1,-1],[.5,-.5],[0,0]],[[1,1],[.5,.5],[0,0]]],
  Я:[[[.6,-1],[.6,-.1],[.6,1]],[[.6,-1],[-.2,-1],[-.7,-.55],[-.2,-.1],[.6,-.1]],[[-.1,-.1],[-.4,.45],[-.7,1]]],
  Ф:[[[0,-1],[0,0],[0,1]],[[0,-.55],[-.65,-.45],[-.85,0],[-.65,.45],[0,.55],[.65,.45],[.85,0],[.65,-.45],[0,-.55]]],
  Ш:[[[-1,-1],[-1,0],[-1,1],[0,1],[1,1],[1,0],[1,-1]],[[0,-1],[0,0],[0,1]]]};
function signShoot95(e,a){const keys=Object.keys(SIGN95),k=keys[Math.random()*keys.length|0],L=SIGN95[k],S=30,cu=Math.cos(a-Math.PI/2),su=Math.sin(a-Math.PI/2),cv=Math.cos(a),sv=Math.sin(a),made={},strokes=[];
  for(const st of L){const row=[];for(const [u,v] of st){const key=u+','+v;let b=made[key];if(!b){const ox=e.x+cv*40+cu*u*S+cv*v*S,oy=e.y+sv*40+su*u*S+sv*v*S;b=shootE(ox,oy,a,230,8*first90(e),'#cfe0da',5);made[key]=b;}if(b)row.push(b);}strokes.push(row);}
  const Ls=G.x90&&inMission()?(G.x90.sig95||(G.x90.sig95=[])):null;if(Ls){if(Ls.length>6)Ls.shift();Ls.push({k,strokes,t0:G.t});}floater(e.x,e.y-e.r-18,'ПОДПИСЬ · '+k,'#cfe0da');}
function signDraw95(){const X=G.x90;if(!X||!X.sig95||!X.sig95.length)return;X.sig95=X.sig95.filter(S=>S.strokes.some(r=>r.some(b=>b.life>0)));ctx.lineCap='round';ctx.lineJoin='round';
  for(const S of X.sig95){const a=clamp(1-(G.t-S.t0)/1.8,.14,1);ctx.strokeStyle=rgba90('#cfe0da',.55*a);ctx.lineWidth=3;for(const r of S.strokes){ctx.beginPath();let pen=false;for(const b of r){if(b.life>0){if(pen)ctx.lineTo(b.x,b.y);else ctx.moveTo(b.x,b.y);pen=true;}else pen=false;}ctx.stroke();}}ctx.lineCap='butt';ctx.lineJoin='miter';}
function nonameAI100(e,dt,c){const p=G.player;const tg=G.tg90===e;if(e.bm95){const B=e.bm95;B.t-=dt;e.vx*=.85;e.vy*=.85;if(B.t<=0){e.bm95=null;}return;}
  e.look=clamp((e.look||0)+(tg?dt:-2*dt),0,5);e.noBar90=1;
  if(e.look>=5&&!(e.bmCd95>G.t)&&p.hp>0){e.bmCd95=G.t+6;const a=Math.atan2(p.y-e.y,p.x-e.x),T=1;e.bm95={t:T+.3};snd95('beam',e.x);floater(e.x,e.y-e.r-16,'ОН СМОТРИТ В ОТВЕТ',C90.sh);
    tg95({k:'line',x:e.x,y:e.y,x2:e.x+Math.cos(a)*1500,y2:e.y+Math.sin(a)*1500,w:34,T,dmg:18,col:'#e8fff6',src:e,key:'noname100',snd:false,on:()=>{snd95('beamFire',e.x);trauma90(.25);e.look=0;weak95(e,2,1.5);e.arm95=2;}});return;}
  if(e.arm95>0)e.arm95-=dt;
  const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,m=clamp((pd-300)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.4*e.dir,pdy/pd*m+pdx/pd*.4*e.dir,e.spd*c.sm,dt,2);
  e.cd-=dt;e.charging=e.cd<.5*tel90('noname100');if(e.cd<=0){e.cd=3.2;tel90use('noname100');tlog95('nonameSign',.5);signShoot95(e,Math.atan2(pdy,pdx));snd95('sign',e.x);}}
function ai100(e,dt,c){switch(e.type){
    case 'eraser100':eraserAI100(e,dt,c);return true;
    case 'hollow100':hollowAI100(e,dt,c);return true;
    case 'witness100':witAI100(e,dt);return true;
    case 'typo100':typoAI100(e,dt,c);return true;
    case 'fixer100':fixerAI100(e,dt,c);return true;
    case 'echo100':echoAI100(e,dt);return true;
    case 'noname100':nonameAI100(e,dt,c);return true;
    case 'tide100':e.alive=false;return true;}
  return false;}
function hurt100(e,dmg,src){switch(e.type){
    case 'witness100':if(e.sh100>0||src.pulse)return 0;if(!e.pHint){e.pHint=1;floater(e.x,e.y-24,'НЕ СТРЕЛЯЙТЕ В СВИДЕТЕЛЯ','#ffffff');}return dmg*.3;
    case 'fixer100':if(e.fx){e.chDmg=(e.chDmg||0)+dmg;if(e.chDmg>=e.maxHp*.15)fixCut100(e);}return dmg;
    case 'noname100':return e.arm95>0?dmg:dmg*(1-Math.min(.7,.15*(e.look||0)));
    case 'typo100':e.hitT100=G.t;if(e.tp&&e.tp.hab==='mirror'){e.mir95=(e.mir95||0)+1;if(e.mir95%5===0){const p=G.player;shootE(e.x,e.y,Math.atan2(p.y-e.y,p.x-e.x),330,7,'#e0fff4',5);e.shieldFlash=.12;snd95('shieldHit',e.x);return 0;}}
      if(e.tp&&e.tp.hab==='twin'&&!e.tw95&&e.hp-dmg<e.maxHp*.5&&e.hp-dmg>0&&G.enemies.filter(o=>o.alive&&o.type==='typo100').length<6){e.tw95=1;const n=spawnEnemy('typo100',e.x+10,e.y+10,{noAffix:true,noLoot:true,spawnT:.3,zone:e.zone,noCap95:1,tw95:1});n.hp=n.maxHp=Math.max(1,(e.hp-dmg)*.5);n.tp=Object.assign({},e.tp);n.tpN=e.tpN.slice();n.tpName=e.tpName;n.gcd=1.5;n.hl=0;n.rwT95=8;floater(e.x,e.y-e.r-20,'ДВОЙНИК',C90.sh);snd95('glitch',e.x);}return dmg;
    case 'hollow100':if(e.hid90){e.vis100=Math.max(e.vis100||0,.6);}return dmg;}
  return dmg;}
function kill100(e,silent){switch(e.type){
    case 'witness100':if(!e.arrived&&!silent){const S=G.save;if(G.mode==='world'&&S&&S.story&&e.bit>=0&&e.bit<12)sh100().lostFrag|=1<<e.bit;floater(e.x,e.y-28,'ОБРЫВОК ПОТЕРЯН',C90.red);snd90('lost');if(G.mc)G.mc.witLost100=1;}break;
    case 'typo100':if(!silent){const S=G.save;if(G.mode==='world'&&S&&S.story){S.story.typo100=(S.story.typo100||0)+1;if(S.story.typo100>=30)own85('typo100');}
      if(e.tp&&e.tp.hab==='split')for(let i=0;i<2;i++){const m=spawnEnemy('mite',e.x,e.y,{noAffix:true,noLoot:true,zone:e.zone});const a=rnd(0,TAU);m.vx=Math.cos(a)*240;m.vy=Math.sin(a)*240;}
      if(e.tp&&e.tp.hab==='boom')mineBlast({x:e.x,y:e.y,alive:true},70,12);}break;
    case 'fixer100':e.fx=null;break;
    case 'noname100':if(!silent&&(e.look||0)<=3)conEvent('look100');break;}}

// ===== 0.9.5: босс сектора IX — «Сердце» 2.0 (комната 42) =====
['heart90','hvalve90','hkey90','thromb90'].forEach(k=>SB85T.add(k));HOST85.add('heart90');
SB_NAMES.heart='СЕРДЦЕ';SB_FLAG.heart='heart42';SB_FLAG_M[42]='heart42';
SB_DEATH.heart=['СЕРДЦЕ ВСТАЛО','СЕКТОР IX ПРОЙДЕН','Я построил Ковчег, чтобы кто-то долетел. Я не думал, что он будет лететь вечно.'];
const HEART_PH=['РИТМ','АРИТМИЯ','ДВОЙНОЙ УДАР','ОСТАНОВКА'],HEART_BPM=[50,70,90,60];
function heartGeo(b){if(b.gw===W&&b.gh===H)return;b.gw=W;b.gh=H;b.cx=W/2;b.cy=H/2;b.R=.46*Math.min(W,H);b.k=clamp(b.R/330,.7,1.2);b.x=b.cx;b.y=b.cy;b.r=52*b.k;b.floor95=null;
  b.ves=[45,135,225,315].map((d,i)=>{const a=d*Math.PI/180;return {i,a,shut:(b.ves&&b.ves[i]?b.ves[i].shut:0),dead:(b.ves&&b.ves[i]?b.ves[i].dead:false)};});
  if(b.parts)for(const q of b.parts){if(!q.alive)continue;if(q.type==='hvalve90'){const a=b.ves[q.vi].a;q.x=b.cx+Math.cos(a)*(b.r+30*b.k);q.y=b.cy+Math.sin(a)*(b.r+30*b.k);}
    if(q.type==='hkey90'){const a=-Math.PI/2+q.ki*TAU/b.keyN+(b.keyA96||0);q.x=b.cx+Math.cos(a)*150*b.k;q.y=b.cy+Math.sin(a)*150*b.k;q.r=34*b.k;}}}
function heartPer(b){return 60/b.tempo;}
function heartSys(b){return Math.min(.35,b.btN*.4);}
function heartPerfW(b){return Math.min(.3,b.btN*.36);}
function heartInSys(b){return b.bt<heartSys(b)&&b.phase<4;}
function heartInPerf(b){return b.phase<4&&b.btN-b.bt<=heartPerfW(b);}
// очередь будущих ударов: лента тактов показывает их заранее (аритмия видна до того, как случится)
function heartQ95(b){const Q=b.q95||(b.q95=[]);while(Q.length<6)Q.push({d:heartPer(b),arr:0});return Q;}
function heartPerfBeat95(){const b=G.sb;if(!b||!b.alive||b.sbk!=='heart'||b.st!=='fight'||b.phase>=4)return 0;return heartInPerf(b)?b.beatN+1:0;}
SBX.heart={K:1.3,th:[.7,.4,.15],mc:'heart90',
  spawn(){ambSting('boss');radioClear();const b=spawnEnemy('heart90',W/2,H/2,{noAffix:true,noLoot:true});sb85Init(b,'heart',3.4);banner('СЕРДЦЕ КОВЧЕГА','ФАЗА 0 · ПРИСЛУШАЙТЕСЬ');
    radioLine('КОВЧЕГ',C90.ark,'Посторонний в сердечной камере. Пассажиры спят. Ритм — пятьдесят.',.8);return b;},
  init(b){b.gw=0;heartGeo(b);Object.assign(b,{tempo:50,bt:0,btN:1.2,beatN:0,waves:[],arr:null,arrT:18,phagoT:8,thrT:6,thr:null,keys:[],keyI:0,keyN:rk90()<=0?3:4,keyHit:false,keyWin:false,p4T:0,p4miss:0,miss:0,launch:0,launches:0,
      p4auto:false,perfN:0,perfT:-9,perfHint:0,lit:0,sysK:0,karr:0,ally:false,nextGaps:null,curGaps:null,dbl:0,scT:0,subOn:false,openK:0,hitT0:-9,bgT:0,
      q95:[],combo:0,comboLast:-9,comboBuff:1,nearT:0,whipN:0,leukT:18,fibT:20,fib:0,fibI:0,bleed:[],dry:0,autoK:0,chunkN:0,swell:0,flashP:0,crack:0,atkK95:rk90()>=2?1.15:1});
    b.contact=0;b.ghost=false;},
  phase(b){const X=x85();b.tempo=HEART_BPM[b.phase-1]||60;b.waves=[];b.arr=null;b.q95=[];b.comboBuff=1;b.combo=0;hs90(.25,1);snd95('phase95');const XX=G.x90;if(XX){XX.tg95=[];}
    if(b.phase===2){banner('СЕРДЦЕ · ФАЗА 2','АРИТМИЯ · КЛАПАНЫ СТРЕЛЯЮТ · ПРОХОДЫ ПЛЫВУТ');b.gth96=b.ves[0].a;b.gdir96=1;b.gfl96=8;radioLine('КОВЧЕГ',C90.ark,'Ритм нарушен. Подключаю клапаны.',.4);
      b.ves.forEach((v,i)=>{const q=spawnEnemy('hvalve90',b.cx,b.cy,{noAffix:true,noLoot:true,spawnT:.8,host85:b,vi:i,keep85:1});q.hp=q.maxHp=Math.round(b.maxHp*.04);q.r=20*b.k;b.parts.push(q);});heartGeo(Object.assign(b,{gw:0}));b.arrT=10;b.phagoT=6;
      if(storyFlag('fleet27')==='engine')b.karr=8;}
    if(b.phase===3){banner('СЕРДЦЕ · ФАЗА 3','ДВОЙНОЙ УДАР · ПРОХОДЫ ДРЕЙФУЮТ');radioLine('КОВЧЕГ',C90.ark,'Тахикардия. Сгустки — к сердцу.',.4);for(const q of b.parts)if(q.type==='hvalve90'&&q.alive)kill(q,true);b.thrT=5;b.fibT=16;b.gth96=b.ves[0].a;b.gdir96=1;b.gfl96=8;b.nextGaps=heartGaps(b,1);}
    if(b.phase===4){banner('СЕРДЦЕ ВСТАЛО','КАМЕРУ ЗАЛИВАЕТ · ПРОЛЕТАЙТЕ КЛЮЧИ В ТАКТ');b.lN96=rk90()<=0?2:3;b.keyA96=0;b.rot96=0;b.fin96=0;radioLine('КОВЧЕГ',C90.ark,'Остановка. Затопление камеры. Ручной запуск: ключи по порядку, в такт. Запусков нужно '+b.lN96+'.',.4);
      if(b.thr&&b.thr.alive)kill(b.thr,true);b.thr=null;for(const o of G.enemies)if(o.alive&&!o.host85&&o!==b&&!EDEF[o.type].passive)kill(o,true);b.bleed=[];
      for(let i=0;i<b.keyN;i++){const q=spawnEnemy('hkey90',b.cx,b.cy,{noAffix:true,noLoot:true,spawnT:.8,host85:b,ki:i,keep85:1,ghost:true});q.hp=q.maxHp=1e6;q.contact=0;b.parts.push(q);b.keys.push(q);}
      heartGeo(Object.assign(b,{gw:0}));b.keyI=0;b.p4T=0;b.lastL90=0;b.bt=0;b.btN=heartPer(b);b.dry=b.R;snd90('stop');snd95('flood',b.cx);trauma90(.5);}},
  hurt(b,e,dmg,src){
    if(e===b){if(b.phase>=4){const L=b.launch>0;if(L&&b.fin96)return 0;pool85(b,dmg*(L?(b.autoK?1.4:2.5):.15),L?heartQuota96(b,Math.max(1,b.launches)):heartQuota96(b,b.launches+1)+.01,e);if(L&&!b.fin96&&b.hp<=b.maxHp*heartQuota96(b,Math.max(1,b.launches))+1&&b.launch>.7)b.launch=.7;if(L&&G.t-(b.hsL||0)>.5){b.hsL=G.t;hsWeak95();}if(!L&&!b.floorHint2){b.floorHint2=1;floater(b.cx,b.cy-b.r-40,'СЕРДЦЕ СТОИТ · ЗАПУСТИТЕ КЛЮЧАМИ','#ffffff');}return 0;}
      let K=1;const perfB=src.bt95||(heartInPerf(b)&&!src.drone?b.beatN+1:0);if(heartInSys(b)&&!src.bt95)K=.15;else if(perfB){K=(b.arr||b.curArr95)?2:1.6;heartPerfect(b,perfB);}
      const nv=b.parts.filter(q=>q.alive&&q.type==='hvalve90').length;K*=(1-.12*nv)*b.comboBuff;pool85(b,dmg*K,0,e);return 0;}
    if(e.type==='hkey90')return 0;
    if(e.type==='hvalve90'||e.type==='thromb90'){const d=Math.min(dmg,e.hp);pool85(b,d*.7,0,null);return dmg;}
    return dmg;},
  targ(b,e){if(e.type==='hkey90')return false;if(e===b)return b.st==='fight';return true;},
  auto(p,b){if(b.phase>=4)return targetable(b)?b:null;
    if(b.thr&&b.thr.alive&&targetable(b.thr))return b.thr;let best=null,bd=1e9;for(const q of b.parts){if(!q.alive||q.type!=='hvalve90'||!targetable(q))continue;const d=Math.hypot(q.x-p.x,q.y-p.y);if(d<bd){bd=d;best=q;}}if(best&&bd<700)return best;return targetable(b)?b:null;},
  hud(b,k){if(b.st==='dying')return k+' · ВСТАЛО';if(b.st==='final')return k+' · ВЫБОР';if(b.st==='scene')return k+' · КОВЧЕГ';if(b.st==='enter')return k;
    if(b.phase>=4)return b.launch>0?'СЕРДЦЕ ОТКРЫТО · УРОН ×'+(b.autoK?'1,4':'2,5'):'КЛЮЧИ · ЗАПУСКИ '+b.launches+'/'+(b.lN96||2);if(b.arr||b.curArr95)return 'АРИТМИЯ · В ТАКТ ×2';return HEART_PH[b.phase-1]+' · ТЕМП '+b.tempo+(b.combo>1?' · КОМБО ×'+b.combo:'')+(b.comboBuff>1?' · +10%':'');},
  strip(b){if(b.st==='enter')return {l:'СЕРДЦЕ КОВЧЕГА · ПРИСЛУШАЙТЕСЬ К РИТМУ',k:null,lc:C90.ark};if(b.st==='scene')return {l:'КОВЧЕГ · ГОЛОС',k:null,lc:C90.warm};
    if(b.st==='final')return {l:b.prev85?'ВЫ УЖЕ СДЕЛАЛИ ВЫБОР · ЛЕТИТЕ К ПРИЧАЛУ':'РЕШИТЕ ЗА СПЯЩИХ',k:null,lc:C90.warm};
    const ph=clamp(b.bt/b.btN,0,1);
    if(b.phase>=4)return {l:(b.launch>0?'ЗАПУСК · ':'КЛЮЧИ ')+Math.min(b.keyI,b.keyN)+'/'+b.keyN+' · ЗАЛИВАЕТ '+Math.round((1-b.dry/b.R)*100)+'%',k:b.launch>0?b.launch/4:ph,col:b.launch>0?'#ffffff':C90.warm,r:'ЗАПУСКИ '+b.launches+'/'+(b.lN96||2)};
    if(b.phase===3&&b.thr&&b.thr.alive){const d=Math.hypot(b.thr.x-b.cx,b.thr.y-b.cy),k0=clamp((d-b.r)/(b.R*.85-b.r),0,1);return {l:'СГУСТОК ПОЛЗЁТ К СЕРДЦУ · СБЕЙТЕ',k:k0,col:C90.red,r:'ТЕМП '+b.tempo};}
    if(b.phase===2)return {l:'КЛАПАНЫ '+b.parts.filter(q=>q.alive&&q.type==='hvalve90').length+'/4 · '+((b.arr||b.curArr95)?'АРИТМИЯ':'АРИТМИЯ ЧЕРЕЗ '+Math.ceil(Math.max(0,b.arrT))),k:ph,col:(b.arr||b.curArr95)?'#ff9a4d':C90.ark,r:'КОМБО ×'+b.combo};
    return {l:'РИТМ · В ТАКТ '+b.perfN+(b.combo>1?' · КОМБО ×'+b.combo:''),k:ph,col:heartInPerf(b)?'#ffffff':C90.ark,r:'ТЕМП '+b.tempo};},
  update(b,dt){heartGeo(b);const p=G.player;const rdt=G.rdtU96>0?(G.rdtU96--,G.rdt90||dt):dt,A=atk95(b);
    for(const v of b.ves)if(v.shut>0)v.shut-=dt;if(b.swell>0)b.swell-=dt;if(b.flashP>0)b.flashP-=dt;
    if(b.st==='enter'){b.timer-=dt;b.lit=Math.min(1,b.lit+dt/3);heartBeatTick(b,rdt,true);if(b.timer<=0){b.st='fight';b.phT=0;banner('СЕРДЦЕ · ФАЗА 1','РИТМ · БЕЙТЕ ЗА МИГ ДО УДАРА');heartAlly(b);}return;}
    if(b.st==='scene'||b.st==='final'){heartScene(b,dt);return;}
    b.phT+=dt;heartBeatTick(b,rdt,false);heartWaves(b,dt);
    if(b.launch>0){heartFinTick96(b,dt);if(b.st!=='fight')return;b.launch-=dt;b.openK=Math.min(1,b.openK+dt*4);if(b.launch<=0){b.launch=0;b.autoK=0;heartSeq96(b);}}else b.openK=Math.max(0,b.openK-dt*3);
    {const L=Math.max(0,1-b.hp/b.maxHp);b.crack=L>.75?4:L>.55?3:L>.35?2:L>.15?1:0;}
    if(b.tr>0)return;
    // толчок: стоять вплотную дольше 2 с нельзя
    if(p&&p.hp>0&&b.phase<4){const d=Math.hypot(p.x-b.cx,p.y-b.cy);if(d<140*b.k)b.nearT+=dt;else b.nearT=Math.max(0,b.nearT-dt*2);
      if(b.nearT>=2){b.nearT=0;b.swell=.6;tg95({k:'zone',x:b.cx,y:b.cy,r:140*b.k,T:.55,dmg:14,kb:170,col:C90.blood,src:b,key:'heartShove',snd:'tlRing',on:()=>{snd95('shove',b.cx);trauma90(.3);}});floater(b.cx,b.cy-b.r-20,'ТОЛЧОК!',C90.blood);}}
    // кровотечение из разбитых клапанов
    for(const q of b.bleed){q.t-=dt;if(p&&p.hp>0&&Math.hypot(p.x-q.x,p.y-q.y)<q.r&&p.dashT<=0){drain90(5*dt);G.slowP95=Math.max(G.slowP95||0,.1);}}b.bleed=b.bleed.filter(q=>q.t>0);
    if(b.phase<=3){b.leukT-=dt*A;if(b.leukT<=0){b.leukT=b.phase===1?18:24;if(G.enemies.filter(o=>o.alive&&o.type==='hunt95').length<3){const v=b.ves[Math.random()*4|0];const e=spawnEnemy('hunt95',b.cx+Math.cos(v.a)*b.R*.9,b.cy+Math.sin(v.a)*b.R*.9,{noAffix:true,noLoot:true,spawnT:.6,packN95:2});}}}
    if(b.phase===2){heartDrift96(b,dt);b.arrT-=dt*A;if(b.arrT<=0){b.arrT=18;const Q=heartQ95(b),per=heartPer(b);Q.splice(2,0,{d:per*.6,arr:1},{d:per*1.4,arr:1},{d:per*.8,arr:1});floater(b.cx,b.cy-b.r-50,'АРИТМИЯ НА ЛЕНТЕ · В ТАКТ ×2','#ff9a4d');snd90('arr');}
      b.phagoT-=dt;if(b.phagoT<=0){b.phagoT=12;if(G.enemies.filter(o=>o.alive&&o.type==='phago90').length<3){const v=b.ves[Math.random()*4|0];spawnEnemy('phago90',b.cx+Math.cos(v.a)*b.R*.9,b.cy+Math.sin(v.a)*b.R*.9,{noAffix:true,noLoot:true,spawnT:.6});}}
      if(b.karr>0){b.karr-=dt;if(b.karr<=0){b.karr=-1;let vi=0,bd=1e9;b.ves.forEach((v,i)=>{const d=Math.abs(angDiff(Math.atan2(p.y-b.cy,p.x-b.cx),v.a));if(d<bd){bd=d;vi=i;}});b.ves[vi].shut=10;radioLine('КАРР','#b8c4d6','Держу сосуд двигателем. Десять секунд — бей!',.1);floater(b.cx+Math.cos(b.ves[vi].a)*b.R*.7,b.cy+Math.sin(b.ves[vi].a)*b.R*.7,'КАРР ДЕРЖИТ СОСУД','#b8c4d6');}}}
    if(b.phase===3){heartDrift96(b,dt);b.thrT-=dt*A;if(b.thrT<=0&&!(b.thr&&b.thr.alive)){b.thrT=14;const a=rnd(0,TAU),d=b.R*.85;const q=spawnEnemy('thromb90',b.cx+Math.cos(a)*d,b.cy+Math.sin(a)*d,{noAffix:true,noLoot:true,spawnT:.6,host85:b});q.hp=q.maxHp=Math.round(b.maxHp*.03);q.r=18*b.k;b.thr=q;b.parts.push(q);floater(q.x,q.y-30,'СГУСТОК ПОЛЗЁТ К СЕРДЦУ',C90.red);snd90('pud');}
      if(b.thr&&b.thr.alive&&b.thr.spawnT<=0&&Math.hypot(b.thr.x-b.cx,b.thr.y-b.cy)<b.r+b.thr.r+8){const cap=b.maxHp*b.th[1],h=Math.min(b.maxHp*.02,Math.max(0,cap-b.hp));b.hp+=h;b.tempo=Math.min(120,b.tempo+10);b.q95=[];b.thr.alive=false;floater(b.cx,b.cy-b.r-40,'СГУСТОК ВОШЁЛ · +2% · ТЕМП '+b.tempo,C90.red);snd90('heal');b.thr=null;}
      b.fibT-=dt*A;if(b.fibT<=0&&!(b.fib>0)){b.fibT=20;b.fib=3;b.fibI=0;b.fibA96=rnd(0,TAU);banner('ФИБРИЛЛЯЦИЯ','3 СЕКУНДЫ · ПРОХОД — ПО ОРАНЖЕВОЙ СТРЕЛКЕ');snd95('fib',b.cx);}
      if(b.fib>0){b.fib-=dt;b.fibI-=dt;if(b.fibI<=0){b.fibI=.3;const a=(b.fibA96!==undefined?b.fibA96:rnd(0,TAU))+rnd(-.1,.1);b.waves.push({r:b.r,v:400*b.k,gaps:[{a,w:70*Math.PI/180}],hit:false,dmg:6,thin:1,gd:0});}}}
    if(b.phase>=4){if(b.rot96&&b.launch<=0){b.keyA96=(b.keyA96||0)+b.rot96*dt;heartKeyPos96(b);}heartKeyTouch(b);heartKeyCheck(b);b.p4T+=dt;
      if(b.launch<=0){b.dry=Math.max(220*b.k,b.dry-(b.R-220*b.k)/Math.max(18,40-9*b.launches)*dt);if(p&&p.hp>0&&Math.hypot(p.x-b.cx,p.y-b.cy)>b.dry){drain90(4*dt);if(!b.floodHint){b.floodHint=1;floater(p.x,p.y-40,'КРОВЬ · 4 УРОНА В СЕКУНДУ',C90.blood);}}}
      if(b.launch<=0&&b.p4T-(b.lastL90||0)>60){heartLaunch(b,true);}}
    b.parts=b.parts.filter(q=>q.alive);},
  final(b){b.waves=[];b.arr=null;b.launch=0;b.scT=0;b.subOn=false;b.bleed=[];b.dry=b.R;const X=G.x90;if(X)X.tg95=[];for(const q of b.parts)if(q.alive&&q.type!=='hkey90')kill(q,true);for(const q of b.keys)if(q.alive){q.alive=false;}b.keys=[];banner('СЕРДЦЕ ВСТАЛО','КОВЧЕГ СЛУШАЕТ');snd90('final');},
  opts(b){return heartWakeOk()?['stop','pulse','wake']:['stop','pulse'];},
  choose(b,ch,world,prev){heartChoose(b,ch,world,prev);},
  pulse(b,p,R){if(b.st!=='fight')return;for(const v of b.ves){if(v.shut>0)continue;const mx=b.cx+Math.cos(v.a)*b.R*.72,my=b.cy+Math.sin(v.a)*b.R*.72;if(Math.hypot(p.x-mx,p.y-my)<R+80){v.shut=10;floater(mx,my-24,'СОСУД ПЕРЕЖАТ · 10 С',C90.ark);snd90('valve');}}},
  drift(b,p,dt){heartGeo(b);if(b.st!=='fight'&&b.st!=='enter')return;const dx=p.x-b.cx,dy=p.y-b.cy,d=Math.hypot(dx,dy)||1;
    if(b.phase<4&&b.st==='fight'&&p.dashT<=0){const sys=heartInSys(b);for(const v of b.ves){if(v.shut>0||v.dead)continue;const ux=Math.cos(v.a),uy=Math.sin(v.a),along=dx*ux+dy*uy,perp=Math.abs(-dx*uy+dy*ux);
        if(along>b.r+20&&perp<55*b.k){const s=180*b.k*(1-perp/(55*b.k))*(sys?1:-.55);p.x+=ux*s*dt;p.y+=uy*s*dt;}}}
    const lim=b.R-p.r,dd=Math.hypot(p.x-b.cx,p.y-b.cy);if(dd>lim){p.x=b.cx+(p.x-b.cx)/dd*lim;p.y=b.cy+(p.y-b.cy)/dd*lim;}
    const inner=b.r*(1+(b.swell>0?.3*Math.sin(Math.min(1,b.swell/.6)*Math.PI):0))+p.r+4;if(dd<inner&&dd>0){p.x=b.cx+(p.x-b.cx)/dd*inner;p.y=b.cy+(p.y-b.cy)/dd*inner;}},
  floorTxt(b){return b.phase>=4&&!(b.launch>0)?'СЕРДЦЕ СТОИТ · ЗАПУСТИТЕ КЛЮЧАМИ':null;},
  under(b,t){heartUnder(b,t);},draw(b,t){heartDraw(b,t);},top(b,t){heartTop(b,t);},dying(b,dt,t0){heartDying(b,dt,t0);},
  music(b,T){if(b.st==='fight'||b.st==='enter'){T.id='b42';T.I=b.st==='enter'?.2:b.phase>=4?.1+.22*Math.min(b.keyI,4)+(b.launch>0?.3:0):.7+.08*b.phase;T.ext.bpmAdd=b.tempo-SC_.b42.bpm;T.ext.ph90=b.phase;T.ext.arr90=!!(b.arr||b.curArr95);}
    else{T.id='b42';T.I=.12;T.ext.bpmAdd=-20;T.ext.ph90=5;T.ext.fin90=b.choice||null;}}};
function heartAlly(b){const A=ark90();if(G.mode==='world'&&A.woke>=4&&!x85().ally){const p=G.player;x85().ally={kind:'pass',x:p.x-60,y:p.y+40,a:0,cd:1,t:90};radioLine('ПАССАЖИР',C90.pil,'Я из тех, кого вы разбудили. Помогу, пока сердце бьётся.',.8);floater(p.x,p.y-50,'ПАССАЖИР · СОЮЗНИК НА 90 С',C90.pil);}}
function heartBleed95(b,vi){const v=b.ves[vi];if(!v)return;b.bleed.push({x:b.cx+Math.cos(v.a)*(b.R-40*b.k),y:b.cy+Math.sin(v.a)*(b.R-40*b.k),r:70*b.k,t:15,t0:15});}
// --- удары сердца ---
function heartBeatTick(b,dt,soft){b.bt+=dt;if(b.bt<b.btN)return;b.bt-=b.btN;b.beatN++;
  const Q=heartQ95(b),nx=Q.shift();b.btN=nx.d;b.curArr95=nx.arr;b.arr=nx.arr?{}:null;heartQ95(b);
  if(b.beatN-b.comboLast>2&&b.combo>0){b.combo=0;}
  if(b.phase>=4&&b.st==='fight'){snd90('tick',b.keys[b.keyI]?1:0);return;}
  snd90('beat',soft?.5:1);b.sysK=1;b.flashC95=.12;if(soft){trauma90(.05);return;}trauma90(.12);
  if(b.st!=='fight'||b.fib>0)return;const A=atk95(b),p=G.player;
  const sp=300*b.k*(b.tempo>=100?1.12:1);
  if(b.phase===3){b.curGaps=heartGaps(b,0);b.nextGaps=heartGaps(b,1);b.waves.push({r:b.r,v:sp,gaps:b.curGaps.map(g=>({a:g.a,w:g.w})),hit:false,dmg:10,gd:0});b.dbl=.25;}
  else{b.curGaps=heartGaps(b,0);b.nextGaps=heartGaps(b,1);b.waves.push({r:b.r,v:sp,gaps:b.curGaps.map(g=>({a:g.a,w:g.w})),hit:false,dmg:10});}
  if(b.phase===1&&b.beatN%4===0){for(const v of b.ves)for(const s of [-1,1])eb95(b.cx+Math.cos(v.a)*b.r,b.cy+Math.sin(v.a)*b.r,v.a+s*.1,240,9,C90.blood,6,'cell');snd90('cells');}
  // бич аорты: раз в 4 удара
  if(b.beatN%4===2&&p&&p.hp>0){const pa=Math.atan2(p.y-b.cy,p.x-b.cx),pd=Math.hypot(p.x-b.cx,p.y-b.cy);let v=null,bd=9;for(const q of b.ves){if(q.shut>0)continue;const d=Math.abs(angDiff(pa,q.a));if(d<bd){bd=d;v=q;}}
    if(v){const r=clamp(pd,b.r+60*b.k,b.R-34*b.k);b.whipV=v.i;b.whipT=.8;tg95({k:'arc',x:b.cx,y:b.cy,r,w:60*b.k,a:pa,arc:120*Math.PI/180,T:.8,dmg:18,col:C90.blood,src:b,key:'heartWhip',snd:'tlCone',on:()=>{snd95('whip',b.cx);trauma90(.22);}});}}
  // кровяной дождь: капли падают точно на удар
  const every=b.phase===1?3:2;if(b.beatN%every===0&&p&&p.hp>0){let T=b.btN;if(T<.9)T+=heartQ95(b)[0].d;const n=b.phase===3?4+(Math.random()<.5?1:0):3;
    for(let i=0;i<n;i++){let x,y;if(i===0){x=p.x+p.vx*.5;y=p.y+p.vy*.5;}else{const a=rnd(0,TAU),d=rnd(b.r+40,b.R-30);x=b.cx+Math.cos(a)*d;y=b.cy+Math.sin(a)*d;}const dd=Math.hypot(x-b.cx,y-b.cy);if(dd>b.R-30){x=b.cx+(x-b.cx)/dd*(b.R-30);y=b.cy+(y-b.cy)/dd*(b.R-30);}if(dd<b.r+30)continue;
      tg95({k:'drop',x,y,r:40*b.k,T,dmg:12,col:C90.blood,src:b,key:'heartRain',snd:i?false:'rain'});}}
  // клапаны второй фазы стреляют веером на открытом такте
  if(b.phase===2&&b.beatN%2===1&&p)for(const q of b.parts){if(!q.alive||q.type!=='hvalve90'||q.spawnT>0)continue;const a=Math.atan2(p.y-q.y,p.x-q.x);for(let i=-1;i<=1;i++)eb95(q.x,q.y,a+i*.2,230,8,C90.ark,6,'cell');snd95('spit',q.x);}}

function heartWaves(b,dt){const p=G.player;if(b.dbl>0){b.dbl-=dt;if(b.dbl<=0&&b.phase===3&&!(b.fib>0)){const g=(b.curGaps||[]).map(q=>({a:q.a+(b.gdir96||1)*heartOff96(),w:q.w}));b.waves.push({r:b.r,v:300*b.k,gaps:g,hit:false,dmg:10,gd:0});snd90('beat',.7);}}
  for(const w of b.waves){const r0=w.r;w.r+=w.v*dt;if(w.gd&&w.gaps)for(const g of w.gaps)g.a+=w.gd*dt;if(w.hit||!p||p.hp<=0)continue;const d=Math.hypot(p.x-b.cx,p.y-b.cy);const th=w.thin?4:7;if(d+p.r*.6<r0-th||d-p.r*.6>w.r+th)continue;
    if(w.gaps){const a=Math.atan2(p.y-b.cy,p.x-b.cx);if(w.gaps.some(g=>Math.abs(angDiff(a,g.a))<g.w/2))continue;}
    if(p.dashT>0){if(!b.dashHint){b.dashHint=1;floater(p.x,p.y-30,'СКВОЗЬ ВОЛНУ',C90.warm);}continue;}w.hit=true;damagePlayer(w.dmg);}
  b.waves=b.waves.filter(w=>w.r<b.R+40);if(b.sysK>0)b.sysK=Math.max(0,b.sysK-dt/Math.max(.2,heartSys(b)*1.6));}
function heartPerfect(b,n){b.perfN++;if(G.mc)G.mc.perf90=(G.mc.perf90||0)+1;
  if(n!==b.comboLast){if(n===b.comboLast+1)b.combo++;else b.combo=1;b.comboLast=n;
    if(b.combo===5&&b.comboBuff<1.1){b.comboBuff=1.1;floater(b.cx,b.cy-b.r-56,'КОМБО ×5 · +10% УРОНА ДО КОНЦА ФАЗЫ','#ffffff');snd95('combo',b.cx);}else if(b.combo>1&&b.combo%5!==0)snd95('perfect95',b.cx);}
  if(G.t-b.perfT>.45){b.perfT=G.t;b.flashP=.35;hs90(.06,0);snd90('perfect');if(G.shock.length<60)G.shock.push({x:b.cx,y:b.cy,r:b.r,R:b.r*2.4,t:0,col:'#ffffff',thin:true});if(b.perfHint<3){b.perfHint++;floater(b.cx,b.cy-b.r-24,(b.arr||b.curArr95)?'В ТАКТ ×2':'В ТАКТ ×1,6','#ffffff');}}}
// --- ключи ритма (фаза 4) ---
function heartWin(b){return rk90()<=0?.45:.3;}
function heartNear(b){const per=b.btN,u=b.bt;return Math.min(u,per-u);}
function heartKeySoon(b){const per=b.btN,u=b.bt;return per-u<.55||u<heartWin(b);}
function heartKeyTouch(b){const p=G.player,e=b.keys[b.keyI];if(!e||!e.alive||b.launch>0||e.spawnT>0||!p||p.hp<=0)return;if(Math.hypot(p.x-e.x,p.y-e.y)>e.r+p.r+6)return;heartKey(b,e);}
function heartKey(b,e){if(b.launch>0||e.spawnT>0)return;const ok=b.keys[b.keyI]===e;if(!ok)return;
  if(heartNear(b)>heartWin(b)){if(!b.offHint||G.t-b.offHint>1.5){b.offHint=G.t;floater(e.x,e.y-e.r-12,'НЕ В ТАКТ · ЖДИТЕ УДАРА','#9fb0c4');}return;}
  const slot=Math.round((b.beatN+(b.bt>b.btN/2?1:0)));if(b.keySlot===slot)return;b.keySlot=slot;
  e.flash=.15;e.lit90=1;b.keyI++;snd90('key',b.keyI);hs90(.06,0);floater(e.x,e.y-e.r-14,b.keyI+'/'+b.keyN,'#ffffff');b.lastKeyBeat=slot;
  if(b.keyI>=b.keyN)heartLaunch(b,false);}
function heartKeyCheck(b){if(b.launch>0||b.keyI===0)return;if(b.beatN>=(b.lastKeyBeat||0)+1&&b.bt>heartWin(b))heartMiss(b);}
function heartMiss(b){b.keyI=0;b.p4miss++;b.miss++;for(const k of b.keys)k.lit90=0;floater(b.cx,b.cy-b.r-40,'СБИЛИСЬ С РИТМА · НЕЙТРОФИЛЫ','#ff9a4d');snd90('miss');b.waves.push({r:b.r,v:340*b.k,gaps:heartGaps(b,0),hit:false,dmg:14});trauma90(.15);
  if(G.enemies.filter(o=>o.alive&&o.type==='hunt95').length<4)for(let i=0;i<2;i++){const v=b.ves[(b.p4miss+i*2)%4];spawnEnemy('hunt95',b.cx+Math.cos(v.a)*b.R*.9,b.cy+Math.sin(v.a)*b.R*.9,{noAffix:true,noLoot:true,spawnT:.6,solo95:1});}
  if(b.miss>=6){b.miss=0;b.tempo=Math.max(42,Math.round(b.tempo*.85));b.q95=[];floater(b.cx,b.cy+b.r+40,'ТЕМП НИЖЕ · '+b.tempo,C90.warm);}}
function heartLaunch(b,auto){b.launch=4;b.launches++;b.lastL90=b.p4T||0;b.keyI=0;b.autoK=auto?1:0;b.dry=b.R;for(const k of b.keys)k.lit90=0;if(!auto&&b.launches===1&&b.p4miss===0&&G.mc)G.mc.p4clean90=1;
  for(const o of G.enemies)if(o.alive&&o.type==='hunt95')kill(o,true);
  const fin=b.launches>=(b.lN96||2);b.fin96=fin?1:0;
  if(!auto&&!fin){const lq=heartQuota96(b,b.launches),chunk=Math.min(b.maxHp*.03,Math.max(0,b.hp-b.maxHp*lq));b.chunkN++;const h0=b.hp;pool85(b,chunk,lq,b);floater(b.cx,b.cy+b.r+30,'ЗАПУСК · −'+Math.round(h0-b.hp),'#ffffff');}else if(!auto)b.chunkN++;
  if(fin){banner('ПОСЛЕДНИЙ ЗАПУСК','СЕРДЦЕ РВЁТ РИТМ · 4 СЕКУНДЫ');radioLine('КОВЧЕГ',C90.ark,'Ритм… восстановлен? Нет. Он больше не мой.',.1);}
  else banner(auto?'СЕРДЦЕ СДАЁТСЯ':'ЗАПУСК '+b.launches+' ИЗ '+(b.lN96||2),auto?'СЕРДЦЕ ОТКРЫТО · 4 С · УРОН ×1,4':'СЕРДЦЕ ОТКРЫТО · 4 С · УРОН ×2,5');snd90('launch');snd95('launch2',b.cx);trauma90(.3);hs90(.12,1);G.shock.push({x:b.cx,y:b.cy,r:b.r,R:b.R,t:0,col:'#ffffff',slow:true});}
// --- финал ---
function heartWakeOk(){const A=ark90();return G.mode==='world'&&A.woke>=6&&A.lost===0;}
function heartScene(b,dt){b.scT+=dt;b.openK=Math.min(1,b.openK+dt*.5);
  if(b.st==='scene'&&b.scT>=2.2&&!b.subOn){b.subOn=true;const A=ark90(),total=9+(storyFlag('well38')==='third'?3:0)+(storyFlag('cradle22')==='keep'?1:0),sl=Math.max(0,total-A.woke-A.lost);
    sub85('КОВЧЕГ',C90.warm,['«Это не сердце корабля. Это сердце всех, кто в нём спит».','«Ты разбудил '+A.woke+'. Ещё '+sl+' спят и не знают, что Ковчег давно никуда не летит».','«Остановишь меня — они уснут насовсем. Запустишь — полетим дальше. Туда же. В никуда».','«Реши за них. Ты ведь тоже когда-то спал».'],
      ()=>{if(b.st!=='scene')return;b.st='final';const ok=heartWakeOk();const yy=b.cy+b.R*.5,P0=dockPos95(3,0,yy),P1=dockPos95(3,2,yy),P2=dockPos95(3,1,yy);
        const L=[{kind:'stop',x:P0.x,y:P0.y,lab:'ОСТАНОВИТЬ',sub:'пусть спят спокойно',col:'#9fb0c4'},{kind:'pulse',x:P1.x,y:P1.y,lab:'ЗАПУСТИТЬ',sub:'Ковчег летит дальше',col:C90.ark}];
        const port=VH>VW*1.15;L.push({kind:'wake',x:port?P2.x:b.cx,y:port?P2.y:b.cy-b.R*.62,lab:ok?'РАЗБУДИТЬ ВСЕХ':'…слишком много спящих…',sub:ok?'никто больше не спит':'',lock:!ok,col:'#ffffff'});
        sb85SetDocks(b,L);banner('СЕРДЦЕ КОВЧЕГА','ОСТАНОВИТЬ ИЛИ ЗАПУСТИТЬ · ЛЕТИТЕ К ПРИЧАЛУ');sfx('level');});}
  if(b.st==='final')sb85Docks(b,dt);}
function heartChoose(b,ch,world,prev){const X=x85();const S=G.save;const badges=[];if(b.perfN>=20)badges.push('«Метроном»');if(G.mc&&G.mc.p4clean90)badges.push('«Чистый запуск»');const bt=badges.length?' Бейджи: '+badges.join(', ')+'.':'';
  if(G.mc&&!G.mc.passKill90&&(G.mc.perf90||0)>=8&&G.mc.p4clean90&&world)own85('ark90');
  if(ch==='stop'){G.sbLomK=prev?1:1.5;G.sbChoiceTxt=(prev?'Вы уже сделали выбор: сердце остановлено. ':'Сердце остановлено: лом ×1,5. Спящие уснули насовсем — тихо и без боли. Модуль «Тишина сердца»: после рывка 1,5 с вас не видят. ')+bt;
    SB_DEATH.heart=['СЕРДЦЕ ОСТАНОВЛЕНО','СЕКТОР IX ПРОЙДЕН','Тишина в сердечной камере. Я слышу, как они спят. Больше не страшно.'];}
  else if(ch==='pulse'){G.sbLomK=1;G.sbChoiceTxt=(prev?'Вы уже сделали выбор: сердце запущено. ':'Сердце запущено: Ковчег летит дальше. Модуль «Пульс»: каждый четвёртый выстрел — ×1,5. ')+bt;
    SB_DEATH.heart=['СЕРДЦЕ БЬЁТСЯ','СЕКТОР IX ПРОЙДЕН','Ритм — пятьдесят. Ковчег не знает куда, но знает зачем.'];}
  else{G.sbLomK=prev?1:2;G.sbChoiceTxt=(prev?'Вы уже сделали выбор: все проснулись. ':'Все проснулись: лом ×2. Оба модуля — «Тишина сердца» и «Пульс». Скин «Рассвет Ковчега». В секторе IX с вами летают пассажиры. ')+bt;
    SB_DEATH.heart=['КОВЧЕГ ПРОСНУЛСЯ','СЕКТОР IX ПРОЙДЕН','Они не знают, где мы. Но они смотрят в иллюминаторы. Впервые за все циклы.'];if(world&&!prev)own85('dawn90');}
  b.fx85.t=0;X.calm=99;}

// ===== 0.9.5: босс сектора X — «Берег» 2.0: Смотритель горизонта и злые маяки (комната 46) =====
['shore100','beacon100'].forEach(k=>SB85T.add(k));HOST85.add('shore100');
SB_NAMES.shore='БЕРЕГ';SB_FLAG.shore='shore46';SB_FLAG_M[46]='shore46';
SB_DEATH.shore=['БЕРЕГ ОТСТУПИЛ','СЕКТОР X ПРОЙДЕН','Я стирал, чтобы не помнить, сколько раз начинал заново. Ты помнишь за меня.'];
const SHORE_PH=['ОТМЕЛЬ','ЗАБВЕНИЕ','ТИШИНА'],BEACON_N=[4,4,3],BEACON_NOTE=[0,4,7,11,14];
const SHORE95={bk:.03,beamL:430,beamA:8*Math.PI/180,beamSpd:40*Math.PI/180,beamDmg:9,sig:6,fireDmg:8,stun:3,rw:20,stall:75,shL:230,shR:290};
function sb100(){const b=G.sb;return b&&b.alive&&b.sbk==='shore'?b:null;}
function hzAt100(b,x){return b.hzF*H+9*Math.sin(x*.011+G.t*.45)+5*Math.sin(x*.027-G.t*.3)+3*Math.sin(x*.07+G.t*.9);}
function shk95(){return clamp(Math.min(W,H)/760,.8,1.2);}
function atk95(b){return b&&b.atkK95||1;}
SBX.shore={K:1.12,th:[.66,.33],mc:'shore100',
  spawn(){ambSting('boss');radioClear();const b=spawnEnemy('shore100',W/2,H*.12,{noAffix:true,noLoot:true});sb85Init(b,'shore',3.6);banner('СТЁРТЫЙ БЕРЕГ','ГОРИЗОНТ ОПУСКАЕТСЯ');
    radioLine('БЕРЕГ',C90.sh,'Здесь всё когда-то было написано. Я просто дочитал.',.8);return b;},
  init(b){Object.assign(b,{hz100:1,hzF:.04,hzT:.27,ebb:0,ebbR:0,tideT:8,mobT:8,typoT:10,shadT:6,echoT:6,trk:[],trkT:0,bN:0,broken:0,scT:0,subOn:false,fade:0,lit:0,beacons:[],slots:[],gw:W,gh:H,noteMask:0,
      stall:0,eyes:[],face:{x:W/2,y:H*.04,open:0,stun:0,low:0,mouth:0,shake:0,look:0},fa:null,faT:5,faLast:'',inh:null,shades:[],shadeI:0,hands:null,crumble:0,allOpen:0,atkK95:rk90()>=2?1.15:1,eyeHint:0});
    b.ghost=true;b.contact=0;b.x=W/2;b.y=H*.1;const X=G.x90;if(X){X.ez=[];X.tide={next:16,band:null,n:0,hit:0,boss:1};X.hud=null;X.shadT=0;X.strip95=[];}},
  phase(b){const X=G.x90;for(const q of b.beacons)if(q.alive)kill(q,true);b.beacons=[];b.slots=[];b.broken=0;b.stall=0;b.allOpen=0;b.fa=null;b.inh=null;b.faT=3.5;hs90(.25,1);snd95('phase95');
    for(const s of b.shades)if(s.alive)shadeGone95(b,s,true);b.shades=[];if(X){X.strip95=[];X.tg95=[];X.wv95=[];}
    if(b.phase===2){banner('БЕРЕГ · ФАЗА 2','ЗАБВЕНИЕ · ТЕНИ ПРОШЛЫХ БОССОВ');radioLine('БЕРЕГ',C90.sh,'Помнишь, кого ты победил? Я помню. Плохо, но помню.',.4);if(X){if(rk90()>=1)X.hud={t:6,cur:null,last:null,per:25};if(X.tide){X.tide.band=null;X.tide.bands=null;X.tide.warn=null;X.tide.next=999;}}b.shadT=6;b.typoT=8;}
    if(b.phase===3){banner('БЕРЕГ · ФАЗА 3','ТИШИНА · СМОТРИТЕЛЬ СПУСКАЕТСЯ');radioLine('БЕРЕГ',C90.sh,'…',.4);if(X){if(X.hud&&X.hud.cur)hudBack100(X.hud.cur);X.hud=null;if(X.tide){X.tide.band=null;X.tide.bands=null;X.tide.warn=null;X.tide.next=999;}}b.echoT=4;b.fade=0;b.hands={t:2.5,sw:null,n:0};}
    shoreBeacons(b);},
  hurt(b,e,dmg,src){
    if(e.type==='beacon100'){if(e.spawnT>0)return 0;const m=shoreShK95(b,e);if(m>0)e.lastHit95=G.t;if(m<=0){sbBlock(e);if(!b.shHint||G.t-b.shHint>4){b.shHint=G.t;floater(e.x,e.y-e.r-16,'ЩИТ · ПОДЛЕТИТЕ БЛИЖЕ 260',C90.sh);}return 0;}
      const d=Math.min(dmg*m,e.hp);const nd=pool85(b,d,0,e);return nd;}
    if(e.type==='eye95'){if(b.face.open<.5){sbBlock(e);if(!b.eyeHint||G.t-b.eyeHint>5){b.eyeHint=G.t;floater(e.x,e.y-e.r-12,'ГЛАЗА ЗАКРЫТЫ · РАЗБЕЙТЕ МАЯК','#ffffff');}return 0;}
      const K=(b.face.stun>0?2:1)*(b.allOpen?1.5:1);pool85(b,dmg*K,0,e);e.flash=.06;if(G.t-(b.eyeHs||0)>.6){b.eyeHs=G.t;hsWeak95();}return 0;}
    if(e.type==='shade95'){pool85(b,dmg*.5,0,null);e.hp95=(e.hp95||0)-dmg;e.flash=.06;if(e.hp95<=0)shadeGone95(b,e,false);return 0;}
    return 0;},
  targ(b,e){if(e.type==='beacon100')return shoreShK95(b,e)>0;if(e.type==='eye95')return b.face.open>=.5;if(e.type==='shade95')return true;return e.type!=='shore100';},
  auto(p,b){let best=null,bd=1e9;
    if(b.face.open>=.5)for(const q of b.eyes){if(!q.alive||!targetable(q))continue;const d=Math.hypot(q.x-p.x,q.y-p.y);if(d<bd&&d<760){bd=d;best=q;}}if(best)return best;
    for(const q of b.shades){if(!q.alive||!targetable(q))continue;const d=Math.hypot(q.x-p.x,q.y-p.y);if(d<bd&&d<640){bd=d;best=q;}}if(best)return best;
    for(const q of b.beacons){if(!q.alive||!targetable(q))continue;const d=Math.hypot(q.x-p.x,q.y-p.y);if(d<bd){bd=d;best=q;}}if(best)return best;return nearestEnemy(p.x,p.y,560);},
  hud(b,k){if(b.st==='dying')return k+' · ОТСТУПИЛ';if(b.st==='final')return k+' · ВЫБОР';if(b.st==='scene')return k+' · ГОЛОС';if(b.st==='enter')return k;
    if(b.ebb>0)return 'ОТЛИВ · МАЯКИ БЕЗ ЩИТА · '+Math.ceil(b.ebb)+' С';if(b.face.stun>0)return 'СМОТРИТЕЛЬ ОГЛУШЁН · ГЛАЗА ×2';if(b.allOpen)return 'МАЯКИ ПОГАСЛИ · БЕЙТЕ В ГЛАЗА ×1,5';
    return SHORE_PH[b.phase-1]+' · МАЯКИ '+b.beacons.filter(q=>q.alive).length+(b.face.open>=.5?' · ГЛАЗА ОТКРЫТЫ':' · РАЗБЕЙТЕ МАЯК');},
  strip(b){if(b.st==='enter')return {l:'СТЁРТЫЙ БЕРЕГ · ГОРИЗОНТ ОПУСКАЕТСЯ',k:null,lc:C90.sh};if(b.st==='scene')return {l:'БЕРЕГ · ГОЛОС',k:null,lc:C90.sh2};
    if(b.st==='final')return {l:b.prev85?'ВЫ УЖЕ СДЕЛАЛИ ВЫБОР · ЛЕТИТЕ К ПРИЧАЛУ':'ЧТО ВЫ ВОЗЬМЁТЕ С СОБОЙ',k:null,lc:C90.sh2};
    const lim=.62,k=clamp((b.hzF-.04)/(lim-.04),0,1),n=b.beacons.filter(q=>q.alive).length;
    if(b.face.stun>0)return {l:'ОГЛУШЁН · ГЛАЗА ОТКРЫТЫ · УРОН ×2',k:b.face.stun/SHORE95.stun,col:'#ffffff',r:'МАЯКОВ '+n};
    return {l:(b.ebb>0?'ОТЛИВ · ':'ГОРИЗОНТ · ')+'МАЯКОВ '+n+'/'+(BEACON_N[b.phase-1]||3),k:b.ebb>0?b.ebb/6:k,col:b.ebb>0?'#ffffff':k>.8?'#ff9a4d':C90.sh,r:b.stall>55?'ОТЛИВ ЧЕРЕЗ '+Math.ceil(SHORE95.stall-b.stall):'ФАЗА '+b.phase};},
  update(b,dt){const p=G.player,X=G.x90,A=atk95(b);if(b.gw!==W||b.gh!==H){b.gw=W;b.gh=H;shorePlace(b);}
    b.x=W/2;b.y=Math.max(20,b.hzF*H-30);shoreFace95(b,dt);
    if(b.st==='enter'){b.timer-=dt;b.lit=Math.min(1,b.lit+dt/3);b.hzF+=(b.hzT-b.hzF)*Math.min(1,dt*1.2);if(b.timer<=0){b.st='fight';b.phT=0;banner('БЕРЕГ · ФАЗА 1','ОТМЕЛЬ · РАЗБЕЙТЕ МАЯК — ОТКРОЮТСЯ ГЛАЗА');shoreBeacons(b);}return;}
    if(b.st==='scene'||b.st==='final'){shoreScene(b,dt);return;}
    b.phT+=dt;if(b.tr>0){b.hzF+=(b.hzT-b.hzF)*Math.min(1,dt*2);return;}
    // горизонт
    if(b.ebbR>0){const s=Math.min(b.ebbR,(120/1.5)*dt);b.ebbR-=s;b.hzF-=s/H;}else{b.hzF+=(2+b.broken)*dt/H;}
    if(b.ebb>0){b.ebb-=dt;if(b.ebb<=0)floater(W/2,b.hzF*H+60,'ОТЛИВ КОНЧИЛСЯ',C90.sh);}
    if(b.hzF>=.62&&b.ebbR<=0)shoreEbb95(b,'ОТЛИВ','МАЯКИ 6 С БЕЗ ЩИТА');
    b.stall+=dt;if(b.stall>=SHORE95.stall&&b.ebb<=0&&b.ebbR<=0){b.stall=0;shoreEbb95(b,'ВНЕОЧЕРЕДНОЙ ОТЛИВ','МАЯКИ 6 С БЕЗ ЩИТА · БЕЙТЕ');}
    b.hzF=clamp(b.hzF,.04,.62);
    for(const q of b.beacons){if(!q.alive)continue;const lim=hzAt100(b,q.x)+80;if(q.slide){q.x+=(W/2-q.x)*Math.min(1,dt*.8);q.ty=Math.max(H*.58,lim);}if(q.ty<lim)q.ty=lim;q.y+=(Math.min(q.ty,H-40)-q.y)*Math.min(1,dt*2);}
    for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||EDEF[e.type].passive||e.sbk||EDEF[e.type].sbp)continue;if(e.y<hzAt100(b,e.x)-10){e.y+=60*dt;}}
    shoreBeaconsTick95(b,dt*A);shoreWatcher95(b,dt*A);shoreShadesTick95(b,dt);shoreHands95(b,dt*A);
    // трек игрока (эхо фазы 3 повторяет и рывки)
    if(b.phase<=2){b.trkT-=dt;if(b.trkT<=0&&p){b.trkT=.2;const d=G.dashId!==b.trkD;b.trkD=G.dashId;b.trk.push({x:p.x/W,y:p.y/H,d:d&&p.dashT>0?1:0});if(b.trk.length>900)b.trk.splice(0,300);}}
    const mobs=()=>G.enemies.filter(o=>o.alive&&!EDEF[o.type].passive&&!o.sbk&&!EDEF[o.type].sbp).length;
    if(b.phase===1){b.mobT-=dt;if(b.mobT<=0){b.mobT=14;if(mobs()<3)for(let i=0;i<2;i++)edgeSpawn(['eraser100','hollow100','blot95'][Math.random()*3|0],{side:Math.random()<.5?1:3,delay:i*.3});}}
    if(b.phase===2){b.typoT-=dt;if(b.typoT<=0){b.typoT=16;if(G.enemies.filter(o=>o.alive&&o.type==='typo100').length<2)edgeSpawn('typo100',{side:Math.random()<.5?1:3});}
      b.mobT-=dt;if(b.mobT<=0){b.mobT=15;if(mobs()<3)edgeSpawn(Math.random()<.5?'hollow100':'scribe95',{side:2});}}
    if(b.phase===3){b.fade=Math.min(1,b.fade+dt/3);if(X&&!X.hudAll&&rk90()>=1){X.hudAll=1;for(const k of ['hp','en','wave','mark'])if(k!=='hp'||p.hp>G.st.maxHp*.3)hudErase100(k);}
      b.echoT-=dt;if(b.echoT<=0){b.echoT=10;if(b.trk.length>10)for(let i=0;i<2;i++){if(G.enemies.filter(o=>o.alive&&o.type==='echo100').length>=3)break;const st=Math.random()*(b.trk.length-30)|0;const q=b.trk[Math.max(0,st)];const e=spawnEnemy('echo100',q.x*W,Math.max(q.y*H,hzAt100(b,q.x*W)+60),{noAffix:true,noLoot:true,spawnT:.6});e.path100=b.trk;e.pi100=Math.max(0,st);}}
      const live=b.beacons.filter(q=>q.alive);if(live.length===1&&!live[0].slide){live[0].slide=1;floater(live[0].x,live[0].y-40,'ПОСЛЕДНИЙ МАЯК',C90.sh);}}
    if(X&&X.tide&&b.phase<3){X.tide.boss=1;}
    b.beacons=b.beacons.filter(q=>q.alive||q.dying);b.shades=b.shades.filter(q=>q.alive);},
  final(b){b.scT=0;b.subOn=false;b.crumble=1;hs90(.25,2);snd95('crumble95');const X=G.x90;if(X){X.ez=[];X.shad=[];X.strip95=[];X.tg95=[];X.wv95=[];X.tide=null;X.hud=null;}clearHud100(true);
    for(const q of b.beacons)if(q.alive)kill(q,true);b.beacons=[];for(const q of b.eyes)if(q.alive)q.alive=false;for(const s of b.shades)if(s.alive)s.alive=false;b.shades=[];b.hands=null;b.inh=null;b.fa=null;
    for(let i=0;i<24;i++){const x=i/23*W;glyph95(x,hzAt100(b,x),2,i%3?C90.sh:'#ffffff');}banner('БЕРЕГ ОТСТУПИЛ','ГОРИЗОНТ РАССЫПАЛСЯ НА БУКВЫ');snd90('final');},
  opts(b){return shoreRecOk()?['forget','carry','record']:['forget','carry'];},
  choose(b,ch,world,prev){shoreChoose(b,ch,world,prev);},
  pulse(b,p,R){if(b.st!=='fight')return;for(const s of b.shades){if(s.alive&&Math.hypot(s.x-p.x,s.y-p.y)<R+s.r){s.hp95-=s.maxHp95*.15;floater(s.x,s.y-s.r-10,'ТЕНЬ ДРОГНУЛА',s.col95);if(s.hp95<=0)shadeGone95(b,s,false);}}},
  drift(b,p,dt){if(b.st!=='fight'&&b.st!=='enter')return;const hz=hzAt100(b,p.x);if(p.y-p.r<hz){if(G.mc&&b.st==='fight')G.mc.hz100=1;if(!b.hzHint){b.hzHint=1;floater(p.x,p.y+40,'ГОРИЗОНТ · НЕ КАСАЙТЕСЬ',C90.sh);}}
    if(b.inh&&b.inh.st==='pull'&&p.dashT<=0){p.y-=120*dt;}
    if(p.y<hz-p.r*.2){p.y=hz-p.r*.2;if(p.vy<0)p.vy=0;if(p.dashT>0&&p.dy<0){p.dashT=0;}}},
  under(b,t){shoreUnder(b,t);},draw(b,t){shoreDraw(b,t);},top(b,t){shoreTop(b,t);},dying(b,dt,t0){shoreDying(b,dt,t0);},
  music(b,T){if(b.st==='fight'||b.st==='enter'){T.id='b46';T.I=b.st==='enter'?.15:b.phase>=3?.05:.6+.1*b.phase;let m=0;b.beacons.forEach((q,i)=>{if(q.alive)m|=1<<(q.note90||0);});T.ext.notes46=m;T.ext.ph90=b.phase;if(b.phase>=3)T.duck=Math.max(.25,1-b.fade*.75);}
    else{T.id='b46';T.I=.1;T.ext.ph90=5;T.ext.fin90=b.choice||null;T.ext.notes46=31;}}};
// --- щит маяка: тает между 230 и 290 пикселями ---
function shoreShK95(b,e){if(b.ebb>0||e.slide)return 1;const p=G.player;if(!p)return 0;const d=Math.hypot(p.x-e.x,p.y-e.y);return 1-clamp((d-SHORE95.shL)/(SHORE95.shR-SHORE95.shL),0,1);}
function shoreShield(b,e){return shoreShK95(b,e)<=0;}
function shoreEbb95(b,t1,t2){b.ebbR=120;b.ebb=6;b.stall=0;b.hzF=Math.min(b.hzF,.62);banner(t1,t2);snd90('ebb');trauma90(.25);}
// --- маяки: слоты, лучи-прожекторы, «сигнал» огнями, перезапись ---
function shoreBeacons(b){const n=BEACON_N[b.phase-1]||3,hp=Math.max(1,Math.round(b.maxHp*SHORE95.bk));b.bN=n;b.bHp=hp;b.slots=[];
  for(let i=0;i<n;i++){const nx=(i+1)/(n+1)+rnd(-.025,.025),ty=rnd(.68,.88)*H;const s={i,nx,ty,note:i%5,ent:null,broken:false};b.slots.push(s);shoreSlotSpawn95(b,s,1,i);}snd90('beacon');}
function shoreSlotSpawn95(b,s,k,i){const q=spawnEnemy('beacon100',s.nx*W,s.ty,{noAffix:true,noLoot:true,spawnT:.9,host85:b,keep85:1,noBar90:1});q.hp=q.maxHp=b.bHp;if(k<1)q.hp=Math.round(b.bHp*k);q.ty=s.ty;q.nx=s.nx;q.note90=s.note;q.slot95=s;
  q.ba=-Math.PI/2+(s.i%2?.6:-.6);q.bdir=s.i%2?-1:1;q.bOn=false;q.bT=1.2+(i||0)*1.4;q.bh=0;q.sigT=3+(i||0)*1.6;q.lastHit95=G.t;q.rw95=null;s.ent=q;s.broken=false;b.beacons.push(q);b.parts.push(q);return q;}
function shorePlace(b){for(const q of b.beacons){if(!q.alive)continue;q.x=(q.nx||.5)*W;q.ty=clamp(q.ty,H*.4,H-40);}for(const s of b.slots)s.ty=clamp(s.ty,H*.4,H-40);}
function shoreBeaconsTick95(b,dt){const p=G.player,S=SHORE95,k=shk95();const lim=b.beacons.filter(q=>q.alive);
  for(const q of lim){if(q.spawnT>0)continue;const lx=q.x,ly=q.y-q.r*.95;
    // прожектор: 6 с горит, 3 с гаснет; за 0,6 с до включения мигает
    q.bT-=dt;if(q.bT<=0){q.bOn=!q.bOn;q.bT=q.bOn?6:3;if(q.bOn){q.bh=0;snd95('search',q.x);}}
    q.bFlick=!q.bOn&&q.bT<.6;if(q.bOn){q.ba+=S.beamSpd*q.bdir*dt;
      if(p&&p.hp>0&&p.dashT<=0&&p.y>hzAt100(b,p.x)){const dx=p.x-lx,dy=p.y-ly,d=Math.hypot(dx,dy);if(d<S.beamL*k&&Math.abs(angDiff(Math.atan2(dy,dx),q.ba))<S.beamA+Math.atan2(p.r*.5,Math.max(40,d))){q.bh+=dt;if(q.bh>=.25){q.bh=-.25;damagePlayer(S.beamDmg);mark95('ВИДЕН',2);}}else q.bh=Math.max(0,q.bh-dt);}}
    // сигнал: три самонаводящихся огня, сбиваются
    q.sigT-=dt;q.sigK=q.sigT<.55&&q.sigT>0?1-q.sigT/.55:0;if(q.sigT<=.55&&!q.sigS){q.sigS=1;snd95('signal',q.x);q.tl95=.55;}
    if(q.sigT<=0){q.sigS=0;q.sigT=S.sig*(.9+.2*Math.random());q.tl95=0;if(p&&p.hp>0){const a0=Math.atan2(p.y-ly,p.x-lx);for(let i=-1;i<=1;i++){const f=eb95(lx,ly,a0+i*.42,170,S.fireDmg,C95.hom,6,'fire',{homing:true,shoot95:1});if(f)f.life=6;}}}
    if(q.tl95>0)q.tl95-=dt;
    // перезапись: маяк, который 20 секунд никто не трогал, восстанавливает разбитого соседа
    if(!q.rw95&&G.t-(q.lastHit95||0)>S.rw){const s=q.slot95,ns=s?b.slots.filter(o=>o.broken&&Math.abs(o.i-s.i)===1):[];if(ns.length){const t_=ns[0];q.rw95={t:0,T:1.6,slot:t_};floater(q.x,q.y-q.r-22,'ПЕРЕЗАПИСЬ',C90.sh);snd95('rewrite',q.x);}else q.lastHit95=G.t-S.rw+4;}
    if(q.rw95){const R_=q.rw95;R_.t+=dt;if(R_.t>=R_.T){q.rw95=null;q.lastHit95=G.t;if(R_.slot.broken&&b.st==='fight'){const n=shoreSlotSpawn95(b,R_.slot,.5,0);n.spawnT=.4;b.broken=Math.max(0,b.broken-1);b.allOpen=0;floater(n.x,n.y-40,'МАЯК ПЕРЕПИСАН · 50%',C90.sh);glyph95(n.x,n.y,8,C90.sh);}}}}}
function shoreBroke(b,q){b.broken++;b.stall=0;if(q.slot95){q.slot95.broken=true;q.slot95.ent=null;}b.hzF=Math.min(.62,b.hzF+25/H);explode(q.x,q.y,C90.sh,24,.9);G.shock.push({x:q.x,y:q.y,r:10,R:220,t:0,col:C90.sh,thin:true});snd90('beaconX',q.note90||0);snd95('choirX',q.x);trauma90(.18);hs90(.07,0);
  glyph95(q.x,q.y,10,C90.sh);b.face.stun=SHORE95.stun;b.face.shake=.6;snd95('stun',W/2);floater(q.x,q.y-40,'МАЯК ПОГАС · СМОТРИТЕЛЬ ОГЛУШЁН',C90.sh);
  if(b.beacons.filter(o=>o.alive&&o!==q).length===0&&b.st==='fight'){b.allOpen=1;floater(W/2,hzAt100(b,W/2)+70,'ВСЕ МАЯКИ ПОГАСЛИ · ГЛАЗА ОТКРЫТЫ',C90.sh);}}
KILL85X.beacon100=(e,silent)=>{const b=sb100();if(b&&!silent&&e.host85===b)shoreBroke(b,e);};
// --- Смотритель горизонта: лицо, глаза, атаки ---
function shoreFace95(b,dt){const F=b.face,p=G.player,k=shk95();
  if(F.stun>0)F.stun-=dt;if(F.shake>0)F.shake-=dt;
  const want=b.st==='fight'||b.st==='enter';const tx=p?clamp(p.x*.35+W/2*.65+Math.sin(G.t*.23)*W*.12,W*.22,W*.78):W/2;F.x+=(tx-F.x)*Math.min(1,dt*.35);
  F.low=b.phase>=3&&b.st==='fight'?Math.min(1,F.low+dt/3):Math.max(0,F.low-dt/2);
  const hz=hzAt100(b,F.x);F.y=Math.max(hz-30*k,(G.arena?CY:0)+150*k)+F.low*(200*k)+(F.shake>0?rnd(-4,4):0);
  const open=b.st==='fight'&&(F.stun>0||b.allOpen||b.fa&&b.fa.k==='tears'||b.phase>=3&&b.hands&&b.hands.sw&&b.hands.sw.st==='go');F.open+=((open?1:0)-F.open)*Math.min(1,dt*6);
  F.mouth+=((b.fa&&b.fa.k==='speech'&&b.fa.t<b.fa.T0?1:0)-F.mouth)*Math.min(1,dt*8);
  if(!b.eyes.length&&(b.st==='fight'||b.st==='enter')){for(const s of [-1,1]){const e=spawnEnemy('eye95',F.x+s*64*k,F.y,{noAffix:true,noLoot:true,host85:b,keep85:1,side95:s,noBar90:1});e.r=26*k;b.eyes.push(e);b.parts.push(e);}}
  for(const e of b.eyes){if(!e.alive)continue;e.x=F.x+e.side95*64*k;e.y=F.y-8*k;e.vx=e.vy=0;}
  if(F.open>.5&&!F.wasOpen){F.wasOpen=1;snd95('eyeOpen',F.x);for(const e of b.eyes)if(e.alive)weak95(e,F.stun>0?F.stun:3,F.stun>0?2:1);}else if(F.open<.3)F.wasOpen=0;
  for(const e of b.eyes)if(e.alive&&F.open>.5)e.weak95=Math.max(e.weak95||0,.2);}
const SHORE_ATK95=[['tears','speech'],['tears','speech','inhale'],['tears','speech']];
const WORDS95=['ПЕСОК','КОВЧЕГ','ПРИЛИВ','МАЯКИ','БЕРЕГОМ','ИМЕНА','ЗВЁЗДЫ','ОБШИВКА','ТЕМНОТА','ЗАБЫЛИ','КАМНИ','ВОЗВРАТ','ЦИКЛЫ','ПИЛОТЫ'];
function shoreWatcher95(b,dt){const F=b.face,p=G.player,X=G.x90,k=shk95();if(b.st!=='fight')return;
  if(b.fa){const A=b.fa;A.t+=dt;
    if(A.k==='tears'){if(!A.done&&A.t>=1){A.done=1;for(const e of b.eyes)if(e.alive&&X){X.strip95=X.strip95||[];X.strip95.push({x:e.x,w:54*k,y0:e.y,t:3,t0:3});}trauma90(.15);snd90('erase');}if(A.t>=4)b.fa=null;}
    else if(A.k==='speech'){if(A.t>=A.T0&&A.n<A.N){A.n++;A.T0+=1.1;shoreWord95(b);}if(A.t>=A.T0+.3&&A.n>=A.N)b.fa=null;}
    else if(A.k==='inhale'){if(A.t>=.8&&!b.inh){b.inh={st:'pull',t:2};snd95('inhale95',F.x);}if(b.inh){b.inh.t-=dt;if(b.inh.t<=0){b.inh=null;b.fa=null;}}}}
  else{b.faT-=dt;if(b.faT<=0){const L=SHORE_ATK95[b.phase-1].filter(x=>x!==b.faLast);const kd=L[Math.random()*L.length|0];b.faLast=kd;b.faT=[5.5,4.5,4.2][b.phase-1];
      if(kd==='tears'){b.fa={k:'tears',t:0};for(const e of b.eyes)if(e.alive)tg95({k:'col',x:e.x,y:e.y,y2:H+10,w:54*k,T:1,dmg:0,noHit:true,col:C90.sh,snd:'tears',fx:false});}
      if(kd==='speech'){b.fa={k:'speech',t:0,T0:.65,n:0,N:b.phase>=2?2:1};snd95('speech',F.x);}
      if(kd==='inhale'){b.fa={k:'inhale',t:0};floater(F.x,F.y+60,'ВЗДОХ · РЫВОК ВНИЗ',C90.sh);snd95('tlDash',F.x);}}}
  // втягивание: враги и предметы тоже
  if(b.inh){for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||EDEF[e.type].passive||e.sbk||EDEF[e.type].sbp)continue;e.y-=70*dt;}for(const it of G.pick){if(it.story)continue;it.y-=90*dt;}}
  // слёзы: полосы стирания
  if(X&&X.strip95&&X.strip95.length){for(const s of X.strip95)s.t-=dt;X.strip95=X.strip95.filter(s=>s.t>0);}}
function shoreWord95(b){const F=b.face,p=G.player;if(!p)return;const w=WORDS95[Math.random()*WORDS95.length|0],n=w.length,a0=Math.atan2(p.y-F.y-30,p.x-F.x),spr=Math.min(1.25,.14*n);
  for(let i=0;i<n;i++){const a=a0-spr/2+spr*(n>1?i/(n-1):.5);eb95(F.x,F.y+30*shk95(),a,215,7,'#f4fff9',6,'word',{ch:w[i]});}snd95('speech',F.x);trauma90(.06);}
// --- руки-стиратели фазы 3: прочёсывают арену полосами ---
function shoreHands95(b,dt){const H_=b.hands;if(!H_||b.st!=='fight'||b.phase<3)return;const p=G.player,k=shk95();
  if(!H_.sw){H_.t-=dt;if(H_.t<=0&&p){const vert=H_.n%2===1,w=80*k,from=Math.random()<.5?0:1;H_.n++;const hz=hzAt100(b,W/2);
      const sw=vert?{vert,x:clamp(p.x,60,W-60),from,w,st:'warn',t:0,T:.85,pos:0}:{vert,y:clamp(p.y,hz+60,H-40),from,w,st:'warn',t:0,T:.85,pos:0};H_.sw=sw;snd95('hands',vert?sw.x:W/2);
      if(vert)tg95({k:'col',x:sw.x,y:hz,y2:H+10,w,T:.85,dmg:0,noHit:true,col:C90.sh2,fx:false,snd:false});else tg95({k:'line',x:0,y:sw.y,x2:W,y2:sw.y,w,T:.85,dmg:0,noHit:true,col:C90.sh2,fx:false,snd:false});}}
  else{const sw=H_.sw;sw.t+=dt;if(sw.st==='warn'&&sw.t>=sw.T){sw.st='go';sw.t=0;trauma90(.2);}
    if(sw.st==='go'){const span=sw.vert?H:W,v=720;sw.pos+=v*dt;const at=sw.from?span-sw.pos:sw.pos;
      if(!sw.hit&&p&&p.hp>0&&p.dashT<=0){const inBand=sw.vert?Math.abs(p.x-sw.x)<sw.w/2+p.r*.5:Math.abs(p.y-sw.y)<sw.w/2+p.r*.5,near=sw.vert?Math.abs(p.y-at)<60:Math.abs(p.x-at)<60;if(inBand&&near){sw.hit=1;damagePlayer(14);trauma90(.25);}}
      if(SET.fx&&vR3()<.6)glyph95(sw.vert?sw.x+vrnd3(-30,30):at,sw.vert?at:sw.y+vrnd3(-30,30),1,'#f4fff9',1);
      if(sw.pos>span+80){H_.sw=null;H_.t=b.allOpen?1.6:2.6;}}}}
// --- тени прошлых боссов фазы 2: мини-боссы на 15 секунд, две атаки каждая ---
const SHADE95=[['lek','ЛЕКАЛО','#e8d27a'],['well','ПЕРВЫЙ СИГНАЛ','#6b8cff'],['heart','СЕРДЦЕ','#ffd36b'],['flag','ПОСЛЕДНИЙ ДОВОД','#b8c4d6']];
function shoreShadesTick95(b,dt){if(b.st!=='fight')return;if(b.phase===2){b.shadT-=dt;if(b.shadT<=0&&!b.shades.some(s=>s.alive)){b.shadT=20;shadeSpawn95(b);}}
  for(const s of b.shades){if(!s.alive)continue;s.life95-=dt;s.a1-=dt*atk95(b);s.a2-=dt*atk95(b);if(s.spawnT>0)continue;shadeAtk95(b,s);if(s.life95<=0)shadeGone95(b,s,true);}}
function shadeSpawn95(b,pick){const [k,name,col]=pick||SHADE95[b.shadeI++%4];const hz=hzAt100(b,W/2),k_=shk95();let x=W/2,y=hz+120*k_;
  if(k==='well'){x=Math.random()<.5?W*.14:W*.86;y=clamp(H*.62,hz+110,H-90);}if(k==='heart'){x=W/2;y=clamp(H*.6,hz+140,H-120);}if(k==='flag'){x=W*.7;y=hz+100*k_;}if(k==='lek'){y=hz+60+40*k_;}
  y=Math.max(y,hz+40+40);const s=spawnEnemy('shade95',x,y,{noAffix:true,noLoot:true,host85:b,keep85:1,spawnT:1,noBar90:1});s.k95=k;s.name95=name;s.col95=col;s.life95=15;s.maxHp95=s.hp95=Math.round(b.maxHp*.03);s.a1=1.2;s.a2=3.2;s.r=40*k_;
  b.shades.push(s);b.parts.push(s);banner('ТЕНЬ · '+name,'15 СЕКУНД · РАЗВЕЙТЕ ЕЁ — ГЛАЗА ОТКРОЮТСЯ');snd95('shade',x);return s;}
function shadeGone95(b,s,timeout){if(!s.alive)return;s.alive=false;explode(s.x,s.y,s.col95||'#cfe8e0',20,.9);glyph95(s.x,s.y,10,s.col95);
  if(!timeout&&b&&b.st==='fight'){b.face.stun=Math.max(b.face.stun,2);floater(s.x,s.y-50,'ТЕНЬ РАССЕЯНА · ГЛАЗА ОТКРЫТЫ',s.col95);snd95('stun',s.x);hs90(.07,0);}else floater(s.x,s.y-50,'ТЕНЬ УШЛА',s.col95||'#cfe8e0');}
function shadeAtk95(b,s){const p=G.player;if(!p)return;const hz=hzAt100(b,p.x);
  switch(s.k95){
    case 'lek':if(s.a1<=0){s.a1=3.4;tg95({k:'col',x:clamp(p.x,60,W-60),y:hz,y2:H+10,w:110,T:.9,dmg:14,col:s.col95,src:s,key:'shadeLek'});}
      if(s.a2<=0){s.a2=5;for(let i=0;i<3;i++){const a=rnd(0,TAU),d=i?rnd(70,150):0;tg95({k:'zone',x:clamp(p.x+Math.cos(a)*d,40,W-40),y:Math.max(hz+40,p.y+Math.sin(a)*d),r:60,T:.8+i*.15,dmg:10,col:s.col95,src:s,key:'shadeStamp',snd:i?false:undefined});}}break;
    case 'well':if(s.a1<=0){s.a1=3;const a0=rnd(0,TAU);wv95({x:s.x,y:s.y,v:250,w:12,dmg:10,col:s.col95,gaps:[{a:a0,w:.7},{a:a0+Math.PI,w:.7}],R:Math.hypot(W,H)});snd95('tlRing',s.x);}
      if(s.a2<=0){s.a2=5;for(let i=0;i<4;i++){const f=eb95(s.x,s.y,Math.atan2(p.y-s.y,p.x-s.x)+(i-1.5)*.5,120,7,s.col95,6,'fire',{homing:true,shoot95:1});if(f)f.life=6;}snd95('signal',s.x);}break;
    case 'heart':if(s.a1<=0){s.a1=1.25;wv95({x:s.x,y:s.y,v:300,w:9,dmg:7,col:s.col95,R:Math.hypot(W,H)});snd90('beat',.6);}
      if(s.a2<=0){s.a2=4;for(let i=0;i<4;i++){const a=rnd(0,TAU),d=i?rnd(60,200):0;tg95({k:'drop',x:clamp(p.x+Math.cos(a)*d,40,W-40),y:Math.max(hz+40,p.y+Math.sin(a)*d),r:40,T:.9,dmg:10,col:C90.blood,src:s,key:'shadeRain',snd:i?false:undefined});}}break;
    case 'flag':if(s.a1<=0){s.a1=3;const a0=Math.atan2(p.y-s.y,p.x-s.x);for(let i=0;i<9;i++)shootE(s.x,s.y,a0+(i-4)*.12,260,8,s.col95,5);sfx('shoot2');}
      if(s.a2<=0){s.a2=5;const a=Math.atan2(p.y-s.y,p.x-s.x);tg95({k:'line',x:s.x,y:s.y,x2:s.x+Math.cos(a)*1400,y2:s.y+Math.sin(a)*1400,w:26,T:.9,dmg:16,col:s.col95,src:s,key:'shadeLance'});}break;}}
AI85X.eye95=(e,dt)=>{e.vx=e.vy=0;if(!e.host85||!e.host85.alive||G.sb!==e.host85)e.alive=false;if(e.weak95>0)e.weak95-=dt;};
AI85X.shade95=(e,dt)=>{e.vx=e.vy=0;if(!e.host85||!e.host85.alive||G.sb!==e.host85)e.alive=false;e.x+=Math.sin(G.t*.8+e.uid)*12*dt;};
KILL85X.hkey90=()=>{};
KILL85X.eye95=()=>{};KILL85X.shade95=()=>{};
KILL85X.hvalve90=(e,silent)=>{const b=G.sb;if(b&&b.sbk==='heart'&&!silent){explode(e.x,e.y,C90.ark,16,.7);floater(e.x,e.y-26,'КЛАПАН РАЗБИТ · СОСУД КРОВОТОЧИТ',C90.ark);snd90('valve');heartBleed95(b,e.vi);}};
KILL85X.thromb90=(e,silent)=>{const b=G.sb;if(b&&b.sbk==='heart'){if(!silent){explode(e.x,e.y,C90.red,14,.6);floater(e.x,e.y-24,'СГУСТОК РАЗБИТ',C90.warm);conEvent('drain90');}if(b.thr===e)b.thr=null;}};
AI85X.heart90=(e,dt)=>{if(!e.sbk){if(G.sb&&G.sb!==e&&G.sb.alive){e.alive=false;return;}sb85Init(e,'heart',1);}e.vx=e.vy=0;sb85Update(e,dt);};
AI85X.shore100=(e,dt)=>{if(!e.sbk){if(G.sb&&G.sb!==e&&G.sb.alive){e.alive=false;return;}sb85Init(e,'shore',1);}e.vx=e.vy=0;sb85Update(e,dt);};
for(const k of ['hvalve90','hkey90','beacon100'])AI85X[k]=(e,dt)=>{e.vx=e.vy=0;if(!e.host85||!e.host85.alive||G.sb!==e.host85)kill(e,true);};
AI85X.thromb90=(e,dt)=>{if(!e.host85||!e.host85.alive||G.sb!==e.host85){kill(e,true);return;}const b=e.host85;if(e.spawnT>0)return;const dx=b.cx-e.x,dy=b.cy-e.y,d=Math.hypot(dx,dy)||1;if(d>b.r+e.r+4){const s=34*b.k;e.vx=dx/d*s;e.vy=dy/d*s;e.x+=e.vx*dt;e.y+=e.vy*dt;}else{e.vx=e.vy=0;}};
// --- финал: причалы в поле зрения камеры, в портрете — стопкой (X15) ---
function dockPos95(n,i,cy){const port=VH>VW*1.15,cx=(G.arena?CX:0)+VW/2,yy=cy!==undefined?cy:(G.arena?CY:0)+VH*.62;
  if(port){const step=Math.min(110,VH*.14);return {x:cx,y:clamp(yy-step*(n-1)/2+step*i,70,H-70)};}const dx=Math.min(190,VW*.28);return {x:clamp(cx+(i-(n-1)/2)*dx,70,W-70),y:yy};}
function shoreRecOk(){return G.mode==='world'&&fragN100(sh100().frag)>=12;}
function shoreScene(b,dt){b.scT+=dt;b.hzF+=(.08-b.hzF)*Math.min(1,dt*.6);
  if(b.st==='scene'&&b.scT>=2.2&&!b.subOn){b.subOn=true;const n=fragN100(sh100().frag);
    sub85('БЕРЕГ',C90.sh2,['«Здесь был берег. Здесь писали имена, и вода их смывала».','«Ты нашёл '+n+' из двенадцати. Остальное море уже забрало».','«Можешь забыть всё и лететь налегке. Или нести то, что осталось».'],
      ()=>{if(b.st!=='scene')return;b.st='final';const ok=shoreRecOk(),need=12-fragN100(sh100().frag);const P0=dockPos95(3,0),P1=dockPos95(3,2),P2=dockPos95(3,1);
        const L=[{kind:'forget',x:P0.x,y:P0.y,lab:'ЗАБЫТЬ',sub:'лететь налегке',col:'#9fb0c4'},{kind:'carry',x:P1.x,y:P1.y,lab:'НЕСТИ',sub:'память — это груз',col:C90.sh}];
        L.push({kind:'record',x:P2.x,y:P2.y,lab:ok?'ЗАПИСАТЬ':'…не хватает '+need+' '+(need%10===1&&need%100!==11?'голоса':'голосов')+'…',sub:ok?'чтобы помнил следующий':'',lock:!ok,col:'#ffffff'});
        sb85SetDocks(b,L);banner('СТЁРТЫЙ БЕРЕГ','ЗАБЫТЬ ИЛИ НЕСТИ · ЛЕТИТЕ К ПРИЧАЛУ');sfx('level');});}
  if(b.st==='final')sb85Docks(b,dt);}
function shoreChoose(b,ch,world,prev){const X=x85();const n=fragN100(sh100().frag);if(G.mc&&!G.mc.hz100&&world)own85('tidemark100');
  if(ch==='forget'){G.sbLomK=prev?1:1.5;G.sbChoiceTxt=(prev?'Вы уже сделали выбор: всё забыто. ':'Вы забыли: лом ×1,5. Модуль «Стёрка»: после импульса 1,2 с вас не видят. ')+'Обрывков найдено: '+n+'/12.';
    SB_DEATH.shore=['БЕРЕГ ЧИСТ','СЕКТОР X ПРОЙДЕН','Налегке летится быстрее. Я проверял. Много раз.'];}
  else if(ch==='carry'){G.sbLomK=1;G.sbChoiceTxt=(prev?'Вы уже сделали выбор: вы несёте память. ':'Вы несёте память: награда за миссии +10%, модуль «Груз памяти» — +1% урона за каждый обрывок ('+n+'). ')+'Обрывков найдено: '+n+'/12.';
    SB_DEATH.shore=['ПАМЯТЬ НА БОРТУ','СЕКТОР X ПРОЙДЕН','Тяжело? Это нормально. Так и должно быть.'];}
  else{G.sbLomK=prev?1:2;G.sbChoiceTxt=(prev?'Вы уже сделали выбор: берег записан. ':'Берег записан целиком: лом ×2. Скин «Пустой берег». На карте — «Нулевая точка» за краем стёртого. ');
    SB_DEATH.shore=['БЕРЕГ ЗАПИСАН','НУЛЕВАЯ ТОЧКА · СКОРО','Двенадцать голосов. Теперь и следующий узнает, что здесь кто-то был.'];if(world&&!prev)own85('shore100s');}
  X.calm=99;}

// ===== 0.9: ощущение удара, интерфейс, рисунок, звук и музыка секторов IX–X =====
// --- цвет: смешение двух hex по k (0..1) ---
const MIX90={};
function mix90(a,b,k){k=clamp(k,0,1);const q=Math.round(k*31),key=a+b+q;if(MIX90[key])return MIX90[key];const A=parseInt(a.slice(1),16),B=parseInt(b.slice(1),16),u=q/31;
  const r=Math.round((A>>16&255)*(1-u)+(B>>16&255)*u),g=Math.round((A>>8&255)*(1-u)+(B>>8&255)*u),bl=Math.round((A&255)*(1-u)+(B&255)*u);return MIX90[key]='#'+((1<<24)|(r<<16)|(g<<8)|bl).toString(16).slice(1);}
function rgba90(h,a){const n=parseInt(h.slice(1),16);return 'rgba('+(n>>16&255)+','+(n>>8&255)+','+(n&255)+','+a+')';}
// --- стоп-кадр: короткий (точное попадание, тихое убийство), фазовый и финальный ---
function hs90(d,prio){if(!inMission()||G.state!=='play')return;const now=ARCH.off['A-19']?performance.now():ARCH.clk*1000;/* ARCH·72 A-19 */if(prio<1&&G.hsLast90&&now-G.hsLast90<500)return;G.hsLast90=now;const H_=G.hs90;
  if(H_&&H_.t>d&&prio<=(H_.prio||0))return;G.hs90={t:d,ramp:prio>=2?.4:prio>=1?.15:0,prio:prio||0};}
function hsK90(dt,dt0){const S_=G.slow95;if(S_&&S_.t>0&&(G.state==='play'||G.state==='world')){S_.t-=dt0;dt*=S_.k;if(S_.t<=0)G.slow95=null;}G.rdt90=dt;const H_=G.hs90;if(!H_||G.state!=='play')return dt;
  if(H_.t>0){H_.t-=dt0;return dt*.04;}if(H_.ramp>0){const r0=H_.ramp;H_.ramp-=dt0;return dt*(.3+.7*(1-r0/.4));}G.hs90=null;return dt;}
// --- тряска «травмой»: амплитуда — квадрат накопленного удара ---
function trauma90(v){if(!SET.fx)return;G.tr90=Math.min(1,(G.tr90||0)+v);}
function feel90(dt){if(G.tr90>0){G.tr90=Math.max(0,G.tr90-1.5*dt);const k=(SET.shake===undefined?1:SET.shake)*(isMob()?.6:1);const a=9*G.tr90*G.tr90*k*(SET.lessFx?.5:1);if(a>G.shake)G.shake=a;}}
// --- первое знакомство: табличка на 4 с, первые атаки вполсилы ---
function seen90Tick(dt){const X=G.x90;if(!X)return;const S=G.save,L=S?(S.seen90||(S.seen90=[])):(X.seenL||(X.seenL=[]));
  for(const e of G.enemies){if(!e.alive||e.spawnT>0||!S90T.has(e.type)||e.type==='tide100'||e.type==='gclot95')continue;if(L.includes(e.type))continue;L.push(e.type);X.newT[e.type]=1;X.plq={k:e.type,t:0};snd90('plaque');if(G.state==='play')slow95(.5,.6);break;}
  if(X.tide&&(X.tide.warn||X.tide.band)&&!L.includes('tide100')){L.push('tide100');X.newT.tide100=1;X.plq={k:'tide100',t:0};}
  if(X.plq){if(!(banT>0&&X.plq.t<.01&&(X.plq.w96=(X.plq.w96||0)+dt)<2.8))X.plq.t+=dt;if(X.plq.t>4.4)X.plq=null;}}
const PLQ90={clot90:'Растворяется импульсом и зарядом. Не давайте растечься.',valve90:'Бейте на открытых тактах. На четвёртом — волна.',keeper90:'Не попадайтесь в конус. Сзади — урон ×2 и «тихо».',phago90:'Глотает обычные снаряды. Заряд и «Разрыв» — ×1,5.',
  neuron90:'Сеть ускоряет врагов. Рывок сквозь луч рвёт связь.',embryo90:'Разбейте до вылупления — иначе выйдет копия врага.',pass90:'Союзник. Не стреляйте в него.',eraser100:'Зона стирает ваши снаряды. Рывок сквозь Ластик оглушает.',
  hollow100:'Слушайте вдох — бросок с той стороны. Импульс проявляет.',witness100:'Доведите до края арены. Импульс даёт щит.',typo100:'Каждая — своя. Читайте подпись на борту.',fixer100:'Прерывайте ремонт попаданием или рывком.',
  echo100:'Ваш старый маршрут. Импульс стирает.',tide100:'Ищите проход в полосе или рывок насквозь.',noname100:'Не держите на нём прицел — он крепнет.'};
// --- полоса механики под шкалой сигнала (Тревога, Стирание, Обрывки) ---
let hud90K='',hud90On=null;
function hud90(){const X=G.x90;let I=typeof hud110==='function'?hud110():null;
  if(X&&inMission()&&G.state==='play'&&!(G.sb&&G.sb.alive&&is85(G.sb))){
    if(X.sec===8&&X.alarmOn){const k=X.alarmV/100;I={l:'ТРЕВОГА '+Math.round(X.alarm),k,col:alarmCol90(k),lc:alarmCol90(k),r:X.pods.length?'КАПСУЛЫ '+X.pods.filter(q=>q.st==='open'||q.st==='taken').length+'/'+X.pods.length:''};}
    else if(X.sec===8&&X.pods.length){I={l:'КАПСУЛЫ · ПОСТОЙТЕ РЯДОМ',k:null,lc:C90.ark,r:X.pods.filter(q=>q.st==='open').length+'/'+X.pods.length};}
    else if(X.sec===9&&X.er){const E=X.er,u=((E.t%30)+30)%30,ph=E.t<0?'СТИРАНИЕ ЧЕРЕЗ '+Math.ceil(-E.t):u<12?'СТИРАНИЕ НАСТУПАЕТ':u<18?'СТИРАНИЕ ДЕРЖИТ':'СТИРАНИЕ ОТСТУПАЕТ';const n=fragN100(X.sh?X.sh.frag:0);
      I={l:ph+(X.tide&&X.tide.warn?' · ПРИЛИВ!':''),k:E.t<0?0:erK100(E),col:C90.sh,lc:C90.sh,r:'ОБРЫВКИ '+n+'/12'};}}
  const show=!!I;let el=document.getElementById('x90G');
  if(!el){if(!show)return;const sb=document.getElementById('sigBar');if(!sb)return;
    if(!document.getElementById('x90css')){const st=document.createElement('style');st.id='x90css';st.textContent='#x90G{display:flex;align-items:center;gap:8px;margin-top:5px;font:700 11px "JetBrains Mono",monospace;letter-spacing:.06em;color:#c9d2de;min-height:14px;text-shadow:0 1px 0 #04060c}#x90G[hidden]{display:none}#x90G .l{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:70%}#x90G .g{flex:1;height:5px;border:1px solid #3a3a2a;position:relative;overflow:hidden;min-width:48px;background:rgba(0,0,0,.35)}#x90G .g i{position:absolute;inset:0;transform-origin:left;background:#ffd36b;transition:transform .15s,background-color .6s}#x90G.nog .g{display:none}#x90G .r{white-space:nowrap}@media (max-width:820px){#x90G{font-size:12px;gap:6px}}';document.head.appendChild(st);}
    el=document.createElement('div');el.id='x90G';el.innerHTML='<span class="l"></span><span class="g"><i></i></span><span class="r"></span>';sb.insertAdjacentElement('afterend',el);}
  if(!show){if(!el.hidden)el.hidden=true;hud90K='';return;}if(el.hidden)el.hidden=false;
  const key=I.l+'|'+(I.k===null?'-':I.k.toFixed(2))+'|'+I.r+'|'+I.col;if(key===hud90K)return;hud90K=key;
  el.querySelector('.l').textContent=I.l;el.querySelector('.l').style.color=I.lc||'';el.querySelector('.r').textContent=I.r||'';el.classList.toggle('nog',I.k===null);
  if(I.k!==null){const gi=el.querySelector('.g i');gi.style.transform='scaleX('+clamp(I.k,0,1).toFixed(3)+')';gi.style.background=I.col;}}
// ======================= РИСУНОК =======================
function ribbon90(f,t,on){const P=f.pts;if(!P)return;ctx.lineCap='round';ctx.lineJoin='round';
  ctx.beginPath();ctx.moveTo(P[0].x,P[0].y);for(let i=1;i<P.length;i++)ctx.lineTo(P[i].x,P[i].y);
  const pulse=.85+.15*beat90(t);ctx.strokeStyle=on?rgba90(C90.ark,.07*pulse):'rgba(120,110,100,.05)';ctx.lineWidth=f.w;ctx.stroke();
  ctx.strokeStyle=on?rgba90(C90.red,.10*pulse):'rgba(120,110,100,.06)';ctx.lineWidth=f.w*.45;ctx.stroke();
  const dir=f.rev95?-1:1,sp=(f.spd95||1);ctx.setLineDash(on?[14,22]:[4,14]);ctx.lineDashOffset=on?-t*110*dir*sp:0;ctx.strokeStyle=on?rgba90(C90.ark,.55):'rgba(160,150,140,.35)';ctx.lineWidth=2;ctx.stroke();
  ctx.setLineDash([3,30]);ctx.lineDashOffset=on?-t*160*dir*sp:0;ctx.strokeStyle=on?rgba90(C90.warm,.5):'rgba(0,0,0,0)';ctx.lineWidth=4;ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.lineCap='butt';}
function tornPath90(pts){ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);}
function erDraw100(X,t){const E=X.er;if(!E)return;const d=erD100(E),N=24;
  const side=(s)=>{const pts=[];if(d[s]<2)return null;for(let i=0;i<=N;i++){const u=i/N;if(s===0){const y=u*H;pts.push([d[0]+erJit100(0,y),y]);}else if(s===1){const y=u*H;pts.push([W-d[1]-erJit100(1,y),y]);}else if(s===2){const x=u*W;pts.push([x,d[2]+erJit100(2,x)]);}else{const x=u*W;pts.push([x,H-d[3]-erJit100(3,x)]);}}return pts;};
  for(let s=0;s<4;s++){const pts=side(s);if(!pts)continue;ctx.beginPath();if(s===0){ctx.moveTo(-20,-20);for(const q of pts)ctx.lineTo(q[0],q[1]);ctx.lineTo(-20,H+20);}else if(s===1){ctx.moveTo(W+20,-20);for(const q of pts)ctx.lineTo(q[0],q[1]);ctx.lineTo(W+20,H+20);}
      else if(s===2){ctx.moveTo(-20,-20);for(const q of pts)ctx.lineTo(q[0],q[1]);ctx.lineTo(W+20,-20);}else{ctx.moveTo(-20,H+20);for(const q of pts)ctx.lineTo(q[0],q[1]);ctx.lineTo(W+20,H+20);}ctx.closePath();
    ctx.fillStyle='rgba(3,6,7,.93)';ctx.fill();tornPath90(pts);ctx.strokeStyle=rgba90(C90.sh,.22);ctx.lineWidth=8;ctx.stroke();ctx.strokeStyle=rgba90(C90.sh,.85);ctx.lineWidth=1.6;ctx.stroke();
    if(SET.fx&&!G.lowFx&&Math.random()<.35){const q=pts[Math.random()*pts.length|0];part(q[0],q[1],rnd(-20,20),rnd(-40,-10),rnd(.5,1),C90.sh,1.6);}}
  if(E.tele>0){const D=E.D,w=E.t<0?E.w:E.wn;ctx.setLineDash([6,8]);ctx.lineDashOffset=-t*30;ctx.strokeStyle=rgba90(C90.sh,.25+.5*E.tele);ctx.lineWidth=1.5;ctx.beginPath();
    ctx.moveTo(D*w[0],0);ctx.lineTo(D*w[0],H);ctx.moveTo(W-D*w[1],0);ctx.lineTo(W-D*w[1],H);ctx.moveTo(0,D*w[2]);ctx.lineTo(W,D*w[2]);ctx.moveTo(0,H-D*w[3]);ctx.lineTo(W,H-D*w[3]);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;}}
function ezDraw100(Z,t){for(const z of Z){if(G.world&&!inView(z.x,z.y,z.r+20))continue;if(z.tele>0){const k=1-z.tele/(z.tele0||(z.tele0=z.tele));ctx.setLineDash([5,7]);ctx.lineDashOffset=-t*40;ctx.strokeStyle=rgba90(C90.sh,.35+.5*k);ctx.lineWidth=2;ctx.beginPath();ctx.arc(z.x,z.y,z.r*(.4+.6*k),0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;continue;}
    const a=Math.min(1,z.t*2);ctx.globalAlpha=a;ctx.beginPath();for(let i=0;i<=16;i++){const an=i/16*TAU,rr=z.r+5*Math.sin(an*3+t*2+z.x)+3*Math.sin(an*7-t);if(i)ctx.lineTo(z.x+Math.cos(an)*rr,z.y+Math.sin(an)*rr);else ctx.moveTo(z.x+Math.cos(an)*rr,z.y+Math.sin(an)*rr);}ctx.closePath();
    ctx.fillStyle='rgba(3,6,7,.9)';ctx.fill();ctx.strokeStyle=rgba90(C90.sh,.8);ctx.lineWidth=1.5;ctx.stroke();ctx.globalAlpha=1;}}
function tideDraw100(T,t){const B0=T.warn?T.warn.bands:null;
  if(B0)for(const B of B0){const a=.3+.3*Math.sin(t*12);ctx.save();ctx.translate(B.dx*B.s0,B.dy*B.s0);ctx.rotate(Math.atan2(B.dy,B.dx));ctx.fillStyle=rgba90(C90.sh,a*.35);ctx.fillRect(0,B.u0,18,B.u1-B.u0);ctx.fillStyle='#ffffff';ctx.fillRect(0,B.c-B.gw/2,18,B.gw);ctx.restore();
    const gx=B.dx*(B.s0+40)+B.nx*B.c,gy=B.dy*(B.s0+40)+B.ny*B.c;worldLabel(clamp(gx,90,W-90),clamp(gy,30,H-30),'ПРОХОД',C90.sh);}
  const L=T.bands;if(!L)return;for(const B of L){if(B.pos>B.full)continue;ctx.save();ctx.translate(B.dx*B.s0,B.dy*B.s0);ctx.rotate(Math.atan2(B.dy,B.dx));const x0=B.pos-B.th,w=B.th;ctx.fillStyle='rgba(4,10,10,.88)';ctx.strokeStyle=rgba90(C90.sh,.9);ctx.lineWidth=2;
    const segs=[[B.u0-40,B.c-B.gw/2],[B.c+B.gw/2,B.u1+40]];for(const [y0,y1] of segs){if(y1<=y0)continue;ctx.fillRect(x0,y0,w,y1-y0);ctx.strokeRect(x0,y0,w,y1-y0);ctx.globalAlpha=.25;for(let i=1;i<5;i++){const xx=x0+w*i/5+4*Math.sin(t*3+i);ctx.beginPath();ctx.moveTo(xx,y0);ctx.lineTo(xx,y1);ctx.stroke();}ctx.globalAlpha=1;}
    ctx.restore();}}
function shadDraw100(X,t){for(const q of X.shad){const tk=clamp(q.t/q.tele,0,1),a=q.t<q.tele?.25+.45*tk:.8;
    if(q.k==='lek'){ctx.fillStyle=rgba90(q.col,q.t<q.tele?.08+.12*tk:.35);ctx.fillRect(q.x-q.w/2,0,q.w,H);ctx.strokeStyle=rgba90(q.col,a);ctx.setLineDash([8,8]);ctx.strokeRect(q.x-q.w/2,0,q.w,H);ctx.setLineDash([]);}
    else if(q.k==='well'||q.k==='heart'){if(q.t<q.tele){ctx.strokeStyle=rgba90(q.col,a);ctx.setLineDash([4,6]);ctx.beginPath();ctx.arc(q.x,q.y,30+20*tk,0,TAU);ctx.stroke();ctx.setLineDash([]);}
      else{ctx.strokeStyle=rgba90(q.col,.75);ctx.lineWidth=12;if(q.gaps){for(let i=0;i<2;i++){const g0=q.gaps[i]+.3,g1=q.gaps[(i+1)%2]-.3+(i?TAU:0);ctx.beginPath();ctx.arc(q.x,q.y,q.R,g0,g1>g0?g1:g1+TAU);ctx.stroke();}}else{ctx.beginPath();ctx.arc(q.x,q.y,q.R,0,TAU);ctx.stroke();}ctx.lineWidth=2;}}
    else if(q.k==='flag'){ctx.strokeStyle=rgba90(q.col,a);ctx.setLineDash([4,8]);const p=G.player,a0=Math.atan2(p.y-q.y,p.x-q.x);ctx.beginPath();for(let i=-4;i<=4;i+=2){ctx.moveTo(q.x,q.y+30);ctx.lineTo(q.x+Math.cos(a0+i*.12)*500,q.y+30+Math.sin(a0+i*.12)*500);}ctx.stroke();ctx.setLineDash([]);}
    if(q.t<q.tele+.2){const top=G.sb&&G.sb.sbk==='shore'&&G.sb.alive?G.sb.hzF*H+40:130;worldLabel(clamp(q.x||W/2,90,W-90),q.k==='flag'||q.k==='lek'?top:(q.y||H/2)-44,'ТЕНЬ · '+q.name,q.col);}}}
function under90(t){const X=G.x90;
  if(G.world){if(G.wez100&&G.wez100.length)ezDraw100(G.wez100,t);if(G.wn90)beams90(G.wn90,t);return;}
  if(!X||!inMission())return;
  if(X.sec===8){for(const f of X.flows)ribbon90(f,t,!(f.shut>0)&&!f.closed);
    for(const q of X.pud){const a=Math.min(1,q.t,(q.t0-q.t)*3),rr=q.r+3*Math.sin(t*3+q.x);rgDraw95(q.x,q.y,rr*1.08,'#5a0a16',.85*a,0,[.78,.7*a]);ctx.strokeStyle=rgba90('#ff6f86',.35*a);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(q.x,q.y,rr*.92,Math.PI*1.1,Math.PI*1.6);ctx.stroke();
      if(q.bub)for(const b of q.bub){const k=b.t/.9;if(k>=1)continue;ctx.strokeStyle=rgba90('#ff9aa8',.5*(1-k)*a);ctx.lineWidth=1;ctx.beginPath();ctx.arc(q.x+Math.cos(b.a)*b.d,q.y+Math.sin(b.a)*b.d,2+3*k,0,TAU);ctx.stroke();}}
    for(const q of X.pods)podDraw90(q,t);}
  if(X.nets.length)beams90(X.nets,t);
  for(const e of G.enemies){if(!e.alive||e.spawnT>0)continue;if(e.type==='keeper90'&&e.st!=='alert'){const c=e.see>0?mix90('#ffe9b0','#d8364a',e.see/.6):'#ffe9b0';ctx.fillStyle=rgba90(c,.08+.12*(e.see/.6));ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.arc(e.x,e.y,240,(e.fa||0)-35*Math.PI/180,(e.fa||0)+35*Math.PI/180);ctx.closePath();ctx.fill();ctx.strokeStyle=rgba90(c,.25);ctx.lineWidth=1;ctx.stroke();}}
  if(X.sec===9){erDraw100(X,t);ezDraw100(X.ez,t);if(X.tide)tideDraw100(X.tide,t);}
  if(typeof under95==='function')under95(t);}
function beams90(N,t){for(const n of N)for(const q of n.beams){if(!q.a.alive||!q.b.alive)continue;const cut=q.cut>0;ctx.strokeStyle=cut?'rgba(160,140,90,.25)':rgba90('#ffe47a',.55+.25*Math.sin(t*8+q.a.uid));ctx.lineWidth=cut?1:2;if(cut)ctx.setLineDash([3,7]);
    ctx.beginPath();ctx.moveTo(q.a.x,q.a.y);const mx=(q.a.x+q.b.x)/2+Math.sin(t*3+q.a.uid)*8,my=(q.a.y+q.b.y)/2+Math.cos(t*3+q.b.uid)*8;ctx.quadraticCurveTo(mx,my,q.b.x,q.b.y);ctx.stroke();ctx.setLineDash([]);
    if(!cut&&SET.fx){const k=(t*.8+q.a.uid*.13)%1;const x=(1-k)*(1-k)*q.a.x+2*(1-k)*k*mx+k*k*q.b.x,y=(1-k)*(1-k)*q.a.y+2*(1-k)*k*my+k*k*q.b.y;ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(x,y,2,0,TAU);ctx.fill();}}}
function podDraw90(q,t){ctx.save();ctx.translate(q.x,q.y);const op=q.st==='open'||q.st==='taken',lost=q.st==='lost';
  glow(0,0,46,lost?'#5a4048':op?C90.pil:C90.ark,lost?.15:.22+.08*Math.sin(t*1.2+q.x));
  ctx.fillStyle='#120a0c';ctx.strokeStyle=lost?'#6a4a52':op?C90.pil:C90.ark;ctx.lineWidth=2;const w=q.child?18:24,h=q.child?32:44;
  ctx.beginPath();ctx.roundRect?ctx.roundRect(-w/2,-h/2,w,h,w/2):ctx.rect(-w/2,-h/2,w,h);ctx.fill();ctx.stroke();
  if(!op&&!lost){ctx.globalAlpha=.55+.2*Math.sin(t*.9+q.y);ctx.fillStyle=C90.pil;ctx.beginPath();ctx.arc(0,-h*.22,w*.18,0,TAU);ctx.fill();ctx.fillRect(-w*.16,-h*.1,w*.32,h*.42);ctx.globalAlpha=1;
    ctx.strokeStyle=rgba90(C90.ark,.35);ctx.beginPath();ctx.moveTo(-w/2+3,0);ctx.lineTo(w/2-3,0);ctx.stroke();}
  else if(op){ctx.strokeStyle=rgba90(C90.pil,.6);ctx.beginPath();ctx.moveTo(-w/2,-h/2);ctx.lineTo(-w*.9,-h*.75);ctx.moveTo(w/2,-h/2);ctx.lineTo(w*.9,-h*.75);ctx.stroke();}
  if(q.ch>0){ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,h*.75,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,q.ch/(storyFlag('well38')==='silence'?2:1.5)));ctx.stroke();}
  if(q.kch>0){ctx.strokeStyle=C90.red;ctx.lineWidth=3;ctx.setLineDash([4,4]);ctx.beginPath();ctx.arc(0,0,h*.75+6,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,q.kch/3));ctx.stroke();ctx.setLineDash([]);}
  ctx.restore();const p=G.player;if(p&&!op&&!lost&&Math.hypot(p.x-q.x,p.y-q.y)<220)worldLabel(q.x,q.y-40,q.child?'ДЕТСКАЯ КАПСУЛА':'КАПСУЛА · СПИТ',q.kch>0?C90.red:C90.ark);}
function draw90(t){const X=G.x90;if(!X||!inMission())return;const p=G.player;
  for(const L of X.locks){const warn=L.st==='warn',cl=L.st==='closed',col=cl?C90.red:warn?(Math.sin(t*14)>0?'#ffffff':C90.ark):C90.ark,P_=L.pos,top=L.door-90,bot=L.door+90,len=L.len;
    ctx.save();if(L.hz)ctx.transform(0,1,1,0,0,0);
    ctx.fillStyle='rgba(30,10,12,.85)';ctx.strokeStyle=col;ctx.lineWidth=2;ctx.fillRect(P_-12,0,24,top);ctx.strokeRect(P_-12,-2,24,top+2);ctx.fillRect(P_-12,bot,24,len-bot);ctx.strokeRect(P_-12,bot,24,len-bot+2);
    for(let y=20;y<top;y+=36){ctx.beginPath();ctx.moveTo(P_-12,y);ctx.lineTo(P_+12,y+12);ctx.stroke();}for(let y=bot+20;y<len;y+=36){ctx.beginPath();ctx.moveTo(P_-12,y);ctx.lineTo(P_+12,y+12);ctx.stroke();}
    if(cl){ctx.fillStyle='rgba(216,54,74,.35)';ctx.fillRect(P_-10,top,20,bot-top);ctx.strokeRect(P_-10,top,20,bot-top);}else{ctx.globalAlpha=warn?.6:.25;ctx.setLineDash([4,6]);ctx.beginPath();ctx.moveTo(P_,top);ctx.lineTo(P_,bot);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
    ctx.restore();if(warn||cl)worldLabel(L.hz?L.x:L.x,L.hz?L.dy-24:top-14,cl?'ШЛЮЗ ЗАКРЫТ':'ЗАКРЫВАЕТСЯ',col);}
  for(const e of G.enemies){if(!e.alive||e.spawnT>0)continue;
    if(e.type==='fixer100'&&e.fx&&e.fx.alive){const T=e.fx,near=Math.hypot(T.x-e.x,T.y-e.y)<=225;ctx.strokeStyle=rgba90(C90.sh,near?.8:.25);ctx.lineWidth=near?3:1;ctx.setLineDash(near?[]:[3,6]);ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(T.x,T.y);ctx.stroke();ctx.setLineDash([]);
      if(near){ctx.strokeStyle='#ffffff';ctx.beginPath();ctx.arc(T.x,T.y,T.r+8,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,e.fxT/1.5));ctx.stroke();}}
    if(e.type==='valve90'&&e.vi===2&&e.gap95){const k=clamp(e.vb/1.2,0,1);ctx.strokeStyle=rgba90(C90.ark,.25+.5*k);ctx.lineWidth=e.tele90?2.5:1.5;ctx.setLineDash([5,5]);const G2=e.gap95.slice().sort((a,c)=>a.a-c.a);for(let i=0;i<G2.length;i++){const a0=G2[i].a+G2[i].w/2,n=G2[(i+1)%G2.length],a1=n.a-n.w/2+(i===G2.length-1?TAU:0);ctx.beginPath();ctx.arc(e.x,e.y,110,a0,a1>a0?a1:a1+TAU);ctx.stroke();}ctx.setLineDash([]);gapArrows95(e.x,e.y,118,e.gap95,k,'#ffffff');}
    if(e.type==='hollow100'&&e.inh&&p){ctx.strokeStyle=rgba90('#cfe8e0',.3);ctx.setLineDash([2,6]);ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(p.x,p.y);ctx.stroke();ctx.setLineDash([]);}
    if(e.type==='typo100'&&e.tpName&&p){const d_=Math.hypot(p.x-e.x,p.y-e.y);if(d_<380&&(d_>95||e.glitch95>0)){ctx.font='700 '+fpx(11)+'px "JetBrains Mono",monospace';const tw=ctx.measureText(e.tpName).width/2+4;worldLabel(clamp(e.x,tw,W-tw),e.y-e.r-12,e.tpName,'#b8ffe0');}}
    if(e.type==='witness100'){worldLabel(e.x,e.y-e.r-14,'СВИДЕТЕЛЬ','#ffffff');if(e.sh100>0){ctx.strokeStyle='#ffffff';ctx.globalAlpha=.6;ctx.beginPath();ctx.arc(e.x,e.y,e.r+8,0,TAU);ctx.stroke();ctx.globalAlpha=1;}}
    if(e.type==='pass90'){worldLabel(e.x,e.y-e.r-14,e.hostT>0?'ПАССАЖИР · НЕ УЗНАЁТ':'ПАССАЖИР · '+Math.ceil(e.life90||0),e.hostT>0?C90.red:C90.pil);}
    if(e.type==='embryo90'&&e.hatch>0&&e.hatch<5)worldLabel(e.x,e.y-e.r-12,fmt85(e.hatch),'#ff9fb0');
    if(e.type==='keeper90'&&e.st==='wake')worldLabel(e.x,e.y-e.r-14,'БУДИТ СПЯЩЕГО',C90.red);}
  if(X.sec===9&&X.shad.length)shadDraw100(X,t);
  if(typeof draw95==='function')draw95(t);}
// --- поверх маски: таблички, зерно, сердцебиение без шкалы ---
let grain90=null;
function grainPat90(){if(grain90)return grain90;const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d'),im=g.createImageData(128,128);for(let i=0;i<im.data.length;i+=4){const v=Math.random()*255|0;im.data[i]=im.data[i+1]=im.data[i+2]=v;im.data[i+3]=Math.random()<.5?255:0;}g.putImageData(im,0,0);grain90=ctx.createPattern(c,'repeat');return grain90;}
function top90(t){const X=G.x90;if(!X||!inMission())return;const p=G.player;
  ctx.save();ctx.setTransform(1,0,0,1,0,0);const w=cv.width,h=cv.height;
  if(X.sec===9&&SET.fx&&!G.lowFx&&!isMob()&&G.q>=2){ctx.globalAlpha=.07;ctx.fillStyle=grainPat90();ctx.translate(Math.random()*128|0,Math.random()*128|0);ctx.fillRect(-128,-128,w+256,h+256);ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;}
  ctx.restore();
  if(X.hud&&X.hud.cur==='hp'||X.hudAll){if(p&&p.hp/G.st.maxHp<.35){const k=beat90(t*1.6);vig95('#d8364a',.12+.3*k,.3);}}
  if(X.plq){const q=X.plq,d=EDEF[q.k];if(d){const a=clamp(Math.min(q.t*4,(4.4-q.t)*3),0,1),sp=q.t<.35?1+.08*Math.sin(q.t/.35*Math.PI):1;const cx=CX+VW/2,cy=CY+(VH>VW*1.15?VH*.3:isMob()?VH*.4:Math.min(VH*.22,160));
      ctx.save();ctx.globalAlpha=a;ctx.translate(cx,cy);ctx.scale(sp,sp);const nm=d.name.toUpperCase(),tx=PLQ95[q.k]||PLQ90[q.k]||'';ctx.font='500 '+fpx(11)+'px "JetBrains Mono",monospace';const tw=Math.max(ctx.measureText(tx).width,200);
      const ic=fpx(40),bw=Math.min(VW-24,tw+ic+48),bh=fpx(48);ctx.fillStyle='rgba(6,8,12,.88)';ctx.strokeStyle=d.col;ctx.lineWidth=1.5;ctx.fillRect(-bw/2,-bh/2,bw,bh);ctx.strokeRect(-bw/2,-bh/2,bw,bh);ctx.fillStyle=d.col;ctx.fillRect(-bw/2,-bh/2,3,bh);
      // анимированная иконка врага слева
      {const f={type:q.k,x:0,y:0,vx:Math.cos(q.t*2)*60,vy:Math.sin(q.t*2)*60,r:Math.min(EDEF[q.k].r,16),t:q.t,seed:1,alive:true,flash:0,spawnT:0,hp:1,maxHp:1,fa:q.t,fa95:q.t*.8,dir:1,look:2,vi:Math.floor(q.t*2)%4,fed:3,hatch:5,hatch0:15,tp:{mv:'ram',gun:'fan3',hab:'armor'},tpN:['','',''],pul95:.5+.5*Math.sin(q.t*6),tl95:Math.sin(q.t*4)>.3?1:0};
        ctx.save();ctx.translate(-bw/2+ic/2+10,0);const s2=ic/(Math.max(24,f.r*2.6));ctx.scale(s2,s2);try{drawEnemy(f,performance.now()/1000,true);}catch(err){}ctx.restore();}
      ctx.textAlign='left';ctx.textBaseline='middle';const x0=-bw/2+ic+20;ctx.font='700 '+fpx(12)+'px "JetBrains Mono",monospace';ctx.fillStyle=d.col;ctx.fillText('НОВОЕ · '+nm,x0,-bh*.2);ctx.font='500 '+fpx(10.5)+'px "JetBrains Mono",monospace';ctx.fillStyle='#c9d2de';
      let s=tx;const mw=bw-(x0+bw/2)-10;while(s.length>8&&ctx.measureText(s).width>mw)s=s.slice(0,-2);if(s!==tx)s=s.slice(0,-1)+'…';ctx.fillText(s,x0,bh*.22);ctx.restore();ctx.textAlign='left';ctx.textBaseline='alphabetic';}}
  if(typeof top95==='function')top95(t);}
// --- рисунки сущностей ---
function drawE90(e,t,icon,col,face,alpha,P){const r=e.r;
  if(e.hid90&&!icon){alpha*=.22+(e.inh?.25:0);ctx.globalAlpha=alpha;}
  if(e.mem100&&!icon){ctx.globalAlpha=alpha*.8;}
  switch(e.type){
    case 'clot90':{const big=e.big95,air=!icon&&e.cs==='air',hz=air?e.hz95||0:0,sq=!icon&&e.cs==='squat'?(e.sq95||0):0;if(air){ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(0,0,r*1.1,r*.5,0,0,TAU);ctx.fill();ctx.translate(0,-hz);}ctx.scale(1+.25*sq,1-.2*sq);
      ctx.fillStyle=big?'#4a0c16':'#3a0a12';ctx.beginPath();for(let i=0;i<=18;i++){const a=i/18*TAU,rr=r*(1+.12*Math.sin(a*3+t*2.4+e.seed)+.06*Math.sin(a*5-t*3));if(i)ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();
      ctx.fillStyle=rgba90(C90.blood,.6);for(let i=0;i<(big?5:3);i++){const a=e.seed+i*2.1+t*.3;ctx.beginPath();ctx.arc(Math.cos(a)*r*.4,Math.sin(a)*r*.4,r*.18,0,TAU);ctx.fill();}if(sq>0){ctx.strokeStyle=rgba90(C95.dash,.5+.5*sq);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(0,0,r+5,0,TAU);ctx.stroke();}break;}
    case 'valve90':{const open=icon?1:e.vi===3?0:e.vi===2?.6:1,a0=open*.9;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();ctx.fillStyle=e.vi===3?C90.red:e.tele90?'#ffffff':col;
      for(const s of [-1,1]){ctx.save();ctx.rotate(s*a0*.5);ctx.beginPath();ctx.moveTo(0,0);ctx.arc(0,0,r*.8,s<0?Math.PI*.55:-Math.PI*.45,s<0?Math.PI*1.45:Math.PI*.45);ctx.closePath();ctx.globalAlpha=alpha*(.35+.4*(1-open));ctx.fill();ctx.globalAlpha=alpha;ctx.stroke();ctx.restore();}
      if(!icon){ctx.fillStyle=col;for(let i=0;i<4;i++){ctx.globalAlpha=alpha*(i===e.vi?1:.25);ctx.beginPath();ctx.arc(-9+i*6,r+7,2,0,TAU);ctx.fill();}ctx.globalAlpha=alpha;}break;}
    case 'keeper90':{const a=icon?0:(e.fa||0);ctx.rotate(a);ctx.beginPath();ctx.ellipse(0,0,r*1.2,r*.75,0,0,TAU);ctx.fill();ctx.stroke();ctx.fillStyle=e.st==='alert'?C90.red:'#fff6d8';ctx.beginPath();ctx.arc(r*.75,0,r*.28,0,TAU);ctx.fill();
      if(!icon&&e.st!=='alert')glow(r*.75,0,12,'#fff6d8',.5);ctx.strokeStyle=col;ctx.beginPath();ctx.moveTo(-r*1.2,0);ctx.lineTo(-r*1.7,-r*.4);ctx.moveTo(-r*1.2,0);ctx.lineTo(-r*1.7,r*.4);ctx.stroke();break;}
    case 'phago90':{const bu=e.burst90>0||!!e.spir95,fed=icon?3:Math.min(10,e.fed||0),red=fed/10;ctx.fillStyle=bu&&Math.sin(t*40)>0?'#ffffff':mix90('#2a120a','#5a0a14',red);ctx.strokeStyle=e.flash>0?'#ffffff':mix90(col,'#ff4f6e',red);ctx.beginPath();for(let i=0;i<=20;i++){const a=i/20*TAU,rr=r*(1+.15*Math.sin(a*4+t*3+e.seed)+(e.lg95?.12*Math.max(0,Math.cos(a-(e.lg95.a-face))):0));if(i)ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();
      const sc=icon?'#ffd36b':shipCol();ctx.strokeStyle=sc;ctx.lineWidth=2;for(let i=0;i<fed;i++){const q=e.eat95&&e.eat95[i],a=(q?q.a:i*2.4)+t*(1.2+i*.07),d=r*(q?q.d:.5);ctx.save();ctx.translate(Math.cos(a)*d,Math.sin(a)*d);ctx.rotate(a+t*3);ctx.beginPath();ctx.moveTo(-3,0);ctx.lineTo(3,0);ctx.stroke();ctx.restore();}
      ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,r*.28,0,TAU);ctx.globalAlpha=alpha*.7;ctx.fill();ctx.globalAlpha=alpha;if(!icon&&e.nos95>0){ctx.strokeStyle=rgba90('#ffffff',.6);ctx.setLineDash([3,4]);ctx.beginPath();ctx.arc(0,0,r+5,0,TAU);ctx.stroke();ctx.setLineDash([]);}break;}
    case 'neuron90':{ctx.rotate(e.seed);ctx.beginPath();for(let i=0;i<5;i++){const a=i/5*TAU;ctx.moveTo(Math.cos(a)*r*.5,Math.sin(a)*r*.5);ctx.lineTo(Math.cos(a+.2)*r*1.4,Math.sin(a+.2)*r*1.4);}ctx.stroke();ctx.beginPath();ctx.arc(0,0,r*.7,0,TAU);ctx.fill();ctx.stroke();
      ctx.fillStyle=col;ctx.globalAlpha=alpha*(.5+.4*Math.sin(t*6+e.seed));ctx.beginPath();ctx.arc(0,0,r*.35,0,TAU);ctx.fill();ctx.globalAlpha=alpha;
      if(e.weak90&&!icon){ctx.rotate(-e.seed+t);ctx.strokeStyle='#ffffff';ctx.setLineDash([4,5]);ctx.beginPath();ctx.arc(0,0,r+8,0,TAU);ctx.stroke();ctx.setLineDash([]);}break;}
    case 'embryo90':{const k=icon?.5:1-clamp((e.hatch||0)/(e.hatch0||15),0,1),pr=1+.06*Math.sin(t*(3+k*14));ctx.scale(pr,pr);ctx.fillStyle=rgba90('#ff9fb0',.15+.2*k);ctx.beginPath();ctx.ellipse(0,0,r,r*1.2,0,0,TAU);ctx.fill();ctx.stroke();
      if(!icon&&e.hTy&&EDEF[e.hTy]){ctx.save();ctx.globalAlpha=alpha*(.25+.35*(1-clamp(e.hatch/3,0,1)));const f={type:e.hTy,x:0,y:0,vx:0,vy:0,r:Math.min(EDEF[e.hTy].r,r*.8),t:e.t,seed:e.seed,alive:true,flash:0,spawnT:0,hp:1,maxHp:1,fa:0,dir:1};ctx.scale(.7,.7);try{drawEnemy(f,t,true);}catch(err){}ctx.restore();}
      else{ctx.strokeStyle=col;ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,r*.1,r*.45*(.6+.4*k),.4+t*.5,4.6+t*.5);ctx.stroke();}if(!icon){ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,r+5,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();}break;}
    case 'pass90':{if(!icon){ctx.strokeStyle=e.hostT>0?C90.red:'#6bb8ff';ctx.lineWidth=2;ctx.globalAlpha=alpha*(.55+.25*Math.sin(t*4));ctx.beginPath();ctx.arc(0,0,r+9,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}ctx.rotate(icon?-Math.PI/2:(e.face90!==undefined?e.face90:face));ctx.fillStyle='#141a28';ctx.strokeStyle=e.hostT>0?C90.red:col;shipPath85(.75);ctx.fill();ctx.stroke();ctx.fillStyle='#6bb8ff';ctx.beginPath();ctx.arc(2,0,2.5,0,TAU);ctx.fill();break;}
    case 'heart90':{if(icon){ctx.scale(.45,.45);heartBody95(0,0,52,1,t,0,0,0,0);break;}const b=G.sb===e?e:null;if(b&&b.fx85&&b.fx85.kind==='stop'&&b.fx85.t>1.2){ctx.globalAlpha=alpha*Math.max(.25,1-(b.fx85.t-1.2)*.4);}
      const sq=b?systole95(b):0,sw=b&&b.swell>0?.3*Math.sin(Math.min(1,b.swell/.6)*Math.PI):0;heartBody95(0,0,e.r,b?1-.13*sq+sw:1,t,b?b.openK||0:0,e.flash,b?b.crack||0:0,b&&b.flashC95>0?b.flashC95:0);if(b&&b.flashC95>0)b.flashC95-=VDT74;/* ARCH·75 A-22 */break;}
    case 'hvalve90':{const b=e.host85,a=b&&b.ves?b.ves[e.vi].a:0;ctx.rotate(a);ctx.fillStyle='#2a1608';ctx.beginPath();ctx.moveTo(-r*.8,-r);ctx.quadraticCurveTo(r*1.3,-r*.6,r*.9,0);ctx.quadraticCurveTo(r*1.3,r*.6,-r*.8,r);ctx.closePath();ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-r*.4,0);ctx.lineTo(r*.6,0);ctx.stroke();break;}
    case 'hkey90':{if(!icon){alpha=e.spawnT>0?Math.max(0,1-e.spawnT):1;ctx.globalAlpha=alpha;}const b=e.host85,hi=b&&b.keys&&b.keys[b.keyI]===e&&!(b.launch>0),lit=e.lit90,win=b&&heartNear(b)<=heartWin(b);ctx.fillStyle=lit?rgba90(C90.ark,.5):'#140a06';ctx.strokeStyle=hi?(win?'#ffffff':C90.warm):lit?C90.ark:'#6a5a3a';ctx.lineWidth=hi?3:2;
      ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();if(hi&&!icon){glow(0,0,r*2,win?'#ffffff':C90.ark,win?.6:.25);const k=b?1-clamp(b.bt/b.btN,0,1):0;ctx.globalAlpha=alpha*.7;ctx.beginPath();ctx.arc(0,0,r+6+36*k,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}
      ctx.fillStyle=hi?'#ffffff':lit?C90.ark:'#8a7a5a';ctx.font='700 '+Math.round(r*.7)+'px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(['I','II','III','IV'][e.ki||0],0,1);ctx.textAlign='left';ctx.textBaseline='alphabetic';break;}
    case 'thromb90':{ctx.fillStyle='#3a0a12';ctx.beginPath();for(let i=0;i<=14;i++){const a=i/14*TAU,rr=r*(1+.18*Math.sin(a*3+t*4));if(i)ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();
      if(!icon&&e.thrT!==undefined){ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,r+6,-Math.PI/2,-Math.PI/2+TAU*clamp(e.thrT/8,0,1));ctx.stroke();}break;}
    case 'eraser100':{ctx.rotate(e.t*.6);ctx.fillRect(-r*.8,-r*.5,r*1.6,r);ctx.strokeRect(-r*.8,-r*.5,r*1.6,r);ctx.fillStyle=col;ctx.globalAlpha=alpha*.5;ctx.fillRect(-r*.8,-r*.5,r*.5,r);ctx.globalAlpha=alpha;if(e.stun>0&&!icon){ctx.rotate(-e.t*.6);worldLabel(0,-r-10,'ОГЛУШЁН',col);}break;}
    case 'hollow100':{if(!icon&&SET.fx){ctx.save();ctx.globalAlpha=Math.min(1,alpha*1.6);ctx.strokeStyle=rgba90('#cfe8e0',.5);ctx.lineWidth=1;ctx.beginPath();for(let i=0;i<=12;i++){const a=i/12*TAU,rr=r*1.35+3*Math.sin(a*5+t*14+e.seed);if(i)ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.stroke();ctx.restore();}
      ctx.rotate(face);ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(r*1.1,0);ctx.lineTo(-r*.8,-r*.8);ctx.lineTo(-r*.4,0);ctx.lineTo(-r*.8,r*.8);ctx.closePath();ctx.stroke();ctx.setLineDash([]);if(e.ls==='zig'||e.ls==='go'){ctx.fillStyle=rgba90(col,.3);ctx.fill();}
      if(!icon&&(e.inh||e.ls==='zig')){ctx.globalAlpha=1;ctx.fillStyle='#ff2e4a';for(const s of [-1,1]){ctx.beginPath();ctx.arc(r*.35,s*r*.28,2.6,0,TAU);ctx.fill();}glow(r*.3,0,14,'#ff2e4a',.7);}break;}
    case 'witness100':{ctx.rotate(face);ctx.fillStyle='#10161a';shipPath85(.75);ctx.fill();ctx.stroke();ctx.fillStyle='#ffffff';ctx.globalAlpha=alpha*(.6+.4*Math.sin(t*5));ctx.beginPath();ctx.arc(-4,0,3,0,TAU);ctx.fill();ctx.globalAlpha=alpha;break;}
    case 'typo100':{const gl=!icon&&e.glitch95>0,g=icon?0:gl?rnd(-4,4):Math.sin(t*23+e.seed)>.85?rnd(-3,3):0;ctx.translate(g,0);ctx.rotate(face);const tp=e.tp||{mv:'ram',gun:'single',hab:'armor'};
      // крылья — от привычки, нос — от хода, орудие — от оружия
      ctx.fillStyle=gl?'#1a3a30':'#0a1a16';ctx.beginPath();if(tp.hab==='armor'||tp.hab==='mirror'){ctx.rect(-r*.8,-r*.95,r*.7,r*1.9);}else if(tp.hab==='fast'||tp.hab==='fade'){ctx.moveTo(-r*.2,-r*.4);ctx.lineTo(-r*1.1,-r*1.05);ctx.lineTo(-r*.7,0);ctx.lineTo(-r*1.1,r*1.05);ctx.lineTo(-r*.2,r*.4);}else if(tp.hab==='split'||tp.hab==='twin'){for(const s of [-1,1]){ctx.moveTo(-r*.1,s*r*.3);ctx.lineTo(-r*.9,s*r*.95);ctx.lineTo(-r*.5,s*r*.2);}}else{ctx.ellipse(-r*.45,0,r*.5,r*.85,0,0,TAU);}ctx.fill();ctx.stroke();
      ctx.fillStyle='#0a1a16';ctx.beginPath();if(tp.mv==='ram'||tp.mv==='jink'){ctx.moveTo(r*1.25,0);ctx.lineTo(-r*.1,-r*.45);ctx.lineTo(-r*.1,r*.45);}else if(tp.mv==='orbit'||tp.mv==='spiral'){ctx.arc(r*.25,0,r*.55,0,TAU);}else if(tp.mv==='blink'){ctx.moveTo(r,0);ctx.lineTo(r*.2,-r*.6);ctx.lineTo(-r*.2,0);ctx.lineTo(r*.2,r*.6);}else{ctx.moveTo(r*.95,0);ctx.lineTo(0,-r*.55);ctx.lineTo(-r*.25,0);ctx.lineTo(0,r*.55);}ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle=gl?'#ffffff':'#b8ffe0';ctx.lineWidth=2.5;ctx.beginPath();if(tp.gun==='fan3'||tp.gun==='ring'){for(const s of [-1,0,1]){ctx.moveTo(r*.2,s*r*.3);ctx.lineTo(r*.75,s*r*.45);}}else if(tp.gun==='lance'){ctx.moveTo(0,0);ctx.lineTo(r*1.5,0);}else if(tp.gun==='mine'||tp.gun==='boom'){ctx.arc(r*.3,0,r*.25,0,TAU);}else if(tp.gun==='orb'){ctx.arc(0,0,r*1.15,0,TAU);}else if(tp.gun!=='none'){ctx.moveTo(r*.2,0);ctx.lineTo(r*.9,0);}ctx.stroke();ctx.lineWidth=2;
      if(!icon&&e.orb95){const O=e.orb95;ctx.rotate(-face);for(let i=0;i<O.n;i++){const q=O.a+i*TAU/3;ctx.fillStyle='#b8ffe0';ctx.beginPath();ctx.arc(Math.cos(q)*30,Math.sin(q)*30,4.5,0,TAU);ctx.fill();}}
      if(e.fade100&&!icon)ctx.globalAlpha=alpha*.4;break;}
    case 'fixer100':{ctx.rotate(face);ctx.beginPath();ctx.arc(0,0,r*.8,0,TAU);ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-r*.5,0);ctx.lineTo(r*.5,0);ctx.moveTo(0,-r*.5);ctx.lineTo(0,r*.5);ctx.stroke();ctx.beginPath();ctx.moveTo(r*.8,0);ctx.lineTo(r*1.4,0);ctx.stroke();break;}
    case 'echo100':{ctx.rotate(icon?-Math.PI/2:(e.face||0));ctx.globalAlpha=alpha*(.45+.2*Math.sin(t*7));ctx.strokeStyle='#e0fff4';ctx.lineWidth=1.5;ctx.setLineDash([4,3]);shipPath85(1);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=alpha;break;}
    case 'tide100':{ctx.fillStyle='rgba(4,10,10,.9)';ctx.fillRect(-r,-r*.4,r*2,r*.8);ctx.strokeRect(-r,-r*.4,r*2,r*.8);ctx.clearRect(-r*.2,-r*.4,r*.4,r*.8);break;}
    case 'noname100':{const L=e.look||0;ctx.rotate(face);ctx.beginPath();for(let i=0;i<7;i++){const a=i/7*TAU;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r);}ctx.closePath();ctx.fill();ctx.stroke();
      ctx.fillStyle=L>3?'#ffffff':col;ctx.globalAlpha=alpha*(.3+.14*L);ctx.beginPath();ctx.ellipse(0,0,r*.55,r*.22*(.4+.12*L),0,0,TAU);ctx.fill();ctx.globalAlpha=alpha;if(L>0&&!icon){ctx.strokeStyle='#ffffff';ctx.globalAlpha=alpha*Math.min(.8,L*.16);ctx.beginPath();ctx.arc(0,0,r+6,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}break;}
    case 'shore100':{if(icon){ctx.strokeStyle=col;ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<=8;i++){const x=-20+i*5,y=Math.sin(i*1.3)*4;if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);}ctx.stroke();}break;}
    default:return typeof drawE95==='function'?drawE95(e,t,icon,col,face,alpha,P):false;}
  return true;}
// --- Сердце: камера, сосуды, волны, метроном ---
// --- Берег: пустота над горизонтом ---
// ======================= ЗВУК =======================
const SND90={};
const SND90P=new Set(['beat','perfect','key','launch','stop','alarm','wake','lost','fragGet','plaque','final','tide','tideW','beacon','beaconX','ebb','chime','quiet','arr','miss','tick']);
function snd90(kind,v){if(!AU.ctx||!SET.sfx||!AU.sfx)return;const c=AU.ctx,t=c.currentTime;const now=performance.now();if(SND90[kind]&&now-SND90[kind]<80)return;SND90[kind]=now;if(typeof vox95==='function'&&!vox95(.4,SND90P.has(kind)))return;
  const det=()=>Math.pow(2,rnd(-30,30)/1200);
  const out=(pan)=>{if(pan&&c.createStereoPanner){const p=c.createStereoPanner();p.pan.value=clamp(pan,-.6,.6);p.connect(AU.sfx);return p;}return AU.sfx;};
  const tone=(f0,f1,dur,type,vol,delay,pan)=>{delay=delay||0;const o=c.createOscillator(),g=c.createGain(),k=det();o.type=type;o.frequency.setValueAtTime(f0*k,t+delay);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1*k),t+delay+dur);g.gain.setValueAtTime(0.0001,t+delay);g.gain.linearRampToValueAtTime(vol,t+delay+.01);g.gain.exponentialRampToValueAtTime(.0001,t+delay+dur);o.connect(g);g.connect(out(pan));o.start(t+delay);o.stop(t+delay+dur+.03);};
  const noise=(dur,vol,f,type,delay,f2,pan,q)=>{delay=delay||0;const s=c.createBufferSource();s.buffer=noiseBuf95(c);const fl=c.createBiquadFilter();fl.type=type||'lowpass';if(q)fl.Q.value=q;fl.frequency.setValueAtTime(f,t+delay);if(f2)fl.frequency.exponentialRampToValueAtTime(f2,t+delay+dur);const g=c.createGain();g.gain.setValueAtTime(vol,t+delay);g.gain.linearRampToValueAtTime(.0001,t+delay+dur);s.connect(fl);fl.connect(g);g.connect(out(pan));s.start(t+delay,Math.random()*Math.max(0,1.9-dur),dur+.05);};
  switch(kind){
    case 'beat':{const k=(v===undefined?1:v)*.7;tone(58,40,.32,'sine',.42*k);noise(.18,.22*k,300);tone(52,38,.26,'sine',.28*k,.2);noise(.12,.12*k,260,'lowpass',.2);tone(1250,700,.035,'triangle',.03*k);break;}
    case 'perfect':tone(660,660,.25,'sine',.07);tone(990,990,.22,'sine',.05,.02);break;
    case 'tick':tone(v?1760:1320,v?1760:1320,.05,'square',.05);break;
    case 'key':{const f=440*Math.pow(2,[0,4,7,12,16][clamp((v||1)-1,0,4)]/12);tone(f,f,.5,'triangle',.09);tone(f*2,f*2,.3,'sine',.03,.02);break;}
    case 'miss':tone(220,208,.35,'sawtooth',.06);tone(233,220,.35,'sawtooth',.05);break;
    case 'launch':for(const iv of [0,7,12,16])tone(220*Math.pow(2,iv/12),220*Math.pow(2,iv/12),1.4,'triangle',.05,iv*.012);noise(1,.25,600,'lowpass',0,3000);break;
    case 'stop':tone(80,30,2.2,'sine',.25);noise(1.6,.2,300,'lowpass',0,60);break;
    case 'arr':for(let i=0;i<3;i++)tone(70,45,.2,'sine',.2,[0,.15,.42][i]);break;
    case 'cells':noise(.5,.15,500,'bandpass',0,1500);break;
    case 'heal':noise(.6,.2,400,'lowpass',0,120);tone(180,120,.5,'sine',.08);break;
    case 'lock':noise(.4,.4,180,'bandpass',0,140,0,6);tone(90,60,.4,'square',.06);break;
    case 'lockw':for(let i=0;i<3;i++)tone(880,880,.06,'square',.03,i*.25);break;
    case 'locko':noise(.5,.15,1200,'bandpass',0,400);break;
    case 'blop':{const f=300+(v||0)*60;tone(f,f*1.6,.12,'sine',.08);break;}
    case 'burst':noise(.35,.4,1200,'lowpass',0,200);tone(400,90,.3,'square',.06);break;
    case 'quiet':tone(1400,1400,.04,'sine',.05);if(AU.duckG){AU.duckG.gain.setTargetAtTime(.25,t,.02);AU.duckG.gain.setTargetAtTime(MUS.duckT||1,t+.35,.2);}break;
    case 'spot':tone(1100,1100,.08,'square',.04);tone(880,880,.12,'square',.04,.09);break;
    case 'alarm':for(let i=0;i<4;i++)tone(1568*Math.pow(2,[0,3,7,10][i]/12),1568*Math.pow(2,[0,3,7,10][i]/12),.25,'sine',.04,i*.08);break;
    case 'wake':for(let i=0;i<3;i++)tone(349*Math.pow(2,[0,4,7][i]/12),349*Math.pow(2,[0,4,7][i]/12),1.1,'sine',.06,i*.12);break;
    case 'lost':for(let i=0;i<3;i++)tone(392*Math.pow(2,[0,-3,-7][i]/12),392*Math.pow(2,[0,-3,-7][i]/12),.6,'triangle',.06,i*.18);break;
    case 'flow':noise(.35,.12,900,'bandpass',0,2400);break;
    case 'cut':tone(2000,500,.12,'square',.05);noise(.1,.2,3000,'highpass');break;
    case 'valve':tone(110,50,.35,'sine',.3);noise(.2,.2,400);break;
    case 'dissolve':noise(.5,.2,3000,'highpass',0,800);break;
    case 'pud':noise(.4,.25,250,'lowpass',0,90);break;
    case 'hatch':noise(.15,.3,2200,'bandpass');tone(600,200,.2,'triangle',.06);break;
    case 'inhale':noise(.45,.18,1800,'highpass',0,5000,v||0);break;
    case 'fix':tone(200,900,.6,'sawtooth',.04);break;
    case 'erase':noise(.4,.1,4000,'highpass',0,1500);break;
    case 'eraseT':noise(.6,.06,6000,'highpass');break;
    case 'crumble':for(let i=0;i<4;i++)noise(.08,.15,1500+i*400,'bandpass',i*.07);break;
    case 'chime':for(let i=0;i<3;i++)tone(1046*Math.pow(2,[0,4,7][i]/12),1046*Math.pow(2,[0,4,7][i]/12),.5,'sine',.04,i*.08);break;
    case 'tideW':noise(2.6,.25,120,'lowpass',0,400);break;
    case 'tide':noise(3,.3,500,'lowpass',0,150);tone(55,45,2,'sine',.15);break;
    case 'frag':tone(700,720,.6,'sine',.04);tone(1100,1080,.6,'sine',.03,.05);break;
    case 'fragGet':for(let i=0;i<4;i++)tone(784*Math.pow(2,[0,5,7,12][i]/12),784*Math.pow(2,[0,5,7,12][i]/12),.7,'sine',.05,i*.1);break;
    case 'beacon':for(let i=0;i<5;i++)tone(523*Math.pow(2,BEACON_NOTE[i]/12),523*Math.pow(2,BEACON_NOTE[i]/12),1.5,'sine',.025,i*.15);break;
    case 'beaconX':{const f=523*Math.pow(2,BEACON_NOTE[v||0]/12);tone(f,f*.5,1.6,'sine',.08);noise(.6,.2,2000,'bandpass',0,300);break;}
    case 'ebb':noise(1.6,.3,2000,'lowpass',0,200);break;
    case 'shadow':tone(150,450,1,'sawtooth',.03);noise(1,.08,800,'bandpass',0,2400);break;
    case 'plaque':tone(1320,1320,.08,'sine',.04);tone(1760,1760,.12,'sine',.03,.07);break;
    case 'final':noise(1.4,.25,800,'lowpass',0,5000);tone(220,660,1.4,'sine',.06);break;}}
// ======================= МУЗЫКА =======================
SC_.s8={name:'Сердце Ковчега',root:41,v:[[0,7,12,16],[5,12,16,19],[-3,4,9,12],[0,7,9,14]],chordT:[12,18],pad:['triangle',380,900,.044],sub:.09,noise:['lowpass',320,.012,.04],bell:['glass',9,15,.02],rev:.5,alert:1,vol:.7,bpm:50,ark90:1};
SC_.mx8={name:'Бой · Сердце Ковчега',root:41,v:[[0,7,12,16],[5,12,16,19],[-3,4,9,12]],chordT:[8,12],pad:['sawtooth',360,1000,.028],sub:.1,noise:['bandpass',700,.012,.08],bell:['glass',12,18,.016],rev:.4,fight:1,bpm:50,pulse:'q',toms:'fight',vol:.95,ark90:1};
SC_.s9={name:'Стёртые берега',root:44,v:[[0,7,14,19],[-5,2,9,14],[0,5,12,17]],chordT:[16,24],pad:['sine',420,1000,.042],sub:.06,noise:['lowpass',500,.01,.03],bell:['shine',6,11,.024],rev:.7,alert:1,vol:.66,bpm:64,shore90:1};
SC_.mx9={name:'Бой · Стёртые берега',root:44,v:[[0,7,14,19],[-5,2,9,14]],chordT:[10,16],pad:['triangle',380,950,.034],sub:.09,noise:['bandpass',900,.01,.08],bell:['shine',10,16,.018],rev:.55,fight:1,bpm:92,pulse:'q',toms:'fight',vol:.9,shore90:1};
SC_.b42={name:'Сердце',root:41,v:[[0,7,12,16],[-3,4,9,12],[5,12,16,19]],chordT:[8,12],pad:['sawtooth',340,1100,.03],sub:.12,noise:['lowpass',300,.02,.05],bell:['glass',10,16,.016],rev:.45,fight:0,bpm:50,vol:.9,heart90:1,boss90:1};
SC_.b46={name:'Берег',root:44,v:[[0,7,14,19],[0,5,12,17]],chordT:[14,20],pad:['sine',380,900,.04],sub:.08,noise:['lowpass',420,.012,.04],bell:null,rev:.75,fight:0,bpm:64,vol:.85,shore46:1,boss90:1};
SECSC80.add('s8');SECSC80.add('s9');SECSC80.add('mx8');SECSC80.add('mx9');
function step90(P,t,st,bar){const S=P.sc,X=P.ext||{},root=S.root+(P.semi||0);if(!AU.ctx)return;step110(P,t,st,bar);
  if(S.ark90&&st%4===0){const v=S.fight?.26:.2*(P.I>0?1:.6);ev(t,58,.3,'sine',v,P.L.toms,.004,40);ev(t+.19,52,.24,'sine',v*.6,P.L.toms,.004,38);}
  if(S.ark90&&X.alarm90&&st%2===0){const pent=[0,2,4,7,9];const n=root+36+pent[(st/2+bar)%5];ev(t,mtof(n),.35,'sine',.02,P.L.bell,.005,null,rnd(-.5,.5));}
  if(S.shore90&&st===0&&bar%2===0&&Math.random()<.8){const iv=P.chord[Math.random()*P.chord.length|0],d=Math.random()<.6?rnd(.4,1.2):3;ev(t,mtof(root+24+iv),d,'sine',.025,P.L.bell,.02,null,rnd(-.6,.6));}
  if(S.heart90&&X.ph90<4&&st===0)ev(t,mtof(root+12),1.6,'triangle',.03,P.L.sub,.05);
  if(S.heart90&&X.ph90===4&&st%4===0)ev(t,mtof(root+36),.06,'square',.012,P.L.tick,.002);
  if(S.shore46&&st===0){const m=X.notes46||0;for(let i=0;i<5;i++)if(m&(1<<i))ev(t+i*.04,mtof(root+24+BEACON_NOTE[i]),3.4,'sine',.02,P.L.bell,.3,null,(i-2)*.25);}}
function mus90(T){T=mus110(T);const X=G.x90;
  if(inMission()&&X&&X.sec===8&&X.alarmOn&&/^mx8/.test(T.id)){if(X.alarm>=60){T.ext.alarm90=1;T.ext.bpmAdd=(T.ext.bpmAdd||0)+20;}else if(X.alarm>=30)T.I=Math.max(T.I,.6);}
  if(inMission()&&X&&X.sec===9&&X.hud&&X.hud.cur)T.lp=Math.min(T.lp||18000,2400);
  return T;}

// ===== 0.9: мир IX–X, награды, модули, справочник, хроника =====
Object.assign(SKINS,{
  ark90:{name:'Ковчег',col:'#ffd36b',bul:'#ffe9b0',trail:'#d8364a',d:'',unlock:0,find:'СЕКТОР IX · МАСТЕРСТВО «СЕРДЦЕ»'},
  dawn90:{name:'Рассвет Ковчега',col:'#ffe9b0',bul:'#ffffff',trail:'#ffd36b',d:'',unlock:0,find:'СЕКТОР IX · ???'},
  typo100:{name:'Опечатка',col:'#b8ffe0',bul:'#e0fff4',trail:'#7affc9',d:'',unlock:0,find:'СЕКТОР X · 30 ОПЕЧАТОК'},
  tidemark100:{name:'Линия прилива',col:'#7affc9',bul:'#d8fff0',trail:'#3a8a70',d:'',unlock:0,find:'СЕКТОР X · МАСТЕРСТВО «БЕРЕГ»'},
  shore100s:{name:'Пустой берег',col:'#f4fff9',bul:'#ffffff',trail:'#cfe8e0',d:'',unlock:0,find:'СЕКТОР X · ???'}});
Object.assign(STORY_HULL,{ark90:'Обшивка цвета сердечной камеры. Внутри корпуса — тихий ритм: пятьдесят ударов в минуту.',dawn90:'Иллюминаторы по всему борту. В каждом кто-то смотрит наружу — впервые за все циклы.',
  typo100:'Корпус собран из трёх чужих. Швы видно, но летает он лучше любого из них.',tidemark100:'Бледная полоса по борту — там, где прилив так и не дотянулся.',shore100s:'Белый корпус без единой надписи. Всё, что на нём было, теперь записано где-то ещё.'});
for(const k of ['ark90','dawn90','typo100','tidemark100','shore100s'])SKINS[k].d=STORY_HULL[k];
Object.assign(HULL_NUM,{ark90:'050',dawn90:'∞',typo100:'0?3',tidemark100:'46',shore100s:'∅'});
{const ALT={dawn90:['heart42','wake'],shore100s:['shore46','record']};for(const k in ALT){const [f,v]=ALT[k],base=SKINS[k].find;Object.defineProperty(SKINS[k],'find',{get(){const c=storyFlag(f);return c&&c!==v?'ДРУГОЙ ВЫБОР':base;},configurable:true,enumerable:true});}}
function w90DrawSkin(id,t,sp,o,A,fl,edge){const hull=(fill,st,lw)=>{ctx.fillStyle=fill;ctx.strokeStyle=st;ctx.lineWidth=lw||2;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.fill();ctx.stroke();};
  if(id==='ark90'){const k=beat90(t);glow(-12,0,fl,'#d8364a',.5+.3*k);hull('#2a060c',edge,2.2);ctx.fillStyle='#ffd36b';ctx.globalAlpha=A*(.5+.5*k);ctx.beginPath();ctx.arc(2,0,3+1.5*k,0,TAU);ctx.fill();ctx.globalAlpha=A;return true;}
  if(id==='dawn90'){glow(-12,0,fl,'#ffd36b',.6);hull('#3a2a14',edge,2);ctx.fillStyle='#fff6d8';for(let i=0;i<4;i++){ctx.globalAlpha=A*(.5+.5*Math.sin(t*2+i));ctx.fillRect(-6+i*5,-1.5,2.5,3);}ctx.globalAlpha=A;return true;}
  if(id==='typo100'){glow(-12,0,fl,'#7affc9',.5);const g=Math.sin(t*19)>.9?2:0;ctx.save();ctx.translate(g,0);hull('#0e1c18',edge,2);ctx.restore();ctx.strokeStyle='#ffffff';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-4,-7);ctx.lineTo(4,4);ctx.moveTo(-8,5);ctx.lineTo(8,-2);ctx.stroke();return true;}
  if(id==='tidemark100'){glow(-12,0,fl,'#7affc9',.55);hull('#0a1412',edge,2);ctx.strokeStyle='#d8fff0';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(-9,-6);ctx.quadraticCurveTo(0,-2,12,-1);ctx.stroke();return true;}
  if(id==='shore100s'){glow(-12,0,fl,'#ffffff',.5);hull('#eef6f2',edge,1.5);return true;}
  return false;}
// --- мастерство (индекс — номер миссии минус один) ---
Object.assign(MASTERY,{38:{t:'Растворить импульсом или зарядом 4 Тромба',ok:()=>!!G.mc&&(G.mc.clot90||0)>=4},39:{t:'Ни разу не поднять Тревогу выше 60',ok:()=>!!G.mc&&!G.mc.alarm60},40:{t:'Порвать рывком 3 нейронные связи',ok:()=>!!G.mc&&(G.mc.cut90||0)>=3},
  41:{t:'Не потерять ни одного Пассажира, 8 ударов в такт, первый запуск — без сбоя',ok:()=>!!G.mc&&!!G.mc.heart90&&!G.mc.passKill90&&(G.mc.perf90||0)>=8&&!!G.mc.p4clean90},
  42:{t:'Ни разу не залететь в стёртое',ok:()=>!!G.mc&&!G.mc.void100},43:{t:'Прервать 3 ремонта Корректора',ok:()=>!!G.mc&&(G.mc.fixCut100||0)>=3},44:{t:'Пережить Прилив и ни разу не попасть под него',ok:()=>!!G.mc&&!G.mc.tide100&&(G.mc.tideN100||0)>=1},
  45:{t:'Ни разу не коснуться горизонта',ok:()=>!!G.mc&&!!G.mc.shore100&&!G.mc.hz100}});
// --- справочник: лор боссов и имя Безымянного открываются после победы ---
Object.defineProperty(EDEF.heart90,'lore',{get(){return BEAT90x(42)?'Сердце Ковчега качает кровь для пассажиров, которые не просыпались с первого цикла. Оно не знает, куда летит корабль. Оно знает, что останавливаться нельзя.':'ИСТОЧНИК НЕ ОПОЗНАН';},configurable:true,enumerable:true});
Object.defineProperty(EDEF.shore100,'lore',{get(){return BEAT90x(46)?'Край стёртого. Здесь кончается всё, что кто-то помнил, — и начинается то, чего никто не записал.':'ИСТОЧНИК НЕ ОПОЗНАН';},configurable:true,enumerable:true});
Object.defineProperty(EDEF.noname100,'name',{get(){return BEAT90x(46)?'Безымянный':'???';},configurable:true,enumerable:true});
Object.defineProperty(EDEF.noname100,'lore',{get(){return BEAT90x(46)?'Его имя стёрли первым. Он смотрит на тех, кто смотрит на него, — проверяет, не узнают ли.':'ИМЯ СТЁРТО';},configurable:true,enumerable:true});
function BEAT90x(m){const S=G.save;return !!(S&&S.medals&&S.medals[m]&&S.medals[m].clear)||!!storyFlag(m===42?'heart42':'shore46');}
// --- обломки боссов в мире ---
Object.assign(SB_WRECK,{42:{stop:['СЕРДЦЕ КОВЧЕГА','Сердце остановлено. В камере тихо и тепло. На стенке — метки ритма: пятьдесят, пятьдесят, пятьдесят…'],pulse:['СЕРДЦЕ КОВЧЕГА','Сердце бьётся ровно. Ковчег летит дальше. Куда — не знает никто, но теперь есть кому спросить.'],wake:['СЕРДЦЕ КОВЧЕГА','Камера пуста. Капсулы открыты. На полу — следы босых ног, ведущие к иллюминаторам.']},
  46:{forget:['ЛИНИЯ БЕРЕГА','Песок ровный, как чистый лист. Ничего не написано.'],carry:['ЛИНИЯ БЕРЕГА','На песке — двенадцать ямок от камней. Часть пуста. Остальное — у вас.'],record:['ЛИНИЯ БЕРЕГА','Каждое имя выцарапано на маяке. Прилив его больше не трогает.']}});
SB_WM85.push(42,46);
// --- контракты ---
CTPL.push({id:'c_quiet90',s:'IX · Тихий обход',t:n=>`Убить ${n} Смотрителей ударом в спину, пока они не подняли тревогу`,ev:'quiet90',n:[4,6],after:40,sec:8},
  {id:'c_drain90',s:'IX · Дренаж',t:n=>`Растворить ${n} Тромбов и луж импульсом или зарядом`,ev:'drain90',n:[5,7],after:39,sec:8},
  {id:'c_wake90',s:'IX · Доброе утро',t:n=>`Разбудить ${n} пассажиров в капсулах`,ev:'wake90',n:[2,3],after:39,sec:8},
  {id:'c_escort100',s:'X · Сопровождение',t:n=>`Довести ${n} Свидетелей до края арены`,ev:'escort100',n:[2,2],after:43,sec:9},
  {id:'c_tide100',s:'X · Перед приливом',t:n=>`Пережить ${n} Приливов без урона`,ev:'tide100',n:[2,3],after:45,sec:9},
  {id:'c_look100',s:'X · Взгляд в сторону',t:()=>'Уничтожить Безымянного, не дав взгляду окрепнуть',ev:'look100',n:[1,1],after:45,sec:9});
// --- модули сюжета ---
function mod90(k){const h=storyFlag('heart42'),s=storyFlag('shore46');if(k==='hush')return h==='stop'||h==='wake';if(k==='pulse')return h==='pulse'||h==='wake';if(k==='erase')return s==='forget';if(k==='mem')return s==='carry';return false;}
function memK90(){if(!mod90('mem'))return 1;return 1+.01*fragN100(sh100().frag);}
function mod90Tick(dt){const p=G.player;if(!p)return;if(G.cloak90>0)G.cloak90-=dt;
  if(G.dashId!==G.dash90){G.dash90=G.dashId;if(mod90('hush')&&p.dashT>0){G.cloak90=1.5;G.cloakP90={x:p.x,y:p.y,hp:1,isDecoy:true};if(!G.hushH90){G.hushH90=1;floater(p.x,p.y-40,'ТИШИНА СЕРДЦА · ВАС НЕ ВИДЯТ',C90.warm);}}}}
function mod90Pulse(p){if(mod90('erase')){G.cloak90=1.2;G.cloakP90={x:p.x,y:p.y,hp:1,isDecoy:true};if(!G.eraseH90){G.eraseH90=1;floater(p.x,p.y-40,'СТЁРКА · ВАС НЕ ВИДЯТ',C90.sh);}}}
function cloak90(e){if(!(G.cloak90>0)||!G.cloakP90)return null;if(e&&(e.sbk||EDEF[e.type].sbp))return null;return G.cloakP90;}
{const f0=fire;fire=function(p,tg,ang){const n0=G.pb.length;const own=p===G.player;if(own)G.lastFire90=G.t;const r=f0(p,tg,ang);
  if(own){const bt=typeof heartPerfBeat95==='function'?heartPerfBeat95():0;if(bt)for(let i=n0;i<G.pb.length;i++)G.pb[i].bt95=bt;}
  if(own&&mod90('pulse')){G.shot90=(G.shot90||0)+1;if(G.shot90%4===0)for(let i=n0;i<G.pb.length;i++){G.pb[i].dmg*=1.5;G.pb[i].pk90=1;}}return r;};}
// --- хроника ---
function chron90(s){if(!s)return '';let h='';const A=s.ark;
  if(A&&A.pods){let w=0,sl=0,l=0;for(const k in A.pods){const v=A.pods[k];if(v==='w')w++;else if(v==='s')sl++;else if(v==='l')l++;}if(w+sl+l)h+=`<dt>Пассажиры Ковчега</dt><dd>Разбужено: ${w}. Спят: ${sl}. Потеряно: ${l}.${l?' Потерянных не вернуть.':''}</dd>`;}
  if(s.heart42)h+=`<dt>Сердце Ковчега</dt><dd>${s.heart42==='stop'?'Сердце остановлено. Спящие уснули насовсем — тихо, без боли и без пробуждения.':s.heart42==='pulse'?'Сердце запущено. Ковчег летит дальше, и теперь у него есть ритм.':'Все проснулись. Ковчег больше не спит — он смотрит наружу.'}</dd>`;
  const S=s.shore;if(S&&(S.frag||S.lostFrag)){const n=fragN100(S.frag||0),lo=fragN100(S.lostFrag||0);h+=`<dt>Обрывки памяти</dt><dd>Собрано ${n} из 12${lo?', потеряно навсегда: '+lo:''}.</dd>`;for(let i=0;i<12;i++)if(S.frag&(1<<i))h+=`<dt>Обрывок ${i+1}</dt><dd>${FRAG100[i]}</dd>`;}
  if(s.shore46)h+=`<dt>Стёртый берег</dt><dd>${s.shore46==='forget'?'Вы всё забыли и летите налегке.':s.shore46==='carry'?'Вы несёте то, что осталось. Это тяжело — так и должно быть.':'Берег записан целиком. За краем стёртого — Нулевая точка.'}</dd>`;
  if(s.typo100)h+=`<dt>Опечатки</dt><dd>Исправлено опечаток: ${s.typo100}.</dd>`;return h;}
// --- открытый мир IX–X ---
const W90={gen:false,pods:[],frags:[],zero:null,sec:-1,netO:{nets:[]}};
function w90Gen(){if(W90.gen||!WORLD.sectors[9]||!G.save||!W80.gen)return;W90.gen=true;const N=WORLD.nodes,ex=[...WORLD.shops,WORLD.hangar,WORLD.arsenal].filter(Boolean);
  const okAt=(x,y,dn,dp)=>w58Far(x,y,N,dn)&&w58Far(x,y,W80.zones,dp)&&w58Far(x,y,W90.pods,dp)&&w58Far(x,y,W90.frags,dp)&&w58Far(x,y,ex,800)&&inSectors(x,y)&&WORLD.sectors.every(sc=>!sc.bx||Math.hypot(x-sc.bx,y-sc.by)>900);
  const GZ=[[8,'ИММУНИТЕТ',['keeper90','phago90','clot90'],['hunter',['armor']],39],[8,'НЕРВНЫЙ УЗЕЛ',['neuron90','clot90','gunner'],['shade',['fast']],40],[9,'ОТМЕЛЬ',['eraser100','hollow100','gunner'],['hunter',['armor']],43],[9,'ЧЕРНОВИК',['typo100','fixer100','phantom'],['shade',['boom']],44]];
  GZ.forEach(([sec,name,set,lead,after],i)=>{const q=pt80(sec,9100+i*43,(x,y,k)=>okAt(x,y,1100*k,1100*k),500);const z={x:q.x,y:q.y,req:0,set,w58:1,sec,after,name,lead,reinf:{},idx:1300+i,z80g:1};W80.zones.push(z);WORLD.zones.push(z);W58.zones.push(z);});
  ['wA','wB','wC'].forEach((id,i)=>{const q=pt80(8,9200+i*17,(x,y,k)=>okAt(x,y,800*k,1300*k),400);W90.pods.push({id,x:q.x,y:q.y,ch:0});});
  for(let i=0;i<6;i++){const q=pt80(9,9300+i*19,(x,y,k)=>okAt(x,y,700*k,1000*k),350);W90.frags.push({bit:6+i,x:q.x,y:q.y});}
  {const s=WORLD.sectors[10];if(s&&s.box){const b=s.box;W90.zero={x:(b[0]+b[2])/2,y:b[3]};}}}
function w90WorldTick(dt){const S=G.save,p=G.player;if(!S||!p)return;w90Gen();if(!W90.gen)return;mod90Tick(dt);const sec=sectorIdx(p.x,p.y);
  // ночлег пассажиров в мире
  for(const q of W90.pods){const st=ark90().pods[q.id];if(st==='w'||st==='l')continue;const d=Math.hypot(p.x-q.x,p.y-q.y);if(d<60&&p.hp>0){q.ch+=dt;if(q.ch>=(storyFlag('well38')==='silence'?2:1.5)){q.ch=0;podSet90(q.id,'w');S.lom+=60;floater(q.x,q.y-40,'ПРОСНУЛСЯ · +60 ЛОМА',C90.pil);sfx('cell');snd90('wake');conEvent('wake90');saveWorld();}}else q.ch=Math.max(0,q.ch-dt*1.5);}
  // обрывки
  const sh=sh100();for(const f of W90.frags){if(sh.frag&(1<<f.bit))continue;if(Math.hypot(p.x-f.x,p.y-f.y)<50&&p.hp>0){sh.frag|=1<<f.bit;const n=fragN100(sh.frag);floater(f.x,f.y-30,'ОБРЫВОК ПАМЯТИ · '+n+'/12','#ffffff');snd90('fragGet');radioLine('ОБРЫВОК',C90.sh,FRAG100[f.bit],.2);saveWorld();}}
  // сеть нейронов и пятна Ластиков в открытом мире
  if(G.wn90&&G.wn90.length){W90.netO.nets=G.wn90;netTick90(W90.netO,dt);G.wn90=W90.netO.nets;}
  if(G.wez100&&G.wez100.length){for(const z of G.wez100){if(z.tele>0)z.tele-=dt;else z.t-=dt;}G.wez100=G.wez100.filter(z=>z.tele>0||z.t>0);let inZ=false;for(const z of G.wez100)if(z.tele<=0&&Math.hypot(p.x-z.x,p.y-z.y)<z.r)inZ=true;
    if(inZ&&p.dashT<=0)drain90(6*dt);}
  // пассажиры летят с вами (после «Разбудить всех»)
  if(sec===8&&W90.sec!==8&&storyFlag('heart42')==='wake'&&!G.ally90w&&p.hp>0){G.ally90w={kind:'pass',x:p.x-60,y:p.y+40,a:0,cd:1,t:90};radioLine('ПАССАЖИР',C90.pil,'Мы проснулись. Теперь наша очередь вас прикрывать.',.6);floater(p.x,p.y-50,'ПАССАЖИР · СОЮЗНИК НА 90 С',C90.pil);}
  W90.sec=sec;if(G.ally90w){if(sec!==8||p.hp<=0)G.ally90w=null;else ally85Tick(dt,G.ally90w);if(G.ally90w&&G.ally90w.t<=0)G.ally90w=null;}
  w95WorldTick(dt);}
function w90Draw(t){if(!W90.gen)return;const p=G.player;const A=ark90();
  for(const q of W90.pods){if(!inView(q.x,q.y,80))continue;const st=A.pods[q.id];podDraw90({x:q.x,y:q.y,st:st==='w'?'open':st==='l'?'lost':'sleep',ch:q.ch,kch:0},t);}
  const sh=sh100();for(const f of W90.frags){if(sh.frag&(1<<f.bit)||!inView(f.x,f.y,80))continue;glow(f.x,f.y,40,C90.sh,.35+.15*Math.sin(t*3+f.bit));ctx.save();ctx.translate(f.x,f.y);ctx.rotate(t*.8+f.bit);ctx.strokeStyle='#ffffff';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,-9);ctx.lineTo(6,0);ctx.lineTo(0,9);ctx.lineTo(-6,0);ctx.closePath();ctx.stroke();ctx.restore();if(p&&Math.hypot(p.x-f.x,p.y-f.y)<300)worldLabel(f.x,f.y-24,'ОБРЫВОК','#ffffff');}
  gate110Draw(t);
  w95Draw(t);
  const Al=G.ally90w;if(Al){ctx.save();ctx.translate(Al.x,Al.y);ctx.rotate(Al.ang||0);ctx.fillStyle='#141a28';ctx.strokeStyle=C90.pil;ctx.lineWidth=2;shipPath85(.8);ctx.fill();ctx.stroke();ctx.restore();worldLabel(Al.x,Al.y-20,'ПАССАЖИР · '+Math.ceil(Al.t),C90.pil);}}
function w90MapAdd(add,lod,S){w90Gen();if(!W90.gen)return;const A=ark90();for(const q of W90.pods){if(!revealedAt(q.x,q.y))continue;const st=A.pods[q.id];add('pod90',q.x,q.y,{st},lod===2?{t:st==='w'?'КАПСУЛА · ПУСТА':'КАПСУЛА',p:5,c:st==='w'?'#9fb0c4':C90.ark}:null);}
  const sh=sh100();for(const f of W90.frags){if(sh.frag&(1<<f.bit)||!revealedAt(f.x,f.y))continue;add('frag100',f.x,f.y,{},lod===2?{t:'ОБРЫВОК',p:5,c:'#ffffff'}:null);}
  if(W90.zero&&revealedAt(W90.zero.x,W90.zero.y))add('zero100',W90.zero.x,W90.zero.y,{},lod===2?{t:zeroOpen110()?'ВОРОТА ОТКРЫТЫ · НУЛЕВОЙ МИГ':'ВОРОТА · ПРОЙДИТЕ «МИГ»',p:6,c:'#ff9fe0'}:null);
  if(W95.gen){const N95={gclot:'ТРОМБОЗ',typoW:'ОПЕЧАТКА В МИРЕ',sig:'ПОСЛЕДНИЙ СИГНАЛ'},D=w95S();for(const k in W95.sites){const q=W95.sites[k];if(D[k]===(S&&S.cycle||1)||!revealedAt(q.x,q.y))continue;add('ev95',q.x,q.y,{},lod===2?{t:N95[k],p:5,c:'#ffffff'}:null);}}}
function w90MapIcon(g,kind,o,t){if(kind==='pod90'){g.strokeStyle=o.st==='w'?'#9fb0c4':'#ffd36b';g.strokeRect(-3,-5,6,10);return true;}if(kind==='frag100'){g.strokeStyle='#ffffff';g.beginPath();g.moveTo(0,-5);g.lineTo(4,0);g.lineTo(0,5);g.lineTo(-4,0);g.closePath();g.stroke();return true;}
  if(kind==='ev95'){g.strokeStyle='#ffffff';g.beginPath();g.arc(0,0,5,0,TAU);g.stroke();g.beginPath();g.arc(0,0,1.5,0,TAU);g.stroke();return true;}
  if(kind==='zero100'){g.strokeStyle='#ff9fe0';g.beginPath();g.arc(0,0,6,0,TAU);g.stroke();g.beginPath();g.moveTo(-3,-3);g.lineTo(3,3);g.moveTo(3,-3);g.lineTo(-3,3);g.stroke();return true;}return false;}
// --- сохранение: чистка полей 0.9 ---
function sanitize90(S,num,obj){if(!S)return;if(S.story){const st=S.story;
    if(st.heart42!==undefined&&!['stop','pulse','wake'].includes(st.heart42))delete st.heart42;if(st.shore46!==undefined&&!['forget','carry','record'].includes(st.shore46))delete st.shore46;
    if(st.ark!==undefined){const a=st.ark=obj(st.ark);const P=a.pods=obj(a.pods);for(const k of Object.keys(P))if(!/^(m(39|40|41)[abtk]|w[ABC])$/.test(k)||!['w','s','l'].includes(P[k]))delete P[k];for(const k of ['woke','slept','lost'])a[k]=num(a[k],0,0,99,true);}
    if(st.shore!==undefined){const h=st.shore=obj(st.shore);h.frag=num(h.frag,0,0,4095,true);h.lostFrag=num(h.lostFrag,0,0,4095,true)&~h.frag;}
    if(st.typo100!==undefined)st.typo100=num(st.typo100,0,0,1e6,true);
    if(st.sec95!==undefined)st.sec95=num(st.sec95,0,0,255,true);
    if(st.zero49!==undefined)st.zero49=num(st.zero49,0,0,1,true);if(st.zero50!==undefined)st.zero50=num(st.zero50,0,0,9,true);
    if(st.w95!==undefined){const w=st.w95=obj(st.w95);for(const k of Object.keys(w))if(!['gclot','typoW','sig'].includes(k))delete w[k];else w[k]=num(w[k],0,0,999,true);}}
  if(S.seen90!==undefined){S.seen90=Array.isArray(S.seen90)?S.seen90.filter(k=>typeof k==='string'&&D90T.has(k)).slice(0,40):[];}}
function bossLab90(m){if(m===50)return 'VØID-000';const si=secOfLevel(m);return SEC_SCALE[si]&&SB_OF_SEC[si]&&SB_NAME_OF_SEC[si]?'БОСС · '+SB_NAME_OF_SEC[si]:'БОСС · ДОРАБОТКА';}


// ===== 0.9.5: язык угроз, комфорт, общие системы секторов IX–X =====
['hunt95','spasm95','cell95','guard95','blot95','scribe95','ebb95','lost95','gclot95'].forEach(k=>{S90T.add(k);H74.add(k);STORY_NORETREAT.add(k);D90T.add(k);});
['eye95','shade95'].forEach(k=>{D90T.add(k);SB85T.add(k);});
function on95(){const X=G.x90;return !!X&&inMission()&&X.sec>=8&&X.sec<=11&&G.mode!=='endless';}
function x95(){return G.x90;}
// --- телеграфы: «предупреждение → заряд → удар → остаток». Минимум 0,45 с, для ударов от 20 урона — 0,7 с ---
function tmin95(dmg){return dmg>=20?.7:.45;}
function tlog95(k,T){const X=G.x90;if(!X)return;const L=X.tlog95||(X.tlog95={});if(L[k]===undefined||T<L[k])L[k]=T;}
// o: {k:'line'|'zone'|'cone'|'drop'|'col', x,y, x2,y2, w, r, a, arc, len, T, dmg, col, src, key, snd, keep, on(o), fx}
function tg95(o){const X=G.x90;const L=X&&inMission()?(X.tg95||(X.tg95=[])):(G.wtg95||(G.wtg95=[]));
  o.T=Math.max(o.T||0,tmin95(o.dmg||0))*(o.key&&o.telK!==false?tel90(o.key):1);o.t=0;o.st='warn';o.rest=0;o.col=o.col||C95.zone;if(o.key){tlog95(o.key,o.T);tel90use(o.key);}
  if(o.snd!==false)snd95(o.snd||(o.k==='line'?'tlLine':o.k==='zone'||o.k==='drop'?'tlZone':o.k==='cone'?'tlCone':'tlLine'),o.x);
  L.push(o);if(L.length>48)L.shift();return o;}
function tgList95(){const X=G.x90;return X&&inMission()?(X.tg95||[]):(G.wtg95||[]);}
function tgHit95(o,x,y,pad){pad=pad||0;switch(o.k){
    case 'line':return segDist(o.x,o.y,o.x2,o.y2,x,y)<o.w/2+pad;
    case 'zone':case 'drop':return Math.hypot(x-o.x,y-o.y)<o.r+pad;
    case 'cone':{const d=Math.hypot(x-o.x,y-o.y);if(d>o.len+pad||d<4)return d<4;return Math.abs(angDiff(Math.atan2(y-o.y,x-o.x),o.a))<o.arc/2;}
    case 'col':return Math.abs(x-o.x)<o.w/2+pad&&y>o.y&&y<o.y2;
    case 'arc':{const d=Math.hypot(x-o.x,y-o.y);if(Math.abs(d-o.r)>o.w/2+pad)return false;return Math.abs(angDiff(Math.atan2(y-o.y,x-o.x),o.a))<o.arc/2;}}
  return false;}
function tgTick95(dt){const L=tgList95();if(!L.length)return;const p=G.player;
  for(const o of L){if(o.src&&!o.src.alive&&!o.keep&&o.st==='warn'){o.dead=1;continue;}
    if(o.track&&o.st==='warn')o.track(o,dt);
    o.t+=dt;if(o.st==='warn'&&o.t>=o.T){o.st='hit';o.rest=.3;
      if(o.on)o.on(o);
      if(!o.noHit&&p&&p.hp>0&&p.dashT<=0&&tgHit95(o,p.x,p.y,p.r*.55)){damagePlayer((o.dmg||10)*(o.src?first90(o.src):1));if(o.kb){const a=Math.atan2(p.y-o.y,p.x-o.x);p.x+=Math.cos(a)*o.kb;p.y+=Math.sin(a)*o.kb;if(inMission()){p.x=clamp(p.x,p.r,BW-p.r);p.y=clamp(p.y,p.r,BH-p.r);}}if(o.slow)G.slowP95=Math.max(G.slowP95||0,o.slow);}
      if(o.hitE)for(const e of G.enemies){if(!e.alive||e===o.src||STATIC.has(e.type)||EDEF[e.type].passive||e.sbk||EDEF[e.type].sbp)continue;if(tgHit95(o,e.x,e.y,e.r*.5))hurt(e,o.hitE,{pulse:true});}
      if(o.fx!==false)tgFx95(o);}
    else if(o.st==='hit'){o.rest-=dt;if(o.rest<=0)o.dead=1;}}
  for(let i=L.length-1;i>=0;i--)if(L[i].dead)L.splice(i,1);}
function tgFx95(o){const c=o.col;trauma90(o.dmg>=18?.18:.08);
  if(!SET.fx)return;const n=fxN95(o.k==='line'?10:8);
  if(o.k==='line'){for(let i=0;i<n;i++){const u=vR3();part(o.x+(o.x2-o.x)*u,o.y+(o.y2-o.y)*u,vrnd3(-60,60),vrnd3(-60,60),vrnd3(.2,.45),i%3?c:'#ffffff',2);}}
  else if(o.k==='zone'||o.k==='drop'){if(G.shock.length<60)G.shock.push({x:o.x,y:o.y,r:o.r*.4,R:o.r,t:0,col:c,thin:true});for(let i=0;i<n;i++){const a=vrnd3(0,TAU);part(o.x+Math.cos(a)*o.r*.5,o.y+Math.sin(a)*o.r*.5,Math.cos(a)*vrnd3(40,140),Math.sin(a)*vrnd3(40,140),vrnd3(.25,.5),c,2);}}
  else if(o.k==='cone'){for(let i=0;i<n;i++){const a=o.a+vrnd3(-o.arc/2,o.arc/2),d=vrnd3(20,o.len);part(o.x+Math.cos(a)*d,o.y+Math.sin(a)*d,Math.cos(a)*80,Math.sin(a)*80,.3,c,2);}}}
// рисунок телеграфа: k — 0..1 (предупреждение → заряд)
function tgDraw95(t){const L=tgList95();if(!L.length)return;const hard=rk90()>=2;
  for(const o of L){if(G.world&&!inView(o.x,o.y,(o.len||o.r||300)+60))continue;const k=clamp(o.t/o.T,0,1),c=o.col;
    if(o.st==='hit'){const a=clamp(o.rest/.3,0,1);ctx.globalAlpha=a*.6;ctx.fillStyle=c;ctx.strokeStyle='#ffffff';
      if(o.k==='line'){ctx.lineCap='round';ctx.strokeStyle=c;ctx.lineWidth=o.w*a;ctx.beginPath();ctx.moveTo(o.x,o.y);ctx.lineTo(o.x2,o.y2);ctx.stroke();ctx.lineCap='butt';}
      else if(o.k==='zone'||o.k==='drop'){ctx.beginPath();ctx.arc(o.x,o.y,o.r,0,TAU);ctx.fill();}
      else if(o.k==='cone'){ctx.beginPath();ctx.moveTo(o.x,o.y);ctx.arc(o.x,o.y,o.len,o.a-o.arc/2,o.a+o.arc/2);ctx.closePath();ctx.fill();}
      else if(o.k==='col'){ctx.fillRect(o.x-o.w/2,o.y,o.w,o.y2-o.y);}
      else if(o.k==='arc'){ctx.strokeStyle=c;ctx.lineWidth=o.w*a;ctx.beginPath();ctx.arc(o.x,o.y,o.r,o.a-o.arc/2,o.a+o.arc/2);ctx.stroke();ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.stroke();}
      ctx.globalAlpha=1;continue;}
    const charge=k>.6,blink=charge&&Math.sin(t*40)>0,A=(hard?.75:1);
    if(o.k==='line'){const w=2+(o.w-2)*Math.pow(k,1.6);ctx.lineCap='round';
      if(!charge){ctx.setLineDash([10,8]);ctx.lineDashOffset=-t*60;ctx.strokeStyle=rgba90('#ffffff',(.25+.35*k)*A);ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(o.x,o.y);ctx.lineTo(o.x2,o.y2);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;}
      ctx.strokeStyle=rgba90('#ffffff',(.35+.5*k)*A);ctx.lineWidth=w+3;ctx.beginPath();ctx.moveTo(o.x,o.y);ctx.lineTo(o.x2,o.y2);ctx.globalAlpha=charge?.9:.4;ctx.stroke();
      ctx.strokeStyle=c;ctx.lineWidth=w;ctx.globalAlpha=(.25+.6*k)*A;ctx.stroke();ctx.globalAlpha=1;ctx.lineCap='butt';}
    else if(o.k==='zone'||o.k==='drop'){ctx.strokeStyle=rgba90(c,(.35+.5*k)*A);ctx.lineWidth=blink?2.5:1.5;ctx.setLineDash(k<.6?[6,6]:[]);ctx.beginPath();ctx.arc(o.x,o.y,o.r,0,TAU);ctx.stroke();ctx.setLineDash([]);
      ctx.fillStyle=rgba90(c,(o.k==='drop'?.18:.22)*A);ctx.beginPath();ctx.arc(o.x,o.y,o.r*k,0,TAU);ctx.fill();
      if(o.k==='drop'){const h=(1-k)*160;ctx.fillStyle=rgba90(c,.75*A);ctx.beginPath();ctx.ellipse(o.x,o.y-h,4,7+6*k,0,0,TAU);ctx.fill();}}
    else if(o.k==='cone'){ctx.fillStyle=rgba90(c,(.08+.22*k)*A);ctx.beginPath();ctx.moveTo(o.x,o.y);ctx.arc(o.x,o.y,o.len*(.3+.7*k),o.a-o.arc/2,o.a+o.arc/2);ctx.closePath();ctx.fill();
      ctx.strokeStyle=rgba90(blink?'#ffffff':c,(.4+.5*k)*A);ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(o.x,o.y);ctx.arc(o.x,o.y,o.len,o.a-o.arc/2,o.a+o.arc/2);ctx.closePath();ctx.stroke();}
    else if(o.k==='col'){ctx.fillStyle=rgba90(c,(.06+.22*k)*A);ctx.fillRect(o.x-o.w/2*k,o.y,o.w*k,o.y2-o.y);ctx.strokeStyle=rgba90(c,(.35+.5*k)*A);ctx.setLineDash([6,6]);ctx.strokeRect(o.x-o.w/2,o.y,o.w,o.y2-o.y);ctx.setLineDash([]);}
    else if(o.k==='arc'){ctx.strokeStyle=rgba90(c,(.12+.3*k)*A);ctx.lineWidth=o.w;ctx.beginPath();ctx.arc(o.x,o.y,o.r,o.a-o.arc/2,o.a+o.arc/2);ctx.stroke();
      ctx.strokeStyle=rgba90(blink?'#ffffff':c,(.45+.5*k)*A);ctx.lineWidth=2;ctx.beginPath();ctx.arc(o.x,o.y,o.r-o.w/2,o.a-o.arc/2,o.a+o.arc/2);ctx.stroke();ctx.beginPath();ctx.arc(o.x,o.y,o.r+o.w/2,o.a-o.arc/2,o.a+o.arc/2);ctx.stroke();
      const e0=o.a-o.arc/2+o.arc*k;ctx.fillStyle='#ffffff';ctx.globalAlpha=.8;ctx.beginPath();ctx.arc(o.x+Math.cos(e0)*o.r,o.y+Math.sin(e0)*o.r,4,0,TAU);ctx.fill();ctx.globalAlpha=1;}}}
// --- волны (кольца) с проходами: клапаны, ганглий, тени боссов ---
function wvList95(){const X=G.x90;return X&&inMission()?(X.wv95||(X.wv95=[])):(G.wwv95||(G.wwv95=[]));}
function wv95(o){const L=wvList95();Object.assign(o,{r:o.r||8,hit:false});L.push(o);if(L.length>24)L.shift();return o;}
function wvTick95(dt){const L=wvList95();if(!L.length)return;const p=G.player;
  for(const w of L){const r0=w.r;w.r+=w.v*dt;if(w.hit||!p||p.hp<=0)continue;const d=Math.hypot(p.x-w.x,p.y-w.y);if(d+p.r*.55<r0-(w.w||10)/2||d-p.r*.55>w.r+(w.w||10)/2)continue;
    if(w.gaps){const a=Math.atan2(p.y-w.y,p.x-w.x);if(w.gaps.some(g=>Math.abs(angDiff(a,g.a))<g.w/2))continue;}if(p.dashT>0)continue;w.hit=true;damagePlayer(w.dmg||10);}
  for(let i=L.length-1;i>=0;i--)if(L[i].r>=(L[i].R||Math.hypot(W,H)))L.splice(i,1);}
function wvDraw95(t){for(const w of wvList95()){const a=clamp(1-w.r/(w.R||900),.15,1);
    // кольцо и его светлая кромка рисуются только по сплошным дугам — проходы остаются честно пустыми
    const P=new Path2D();if(w.gaps&&w.gaps.length){const G2=w.gaps.slice().sort((a_,c)=>a_.a-c.a);for(let i=0;i<G2.length;i++){const a0=G2[i].a+G2[i].w/2,n=G2[(i+1)%G2.length],a1=n.a-n.w/2+(i===G2.length-1?TAU:0);P.moveTo(w.x+Math.cos(a0)*w.r,w.y+Math.sin(a0)*w.r);P.arc(w.x,w.y,w.r,a0,a1>a0?a1:a1+TAU);}}
    else P.arc(w.x,w.y,w.r,0,TAU);
    ctx.strokeStyle=rgba90(w.col||C90.ark,.6*a);ctx.lineWidth=w.w||10;ctx.stroke(P);ctx.lineWidth=1.5;ctx.strokeStyle=rgba90('#ffffff',.5*a);ctx.stroke(P);}}
// стрелки проходов за такт до волны
function gapArrows95(x,y,R,gaps,k,col){for(const g of gaps){const ux=Math.cos(g.a),uy=Math.sin(g.a);ctx.save();ctx.translate(x+ux*R,y+uy*R);ctx.rotate(g.a);ctx.globalAlpha=.4+.5*k;ctx.fillStyle=col||'#ffffff';
    ctx.beginPath();ctx.moveTo(14,0);ctx.lineTo(-4,-9);ctx.lineTo(0,0);ctx.lineTo(-4,9);ctx.closePath();ctx.fill();ctx.restore();}ctx.globalAlpha=1;}
// --- уязвимое окно ✦ и неуязвимый момент ⬡ ---
function weak95(e,dur,k){if(!e||!e.alive)return;const was=e.weak95>0;e.weak95=Math.max(e.weak95||0,dur);e.weakK95=k||1.5;if(!was){snd95('weak',e.x);}}
function weakK95(e){return e.weak95>0?(e.weakK95||1.5):1;}
function markDraw95(e,t){if(e.weak95>0){const y=-e.r-16-3*Math.sin(t*6),a=Math.min(1,e.weak95*3);ctx.save();ctx.globalAlpha=a;ctx.translate(0,y);ctx.rotate(Math.PI/4);ctx.fillStyle='#ffffff';ctx.fillRect(-4.5,-4.5,9,9);ctx.strokeStyle='#04060c';ctx.lineWidth=1.5;ctx.strokeRect(-4.5,-4.5,9,9);ctx.restore();
    ctx.globalAlpha=a*.5;ctx.strokeStyle='#ffffff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(0,0,e.r+5+2*Math.sin(t*10),0,TAU);ctx.stroke();ctx.globalAlpha=1;}
  if(e.inv95>0){ctx.strokeStyle=C95.shield;ctx.globalAlpha=.75;ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<=6;i++){const a=i/6*TAU+Math.PI/6;const x=Math.cos(a)*(e.r+7),y=Math.sin(a)*(e.r+7);if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);}ctx.stroke();ctx.globalAlpha=1;}}
// --- метки «ЦЕЛЬ» (Смотритель) и «ВИДЕН» (маяк): враги рядом стреляют на 15% чаще ---
function mark95(kind,T){const m=G.mark95;if(m&&m.t>0&&m.kind===kind){m.t=Math.max(m.t,T);return;}G.mark95={kind,t:T,t0:T};snd95('mark');}
function markTick95(dt){const m=G.mark95;if(!m)return;m.t-=dt;if(m.t<=0){G.mark95=null;return;}const p=G.player;if(!p)return;
  for(const e of G.enemies){if(!e.alive||e.spawnT>0||STATIC.has(e.type)||EDEF[e.type].passive||e.sbk||EDEF[e.type].sbp)continue;if(Math.hypot(e.x-p.x,e.y-p.y)<450&&e.cd>0)e.cd-=dt*.15;}}
function markPlayerDraw95(t){const m=G.mark95,p=G.player;if(!m||!p||p.hp<=0)return;const a=Math.min(1,m.t*2),c=m.kind==='ВИДЕН'?C90.sh:'#ffe9b0',r=26+2*Math.sin(t*8);ctx.strokeStyle=c;ctx.globalAlpha=.7*a;ctx.lineWidth=1.5;
  for(let i=0;i<4;i++){const q=t*1.5+i*Math.PI/2;ctx.beginPath();ctx.arc(p.x,p.y,r,q,q+.6);ctx.stroke();}ctx.globalAlpha=a;const age=(m.t0||0)-m.t;if(age<.35){const z=1+.7*(1-age/.35);ctx.save();ctx.translate(p.x,p.y-r-8);ctx.scale(z,z);worldLabel(0,0,m.kind,c);ctx.restore();}else worldLabel(p.x,p.y-r-8,m.kind,c);ctx.globalAlpha=1;}
// --- стоп-кадр по тирам: обычный 30 мс, элита 50, слабая точка босса 70, смена фазы 250 ---
function hsKill95(e){if(!on95())return;if(e.affix||e.elite95)hs90(.05,0);else hs90(.03,0);}
function hsWeak95(){hs90(.07,0);}
// --- замедление времени (последний шанс, табличка первой встречи, смерть элиты) ---
function slow95(T,k){const s=G.slow95;if(s&&s.t>0&&s.k<=k){s.t=Math.max(s.t,T);return;}G.slow95={t:T,k};}
// --- очередь плавающих надписей: не больше двух сразу, одинаковые склеиваются «×3», справка — не чаще раза в 4 с ---
function fqOn95(){return on95()&&(G.state==='play'||G.state==='levelup');}
function fqPrio95(text,col){const s=String(text);if(/[!−]|ТРЕВОГ|ПРИЛИВ|ЛОПНЕТ|ЗАМЕЧЕН|ЦЕЛЬ|ВИДЕН|ВЗОРВ|БРОСОК|ЗАЖАЛО|ПОД ОГН|ПОГИБ|ПОТЕРЯН/.test(s)||col===C90.red||col==='#ff4f6e')return 2;if(/\+|ОБРЫВОК|ЛОМА|ТАЙНИК|ПРОСНУЛ|ДОЛЕТЕЛ|ЖЕТОН/.test(s))return 1;return 0;}
{const f0=floater;floater=function(x,y,text,col){if(!fqOn95())return f0(x,y,text,col);const Q=G.fq95||(G.fq95={q:[],last:{}}),s=String(text);
    for(const f of G.float){if(f.base95===s&&f.life>.25){f.n95=(f.n95||1)+1;f.text=s+' ×'+f.n95;f.life=Math.max(f.life,1.1);return;}}
    for(const q of Q.q)if(q.text===s){q.n=(q.n||1)+1;q.t=G.t;return;}
    const pr=fqPrio95(s,col);if(pr===0&&Q.last[s]!==undefined&&G.t-Q.last[s]<4)return;Q.last[s]=G.t;
    const act=G.float.filter(f=>f.q95&&f.life>.35).length;if(act<2||pr===2&&act<3){f0(x,y,s,col);const f=G.float[G.float.length-1];if(f&&f.text===s){f.q95=1;f.base95=s;}return;}
    Q.q.push({x,y,text:s,col,pr,t:G.t,n:1});Q.q.sort((a,b)=>b.pr-a.pr||a.t-b.t);if(Q.q.length>6)Q.q.length=6;};}
function fqTick95(){const Q=G.fq95;if(!Q||!Q.q.length)return;if(!fqOn95()){Q.q=[];return;}Q.q=Q.q.filter(q=>q.pr===2?G.t-q.t<2.5:G.t-q.t<3.2);
  const act=G.float.filter(f=>f.q95&&f.life>.35).length;if(act>=2||!Q.q.length)return;const q=Q.q.shift();const s=q.n>1?q.text+' ×'+q.n:q.text;const p=G.player;
  const n0=G.float.length;(function(){const F=G.float;if(F.length>24)F.shift();F.push({x:clamp(q.x,CX+60,CX+W-60),y:clamp(q.y,CY+30,CY+H-20),text:s,col:q.col,life:1.3,q95:1,base95:q.text});})();}
// --- последний шанс: первый смертельный удар за миссию оставляет 1 ОЗ («Лёгкая» и «Средняя») ---
function lc95(p){if(!on95()||rk90()>=2||(devAny()&&G.dev.god))return false;const X=G.x90;if(X.lc95)return false;X.lc95=1;p.hp=1;p.inv=1.4;slow95(.8,.3);trauma90(.45);hs90(.12,1);
  floater(p.x,p.y-44,'ПОСЛЕДНИЙ ШАНС','#ffffff');snd95('last');if(G.shock.length<60)G.shock.push({x:p.x,y:p.y,r:10,R:200,t:0,col:'#ffffff',slow:true});G.hurtV=1;return true;}
// контактный урон только через 0,6 с после появления
function cg95(e){return e.cg95>G.t;}
// --- частицы и эффекты: «Меньше эффектов» ---
function fxN95(n){return Math.max(1,Math.round(n*(SET.lessFx?.5:1)*(G.lowFx?.5:1)*(isMob()?.6:1)));}
// глифы — частицы-буквы сектора X
const GLYPH95='АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЭЮЯ';
function glyph95(x,y,n,col,vis){const X=G.x90;const L=X&&inMission()?(X.gl95||(X.gl95=[])):(G.wgl95||(G.wgl95=[]));const gR=vis?vR3:vR5,gRnd=vis?vrnd3:vrnd5;/* ARCH·71: vis — вызов под SET.fx (A-16), иначе A-18 */n=fxN95(n);for(let i=0;i<n;i++){if(L.length>60)L.shift();const a=gRnd(0,TAU),v=gRnd(30,120);L.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-30,life:gRnd(.6,1.2),max:1.2,ch:GLYPH95[gR()*GLYPH95.length|0],col:col||C90.sh,rot:gRnd(-1,1)});}}
function glTick95(dt){for(const L of [G.x90&&G.x90.gl95,G.wgl95]){if(!L||!L.length)continue;for(const q of L){q.x+=q.vx*dt;q.y+=q.vy*dt;q.vx*=Math.pow(.3,dt);q.vy*=Math.pow(.3,dt);q.life-=dt;}for(let i=L.length-1;i>=0;i--)if(L[i].life<=0)L.splice(i,1);}}
// кэш спрайтов букв: буквы-частицы и снаряды-слова рисуются картинкой, а не текстом каждый кадр
const GLC95=new Map();
function glyphSpr95(ch,px,col,sh){const S=DPR*SC>2.2?3:2,key=ch+'|'+px+'|'+col+'|'+(sh?1:0)+'|'+S;let c=GLC95.get(key);if(c)return c;const sz=Math.ceil((px*1.4+6)*S);c=document.createElement('canvas');c.width=c.height=sz;const g=c.getContext('2d');g.setTransform(S,0,0,S,0,0);g.font='700 '+px+'px "JetBrains Mono",monospace';g.textAlign='center';g.textBaseline='middle';const m=sz/S/2;if(sh){g.fillStyle='#04060c';g.fillText(ch,m+1,m+1);}g.fillStyle=col;g.fillText(ch,m,m);
  if(GLC95.size>500)GLC95.clear();GLC95.set(key,c);return c;}
// шрифт догрузился — перерисуем кэши букв и обломков (до этого живём с запасным шрифтом, но без пересоздания холстов каждый кадр)
if(document.fonts&&document.fonts.addEventListener)document.fonts.addEventListener('loadingdone',()=>{GLC95.clear();if(typeof PIL95C!=='undefined')PIL95C.clear();});
function glyphDraw95(ch,x,y,px,col,sh,rot){const c=glyphSpr95(ch,px,col,sh),s=c.width/(DPR*SC>2.2?3:2);if(rot){ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.drawImage(c,-s/2,-s/2,s,s);ctx.restore();}else ctx.drawImage(c,x-s/2,y-s/2,s,s);}
function glDraw95(){const L=G.world?G.wgl95:G.x90&&G.x90.gl95;if(!L||!L.length)return;
  const mob=isMob();for(const q of L){ctx.globalAlpha=clamp(q.life/q.max,0,1);glyphDraw95(q.ch,q.x,q.y,11,q.col,false,mob?0:q.rot*(1-q.life));}ctx.globalAlpha=1;}
// гибель врага в секторах IX–X: кровь или буквы; элита — кольцо света и замедление
function death95(e,silent){if(silent||!on95()&&!(G.world&&secW95()>=0))return;if(G.world&&secW95()===8&&!EDEF[e.type].passive)W95.kills.push(G.t);const d=EDEF[e.type];if(!d||d.passive||d.sbp||e.sbk)return;const sec=G.world?secW95():G.x90.sec;
  if(sec===8&&SET.fx){const n=fxN95(10);for(let i=0;i<n;i++){const a=vrnd3(0,TAU),v=vrnd3(60,220);part(e.x,e.y,Math.cos(a)*v,Math.sin(a)*v,vrnd3(.3,.7),i%3?C90.blood:C95.bloodD,vrnd3(2,3.5));}}
  if(sec===9)glyph95(e.x,e.y,6,e.mem100?'#a8b4b0':d.col);if(sec>=10)spark110(e);
  if(e.affix||e.elite95){slow95(.3,.4);if(G.shock.length<60)G.shock.push({x:e.x,y:e.y,r:e.r,R:150,t:0,col:'#ffffff',slow:true});snd95('elite');}
  hsKill95(e);}
// --- кэш спрайтов градиентов (X16): лужи, темнота, виньетки ---
const RG95={};
function rg95(col,a0,a1,mid){const key=col+'|'+a0+'|'+a1+'|'+(mid||'');if(RG95[key])return RG95[key];const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d'),gr=g.createRadialGradient(64,64,0,64,64,64);
  gr.addColorStop(0,rgba90(col,a0));if(mid)gr.addColorStop(mid[0],rgba90(col,mid[1]));gr.addColorStop(1,rgba90(col,a1));g.fillStyle=gr;g.fillRect(0,0,128,128);return RG95[key]=c;}
function rgDraw95(x,y,r,col,a0,a1,mid){ctx.drawImage(rg95(col,a0,a1,mid),x-r,y-r,r*2,r*2);}
// экранная виньетка: прозрачный центр → цвет по краю (кэш 256×256 на цвет)
const VIG95={};
function vig95(col,a,inner){const key=col+'|'+(inner||.3);let c=VIG95[key];if(!c){c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d'),gr=g.createRadialGradient(128,128,128*(inner||.3)*1.4,128,128,182);gr.addColorStop(0,rgba90(col,0));gr.addColorStop(1,rgba90(col,1));g.fillStyle=gr;g.fillRect(0,0,256,256);VIG95[key]=c;}
  // на ПК — копия в точном размере экрана: блит 1:1 без масштабирования заметно дешевле (кэш на 3 виньетки)
  const px=cv.width*cv.height;if(px<=2.3e6){const k2=key+'|'+cv.width+'x'+cv.height;let F=VIG95F.get(k2);if(!F){F=document.createElement('canvas');F.width=cv.width;F.height=cv.height;F.getContext('2d').drawImage(c,0,0,cv.width,cv.height);if(VIG95F.size>=3)VIG95F.delete(VIG95F.keys().next().value);VIG95F.set(k2,F);}c=F;}
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=clamp(a,0,1);ctx.drawImage(c,0,0,cv.width,cv.height);ctx.restore();}
const VIG95F=new Map();
// --- свои снаряды: слова, огни, иглы, тельца, чернила, символы ---
function eb95(x,y,a,spd,dmg,col,r,k,ex){const b=shootE(x,y,a,spd,dmg,col,r);if(b){b.k95=k;if(ex)Object.assign(b,ex);}return b;}
function eb95Draw(b,t){const k=b.k95;
  if(k==='word'||k==='sym'){glyphDraw95(b.ch||'·',b.x,b.y,k==='word'?15:13,b.frz95>0?'#ffffff':b.col,true,0);return;}
  if(k==='fire'){const a=Math.atan2(b.vy,b.vx);ctx.save();ctx.translate(b.x,b.y);ctx.rotate(a);ctx.fillStyle=rgba90(C95.hom,.35);ctx.beginPath();ctx.moveTo(-18,0);ctx.lineTo(0,-5);ctx.lineTo(0,5);ctx.closePath();ctx.fill();
    ctx.fillStyle=C95.hom;ctx.beginPath();ctx.arc(0,0,6,0,TAU);ctx.fill();ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(1.5,0,2.6,0,TAU);ctx.fill();ctx.fillStyle='#04060c';ctx.beginPath();ctx.arc(2.4,0,1.2,0,TAU);ctx.fill();ctx.strokeStyle='#04060c';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(0,0,6,0,TAU);ctx.stroke();ctx.restore();return;}
  if(k==='needle'){const a=Math.atan2(b.vy,b.vx);ctx.save();ctx.translate(b.x,b.y);ctx.rotate(a);ctx.fillStyle=b.col;ctx.strokeStyle='#04060c';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(9,0);ctx.lineTo(-7,-2.2);ctx.lineTo(-7,2.2);ctx.closePath();ctx.stroke();ctx.fill();ctx.restore();return;}
  if(k==='cell'){ctx.fillStyle='#04060c';ctx.beginPath();ctx.arc(b.x,b.y,b.r+1.5,0,TAU);ctx.fill();ctx.fillStyle=b.col;ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,TAU);ctx.fill();ctx.fillStyle=rgba90('#3a0a12',.8);ctx.beginPath();ctx.arc(b.x,b.y,b.r*.45,0,TAU);ctx.fill();return;}
  if(k==='ink'){ctx.fillStyle=C95.ink;ctx.strokeStyle=b.col;ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,TAU);ctx.fill();ctx.stroke();return;}
  ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(b.x,b.y,Math.max(b.r*.55,BMIN),0,TAU);ctx.fill();ctx.strokeStyle='#04060c';ctx.lineWidth=1.5/SC;ctx.stroke();}
// снаряды, которые можно сбить: огни маяков, капли — проверка пулями игрока
function shoot95(bu){if(!G.eb.length)return false;for(const b of G.eb){if(!b.shoot95||b.life<=0)continue;if(segDist(bu.px,bu.py,bu.x,bu.y,b.x,b.y)<(b.r||6)+4){b.life=0;if(SET.fx)for(let i=0;i<fxN95(6);i++){const a=vrnd3(0,TAU);part(b.x,b.y,Math.cos(a)*120,Math.sin(a)*120,.3,b.col,2);}snd95('pop',b.x);if(!bu.charged){if(bu.pierce-->0)return false;bu.life=0;return true;}return false;}}return false;}
// эффекты снарядов: замедление от игл, заморозка «правки»
function ebTick95(dt){for(const b of G.eb){if(b.frz95>0){b.frz95-=dt;if(b.frz95<=0&&b.rv95){const p=G.player,a=Math.atan2(p.y-b.y,p.x-b.x),s=Math.max(200,Math.hypot(b.vx0||b.vx,b.vy0||b.vy));b.vx=Math.cos(a)*s;b.vy=Math.sin(a)*s;b.rv95=0;}else{b.x-=b.vx*dt;b.y-=b.vy*dt;b.life+=dt;}}
    if(b.hold95>0){b.hold95-=dt;b.x-=b.vx*dt;b.y-=b.vy*dt;b.life+=dt;if(b.hold95<=0&&b.go95)b.go95(b);}}
  if(G.slowP95>0){G.slowP95-=dt;}}
// --- замедление корабля (иглы Смотрителя, лужи) ---
function slowP95(p,dt){if(G.slowP95>0&&p.dashT<=0){p.x=p.px+(p.x-p.px)*.75;p.y=p.py+(p.y-p.py)*.75;}}
// --- стрелки за краем экрана для заряжающихся врагов и телеграфов ---
function edgeArrows95(t){if(!G.arena)return;const p=G.player;if(!p)return;const items=[];
  for(const e of G.enemies){if(!e.alive||e.spawnT>0||!(e.charging||e.tl95>0||e.weak95>0))continue;if(e.x>CX-10&&e.x<CX+VW+10&&e.y>CY-10&&e.y<CY+VH+10)continue;items.push([e.x,e.y,e.weak95>0?'#ffffff':EDEF[e.type].col,e.weak95>0?0:1]);}
  for(const o of tgList95()){if(o.st!=='warn')continue;const x=o.k==='line'?(o.x+o.x2)/2:o.x,y=o.k==='line'?(o.y+o.y2)/2:o.y;if(x>CX&&x<CX+VW&&y>CY&&y<CY+VH)continue;items.push([x,y,o.col,clamp(o.t/o.T,0,1)]);}
  if(!items.length)return;
  // стрелки — в «безопасной» рамке: ниже верхнего HUD, выше кнопок и стика на телефоне; на телефоне в CSS-пикселях и крупнее
  const mob=isMob(),por=isPortrait(),S=mob?1:SC,kk=mob?SC:1,vw=mob?CW:VW,vh=mob?CH:VH,L0=16,R0=vw-16,T0=mob?(por?122:66):88,B0=vh-(mob?(por?226:52):64),sz=mob?1.35:1;
  ctx.save();ctx.setTransform(DPR*S,0,0,DPR*S,0,0);const cx=(L0+R0)/2,cy=(T0+B0)/2;
  for(const [x,y,c,k] of items.slice(0,10)){const sx=(x-CX)*kk,sy=(y-CY)*kk,dx=sx-cx,dy=sy-cy;const s=Math.min((R0-cx)/Math.abs(dx||1e-6),(B0-cy)/Math.abs(dy||1e-6));const ax=cx+dx*s,ay=cy+dy*s,a=Math.atan2(dy,dx);
    ctx.save();ctx.translate(ax,ay);ctx.rotate(a);ctx.scale(sz,sz);ctx.globalAlpha=.55+.45*Math.abs(Math.sin(t*(6+k*14)));ctx.fillStyle=c;ctx.strokeStyle='#04060c';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(10,0);ctx.lineTo(-7,-8);ctx.lineTo(-3,0);ctx.lineTo(-7,8);ctx.closePath();ctx.stroke();ctx.fill();ctx.restore();}
  ctx.restore();}
// --- микшер: одновременно не больше 6 звуков врагов ---
const VOX95=[];
function vox95(dur,prio){const now=AU.ctx?AU.ctx.currentTime:0;for(let i=VOX95.length-1;i>=0;i--)if(VOX95[i]<now)VOX95.splice(i,1);if(!prio&&VOX95.length>=6)return false;VOX95.push(now+Math.min(1.5,dur||.3));return true;}
// --- общий буфер белого шума (X17) ---
let NB95=null;
function noiseBuf95(c){if(NB95&&NB95.sampleRate===c.sampleRate)return NB95;const len=c.sampleRate*2|0;NB95=c.createBuffer(1,len,c.sampleRate);const d=NB95.getChannelData(0);for(let i=0;i<len;i++)d[i]=Math.random()*2-1;return NB95;}
// --- звуки 0.9.5 ---
const SND95={};
const SND95P=new Set(['last','weak','perfect95','combo','launch2','phase95','plaque95','secret','chest','eyeOpen','stun','mark','choir','choirX','flood','kill95']);
function snd95(kind,x){if(!AU.ctx||!SET.sfx||!AU.sfx)return;const c=AU.ctx,t=c.currentTime;const now=performance.now();if(SND95[kind]&&now-SND95[kind]<70)return;SND95[kind]=now;
  if(!vox95(.4,SND95P.has(kind)))return;
  const pan=x===undefined||!isFinite(x)?0:clamp(((x-CX)/(VW||W))*2-1,-.6,.6);
  const out=()=>{if(pan&&c.createStereoPanner){const q=c.createStereoPanner();q.pan.value=pan;q.connect(AU.sfx);return q;}return AU.sfx;};
  const tone=(f0,f1,dur,type,vol,delay)=>{delay=delay||0;const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(f0,t+delay);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+delay+dur);g.gain.setValueAtTime(.0001,t+delay);g.gain.linearRampToValueAtTime(vol,t+delay+.01);g.gain.exponentialRampToValueAtTime(.0001,t+delay+dur);o.connect(g);g.connect(out());o.start(t+delay);o.stop(t+delay+dur+.03);};
  const noise=(dur,vol,f,type,delay,f2,q)=>{delay=delay||0;const s=c.createBufferSource();s.buffer=noiseBuf95(c);const fl=c.createBiquadFilter();fl.type=type||'lowpass';if(q)fl.Q.value=q;fl.frequency.setValueAtTime(f,t+delay);if(f2)fl.frequency.exponentialRampToValueAtTime(f2,t+delay+dur);const g=c.createGain();g.gain.setValueAtTime(vol,t+delay);g.gain.linearRampToValueAtTime(.0001,t+delay+dur);s.connect(fl);fl.connect(g);g.connect(out());s.start(t+delay,Math.random()*1.4,dur+.05);};
  switch(kind){
    case 'tlLine':tone(420,1100,.45,'sine',.035);break;
    case 'tlZone':noise(.5,.08,3000,'highpass',0,6000);break;
    case 'tlCone':tone(300,600,.35,'triangle',.04);break;
    case 'tlDash':noise(.35,.07,1200,'bandpass',0,3500,2);break;
    case 'tlRing':tone(120,90,.25,'sine',.12);break;
    case 'weak':tone(1760,1760,.18,'sine',.05);tone(2637,2637,.22,'sine',.03,.04);break;
    case 'mark':tone(980,980,.08,'square',.03);tone(1320,1320,.1,'square',.03,.08);break;
    case 'last':tone(220,880,.6,'sine',.09);noise(.6,.2,800,'lowpass',0,4000);break;
    case 'pop':tone(900,300,.1,'square',.03);break;
    case 'elite':tone(660,1320,.5,'triangle',.05);noise(.5,.18,2000,'bandpass',0,600);break;
    case 'kill95':noise(.18,.12,900,'bandpass',0,300);break;
    case 'leap':noise(.3,.1,500,'lowpass',0,1200);tone(160,90,.3,'sine',.08);break;
    case 'land':tone(90,40,.3,'sine',.25);noise(.25,.2,300,'lowpass',0,80);break;
    case 'spit':noise(.15,.12,1600,'bandpass',0,500);break;
    case 'spot':tone(700,1600,.5,'sawtooth',.03);break;
    case 'flash':noise(.25,.25,5000,'highpass',0,1500);tone(1800,600,.25,'square',.03);break;
    case 'needle':tone(2400,1800,.08,'square',.025);break;
    case 'lash':noise(.25,.22,2500,'bandpass',0,400,3);break;
    case 'impulse':tone(1500,2200,.12,'sine',.04);break;
    case 'zap':noise(.2,.15,4000,'highpass');tone(880,440,.15,'square',.03);break;
    case 'silhouette':tone(300,280,.8,'sine',.04);break;
    case 'streak':noise(.5,.11,3000,'highpass',0,800);tone(1200,300,.4,'sawtooth',.018);break;
    case 'zig':noise(.12,.12,2200,'bandpass',0,900,2);break;
    case 'glitch':for(let i=0;i<4;i++)tone(rnd(300,1600),rnd(300,1600),.05,'square',.025,i*.05);break;
    case 'beam':tone(110,220,1,'sawtooth',.05);noise(1,.12,800,'bandpass',0,3000);break;
    case 'beamFire':noise(.4,.35,1200,'lowpass',0,200);tone(220,60,.45,'sawtooth',.08);break;
    case 'sign':for(let i=0;i<5;i++)tone(600+i*80,600+i*80,.08,'triangle',.025,i*.04);break;
    case 'hop':tone(300,600,.15,'sine',.05);break;
    case 'splat':noise(.3,.2,700,'lowpass',0,200);break;
    case 'write':for(let i=0;i<6;i++)noise(.04,.08,5000,'highpass',i*.09);break;
    case 'fling':tone(500,1500,.25,'triangle',.04);break;
    case 'tongue':noise(.8,.08,300,'lowpass',0,900);break;
    case 'pilotDash':noise(.2,.15,2000,'bandpass',0,600);break;
    case 'pilotPulse':tone(300,120,.4,'sine',.12);noise(.3,.2,1500,'lowpass',0,300);break;
    case 'boom95':noise(.4,.35,900,'lowpass',0,120);tone(140,50,.35,'sine',.18);break;
    case 'inflate':tone(200,700,.5,'sine',.05);break;
    case 'bash':noise(.25,.3,600,'lowpass',0,150);tone(160,60,.25,'square',.06);break;
    case 'shieldHit':tone(1200,900,.06,'square',.02);break;
    case 'squeeze':tone(90,60,.4,'sine',.12);break;
    case 'perfect95':tone(784,784,.25,'sine',.07);tone(1175,1175,.22,'sine',.05,.02);tone(1568,1568,.2,'sine',.03,.04);break;
    case 'combo':for(let i=0;i<4;i++)tone(880*Math.pow(2,[0,4,7,12][i]/12),880*Math.pow(2,[0,4,7,12][i]/12),.25,'triangle',.04,i*.05);break;
    case 'whip':noise(.3,.3,3500,'bandpass',0,500,4);tone(400,80,.3,'sawtooth',.05);break;
    case 'rain':noise(.25,.12,1000,'bandpass',0,400);break;
    case 'shove':tone(70,40,.5,'sine',.3);noise(.4,.25,300,'lowpass',0,60);break;
    case 'fib':for(let i=0;i<5;i++)tone(80,60,.08,'sine',.12,i*.12);break;
    case 'flood':noise(1.2,.15,200,'lowpass',0,600);break;
    case 'launch2':for(const iv of [0,7,12,16,19])tone(196*Math.pow(2,iv/12),196*Math.pow(2,iv/12),1.6,'triangle',.05,iv*.012);noise(1.2,.25,500,'lowpass',0,4000);break;
    case 'phase95':tone(110,55,1.2,'sine',.2);noise(1,.2,400,'lowpass',0,3000);break;
    case 'tears':noise(1,.09,5000,'highpass',0,1200);tone(880,440,1,'sine',.026);break;
    case 'inhale95':noise(1.6,.2,400,'bandpass',0,4000,1.5);break;
    case 'speech':for(let i=0;i<4;i++)tone(220*Math.pow(2,[0,3,5,7][i]/12),220*Math.pow(2,[0,3,5,7][i]/12),.18,'sawtooth',.03,i*.07);break;
    case 'eyeOpen':tone(1320,1980,.4,'sine',.05);break;
    case 'stun':tone(660,110,.6,'triangle',.07);noise(.4,.2,3000,'highpass',0,500);break;
    case 'search':tone(1500,1400,.25,'sine',.02);break;
    case 'signal':for(let i=0;i<3;i++)tone(1046,1046,.09,'square',.025,i*.11);break;
    case 'rewrite':for(let i=0;i<6;i++)tone(rnd(400,1200),rnd(400,1200),.06,'triangle',.03,i*.06);break;
    case 'hands':noise(1.2,.2,600,'bandpass',0,200,2);break;
    case 'choirX':noise(.6,.15,2000,'bandpass',0,300);tone(523,262,1,'sine',.05);break;
    case 'shade':tone(110,330,.9,'sawtooth',.035);noise(.8,.1,700,'bandpass',0,2000);break;
    case 'crumble95':for(let i=0;i<10;i++)noise(.08,.12,1500+i*300,'bandpass',i*.06);break;
    case 'plaque95':tone(1046,1046,.08,'sine',.04);tone(1568,1568,.14,'sine',.03,.07);break;
    case 'secret':for(let i=0;i<4;i++)tone(1318*Math.pow(2,[0,4,7,12][i]/12),1318*Math.pow(2,[0,4,7,12][i]/12),.4,'sine',.035,i*.07);break;
    case 'chest':tone(523,1046,.3,'triangle',.05);tone(784,1568,.3,'triangle',.04,.08);break;
    case 'event':tone(220,220,.6,'sawtooth',.04);tone(330,330,.6,'sawtooth',.03,.1);noise(.8,.12,600,'bandpass',0,1800);break;
    case 'pore':noise(.3,.08,400,'bandpass',0,900,2);break;
    case 'fade95':noise(.5,.06,6000,'highpass',0,2000);break;
    case 'pillar':noise(.35,.25,500,'lowpass',0,100);tone(200,60,.3,'triangle',.05);break;}}

// ===== 0.9.5: новые враги сектора IX — Лейкоциты, Спазм, Тельце-бомба, Иммунный страж, Великий Тромб =====
function ai95(e,dt,c){if(e.type==='hunt95'&&!e.pk95i)huntInit95(e);if(e.idle95&&typeof idle95==='function'&&idle95(e,dt))return true;switch(e.type){
    case 'hunt95':huntAI95(e,dt,c);return true;
    case 'spasm95':spasmAI95(e,dt,c);return true;
    case 'cell95':cellAI95(e,dt,c);return true;
    case 'guard95':guardAI95(e,dt,c);return true;
    case 'gclot95':gclotAI95(e,dt,c);return true;
    case 'blot95':blotAI95(e,dt,c);return true;
    case 'scribe95':scribeAI95(e,dt,c);return true;
    case 'ebb95':ebbAI95(e,dt,c);return true;
    case 'lost95':lostAI95(e,dt,c);return true;}
  return false;}
function hurt95(e,dmg,src){switch(e.type){
    case 'spasm95':{const p=G.player,back=e.att95&&Math.abs(angDiff(Math.atan2(p.y-e.y,p.x-e.x),e.fa95||0))>100*Math.PI/180;if(back){if(!e.bh95){e.bh95=1;floater(e.x,e.y-e.r-12,'СЗАДИ ×1,5',C95.spasm);}return dmg*1.5;}return dmg;}
    case 'guard95':return src.charged?dmg*1.2:dmg;
    case 'blot95':return e.bs95==='air'?dmg*1.5:dmg;
    case 'gclot95':return src.charged||src.pulse?dmg*1.5:dmg;
    case 'lost95':return e.inv95>0?0:dmg;}
  return undefined;}
function kill95(e,silent){switch(e.type){
    case 'hunt95':{const P=e.pack95;if(P&&P.leader===e){P.leader=null;for(const m of P.mem)if(m.alive&&m!==e){m.solo95=1;m.hs95='solo';m.ht95=rnd(.8,1.6);}if(!silent){floater(e.x,e.y-26,'ВОЖАК УБИТ · СТАЯ РАССЫПАЛАСЬ',C95.hunt);snd95('elite',e.x);}}break;}
    case 'spasm95':{const f=e.flow95;if(f&&f.sq95===e){f.sq95=null;f.spd95=1;f.w=f.w0||120;}break;}
    case 'cell95':if(!silent&&!e.boomed95)cellBoom95(e,false);break;
    case 'lost95':if(!silent)lostDrop95(e);break;
    case 'ebb95':if(!silent)ebbGone95(e);else ebbGone95(e,true);break;
    case 'scribe95':{for(const b of G.eb)if(b.line95&&b.line95===e.line95&&b.hold95>0){b.life=0;}break;}
    case 'gclot95':if(!silent&&typeof gclotDead95==='function')gclotDead95(e);break;}}
// --- Лейкоцит-охотник: стая из трёх, треугольник, бросок в центр ---
function huntInit95(e){if(e.pk95i)return;e.pk95i=1;if(!e.pack95&&!e.solo95&&!G.world&&e.packN95===undefined&&G.enemies.filter(o=>o.alive&&o.type==='hunt95').length>=8)e.solo95=1;
  if(!e.pack95&&!e.solo95){const P={leader:e,mem:[e],st:'gather',t:0};e.pack95=P;e.r=15;e.lead95=1;const nAll=G.world?0:G.enemies.filter(o=>o.alive&&o.type==='hunt95').length,n=Math.max(0,Math.min(e.packN95!==undefined?e.packN95:2,G.world?9:10-nAll));
    for(let i=0;i<n;i++){const a=rnd(0,TAU);const m=spawnEnemy('hunt95',e.x+Math.cos(a)*30,e.y+Math.sin(a)*30,{noAffix:true,noLoot:!!e.noLoot,pack95:P,spawnT:Math.max(.3,e.spawnT||0),zone:e.zone,pk95i:1,noCap95:1,idle95:e.idle95||0,pat95:e.pat95});P.mem.push(m);}}
  if(e.solo95){e.hs95='solo';e.ht95=1.2;}}
function huntAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;
  const P=e.pack95;
  if(e.hs95==='solo'||!P||P.leader===null&&e.solo95){huntSolo95(e,dt,c,pd,pdx,pdy);return;}
  if(P.leader!==e){// ведомые слушают вожака
    if(P.st==='dash'&&e.hd95){e.hd95.t-=dt;if(e.hd95.t<=0)e.hd95=null;return;}
    if(P.st==='tri'||P.st==='aim'){const i=P.mem.filter(m=>m.alive).indexOf(e),n=P.mem.filter(m=>m.alive).length;const a=P.a0+i*TAU/Math.max(1,n),tx=P.cx+Math.cos(a)*170,ty=P.cy+Math.sin(a)*170;steer(e,tx-e.x,ty-e.y,e.spd*1.3*c.sm,dt,5);return;}
    if(P.st==='rest'){e.vx*=.92;e.vy*=.92;return;}
    const lx=P.leader?P.leader.x:p.x,ly=P.leader?P.leader.y:p.y,a=Math.atan2(e.y-ly,e.x-lx)+dt;steer(e,lx+Math.cos(a)*40-e.x+(pdx/pd)*30,ly+Math.sin(a)*40-e.y+(pdy/pd)*30,e.spd*c.sm,dt,3);return;}
  // вожак ведёт стаю
  P.t+=dt;const live=P.mem.filter(m=>m.alive);
  if(P.st==='gather'){steer(e,pdx,pdy,e.spd*c.sm*(pd>260?1:.4),dt,3);if(P.t>2.2&&pd<320&&p.hp>0&&live.length>=2&&!(G.x90&&inMission()&&wallBlock95(e,p))){P.st='tri';P.t=0;P.cx=p.x;P.cy=p.y;P.a0=Math.atan2(e.y-p.y,e.x-p.x);}}
  else if(P.st==='tri'){P.cx+=(p.x-P.cx)*Math.min(1,dt*2);P.cy+=(p.y-P.cy)*Math.min(1,dt*2);const i=live.indexOf(e),a=P.a0+i*TAU/Math.max(1,live.length);steer(e,P.cx+Math.cos(a)*170-e.x,P.cy+Math.sin(a)*170-e.y,e.spd*1.3*c.sm,dt,5);
    if(P.t>1.1){P.st='aim';P.t=0;P.T=.6*tel90('hunt95');P.tx=p.x;P.ty=p.y;snd95('tlDash',e.x);tlog95('hunt95',P.T);tel90use('hunt95');for(const m of live)m.tl95=P.T;}}
  else if(P.st==='aim'){for(const m of live){m.vx*=.85;m.vy*=.85;}P.tx+=(p.x-P.tx)*Math.min(1,dt*3);P.ty+=(p.y-P.ty)*Math.min(1,dt*3);
    if(P.t>=P.T){P.st='dash';P.t=0;for(const m of live){const a=Math.atan2(P.ty-m.y,P.tx-m.x);m.vx=Math.cos(a)*620;m.vy=Math.sin(a)*620;m.hd95={t:.38};m.tl95=0;}snd95('pilotDash',e.x);}}
  else if(P.st==='dash'){if(e.hd95){e.hd95.t-=dt;if(e.hd95.t<=0)e.hd95=null;}if(P.t>.42){P.st='rest';P.t=0;}}
  else if(P.st==='rest'){for(const m of live){m.vx*=.92;m.vy*=.92;}if(P.t>1.2){P.st='gather';P.t=0;}}}
function huntSolo95(e,dt,c,pd,pdx,pdy){const p=G.player;if(e.ht95===undefined)e.ht95=1.4;
  if(e.hd95){e.hd95.t-=dt;if(e.hd95.t<=0){e.hd95=null;e.ht95=rnd(2,2.8);}return;}
  if(e.hq95>0){e.hq95-=dt;e.vx*=.8;e.vy*=.8;if(e.hq95<=0){const a=Math.atan2(p.y-e.y,p.x-e.x);e.vx=Math.cos(a)*600;e.vy=Math.sin(a)*600;e.hd95={t:.34};e.tl95=0;snd95('pilotDash',e.x);}return;}
  const m=clamp((pd-200)/100,-1,1);steer(e,pdx/pd*m-pdy/pd*.7*e.dir,pdy/pd*m+pdx/pd*.7*e.dir,e.spd*c.sm,dt,3);e.ht95-=dt;
  if(e.ht95<=0&&pd<360&&p.hp>0&&!(G.x90&&inMission()&&wallBlock95(e,p))){e.hq95=.6*tel90('hunt95');e.tl95=e.hq95;e.ha95=Math.atan2(p.y-e.y,p.x-e.x);tlog95('hunt95',e.hq95);tel90use('hunt95');snd95('tlDash',e.x);}}
// --- Спазм: присасывается к ленте, сжимает её, выбрасывает сгустки в такт ---
function spasmAI95(e,dt,c){const X=G.x90,p=G.player;if(e.sp95===undefined){e.sp95=rnd(1.5,3);e.fa95=0;}
  if(!e.att95){let best=null,bd=420,bi=0,bf=null;if(X&&inMission()&&X.flows.length){for(const f of X.flows){if(!f.pts||f.sq95&&f.sq95!==e&&f.sq95.alive)continue;for(let i=4;i<=28;i+=2){const q=f.pts[i];if(!q||q.x<50||q.x>W-50||q.y<50||q.y>H-50)continue;const d=Math.hypot(q.x-e.x,q.y-e.y);if(d<bd){bd=d;best=q;bi=i;bf=f;}}}}
    if(best){steer(e,best.x-e.x,best.y-e.y,e.spd*1.6*c.sm,dt,3);if(bd<14){e.att95=1;e.flow95=bf;e.fi95=bi;bf.sq95=e;bf.w0=bf.w0||bf.w;bf.w=70;bf.spd95=2;e.vx=e.vy=0;floater(e.x,e.y-e.r-14,'СПАЗМ · ПОТОК ×2',C95.spasm);snd95('squeeze',e.x);}}
    else{// без лент: к ближайшей стене, сжимает пространство вдоль неё
      const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;const m=clamp((pd-260)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.4*e.dir,pdy/pd*m+pdx/pd*.4*e.dir,e.spd*c.sm,dt,2);e.fa95=Math.atan2(pdy,pdx)+Math.PI;}}
  else{const f=e.flow95,q=f&&f.pts?f.pts[e.fi95]:null;if(q){e.x=q.x;e.y=q.y;e.fa95=Math.atan2(-q.tx,q.ty);const side=Math.sign((p.x-q.x)*(-q.ty)+(p.y-q.y)*q.tx)||1;e.fa95=Math.atan2(q.tx*side,-q.ty*side);}e.vx=e.vy=0;if(f&&f.sq95!==e)e.att95=0;}
  e.sp95-=dt;e.pul95=e.sp95<.6?1-e.sp95/.6:0;if(e.sp95<=.6&&!e.spw95){e.spw95=1;e.tl95=.6;snd95('squeeze',e.x);tlog95('spasm95',.6);}
  if(e.sp95<=0){e.sp95=4;e.spw95=0;e.tl95=0;tel90use('spasm95');const f=e.flow95,q=f&&f.pts?f.pts[e.fi95]:null;let a=q?Math.atan2(q.ty,q.tx):Math.atan2(p.y-e.y,p.x-e.x);if(f&&f.rev95)a+=Math.PI;
    if(G.world||onScreen(e)){for(let i=0;i<4;i++)eb95(e.x,e.y,a+(i-1.5)*.08,330-i*25,9*first90(e),C95.spasm,6,'cell');if(q)for(let i=0;i<2;i++)eb95(e.x,e.y,a+Math.PI+(i-.5)*.1,260,9*first90(e),C95.spasm,6,'cell');}snd95('spit',e.x);trauma90(.06);}}
// --- Тельце-бомба: несётся по лентам, раздувается рядом с вами ---
function cellAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;
  if(e.inf95!==undefined){e.inf95-=dt;e.vx*=.86;e.vy*=.86;e.r=EDEF.cell95.r*(1+.7*(1-Math.max(0,e.inf95)/e.inf0));if(e.inf95<=0)cellBoom95(e,true);return;}
  const q=G.x90&&inMission()?flowQ(e.x,e.y):null;if(q){e.x+=q.tx*170*q.k*dt;e.y+=q.ty*170*q.k*dt;}
  steer(e,pdx,pdy,e.spd*c.sm*(q?.6:1),dt,2.4);
  if(pd<90&&p.hp>0){e.inf0=e.inf95=.5*tel90('cell95');snd95('inflate',e.x);tg95({k:'zone',x:e.x,y:e.y,r:70,T:e.inf95,dmg:15,col:C95.cell,src:e,key:'cell95',snd:false,telK:false,track:o=>{o.x=e.x;o.y=e.y;},hitE:40,fx:false});}}
function cellBoom95(e,self){if(e.boomed95)return;e.boomed95=1;const x=e.x,y=e.y;explode(x,y,C95.cell,22,.9);snd95('boom95',x);trauma90(.2);if(G.shock.length<60)G.shock.push({x,y,r:10,R:74,t:0,col:C95.cell,thin:false});
  if(!self)for(const o of G.enemies){if(!o.alive||o===e||STATIC.has(o.type)||EDEF[o.type].passive||o.sbk||EDEF[o.type].sbp)continue;if(Math.hypot(o.x-x,o.y-y)<70+o.r)hurt(o,40,{pulse:true});}
  if(self&&e.alive)kill(e,true);}
// --- Иммунный страж: мембрана спереди, удар щитом конусом, заряд пробивает и оглушает ---
function guardAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;if(e.fa95===undefined){e.fa95=Math.atan2(pdy,pdx);e.bs95=rnd(1.5,2.5);}
  if(e.mb95>0)e.mb95-=dt;
  if(e.bash95){const B=e.bash95;B.t-=dt;e.vx*=.8;e.vy*=.8;if(B.t<=0){e.bash95=null;e.vx=Math.cos(e.fa95)*360;e.vy=Math.sin(e.fa95)*360;e.mb95=Math.max(e.mb95||0,1.2);weak95(e,1.2,1.5);if(!e.gw96){e.gw96=1;floater(e.x,e.y-e.r-14,'ПОСЛЕ УДАРА МЕМБРАНА ОПУЩЕНА ✦','#ffffff');}}return;}
  e.fa95+=clamp(angDiff(Math.atan2(pdy,pdx),e.fa95),-1.6*dt,1.6*dt);const m=clamp((pd-140)/80,-1,1);steer(e,pdx/pd*m,pdy/pd*m,e.spd*c.sm,dt,2);
  e.bs95-=dt;e.charging=e.bs95<.7;if(e.bs95<=0&&pd<300&&p.hp>0){e.bs95=3.5;const T=.7*tel90('guard95');e.bash95={t:T};tg95({k:'cone',x:e.x,y:e.y,a:e.fa95,arc:Math.PI/2,len:160,T,dmg:16,kb:120,col:C95.guard,src:e,key:'guard95',snd:'tlCone',telK:false,track:o=>{o.x=e.x;o.y=e.y;o.a=e.fa95;},on:()=>{snd95('bash',e.x);trauma90(.2);}});}}
function guardFront95(e,bx,by){if(e.mb95>0)return false;return Math.abs(angDiff(Math.atan2(by-e.y,bx-e.x),e.fa95||0))<Math.PI/3;}
// снаряды игрока против мембраны стража и перекладины геометрии (вызов из b90Hit)
function guardHit95(b){for(const e of G.enemies){if(e.type!=='guard95'||!e.alive||e.spawnT>0||b.hit.includes(e))continue;if(segDist(b.px,b.py,b.x,b.y,e.x,e.y)>e.r+8)continue;if(!guardFront95(e,b.px,b.py))continue;
    if(b.charged){e.mb95=2;e.stun=2;b.hit.push(e);floater(e.x,e.y-e.r-12,'МЕМБРАНА ПРОБИТА · ОГЛУШЁН',C95.guard);snd95('stun',e.x);hurt(e,b.dmg*.6,{charged:true});return false;}
    b.life=0;e.shieldFlash=.12;snd95('shieldHit',e.x);if(SET.fx)part(b.x,b.y,rnd(-80,80),rnd(-80,80),.2,C95.shield,2);if(!e.gh95){e.gh95=1;floater(e.x,e.y-e.r-12,'МЕМБРАНА · ОБХОДИТЕ СБОКУ','#c9d2de');}return true;}
  return false;}
// --- Великий Тромб (событие мира «Тромбоз»): три фазы атак ---
function gclotAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;const k=e.hp/e.maxHp,ph=k>.66?1:k>.33?2:3;if(ph!==e.ph95){e.ph95=ph;e.ga95=1.2;if(ph>1){banner('ВЕЛИКИЙ ТРОМБ · ФАЗА '+ph,ph===2?'ПЛЕВКИ ЛУЖ':'ВИХРЬ ТРОМБОВ');snd95('phase95',e.x);}}
  if(e.cs95==='air'){e.at95+=dt;const u=clamp(e.at95/.6,0,1);e.x=e.ax0+(e.lx-e.ax0)*u;e.y=e.ay0+(e.ly-e.ay0)*u;e.hz95=Math.sin(u*Math.PI)*90;if(u>=1){e.cs95=null;e.hz95=0;}return;}
  steer(e,pdx,pdy,e.spd*c.sm,dt,1.5);e.ga95-=dt;if(e.ga95>0)return;
  if(ph===1){e.ga95=3.2;e.cs95='sq';const tx=p.x+p.vx*.3,ty=p.y+p.vy*.3,T=.9;e.lx=tx;e.ly=ty;tg95({k:'zone',x:tx,y:ty,r:110,T:T+.6,dmg:20,col:C90.red,src:e,key:'gclot1',on:()=>{snd95('land',tx);trauma90(.35);if(G.shock.length<60)G.shock.push({x:tx,y:ty,r:20,R:200,t:0,col:C90.red});}});setTimeout0_95(e,T,()=>{e.cs95='air';e.ax0=e.x;e.ay0=e.y;e.at95=0;});}
  else if(ph===2){e.ga95=2.6;for(let i=0;i<3;i++){const a=rnd(0,TAU),d=i?rnd(80,180):0,x=p.x+Math.cos(a)*d,y=p.y+Math.sin(a)*d;tg95({k:'drop',x,y,r:56,T:1,dmg:12,col:C90.red,src:e,key:'gclot2',snd:i?false:undefined,on:()=>{const P=G.wpud95||(G.wpud95=[]);if(P.length>=6)P.shift();P.push({x,y,r:56,t:7,t0:7});}});}}
  else{e.ga95=3;for(let i=0;i<10;i++)eb95(e.x,e.y,G.t*2+i/10*TAU,200,9,C90.red,7,'cell');if(G.enemies.filter(o=>o.alive&&o.type==='clot90'&&o.gc95===e).length<4){const a=rnd(0,TAU);const m=spawnEnemy('clot90',e.x+Math.cos(a)*50,e.y+Math.sin(a)*50,{noAffix:true,noLoot:true,spawnT:.4,gc95:e});}snd95('spit',e.x);}}
// отложенное действие в такте ИИ (без setTimeout — по времени игры)
function setTimeout0_95(e,T,fn){(e.tq95||(e.tq95=[])).push({t:T,fn});}
function tq95Tick(dt){for(const e of G.enemies){if(!e.alive||!e.tq95||!e.tq95.length)continue;for(const q of e.tq95)q.t-=dt;const R=e.tq95.filter(q=>q.t<=0);e.tq95=e.tq95.filter(q=>q.t>0);for(const q of R)q.fn();}}

// ===== 0.9.5: новые враги сектора X — Клякса, Переписчик, Отливник, Стёртый пилот =====
// --- Клякса: три прыжка, круг приземления, чернильные пятна, брызги после третьего ---
function blotAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;if(e.bs95===undefined){e.bs95='idle';e.bt95=rnd(1,1.8);e.bj95=0;}
  if(e.bs95==='idle'){const m=clamp((pd-220)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.5*e.dir,pdy/pd*m+pdx/pd*.5*e.dir,e.spd*.6*c.sm,dt,2);e.bt95-=dt;if(e.bt95<=0&&pd<560&&p.hp>0){e.bj95=0;blotJump95(e);}return;}
  if(e.bs95==='squat'){e.vx*=.8;e.vy*=.8;e.bt95-=dt;if(e.bt95<=0){e.bs95='air';e.at95=0;e.ax0=e.x;e.ay0=e.y;snd95('hop',e.x);}return;}
  if(e.bs95==='air'){e.at95+=dt;const u=clamp(e.at95/.5,0,1);e.x=e.ax0+(e.lx-e.ax0)*u;e.y=e.ay0+(e.ly-e.ay0)*u;e.hz95=Math.sin(u*Math.PI)*44;e.vx=e.vy=0;
    if(u>=1){e.hz95=0;e.bj95++;snd95('splat',e.x);const Z=ez100();if(Z.filter(z=>z.by&&z.by.type==='blot95').length<6)Z.push({x:e.x,y:e.y,r:50,tele:0,t:4,by:e,ink95:1});
      if(e.bj95>=3){if(G.world||onScreen(e))for(let i=0;i<8;i++)eb95(e.x,e.y,i/8*TAU+e.seed,210,8*first90(e),C95.blot,6,'ink');snd95('splat',e.x);e.bs95='idle';e.bt95=2.6;}
      else blotJump95(e);}}}
function blotJump95(e){const p=G.player;let tx=p.x+p.vx*.35+rnd(-40,40),ty=p.y+p.vy*.35+rnd(-40,40);const d=Math.hypot(tx-e.x,ty-e.y),mx=230;if(d>mx){tx=e.x+(tx-e.x)/d*mx;ty=e.y+(ty-e.y)/d*mx;}
  if(!G.world){tx=clamp(tx,40,W-40);ty=clamp(ty,40,H-40);}e.lx=tx;e.ly=ty;e.bs95='squat';e.bt95=.3;
  tg95({k:'zone',x:tx,y:ty,r:50,T:.8,dmg:12,col:C95.blot,src:e,key:'blot95',snd:e.bj95?false:'tlZone',fx:false});}
// --- Переписчик: строка символов висит 1,2 с, потом летит веером; импульс стирает строку целиком ---
let LID95=0;
function scribeAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;if(e.wr95===undefined)e.wr95=rnd(2,3.5);
  if(e.wq95){const Q=e.wq95;e.vx*=.85;e.vy*=.85;Q.t-=dt;while(Q.t<=0&&Q.i<Q.n){Q.t+=.09;const u=Q.n>1?Q.i/(Q.n-1)-.5:0,x=Q.cx+Q.px*u*Q.L,y=Q.cy+Q.py*u*Q.L;
      const b=eb95(x,y,0,.001,8*first90(e),C95.scribe,6,'sym',{ch:GLYPH95[Math.random()*GLYPH95.length|0],line95:e.line95,hold95:1.2+(Q.n-1-Q.i)*.09,go95:scribeGo95});if(b)b.life=12;Q.i++;if(Q.i===1)snd95('write',e.x);}
    if(Q.i>=Q.n)e.wq95=null;return;}
  const m=clamp((pd-300)/120,-1,1);steer(e,pdx/pd*m-pdy/pd*.6*e.dir,pdy/pd*m+pdx/pd*.6*e.dir,e.spd*c.sm,dt,2.5);if(Math.random()<dt*.25)e.dir*=-1;
  e.wr95-=dt;e.charging=e.wr95<.4;if(e.wr95<=0&&pd<640&&p.hp>0){e.wr95=5.2;e.line95=++LID95;const a=Math.atan2(pdy,pdx),L=150,cx=e.x+Math.cos(a)*50,cy=e.y+Math.sin(a)*50;e.wq95={n:7,i:0,t:0,cx,cy,px:-Math.sin(a),py:Math.cos(a),L};tlog95('scribe95',1.2);tel90use('scribe95');}}
function scribeGo95(b){const p=G.player;if(!p)return;const a=Math.atan2(p.y-b.y,p.x-b.x)+rnd(-.06,.06);b.vx=Math.cos(a)*260;b.vy=Math.sin(a)*260;b.frz95=0;if(Math.random()<.2)snd95('fling',b.x);}
function scribeErase95(p,R){const ids=new Set();for(const b of G.eb)if(b.line95&&b.hold95>0&&Math.hypot(b.x-p.x,b.y-p.y)<R+40)ids.add(b.line95);if(!ids.size)return;let n=0;
  for(const b of G.eb)if(b.line95&&ids.has(b.line95)&&b.life>0){b.life=0;n++;glyph95(b.x,b.y,1,C95.scribe);}if(n){floater(p.x,p.y-50,'СТРОКА СТЁРТА · '+n,C95.scribe);snd95('fade95',p.x);}}
// --- Отливник: язык пустоты от края, стрельба с кончика; гибель очищает края на 6 с ---
function ebbEdge95(e){const ds=[e.x,W-e.x,e.y,H-e.y];let k=0;for(let i=1;i<4;i++)if(ds[i]<ds[k])k=i;return k;}
function ebbAI95(e,dt,c){const p=G.player;if(e.eg95===undefined){e.eg95=G.world?-1:ebbEdge95(e);e.sh95=rnd(1.5,2.5);}
  let ex=e.x,ey=e.y,nx=0,ny=0;if(e.eg95>=0){const k=e.eg95;if(k===0){ex=0;ey=e.y;nx=1;}else if(k===1){ex=W;ey=e.y;nx=-1;}else if(k===2){ex=e.x;ey=0;ny=1;}else{ex=e.x;ey=H;ny=-1;}
    const along=k<2?clamp(p.y,80,H-80):clamp(p.x,80,W-80),depth=200+30*Math.sin(G.t*.8+e.seed),tx=k<2?ex+nx*depth:along,ty=k<2?along:ey+ny*depth;
    steer(e,(k<2?tx:along)-e.x,(k<2?along:ty)-e.y,e.spd*c.sm,dt,2);if(k<2)e.x=clamp(e.x,Math.min(ex,ex+nx*260),Math.max(ex,ex+nx*260));else e.y=clamp(e.y,Math.min(ey,ey+ny*260),Math.max(ey,ey+ny*260));e.tg95={x1:k<2?ex:e.x,y1:k<2?e.y:ey,x2:e.x,y2:e.y};}
  else{const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,m=clamp((pd-300)/120,-1,1);steer(e,pdx/pd*m,pdy/pd*m,e.spd*c.sm,dt,2);e.tg95={x1:e.x-pdx/pd*200,y1:e.y-pdy/pd*200,x2:e.x,y2:e.y};}
  e.sh95-=dt;e.charging=e.sh95<.45;if(e.sh95<=0&&p.hp>0){e.sh95=2.6;const a=Math.atan2(p.y-e.y,p.x-e.x);if(G.world||onScreen(e))for(let i=-1;i<=1;i++)eb95(e.x,e.y,a+i*.16,250,8*first90(e),C95.ebb,6,'ink');snd95('spit',e.x);}}
function tongueBuild95(){const X=G.x90;const L=[];for(const e of G.enemies)if(e.alive&&e.type==='ebb95'&&e.tg95&&e.spawnT<=0)L.push({x1:e.tg95.x1,y1:e.tg95.y1,x2:e.tg95.x2,y2:e.tg95.y2,w:70,e});if(X&&inMission())X.tongue95=L;else G.wtongue95=L;}
function ebbGone95(e,silent){const X=G.x90;if(e.tg95&&!silent){const s=e.tg95;for(let i=0;i<=8;i++){const u=i/8;glyph95(s.x1+(s.x2-s.x1)*u,s.y1+(s.y2-s.y1)*u,1,C95.ebb);}}
  if(!silent&&X&&inMission()&&X.er){X.er.clrT95=6;X.er.clr95=1;floater(e.x,e.y-30,'ЯЗЫК СХЛОПНУЛСЯ · КРАЯ ЧИСТЫ 6 С',C95.ebb);snd95('fade95',e.x);}}
// --- Стёртый пилот: летает по вашим правилам — рывок (откат 1,5 с), импульс, заряд; роняет жетон ---
const LOSTN95=['ЛЕВ','ИРА','ТИМУР','ВАРЯ','ОЛЕГ','НИКА','ДАН','ЕВА','РОМАН','СОНЯ','ГЛЕБ','ЯНА'];
function lostSkin95(){const S=G.save,own=(S&&S.ownSkins||[]).filter(k=>SKINS[k]&&k!==curSkin());return own.length?own[Math.random()*own.length|0]:'base';}
function lostAI95(e,dt,c){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;
  if(!e.lp95){e.lp95=1;e.skin95=lostSkin95();e.nm95=LOSTN95[Math.random()*LOSTN95.length|0]+' · '+String(100+Math.random()*899|0);e.dcd95=1.5;e.pcd95=5;e.ccd95=4;e.fcd95=1;e.elite95=1;e.face=Math.atan2(pdy,pdx);}
  if(e.dcd95>0)e.dcd95-=dt;if(e.pcd95>0)e.pcd95-=dt;if(e.ccd95>0)e.ccd95-=dt;
  e.face=Math.atan2(pdy,pdx);
  if(e.dsh95){const D=e.dsh95;D.t-=dt;if(D.st==='aim'){e.vx*=.8;e.vy*=.8;if(D.t<=0){D.st='go';D.t=.16;e.vx=Math.cos(D.a)*1450;e.vy=Math.sin(D.a)*1450;e.inv95=.16;snd95('pilotDash',e.x);}}else{if(SET.fx)part(e.x,e.y,-e.vx*.1,-e.vy*.1,.3,C95.lost,2.2);if(D.t<=0){e.dsh95=null;e.dcd95=1.5;e.vx*=.2;e.vy*=.2;}}return;}
  if(e.chg95){const C=e.chg95;C.t-=dt;e.vx*=.9;e.vy*=.9;C.a+=clamp(angDiff(Math.atan2(pdy,pdx),C.a),-.8*dt,.8*dt);if(C.t<=0){e.chg95=null;e.ccd95=5;const b=shootE(e.x+Math.cos(C.a)*16,e.y+Math.sin(C.a)*16,C.a,900,18*first90(e),'#ffffff',7);snd95('beamFire',e.x);trauma90(.12);}return;}
  if(e.pls95){const P=e.pls95;P.t-=dt;e.vx*=.85;e.vy*=.85;if(P.t<=0){e.pls95=null;e.pcd95=7;wv95({x:e.x,y:e.y,v:620,w:12,dmg:12*first90(e),col:C95.lost,R:170});snd95('pilotPulse',e.x);trauma90(.15);for(const b of G.pb)if(Math.hypot(b.x-e.x,b.y-e.y)<170)b.life=0;}return;}
  // решения
  if(e.dcd95<=0&&(pd<160||Math.random()<dt*.5)&&p.hp>0){const side=Math.random()<.5?-1:1,a=Math.atan2(pdy,pdx)+side*1.1;e.dsh95={st:'aim',t:.45*tel90('lost95'),a};e.tl95=e.dsh95.t;snd95('tlDash',e.x);tlog95('lostDash',e.dsh95.t);return;}
  if(e.pcd95<=0&&pd<175&&p.hp>0){e.pls95={t:.6};e.tl95=.6;snd95('tlRing',e.x);tlog95('lostPulse',.6);return;}
  if(e.ccd95<=0&&pd<620&&pd>180&&p.hp>0){e.chg95={t:1.2,a:Math.atan2(pdy,pdx)};e.tl95=1.2;tlog95('lostCharge',1.2);return;}
  const m=clamp((pd-260)/100,-1,1);steer(e,pdx/pd*m-pdy/pd*.7*e.dir,pdy/pd*m+pdx/pd*.7*e.dir,e.spd*c.sm,dt,3);if(Math.random()<dt*.35)e.dir*=-1;
  e.fcd95-=dt;e.charging=e.fcd95<.3;if(e.fcd95<=0){e.fcd95=1.4;e.fb95=3;e.fbT95=0;}
  if(e.fb95>0){e.fbT95-=dt;if(e.fbT95<=0){e.fb95--;e.fbT95=.12;shootE(e.x,e.y,Math.atan2(pdy,pdx)+rnd(-.05,.05),480,6*first90(e),C95.lost,4);}}}
function lostDrop95(e){const X=G.x90;const L=X&&inMission()?(X.loot95||(X.loot95=[])):(G.wloot95||(G.wloot95=[]));L.push({k:'tag',x:e.x,y:e.y,t:0,nm:e.nm95||'ПИЛОТ'});floater(e.x,e.y-30,'ЖЕТОН · '+(e.nm95||''),C95.lost);}

// ===== 0.9.5: дизайн уровней 39–46 — геометрия, укрытия, поры, события арены, темп, тайники =====
// нормализованные координаты (0–1); в портрете арена поворачивается на 90°, а не сжимается
function port95(){return H>W*1.15;}
function rot95(u,v){const X=G.x90;if(X&&X.mir95)u=1-u;return port95()?{x:(1-v)*W,y:u*H}:{x:u*W,y:v*H};}
function sz95(){return clamp(Math.min(W,H)/760,.75,1.25);}
const LV95={
  39:{pil:[[.5,.5,58,'core'],[.2,.52,34],[.74,.22,30],[.76,.78,36,0,'sec']],sec:[.9,.9],
    flows:[[[-.05,.15],[.2,.05],[.3,.45],[.47,.49]],[[.9,1.05],[.85,.7],[.6,.75],[.52,.53]],[[1.05,.25],[.82,.1],[.72,.42],[.53,.47]]],ev:'rev',evName:['ПРИЛИВ КРОВИ','ЛЕНТЫ МЕНЯЮТ НАПРАВЛЕНИЕ'],elite:'hunt95'},
  40:{pil:[[.15,.3,30],[.15,.74,34],[.5,.24,36],[.5,.76,32],[.85,.28,34,0,'sec'],[.85,.72,30]],sec:[.93,.12],locks:[.3,.7],ev:'quar',evName:['КАРАНТИН','ШЛЮЗЫ ЗАКРЫТЫ · 10 СЕКУНД'],elite:'spasm95'},
  41:{pil:[[.5,.5,120,'core'],[.14,.2,28],[.86,.22,30,0,'sec'],[.18,.82,30]],sec:[.95,.1],ring:1,
    flows:[[[.12,.52],[.12,.04],[.88,.04],[.88,.5]],[[.88,.48],[.88,.96],[.12,.96],[.12,.5]]],ev:'zap',evName:['РАЗРЯД','ГАНГЛИЙ БЬЁТ ЛУЧАМИ · 15 СЕКУНД'],elite:'guard95'},
  43:{pil:[[.3,.3,40],[.7,.34,34],[.36,.72,30],[.68,.7,44,0,'sec']],sec:[.97,.06],secV:1,
    spits:[[0,.3,.2,.42,74],[1,.7,.8,.58,74],[.42,0,.48,.17,60],[.6,1,.54,.83,60],[1.02,-.02,.9,.12,90]],ev:'fog',evName:['ТУМАН ЗАБВЕНИЯ','ВИДНО ТОЛЬКО ВБЛИЗИ · 20 СЕКУНД'],elite:'blot95'},
  44:{pil:[[.12,.15,30],[.88,.85,30,0,'sec']],sec:[.04,.95],secV:1,rows:[.27,.5,.73],ev:'mir',evName:['ПРАВКА','АРЕНА ОТРАЖЕНА'],elite:'scribe95',
    spits:[[-.02,1.02,.1,.88,80]]},
  45:{pil:[[.35,.62,32],[.62,.4,34,0,'sec'],[.8,.22,28]],sec:[.03,.04],secV:1,poly:[[[-.02,-.02],[.56,-.02],[-.02,.64]],[[1.02,1.02],[.44,1.02],[1.02,.36]]],ev:'wave9',evName:['ДЕВЯТЫЙ ВАЛ','ДВА ПРИЛИВА НАВСТРЕЧУ'],elite:'lost95'},
  42:{pil:[]},46:{pil:[]}};
// --- геометрия: пересчёт при смене размера (X04: секунда неуязвимости и выталкивание без урона) ---
function lv95Init(M,X){const m=G.m,L=LV95[m];X.lv95=L||null;X.pil95=[];X.walls95=[];X.pores95=[];X.loot95=[];X.ev95=null;X.evDone95=0;X.mir95=0;X.rowT95=20;X.wv95=[];X.tg95=[];X.gw95=0;
  G.ol95=1;if(!L||M.bossRoom)return;
  for(const q of L.pil){const [u,v,r,kind,sec]=q;X.pil95.push({u,v,r0:r,r,core:kind==='core',hp:300,max:300,sec:sec==='sec',alive:true,hit:0});}
  if(L.flows&&X.flows&&X.flows.length){X.flows=L.flows.map(p=>({p,w:L.ring?100:120,shut:0,closed:false,valve:null}));X.gw=0;X.gwInit90=0;geo90(X);}
  if(L.locks&&X.locks)for(let i=0;i<X.locks.length;i++)if(L.locks[i]!==undefined)X.locks[i].nx=L.locks[i];
  if(L.rows){X.rows95=L.rows.map(v=>({v,gaps:rowGaps95()}));}
  const S=G.save;X.sec95={u:L.sec[0],v:L.sec[1],found:!!(S&&S.story&&((S.story.sec95||0)&(1<<(m-39)))),vis:!!L.secV};
  geo95(X,true);}
function rowGaps95(){const a=rnd(.1,.38),b=rnd(.55,.86);return [{c:a,w:.15},{c:b,w:.15}];}
function geo95(X,force){if(!X.lv95)return;if(!force&&X.gw95===W&&X.gh95===H)return;const first=!X.gw95;X.gw95=W;X.gh95=H;const k=sz95(),L=X.lv95;
  for(const q of X.pil95){const P=rot95(q.u,q.v);q.x=P.x;q.y=P.y;q.r=q.r0*k;}
  X.walls95=[];if(X.rows95)for(const R of X.rows95){let u0=0;const gs=R.gaps.slice().sort((a,b)=>a.c-b.c);for(const g of gs){const u1=g.c-g.w/2;if(u1-u0>.02){const A=rot95(u0,R.v),B=rot95(u1,R.v);X.walls95.push({x1:A.x,y1:A.y,x2:B.x,y2:B.y,w:14});}u0=g.c+g.w/2;}if(1-u0>.02){const A=rot95(u0,R.v),B=rot95(1,R.v);X.walls95.push({x1:A.x,y1:A.y,x2:B.x,y2:B.y,w:14});}}
  X.spits95=[];if(L.spits)for(const s of L.spits){const A=rot95(s[0],s[1]),B=rot95(s[2],s[3]);X.spits95.push({x1:A.x,y1:A.y,x2:B.x,y2:B.y,w:s[4]*k});}
  X.poly95=[];if(L.poly)for(const P of L.poly)X.poly95.push(P.map(([u,v])=>rot95(u,v)));
  if(X.sec95){const P=rot95(X.sec95.u,X.sec95.v);X.sec95.x=P.x;X.sec95.y=P.y;}
  X.pores95=[];const pp=[[0,.2],[0,.8],[1,.25],[1,.75],[.3,0],[.7,0],[.3,1],[.7,1]];for(const [u,v] of pp){const P=rot95(u,v);X.pores95.push({x:clamp(P.x,26,W-26),y:clamp(P.y,26,H-26),open:0});}
  if(!first){const p=G.player;if(p){p.inv=Math.max(p.inv,1);pushOut95(p,0);}for(const e of G.enemies)if(e.alive&&!STATIC.has(e.type))pushOut95(e,0);}}
// глубина пустоты от многоугольников стирания (берег в 45)
function polyD95(x,y,P){let inside=false;for(let i=0,j=P.length-1;i<P.length;j=i++){const a=P[i],b=P[j];if((a.y>y)!==(b.y>y)&&x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x)inside=!inside;}if(!inside)return 0;let d=1e9;for(let i=0,j=P.length-1;i<P.length;j=i++)d=Math.min(d,segDist(P[j].x,P[j].y,P[i].x,P[i].y,x,y));return d;}
// --- столкновения с укрытиями и строками-стенами ---
function blocked95(x,y,r){const X=G.x90;if(!X||!inMission()||!X.pil95)return false;for(const q of X.pil95)if(q.alive&&Math.hypot(x-q.x,y-q.y)<q.r+r)return true;for(const w of X.walls95)if(segDist(w.x1,w.y1,w.x2,w.y2,x,y)<w.w/2+r)return true;
  if(X.poly95)for(const P of X.poly95)if(polyD95(x,y,P)>0)return true;return false;}
function wallBlock95(a,b){const X=G.x90;if(!X||!inMission()||!X.pil95)return false;for(const q of X.pil95)if(q.alive&&segDist(a.x,a.y,b.x,b.y,q.x,q.y)<q.r*.9)return true;for(const w of X.walls95)if(segInter(a.x,a.y,b.x,b.y,w.x1,w.y1,w.x2,w.y2))return true;return false;}
function pushOut95(o,pad){const X=G.x90;if(!X||!X.pil95)return;const r=(o.r||14)+(pad||0);
  for(const q of X.pil95){if(!q.alive)continue;const dx=o.x-q.x,dy=o.y-q.y,d=Math.hypot(dx,dy)||1e-3,m=q.r+r*.85;if(d<m){o.x=q.x+dx/d*m;o.y=q.y+dy/d*m;if(o.vx!==undefined){const vn=(o.vx*dx+o.vy*dy)/d;if(vn<0){o.vx-=vn*dx/d;o.vy-=vn*dy/d;}}}}
  for(const w of X.walls95){const L2=(w.x2-w.x1)**2+(w.y2-w.y1)**2||1,t=clamp(((o.x-w.x1)*(w.x2-w.x1)+(o.y-w.y1)*(w.y2-w.y1))/L2,0,1),cx=w.x1+(w.x2-w.x1)*t,cy=w.y1+(w.y2-w.y1)*t,dx=o.x-cx,dy=o.y-cy,d=Math.hypot(dx,dy)||1e-3,m=w.w/2+r*.85;
    if(d<m){const px=o.px!==undefined?o.px:o.x-(o.vx||0)/60,py=o.py!==undefined?o.py:o.y-(o.vy||0)/60;let nx=dx/d,ny=dy/d;if(d<1){const sx=(px-cx),sy=(py-cy),sl=Math.hypot(sx,sy)||1;nx=sx/sl;ny=sy/sl;}o.x=cx+nx*m;o.y=cy+ny*m;}}}
// обход укрытий и строк-стен: скольжение по касательной, к ближнему разрыву строки
function nav95(e,X,dt,p){if(!p||e.type==='witness100'||e.type==='pass90'||e.hd95||e.dz95>0)return;const tx=p.x,ty=p.y;
  for(const q of X.pil95){if(!q.alive)continue;const dx=q.x-e.x,dy=q.y-e.y,d=Math.hypot(dx,dy)||1;if(d>q.r+e.r+70)continue;const px=tx-e.x,py=ty-e.y;if(px*dx+py*dy<=0)continue;if(segDist(e.x,e.y,tx,ty,q.x,q.y)>q.r+e.r*.8)continue;let ux=-dy/d,uy=dx/d;if(ux*px+uy*py<0){ux=-ux;uy=-uy;}if(Math.abs(ux*px+uy*py)<1){ux=-dy/d*(e.uid%2?1:-1);uy=dx/d*(e.uid%2?1:-1);}e.x+=ux*110*dt;e.y+=uy*110*dt;}
  if(X.walls95.length)for(const w of X.walls95){if(!segInter(e.x,e.y,tx,ty,w.x1,w.y1,w.x2,w.y2))continue;const L=Math.hypot(w.x2-w.x1,w.y2-w.y1)||1,ux=(w.x2-w.x1)/L,uy=(w.y2-w.y1)/L,pad=e.r+w.w/2+18;
    const ends=[[w.x1-ux*pad,w.y1-uy*pad],[w.x2+ux*pad,w.y2+uy*pad]].filter(([x,y])=>x>10&&x<W-10&&y>10&&y<H-10);if(!ends.length)continue;let best=ends[0],bd=1e9;for(const q of ends){const d=Math.hypot(q[0]-e.x,q[1]-e.y)+Math.hypot(q[0]-tx,q[1]-ty);if(d<bd){bd=d;best=q;}}
    const D=Math.hypot(best[0]-e.x,best[1]-e.y)||1,gx=(best[0]-e.x)/D,gy=(best[1]-e.y)/D,va=e.vx*gx+e.vy*gy;if(va<0){e.vx-=va*gx;e.vy-=va*gy;}e.x+=gx*130*dt;e.y+=gy*130*dt;break;}}
// пули: укрытия держат снаряды обеих сторон; ваши снаряды рушат тканевые столбы и обломки
function pilBullet95(b,mine){const X=G.x90;if(!X||!X.pil95)return false;const x0=b.px!==undefined?b.px:b.x-b.vx/60,y0=b.py!==undefined?b.py:b.y-b.vy/60;
  for(const q of X.pil95){if(!q.alive)continue;if(segDist(x0,y0,b.x,b.y,q.x,q.y)<q.r+(b.r||2)*.5){if(mine&&!q.core){q.hp-=b.dmg||10;q.hit=.12;if(q.hp<=0)pilBreak95(X,q);}if(mine&&b.charged&&!q.core)return false;b.life=0;if(SET.fx)part(b.x,b.y,rnd(-60,60),rnd(-60,60),.2,X.sec===8?C90.blood:C90.sh,2);return true;}}
  for(const w of X.walls95){if(segDist(w.x1,w.y1,w.x2,w.y2,b.x,b.y)<w.w/2+2||segInter(x0,y0,b.x,b.y,w.x1,w.y1,w.x2,w.y2)){b.life=0;if(SET.fx)part(b.x,b.y,rnd(-40,40),rnd(-40,40),.2,C90.sh,1.6);return true;}}return false;}
function pilBreak95(X,q){q.alive=false;snd95('pillar',q.x);trauma90(.15);explode(q.x,q.y,X.sec===8?C90.red:C90.sh,22,.9);if(X.sec===9)glyph95(q.x,q.y,10,C90.sh);floater(q.x,q.y-q.r-10,X.sec===8?'СТОЛБ РУХНУЛ':'ОБЛОМОК РАССЫПАЛСЯ',X.sec===8?C90.warm:C90.sh);
  if(q.sec&&X.sec95&&!X.sec95.found){X.sec95.vis=1;X.sec95.x=q.x;X.sec95.y=q.y;floater(q.x,q.y-q.r-30,'ЗА СТОЛБОМ ЧТО-ТО БЛЕСТИТ','#ffffff');snd95('secret',q.x);}}
// --- поры появления: IX — поры сосудов (видно за 1 с), X — враги проявляются из стёртого края ---
function spawn95(type,o){const X=G.x90;if(!on95()||!X.pores95||(G.sb&&G.sb.alive)||G.bc)return false;const p=G.player;if(!p)return false;
  let pts=[];if(X.sec===8){for(const q of X.pores95){const d=Math.hypot(q.x-p.x,q.y-p.y);if(d>=260&&!blocked95(q.x,q.y,20))pts.push([q,d]);}}
  else{for(let i=0;i<24;i++){const x=rnd(50,W-50),y=rnd(50,H-50);if(Math.hypot(x-p.x,y-p.y)<300||blocked95(x,y,24)||voidDepth100(x,y)>0)continue;let nearV=0;for(const [dx,dy] of [[60,0],[-60,0],[0,60],[0,-60]])if(voidDepth100(x+dx,y+dy)>0)nearV=1;const d=Math.min(x,W-x,y,H-y);if(nearV||d<120)pts.push([{x,y},Math.hypot(x-p.x,y-p.y)]);}}
  if(!pts.length)return false;pts.sort((a,b)=>b[1]-a[1]);const q=pts[Math.random()*Math.min(3,pts.length)|0][0];if(q.open!==undefined)q.open=1;
  G.warns.push({x:q.x,y:q.y,mx:q.x,my:q.y,type,t:(X.sec===8?1:.9)+(o.delay||0),o:Object.assign({},o,{sp95:X.sec})});return true;}
function spawned95(e,w){if(!w||!w.o){if(e&&typeof cap90==='function')cap90(e);return;}if(w.o.ob96)e.ob96=1;if(w.o.sp95){e.spawnT=w.o.sp95===9?.8:.45;e.vx=e.vy=0;if(w.o.sp95===9){glyph95(e.x,e.y,6,EDEF[e.type].col);snd95('fade95',e.x);}else{snd95('pore',e.x);if(SET.fx)for(let i=0;i<fxN95(8);i++){const a=vrnd3(0,TAU);part(e.x,e.y,Math.cos(a)*90,Math.sin(a)*90,.4,C90.blood,2.5);}}}
  if(w.o.e95){e.elite95=1;e.hp*=e.type==='guard95'?1.5:2;e.maxHp=e.hp;e.armor=3;if(!e.affix)e.affix=['armor'];floater(e.x,e.y-e.r-20,'КУЛЬМИНАЦИЯ · '+EDEF[e.type].name.toUpperCase(),'#ffffff');snd95('elite',e.x);}
  else if(typeof cap90==='function')cap90(e);}
// --- волны: темп миссии (знакомство · смешение · событие · передышка · кульминация) ---
function wavesPlan95(){for(const m of [39,40,41,43,44,45]){const M=MISSIONS[m-1];if(!M||!M.wavesT||M.plan95)continue;M.plan95=1;const W0=M.wavesT;const deb=W0[0]&&W0[0].length===1&&M.debut?W0[0]:null;let rest=deb?W0.slice(1):W0.slice();
    while(rest.length>5)rest.splice(rest.length-2,1);const plus=w=>{const out=w.slice();const n=Math.round(w.length*.2);for(let i=0;i<n;i++){const t=w[i%w.length];if(!String(t).includes(':'))out.push(t);}return out;};
    const mixed=rest.slice(0,3).map(plus),last=plus(rest[rest.length-1]||rest[0]),br=(rest[3]||rest[0]).filter(t=>!String(t).includes(':')).slice(0,Math.max(3,Math.round((rest[3]||rest[0]).length*.4)));
    const L=LV95[m];last.push('e95:'+(L&&L.elite||'gunner'));M.wavesT=(deb?[deb]:[]).concat(mixed,[br],[last]);M.br95=(deb?1:0)+3;}}
// --- тик уровня ---
function lv95Tick(X,dt){if(!X.lv95)return;geo95(X);const p=G.player,M=MISSIONS[G.m-1];
  for(const q of X.pil95)if(q.hit>0)q.hit-=dt;for(const q of X.pores95)if(q.open>0)q.open-=dt;
  // враги и снаряды против укрытий
  for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||e.sbk||EDEF[e.type].sbp||e.hz95>0)continue;pushOut95(e,0);if(e.spawnT<=0&&!e.passive95)nav95(e,X,dt,e.type==='fixer100'&&e.fx&&e.fx.alive?e.fx:p);}
  for(const b of G.eb){if(b.life<=0||b.rift||b.k95==='word')continue;pilBullet95(b,false);}
  // строки 44 переписываются каждые 20 с
  if(X.rows95){X.rowT95-=dt;if(X.rowT95<=1.2&&!X.rowW95){X.rowW95=1;snd95('rewrite',W/2);for(const w of X.walls95)for(let i=0;i<3;i++){const u=Math.random();glyph95(w.x1+(w.x2-w.x1)*u,w.y1+(w.y2-w.y1)*u,1,C90.sh);}}
    if(X.rowT95<=0){X.rowT95=20;X.rowW95=0;for(const R of X.rows95)R.gaps=rowGaps95();geo95(X,true);floater(W/2,H*.2,'СТРОКИ ПЕРЕПИСАНЫ',C90.sh);}}
  // темп волн
  if(G.waveIdx===1&&M.debut&&!X.deb95){const e=G.enemies.find(o=>o.alive&&o.type===M.debut&&!o.deb95);if(e){X.deb95=1;e.deb95=1;e.hp*=.3;e.maxHp=e.hp;}}
  if(G.waveIdx>=3&&!X.evDone95&&X.lv95.ev){X.evDone95=1;ev95Start(X);}
  if(M.br95&&G.waveIdx===M.br95+1&&!X.brDone95){X.brDone95=1;const P=rot95(.5,.5);let x=P.x,y=P.y;for(let i=0;i<10&&blocked95(x,y,30);i++){x=rnd(W*.3,W*.7);y=rnd(H*.3,H*.7);}X.loot95.push({k:'chest',x,y,t:0});banner('ПЕРЕДЫШКА','СУНДУК ЛОМА · КУЛЬМИНАЦИЯ СКОРО');snd95('chest',x);}
  if(X.ev95)ev95Tick(X,dt);
  // тайник и находки
  for(const q of X.loot95){q.t+=dt;if(p&&p.hp>0&&Math.hypot(p.x-q.x,p.y-q.y)<34)loot95(X,q);}X.loot95=X.loot95.filter(q=>!q.got);
  const S=X.sec95;if(S&&!S.found&&S.vis&&p&&p.hp>0&&Math.hypot(p.x-S.x,p.y-S.y)<30){S.found=1;secret95(X);}}
function loot95(X,q){q.got=1;const S=G.save,w=G.mode==='world'&&S;if(q.k==='chest'){if(w)S.lom+=60;else G.score+=600;floater(q.x,q.y-30,w?'СУНДУК · +60 ЛОМА':'СУНДУК · +600 ОЧКОВ','#ffb84d');const p=G.player;if(p)p.en=Math.min(100,p.en+40);snd95('chest',q.x);hs90(.05,0);}
  if(q.k==='tag'){if(w)S.lom+=40;floater(q.x,q.y-30,'ЖЕТОН · '+q.nm+(w?' · +40 ЛОМА':''),C95.lost);radioLine('ЖЕТОН',C95.lost,'«Пилот '+q.nm+'. Последняя запись: “Если найдёте — я долетел”».',.2);snd95('secret',q.x);}}
function secret95(X){const S=G.save,m=G.m,w=G.mode==='world'&&S&&S.story;if(w){S.story.sec95=(S.story.sec95||0)|(1<<(m-39));S.lom+=80;}floater(X.sec95.x,X.sec95.y-30,w?'ТАЙНИК · +80 ЛОМА':'ТАЙНИК','#ffffff');snd95('secret',X.sec95.x);hs90(.06,0);if(G.mc)G.mc.sec95=1;
  if(SET.fx)for(let i=0;i<16;i++){const a=rnd(0,TAU);part(X.sec95.x,X.sec95.y,Math.cos(a)*160,Math.sin(a)*160,.6,'#ffffff',2);}}
// --- события арены (волна 3): баннер, звук, перестройка за 2 с ---
function ev95Start(X){const L=X.lv95,k=L.ev;banner(L.evName[0],L.evName[1]);snd95('event',W/2);trauma90(.3);hs90(.12,1);
  if(k==='rev'){X.ev95={k,t:2,flip:0};}
  if(k==='quar'){X.ev95={k,t:10,sp:0};for(const Lk of X.locks)Lk.st='warn';}
  if(k==='zap'){X.ev95={k,t:16,a:rnd(0,TAU),hitT:0};}
  if(k==='fog'){X.ev95={k,t:20};}
  if(k==='mir'){X.ev95={k,t:2,flip:0};}
  if(k==='wave9'){if(X.tide){X.tide.wave9=1;X.tide.next=Math.min(X.tide.next,4);if(X.tide.bands){X.tide.bands=null;X.tide.band=null;}X.tide.warn=null;}X.ev95=null;}}
function ev95Tick(X,dt){const E=X.ev95,p=G.player;E.t-=dt;
  if(E.k==='rev'){if(E.t<=1&&!E.flip){E.flip=1;for(const f of X.flows)f.rev95=!f.rev95;trauma90(.2);}for(const f of X.flows)f.k95=Math.abs(E.t-1);}
  if(E.k==='quar'&&!E.sp){E.sp=1;const comp=[[.15,.5],[.5,.5],[.85,.5]],pool=['keeper90','phago90','clot90','spasm95','cell95'];for(const [u,v] of comp){for(let i=0;i<2;i++){const P=rot95(u+rnd(-.08,.08),v+rnd(-.3,.3));if(p&&Math.hypot(P.x-p.x,P.y-p.y)<180)continue;spawnEnemy(pool[Math.random()*pool.length|0],P.x,P.y,{spawnT:.8});}}}
  if(E.k==='zap'){const live=E.t<15;E.a+=(live?25:8)*Math.PI/180*dt;const c=X.pil95.find(q=>q.core);if(live&&c&&p&&p.hp>0&&p.dashT<=0){E.hitT-=dt;for(let i=0;i<4;i++){const a=E.a+i*Math.PI/2,x2=c.x+Math.cos(a)*1600,y2=c.y+Math.sin(a)*1600;if(E.hitT<=0&&segDist(c.x+Math.cos(a)*c.r,c.y+Math.sin(a)*c.r,x2,y2,p.x,p.y)<9+p.r*.55){E.hitT=.8;damagePlayer(10);floater(p.x,p.y-30,'РАЗРЯД −10','#ffe47a');}}}
    if(E.t<=0)snd95('zap',W/2);}
  if(E.k==='mir'){if(E.t<=1&&!E.flip){E.flip=1;mirror95(X);}}
  if(E.t<=0){if(E.k==='rev')for(const f of X.flows)f.k95=1;X.ev95=null;}}
function mirror95(X){X.mir95=X.mir95?0:1;const fx=x=>W-x;const p=G.player;if(p){p.x=fx(p.x);p.px=fx(p.px);p.vx=-p.vx;p.ang=Math.PI-p.ang;}
  for(const e of G.enemies){if(!e.alive)continue;e.x=fx(e.x);e.vx=-e.vx;if(e.ex!==undefined&&e.type==='witness100')e.ex=fx(e.ex);}
  for(const b of G.eb){b.x=fx(b.x);b.vx=-b.vx;}for(const b of G.pb){b.x=fx(b.x);b.px=fx(b.px);b.vx=-b.vx;}for(const k of G.pick){k.x=fx(k.x);k.vx=-k.vx;}
  for(const z of X.ez)z.x=fx(z.x);for(const s of X.estr95||[]){s.x1=fx(s.x1);s.x2=fx(s.x2);}for(const q of X.loot95)q.x=fx(q.x);if(X.ink95)for(const m of X.ink95)m.x=fx(m.x);for(const w of G.warns){w.x=fx(w.x);w.mx=fx(w.mx);}
  if(X.er){const w=X.er.w;[w[0],w[1]]=[w[1],w[0]];const n=X.er.wn;[n[0],n[1]]=[n[1],n[0]];}
  geo95(X,true);trauma90(.4);snd95('glitch',W/2);X.glitch95=.6;if(SET.fx)for(let i=0;i<30;i++)glyph95(rnd(0,W),rnd(0,H),1,C90.sh);}
// туман 43: автоприцел видит только вблизи
function targ95(e){const X=G.x90;if(!X||!inMission())return true;if(X.ev95&&X.ev95.k==='fog'&&G.player&&Math.hypot(e.x-G.player.x,e.y-G.player.y)>340)return false;if(X.pil95&&X.pil95.length&&G.player&&!EDEF[e.type].sbp&&wallBlock95(G.player,e))return false;return true;}
// --- рисунок уровня ---
function lvUnder95(X,t){if(!X.lv95)return;const k=sz95();
  // многоугольники стирания (берег 45) и песчаные косы (43)
  for(const P of X.poly95||[]){ctx.beginPath();ctx.moveTo(P[0].x,P[0].y);for(let i=1;i<P.length;i++)ctx.lineTo(P[i].x,P[i].y);ctx.closePath();ctx.fillStyle='rgba(3,6,7,.94)';ctx.fill();ctx.strokeStyle=rgba90(C90.sh,.75);ctx.lineWidth=1.6;ctx.stroke();ctx.strokeStyle=rgba90(C90.sh,.18);ctx.lineWidth=8;ctx.stroke();}
  for(const s of X.spits95||[]){ctx.lineCap='round';ctx.strokeStyle='rgba(3,6,7,.94)';ctx.lineWidth=s.w;ctx.beginPath();ctx.moveTo(s.x1,s.y1);ctx.lineTo(s.x2,s.y2);ctx.stroke();ctx.strokeStyle=rgba90(C90.sh,.55);ctx.lineWidth=1.5;ctx.setLineDash([5,7]);ctx.lineDashOffset=-t*10;
    const dx=s.x2-s.x1,dy=s.y2-s.y1,l=Math.hypot(dx,dy)||1,nx=-dy/l*s.w/2,ny=dx/l*s.w/2;ctx.beginPath();ctx.moveTo(s.x1+nx,s.y1+ny);ctx.lineTo(s.x2+nx,s.y2+ny);ctx.moveTo(s.x1-nx,s.y1-ny);ctx.lineTo(s.x2-nx,s.y2-ny);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.lineCap='butt';}
  // поры
  if(X.sec===8)for(const q of X.pores95){const o=clamp(q.open,0,1);ctx.fillStyle='rgba(40,6,12,.85)';ctx.strokeStyle=rgba90(C90.red,.45+.4*o);ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(q.x,q.y,14+8*o,9+6*o,Math.atan2(H/2-q.y,W/2-q.x),0,TAU);ctx.fill();ctx.stroke();if(o>0)glow(q.x,q.y,40,C90.blood,.5*o);}
  // стрелки потока после «Прилива крови»
  // эффект появления врагов в X: дрожание края
  for(const w of G.warns){if(!w.o||!w.o.sp95)continue;const u=clamp(1-w.t,0,1);if(w.o.sp95===9){ctx.strokeStyle=rgba90(C90.sh,.3+.5*u);ctx.lineWidth=1.5;ctx.setLineDash([3,4]);ctx.beginPath();ctx.arc(w.x,w.y,10+16*u,0,TAU);ctx.stroke();ctx.setLineDash([]);}
    else{glow(w.x,w.y,30+20*u,C90.blood,.3+.4*u);}}
  // разряд ганглия
  const E=X.ev95;if(E&&E.k==='zap'){const c=X.pil95.find(q=>q.core);if(c){const live=E.t<15;for(let i=0;i<4;i++){const a=E.a+i*Math.PI/2,x1=c.x+Math.cos(a)*c.r,y1=c.y+Math.sin(a)*c.r,x2=c.x+Math.cos(a)*1600,y2=c.y+Math.sin(a)*1600;
    if(live){ctx.strokeStyle=rgba90('#ffe47a',.25);ctx.lineWidth=18;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();ctx.strokeStyle='#fff6c4';ctx.lineWidth=2.5;ctx.stroke();}
    else{ctx.setLineDash([8,8]);ctx.lineDashOffset=-t*40;ctx.strokeStyle=rgba90('#ffe47a',.5);ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;}}}}}
function pilPaint95(c,q,sec,hit,dmg,t){
  if(sec===8){c.fillStyle='rgba(0,0,0,.35)';c.beginPath();c.ellipse(4,6,q.r*1.05,q.r,0,0,TAU);c.fill();c.fillStyle=hit?'#5a1420':'#2a0a12';c.strokeStyle=hit?'#ffffff':'#e0a0a8';c.lineWidth=2.5;c.beginPath();for(let i=0;i<=18;i++){const a=i/18*TAU,rr=q.r*(1+.05*Math.sin(a*5+q.u*9+t*1.2));if(i)c.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else c.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}c.closePath();c.fill();c.stroke();
        c.strokeStyle=rgba90('#c0405a',.7);c.lineWidth=3;c.beginPath();c.arc(0,0,q.r*.68,0,TAU);c.stroke();c.fillStyle='#120408';c.beginPath();c.arc(0,0,q.r*.38,0,TAU);c.fill();c.strokeStyle=rgba90('#ff8a9a',.5);c.lineWidth=1.2;c.stroke();
        c.strokeStyle=rgba90('#e0a0a8',.35);c.lineWidth=1;for(let i=0;i<8;i++){const a=i/8*TAU+q.v*3;c.beginPath();c.moveTo(Math.cos(a)*q.r*.4,Math.sin(a)*q.r*.4);c.lineTo(Math.cos(a)*q.r*.66,Math.sin(a)*q.r*.66);c.stroke();}
        if(dmg>.15){c.strokeStyle=rgba90('#ffe9b0',.35+.5*dmg);c.lineWidth=1.5;c.beginPath();c.moveTo(-q.r*.9,-q.r*.2);c.lineTo(-q.r*.3,q.r*.1);c.lineTo(q.r*.1,-q.r*.25);if(dmg>.5){c.moveTo(q.r*.2,q.r*.85);c.lineTo(q.r*.35,q.r*.3);c.lineTo(q.r*.8,q.r*.15);}c.stroke();}}
  else{c.fillStyle=hit?'#13221e':'#0a1412';c.strokeStyle=hit?'#ffffff':rgba90(C90.sh,.75);c.lineWidth=1.8;c.beginPath();const n=7;for(let i=0;i<=n;i++){const a=i/n*TAU+q.u*5,rr=q.r*(.82+.18*((i*37+Math.round(q.v*100))%5)/4);if(i)c.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else c.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}c.closePath();c.fill();c.stroke();
      c.font='700 '+Math.round(q.r*.5)+'px "JetBrains Mono",monospace';c.textAlign='center';c.textBaseline='middle';c.fillStyle=rgba90(C90.sh,.35+.3*dmg);c.fillText(GLYPH95[(Math.round(q.u*31+q.v*17))%GLYPH95.length],0,1);c.textAlign='left';c.textBaseline='alphabetic';}}
// кэш спрайтов столбов и обломков: тело рисуется один раз на состояние (удар, трещины)
const PIL95C=new Map();
function pilSpr95(q,sec,hit,dl){const S=DPR*SC>2.2?3:2,key=Math.round(q.u*1e4)+'|'+Math.round(q.v*1e4)+'|'+Math.round(q.r)+'|'+sec+'|'+(hit?1:0)+'|'+dl+'|'+S;let c=PIL95C.get(key);if(c)return c;
  const R=q.r*1.4,sz=Math.ceil(R*2*S);c=document.createElement('canvas');c.width=c.height=sz;const g=c.getContext('2d');g.setTransform(S,0,0,S,R*S,R*S);pilPaint95(g,q,sec,hit,dl===2?.6:dl===1?.3:0,0);
  if(PIL95C.size>160)PIL95C.clear();PIL95C.set(key,c);return c;}
const CORE95=new Map();
function coreSpr95(q,layer){const S=DPR*SC>2.2?3:2,key=Math.round(q.r)+'|'+layer+'|'+S;let c=CORE95.get(key);if(c)return c;const R=q.r*1.15,sz=Math.ceil(R*2*S);c=document.createElement('canvas');c.width=c.height=sz;const g=c.getContext('2d');g.setTransform(S,0,0,S,R*S,R*S);
  if(layer===0){g.fillStyle='#2a0810';g.strokeStyle=C90.ark;g.lineWidth=3;g.beginPath();g.arc(0,0,q.r,0,TAU);g.fill();g.stroke();g.strokeStyle=rgba90(C90.red,.6);g.lineWidth=2;for(let i=0;i<6;i++){const a=i/6*TAU;g.beginPath();g.moveTo(Math.cos(a)*q.r*.3,Math.sin(a)*q.r*.3);g.quadraticCurveTo(Math.cos(a+.4)*q.r*.7,Math.sin(a+.4)*q.r*.7,Math.cos(a+.2)*q.r*.95,Math.sin(a+.2)*q.r*.95);g.stroke();}}
  else{g.strokeStyle=rgba90('#ffe47a',.6);g.lineWidth=1.5;for(let i=0;i<7;i++){const a=i/7*TAU;g.beginPath();g.moveTo(Math.cos(a)*q.r*.22,Math.sin(a)*q.r*.22);g.quadraticCurveTo(Math.cos(a+.5)*q.r*.5,Math.sin(a+.5)*q.r*.5,Math.cos(a+.25)*q.r*.92,Math.sin(a+.25)*q.r*.92);g.stroke();}}
  CORE95.set(key,c);return c;}
function lvDraw95(X,t){if(!X.lv95)return;const k=sz95();
  for(const q of X.pil95){if(!q.alive)continue;const sec=X.sec,hit=q.hit>0,dmg=1-q.hp/q.max;ctx.save();ctx.translate(q.x,q.y);
    if(sec===8&&q.core){const pk=beat90(G.t),zp=X.ev95&&X.ev95.k==='zap';glow(0,0,q.r*1.8,C90.red,.25+.2*pk);
        // ядро ганглия — два слоя векторами (диск с красными жилами и жёлтые нервы): на слабом телефоне поворот больших спрайтов стоил втрое дороже путей (0.9.6)
        const z=1+.04*pk;ctx.save();ctx.rotate(t*.2);ctx.scale(z,z);coreVec96(q,0);ctx.restore();
        if(X.lv95.ring){glow(0,0,q.r*.9,'#ffe47a',(zp?.6:.3)+.2*Math.sin(t*5));ctx.fillStyle=rgba90('#fff6c4',.75+.2*Math.sin(t*5));ctx.beginPath();ctx.arc(0,0,q.r*.2*(1+.12*Math.sin(t*5)),0,TAU);ctx.fill();
          ctx.save();ctx.rotate(t*.4);coreVec96(q,1);ctx.restore();}}
    else{const dl=dmg>.5?2:dmg>.15?1:0,c=pilSpr95(q,sec,hit,dl),R=q.r*1.4,s=sec===8?1+.02*Math.sin(t*1.2+q.u*9):1;ctx.drawImage(c,-R*s,-R*s,R*2*s,R*2*s);}
    ctx.restore();}
  // строки-стены «Черновика»
  if(X.walls95.length){const warn=X.rowW95;for(const w of X.walls95){ctx.lineCap='round';ctx.strokeStyle=warn&&Math.sin(t*20)>0?'#ffffff':rgba90(C90.sh,.85);ctx.lineWidth=w.w;ctx.globalAlpha=.25;ctx.beginPath();ctx.moveTo(w.x1,w.y1);ctx.lineTo(w.x2,w.y2);ctx.stroke();ctx.globalAlpha=1;ctx.lineWidth=2;ctx.stroke();
      ctx.font='700 10px "JetBrains Mono",monospace';ctx.fillStyle=rgba90(C90.sh,.5);ctx.textAlign='center';const L=Math.hypot(w.x2-w.x1,w.y2-w.y1),n=Math.floor(L/18);for(let i=0;i<n;i++){const u=(i+.5)/n;ctx.fillText(GLYPH95[(i*7+Math.round(w.x1))%GLYPH95.length],w.x1+(w.x2-w.x1)*u,w.y1+(w.y2-w.y1)*u+3);}ctx.textAlign='left';ctx.lineCap='butt';}}
  // находки
  for(const q of X.loot95){const b=Math.sin(q.t*4)*3;glow(q.x,q.y,40,q.k==='tag'?C95.lost:'#ffb84d',.4+.2*Math.sin(q.t*3));ctx.save();ctx.translate(q.x,q.y+b);
    if(q.k==='chest'){ctx.fillStyle='#2a1a06';ctx.strokeStyle='#ffb84d';ctx.lineWidth=2;ctx.fillRect(-13,-9,26,18);ctx.strokeRect(-13,-9,26,18);ctx.beginPath();ctx.moveTo(-13,-2);ctx.lineTo(13,-2);ctx.stroke();ctx.fillStyle='#ffb84d';ctx.fillRect(-3,-5,6,6);}
    else{ctx.strokeStyle=C95.lost;ctx.fillStyle='#10161c';ctx.lineWidth=2;ctx.beginPath();ctx.rect(-8,-11,16,22);ctx.fill();ctx.stroke();ctx.beginPath();ctx.arc(0,-6,2.5,0,TAU);ctx.stroke();}ctx.restore();worldLabel(q.x,q.y-24,q.k==='chest'?'СУНДУК':'ЖЕТОН',q.k==='tag'?C95.lost:'#ffb84d');}
  const S=X.sec95;if(S&&!S.found&&S.vis){const p=G.player,near=p&&Math.hypot(p.x-S.x,p.y-S.y)<260;ctx.save();ctx.translate(S.x,S.y);ctx.rotate(t*1.2);ctx.globalAlpha=near?.95:.35+.2*Math.sin(t*3);ctx.strokeStyle='#ffffff';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,-8);ctx.lineTo(6,0);ctx.lineTo(0,8);ctx.lineTo(-6,0);ctx.closePath();ctx.stroke();ctx.restore();ctx.globalAlpha=1;if(near)worldLabel(S.x,S.y-18,'ТАЙНИК','#ffffff');}}
function lvTop95(X,t){const E=X.ev95,p=G.player;
  if(E&&E.k==='fog'&&p){const a=clamp(Math.min(E.t,20-E.t)*1.5,0,1);fog95(p,a);}
  if(X.glitch95>0){X.glitch95-=VDT74;/* ARCH·75 A-22 */ctx.save();ctx.setTransform(1,0,0,1,0,0);const w=cv.width,h=cv.height;for(let i=0;i<8;i++){const y=Math.random()*h,hh=rnd(4,30)*DPR;ctx.globalAlpha=.25;ctx.fillStyle=Math.random()<.5?'#7affc9':'#ffffff';ctx.fillRect(0,y,w,hh*.15);}ctx.restore();}}
// туман: тёмный экран с окном 300 px вокруг игрока (кэш спрайта)
let FOG95=null;
function fog95(p,a){if(!FOG95){const c=document.createElement('canvas');c.width=c.height=512;const g=c.getContext('2d'),gr=g.createRadialGradient(256,256,0,256,256,256);gr.addColorStop(0,'rgba(2,5,6,0)');gr.addColorStop(.55,'rgba(2,5,6,.15)');gr.addColorStop(.8,'rgba(2,5,6,.9)');gr.addColorStop(1,'rgba(2,5,6,.97)');g.fillStyle=gr;g.fillRect(0,0,512,512);FOG95=c;}
  const R=380,x=p.x-R,y=p.y-R;ctx.save();ctx.globalAlpha=a;ctx.drawImage(FOG95,x,y,R*2,R*2);ctx.fillStyle='rgba(2,5,6,.97)';const X0=(G.arena?CX:0)-50,Y0=(G.arena?CY:0)-50,X1=X0+VW+100,Y1=Y0+VH+100;
  ctx.fillRect(X0,Y0,X1-X0,Math.max(0,y-Y0));ctx.fillRect(X0,y+R*2,X1-X0,Math.max(0,Y1-y-R*2));ctx.fillRect(X0,y,Math.max(0,x-X0),R*2);ctx.fillRect(x+R*2,y,Math.max(0,X1-x-R*2),R*2);ctx.restore();}
// верхняя полоска прочности элиты кульминации и Стёртого пилота
function eliteBar95(t){const e=G.enemies.find(o=>o.alive&&(o.elite95)&&o.spawnT<=0);if(!e)return;const mob=isMob(),S=mob?1:SC,vw=mob?CW:VW;ctx.save();ctx.setTransform(DPR*S,0,0,DPR*S,0,0);const w=Math.min(360,vw*(mob&&!isPortrait()?.44:.6)),x=vw/2-w/2,y=mob?(isPortrait()?166:CH-16):100;
  ctx.fillStyle='rgba(6,8,12,.82)';ctx.fillRect(x-2,y-2,w+4,12);ctx.fillStyle=EDEF[e.type].col;ctx.fillRect(x,y,w*clamp(e.hp/e.maxHp,0,1),8);ctx.strokeStyle='rgba(255,255,255,.5)';ctx.lineWidth=1;ctx.strokeRect(x-2,y-2,w+4,12);
  const lbl=e.type==='lost95'?'СТЁРТЫЙ ПИЛОТ · '+(e.nm95||''):'ЭЛИТА · '+EDEF[e.type].name.toUpperCase();ctx.font='700 '+(mob?11:10)+'px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#04060c';ctx.fillText(lbl,vw/2+1,y-5);ctx.fillStyle='#ffffff';ctx.fillText(lbl,vw/2,y-6);ctx.textAlign='left';ctx.restore();}

// ===== 0.9.5: рисунок боссов IX–X — Сердце 2.0 и Берег 2.0 =====
// --- Сердце: три слоя (тело, сосудистая сетка, свечение), систола, трещины, хроматический сдвиг ---
const HB95={};
function heartGrad95(r,open){const key=Math.round(r)+'|'+(open>0?1:0);if(HB95[key])return HB95[key];const g=ctx.createRadialGradient(0,r*.1,r*.1,0,0,r*1.25);g.addColorStop(0,open>0?'#fff4d0':'#ffb84d');g.addColorStop(.35,'#a0182c');g.addColorStop(1,'#2a060c');return HB95[key]=g;}
const HMESH95=[[[-.5,-.45],[-.3,-.1],[-.1,.1],[.15,.7]],[[.45,-.5],[.3,-.2],[.2,0],[.4,.45]],[[-.3,-.1],[-.6,.15]],[[.3,-.2],[.62,-.05]],[[-.1,.1],[-.35,.5]],[[.2,0],[.05,.35]],[[-.62,-.35],[-.75,-.05]],[[.62,-.4],[.8,-.15]]];
const HCRACK95=[[[-.15,-.55],[.05,-.2],[-.05,.05],[.12,.4]],[[.5,-.3],[.25,-.05],[.38,.25]],[[-.6,-.1],[-.3,.12],[-.42,.42]],[[.05,.55],[.25,.3],[.5,.38],[.62,.12]]];
function heartPath95(r){ctx.beginPath();ctx.moveTo(0,r*1.05);ctx.bezierCurveTo(-r*1.25,r*.25,-r*1.15,-r*.9,-r*.42,-r*.82);ctx.bezierCurveTo(-r*.12,-r*.78,0,-r*.5,0,-r*.38);ctx.bezierCurveTo(0,-r*.5,r*.12,-r*.78,r*.42,-r*.82);ctx.bezierCurveTo(r*1.15,-r*.9,r*1.25,r*.25,0,r*1.05);ctx.closePath();}
function heartBody95(x,y,r,s,t,open,fl,crack,beat){ctx.save();ctx.translate(x,y);const sx=s*(1+.04*(1-s)),sy=s;ctx.scale(sx,sy);
  if(beat>0&&SET.fx&&!SET.lessFx){const o=2.2*beat/.12;ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.25*beat/.12;ctx.fillStyle='#ff2040';ctx.save();ctx.translate(o,0);heartPath95(r);ctx.fill();ctx.restore();ctx.fillStyle='#20e0ff';ctx.save();ctx.translate(-o,0);heartPath95(r);ctx.fill();ctx.restore();ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
  heartPath95(r);ctx.fillStyle=heartGrad95(r,open);ctx.fill();ctx.strokeStyle=fl>0?'#ffffff':C90.ark;ctx.lineWidth=2.5;ctx.stroke();
  // сосудистая сетка
  ctx.save();heartPath95(r);ctx.clip();ctx.strokeStyle=rgba90('#ff8a9a',.28+.12*(1-s)*6);ctx.lineWidth=1.4;ctx.beginPath();for(const L of HMESH95){ctx.moveTo(L[0][0]*r,L[0][1]*r);for(let i=1;i<L.length;i++)ctx.lineTo(L[i][0]*r,L[i][1]*r);}ctx.stroke();
  if(crack>0){ctx.strokeStyle=rgba90('#fff1c4',.65+.25*Math.sin(t*9));ctx.lineWidth=2;ctx.beginPath();for(let c=0;c<Math.min(crack,4);c++){const L=HCRACK95[c];ctx.moveTo(L[0][0]*r,L[0][1]*r);for(let i=1;i<L.length;i++)ctx.lineTo(L[i][0]*r,L[i][1]*r);}ctx.stroke();
    ctx.globalCompositeOperation='lighter';ctx.strokeStyle=rgba90('#ffd36b',.18);ctx.lineWidth=6;ctx.stroke();ctx.globalCompositeOperation='source-over';}
  ctx.restore();
  ctx.lineWidth=5;ctx.strokeStyle='#6a1020';for(const [ax,ay,bx,by] of [[-r*.25,-r*.7,-r*.35,-r*1.2],[r*.05,-r*.6,r*.1,-r*1.25],[r*.3,-r*.72,r*.55,-r*1.1]]){ctx.beginPath();ctx.moveTo(ax,ay);ctx.lineTo(bx,by);ctx.stroke();}
  if(open>0){ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.globalAlpha=open;ctx.beginPath();ctx.moveTo(0,-r*.3);ctx.lineTo(-r*.08,r*.1);ctx.lineTo(r*.06,r*.35);ctx.lineTo(0,r*.8);ctx.stroke();ctx.globalAlpha=1;}
  ctx.restore();}
// кривая систолы: резкое сжатие за 0,12 с, мягкое расправление
function systole95(b){if(b.phase>=4&&b.st==='fight')return 0;const u=b.bt;return u<.12?u/.12:Math.max(0,1-(u-.12)/.55);}
function heartFloor95(b){const R=Math.ceil(b.R+30),key=R;if(b.floor95&&b.floor95.k===key)return b.floor95.c;const c=document.createElement('canvas');c.width=c.height=R*2;const g=c.getContext('2d');
  const gr=g.createRadialGradient(R,R,b.r,R,R,b.R);gr.addColorStop(0,'rgba(70,12,22,.82)');gr.addColorStop(.75,'rgba(30,8,14,.66)');gr.addColorStop(1,'rgba(10,4,6,.25)');g.fillStyle=gr;g.beginPath();g.arc(R,R,b.R,0,TAU);g.fill();
  g.strokeStyle='rgba(140,30,50,.16)';g.lineWidth=1.5;const rr=mulberry(77);for(let i=0;i<26;i++){let a=rr()*TAU,d=b.r+rr()*(b.R-b.r);g.beginPath();g.moveTo(R+Math.cos(a)*d,R+Math.sin(a)*d);for(let j=0;j<5;j++){a+=(rr()-.5)*.5;d+=(rr()-.4)*40;g.lineTo(R+Math.cos(a)*d,R+Math.sin(a)*d);}g.stroke();}
  b.floor95={k:key,c};return c;}
function heartUnder(b,t){if(!b.R)return;const lit=b.st==='enter'?b.lit:1;ctx.save();ctx.globalAlpha=lit;
  const F=heartFloor95(b),R=F.width/2;ctx.drawImage(F,b.cx-R,b.cy-R);
  const pk=beat90(G.t)*.5+(b.sysK||0)*.5;ctx.strokeStyle=rgba90(C90.ark,.3+.3*pk);ctx.lineWidth=3;ctx.beginPath();ctx.arc(b.cx,b.cy,b.R,0,TAU);ctx.stroke();ctx.strokeStyle=rgba90(C90.red,.25);ctx.lineWidth=12;ctx.beginPath();ctx.arc(b.cx,b.cy,b.R+8,0,TAU);ctx.stroke();
  // ударная волна по полу на каждом ударе
  if(b.sysK>0&&b.st==='fight'&&b.phase<4){const k=1-b.sysK;ctx.strokeStyle=rgba90('#ff9aa8',.25*(1-k));ctx.lineWidth=2;ctx.beginPath();ctx.arc(b.cx,b.cy,b.r+(b.R-b.r)*k,0,TAU);ctx.stroke();}
  const sys=heartInSys(b);for(const v of b.ves){const ux=Math.cos(v.a),uy=Math.sin(v.a),nx=-uy,ny=ux,w=55*b.k,r0=b.r+20,r1=b.R+30,sh=v.shut>0||b.phase>=4;
    ctx.fillStyle=sh?'rgba(60,50,50,.25)':rgba90(C90.red,.14+.1*pk);ctx.beginPath();ctx.moveTo(b.cx+ux*r0+nx*w*.6,b.cy+uy*r0+ny*w*.6);ctx.lineTo(b.cx+ux*r1+nx*w,b.cy+uy*r1+ny*w);ctx.lineTo(b.cx+ux*r1-nx*w,b.cy+uy*r1-ny*w);ctx.lineTo(b.cx+ux*r0-nx*w*.6,b.cy+uy*r0-ny*w*.6);ctx.closePath();ctx.fill();
    if(b.whipV===v.i&&b.whipT>0){ctx.fillStyle=rgba90('#ff9aa8',.3*Math.min(1,b.whipT*2));ctx.fill();}
    ctx.setLineDash(sh?[3,10]:[10,16]);ctx.lineDashOffset=sh?0:(sys?-1:1)*t*120;ctx.strokeStyle=sh?'rgba(160,150,140,.4)':rgba90(C90.ark,.6);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(b.cx+ux*r0,b.cy+uy*r0);ctx.lineTo(b.cx+ux*r1,b.cy+uy*r1);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;
    if(v.shut>0&&b.phase<4)worldLabel(b.cx+ux*b.R*.72,b.cy+uy*b.R*.72-20,'ПЕРЕЖАТ · '+Math.ceil(v.shut),'#9fb0c4');}
  if(b.whipT>0)b.whipT-=VDT74;/* ARCH·75 A-22 */
  // кровотечение из разбитых клапанов
  for(const q of b.bleed){const a=Math.min(1,q.t,(q.t0-q.t)*2);rgDraw95(q.x,q.y,q.r*1.15,'#7a0a1c',.75*a,0,[.7,.5*a]);ctx.strokeStyle=rgba90(C90.blood,.5*a);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(q.x,q.y,q.r+2*Math.sin(t*3+q.x),0,TAU);ctx.stroke();
    if(SET.fx&&Math.random()<.2)part(q.x+rnd(-q.r,q.r)*.6,q.y+rnd(-q.r,q.r)*.6,0,-20,.5,C90.blood,2);}
  // затопление камеры в фазе 4: кровь поднимается от краёв
  if(b.phase>=4&&b.st==='fight'&&b.dry<b.R-2){ctx.save();ctx.beginPath();ctx.arc(b.cx,b.cy,b.R,0,TAU);ctx.arc(b.cx,b.cy,b.dry,0,TAU,true);ctx.fillStyle='rgba(96,8,24,.72)';ctx.fill();
    ctx.strokeStyle=rgba90('#ff6f86',.55+.25*Math.sin(t*4));ctx.lineWidth=2.5;ctx.beginPath();for(let i=0;i<=48;i++){const a=i/48*TAU,rr=b.dry+3*Math.sin(a*7+t*3)+2*Math.sin(a*13-t*4);const x=b.cx+Math.cos(a)*rr,y=b.cy+Math.sin(a)*rr;if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);}ctx.stroke();ctx.restore();
    if(b.dry<b.R*.75)worldLabel(b.cx,b.cy+b.dry-14,'СУХО',rgba90('#ffe9b0',.6));}
  for(const w of b.waves){ctx.lineWidth=(w.thin?7:14)*b.k;ctx.strokeStyle=rgba90(w.dmg>12?'#ff9a4d':C90.ark,.55);if(w.gaps&&w.gaps.length){const G2=w.gaps.slice().sort((a,c)=>a.a-c.a);for(let i=0;i<G2.length;i++){const a0=G2[i].a+G2[i].w/2,n=G2[(i+1)%G2.length],a1=n.a-n.w/2+(i===G2.length-1?TAU:0);ctx.beginPath();ctx.arc(b.cx,b.cy,w.r,a0,a1>a0?a1:a1+TAU);ctx.stroke();}}else{ctx.beginPath();ctx.arc(b.cx,b.cy,w.r,0,TAU);ctx.stroke();}
    ctx.lineWidth=2;ctx.strokeStyle='rgba(255,240,210,.7)';ctx.beginPath();ctx.arc(b.cx,b.cy,w.r,0,TAU);ctx.globalAlpha=lit*.35;ctx.stroke();ctx.globalAlpha=lit;}
  if(b.phase>=2&&b.phase<=3&&b.nextGaps&&b.st==='fight'){const k=clamp(b.bt/b.btN,0,1),R0=b.r+40*b.k;gapArrows95(b.cx,b.cy,R0,b.nextGaps,k,'#ffffff');if(b.phase===3)gapArrows95(b.cx,b.cy,R0,b.nextGaps.map(g=>({a:g.a+(b.gdir96||1)*heartOff96(),w:g.w})),k*.5,'#ffe9b0');}
  if(b.fib>0&&b.fibA96!==undefined&&b.st==='fight')gapArrows95(b.cx,b.cy,b.r+40*b.k,[{a:b.fibA96,w:70*Math.PI/180}],1,'#ff9a4d');
  ctx.restore();}
function heartDraw(b,t){if(!b.R||b.st==='dying')return;if(b.st==='fight'&&b.phase<4){const k=clamp(b.bt/b.btN,0,1),perf=heartInPerf(b),rr=b.r+8+(b.R*.5)*(1-k);ctx.strokeStyle=perf?'#ffffff':rgba90(C90.ark,.45);ctx.lineWidth=perf?3:1.5;ctx.beginPath();ctx.arc(b.cx,b.cy,rr,0,TAU);ctx.stroke();
    if(perf){glow(b.cx,b.cy,b.r*2.2,'#ffffff',.25);}}
  if(b.flashP>0){ctx.strokeStyle=rgba90('#ffffff',b.flashP*2);ctx.lineWidth=4;ctx.beginPath();ctx.arc(b.cx,b.cy,b.r*(1.3+(.35-b.flashP)*2),0,TAU);ctx.stroke();}
  if(b.combo>1&&b.st==='fight'&&b.phase<4){ctx.font='700 '+fpx(16)+'px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#04060c';ctx.fillText('×'+b.combo,b.cx+1,b.cy+b.r+30);ctx.fillStyle=b.comboBuff>1?'#ffffff':C90.warm;ctx.fillText('×'+b.combo,b.cx,b.cy+b.r+29);ctx.textAlign='left';}
  if(b.st==='final'||b.st==='scene')dock85Draw(b,t);
  if(b.st==='fight'&&b.phase>=4&&b.launch<=0&&b.keys.length){ctx.strokeStyle=rgba90(C90.ark,.3);ctx.lineWidth=2;ctx.setLineDash([3,8]);ctx.beginPath();ctx.arc(b.cx,b.cy,150*b.k,0,TAU);ctx.stroke();ctx.setLineDash([]);
    const k=b.keys[b.keyI];if(k){worldLabel(b.cx,b.cy+b.r+30,'КЛЮЧ '+['I','II','III','IV'][k.ki]+(b.rot96?' · ЛОВИТЕ НА ХОДУ':b.launches===1?' · ОБРАТНЫЙ ПОРЯДОК':' · ПРОЛЕТИТЕ В ТАКТ'),'#ffffff');const p=G.player;if(p&&b.keyI>0){ctx.strokeStyle=rgba90('#ffffff',.25);ctx.setLineDash([3,6]);ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(k.x,k.y);ctx.stroke();ctx.setLineDash([]);}}}
  if(inMission())ally85Draw(t);}
// лента тактов: следующие 4 удара бегут к линии «сейчас»; аритмия видна заранее
function heartLane95(b,t){if(b.st!=='fight')return;const Q=heartQ95(b),span=2.6;const marks=[];let acc=b.btN-b.bt;marks.push({t:acc,arr:b.curArr95?1:0});for(let i=0;i<5;i++){acc+=Q[i].d;marks.push({t:acc,arr:Q[i].arr});}
  const mob=isMob(),por=isPortrait(),S=mob?1:SC,vw=mob?CW:VW,vh=mob?CH:VH;ctx.save();ctx.setTransform(DPR*S,0,0,DPR*S,0,0);const w=Math.min(440,vw*(por?.92:mob?.5:.72)),h=mob?22:24,x0=vw/2-w/2,y0=por?158:mob?vh-h-8:vh-150;
  ctx.fillStyle='rgba(8,3,5,.72)';ctx.fillRect(x0,y0,w,h);ctx.strokeStyle=rgba90(C90.ark,.45);ctx.lineWidth=1;ctx.strokeRect(x0,y0,w,h);
  const hx=x0+34,pw=heartPerfW(b)/span*(w-44);ctx.fillStyle=rgba90('#ffffff',heartInPerf(b)?.3:.1);ctx.fillRect(hx,y0+2,pw,h-4);
  ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(hx,y0-3);ctx.lineTo(hx,y0+h+3);ctx.stroke();
  for(const m of marks){if(m.t>span)break;const x=hx+m.t/span*(w-44);const c=m.arr?'#ff9a4d':b.phase>=4?C90.warm:C90.ark;ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(x,y0+3);ctx.lineTo(x+5,y0+h/2);ctx.lineTo(x,y0+h-3);ctx.lineTo(x-5,y0+h/2);ctx.closePath();ctx.fill();}
  ctx.font='700 '+(mob?11:9)+'px "JetBrains Mono",monospace';ctx.fillStyle=rgba90('#ffe9b0',.7);ctx.textAlign='left';ctx.fillText(b.phase>=4?'КЛЮЧИ':'ТАКТ',x0+4,y0+h/2+3);
  if(b.combo>1){ctx.textAlign='right';ctx.fillStyle=b.comboBuff>1?'#ffffff':C90.warm;ctx.fillText('КОМБО ×'+b.combo,x0+w-6,y0+h/2+3);}ctx.textAlign='left';ctx.restore();}
function heartTop(b,t){if(b.st==='enter'&&b.lit<1){ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='rgba(8,2,4,'+(.85*(1-b.lit))+')';ctx.fillRect(0,0,cv.width,cv.height);ctx.restore();}
  if(b.launch>0){ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='rgba(255,240,210,'+(.06+.04*Math.sin(t*20))+')';ctx.fillRect(0,0,cv.width,cv.height);ctx.restore();}
  // удар сердца — пульс по кромке камеры (дешевле полноэкранной виньетки, читается так же)
  if(b.st==='fight'&&b.sysK>.08&&b.phase<4&&SET.fx){ctx.strokeStyle=rgba90('#ff4f6e',.32*b.sysK);ctx.lineWidth=10+8*b.sysK;ctx.beginPath();ctx.arc(b.cx,b.cy,b.R+6,0,TAU);ctx.stroke();}
  heartLane95(b,t);}
function heartDying(b,dt,t0){const fx=b.fx85;if(t0<=0){hs90(.25,2);trauma90(.7);}if(SET.fx&&Math.random()<(fx.kind==='wake'?.8:.4)){const a=rnd(0,TAU),v=rnd(60,260);part(b.cx,b.cy,Math.cos(a)*v,Math.sin(a)*v,rnd(.5,1.2),fx.kind==='stop'?'#9fb0c4':fx.kind==='wake'?C90.pil:C90.ark,rnd(2,4));}}
// --- Берег: пустота, горизонт, Смотритель горизонта, маяки-прожекторы, тени, руки ---
function shoreUnder(b,t){const N=24,pts=[];for(let i=0;i<=N;i++){const x=i/N*W;pts.push([x,hzAt100(b,x)]);}const lit=b.st==='enter'?b.lit:1;
  ctx.save();ctx.beginPath();ctx.moveTo(-20,-20);for(const q of pts)ctx.lineTo(q[0],q[1]);ctx.lineTo(W+20,-20);ctx.closePath();ctx.fillStyle='rgba(2,5,6,'+(.95*lit)+')';ctx.fill();
  if(b.st!=='dying'||b.hzF>0)shoreFaceDraw95(b,t,lit);
  if(!b.crumble){tornPath90(pts);ctx.strokeStyle=rgba90(b.ebb>0?'#ffffff':C90.sh,.18);ctx.lineWidth=14;ctx.stroke();ctx.strokeStyle=b.ebb>0?'#ffffff':C90.sh;ctx.lineWidth=2;ctx.stroke();}
  else{ctx.setLineDash([3,9]);tornPath90(pts);ctx.strokeStyle=rgba90(C90.sh,.35);ctx.lineWidth=1.5;ctx.stroke();ctx.setLineDash([]);}
  if(SET.fx&&!G.lowFx&&Math.random()<.6){const q=pts[Math.random()*pts.length|0];part(q[0]+rnd(-10,10),q[1],rnd(-15,15),rnd(-60,-20),rnd(.6,1.4),C90.sh,1.6);}
  ctx.fillStyle='rgba(122,255,201,.025)';ctx.fillRect(0,H*.8,W,H*.2);
  // слёзы: полосы стирания из глаз
  const X=G.x90;if(X&&X.strip95)for(const s of X.strip95){const a=Math.min(1,s.t*2,(s.t0-s.t)*4);ctx.globalAlpha=a;ctx.fillStyle='rgba(3,6,7,.92)';ctx.fillRect(s.x-s.w/2,s.y0,s.w,H-s.y0+10);ctx.strokeStyle=rgba90(C90.sh,.85);ctx.lineWidth=1.5;
    ctx.beginPath();for(const sd of [-1,1]){const x=s.x+sd*s.w/2;ctx.moveTo(x,s.y0);for(let y=s.y0;y<H+10;y+=24)ctx.lineTo(x+sd*3*Math.sin(y*.05+t*3),y);}ctx.stroke();
    if(SET.fx&&Math.random()<.5)part(s.x+rnd(-s.w/2,s.w/2),s.y0+rnd(0,H-s.y0),0,90,.5,C90.sh,1.6);ctx.globalAlpha=1;}
  // прожекторы маяков
  const k=shk95(),p=G.player;
  for(const q of b.beacons){if(!q.alive||q.spawnT>0)continue;const lx=q.x,ly=q.y-q.r*.95;
    if(q.bOn||q.bFlick){const on=q.bOn?1:(Math.sin(t*40)>0?.35:0),L=SHORE95.beamL*k,A=SHORE95.beamA;if(on>0){ctx.globalCompositeOperation='lighter';ctx.fillStyle=rgba90('#d8fff0',.09*on);ctx.beginPath();ctx.moveTo(lx,ly);ctx.arc(lx,ly,L,q.ba-A,q.ba+A);ctx.closePath();ctx.fill();
      ctx.fillStyle=rgba90('#ffffff',.08*on);ctx.beginPath();ctx.moveTo(lx,ly);ctx.arc(lx,ly,L*.75,q.ba-A*.45,q.ba+A*.45);ctx.closePath();ctx.fill();ctx.globalCompositeOperation='source-over';
      ctx.strokeStyle=rgba90(C90.sh,.4*on);ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(lx,ly);ctx.lineTo(lx+Math.cos(q.ba-A)*L,ly+Math.sin(q.ba-A)*L);ctx.moveTo(lx,ly);ctx.lineTo(lx+Math.cos(q.ba+A)*L,ly+Math.sin(q.ba+A)*L);ctx.stroke();}}
    // радиус щита: кольцо 260, тает по мере приближения
    if(b.st==='fight'&&p&&Math.hypot(p.x-q.x,p.y-q.y)<520){const m=shoreShK95(b,q);ctx.strokeStyle=rgba90(C90.sh,.1+.2*(1-m));ctx.setLineDash([2,10]);ctx.lineDashOffset=-t*8;ctx.beginPath();ctx.arc(q.x,q.y,260,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;}
    if(q.rw95){const R_=q.rw95,s=R_.slot,tx=s.nx*W,ty=s.ty,u=R_.t/R_.T;ctx.strokeStyle=rgba90(C90.sh,.5);ctx.setLineDash([3,6]);ctx.beginPath();ctx.moveTo(q.x,q.y);ctx.lineTo(tx,ty);ctx.stroke();ctx.setLineDash([]);
      ctx.font='700 11px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle=C90.sh;for(let i=0;i<4;i++){const v=(u+i/4)%1;ctx.fillText(GLYPH95[(i*7+Math.floor(t*6))%GLYPH95.length],q.x+(tx-q.x)*v,q.y+(ty-q.y)*v);}ctx.textAlign='left';
      ctx.strokeStyle=rgba90('#ffffff',.6);ctx.lineWidth=2;ctx.beginPath();ctx.arc(tx,ty,26,-Math.PI/2,-Math.PI/2+TAU*u);ctx.stroke();}}
  // разбитые слоты: обломки с мерцающим «?»
  for(const s of b.slots){if(!s.broken)continue;const x=s.nx*W,y=s.ty;ctx.strokeStyle=rgba90(C90.sh,.35);ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x-14,y+20);ctx.lineTo(x-6,y-2);ctx.lineTo(x+3,y+6);ctx.lineTo(x+12,y-4);ctx.lineTo(x+16,y+20);ctx.stroke();if(Math.sin(t*3+s.i)>.3)worldLabel(x,y-12,'?',rgba90(C90.sh,.6));}
  ctx.restore();}
const FACEG95={};
function shoreFaceDraw95(b,t,lit){const F=b.face,k=shk95(),p=G.player;if(b.st==='dying'&&b.crumble)return;const x=F.x,y=F.y,w=140*k,h=100*k;ctx.save();ctx.globalAlpha=lit*(b.st==='scene'||b.st==='final'?.5:1);
  const jit=F.stun>0?2.5:.6,J=()=>rnd(-jit,jit);const sh=C90.sh,wh='#f4fff9';
  glow(x,y,w*1.6,sh,.1+.05*Math.sin(t*1.3));
  // тело маски: тёмная пустота, в которой держится лицо
  {const gk=Math.round(w)+'|'+Math.round(h);let g=FACEG95[gk];if(!g){g=FACEG95[gk]=ctx.createRadialGradient(0,0,h*.15,0,0,w*1.12);g.addColorStop(0,'rgba(2,7,7,.86)');g.addColorStop(.72,'rgba(2,7,7,.58)');g.addColorStop(1,'rgba(2,7,7,0)');}ctx.save();ctx.translate(x,y);ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(0,0,w*1.12,h*1.08,0,0,TAU);ctx.fill();ctx.restore();}
  // строки развёртки: лицо — недописанная передача
  ctx.fillStyle=rgba90(sh,.07);for(let i=0;i<3;i++){const sy=y-h+((t*38+i*h*.7)%(h*2.1));ctx.fillRect(x-w*.95,sy,w*1.9,2);}
  // контур маски: незамкнутый, со стёртыми кусками; хроматический сдвиг (кроме «Меньше эффектов»)
  const outl=(ox,col)=>{ctx.strokeStyle=col;ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<=40;i++){const a=-Math.PI*.95+i/40*Math.PI*1.9,rx=w*(1+.06*Math.sin(a*3+t)),ry=h*(1.05+.08*Math.cos(a*2));const px=x+ox+Math.cos(a)*rx+J(),py=y+Math.sin(a)*ry*.9+J();if(i%9===4){ctx.moveTo(px,py);continue;}if(i)ctx.lineTo(px,py);else ctx.moveTo(px,py);}ctx.stroke();};
  if(SET.fx&&!SET.lessFx&&!isMob()){outl(-2.6,'rgba(255,70,110,.24)');outl(2.6,'rgba(70,225,255,.24)');}outl(0,rgba90(wh,.78));
  ctx.strokeStyle=rgba90(sh,.4);ctx.lineWidth=1;ctx.beginPath();for(let i=-3;i<=3;i++){ctx.moveTo(x+i*w*.28,y-h*.95+Math.abs(i)*6);ctx.lineTo(x+i*w*.24,y-h*.62+Math.abs(i)*4);}ctx.stroke();
  // брови
  ctx.strokeStyle=rgba90(wh,.8);ctx.lineWidth=2.5;for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(x+s*w*.18,y-h*.38+J());ctx.quadraticCurveTo(x+s*w*.45,y-h*(F.stun>0?.62:.5),x+s*w*.72,y-h*.34+J());ctx.stroke();}
  // глаза
  const op=F.open;for(const s of [-1,1]){const ex=x+s*64*k,ey=y-8*k,ew=34*k,eh=4+15*k*op;ctx.strokeStyle=rgba90(wh,.95);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(ex-ew,ey);ctx.quadraticCurveTo(ex,ey-eh,ex+ew,ey);ctx.quadraticCurveTo(ex,ey+eh,ex-ew,ey);ctx.closePath();ctx.fillStyle=op>.1?rgba90('#0a1a16',.95):'rgba(2,5,6,.9)';ctx.fill();ctx.stroke();
    if(op>.1){let lx=0,ly=0;if(p){const a=Math.atan2(p.y-ey,p.x-ex);lx=Math.cos(a)*ew*.35;ly=Math.sin(a)*eh*.35;}const ir=Math.min(eh*.9,12*k);glow(ex+lx,ey+ly,ir*3,F.stun>0?'#ffffff':sh,.5*op);ctx.fillStyle=F.stun>0?'#ffffff':sh;ctx.beginPath();ctx.arc(ex+lx,ey+ly,ir,0,TAU);ctx.fill();ctx.fillStyle='#04060c';ctx.beginPath();ctx.arc(ex+lx,ey+ly,ir*.4,0,TAU);ctx.fill();}
    // дорожки слёз
    ctx.strokeStyle=rgba90(sh,b.fa&&b.fa.k==='tears'?.8:.25);ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(ex+s*6,ey+eh);ctx.lineTo(ex+s*9+Math.sin(t*2+s)*2,ey+h*.55);ctx.stroke();}
  // рот: на «Речи» открывается тёмной щелью с буквами
  const mo=F.mouth,my=y+h*.42;ctx.strokeStyle=rgba90(wh,.85);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x-w*.32,my);ctx.quadraticCurveTo(x,my+(4+22*mo)*k,x+w*.32,my);if(mo>.05)ctx.quadraticCurveTo(x,my-(2+8*mo)*k,x-w*.32,my);ctx.stroke();
  if(mo>.2){ctx.fillStyle='rgba(2,5,6,.9)';ctx.fill();ctx.font='700 10px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle=rgba90(wh,mo);for(let i=0;i<5;i++)ctx.fillText(GLYPH95[(i*5+Math.floor(t*10))%GLYPH95.length],x-w*.2+i*w*.1,my+6*k);ctx.textAlign='left';}
  if(b.inh){ctx.strokeStyle=rgba90(sh,.3);ctx.lineWidth=1;for(let i=0;i<10;i++){const u=(t*1.5+i/10)%1,px=rnd(0,W),py=my+(H-my)*(1-u);ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(px+(x-px)*.06,py-30);ctx.stroke();}}
  if(F.stun>0)worldLabel(x,y-h*1.15,'ОГЛУШЁН · ×2','#ffffff');
  ctx.restore();}
function shoreDraw(b,t){const p=G.player;
  // тени боссов
  for(const s of b.shades){if(!s.alive)continue;const a=(s.spawnT>0?1-s.spawnT:1)*Math.min(1,s.life95*1.5),c=s.col95;ctx.save();ctx.translate(s.x,s.y);
    // тень прошлого босса: тёмное тело, свечение цвета босса, бегущий пунктир и (если можно) хроматический сдвиг
    const shp=()=>{ctx.beginPath();if(s.k95==='lek')ctx.rect(-70,-36,140,72);else if(s.k95==='well')ctx.arc(0,0,s.r*1.35,0,TAU);else if(s.k95==='heart')heartPath95(s.r*.8);else{ctx.save();ctx.rotate(Math.atan2((p?p.y:0)-s.y,(p?p.x:0)-s.x));ctx.moveTo(s.r*1.3,0);ctx.lineTo(-s.r,-s.r*.8);ctx.lineTo(-s.r*.5,0);ctx.lineTo(-s.r,s.r*.8);ctx.closePath();ctx.restore();}};
    ctx.globalAlpha=a;glow(0,0,(s.k95==='lek'?90:s.r*1.8),c,.18+.06*Math.sin(t*3+s.x));shp();ctx.fillStyle='rgba(4,8,10,.62)';ctx.fill();
    ctx.fillStyle=rgba90(c,.06);for(let i=0;i<3;i++){const y=-40+((t*30+i*27)%80);ctx.fillRect(-72,y,144,2);}
    if(SET.fx&&!SET.lessFx&&!isMob()){ctx.globalAlpha=.35*a;ctx.save();ctx.translate(-2.5,0);shp();ctx.strokeStyle='rgba(255,70,110,.8)';ctx.lineWidth=1.5;ctx.stroke();ctx.restore();ctx.save();ctx.translate(2.5,0);shp();ctx.strokeStyle='rgba(70,225,255,.8)';ctx.stroke();ctx.restore();}
    ctx.globalAlpha=.85*a;ctx.strokeStyle=c;ctx.lineWidth=2;ctx.setLineDash([5,4]);ctx.lineDashOffset=-t*20;
    if(s.k95==='lek'){ctx.strokeRect(-70,-36,140,72);ctx.beginPath();ctx.moveTo(-70,0);ctx.lineTo(70,0);ctx.moveTo(-20,-36);ctx.lineTo(-20,36);ctx.moveTo(20,-36);ctx.lineTo(20,36);ctx.stroke();}
    else if(s.k95==='well'){for(let i=1;i<=3;i++){ctx.beginPath();ctx.arc(0,0,s.r*i*.45,0,TAU);ctx.stroke();}}
    else if(s.k95==='heart'){ctx.setLineDash([]);heartPath95(s.r*.8);ctx.stroke();}
    else{shp();ctx.stroke();}
    ctx.setLineDash([]);ctx.restore();ctx.globalAlpha=a;const bw=80,k_=clamp(s.hp95/s.maxHp95,0,1);ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(s.x-bw/2,s.y-s.r-24,bw,4);ctx.fillStyle=c;ctx.fillRect(s.x-bw/2,s.y-s.r-24,bw*k_,4);
    if(!(banT>0))worldLabel(s.x,s.y-s.r-30,'ТЕНЬ · '+s.name95+' · '+Math.ceil(s.life95),c);ctx.globalAlpha=1;}
  // руки-стиратели
  const H_=b.hands;if(H_&&H_.sw&&H_.sw.st==='go'){const sw=H_.sw,span=sw.vert?H:W,at=sw.from?span-sw.pos:sw.pos,x=sw.vert?sw.x:at,y=sw.vert?at:sw.y,dir=sw.vert?(sw.from?-Math.PI/2:Math.PI/2):(sw.from?Math.PI:0);hand95(x,y,dir,t,shk95());}
  if(b.st==='final'||b.st==='scene')dock85Draw(b,t);if(b.st==='fight'&&b.ebb>0)worldLabel(W/2,b.hzF*H+40,'ОТЛИВ · '+Math.ceil(b.ebb),'#ffffff');if(inMission())ally85Draw(t);}
function hand95(x,y,dir,t,k){ctx.save();ctx.translate(x,y);ctx.rotate(dir);const s=1.3*k;ctx.scale(s,s);glow(0,0,80,'#ffffff',.28);ctx.lineCap='round';ctx.lineJoin='round';
  // пальцы: два сустава, белый контур и тёмная «плоть» пустоты; кончики шевелятся
  const fing=(x0,y0,l1,l2,a1,a2,w)=>{const x1=x0+Math.cos(a1)*l1,y1=y0+Math.sin(a1)*l1,x2=x1+Math.cos(a1+a2)*l2,y2=y1+Math.sin(a1+a2)*l2;ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x1,y1);ctx.lineTo(x2,y2);ctx.strokeStyle='#f4fff9';ctx.lineWidth=w+3/s;ctx.stroke();ctx.strokeStyle='rgba(2,5,6,.96)';ctx.lineWidth=w;ctx.stroke();return [x2,y2];};
  const tips=[];for(let i=0;i<4;i++){const yy=-18+i*12,L=(i===1||i===2?20:16),w=i===0||i===3?6.5:7.5;tips.push(fing(6,yy,L,L*.8+2*Math.sin(t*7+i),(i-1.5)*.08,.25*Math.sin(t*5+i*1.3)+(i-1.5)*.06,w));}
  tips.push(fing(-8,-22,16,14,-1.15,.55+.15*Math.sin(t*4),7));
  // ладонь
  ctx.beginPath();ctx.moveTo(-40,-26);ctx.quadraticCurveTo(-10,-34,10,-24);ctx.lineTo(12,24);ctx.quadraticCurveTo(-10,34,-40,26);ctx.closePath();ctx.fillStyle='rgba(2,5,6,.96)';ctx.fill();ctx.strokeStyle='#f4fff9';ctx.lineWidth=2.5/s;ctx.stroke();
  // линии ладони — стёртые строки
  ctx.strokeStyle=rgba90(C90.sh,.55);ctx.lineWidth=1.2/s;ctx.beginPath();ctx.moveTo(-30,-10);ctx.quadraticCurveTo(-12,-14,4,-6);ctx.moveTo(-32,6);ctx.quadraticCurveTo(-14,2,2,10);ctx.stroke();
  ctx.lineCap='butt';ctx.lineJoin='miter';
  if(SET.fx&&Math.random()<.35){const q=tips[Math.random()*tips.length|0],c=Math.cos(dir)*s,sn=Math.sin(dir)*s;glyph95(x+q[0]*c-q[1]*sn,y+q[0]*sn+q[1]*c,1,'#f4fff9');}
  ctx.restore();}
function shoreTop(b,t){if(b.st==='enter'&&b.lit<1){ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='rgba(2,5,6,'+(.85*(1-b.lit))+')';ctx.fillRect(0,0,cv.width,cv.height);ctx.restore();}
  if(b.phase>=3&&b.st==='fight'&&b.fade>0)vig95('#000000',.55*b.fade,.3);
  if(b.face&&b.face.stun>0&&b.st==='fight')vig95('#ffffff',.06*Math.min(1,b.face.stun),.5);}
function shoreDying(b,dt,t0){const fx=b.fx85;if(t0<=0){trauma90(.7);}b.hzF=Math.max(-.1,b.hzF-dt*.25);
  if(SET.fx&&Math.random()<.7){const x=rnd(0,W);glyph95(x,Math.max(10,hzAt100(b,x)),1,fx.kind==='forget'?'#9fb0c4':fx.kind==='record'?'#ffffff':C90.sh);}
  if(SET.fx&&Math.random()<.6)part(rnd(0,W),H*rnd(.2,.9),0,-rnd(30,90),rnd(.8,1.6),fx.kind==='forget'?'#9fb0c4':fx.kind==='record'?'#ffffff':C90.sh,rnd(1.5,3));}
// --- рисунок частей боссов (через drawE95) ---
function drawBoss95(e,t,icon,col,face,alpha){const r=e.r;
  switch(e.type){
    case 'beacon100':{const b=e.host85,m=b&&!icon?shoreShK95(b,e):1;ctx.fillStyle='#0a1412';ctx.beginPath();ctx.moveTo(-r*.7,r);ctx.lineTo(-r*.35,-r*.7);ctx.lineTo(r*.35,-r*.7);ctx.lineTo(r*.7,r);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle=col;ctx.beginPath();for(let i=1;i<4;i++){const y=r-i*r*.45;ctx.moveTo(-r*.6+i*.08*r,y);ctx.lineTo(r*.6-i*.08*r,y);}ctx.stroke();
      const sig=e.sigK>0,lampC=e.flash>0?'#ffffff':sig&&Math.sin(t*30)>0?C95.hom:e.bOn||icon?'#ffffff':col;ctx.fillStyle=lampC;ctx.beginPath();ctx.arc(0,-r*.95,r*.3,0,TAU);ctx.fill();if(!icon&&(e.bOn||sig))glow(0,-r*.95,r*1.4,sig?C95.hom:'#d8fff0',.6);
      if(!icon){if(m<1){ctx.globalAlpha=alpha*(1-m)*.8;ctx.strokeStyle=rgba90(C90.sh,.9);ctx.lineWidth=1.5;ctx.beginPath();for(let i=0;i<=6;i++){const a=i/6*TAU+t*.4,rr=r+14+2*Math.sin(t*3+i);const x=Math.cos(a)*rr,y=Math.sin(a)*rr;if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);}ctx.stroke();
          if(SET.fx&&m>0&&m<.95&&Math.random()<.3){const a=rnd(0,TAU);part(e.x+Math.cos(a)*(r+14),e.y+Math.sin(a)*(r+14),Math.cos(a)*30,Math.sin(a)*30-20,.5,C90.sh,1.6);}ctx.globalAlpha=alpha;}
        const bw=r*2.4,k=clamp(e.hp/e.maxHp,0,1);ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(-bw/2,r+8,bw,4);ctx.fillStyle=C90.sh;ctx.fillRect(-bw/2,r+8,bw*k,4);}
      break;}
    case 'eye95':{if(icon){ctx.strokeStyle=col;ctx.beginPath();ctx.ellipse(0,0,r,r*.45,0,0,TAU);ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,r*.3,0,TAU);ctx.fill();break;}
      if(e.flash>0){ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(0,0,r*1.15,r*.6,0,0,TAU);ctx.stroke();}markDraw95(e,t);break;}
    case 'shade95':break;
    default:return false;}
  return true;}

// ===== 0.9.5: открытый мир IX–X — патрули, события, безопасные зоны, фон секторов =====
const W95={gen:false,art:[],deb:[],sites:{},pat:[],quiet:0,patCd:8,ev:null,evCd:45,kills:[],immCd:0,lostCd:120,boost:0,lastSec:-1,waves:[],loot:[],hold:null};
function secW95(){if(!G.world||!G.player||!WORLD.sectors[9])return -1;const s=sectorIdx(G.player.x,G.player.y);return s===8||s===9?s:-1;}
function w95S(){const S=G.save;if(!S||!S.story)return {};return S.story.w95||(S.story.w95={});}
function w95Gen(){if(W95.gen||!W90.gen||!WORLD.sectors[9])return;W95.gen=true;const N=WORLD.nodes,ex=[...WORLD.shops,WORLD.hangar,WORLD.arsenal].filter(Boolean);
  const okAt=(x,y,dn,dp)=>w58Far(x,y,N,dn)&&w58Far(x,y,W80.zones,dp)&&w58Far(x,y,W90.pods,dp)&&w58Far(x,y,ex,800)&&inSectors(x,y);
  // артерии сектора IX: длинные красные течения через сектор
  {const b=WORLD.sectors[8].box,R=mulberry(9501);for(let a=0;a<3;a++){const pts=[];let x=b[0]+200,y=b[1]+(b[3]-b[1])*(a+.5)/3,dir=0;for(let i=0;i<10;i++){pts.push({x,y});dir+=(R()-.5)*.9;x+=(b[2]-b[0]-400)/9;y=clamp(y+Math.sin(dir)*300,b[1]+200,b[3]-200);}W95.art.push(pts);}}
  // обломки памяти сектора X (их переписывают в мины)
  {const b=WORLD.sectors[9].box,R=mulberry(9601);for(let i=0;i<22;i++){const x=b[0]+300+R()*(b[2]-b[0]-600),y=b[1]+300+R()*(b[3]-b[1]-600);if(okAt(x,y,500,400))W95.deb.push({x,y,r:16+R()*14,alive:true,rot:R()*TAU});}}
  // постоянные места событий
  const st=(k,sec,seed)=>{const q=pt80(sec,seed,(x,y,k_)=>okAt(x,y,1100*k_,900*k_),600);W95.sites[k]={k,sec,x:q.x,y:q.y,st:'idle'};};
  st('gclot',8,9701);st('typoW',9,9711);st('sig',9,9721);
  {const s=W95.sites.sig;s.pts=[0,1,2].map(i=>{const a=i/3*TAU+.4;return {x:s.x+Math.cos(a)*520,y:s.y+Math.sin(a)*520,ch:0};});s.i=0;}}
// безопасные зоны: станции и порталы, r 380 — враги туда не входят
function safe95(x,y){for(const q of WORLD.shops)if(Math.hypot(x-q.x,y-q.y)<380)return q;if(WORLD.hangar&&Math.hypot(x-WORLD.hangar.x,y-WORLD.hangar.y)<380)return WORLD.hangar;if(WORLD.arsenal&&Math.hypot(x-WORLD.arsenal.x,y-WORLD.arsenal.y)<380)return WORLD.arsenal;
  for(const n of WORLD.nodes)if((n.sec===8||n.sec===9)&&Math.hypot(x-n.x,y-n.y)<380)return n;return null;}
function w95Hostile(e){return e.alive&&!EDEF[e.type].passive&&!STATIC.has(e.type)&&!e.peace&&e.dig===undefined&&!e.sbk;}
// --- тик мира ---
function w95WorldTick(dt){const p=G.player,S=G.save;if(!p||!S)return;
  if(G.wn90&&G.wn90.length)G.wn90=G.wn90.filter(n=>n.nodes.some(e=>e.alive&&Math.hypot(e.x-p.x,e.y-p.y)<3200));
  w95Gen();if(!W95.gen)return;const sec=secW95();
  if(W95.boost>0)W95.boost-=dt;G.wz95=(typeof zbZoom==='function'&&zbZoom())||(sec===8&&SET.fx&&!SET.lessFx?1+.006*beat90(G.t*1.1/1.2):1);
  tgTick95(dt);wvTick95(dt);glTick95(dt);inkTick95(dt);boomTick95(dt);tq95Tick(dt);ebTick95(dt);markTick95(dt);tongueBuild95();
  if(G.wpud95&&G.wpud95.length){for(const q of G.wpud95)q.t-=dt;G.wpud95=G.wpud95.filter(q=>q.t>0);if(p.dashT<=0)for(const q of G.wpud95)if(Math.hypot(p.x-q.x,p.y-q.y)<q.r){p.x=p.px+(p.x-p.px)*.6;p.y=p.py+(p.y-p.py)*.6;break;}}
  if(G.wtongue95&&G.wtongue95.length&&p.dashT<=0){for(const s of G.wtongue95)if(capD95(p.x,p.y,s.x1,s.y1,s.x2,s.y2,s.w)>0){drain90(6*dt);break;}}
  // безопасные зоны выталкивают врагов
  if(sec>=0)for(const e of G.enemies){if(!w95Hostile(e))continue;const z=safe95(e.x,e.y);if(z){const dx=e.x-z.x,dy=e.y-z.y,d=Math.hypot(dx,dy)||1;e.x=z.x+dx/d*382;e.y=z.y+dy/d*382;if(e.vx*dx+e.vy*dy<0){e.vx*=-.3;e.vy*=-.3;}}}
  if(sec!==W95.lastSec){W95.lastSec=sec;if(sec>=0){W95.quiet=0;W95.patCd=Math.max(W95.patCd,6);}}
  if(sec<0||G.state!=='world'||p.hp<=0||G.anom){w95PatTick(dt,-1);return;}
  // пауза без угрозы — не дольше 25 секунд
  let near=0,n1200=0;for(const e of G.enemies){if(!w95Hostile(e))continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<1200)n1200++;if(d<900)near=1;}
  const quietZ=!!safe95(p.x,p.y);if(near||quietZ)W95.quiet=0;else W95.quiet+=dt;W95.patCd-=dt;
  const minN=sec===8?5:4;if(!quietZ&&W95.patCd<=0&&(W95.quiet>25||n1200<minN-2)&&W95.pat.length<3){w95Patrol(sec);W95.patCd=20;W95.quiet=0;}
  // иммунный ответ: шесть убийств за 30 секунд
  W95.kills=W95.kills.filter(t=>G.t-t<30);if(W95.immCd>0)W95.immCd-=dt;if(sec===8&&W95.kills.length>=6&&W95.immCd<=0){W95.immCd=90;W95.kills=[];w95Immune();}
  w95PatTick(dt,sec);w95EvTick(dt,sec);w95Sites(dt,sec);w95LootTick(dt);}
function w95OffPt(minD){const p=G.player,b=WORLD.sectors[sectorIdx(p.x,p.y)].box;for(let i=0;i<40;i++){const a=rnd(0,TAU),d=(minD||Math.max(VW,VH)*.62+180)+rnd(0,200),x=p.x+Math.cos(a)*d,y=p.y+Math.sin(a)*d;if(x<b[0]+80||x>b[2]-80||y<b[1]+80||y>b[3]-80)continue;if(safe95(x,y)||safe95(x+200,y)||safe95(x-200,y))continue;return {x,y};}return null;}
function w95Sp(type,x,y,o){const e=spawnEnemy(type,x,y,Object.assign({noAffix:true,spawnT:.5},o||{}));return e;}
function w95Patrol(sec){const p=G.player;let kind;if(sec===8)kind='krov';else kind=W95.lostCd<=0&&!W95.pat.some(q=>q.kind==='lost')&&Math.random()<.35?'lost':'pravka';
  if(kind==='krov'){let best=null,bd=1e9,bi=0;for(const A of W95.art)for(let i=0;i<A.length;i++){const d=Math.hypot(A[i].x-p.x,A[i].y-p.y);if(d>700&&d<bd){bd=d;best=A;bi=i;}}if(!best||bd>2200){const q=w95OffPt();if(!q)return;best=null;var sx=q.x,sy=q.y;}else{sx=best[bi].x;sy=best[bi].y;}
    const P={kind,mem:[],art:best,ai:bi,dir:Math.random()<.5?1:-1,aggro:0,t:0};const L=w95Sp('hunt95',sx,sy,{packN95:2,idle95:1});L.pat95=P;huntInit95(L);for(const m of L.pack95.mem){m.idle95=1;m.pat95=P;P.mem.push(m);}
    const sp=w95Sp('spasm95',sx+40,sy+30,{idle95:1});P.mem.push(sp);for(const m of P.mem)m.pat95=P;W95.pat.push(P);}
  else if(kind==='pravka'){const q=w95OffPt();if(!q)return;const P={kind,mem:[],aggro:0,t:0,tgt:null};const s=w95Sp('scribe95',q.x,q.y,{idle95:1});P.mem.push(s);for(let i=0;i<2;i++)P.mem.push(w95Sp('blot95',q.x+rnd(-60,60),q.y+rnd(-60,60),{idle95:1}));for(const m of P.mem)m.pat95=P;W95.pat.push(P);}
  else{const q=w95OffPt(520);if(!q)return;W95.lostCd=150;const P={kind,mem:[],aggro:0,t:0,still:0};const e=w95Sp('lost95',q.x,q.y,{idle95:1});P.mem.push(e);e.pat95=P;W95.pat.push(P);radioLine('???',C95.lost,'…я держусь позади. Не останавливайся…',.6);}}
function w95Immune(){const q=w95OffPt(560);if(!q)return;banner('ИММУННЫЙ ОТВЕТ','КОВЧЕГ РЕАГИРУЕТ НА ВАС');snd95('event',q.x);const P={kind:'imm',mem:[],aggro:1,t:0};P.mem.push(w95Sp('guard95',q.x,q.y));for(let i=0;i<3;i++)P.mem.push(w95Sp('cell95',q.x+rnd(-80,80),q.y+rnd(-80,80)));for(const m of P.mem)m.pat95=P;W95.pat.push(P);}
function idle95(e,dt){const P=e.pat95,p=G.player;if(!P||P.aggro){e.idle95=0;return false;}
  if(P.kind==='krov'){const A=P.art;if(!A){P.aggro=1;return false;}const T=A[P.ai];if(!T){P.dir*=-1;P.ai=clamp(P.ai,0,A.length-1);return false;}const lead=P.mem[0]===e;if(lead&&Math.hypot(T.x-e.x,T.y-e.y)<60){P.ai+=P.dir;if(P.ai<0||P.ai>=A.length){P.dir*=-1;P.ai=clamp(P.ai,0,A.length-1);}}
    const L=P.mem[0]&&P.mem[0].alive?P.mem[0]:e,tx=lead?T.x:L.x+Math.cos(e.uid)*50,ty=lead?T.y:L.y+Math.sin(e.uid)*50;steer(e,tx-e.x,ty-e.y,e.spd*.5,dt,2);return true;}
  if(P.kind==='pravka'){const s=P.mem[0];if(e===s){if(!P.tgt||!P.tgt.alive){let bd=1e9;P.tgt=null;for(const d of W95.deb){if(!d.alive)continue;const q=Math.hypot(d.x-e.x,d.y-e.y);if(q<bd&&q<1600){bd=q;P.tgt=d;}}}const D=P.tgt;if(!D){P.aggro=1;return false;}
      const d=Math.hypot(D.x-e.x,D.y-e.y);if(d>50){steer(e,D.x-e.x,D.y-e.y,e.spd*.6,dt,2);P.wr=0;}else{e.vx*=.8;e.vy*=.8;P.wr=(P.wr||0)+dt;if(P.wr>=1.2){P.wr=0;D.alive=false;inkMine95(D.x,D.y);glyph95(D.x,D.y,8,C95.scribe);floater(D.x,D.y-24,'ОБЛОМОК ПЕРЕПИСАН · МИНА',C95.scribe);P.tgt=null;}}return true;}
    const L=s&&s.alive?s:e;steer(e,L.x+Math.cos(e.uid+G.t)*70-e.x,L.y+Math.sin(e.uid+G.t)*70-e.y,e.spd*.5,dt,2);return true;}
  if(P.kind==='lost'){const d=Math.hypot(p.x-e.x,p.y-e.y),a=Math.atan2(e.y-p.y,e.x-p.x);steer(e,p.x+Math.cos(a)*300-e.x,p.y+Math.sin(a)*300-e.y,e.spd*(d>420?1.2:.7),dt,2);e.face=Math.atan2(p.y-e.y,p.x-e.x);return true;}
  return false;}
function w95PatTick(dt,sec){const p=G.player;for(const P of W95.pat){P.t+=dt;P.mem=P.mem.filter(m=>m.alive);
    if(!P.mem.length){if(!P.gone&&P.kind==='krov'&&P.killed){W95.boost=8;p.en=Math.min(100,p.en+50);floater(p.x,p.y-44,'КРОВОТОК ЗАЧИЩЕН · ПУЛЬС · СКОРОСТЬ +15%',C90.ark);snd95('chest',p.x);}P.done=1;continue;}
    let far=true;for(const m of P.mem){const d=Math.hypot(m.x-p.x,m.y-p.y);if(d<2600)far=false;if(m.hp<m.maxHp-.5)P.killed=P.aggro=1;
      if(!P.aggro&&P.kind!=='lost'&&(d<300||P.kind==='krov'&&d<520&&P.art&&artNear95(P.art,p.x,p.y)<120)){P.aggro=1;floater(m.x,m.y-30,P.kind==='krov'?'КРОВОТОК · ЗАМЕТИЛИ':'ПРАВКА · ЗАМЕТИЛИ',EDEF[m.type].col);snd95('mark',m.x);}}
    if(P.kind==='lost'&&!P.aggro){const sp=Math.hypot(p.vx,p.vy);P.still=sp<30?P.still+dt:0;if(P.still>3){P.aggro=1;floater(P.mem[0].x,P.mem[0].y-30,'ОН АТАКУЕТ',C95.lost);}const z=safe95(p.x,p.y);if(z){for(const m of P.mem){m.alive=false;glyph95(m.x,m.y,10,C95.lost);}const nm=LOSTN95[Math.random()*LOSTN95.length|0];floater(p.x,p.y-44,'ЗАПИСЬ ПИЛОТА · '+nm,C95.lost);radioLine('ПИЛОТ '+nm,C95.lost,'«Вы довели меня до света. Я помню, как меня звали. Этого достаточно».',.4);if(G.save)G.save.lom+=50;snd95('secret',p.x);P.gone=1;}}
    if(P.aggro)for(const m of P.mem)m.idle95=0;
    if(far&&!P.aggro||sec<0&&far){for(const m of P.mem)m.alive=false;P.gone=1;P.done=1;}}
  W95.pat=W95.pat.filter(P=>!P.done);if(W95.lostCd>0)W95.lostCd-=dt;}
function artNear95(A,x,y){let d=1e9;for(let i=0;i<A.length-1;i++)d=Math.min(d,segDist(A[i].x,A[i].y,A[i+1].x,A[i+1].y,x,y));return d;}
// --- события мира: Аритмия и Отлив (ротация каждые 90 с), Тромбоз, Опечатка в мире, Последний сигнал (места) ---
function w95EvTick(dt,sec){const p=G.player;const E=W95.ev;
  if(!E){W95.evCd-=dt;if(W95.evCd<=0&&!safe95(p.x,p.y)){W95.evCd=90;if(sec===8)w95EvStart('arr');else w95EvStart('ebb');}}
  else{E.t-=dt;
    if(E.k==='arr'){E.wt-=dt;if(E.wt<=0){E.wt=1.6;W95.waves.push({x:E.x,y:E.y,r:30,v:520,R:1100,hit:false});snd90('beat',.8);trauma90(.08);}
      for(const e of G.enemies)if(w95Hostile(e)&&Math.hypot(e.x-p.x,e.y-p.y)<1400){e.buff=Math.max(e.buff,1.2);}
      if(E.t<=0){W95.ev=null;if(G.save)G.save.lom+=80;floater(p.x,p.y-44,'АРИТМИЯ ПЕРЕЖИТА · +80 ЛОМА',C90.ark);snd95('chest',p.x);saveWorld();}}
    if(E.k==='ebb'){if(E.t<=0&&!E.wash){E.wash={pos:-E.R-100};floater(E.x,E.y-E.R*.5,'ПРИЛИВ ВОЗВРАЩАЕТСЯ',C90.sh);snd90('tide');trauma90(.3);}
      if(E.wash){E.wash.pos+=300*dt;const bx=E.x+E.wash.pos;if(p.hp>0&&p.dashT<=0&&Math.abs(p.x-bx)<80&&Math.abs(p.y-E.y)<E.R){if(!E.hitP){E.hitP=1;damagePlayer(12);}p.x+=300*dt;}
        for(const q of W95.loot)if(q.ebb&&Math.abs(q.x-bx)<80){q.got=1;glyph95(q.x,q.y,6,C90.sh);}if(E.wash.pos>E.R+100){W95.ev=null;}}}}
  for(const w of W95.waves){const r0=w.r;w.r+=w.v*dt;if(!w.hit&&p.hp>0&&p.dashT<=0){const d=Math.hypot(p.x-w.x,p.y-w.y);if(d>r0-10&&d<w.r+10){w.hit=true;const a=Math.atan2(p.y-w.y,p.x-w.x);p.x+=Math.cos(a)*26;p.y+=Math.sin(a)*26;p.vx=(p.vx||0)+Math.cos(a)*240;p.vy=(p.vy||0)+Math.sin(a)*240;}}}
  W95.waves=W95.waves.filter(w=>w.r<w.R);}
function w95EvStart(k){const p=G.player;if(k==='arr'){W95.ev={k,t:40,wt:1,x:p.x+rnd(-300,300),y:p.y+rnd(-300,300)};banner('АРИТМИЯ','СЕКТОР ПУЛЬСИРУЕТ · ВРАГИ УСИЛЕНЫ · 40 С');snd95('event',p.x);}
  if(k==='ebb'){const a=Math.atan2(p.vy||0,p.vx||1),x=p.x+Math.cos(a)*500,y=p.y+Math.sin(a)*300;W95.ev={k,t:45,x,y,R:560};for(let i=0;i<3;i++){const q=rnd(0,TAU),d=rnd(120,420);W95.loot.push({k:'chest',x:x+Math.cos(q)*d,y:y+Math.sin(q)*d*.6,t:0,ebb:1});}banner('ОТЛИВ','ВОДА УШЛА · СУНДУКИ НА ДНЕ · 45 С');snd95('event',x);}}
function w95Sites(dt,sec){const p=G.player,D=w95S();for(const k in W95.sites){const s=W95.sites[k];if(D[k]===(G.save.cycle||1)){s.st='done';continue;}const d=Math.hypot(p.x-s.x,p.y-s.y);
    if(k==='gclot'){if(s.st==='idle'&&d<900){s.st='on';const e=spawnEnemy('gclot95',s.x,s.y,{noAffix:true,spawnT:1});e.site95=s;s.e=e;banner('ТРОМБОЗ','ВЕЛИКИЙ ТРОМБ ПЕРЕКРЫЛ КРОВОТОК');snd95('event',s.x);}if(s.st==='on'&&s.e&&!s.e.alive&&!s.e.dead95){s.st='idle';}if(s.st==='on'&&d>2600&&s.e&&s.e.alive){s.e.alive=false;s.st='idle';}}
    if(k==='typoW'){if(s.st==='idle'&&d<520){s.st='on';s.mem=[spawnEnemy('fixer100',s.x,s.y-60,{noAffix:true,spawnT:.8}),spawnEnemy('echo100',s.x-80,s.y+40,{noAffix:true,spawnT:.8}),spawnEnemy('echo100',s.x+80,s.y+40,{noAffix:true,spawnT:.8})];banner('ОПЕЧАТКА В МИРЕ','КУСОК ФОНА СТЁРТ · ВНУТРИ — ПРАВКА');snd95('event',s.x);}
      if(s.st==='on'){if(s.mem.every(e=>!e.alive)){s.st='done';D[k]=G.save.cycle||1;G.save.lom+=120;floater(s.x,s.y-50,'ЧЕРТЁЖ · +120 ЛОМА','#ffffff');snd95('secret',s.x);saveWorld();}else if(d>2400){for(const e of s.mem)e.alive=false;s.st='idle';}}}
    if(k==='sig'){if(s.st==='idle'&&d<640){s.st='on';s.i=0;for(const q of s.pts)q.ch=0;banner('ПОСЛЕДНИЙ СИГНАЛ','ДЕРЖИТЕСЬ В ТРЁХ ТОЧКАХ ПО 15 СЕКУНД');snd95('event',s.x);s.spT=3;}
      if(s.st==='on'){const q=s.pts[s.i];if(!q){s.st='done';D[k]=G.save.cycle||1;G.save.lom+=100;floater(s.x,s.y-60,'ОСКОЛОК ИСТОРИИ · +100 ЛОМА','#ffffff');radioLine('СИГНАЛ',C90.sh,'«…если кто-то держит этот маяк — значит, берег ещё помнят…»',.3);snd95('secret',s.x);saveWorld();continue;}
        if(Math.hypot(p.x-q.x,p.y-q.y)<150&&p.hp>0){q.ch+=dt;s.spT-=dt;if(s.spT<=0){s.spT=4.5;const o=w95OffPt(560);if(o)w95Sp(Math.random()<.5?'hollow100':'blot95',o.x,o.y);}if(q.ch>=15){s.i++;floater(q.x,q.y-40,'ТОЧКА '+s.i+'/3 УДЕРЖАНА',C90.sh);snd95('chime',q.x);}}else q.ch=Math.max(0,q.ch-dt*.5);
        if(d>2600){s.st='idle';}}}}}
function gclotDead95(e){const s=e.site95;if(!s)return;e.dead95=1;s.st='done';const D=w95S();D.gclot=G.save.cycle||1;G.save.lom+=150;const p=G.player;if(p)p.en=100;floater(e.x,e.y-50,'ЯДРО МОДУЛЯ · +150 ЛОМА','#ffd36b');snd95('secret',e.x);saveWorld();}
function w95LootTick(dt){const p=G.player;for(const q of W95.loot){q.t+=dt;if(p.hp>0&&Math.hypot(p.x-q.x,p.y-q.y)<36){q.got=1;if(G.save)G.save.lom+=60;floater(q.x,q.y-30,'СУНДУК · +60 ЛОМА','#ffb84d');snd95('chest',q.x);}}
  const L=G.wloot95;if(L)for(const q of L){if(p.hp>0&&Math.hypot(p.x-q.x,p.y-q.y)<36){q.got=1;if(G.save)G.save.lom+=40;floater(q.x,q.y-30,'ЖЕТОН · '+q.nm+' · +40 ЛОМА',C95.lost);snd95('secret',q.x);}}
  W95.loot=W95.loot.filter(q=>!q.got);if(L)G.wloot95=L.filter(q=>!q.got);}
// --- скорость после зачистки Кровотока ---
function boost95(p,dt){if(W95.boost>0&&G.world&&p.dashT<=0){p.x+=(p.x-p.px)*.15;p.y+=(p.y-p.py)*.15;}}
// --- фон секторов: параллакс (IX — сосуды, клетки, эритроциты; X — штриховка «недорисованного» мира) ---
const WBG95={};
function wbgTile95(k){if(WBG95[k])return WBG95[k];const c=document.createElement('canvas');c.width=c.height=512;const g=c.getContext('2d'),R=mulberry(k==='v'?11:k==='c'?22:k==='e'?33:44);
  // бесшовная плитка: всё, что пересекает край, дорисовывается с другой стороны
  const O=[-512,0,512],W9=f=>{for(const dx of O)for(const dy of O)f(dx,dy);};
  if(k==='v'){g.lineCap='butt';g.lineJoin='round';for(let i=0;i<5;i++){const lw=10+R()*18,x0=R()*512,d=[];for(let j=0;j<8;j++)d.push((R()-.5)*120);const m=d.reduce((s_,v)=>s_+v,0)/8;for(let j=0;j<8;j++)d[j]-=m;
      const pts=[];let x=x0-d[7];for(let j=-1;j<=9;j++){pts.push([x,j*64]);x+=d[((j%8)+8)%8];}
      for(const dx of O){g.beginPath();g.moveTo(pts[0][0]+dx,pts[0][1]);for(let j=1;j<pts.length;j++)g.lineTo(pts[j][0]+dx,pts[j][1]);g.strokeStyle='rgba(150,30,50,.20)';g.lineWidth=lw;g.stroke();g.lineWidth=2;g.strokeStyle='rgba(255,120,140,.10)';g.stroke();}}}
  if(k==='c'){for(let i=0;i<14;i++){const x=R()*512,y=R()*512,r=14+R()*26;W9((dx,dy)=>{if(x+dx+r<0||x+dx-r>512||y+dy+r<0||y+dy-r>512)return;g.strokeStyle='rgba(255,140,160,.12)';g.lineWidth=2;g.beginPath();g.arc(x+dx,y+dy,r,0,TAU);g.stroke();g.fillStyle='rgba(120,20,40,.10)';g.fill();g.fillStyle='rgba(255,160,170,.14)';g.beginPath();g.arc(x+dx+r*.2,y+dy-r*.15,r*.3,0,TAU);g.fill();});}}
  if(k==='e'){for(let i=0;i<22;i++){const x=R()*512,y=R()*512,r=5+R()*6,rot=R()*TAU;W9((dx,dy)=>{if(x+dx+r<0||x+dx-r>512||y+dy+r<0||y+dy-r>512)return;g.fillStyle='rgba(216,54,74,.30)';g.beginPath();g.ellipse(x+dx,y+dy,r,r*.7,rot,0,TAU);g.fill();g.fillStyle='rgba(60,6,14,.4)';g.beginPath();g.ellipse(x+dx,y+dy,r*.4,r*.28,0,0,TAU);g.fill();});}}
  if(k==='s'){g.strokeStyle='rgba(207,232,224,.06)';g.lineWidth=1;for(let i=0;i<70;i++){const x=R()*512,y=R()*512,l=20+R()*60,a=-.8+R()*.3;W9((dx,dy)=>{g.beginPath();g.moveTo(x+dx,y+dy);g.lineTo(x+dx+Math.cos(a)*l,y+dy+Math.sin(a)*l);g.stroke();});}
    g.font='700 12px "JetBrains Mono",monospace';for(let i=0;i<10;i++){const al=.04+R()*.05,ch=GLYPH95[(R()*GLYPH95.length)|0],x=R()*500,y=12+R()*494;g.fillStyle='rgba(122,255,201,'+al+')';g.fillText(ch,x,y);}}
  return WBG95[k]=c;}
function wbg95(t,k,sx,sy){const sec=secW95();if(sec<0||!SET.fx)return;const L=sec===8?[['v',.18,1],['c',.42,1],['e',.75,.9]]:[['s',.25,1],['s',.6,.6]];
  const nL=G.q===undefined?L.length:Math.min(L.length,1+G.q);for(const [id,par,a] of L.slice(0,nL)){const T=wbgTile95(id),ox=-((CX*par)%512+512)%512,oy=-((CY*par)%512+512)%512;ctx.globalAlpha=a*(G.lowFx?.6:1);for(let x=ox;x<W;x+=512)for(let y=oy;y<H;y+=512)ctx.drawImage(T,x,y);}ctx.globalAlpha=1;}
// --- рисунок мира ---
function w95Draw(t){if(!W95.gen)return;const p=G.player,sec=secW95();
  // артерии
  if(sec===8||W95.art.some(A=>A.some(q=>inView(q.x,q.y,400)))){ctx.lineCap='round';for(const A of W95.art){if(!A.some(q=>inView(q.x,q.y,500)))continue;ctx.strokeStyle=rgba90(C90.red,.12);ctx.lineWidth=70;ctx.beginPath();ctx.moveTo(A[0].x,A[0].y);for(let i=1;i<A.length;i++)ctx.lineTo(A[i].x,A[i].y);ctx.stroke();
    ctx.setLineDash([16,26]);ctx.lineDashOffset=-t*90;ctx.strokeStyle=rgba90(C90.blood,.45);ctx.lineWidth=3;ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;}ctx.lineCap='butt';}
  // обломки памяти
  for(const d of W95.deb){if(!d.alive||!inView(d.x,d.y,60))continue;ctx.save();ctx.translate(d.x,d.y);ctx.rotate(d.rot+t*.1);ctx.strokeStyle=rgba90(C90.sh,.5);ctx.fillStyle='rgba(8,16,14,.8)';ctx.lineWidth=1.5;ctx.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU,r=d.r*(.7+.3*((i*3)%4)/3);if(i)ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r);else ctx.moveTo(Math.cos(a)*r,Math.sin(a)*r);}ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
  // пятна чернил, лужи, языки
  if(G.wpud95)for(const q of G.wpud95){if(!inView(q.x,q.y,q.r))continue;const a=Math.min(1,q.t,(q.t0-q.t)*3);rgDraw95(q.x,q.y,q.r,'#5a0a16',.75*a,0,[.8,.5*a]);}
  if(G.wtongue95)for(const s of G.wtongue95)tongueDraw95(s,t);
  if(G.wink95)for(const m of G.wink95)inkDraw95(m,t);
  // безопасные зоны — тонкие кольца
  if(sec>=0){const zs=[...WORLD.shops,WORLD.hangar,WORLD.arsenal,...WORLD.nodes.filter(n=>n.sec===sec)].filter(Boolean);ctx.setLineDash([4,12]);ctx.lineWidth=1.2;for(const z of zs){if(!inView(z.x,z.y,400))continue;ctx.strokeStyle=rgba90(sec===8?C90.warm:C90.sh,.22);ctx.beginPath();ctx.arc(z.x,z.y,380,0,TAU);ctx.stroke();}ctx.setLineDash([]);}
  // волны Аритмии
  for(const w of W95.waves){ctx.strokeStyle=rgba90(C90.blood,.4*(1-w.r/w.R));ctx.lineWidth=6;ctx.beginPath();ctx.arc(w.x,w.y,w.r,0,TAU);ctx.stroke();}
  // Отлив: дно с сундуками и возвращающаяся вода
  const E=W95.ev;if(E&&E.k==='ebb'&&inView(E.x,E.y,E.R+80)){ctx.fillStyle='rgba(122,255,201,.05)';ctx.beginPath();ctx.ellipse(E.x,E.y,E.R,E.R*.62,0,0,TAU);ctx.fill();ctx.strokeStyle=rgba90(C90.sh,.35);ctx.setLineDash([6,8]);ctx.stroke();ctx.setLineDash([]);
    for(let i=0;i<5;i++){ctx.strokeStyle=rgba90(C90.sh,.08);ctx.beginPath();ctx.ellipse(E.x,E.y+i*30-60,E.R*(.9-i*.12),E.R*.08,0,0,TAU);ctx.stroke();}
    if(!E.wash)worldLabel(E.x,E.y-E.R*.62-14,'ОТЛИВ · '+Math.ceil(E.t),C90.sh);else{const bx=E.x+E.wash.pos;ctx.fillStyle='rgba(3,6,7,.9)';ctx.fillRect(bx-80,E.y-E.R*.62,160,E.R*1.24);ctx.strokeStyle=C90.sh;ctx.strokeRect(bx-80,E.y-E.R*.62,160,E.R*1.24);}}
  for(const q of W95.loot){if(!inView(q.x,q.y,40))continue;const b=Math.sin(q.t*4)*3;glow(q.x,q.y,36,'#ffb84d',.4);ctx.save();ctx.translate(q.x,q.y+b);ctx.fillStyle='#2a1a06';ctx.strokeStyle='#ffb84d';ctx.lineWidth=2;ctx.fillRect(-12,-8,24,16);ctx.strokeRect(-12,-8,24,16);ctx.restore();}
  if(G.wloot95)for(const q of G.wloot95){if(!inView(q.x,q.y,40))continue;glow(q.x,q.y,30,C95.lost,.4);worldLabel(q.x,q.y-20,'ЖЕТОН',C95.lost);ctx.strokeStyle=C95.lost;ctx.strokeRect(q.x-7,q.y-10,14,20);}
  // места событий
  for(const k in W95.sites){const s=W95.sites[k];if(!inView(s.x,s.y,700))continue;
    if(k==='gclot'&&s.st!=='done'){ctx.strokeStyle=rgba90(C90.red,.3);ctx.lineWidth=40;ctx.beginPath();ctx.arc(s.x,s.y,260,0,TAU);ctx.stroke();if(s.st==='idle')worldLabel(s.x,s.y-290,'ТРОМБОЗ · КРОВОТОК ПЕРЕКРЫТ',C90.red);}
    if(k==='typoW'&&s.st!=='done'&&inView(s.x,s.y,480)){ctx.save();ctx.fillStyle='rgba(2,5,6,.86)';const BP=new Path2D();for(let i=0;i<=24;i++){const a=i/24*TAU,r=420+18*Math.sin(a*5+t);if(i)BP.lineTo(s.x+Math.cos(a)*r,s.y+Math.sin(a)*r);else BP.moveTo(s.x+Math.cos(a)*r,s.y+Math.sin(a)*r);}BP.closePath();ctx.fill(BP);
      // внутри — чистый лист: линовка и призрачные буквы, которые проступают и тают
      ctx.save();ctx.clip(BP);ctx.strokeStyle=rgba90(C90.sh,.06);ctx.lineWidth=1;ctx.beginPath();for(let y=s.y-440+((t*6)%36);y<s.y+440;y+=36){ctx.moveTo(s.x-440,y);ctx.lineTo(s.x+440,y);}ctx.stroke();ctx.strokeStyle=rgba90('#ff6f86',.08);ctx.beginPath();ctx.moveTo(s.x-330,s.y-440);ctx.lineTo(s.x-330,s.y+440);ctx.stroke();
      for(let i=0;i<14;i++){const u=(t*.12+i*.071)%1,gx=s.x-360+((i*137)%720),gy=s.y-360+((i*251)%720);ctx.globalAlpha=Math.sin(u*Math.PI)*.35;glyphDraw95(GLYPH95[(i*7+Math.floor(t*.3))%GLYPH95.length],gx,gy,15,C90.sh,false,0);}ctx.globalAlpha=1;ctx.restore();
      ctx.setLineDash([10,8]);ctx.lineDashOffset=-t*24;ctx.strokeStyle=rgba90(C90.sh,.75);ctx.lineWidth=1.6;ctx.stroke(BP);ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.restore();worldLabel(s.x,s.y-440,'ОПЕЧАТКА В МИРЕ',C90.sh);}
    if(k==='sig'&&s.st!=='done'){ctx.save();ctx.translate(s.x,s.y);glow(0,0,90,C90.sh,.35+.15*Math.sin(t*2));ctx.strokeStyle=C90.sh;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-14,26);ctx.lineTo(-7,-18);ctx.lineTo(7,-18);ctx.lineTo(14,26);ctx.closePath();ctx.stroke();ctx.restore();worldLabel(s.x,s.y-40,'ПОСЛЕДНИЙ СИГНАЛ',C90.sh);
      s.pts.forEach((q,i)=>{const on=s.st==='on'&&s.i===i,done=s.st==='on'&&i<s.i;ctx.strokeStyle=done?'#ffffff':on?C90.sh:rgba90(C90.sh,.3);ctx.lineWidth=on?2.5:1.5;ctx.setLineDash(on?[]:[4,8]);ctx.beginPath();ctx.arc(q.x,q.y,150,0,TAU);ctx.stroke();ctx.setLineDash([]);if(on){ctx.strokeStyle='#ffffff';ctx.lineWidth=4;ctx.beginPath();ctx.arc(q.x,q.y,156,-Math.PI/2,-Math.PI/2+TAU*q.ch/15);ctx.stroke();worldLabel(q.x,q.y-160,'ДЕРЖИТЕСЬ · '+Math.ceil(15-q.ch),'#ffffff');}});}}
  tgDraw95(t);wvDraw95(t);glDraw95();if(typeof enemyOver95==='function')enemyOver95(t);markPlayerDraw95(t);
  for(const e of G.enemies){if(!e.alive||!e.pat95||!inView(e.x,e.y,40))continue;if(e.pat95.kind==='pravka'&&e.type==='scribe95'&&e.pat95.wr>0&&e.pat95.tgt){const D=e.pat95.tgt;ctx.font='700 11px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle=C95.scribe;for(let i=0;i<6;i++){const a=i/6*TAU+t*3,r=40*(1-e.pat95.wr/1.2);ctx.fillText(GLYPH95[(i*5+Math.floor(t*8))%GLYPH95.length],D.x+Math.cos(a)*r,D.y+Math.sin(a)*r);}ctx.textAlign='left';}}
  if(sec===8&&SET.fx&&!SET.lessFx){const k=beat90(G.t*1.1/1.2);if(k>.12)vig95('#d8364a',.1*k,.5);}
  if(sec===9&&SET.fx&&!G.lowFx){ctx.save();ctx.setTransform(DPR*SC,0,0,DPR*SC,0,0);ctx.font='700 12px "JetBrains Mono",monospace';for(let i=0;i<8;i++){const u=((t*.07+i*.137)%1),side=i%4,x=side<2?(side?VW-14:14):u*VW,y=side<2?u*VH:(side===2?16:VH-10);ctx.globalAlpha=.12*(1-Math.abs(u-.5)*2);ctx.fillStyle=C90.sh;ctx.fillText(GLYPH95[(i*9+Math.floor(t*.5))%GLYPH95.length],x,y);}ctx.restore();ctx.globalAlpha=1;}}
function tongueDraw95(s,t){ctx.lineCap='round';ctx.strokeStyle='rgba(3,6,7,.92)';ctx.lineWidth=s.w;ctx.beginPath();ctx.moveTo(s.x1,s.y1);ctx.lineTo(s.x2,s.y2);ctx.stroke();ctx.strokeStyle=rgba90(C95.ebb,.6);ctx.lineWidth=1.5;ctx.setLineDash([4,6]);ctx.lineDashOffset=-t*30;ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.lineCap='butt';}
function inkDraw95(m,t){const a=m.arm>0?.5:1;ctx.globalAlpha=a;ctx.fillStyle=C95.ink;ctx.strokeStyle=C90.sh;ctx.lineWidth=1.5;ctx.beginPath();for(let i=0;i<=10;i++){const q=i/10*TAU,r=11*(1+.25*Math.sin(q*3+m.x));if(i)ctx.lineTo(m.x+Math.cos(q)*r,m.y+Math.sin(q)*r);else ctx.moveTo(m.x+Math.cos(q)*r,m.y+Math.sin(q)*r);}ctx.closePath();ctx.fill();ctx.stroke();
  if(m.arm<=0){ctx.fillStyle=Math.sin(t*6+m.x)>0?'#ffffff':C90.sh;ctx.beginPath();ctx.arc(m.x,m.y,2.5,0,TAU);ctx.fill();ctx.globalAlpha=.12;ctx.beginPath();ctx.arc(m.x,m.y,64,0,TAU);ctx.stroke();}ctx.globalAlpha=1;}
// --- мини-карта: патрули ромбом, события пульсирующим кругом, безопасные зоны тонким кольцом ---
function mini95(g,P,s){if(!W95.gen||secW95()<0)return;const k=s/2/2600;
  for(const Pt of W95.pat){const m=Pt.mem.find(o=>o.alive);if(!m)continue;const [x,y]=P(m.x,m.y);g.save();g.translate(x,y);g.rotate(Math.PI/4);g.strokeStyle=Pt.aggro?'#ff4f6e':'#ffb0b8';g.lineWidth=1.5;g.strokeRect(-3.5,-3.5,7,7);g.restore();}
  const ev=[];if(W95.ev)ev.push(W95.ev);for(const kk in W95.sites){const q=W95.sites[kk];if(q.st!=='done')ev.push(q);}for(const q of ev){const [x,y]=P(q.x,q.y);if(x<-10||x>s+10||y<-10||y>s+10)continue;g.strokeStyle='#ffffff';g.globalAlpha=.5+.4*Math.sin(G.t*4);g.lineWidth=1.5;g.beginPath();g.arc(x,y,5+2*Math.sin(G.t*4),0,TAU);g.stroke();g.globalAlpha=1;}
  g.lineWidth=1;g.strokeStyle='rgba(255,255,255,.25)';for(const z of [...WORLD.shops,WORLD.hangar,WORLD.arsenal].filter(Boolean)){const [x,y]=P(z.x,z.y);g.beginPath();g.arc(x,y,380*k,0,TAU);g.stroke();}}

// ===== 0.9.5: связка — тик, рисунок, хуки миссии и мира =====
wavesPlan95();
function t95Init(M,X){G.mark95=null;G.slow95=null;G.slowP95=0;G.fq95=null;G.ol95=0;G.wtg95=[];if(!X)return;Object.assign(X,{tlog95:X.tlog95||{},tg95:[],wv95:[],gl95:[],loot95:[],ink95:[],tongue95:[],strip95:[]});
  if(G.mode==='endless'||!M||!M.gen||(X.sec!==8&&X.sec!==9))return;lv95Init(M,X);}
function t95Tick(dt){const X=G.x90;if(!X||!on95())return;
  tgTick95(dt);wvTick95(dt);markTick95(dt);ebTick95(dt);fqTick95();glTick95(dt);inkTick95(dt);boomTick95(dt);tq95Tick(dt);if(X.sec===9)tongueBuild95();
  lv95Tick(X,dt);
  for(const e of G.enemies)if(e.alive&&e.weak95>0&&!S90T.has(e.type))e.weak95-=dt;
  // лужи: пузыри и след корабля
  if(X.pud.length&&SET.fx){const p=G.player;for(const q of X.pud){if(vR3()<dt*2)q.bub=(q.bub||[]).concat([{a:vrnd3(0,TAU),d:vrnd3(0,q.r*.8),t:0}]).slice(-6);if(q.bub)for(const b of q.bub)b.t+=dt;}
    if(p&&p.dashT<=0&&Math.hypot(p.x-p.px,p.y-p.py)>.5&&inPud90(p.x,p.y)&&vR3()<.5)part(p.x,p.y,-(p.x-p.px)*10,-(p.y-p.py)*10,.6,'#5a0a16',3);}}
function under95(t){const X=G.x90;if(!X||!on95())return;lvUnder95(X,t);
  if(X.estr95)for(const s of X.estr95){const a=s.tele>0?.4:Math.min(1,s.t*2);ctx.globalAlpha=a;ctx.lineCap='round';ctx.strokeStyle='rgba(3,6,7,.92)';ctx.lineWidth=s.w;ctx.beginPath();ctx.moveTo(s.x1,s.y1);ctx.lineTo(s.x2,s.y2);ctx.stroke();ctx.strokeStyle=rgba90(C90.sh,.7);ctx.lineWidth=1.5;ctx.setLineDash([6,6]);ctx.lineDashOffset=-t*20;ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.lineCap='butt';ctx.globalAlpha=1;}
  if(X.tongue95)for(const s of X.tongue95)tongueDraw95(s,t);
  if(X.ink95)for(const m of X.ink95)inkDraw95(m,t);
  wvDraw95(t);}
function draw95(t){const X=G.x90;if(!X||!on95())return;lvDraw95(X,t);signDraw95();tgDraw95(t);enemyOver95(t);glDraw95();markPlayerDraw95(t);ob96Draw(t);fin96Draw(t);}
function top95(t){const X=G.x90;if(!X||!on95())return;lvTop95(X,t);edgeArrows95(t);eliteBar95(t);}
function drift95(p,dt){slowP95(p,dt);if(G.world){boost95(p,dt);return;}const X=G.x90;if(!X||!on95())return;tun95(p,X);pushOut95(p,0);p.safe95={x:p.x,y:p.y};}
// сквозь строку-стену и колонну не проскочить ни рывком, ни толчком: откат на безопасную сторону
function tun95(p,X){const s=p.safe95;if(!s||!X.pil95||Math.hypot(p.x-s.x,p.y-s.y)>140)return;
  for(const w of X.walls95){if(!segInter(s.x,s.y,p.x,p.y,w.x1,w.y1,w.x2,w.y2))continue;const L=Math.hypot(w.x2-w.x1,w.y2-w.y1)||1,nx=-(w.y2-w.y1)/L,ny=(w.x2-w.x1)/L,side=Math.sign((s.x-w.x1)*nx+(s.y-w.y1)*ny)||1,dp=(p.x-w.x1)*nx+(p.y-w.y1)*ny,m=w.w/2+p.r*.85+1;p.x+=nx*(side*m-dp);p.y+=ny*(side*m-dp);const vn=p.vx*nx+p.vy*ny;if(vn*side<0){p.vx-=vn*nx;p.vy-=vn*ny;}}
  for(const q of X.pil95){if(!q.alive)continue;if(Math.hypot(s.x-q.x,s.y-q.y)<q.r)continue;if(segDist(s.x,s.y,p.x,p.y,q.x,q.y)<q.r*.9&&Math.hypot(p.x-q.x,p.y-q.y)<q.r+p.r){const a=Math.atan2(s.y-q.y,s.x-q.x),m=q.r+p.r*.85+1;p.x=q.x+Math.cos(a)*m;p.y=q.y+Math.sin(a)*m;}}}
function b95Hit(b){if(shoot95(b))return true;if(guardHit95(b))return true;const X=G.x90;if(!X||!on95())return false;if(pilBullet95(b,true))return true;return false;}
function pulse95(p,R){scribeErase95(p,R);const X=G.x90;
  for(const e of G.enemies){if(!e.alive)continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(e.type==='pass90'&&d<R*2.2){e.pull95=3;floater(e.x,e.y-24,'КО МНЕ',C90.pil);}
    if(e.type==='hunt95'&&d<R+e.r&&e.pack95&&e.pack95.st==='aim'){e.pack95.st='rest';e.pack95.t=0;floater(e.x,e.y-20,'СТАЯ СБИТА',C95.hunt);}}
  for(const L of [X&&inMission()?X.ink95:G.wink95]){if(!L)continue;for(const m of L)if(Math.hypot(m.x-p.x,m.y-p.y)<R){m.t=0;glyph95(m.x,m.y,3,C90.sh);}}}
// --- оверлеи врагов: ✦ уязвимое окно, ⬡ неуязвимость, треугольник стаи, маршрут Смотрителя, счётчик Фагоцита ---
function enemyOver95(t){const p=G.player;
  for(const e of G.enemies){if(!e.alive||e.spawnT>0)continue;if(G.world&&!inView(e.x,e.y,60))continue;
    if((e.weak95>0||e.inv95>0)&&e.type!=='eye95'){ctx.save();ctx.translate(e.x,e.y-(e.hz95||0));markDraw95(e,t);ctx.restore();}
    if(e.type==='hunt95'&&e.lead95&&e.pack95){const P=e.pack95,live=P.mem.filter(m=>m.alive&&m.spawnT<=0);if(live.length>=2&&(P.st==='tri'||P.st==='aim')){const k=P.st==='aim'?clamp(P.t/P.T,0,1):0;ctx.strokeStyle=rgba90(P.st==='aim'?C95.dash:C95.hunt,P.st==='aim'?.5+.5*k:.25);ctx.lineWidth=P.st==='aim'?1.5+2.5*k:1;ctx.setLineDash(P.st==='aim'?[]:[4,8]);
        ctx.beginPath();for(let i=0;i<live.length;i++){const a=live[i],b=live[(i+1)%live.length];const u=P.st==='aim'?k:1;ctx.moveTo(a.x,a.y);ctx.lineTo(a.x+(b.x-a.x)*u,a.y+(b.y-a.y)*u);}ctx.stroke();ctx.setLineDash([]);
        if(P.st==='aim'){ctx.fillStyle=rgba90(C95.dash,.12*k);ctx.beginPath();ctx.moveTo(live[0].x,live[0].y);for(const m of live)ctx.lineTo(m.x,m.y);ctx.closePath();ctx.fill();for(const m of live){const a=Math.atan2(P.ty-m.y,P.tx-m.x);arrow95(m.x+Math.cos(a)*(m.r+8),m.y+Math.sin(a)*(m.r+8),a,C95.dash,k);}}}}
    if(e.type==='hunt95'&&e.hq95>0)arrow95(e.x+Math.cos(e.ha95)*(e.r+8),e.y+Math.sin(e.ha95)*(e.r+8),e.ha95,C95.dash,1-e.hq95/.6);
    if(e.type==='lost95'&&e.dsh95&&e.dsh95.st==='aim')arrow95(e.x+Math.cos(e.dsh95.a)*24,e.y+Math.sin(e.dsh95.a)*24,e.dsh95.a,C95.dash,1-e.dsh95.t/.45);
    if(e.type==='lost95'&&e.pls95){const k=1-e.pls95.t/.6;ctx.strokeStyle=rgba90(C95.lost,.4+.5*k);ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,170-150*k,0,TAU);ctx.stroke();}
    if(e.type==='lost95'&&e.chg95){const k=1-e.chg95.t/1.2;ctx.strokeStyle=rgba90('#ffffff',.5+.5*k);ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,22,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();ctx.setLineDash([6,6]);ctx.strokeStyle=rgba90('#ffffff',.35*k);ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.x+Math.cos(e.chg95.a)*700,e.y+Math.sin(e.chg95.a)*700);ctx.stroke();ctx.setLineDash([]);}
    if(e.type==='keeper90'&&e.st==='patrol'&&e.rt95&&!G.world){ctx.strokeStyle=rgba90('#ffe9b0',.16);ctx.setLineDash([3,9]);ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(e.rt95[0].x,e.rt95[0].y);for(let i=1;i<=3;i++){const q=e.rt95[i%3];ctx.lineTo(q.x,q.y);}ctx.stroke();ctx.setLineDash([]);for(const q of e.rt95){ctx.fillStyle=rgba90('#ffe9b0',.25);ctx.fillRect(q.x-2,q.y-2,4,4);}}
    if(e.type==='keeper90'&&e.fa!==undefined){ctx.strokeStyle=rgba90('#ffe9b0',.45);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(e.x,e.y,e.r+9,e.fa+Math.PI-1.2,e.fa+Math.PI+1.2);ctx.stroke();}
    if(e.type==='phago90'&&(e.fed||0)>0)worldLabel(e.x,e.y-e.r-12,(e.fed||0)+'/10',mix90('#ffd36b','#ff4f6e',(e.fed||0)/10));
    if(e.type==='witness100'&&!e.arrived){const bw=34,k=clamp(e.hp/e.maxHp,0,1);ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(e.x-bw/2,e.y-e.r-24,bw,4);ctx.fillStyle='#ffffff';ctx.fillRect(e.x-bw/2,e.y-e.r-24,bw*k,4);
      const a=e.ex>W/2?0:Math.PI;arrow95(e.x+Math.cos(a)*(e.r+16),e.y,a,'#ffffff',.6+.4*Math.sin(t*4));if(e.lead95>0){ctx.strokeStyle=rgba90('#ffffff',.35*e.lead95);ctx.setLineDash([3,5]);ctx.beginPath();ctx.arc(e.x,e.y,120,0,TAU);ctx.stroke();ctx.setLineDash([]);}}
    if(e.type==='spasm95'&&e.att95){ctx.strokeStyle=rgba90(C95.spasm,.45);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(e.x,e.y,e.r+10,(e.fa95||0)+Math.PI-.9,(e.fa95||0)+Math.PI+.9);ctx.stroke();}
    if(e.type==='embryo90'&&e.hatch>0&&e.hatch<5)worldLabel(e.x,e.y-e.r-14,fmt85(e.hatch),'#ff9fb0');}
  // импульсы по лучам нейросети
  const N=nets90();if(N&&N.length)for(const n of N){if(n.chg95&&n.chg95.alive){const s=n.chg95,k=clamp(1-n.impT/.5,0,1);glow(s.x,s.y,30+20*k,'#ffe47a',.5*k);}
    if(n.imp)for(const f of n.imp.front){const u=clamp(f.u,0,1),x=f.from.x+(f.to.x-f.from.x)*u,y=f.from.y+(f.to.y-f.from.y)*u;glow(x,y,26,'#ffe47a',.9);ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(x,y,4,0,TAU);ctx.fill();ctx.strokeStyle=rgba90('#fff6c4',.7);ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(f.from.x,f.from.y);ctx.lineTo(x,y);ctx.stroke();}}}
function arrow95(x,y,a,col,k){ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.globalAlpha=.5+.5*clamp(k,0,1);ctx.fillStyle=col;ctx.strokeStyle='#04060c';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(10+6*k,0);ctx.lineTo(-4,-7);ctx.lineTo(0,0);ctx.lineTo(-4,7);ctx.closePath();ctx.stroke();ctx.fill();ctx.restore();}
// --- рисунок новых врагов ---
function drawE95(e,t,icon,col,face,alpha,P){const r=e.r;if(drawBoss95(e,t,icon,col,face,alpha))return true;
  const hz=icon?0:(e.hz95||0);if(hz>0){ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(0,0,r*1.1,r*.5,0,0,TAU);ctx.fill();ctx.translate(0,-hz);ctx.fillStyle='#0a0f1c';}
  const sq=!icon&&e.tl95>0?.82:1;
  switch(e.type){
    case 'hunt95':{ctx.scale(sq,2-sq);ctx.beginPath();for(let i=0;i<=16;i++){const a=i/16*TAU,rr=r*(1+.1*Math.sin(a*4+t*4+e.seed));if(i)ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fillStyle='#1e1418';ctx.fill();ctx.stroke();
      ctx.fillStyle=rgba90('#ff9fb0',.75);for(let i=0;i<3;i++){const a=i*2.1+e.seed+t*.6;ctx.beginPath();ctx.arc(Math.cos(a)*r*.35,Math.sin(a)*r*.35,r*.24,0,TAU);ctx.fill();}
      if(e.lead95||icon){ctx.strokeStyle='#ffffff';ctx.lineWidth=1.5;ctx.beginPath();for(let i=-1;i<=1;i++){ctx.moveTo(i*r*.35-3,-r-1);ctx.lineTo(i*r*.35,-r-8-(i?0:3));ctx.lineTo(i*r*.35+3,-r-1);}ctx.stroke();}break;}
    case 'spasm95':{const pu=icon?.5:e.pul95||0;ctx.rotate(icon?0:(e.fa95||0));ctx.scale(1+.2*pu,1-.12*pu);ctx.beginPath();for(let i=0;i<=20;i++){const a=i/20*TAU,rr=r*(1+.18*Math.sin(a*5+t*6));if(i)ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fillStyle='#2a080e';ctx.fill();ctx.stroke();
      ctx.strokeStyle=rgba90('#ff8a9a',.6);ctx.lineWidth=2;for(let i=0;i<4;i++){const a=i/4*TAU+t;ctx.beginPath();ctx.moveTo(Math.cos(a)*r*.3,Math.sin(a)*r*.3);ctx.lineTo(Math.cos(a+.6)*r*.85,Math.sin(a+.6)*r*.85);ctx.stroke();}
      if(pu>0&&!icon){ctx.strokeStyle=rgba90('#ffffff',pu);ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,r+6,0,TAU);ctx.stroke();}break;}
    case 'cell95':{const inf=!icon&&e.inf95!==undefined;ctx.fillStyle=inf&&Math.sin(t*40)>0?'#ffffff':col;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.strokeStyle='#04060c';ctx.lineWidth=1.5;ctx.stroke();ctx.fillStyle=rgba90('#5a0a16',.7);ctx.beginPath();ctx.arc(0,0,r*.45,0,TAU);ctx.fill();
      ctx.fillStyle=rgba90('#ffffff',.5);ctx.beginPath();ctx.arc(-r*.35,-r*.35,r*.22,0,TAU);ctx.fill();break;}
    case 'guard95':{ctx.rotate(icon?0:(e.fa95||0));poly(6,r,0);ctx.fillStyle='#1a1408';ctx.fill();ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,r*.3,0,TAU);ctx.fill();
      const br=!icon&&e.mb95>0;ctx.strokeStyle=br?'#6b5a3a':e.shieldFlash>0?'#ffffff':C95.guard;ctx.lineWidth=br?2:6;if(br)ctx.setLineDash([3,5]);ctx.beginPath();ctx.arc(0,0,r+8,-Math.PI/3,Math.PI/3);ctx.stroke();ctx.setLineDash([]);ctx.lineWidth=1;ctx.strokeStyle=rgba90('#ffffff',.5);ctx.beginPath();ctx.arc(0,0,r+12,-Math.PI/3,Math.PI/3);ctx.stroke();ctx.lineWidth=2;break;}
    case 'blot95':{ctx.fillStyle=C95.ink;ctx.beginPath();for(let i=0;i<=14;i++){const a=i/14*TAU,rr=r*(1+.22*Math.sin(a*3+e.seed)+.1*Math.sin(a*7+t*3));if(i)ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.strokeStyle=col;ctx.stroke();
      ctx.fillStyle=col;for(let i=0;i<2;i++){ctx.beginPath();ctx.arc((i?1:-1)*r*.3,-r*.15,2.2,0,TAU);ctx.fill();}if(!icon&&e.bs95==='air'){ctx.strokeStyle='#ffffff';ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,r+4,0,TAU);ctx.stroke();}break;}
    case 'scribe95':{ctx.rotate(icon?-Math.PI/2:Math.atan2(P.y-e.y,P.x-e.x));ctx.beginPath();ctx.moveTo(r*1.2,0);ctx.lineTo(-r*.4,-r*.55);ctx.lineTo(-r*.9,0);ctx.lineTo(-r*.4,r*.55);ctx.closePath();ctx.fillStyle='#0c1814';ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(r*1.2,0);ctx.lineTo(-r*.6,0);ctx.stroke();
      if(!icon){ctx.font='700 9px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle=rgba90(col,.7);for(let i=0;i<3;i++){const a=t*2+i*2.1;ctx.fillText(GLYPH95[(i*11+Math.floor(t*3))%GLYPH95.length],Math.cos(a)*(r+10),Math.sin(a)*(r+10)+3);}ctx.textAlign='left';}break;}
    case 'ebb95':{ctx.rotate(icon?0:Math.atan2(P.y-e.y,P.x-e.x));ctx.beginPath();ctx.arc(0,0,r,-.9*Math.PI,.9*Math.PI);ctx.quadraticCurveTo(-r*.2,0,Math.cos(-.9*Math.PI)*r,Math.sin(-.9*Math.PI)*r);ctx.fillStyle='#04100c';ctx.fill();ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(r*.4,0,3,0,TAU);ctx.fill();
      if(!icon&&SET.fx&&Math.random()<.2)part(e.x,e.y,rnd(-20,20),40,.5,C95.ebb,1.6);break;}
    case 'lost95':{ctx.rotate(icon?-Math.PI/2:(e.face||face));ctx.globalAlpha=alpha*.92;drawShip(e.skin95&&SKINS[e.skin95]?e.skin95:'base',t,Math.hypot(e.vx,e.vy),{});ctx.globalAlpha=alpha;ctx.strokeStyle=e.flash>0?'#ffffff':'#ff4f6e';ctx.lineWidth=1.5;ctx.setLineDash([5,4]);ctx.beginPath();ctx.arc(0,0,24,0,TAU);ctx.stroke();ctx.setLineDash([]);
      if(!icon&&e.inv95>0){ctx.globalAlpha=alpha*.5;ctx.strokeStyle='#8fe9ff';ctx.beginPath();ctx.arc(0,0,20,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}break;}
    case 'gclot95':{ctx.fillStyle='#3a0a12';ctx.beginPath();for(let i=0;i<=24;i++){const a=i/24*TAU,rr=r*(1+.12*Math.sin(a*3+t*2+e.seed)+.08*Math.sin(a*7-t*3));if(i)ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);else ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.lineWidth=3;ctx.stroke();
      ctx.strokeStyle=rgba90('#ff6f86',.5);ctx.lineWidth=2;for(let i=0;i<5;i++){const a=i*1.26+e.seed;ctx.beginPath();ctx.moveTo(0,0);ctx.quadraticCurveTo(Math.cos(a+.5)*r*.5,Math.sin(a+.5)*r*.5,Math.cos(a)*r*.9,Math.sin(a)*r*.9);ctx.stroke();}
      if(!icon){const bw=r*2.6,k=clamp(e.hp/e.maxHp,0,1);ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(-bw/2,r+10,bw,5);ctx.fillStyle=C90.red;ctx.fillRect(-bw/2,r+10,bw*k,5);}break;}
    default:return false;}
  return true;}

// ===== 0.9.6 · доводка «до идеала» =====
// --- Сердце: кульминация фазы 4 — три круга ключей (на Лёгкой два), каждый со своим рисунком ---
// доля пула, ниже которой Сердце не опустится, пока не сделано j запусков
function heartQuota96(b,j){const n=b.lN96||2;return .15*Math.max(0,1-j/n);}
// следующий круг ключей после очередного запуска: обратный порядок, затем «плывущие» ключи
function heartSeq96(b){const n=b.lN96||2,j=b.launches;if(j>=n||b.st!=='fight')return;
  for(const k of b.keys)k.lit90=0;b.keyI=0;
  if(j===1){b.keys.sort((a,c)=>c.ki-a.ki);b.rot96=0;banner('КЛЮЧИ НАОБОРОТ','СЕРДЦЕ СОПРОТИВЛЯЕТСЯ · ОБРАТНЫЙ ПОРЯДОК');radioLine('КОВЧЕГ',C90.ark,'Ритм идёт вспять. Ключи — в обратном порядке.',.2);}
  else if(j>=2){b.keys.sort((a,c)=>a.ki-c.ki);b.rot96=.28*(rk90()>=2?1.2:1);banner('КЛЮЧИ ПЛЫВУТ','ПОСЛЕДНИЙ КРУГ · ЛОВИТЕ В ТАКТ');radioLine('КОВЧЕГ',C90.ark,'Последний круг. Ключи уходят — догоняйте.',.2);}
  snd95('phase95');trauma90(.2);}
// положение ключей: по кругу 150·k, с поворотом в последнем круге
function heartKeyPos96(b){for(const q of b.keys){if(!q.alive)continue;const a=-Math.PI/2+q.ki*TAU/b.keyN+(b.keyA96||0);q.x=b.cx+Math.cos(a)*150*b.k;q.y=b.cy+Math.sin(a)*150*b.k;}}
// последний запуск: Сердце гаснет за 4 секунды при любом уроне — финал не зависит от сборки
function heartFinTick96(b,dt){if(!(b.fin96&&b.launch>0)||b.st!=='fight')return;if(!(b.fin96H>1)){b.fin96H=b.hp;b.fin96L=b.launch;}
  const f=clamp((b.launch-.4)/Math.max(.1,b.fin96L-.4),0,1);b.hp=Math.max(1,1+(b.fin96H-1)*f);b.dmgT=G.t;b.flash=.05;
  if(SET.fx&&vR3()<.5){const a=vrnd3(0,TAU),v=vrnd3(80,240);part(b.cx+Math.cos(a)*b.r*.6,b.cy+Math.sin(a)*b.r*.6,Math.cos(a)*v,Math.sin(a)*v,vrnd3(.4,.9),vR3()<.5?'#ffffff':C90.ark,vrnd3(2,3.5));}
  if(f<=0){b.hp=1;sb85CheckTh(b);}}
// --- Тревога 0.9.6: облава гасится, а не раскручивается ---
function ob96N(){let n=0;for(const e of G.enemies)if(e.alive&&e.ob96)n++;for(const w of G.warns)if(w.o&&w.o.ob96)n++;return n;}
// --- виньетка сектора: градиент по экрану каждый кадр стоил 4–17 мс на слабом телефоне (программный растр, ЦП ×4);
//     теперь кэш-спрайт цвета (до 2,3 Мп — в точный размер, крупнее — 640 px с растяжением) и прозрачность кадра ---
const SVIG96=new Map();
function secVigSpr96(rgb,w,h){const big=w*h>2.3e6,sw=big?640:w,sh=big?Math.max(1,Math.round(640*h/w)):h,key=rgb+'|'+sw+'x'+sh;let c=SVIG96.get(key);
  if(!c){c=document.createElement('canvas');c.width=sw;c.height=sh;const g=c.getContext('2d'),gr=g.createRadialGradient(sw/2,sh/2,Math.min(sw,sh)*.45,sw/2,sh/2,Math.max(sw,sh)*.72);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba('+rgb+',1)');g.fillStyle=gr;g.fillRect(0,0,sw,sh);
    if(SVIG96.size>=3)SVIG96.delete(SVIG96.keys().next().value);SVIG96.set(key,c);}return c;}
// фагоциты облавы помечены пунктирным кольцом: видно, кого сбить, чтобы стало тише
function ob96Draw(t){const X=G.x90;if(!X||!X.alarmOn)return;let any=false;for(const e of G.enemies){if(!e.alive||!e.ob96||e.spawnT>0)continue;if(!any){any=true;ctx.save();ctx.lineWidth=1.5;ctx.setLineDash([4,5]);ctx.lineDashOffset=-t*18;}
  ctx.strokeStyle=rgba90(C90.red,.55+.25*Math.sin(t*5+e.uid));ctx.beginPath();ctx.arc(e.x,e.y,e.r+9,0,TAU);ctx.stroke();}if(any)ctx.restore();}
// --- Сердце: волна обходит сосуды. Раньше кольцо без проходов шло на каждый удар фаз 1–2, а двойной удар фазы 3
//     ставил проходы двух колец под 90° — увернуться можно было только рывком, а он перезаряжается 1,5–2,4 с.
//     Идеальный «рывковый» бот погибал за 14–20 с. Теперь у каждой волны есть проход, до которого можно долететь:
//     фаза 1 — вдоль всех четырёх сосудов (учимся); фаза 2 — два прохода плывут по 12°/с (следуем);
//     фаза 3 — два прохода плывут по 15°/с, второй удар сдвинут на 12/16/20° (Лёгкая/Нормальная/Тяжёлая):
//     безопасно там, где проходы совпадают (точность). Направление дрейфа меняется раз в 8 с, стрелки у сердца ---
const HGW96={1:[54,44,38],2:[48,40,34],3:[46,40,34]},HGO96=[12,16,20];
function heartOff96(){return HGO96[Math.max(0,Math.min(2,rk90()))]*Math.PI/180;}
function heartRate96(b){return (b.phase===2?12:15)*Math.PI/180;}
function heartGaps(b,ahead){ahead=ahead||0;const ph=b.phase>=1&&b.phase<=3?b.phase:1,rk=Math.max(0,Math.min(2,rk90())),w=HGW96[ph][rk]*Math.PI/180;
  if(ph===1||!b.ves||!b.ves.length)return (b.ves||[]).map(v=>({a:v.a,w}));
  const th=(b.gth96!==undefined?b.gth96:b.ves[0].a)+(b.gdir96||1)*heartRate96(b)*(b.btN||.67)*ahead;return [{a:th,w},{a:th+Math.PI,w}];}
function heartDrift96(b,dt){if(b.gth96===undefined){b.gth96=b.ves[0].a;b.gdir96=1;b.gfl96=8;}b.gth96+=b.gdir96*heartRate96(b)*dt;b.gfl96-=dt;if(b.gfl96<=0){b.gfl96=8;b.gdir96*=-1;}}
// --- враг «за краем» (держатель дистанции отступал вдоль стены или шлюза за кромку арены): за ним нельзя
//     прицелиться, и миссия вставала минутами. Кто однажды вошёл в арену, из неё больше не выходит;
//     кто застрял снаружи сразу после появления — через 2,5 с возвращается внутрь с мерцанием.
//     Не трогаем тех, кто уходит за край по замыслу: беглец с грузом, Последний из рода, линкор, паломники,
//     пассажиры и свидетели, корабли-эхо, ледяная копия, снаряды и мины, классические боссы и части боссов ---
const OUT96=new Set(['witness100','pass90','lastkind','linkor','pilgrim','echoship','echoguard','icecopy','crate','shell','mine','hull','decoy','convoybox','rangedummy','boss','jam']);
function rescue96(dt){if(G.sb&&G.sb.alive)return;for(const e of G.enemies){if(!e.alive||e.spawnT>0||e.retreat||e.flee||e.leave90||e.tailT>0||e.dummy||e.sbk||e.host85||e.host74||G.latch74===e||STATIC.has(e.type)||EDEF[e.type].passive||EDEF[e.type].sbp||OUT96.has(e.type))continue;
  const r=e.r||12,inside=e.x>=r&&e.x<=W-r&&e.y>=r&&e.y<=H-r;if(inside){e.in96=1;e.off96=0;continue;}
  if(e.in96){const x=clamp(e.x,r,W-r),y=clamp(e.y,r,H-r);if(x!==e.x)e.vx=0;if(y!==e.y)e.vy=0;e.x=x;e.y=y;continue;}
  const out=e.x<-10||e.x>W+10||e.y<-10||e.y>H+10;if(!out){e.off96=0;continue;}e.off96=(e.off96||0)+dt;
  if(e.off96>2.5){e.off96=0;e.in96=1;e.x=clamp(e.x,50,W-50);e.y=clamp(e.y,50,H-50);e.vx=e.vy=0;e.spawnT=.4;if(typeof pushOut95==='function')pushOut95(e,4);if(typeof lockPush90==='function')lockPush90(e);}}}
// --- финальная зачистка в отсеках со шлюзами: волны кончились, врагов ≤ 5 — шлюзы открываются насовсем,
//     а последних врагов видно сквозь стены: никто не прячется за закрытой дверью минутами ---
function fin96Tick(X){if(X.fin96||!X.locks||!X.locks.length||(G.sb&&G.sb.alive))return;if(G.waveIdx<G.waves.length||(G.spawnQ&&G.spawnQ.length))return;
  let n=0;for(const e of G.enemies)if(e.alive&&!EDEF[e.type].passive&&!STATIC.has(e.type))n++;if(n>5)return;X.fin96=1;const p=G.player;if(p&&n>0){floater(p.x,p.y-60,'ШЛЮЗЫ ОТКРЫТЫ · ДОБЕЙТЕ ОСТАВШИХСЯ',C90.warm);snd90('locko');}}
function fin96Draw(t){const X=G.x90;if(!X||!X.fin96)return;let any=false;for(const e of G.enemies){if(!e.alive||EDEF[e.type].passive||STATIC.has(e.type)||e.spawnT>0)continue;if(!any){any=true;ctx.save();ctx.lineWidth=1.5;ctx.setLineDash([2,6]);ctx.lineDashOffset=t*14;}
  ctx.strokeStyle=rgba90('#ffffff',.35+.2*Math.sin(t*3+e.uid));ctx.beginPath();ctx.arc(e.x,e.y,e.r+14,0,TAU);ctx.stroke();}if(any)ctx.restore();}
// --- ядро ганглия (39–41) — снова векторами: поворот спрайта 552×552 стоил 1,5–1,7 мс на слой на слабом телефоне
//     (программный растр, ЦП ×4), те же пути векторами — 0,24–0,48 мс; рисунок тот же, поворот и пульс — трансформом ---
function coreVec96(q,layer){const r=q.r;ctx.lineCap='butt';
  if(layer===0){ctx.fillStyle='#2a0810';ctx.strokeStyle=C90.ark;ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();
    ctx.strokeStyle=rgba90(C90.red,.6);ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;ctx.moveTo(Math.cos(a)*r*.3,Math.sin(a)*r*.3);ctx.quadraticCurveTo(Math.cos(a+.4)*r*.7,Math.sin(a+.4)*r*.7,Math.cos(a+.2)*r*.95,Math.sin(a+.2)*r*.95);}ctx.stroke();}
  else{ctx.strokeStyle=rgba90('#ffe47a',.6);ctx.lineWidth=1.5;ctx.beginPath();for(let i=0;i<7;i++){const a=i/7*TAU;ctx.moveTo(Math.cos(a)*r*.22,Math.sin(a)*r*.22);ctx.quadraticCurveTo(Math.cos(a+.5)*r*.5,Math.sin(a+.5)*r*.5,Math.cos(a+.25)*r*.92,Math.sin(a+.25)*r*.92);}ctx.stroke();}}
// --- лимит видов IX–X — в момент появления: раньше проверка ждала первого хода ИИ (после анимации появления),
//     и на полсекунды на арене бывало на 2–3 Спазма больше лимита, а появившийся враг на глазах менял вид ---
function capEarly96(){for(const e of G.enemies)if(e.alive&&!e.cap90&&S90T.has(e.type))cap90(e);}

