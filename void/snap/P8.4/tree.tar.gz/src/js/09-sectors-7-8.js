// ===== 0.8.0: сектора VII «Предел» и VIII «Исток» — поведение, мир, звук =====
const S80T=new Set(['labrat','defect','inspector','railshield','stamp','recycler','echo80','loop','inverse','pilgrim','rangedummy','convoybox']);
S80T.forEach(k=>H74.add(k));S80T.forEach(k=>STORY_NORETREAT.add(k));['pilgrim','rangedummy','convoybox'].forEach(k=>AIM_SKIP75.add(k));
const DEF_MODES80=['shoot','ram','mine','guard'],DEF_COL80={shoot:'#ffd36b',ram:'#ff4f6e',mine:'#ff9a3d',guard:'#9fb0c4'},DEF_TXT80={shoot:'СТРЕЛОК',ram:'ТАРАН',mine:'МИНЁР',guard:'СТОРОЖ'};
const VOICES80=['«…вы тоже слышали? Не ответ. Вопрос…»','«…мы не первые. Мы не последние. Мы — те, кто дошёл…»','«…Стражи спрашивали то же самое. Им ответили. Им не понравилось…»','«…номер не важен. Важно, что сигнал повторяется…»',
  '«…я помнил небо. Потом помнил только курс…»','«…Исток не зовёт. Он просто не перестаёт звучать…»','«…если ты слышишь это — ты уже копия. Не бойся. Мы тоже…»','«…бюро считало нас изделиями. Изделия не уходят сами…»',
  '«…сто двадцать седьмой цикл. Или первый. Здесь это одно и то же…»','«…Карр тоже летит сюда. Он ещё не знает зачем…»','«…они назвали это «Пределом». Предел — это где кончается бюро. Не мы…»','«…последний голос. Дальше — только сигнал…»'];
function sec80(){const s=sec74();return s===6||s===7?s:-1;}
function d80H(k,txt,col){const H=G.h80||(G.h80={});if(H[k])return;H[k]=1;const p=G.player;if(p)floater(p.x,p.y-44,txt,col||'#e8d27a');}
function w80S(){const S=G.save;if(!S)return {clk:0,alarmAt:[0,0,0],rangeBest:0,seen:{},voices:0};const w=S.w80||(S.w80={clk:0,alarmAt:[0,0,0],rangeBest:0,seen:{},voices:0});w.alarmAt=w.alarmAt||[0,0,0];w.seen=w.seen||{};return w;}
function rankD80(){return curDiff().rank||0;}
// --- инициализация миссии ---
function t80Init(M){t85Init(M);t90Init(M);const sec=M&&M.gen?M.sec:-1;G.x80={sec,leaks:[],bo:null,pil:null,born:G.t};G.bo80=0;G.insp80=0;G.insp80By=null;G.inv80=0;G.slow80=0;G.stamp80=null;G.rcDrop80=0;G.rcLost80=0;G.echoQ80=[];G.echoSeq80=0;G.echoHitT80=-99;G.dmgN80=[];G.rcB80=[];G.echoBl80=[];G.res80=null;document.body.classList.remove('stamp80');
  if(G.mode==='endless'||!inMission()||(sec!==6&&sec!==7))return;const m=G.m,X=G.x80;
  if(!M.bossRoom&&m!==28&&m!==32&&m!==34&&m!==36&&!(sec===6&&G.mode==='world'&&storyFlag('line31')==='break'))X.bo={st:'wait',t:0};
  if(m===29||m===30){const n=m===29?1:2;for(let i=0;i<n;i++)X.leaks.push({x:n===1?W*.5:(i?W*.72:W*.3),y:n===1?H*.52:(i?H*.62:H*.4),r:Math.min(W,H)*(n===1?.22:.18)});}
  if(m===36||m===37)X.pil={at:m===36?20:30,done:false,hostile:false,tol:((G.save&&G.save.story&&G.save.story.spared||0)>=5?1:0)+(storyFlag('line31')==='write'?1:0)};}
// --- ИИ (из s74Update0; true = обработан) ---
const CAP80={labrat:2,railshield:2,recycler:1,inspector:2,echo80:2,loop:4,stamp:3,inverse:1};
function cap80(e){if(e.cap80||G.world||e.zone)return;e.cap80=1;const lim=CAP80[e.type];if(lim===undefined)return;const M=MISSIONS[G.m-1],L=e.type==='recycler'&&M&&M.bossRoom?2:lim;
  const n=G.enemies.filter(o=>o!==e&&o.alive&&o.type===e.type).length;if(n<L)return;const sec=M&&M.sec;let nt=sec===7?(e.type==='loop'?'phantom':'loop'):'defect';if(nt===e.type)nt='gunner';if(nt==='defect'&&G.enemies.filter(o=>o.alive&&o.type==='defect').length>=3)nt='gunner';
  if(CAP80[nt]!==undefined&&G.enemies.filter(o=>o!==e&&o.alive&&o.type===nt).length>=CAP80[nt])nt='gunner';const k=e.maxHp/EDEF[e.type].hp;e.type=nt;e.maxHp=e.hp=EDEF[nt].hp*k;e.r=EDEF[nt].r;e.contact=EDEF[nt].contact;e.cap80=1;}
function s80Update(e,dt,c){cap80(e);if(!S80T.has(e.type))return false;const p=G.player,{ux,uy,d,sm,T,pd}=c,pdx=p.x-e.x,pdy=p.y-e.y,dark=G.bo80>=.5;
  switch(e.type){
    case 'labrat':{let cx=0,cy=0,n=0;for(const o of G.enemies){if(o===e||!o.alive||o.type==='labrat'||EDEF[o.type].passive||STATIC.has(o.type)||Math.hypot(o.x-e.x,o.y-e.y)>600)continue;cx+=o.x;cy+=o.y;n++;}
      let tx,ty;if(n){cx/=n;cy/=n;const dx=cx-p.x,dy=cy-p.y,l=Math.hypot(dx,dy)||1;tx=cx+dx/l*120;ty=cy+dy/l*120;}else{const a=G.t*.5+e.seed;tx=p.x+Math.cos(a)*300;ty=p.y+Math.sin(a)*300;}
      const q=Math.hypot(tx-p.x,ty-p.y);if(q<260){tx=p.x+(tx-p.x)/(q||1)*280;ty=p.y+(ty-p.y)/(q||1)*280;}
      steer(e,tx-e.x,ty-e.y,e.spd*sm,dt,2.5);if(e.bcut>0)e.bcut-=dt;
      e.ht=(e.ht===undefined?.3:e.ht)-dt;if(e.hot>0)e.hot-=dt;if(e.ht<=0&&!(e.hot>0)){e.ht=.5;let best=e.beam&&e.beam.alive&&e.beam.healBy===e?e.beam:null,bk=best?best.hp/best.maxHp:1;if(!best)for(const o of G.enemies){if(o===e||!o.alive||o.spawnT>0||o.type==='labrat'||EDEF[o.type].passive||EDEF[o.type].sbp||STATIC.has(o.type)||o.type==='boss'||o.type==='loop'&&o.tr80>0||(o.healBy&&o.healBy!==e&&o.healBy.alive&&o.healBy.beam===o))continue;const k=o.hp/o.maxHp;if(k<bk&&Math.hypot(o.x-e.x,o.y-e.y)<300){bk=k;best=o;}}if(best!==e.beam)e.bt80=0;e.beam=best;if(best)best.healBy=e;}
      const b=e.beam;if(b&&(!b.alive||b.hp>=b.maxHp||Math.hypot(b.x-e.x,b.y-e.y)>340||e.bcut>0))e.beam=null;
      if(e.beam&&p.hp>0&&p.dashT>0&&segInter(p.px,p.py,p.x,p.y,e.x,e.y,e.beam.x,e.beam.y)){floater((e.x+e.beam.x)/2,(e.y+e.beam.y)/2-14,'ЛУЧ ПОРВАН','#7affc9');e.beam=null;e.bcut=1;if(G.mc)G.mc.beam80=1;}
      if(e.beam){const o=e.beam;e.bt80=(e.bt80||0)+dt;if(e.bt80>4){e.beam=null;e.hot=2;e.bt80=0;}else o.hp=Math.min(o.maxHp,o.hp+o.maxHp*(HEAVY.has(o.type)?.04:.06)*(rankD80()>=2?.6:1)*dt);}if(e.beam){d80H('labrat','ЛАБОРАНТ ЧИНИТ РАНЕНЫХ · СНАЧАЛА ЕГО','#7affc9');}return true;}
    case 'defect':{if(!e.mode){e.mode=DEF_MODES80[Math.floor(Math.random()*4)];e.mT=3;}e.mT-=dt;
      if(e.mT<=0){let nm;do{nm=DEF_MODES80[Math.floor(Math.random()*4)];}while(nm===e.mode);e.mode=nm;e.mT=3;e.rst=null;e.mined=0;e.bn=0;}
      const m_=e.mode;
      if(m_==='shoot'){const k=clamp((pd-300)/120,-1,1);steer(e,pdx/pd*k-pdy/pd*.6*e.dir,pdy/pd*k+pdx/pd*.6*e.dir,e.spd*sm,dt,3);
        if(e.bn>0){e.bt-=dt;if(e.bt<=0){e.bn--;e.bt=.15;shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x)+rnd(-.06,.06),280,8,'#ffd36b',4,!!T.isBc);}}
        else{e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0&&(!dark||pd<520)){e.cd=1.6;e.bn=3;e.bt=0;}}}
      else if(m_==='ram'){if(!e.rst){e.rst='aim';e.rt=G.noTele?.5:.8;e.aim=Math.atan2(pdy,pdx);}
        if(e.rst==='aim'){e.vx*=.85;e.vy*=.85;if(e.rt>.22)e.aim+=clamp(angDiff(Math.atan2(pdy,pdx),e.aim),-1.5*dt,1.5*dt);e.rt-=dt;if(e.rt<=0){e.rst='go';e.rt=.6;}}
        else if(e.rst==='go'){e.vx=Math.cos(e.aim)*420;e.vy=Math.sin(e.aim)*420;e.rt-=dt;if(e.rt<=0)e.rst='rest';}
        else{e.vx*=.9;e.vy*=.9;}}
      else if(m_==='mine'){steer(e,-pdx/pd*.3-pdy/pd*e.dir,-pdy/pd*.3+pdx/pd*e.dir,e.spd*sm*.8,dt,2);
        if(!e.mined&&e.mT<2.4){e.mined=1;if(G.enemies.filter(o=>o.alive&&o.type==='mine'&&o.def80).length<4){const mn=spawnEnemy('mine',e.x,e.y,{arm:.95,fuse:0,life:12,noAffix:true,noLoot:true,def80:true});}}}
      else{e.vx*=.9;e.vy*=.9;}
      return true;}
    case 'inspector':{const k=clamp((pd-380)/120,-1,1);steer(e,pdx/pd*k-pdy/pd*.5*e.dir,pdy/pd*k+pdx/pd*.5*e.dir,e.spd*sm,dt,2);
      if(e.ca===undefined)e.ca=Math.atan2(pdy,pdx)+rnd(-1,1);if(!e.cdir)e.cdir=Math.random()<.5?-1:1;if(e.ct===undefined)e.ct=rnd(4,7);
      e.ct-=dt;if(e.ct<=0){e.ct=rnd(4,7);e.cdir*=-1;}e.ca+=.6*e.cdir*dt;if(e.cool80>0)e.cool80-=dt;
      const len=dark?260:420;e.clen=len;let see=false;
      if(p.hp>0&&pd<len&&Math.abs(angDiff(Math.atan2(pdy,pdx),e.ca))<.436&&e.spawnT<=0){see=true;const X=x74();if(X.hulls.length&&typeof hullBlocks75==='function'&&hullBlocks75(e.x,e.y,p.x,p.y))see=false;}
      const need=rankD80()===0?1.2:sbHard()?.5:.8;
      if(see)e.seeT=(e.seeT||0)+dt;else e.seeT=Math.max(0,(e.seeT||0)-dt*2);
      if(e.seeT>=need&&!(e.cool80>0)){e.seeT=0;e.cool80=5;insAlarm80(e);}
      e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0&&(!dark||pd<520)){e.cd=2.8;shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x),240,8,'#ffd36b',4,!!T.isBc);}return true;}
    case 'railshield':{let cx=0,cy=0,n=0;for(const o of G.enemies){if(o===e||!o.alive||o.type==='railshield'||EDEF[o.type].passive||STATIC.has(o.type)||Math.hypot(o.x-p.x,o.y-p.y)>900)continue;cx+=o.x;cy+=o.y;n++;}
      if(!n){cx=e.x;cy=e.y;}else{cx/=n;cy/=n;}let dx=cx-p.x,dy=cy-p.y,l=Math.hypot(dx,dy);if(l<1){dx=e.x-p.x;dy=e.y-p.y;l=Math.hypot(dx,dy)||1;}
      const dist=clamp(l*.45,200,400),tx=p.x+dx/l*dist,ty=p.y+dy/l*dist;e.rail={x:tx,y:ty,ux:-dy/l,uy:dx/l};
      const q=Math.hypot(tx-e.x,ty-e.y);if(q>6)steer(e,tx-e.x,ty-e.y,Math.min(e.spd*sm,q*3),dt,3);else{e.vx*=.8;e.vy*=.8;}
      const fa=Math.atan2(p.y-e.y,p.x-e.x);e.fa=e.fa===undefined?fa:e.fa+clamp(angDiff(fa,e.fa),-2*dt,2*dt);return true;}
    case 'stamp':{if(e.sc>0)e.sc-=dt;const away=e.sc>0;
      if(away){const k=clamp((pd-220)/100,-1,1);steer(e,pdx/pd*k-pdy/pd*.7*e.dir,pdy/pd*k+pdx/pd*.7*e.dir,e.spd*sm,dt,3);}
      else{const w=Math.sin(e.t*5+e.seed)*.8;steer(e,pdx/pd-pdy/pd*w,pdy/pd+pdx/pd*w,e.spd*sm,dt,3);
        if(pd<e.r+p.r+4&&p.hp>0&&p.dashT<=0&&e.spawnT<=0){if(!G.stamp80&&p.inv<=0){G.stamp80={t:rankD80()===0?5:4,max:rankD80()===0?5:4};floater(p.x,p.y-34,'ПРОВЕРЕНО · СБРОСЬТЕ РЫВКОМ','#ff7a3d');buzz('hit');sfx('block');document.body.classList.add('stamp80');d80H('stamp','ШТАМП: РЫВОК ИЛИ ИМПУЛЬС СБРАСЫВАЮТ','#ff7a3d');}
          e.sc=G.stamp80?8:2;e.vx=-pdx/pd*320;e.vy=-pdy/pd*320;}}return true;}
    case 'recycler':{const k=clamp((pd-300)/90,-1,1);steer(e,pdx/pd*k-pdy/pd*.4*e.dir,pdy/pd*k+pdx/pd*.4*e.dir,e.spd*sm,dt,1.5);
      e.hopper=e.hopper||[];e.pt=(e.pt||0)-dt;
      if(e.pt<=0){e.pt=.25;const lim=G.rcLost80>=.3*Math.max(10,G.rcDrop80);if(!lim&&e.hopper.length<12){const mag=G.st?G.st.mag:0;let n=0;
          for(const k_ of G.pick){if(n>=6)break;if(k_.rc80||k_.anom||k_.story||k_.quest||k_.life<=0||(k_.k!=='xp'&&k_.k!=='lom'&&k_.k!=='cell'&&k_.k!=='part80'))continue;
            if(Math.hypot(k_.x-e.x,k_.y-e.y)>320)continue;if(p.hp>0&&Math.hypot(k_.x-p.x,k_.y-p.y)<mag+10)continue;k_.rc80=e;k_.noMag=true;n++;}}}
      if(e.fire80){e.fire80-=dt;if(e.fire80<=0){e.fire80=0;const n=Math.min(4,e.hopper.length);const a0=Math.atan2(T.y-e.y,T.x-e.x);
          for(let i=0;i<n;i++){const it=e.hopper.shift();const dmg=it.k==='lom'?Math.min(14,8+Math.floor((it.v||1)/10)):it.k==='part80'?12:6;const col=it.k==='lom'?'#ffb84d':it.k==='xp'?'#d9c8ff':it.k==='cell'?'#ffb84d':'#c9d2de';
            const b=shootE(e.x,e.y,a0+(i-(n-1)/2)*.14,260,dmg,col,it.k==='part80'?7:5,!!T.isBc);if(b){b.rc80=it;G.rcB80.push(b);}}sfx('shot');e.fT=2.4;if(G.mc&&n)G.mc.rcFired80=1;}}
      else{e.fT=(e.fT===undefined?2:e.fT)-dt;if(e.fT<=0&&e.hopper.length&&p.hp>0&&onScreen(e)&&(!dark||pd<520)){e.fire80=G.noTele?.5:.8;sfx('warn');}}return true;}
    case 'echo80':{const k=clamp((pd-420)/80,-1,1);let tx=null;const L=G.posLog;if(L&&L.length){for(let i=L.length-1;i>=0;i--){if(G.t-L[i].t>=3){tx=L[i];break;}}}
      if(tx&&pd>380){steer(e,(tx.x-e.x)*.6+pdx/pd*k*120,(tx.y-e.y)*.6+pdy/pd*k*120,e.spd*sm,dt,1.6);}else steer(e,pdx/pd*k-pdy/pd*.5*e.dir,pdy/pd*k+pdx/pd*.5*e.dir,e.spd*sm,dt,2);
      if(Math.random()<dt*.2)e.dir*=-1;e.born80=e.born80||G.t;return true;}
    case 'loop':{if(e.tr80>0){e.tr80-=dt;e.vx=e.vy=0;e.ghost=true;if(e.tr80<=0){e.tr80=0;e.ghost=false;e.hp=e.maxHp*(rankD80()>=2?.4:.5);e.lr80=(e.lr80||0)+1;e.win80=2.6;e.spawnT=.6;e.contact=e.contact0||10;if(e.lr80>=2&&G.mc)G.mc.loopBad80=1;sfx('warn');}return true;}
      if(e.win80>0)e.win80-=dt;
      if(pd>320){steer(e,pdx,pdy,e.spd*sm,dt,3);}else{steer(e,-pdy/pd*e.dir+pdx/pd*.2,pdx/pd*e.dir+pdy/pd*.2,e.spd*sm,dt,3);if(Math.random()<dt*.3)e.dir*=-1;}
      if(e.bn>0){e.bt-=dt;if(e.bt<=0){e.bn--;e.bt=.12;shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x),300,8,'#6b8cff',4,!!T.isBc);}}
      else{e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0&&pd<520){e.cd=1.6;e.bn=2;e.bt=0;}}return true;}
    case 'inverse':{const k=clamp((pd-300)/80,-1,1);steer(e,pdx/pd*k-pdy/pd*.6*e.dir,pdy/pd*k+pdx/pd*.6*e.dir,e.spd*sm,dt,2.5);if(Math.random()<dt*.25)e.dir*=-1;
      if(e.it===undefined)e.it=4;
      if(e.iw){const w=e.iw;w.r+=500*dt;if(!w.hit&&p.hp>0&&Math.abs(Math.hypot(p.x-w.x,p.y-w.y)-w.r)<22){w.hit=true;if(p.dashT<=0){invHit80();}}if(w.r>=380)e.iw=null;}
      else if(e.itel>0){e.itel-=dt;e.vx*=.9;e.vy*=.9;if(e.itel<=0){e.itel=0;e.iw={x:e.x,y:e.y,r:e.r,hit:false};e.pulsed80=1;sfx('pulse');G.shock.push({x:e.x,y:e.y,r:e.r,R:380,t:0,col:'#e86bff',thin:true});}}
      else{e.it-=dt;if(e.it<=0&&onScreen(e)&&p.hp>0){e.it=7*(G.atkK||1);e.itel=sbHard()?.6:1.0;sfx('warn');}}return true;}
    case 'pilgrim':return pilgrimAI80(e,dt),true;
    case 'rangedummy':case 'convoybox':e.vx=e.vy=0;return true;}
  return false;}
function s80Pre(e,dt){if(e.alarm80&&alarmAI80(e,dt))return true;if(e.convoy80&&convoyAI80(e,dt))return true;if(e.audit80&&auditAI80(e,dt))return true;return false;}
function insAlarm80(e){G.insp80=5;G.insp80By=e;const p=G.player;for(const o of G.enemies)if(o.alive&&o!==e&&Math.hypot(o.x-e.x,o.y-e.y)<500)o.insB80=5;
  floater(p.x,p.y-38,'НАРУШЕНИЕ РЕГЛАМЕНТА · ВРАГИ СИЛЬНЕЕ','#ffd36b');buzz('ready');sfx('warn');if(G.mc)G.mc.seen80=1;
  if(e.audit80&&e.zone&&!e.zone.alarm){const z=e.zone;z.alarm=1;if(!z.stealth){radioLine('БЮРО','#e8d27a','Изделие вне партии. Квадрат '+(1+Math.floor(Math.abs(z.x+z.y)/700)%9)+'.',.1);const s=w74Sp(z,'stamp',e.x+rnd(-40,40),e.y+rnd(-40,40));}}}
function invHit80(){const p=G.player;if(G.inv80>0||G.slow80>0)return;if(SET.softInv){G.slow80=2;floater(p.x,p.y-34,'ИЗНАНКА · ЗАМЕДЛЕНИЕ','#e86bff');}else{G.inv80=2;if(!(G.h80&&G.h80.inv))floater(p.x,p.y-34,'ИЗНАНКА · УПРАВЛЕНИЕ НАОБОРОТ','#e86bff');G.h80=G.h80||{};G.h80.inv=1;}buzz('hit2');sfx('block');if(G.mc)G.mc.inv80=1;}
function inputK80(){return G.inv80>0&&!SET.softInv?-1:1;}
// --- урон ---
function s80Hurt(e,dmg,src){src=src||{};
  switch(e.type){
    case 'rangedummy':{rangeHit80(e,dmg,src);return 0;}
    case 'defect':return e.mode==='guard'?dmg*.6:dmg;
    case 'labrat':e.bcut=1;e.beam=null;return dmg;
    case 'pilgrim':if(e.pg85)return pil85Hurt(e,dmg,src);if(src.pulse&&G.world&&e.peace&&storyFlag('well38'))return 0;pilgrimHit80(e);return dmg;
    case 'convoybox':if(e.zone)e.zone.prov80=1;return dmg;}
  return dmg;}
function s80Killed(e,silent){const p=G.player;if(!e)return;const hop=e.hopper?e.hopper.length:0;
  if(e.type==='inspector'&&G.insp80By===e){G.insp80=0;G.insp80By=null;}
  if(e.type==='recycler')rcRelease80(e,silent);
  if(silent)return;
  if(G.bo80>=.5&&(inMission()||(G.world&&sec80()>=0))&&!EDEF[e.type].passive){conEvent('darkKill');if(G.mc)G.mc.dark80=(G.mc.dark80||0)+1;}
  if(G.world&&W80.alarm&&W80.alarm.st==='on'){const q=W80.pults[W80.alarm.i];if(q&&Math.hypot(e.x-q.x,e.y-q.y)<600&&!EDEF[e.type].passive){G.save.carry+=5;floater(e.x,e.y-20,'+5 · ТРЕВОГА','#ff7a3d');conEvent('alarmKill');}}
  switch(e.type){
    case 'defect':if(Math.random()<.25){if(G.world)G.pick.push({k:'lom',x:e.x,y:e.y,vx:rnd(-60,60),vy:rnd(-60,60),r:5,t:0,life:30,v:2});else for(let i=0;i<EDEF.defect.xp;i++)G.pick.push({k:'xp',x:e.x+rnd(-8,8),y:e.y+rnd(-8,8),vx:rnd(-90,90),vy:rnd(-90,90),r:5,t:0,life:22});floater(e.x,e.y-20,'ДЕТАЛЬ С БРАКОМ','#e8d27a');}break;
    case 'railshield':for(let i=0;i<3;i++)G.pick.push({k:'part80',x:e.x+rnd(-14,14),y:e.y+rnd(-14,14),vx:rnd(-80,80),vy:rnd(-80,80),r:6,t:0,life:12,noMag:true});break;
    case 'echo80':if(!(G.echoHitT80>(e.born80||0)))conEvent('echoClean');break;
    case 'loop':if(G.mc)G.mc.loopK80=(G.mc.loopK80||0)+1;if(e.lb80){if(!G.world)for(let i=0;i<Math.ceil(EDEF.loop.xp*.5);i++)G.pick.push({k:'xp',x:e.x+rnd(-8,8),y:e.y+rnd(-8,8),vx:rnd(-90,90),vy:rnd(-90,90),r:5,t:0,life:22});else G.save.carry+=3;floater(e.x,e.y-22,'ПЕТЛЯ РАЗОРВАНА','#6b8cff');if((e.lr80||0)<=1)conEvent('loopBreak');}else if(G.mc)G.mc.loopBad80=1;break;
    case 'inverse':if(!e.pulsed80)conEvent('inverseFast');break;
    case 'recycler':if(hop>=8)conEvent('recyclerFull');break;
    case 'pilgrim':{const S=G.save;if(S&&S.story)S.story.pilgrimsKilled=(S.story.pilgrimsKilled||0)+1;break;}}}
// перехват смерти Петли: след на 5 с
function loopIntercept80(e){if(e.tr80>0)return true;if(e.win80>0&&e.spawnT<=0){e.lb80=1;return false;}if((e.lr80||0)>=(rankD80()>=2?1:2))return false;
  e.tr80=5;e.ghost=true;e.hp=1;e.vx=e.vy=0;e.contact0=e.contact||10;e.contact=0;prioClear(e);explode(e.x,e.y,'#6b8cff',10,.6);
  if(!(G.h80&&G.h80.loop)){G.h80=G.h80||{};G.h80.loop=1;floater(e.x,e.y-24,'ПЕТЛЯ ВЕРНЁТСЯ · ДОБЕЙТЕ ЗА 2 С','#6b8cff');}return true;}
function loopBreak80(e){if(!e.alive||!(e.tr80>0))return;e.tr80=0;e.ghost=false;e.win80=99;e.spawnT=0;e.hp=0;kill(e);}
// --- снаряды игрока (до общих попаданий; true = поглощён) ---
function b80Hit(b){if(b85Hit(b))return true;if(b90Hit(b))return true;
  for(const e of G.enemies){if(!e.alive)continue;
    if(e.type==='railshield'&&e.spawnT<=0&&e.fa!==undefined){const ux=Math.cos(e.fa+Math.PI/2)*30,uy=Math.sin(e.fa+Math.PI/2)*30;
      if(segInter(b.px,b.py,b.x,b.y,e.x-ux,e.y-uy,e.x+ux,e.y+uy)){if(b.charged||b.blast){if(!b.hit.includes(e)){b.hit.push(e);hurt(e,b.dmg*1.5,{charged:!!b.charged,blast:!!b.blast});}continue;}
        hurt(e,b.dmg,{rail:true});b.life=0;e.shieldFlash=.08;if(SET.fx)part(b.x,b.y,vrnd3(-40,40),vrnd3(-40,40),.25,'#c9d2de',2);return true;}}
    if(e.type==='loop'&&e.tr80>0&&b.charged&&segDist(b.px,b.py,b.x,b.y,e.x,e.y)<e.r+10){loopBreak80(e);}}
  return false;}
// импульс: следы Петель, память Отзвуков, штамп
function pulse80(p,R){pulse85(p,R);pulse90(p,R);mod90Pulse(p);for(const e of G.enemies.slice()){if(e.type==='loop'&&e.tr80>0&&Math.hypot(e.x-p.x,e.y-p.y)<R+e.r)loopBreak80(e);}
  if(G.echoQ80&&G.echoQ80.length&&G.enemies.some(e=>e.alive&&e.type==='echo80'&&Math.hypot(e.x-p.x,e.y-p.y)<R+e.r)){G.echoQ80.length=0;if(G.mc)G.mc.echoWipe80=1;floater(p.x,p.y-30,'ПАМЯТЬ ОТЗВУКА СТЁРТА','#b48cff');}
  if(G.stamp80)stampOff80('ИМПУЛЬС');}
function stampOff80(how){G.stamp80=null;document.body.classList.remove('stamp80');const p=G.player;if(p)floater(p.x,p.y-30,'ШТАМП СБРОШЕН','#ff7a3d');conEvent('stampOff');}
// --- автоприцел (замена 0.7.5): веса новых целей, мишень полигона, радиус в темноте ---
/* ARCH·81 → aimPt перенесена в блок «ПОДСИСТЕМА НАВЕДЕНИЯ» после nearestEnemy */
function nearestEnemy(x,y,R,ignoreDecoy){
  if(!ignoreDecoy&&G.jam&&G.jam.phase===2){const dc=G.enemies.find(e=>e.type==='decoy'&&targetable(e));if(dc)return dc;}
  if(G.bo80>=.5)R=Math.min(R,380);
  let best=null,bd=R,ab=null,abd=R,dm=null;for(const e of G.enemies){if(e.type==='rangedummy'){if(e.alive)dm=e;continue;}
    if(!targetable(e)||(NOAUTO.has(e.type)&&!(e.type==='pilgrim'&&e.hostile80))||e.retreat||e.n74)continue;let d=Math.hypot(e.x-x,e.y-y)-e.r;
    if(e.type==='absorber'&&!e.tired){if(d<abd){abd=d;ab=e;}continue;}
    if(e.type==='membrane'){const q=aimPt(e);d=Math.hypot(q.x-x,q.y-y)*1.5;}
    else if(e.type==='railshield'){const q=aimPt(e);d=Math.hypot(q.x-x,q.y-y)*1.3;}
    else if(e.type==='labrat'&&e.beam)d*=.7;else if(e.type==='echo80')d*=.8;d*=aw90(e);
    if(d<bd){bd=d;best=e;}}
  if(!best&&ab)best=ab;
  if(!best&&dm&&G.world&&W80.range&&inRange80(x,y,200)&&dm.spawnT<=0&&Math.hypot(dm.x-x,dm.y-y)<R)best=dm;
  if(!best){for(const e of G.enemies){if((e.type==='mine'||e.type==='shell')&&targetable(e)){const d=Math.hypot(e.x-x,e.y-y);if(d<Math.min(bd,260)){bd=d;best=e;}}}}return best;}
/* ▼▼▼ ARCH·81 · ПОДСИСТЕМА НАВЕДЕНИЯ ▼▼▼ (1.5.21 α · этап 5, пилот переноса)
   Ответственность: кого можно взять в автоприцел (targetable, aimLockable), выбор цели (pickTarget, nearestEnemy — сразу выше,
   запасной выбор aimFallback), ручной прицел (aimManual), отметка цели касанием (prioTap), точка прицеливания (aimPt).
   Внешние входы, только чтение: G.player, G.enemies, G.state, G.world, G.dark, G.bo80, G.boss, G.jam, EDEF, NOAUTO, AIM_SKIP75, W80,
     SET.manual, touchMode, MOUSE, камера CX/CY/W/H/SC; функции inMission, isMob, sbAutoTarget (бой с носителем), visibleAt, inStorm,
     w58Hidden, targ90, sbTargetable, bossShielded, jamShielded, aw90, inRange80, memSeg, clamp; вывод — floater, console.warn.
   Поля G подсистемы: G.prio, G.aimLock, G.tg90, G.noTg75, G.aimWarn75. ARCH·84 (1.5.24): снаружи их меняют только
     через prioSet / prioClear / aimLockClear — kill, storyRetreat, loopIntercept80, startAnom, startEndless (шесть мест, ARCH·83);
     зарегистрированные исключения: групповые сбросы раунда Object.assign в setupMission0, startEndless, enterWorldAt (prio, aimLock).
     Ветка отката A-26 снята в ARCH·87 (1.5.27). Шаг наведения — aimStep (ARCH·82).
     Граница проверяется tools6/own6.js по tools6/ownership6.json (группа targeting; прежде — tools5/own5.js). Подсистема логически ограничена, но не инкапсулирована:
     G остаётся глобальным, поля читаются откуда угодно (в том числе diag77Text, ip78Post, nonameAI100 читают G.tg90).
   Перенос: объявления перенесены сюда без изменения тел (подъём объявлений делает место неважным; повторов у этих имён,
     кроме aimPt и nearestEnemy, нет; мёртвые копии aimPt и nearestEnemy сняты в ARCH·85, 1.5.25).
   Единственная правка — aimPt(e, from = G.player): точка считается относительно from, по умолчанию — игрока, как и раньше.
     Все вызовы aimPt передают один аргумент (в том числе прицел союзников), поэтому расчёт не изменился,
     а зависимость от G.player сохраняется — она внесена в реестр остатков. Длина aimPt.length осталась 1.
   Откат: mstrip 81 (байт в байт). */
function aimLockable(e){if(!e||!e.alive||e.spawnT>0||e.ghost||e.down>0||e.type==='shell')return false;if(e.type==='boss'||e.type==='jam')return e.st!=='enter'&&e.st!=='dying';if(EDEF[e.type].sbp)return targetable(e);return targetable(e)||(G.dark&&inStorm(e.x,e.y));}
function aimManual(){return SET.manual&&!touchMode&&MOUSE.moved;}
function targetable(e){
  if(!e||!e.alive||e.spawnT>0||e.ghost||e.down>0)return false;
  if(e.x<CX-10||e.x>CX+W+10||e.y<CY-10||e.y>CY+H+10)return false;
  if(e.type==='boss')return G.boss&&G.boss.st==='fight'&&!bossShielded();
  if(e.type==='jam')return G.jam&&G.jam.st==='fight'&&!jamShielded();
  if(EDEF[e.type].sbp)return sbTargetable(e);
  if(G.dark&&!visibleAt(e.x,e.y)&&!(e.reveal>0))return false;
  if(G.bo80>=.5&&(G.world||inMission())&&G.player&&!(e.reveal>0)&&Math.hypot(e.x-G.player.x,e.y-G.player.y)>380)return false;
  if(G.world&&(e.peace||e.dig!==undefined||w58Hidden(e)))return false;
  if(!targ90(e))return false;
  return true;
}
function pickTarget(){const p=G.player;if(G.prio&&targetable(G.prio)&&Math.hypot(G.prio.x-p.x,G.prio.y-p.y)<760)return G.prio;if(G.prio&&!G.prio.alive)G.prio=null;{const q=sbAutoTarget(p);if(q)return q;}return nearestEnemy(p.x,p.y,560);}
function prioTap(cx,cy){if(G.state!=='play'&&G.state!=='world')return;const x=cx/SC+CX,y=cy/SC+CY,tm=touchMode&&isMob();let best=null,bd=1e9;
  for(const en of G.enemies){if(!targetable(en))continue;const d=Math.hypot(en.x-x,en.y-y),R=tm?Math.max(en.r*SC+12,28)/SC:en.r+24;if(d<R&&d<bd){bd=d;best=en;}}
  if(best){if(tm&&G.prio===best){G.prio=null;floater(best.x,best.y-best.r-18,'ПРИОРИТЕТ СНЯТ','#9fb0c4');}else{G.prio=best;floater(best.x,best.y-best.r-18,'ПРИОРИТЕТ','#ffffff');}}else G.prio=null;}
function aimFallback(dt){const p=G.player;if(!p||!(G.world||inMission())){G.noTg75=0;return null;}
  let need=false;for(const e of G.enemies){if(e.alive&&e.spawnT<=0&&!EDEF[e.type].passive&&!e.retreat&&!e.n74&&!AIM_SKIP75.has(e.type)&&targetable(e)&&Math.hypot(e.x-p.x,e.y-p.y)<560){need=true;break;}}
  if(!need){G.noTg75=0;return null;}G.noTg75=(G.noTg75||0)+dt;if(G.noTg75<3)return null;
  let best=null,bd=560;for(const e of G.enemies){if(!e.alive||!targetable(e)||e.retreat||e.n74||EDEF[e.type].passive||AIM_SKIP75.has(e.type))continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<bd){bd=d;best=e;}}
  if(best){G.aimWarn75=G.aimWarn75||{};if(!G.aimWarn75[best.type]){G.aimWarn75[best.type]=1;try{console.warn('[VØID] автоприцел: запасной выбор цели — '+best.type);}catch(err){}}}return best;}
function aimPt(e,from=G.player){const p=from;if(e&&e.alive&&p){if(e.type==='membrane'&&e.wa!==undefined){const s=memSeg(e),dx=s[2]-s[0],dy=s[3]-s[1],L2=dx*dx+dy*dy||1,k=clamp(((p.x-s[0])*dx+(p.y-s[1])*dy)/L2,.12,.88);return {x:s[0]+dx*k,y:s[1]+dy*k};}
    if(e.type==='railshield'&&e.fa!==undefined){const ux=Math.cos(e.fa+Math.PI/2),uy=Math.sin(e.fa+Math.PI/2),k=clamp((p.x-e.x)*ux+(p.y-e.y)*uy,-24,24);return {x:e.x+ux*k,y:e.y+uy*k};}}return e;}
/* ARCH·82 · шаг наведения из updatePlayer (1.5.22). Тело — дословно операторы 1.5.21 от «let tg=» до поворота p.ang:
   выбор цели → G.tg90 (в ручном режиме — захват прошлого шага) → noTg75/aimFallback → sp → ручной захват/want → A-24 → p.ang.
   Возвращает tg (цель для выстрела). Вызывается из updatePlayer в том же месте; при window.__archOff=['A-26'] работает прежний текст. */
function aimStep(p,dt,man){
  let tg=man?null:pickTarget();G.tg90=man?G.aimLock:tg;if(!man){if(tg)G.noTg75=0;else tg=aimFallback(dt);}/* 0.7.5 */
  const sp=Math.hypot(p.vx,p.vy);
  let want;if(man){const m=mouseWorld();let L=G.aimLock;
    if(L&&(!aimLockable(L)||Math.hypot(m.x-L.x,m.y-L.y)>L.r+70))L=G.aimLock=null;
    if(!L){let bd=1e9;for(const e of G.enemies){if(!aimLockable(e))continue;const q=Math.hypot(m.x-e.x,m.y-e.y);if(q<e.r+26&&q<bd){bd=q;L=e;}}G.aimLock=L;}
    const T=L||m;want=Math.atan2(T.y-p.y,T.x-p.x);}else{G.aimLock=null;want=tg?Math.atan2(aimPt(tg).y-p.y,aimPt(tg).x-p.x):sp>20?Math.atan2(p.vy,p.vx):p.ang;}
  if(ARCH.a24)want=a24Want(p,tg,want,sp,dt,man);/* ARCH·80 A-24 */
  p.ang+=man?clamp(angDiff(want,p.ang)*Math.min(1,dt*18),-.45,.45):angDiff(want,p.ang)*Math.min(1,dt*14);
  return tg;}
/* ARCH·82 · условие автострельбы (шаг 14), вызывается после p.fireT-=dt, как и раньше; запросная функция — G не пишет */
function autoFireWanted(man,tg){return man?(MOUSE.down||G.enemies.some(e=>targetable(e)&&!NOAUTO.has(e.type))):!!tg;}
/* ARCH·83 · контролируемые точки записи (1.5.23). Внешний код меняет G.prio и G.aimLock только через эти три функции
   (или в зарегистрированных групповых сбросах Object.assign в setupMission0, startEndless, enterWorldAt). Логики сверх присваивания нет,
   возвращаемое значение не используется. Вызовы: kill (prioClear — ветка twin; prioSet(null) — основная, условие и счётчик prioKills снаружи),
   storyRetreat и loopIntercept80 (prioClear), startAnom (prioSet), startEndless (aimLockClear). Записи внутри подсистемы остаются прямыми. */
function prioSet(e){G.prio=e;}
function prioClear(e){if(G.prio===e)G.prio=null;}
function aimLockClear(){G.aimLock=null;}
/* ▲▲▲ ARCH·81 · КОНЕЦ ПОДСИСТЕМЫ НАВЕДЕНИЯ ▲▲▲ */
// --- утечка охлаждения: снаряды втрое медленнее ---
function leakK80(x,y){if(!G.world&&!inMission())return 1;const L=G.world?W80.near:(G.x80&&G.x80.leaks);if(!L||!L.length)return 1;for(const q of L)if((x-q.x)*(x-q.x)+(y-q.y)*(y-q.y)<q.r*q.r)return 1/3;return 1;}
// --- общий тик (миссия и мир) ---
function ens80(){if(!G.rcB80)G.rcB80=[];if(!G.echoBl80)G.echoBl80=[];if(!G.echoB80)G.echoB80=[];if(!G.echoQ80)G.echoQ80=[];if(!G.dmgN80)G.dmgN80=[];if(G.echoSeq80===undefined)G.echoSeq80=0;if(G.echoHitT80===undefined)G.echoHitT80=-99;if(G.rcDrop80===undefined){G.rcDrop80=0;G.rcLost80=0;}}
function c80Tick(dt){const p=G.player;if(!p)return;ens80();const S=G.save;if(S)w80S().clk+=dt;
  if(G.insp80>0){G.insp80-=dt;if(G.insp80By&&!G.insp80By.alive)G.insp80=0;}for(const e of G.enemies)if(e.insB80>0)e.insB80-=dt;
  if(G.inv80>0)G.inv80-=dt;if(G.slow80>0)G.slow80-=dt;if(p.hp<=0){G.inv80=0;G.slow80=0;}
  if(G.stamp80){const s=G.stamp80;if(p.hp<=0){G.stamp80=null;document.body.classList.remove('stamp80');}else if(p.dashT>0)stampOff80('РЫВОК');else{s.t-=dt;if(s.t<=0){G.stamp80=null;document.body.classList.remove('stamp80');if(G.mc)G.mc.stampBoom80=1;explode(p.x,p.y,'#ff7a3d',30,1);G.shock.push({x:p.x,y:p.y,r:10,R:90,t:0,col:'#ff7a3d'});sfx('boom');shake(6);
        damagePlayer(22);for(const o of G.enemies){if(!o.alive||o.spawnT>0||STATIC.has(o.type)||EDEF[o.type].sbp||EDEF[o.type].passive)continue;if(Math.hypot(o.x-p.x,o.y-p.y)<90+o.r)hurt(o,40,{force:true});}}}}
  // Утилизатор: подбираемое тянется спиралью
  for(const k of G.pick){if(!k.c80){k.c80=1;if(k.k==='xp'||k.k==='lom')G.rcDrop80=(G.rcDrop80||0)+1;}const e=k.rc80;if(!e)continue;if(!e.alive||e.hopper&&e.hopper.length>=12){k.rc80=null;k.noMag=k.k==='part80';continue;}
    if(p.hp>0&&Math.hypot(k.x-p.x,k.y-p.y)<(G.st.mag||0)*.6){k.rc80=null;k.noMag=k.k==='part80';continue;}
    const dx=e.x-k.x,dy=e.y-k.y,d=Math.hypot(dx,dy)||1;k.vx=dx/d*160-dy/d*60;k.vy=dy/d*160+dx/d*60;if(d<e.r){k.life=0;e.hopper.push({k:k.k,v:k.v||1});e.hopper0=Math.max(e.hopper0||0,e.hopper.length);}}
  // снаряды Утилизатора: промах — снова на пол
  const live=(G.rcB80.length||G.echoB80.length||G.echoBl80.length)?new Set(G.eb):null;G.live80=live;
  if(G.rcB80.length){for(const b of G.rcB80){if(b.life>0&&live.has(b))continue;const hitP=p.hp>0&&Math.hypot(b.x-p.x,b.y-p.y)<b.r+14;const it=b.rc80;b.rc80=null;
      if(hitP){if(it&&(it.k==='xp'||it.k==='lom'))G.rcLost80++;}else if(it){G.pick.push({k:it.k,x:clamp(b.x,10,BW-10),y:clamp(b.y,10,BH-10),vx:0,vy:0,r:it.k==='part80'?6:it.k==='cell'?9:5,t:0,life:it.k==='part80'?10:20,v:it.v||1,stab:it.k==='cell'?0:undefined,noMag:it.k==='part80'||it.k==='wreck85'});}}
    G.rcB80=G.rcB80.filter(b=>b.rc80&&b.life>0&&live.has(b));}
  echoTick80(dt);
  for(const n of G.dmgN80){n.t-=dt;n.y-=30*dt;}G.dmgN80=G.dmgN80.filter(n=>n.t>0);
  if(G.res80)res80Tick(dt);}
// --- Отзвук: запись и ответ ---
function echoTick80(dt){const p=G.player,E=G.enemies.filter(e=>e.alive&&e.type==='echo80'&&e.spawnT<=0);
  if(!E.length){if(G.echoQ80&&G.echoQ80.length)G.echoQ80.length=0;for(const b of G.pb)b.e80=1;return;}
  const Q=G.echoQ80||(G.echoQ80=[]);
  for(const b of G.pb){if(b.e80)continue;b.e80=1;if(b.drone||b.turret||b.jr||b.test||(b.age||0)>.08||Math.hypot(b.x-p.x,b.y-p.y)>60)continue;
    if(Q.length>=90)Q.shift();Q.push({t:G.t,seq:G.echoSeq80++,off:angDiff(Math.atan2(b.vy,b.vx),ARCH.a24?a24Hull(p):p.ang)/* ARCH·80 A-24 */,spd:Math.hypot(b.vx,b.vy),dmg:b.dmg,blast:b.blast?(b.R||110):0,charged:!!b.charged});}
  E.sort((a,c)=>a.uid-c.uid);const cap=[12,18,22][rankD80()];
  while(Q.length&&G.t-Q[0].t>=1){const r=Q.shift();const e=E[r.seq%E.length];e.rl=Math.min(12,(e.rl===undefined?12:e.rl));if(e.rl<1)continue;e.rl-=1;
    if(p.hp<=0)continue;const a=Math.atan2(p.y-e.y,p.x-e.x)+r.off;const b=shootE(e.x,e.y,a,Math.min(700,r.spd*.7),clamp(r.dmg*.4,2,cap),'#c9b6ff',r.charged?7:r.blast?6:4);
    if(b){b.ech80=1;G.echoB80.push(b);if(r.blast){b.bl80=r.blast*.6;G.echoBl80.push(b);}}}
  for(const e of E)e.rl=Math.min(12,(e.rl===undefined?12:e.rl)+12*dt);
  // попадания по игроку и взрывы «Разрыва»-копии
  const live=G.live80||new Set(G.eb);
  if(G.echoB80.length){for(const b of G.echoB80){if(b.life>0&&live.has(b))continue;if(p.hp>0&&Math.hypot(b.x-p.x,b.y-p.y)<b.r+14){b.e80h=1;G.echoHitT80=G.t;G.echoDmg80=(G.echoDmg80||0)+b.dmg;if(G.mc)G.mc.echoHit80=1;}b.e80d=1;}G.echoB80=G.echoB80.filter(b=>!b.e80d);}
  if(G.echoBl80.length){for(const b of G.echoBl80){if(b.life>0&&live.has(b))continue;if(b.bx80)continue;b.bx80=1;const R=b.bl80||60;explode(b.x,b.y,'#c9b6ff',14,.6);G.shock.push({x:b.x,y:b.y,r:6,R,t:0,col:'#c9b6ff',thin:true});
      if(p.hp>0&&p.dashT<=0&&Math.hypot(b.x-p.x,b.y-p.y)<R&&!b.e80h){damagePlayer(b.dmg*.5);G.echoHitT80=G.t;}}G.echoBl80=G.echoBl80.filter(b=>!b.bx80);}}
// --- Утилизатор: высыпать бункер ---
function rcRelease80(e,silent){const H_=e.hopper||[];if(!H_.length&&silent)return;const extra=silent?0:Math.ceil(H_.length*.15);
  for(const it of H_)G.pick.push({k:it.k,x:e.x+rnd(-16,16),y:e.y+rnd(-16,16),vx:rnd(-120,120),vy:rnd(-120,120),r:it.k==='part80'?6:it.k==='cell'?9:5,t:0,life:it.k==='part80'?10:22,v:it.v||1,noMag:it.k==='part80'});
  for(let i=0;i<extra;i++)G.pick.push(G.world?{k:'lom',x:e.x+rnd(-16,16),y:e.y+rnd(-16,16),vx:rnd(-120,120),vy:rnd(-120,120),r:5,t:0,life:30,v:1}:{k:'xp',x:e.x+rnd(-16,16),y:e.y+rnd(-16,16),vx:rnd(-120,120),vy:rnd(-120,120),r:5,t:0,life:22});
  if(!silent&&H_.length)floater(e.x,e.y-30,'УТИЛИЗАТОР ВСКРЫТ · +'+extra,'#ffb84d');e.hopper=[];}
// --- мишень полигона ---
function rangeHit80(e,dmg,src){const col=src.pulse||src.blast?'#e86bff':src.charged?'#8fe9ff':'#ffffff',now=G.t;e.flash=.07;sfx('hit');const R=W80.rlog||(W80.rlog=[]);R.push({t:now,v:dmg});W80.last=dmg;
  const N=G.dmgN80,mx=isMob()?12:40;const rec=N.filter(n=>now-n.at<.2&&n.r80===e);
  if(rec.length>=8){const n=rec[rec.length-1];n.v+=dmg;n.t=1;}else{if(N.length>=mx)N.shift();N.push({x:e.x+rnd(-14,14),y:e.y-e.r-8,v:dmg,col,t:1,at:now,r80:e});}}
// --- мирные/враждебные Паломники ---
function pilgrimHit80(e){const g=e.pg80;if(G.mc)G.mc.pilHit80=1;if(!g||g.hostile)return;if(g.tol>0){g.tol--;floater(e.x,e.y-24,'ОНИ СЧИТАЮТ ЭТО ОШИБКОЙ','#dfe8ff');return;}
  g.hostile=true;g.hostT=300;g.hitByP=1;for(const o of g.ships)if(o.alive){o.peace=false;o.hostile80=true;}floater(e.x,e.y-24,'ПАЛОМНИКИ: ТЫ НЕ ИЗ НАС','#ff4f6e');radioLine('ИСТОК','#6b8cff','…ты не из нас…',.1);sfx('warn');}
function pilgrimAI80(e,dt){const p=G.player,g=e.pg80;if(!g)return;if(e.hostile80&&g.hostile){const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,k=clamp((pd-300)/100,-1,1);steer(e,pdx/pd*k-pdy/pd*.5*e.dir,pdy/pd*k+pdx/pd*.5*e.dir,e.spd*1.4,dt,2);
    e.cd-=dt;if(e.cd<=0&&p.hp>0&&pd<700){e.cd=1.2;const a=Math.atan2(pdy,pdx);if(G.st&&G.st.weapon==='blast'){const b=shootE(e.x,e.y,a,380,7,'#dfe8ff',6);if(b){b.ech80=1;b.bl80=60;G.echoBl80.push(b);}}else{const n=Math.min(3,(G.st&&G.st.shots)||1);for(let i=0;i<n;i++)shootE(e.x,e.y,a+(i-(n-1)/2)*.12,590,6,'#dfe8ff',4);}}return;}
  const tx=g.dest.x+(e.fo||0)*.0,ty=g.dest.y;const dx=tx-e.x+(e.fx||0),dy=ty-e.y+(e.fy||0),d=Math.hypot(dx,dy)||1;steer(e,dx,dy,Math.min(60,d),dt,1.5);}
// --- спасённая копия (конвой) ---
function res80Tick(dt){const R=G.res80,p=G.player;if(!R)return;R.t-=dt;if(!G.world||sec80()!==6||p.hp<=0||R.t<=0){if(R.t<=0&&G.world)radioLine('КОПИЯ','#dfe8ff','Номера нет. Спасибо.',.2);G.res80=null;return;}
  R.a+=dt*1.4;const tx=p.x+Math.cos(R.a)*70,ty=p.y+Math.sin(R.a)*70;R.x+=(tx-R.x)*Math.min(1,dt*3);R.y+=(ty-R.y)*Math.min(1,dt*3);R.cd-=dt;
  if(R.cd<=0){const t_=nearestEnemy(R.x,R.y,460);if(t_&&t_.type!=='rangedummy'){R.cd=.6;const an=Math.atan2(t_.y-R.y,t_.x-R.x);G.pb.push({x:R.x,y:R.y,px:R.x,py:R.y,vx:Math.cos(an)*760,vy:Math.sin(an)*760,dmg:6*Math.max(1,playerDmgK()),pierce:0,rico:0,life:.7,hit:[],drone:true,jr:true});}else R.cd=.25;}}
// --- тик миссии ---
function t80Tick(dt){t85Tick(dt);t90Tick(dt);if(!inMission()||!G.x80)return;const X=G.x80,p=G.player;c80Tick(dt);const M=MISSIONS[G.m-1];if(G.endT>0||G.deadT>0){G.bo80=Math.max(0,G.bo80-dt);if(G.stamp80){G.stamp80=null;document.body.classList.remove('stamp80');}G.inv80=0;G.slow80=0;return;}
  // отключение света
  if(X.bo){const B=X.bo;if(B.st==='wait'){if(G.waveIdx>=2&&!G.sb){B.t+=dt;if(B.t>=(B.at||(B.at=rnd(6,18)))){B.st='warn';B.t=5;radioLine(X.sec===6?'БЮРО':'ИСТОК',X.sec===6?'#e8d27a':'#6b8cff',X.sec===6?'Смена окончена. Свет — по регламенту.':'…тише… слушай…',0);buzz('ready');}}}
    else if(B.st==='warn'){B.t-=dt;G.bo80=Math.sin(G.t*22)>.3?.45:0;if(B.t<=0){B.st='dark';B.t=20;}}
    else if(B.st==='dark'){B.t-=dt;G.bo80=1;d80H('dark','ТЕМНОТА · АВТОПРИЦЕЛ ВИДИТ ТОЛЬКО РЯДОМ','#e8d27a');if(B.t<=0){B.st='back';B.t=3;}}
    else if(B.st==='back'){B.t-=dt;G.bo80=clamp(B.t/3,0,1);if(B.t<=0){B.st='done';G.bo80=0;}}}
  if(X.leaks.length&&p.hp>0&&X.leaks.some(q=>Math.hypot(p.x-q.x,p.y-q.y)<q.r))d80H('leak','УТЕЧКА ОХЛАЖДЕНИЯ · СНАРЯДЫ ×3 МЕДЛЕННЕЕ','#bfe8ff');
  // Паломники через арену
  if(X.pil&&!X.pil.done&&G.mT>=X.pil.at&&!G.sb){X.pil.done=true;const g={hostile:false,tol:X.pil.tol,ships:[],dest:{x:W+120,y:H*.5}};X.pg=g;const y0=H*rnd(.3,.7);
    for(let i=0;i<3;i++){const e=spawnEnemy('pilgrim',-40-i*50,y0+(i-1)*46,{noAffix:true,noLoot:true,spawnT:.5});e.peace=true;e.pg80=g;e.fx=0;e.fy=(i-1)*46;g.ships.push(e);}
    floater(p.x,p.y-40,'ПАЛОМНИКИ · НЕ СТРЕЛЯТЬ','#dfe8ff');radioLine('ИСТОК','#6b8cff','…мы мимо. Мы не к тебе…',.3);}
  if(X.pg){for(const e of X.pg.ships)if(e.alive&&!e.hostile80&&e.x>W+60){e.alive=false;}}}
// ===== открытый мир секторов VII–VIII =====
const W80={gen:false,zones:[],pults:[],range:null,melt:null,leaks:[],near:[],nearT:0,alarm:null,dummy:null,rlog:[],last:0,radioT:0,boPh:-1};
function w80Gen(){if(W80.gen||!WORLD.sectors[7]||!G.save)return;W80.gen=true;const N=WORLD.nodes,ex=[...WORLD.shops,WORLD.hangar,WORLD.arsenal].filter(Boolean);
  const okAt=(x,y,dn,dp)=>w58Far(x,y,N,dn)&&w58Far(x,y,W80.zones,dp)&&w58Far(x,y,W80.pults,dp)&&w58Far(x,y,ex,800)&&inSectors(x,y)&&WORLD.sectors.every(sc=>!sc.bx||Math.hypot(x-sc.bx,y-sc.by)>900);
  const ZS=[[6,'КОНВОЙ «УТИЛИЗАЦИЯ»','convoy',28],[6,'РЕВИЗИЯ','audit',28],[7,'ПАЛОМНИКИ','pilgrims',32]];
  const pick=(sec,seed)=>{for(const [dn,dz] of [[1300,1700],[1300,1400],[1300,1150],[1150,1000]]){const R=mulberry(seed);const q=w58Pt(sec,R,(x,y)=>okAt(x,y,dn,dz),500);if(w58Far(q.x,q.y,N,dn)&&w58Far(q.x,q.y,W80.zones,dz))return q;}return pt80(sec,seed,(x,y,k)=>okAt(x,y,900*k,900*k),500);};
  ZS.forEach(([sec,name,k,after],i)=>{const q=pick(sec,8000+i*41);const z={x:q.x,y:q.y,home:{x:q.x,y:q.y},req:0,set:[],w58:1,sec,after,name,lead:null,reinf:{},idx:1200+i,k74:'x80',k80:k,cool:0};W80.zones.push(z);WORLD.zones.push(z);W58.zones.push(z);});
  const GZ=[[6,'СМЕНА',['labrat','defect','gunner'],['hunter',['armor']],28],[6,'БРАКОВКА',['defect','stamp','phantom'],['shade',['fast']],28],[7,'ОТРАЖЕНИЯ',['echo80','phantom','shocker'],['hunter',['armor']],32],[7,'ПЕТЛИ',['loop','gunner','mirror'],['shade',['boom']],32]];
  GZ.forEach(([sec,name,set,lead,after],i)=>{const q=pick(sec,8100+i*43);const z={x:q.x,y:q.y,req:0,set,w58:1,sec,after,name,lead,reinf:{},idx:1210+i,z80g:1};W80.zones.push(z);WORLD.zones.push(z);W58.zones.push(z);});
  for(let i=0;i<3;i++){const q=pt80(6,8200+i*17,(x,y,k)=>okAt(x,y,700*k,1500*k)&&w58Far(x,y,W80.pults,Math.max(900,1500*k)),400);W80.pults.push({x:q.x,y:q.y,i,ch:0});}
  {const q=pt80(6,8301,(x,y,k)=>okAt(x,y,900*k,1200*k)&&W80.zones.every(z=>Math.abs(x-z.x)>1500*k||Math.abs(y-z.y)>1100*k)&&W80.pults.every(p_=>Math.abs(p_.x-x)>560||Math.abs(p_.y-y)>460),600);W80.range={x:q.x,y:q.y,w:600,h:400};}
  {const cz=W80.zones[0];const q=pt80(6,8302,(x,y,k)=>okAt(x,y,800*k,900*k)&&Math.hypot(x-cz.x,y-cz.y)>1600*k&&!inRange80(x,y,250),500);W80.melt={x:q.x,y:q.y};}
  for(let i=0;i<7;i++){const q=pt80(6,8400+i*13,(x,y,k)=>w58Far(x,y,N,600*k)&&w58Far(x,y,W80.leaks,Math.max(450,700*k))&&inSectors(x,y)&&!inRange80(x,y,Math.max(250,400*k))&&w58Far(x,y,W80.pults,350),300);W80.leaks.push({x:q.x,y:q.y,r:220+Math.round(mulberry(8450+i)()*100)});}
  {const n38=N.find(n=>n.m===38),b=WORLD.sectors[7].box;W80.dest=n38?{x:n38.x,y:n38.y}:{x:(b[0]+b[2])/2,y:(b[1]+b[3])/2};}}
// размещение с постепенным ослаблением дистанций; в худшем случае — самая свободная точка (не центр сектора)
function pt80(sec,seed,fn,m){m=m||300;for(const k of [1,.8,.65,.5,.38,.27]){const q=w58Pt(sec,mulberry(seed),(x,y)=>fn(x,y,k),m);if(fn(q.x,q.y,k))return q;}
  const b=WORLD.sectors[sec].box,R=mulberry(seed+1),occ=[...WORLD.nodes,...W80.zones,...W80.pults,...W80.leaks,...(W80.range?[W80.range]:[]),...(W80.melt?[W80.melt]:[])];let best=null,bd=-1;
  for(let i=0;i<300;i++){const x=b[0]+m+R()*(b[2]-b[0]-2*m),y=b[1]+m+R()*(b[3]-b[1]-2*m);if(W80.range&&inRange80(x,y,200))continue;let d=1e9;for(const q of occ)d=Math.min(d,Math.hypot(q.x-x,q.y-y));if(d>bd){bd=d;best={x:Math.round(x),y:Math.round(y)};}}
  return best||{x:(b[0]+b[2])/2,y:(b[1]+b[3])/2};}
function inRange80(x,y,pad){const r=W80.range;if(!r)return false;return Math.abs(x-r.x)<r.w/2+pad&&Math.abs(y-r.y)<r.h/2+pad;}
function rangeGoal80(){const ws=w80S();return ws.rangeGoal||(ws.rangeGoal=Math.round(Math.max(60,(ws.rangeBest||0)*1.1)));}
function convoyRoute80(z){const b=WORLD.sectors[6].box,m=W80.melt,h=z.home,R=mulberry(8500+Math.floor((w80S().clk||0)/60));const pts=[];for(let i=1;i<=3;i++){const f=i/4;pts.push({x:clamp(h.x+(m.x-h.x)*f+(R()-.5)*900,b[0]+300,b[2]-300),y:clamp(h.y+(m.y-h.y)*f+(R()-.5)*900,b[1]+300,b[3]-300)});}pts.push({x:m.x,y:m.y});return pts;}
function w80ZoneSpawn(z){const p=G.player,R=(r)=>[z.x+rnd(-r,r),z.y+rnd(-r,r)];z.t80=0;z.out80=null;z.prov80=0;z.alarm=0;z.stealth=0;z.n=0;
  switch(z.k80){
    case 'convoy':{z.tug={x:z.home.x,y:z.home.y,i:0,route:convoyRoute80(z),ang:0};const bx=spawnEnemy('convoybox',z.home.x-46,z.home.y,{zone:z,noSec:true,noAffix:true,noLoot:true,spawnT:.6});bx.hp=bx.maxHp=600;z.box=bx;z.n++;
      for(const t of ['labrat','labrat','recycler','gunner','gunner'])w74Sp(z,t,...R(160),{convoy80:z});break;}
    case 'audit':{z.ap={x:z.home.x-800,y:z.home.y-500};z.wp=0;z.path=[];for(let r=0;r<5;r++){const y=z.home.y-500+r*250;z.path.push(r%2?{x:z.home.x+800,y}:{x:z.home.x-800,y},r%2?{x:z.home.x-800,y}:{x:z.home.x+800,y});}z.dir={x:1,y:0};
      for(let i=0;i<3;i++)w74Sp(z,'inspector',z.ap.x,z.ap.y+(i-1)*260,{audit80:z,ai80:i});break;}
    case 'pilgrims':{const g={hostile:false,tol:((G.save.story&&G.save.story.spared||0)>=5?1:0)+(storyFlag('line31')==='write'?1:0),ships:[],dest:W80.dest,hitByP:0};z.pg=g;z.esc=0;z.atkT=12;const n=4+Math.floor(Math.random()*3);
      for(let i=0;i<n;i++){const fx=((i%3)-1)*50,fy=(Math.floor(i/3)-.5)*50;const e=w74Sp(z,'pilgrim',z.home.x+fx,z.home.y+fy,{full:true,noSec:true});e.hp=e.maxHp=80;e.peace=true;e.pg80=g;e.fx=fx;e.fy=fy;g.ships.push(e);}break;}}}
function w80ZoneRadio(z){const L={convoy:['БЮРО','#e8d27a','Партия на переплавку. Сопровождение — по регламенту.'],audit:['БЮРО','#e8d27a','Плановая ревизия квадрата. Изделия — на места.'],pilgrims:['ИСТОК','#6b8cff','…мы идём. Ты тоже идёшь. Не мешай…']}[z.k80];
  if(z.z80g)radioLine(z.sec===6?'БЮРО':'ИСТОК',z.sec===6?'#e8d27a':'#6b8cff',z.sec===6?'Линия работает. Посторонним — покинуть цех.':'…повтори… повтори… повтори…',.4);else if(L)radioLine(L[0],L[1],L[2],.4);}
function convoyAI80(e,dt){const z=e.convoy80;if(!z||!z.active||z.prov80||!z.box||!z.box.alive)return false;const p=G.player;if(Math.hypot(p.x-z.box.x,p.y-z.box.y)<450)return false;
  const tx=z.box.x+Math.cos(e.seed)*90,ty=z.box.y+Math.sin(e.seed)*90;steer(e,tx-e.x,ty-e.y,Math.min(e.spd,140),dt,2);return true;}
function auditAI80(e,dt){const z=e.audit80;if(!z||!z.active||z.alarm)return false;const p=G.player,dx=z.dir.x,dy=z.dir.y,i=e.ai80||0;
  const tx=z.ap.x-dy*(i-1)*260,ty=z.ap.y+dx*(i-1)*260;steer(e,tx-e.x,ty-e.y,Math.min(Math.max(e.spd*1.6,90),Math.hypot(tx-e.x,ty-e.y)*3+40),dt,3);
  e.ca=Math.atan2(dy,dx)+Math.sin(G.t*.8+i)*.44;const dark=G.bo80>=.5,len=dark?260:420;e.clen=len;const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy);
  const see=p.hp>0&&pd<len&&Math.abs(angDiff(Math.atan2(pdy,pdx),e.ca))<.436&&e.spawnT<=0;const need=rankD80()===0?1.2:sbHard()?.5:.8;
  if(see)e.seeT=(e.seeT||0)+dt;else e.seeT=Math.max(0,(e.seeT||0)-dt*2);if(e.seeT>=need){e.seeT=0;e.cool80=5;insAlarm80(e);}return true;}
function alarmAI80(e,dt){const q=e.alarm80;if(!q||!W80.alarm||W80.alarm.st!=='on'){e.alarm80=null;return false;}const d=Math.hypot(q.x-e.x,q.y-e.y);if(d<180)return false;steer(e,q.x-e.x,q.y-e.y,e.spd,dt,2);return true;}
function w80ZoneTick(dt){const p=G.player;for(const z of W80.zones){if(!z.k80)continue;
    if(!z.active){if(z.home&&(z.x!==z.home.x||z.y!==z.home.y)){z.x=z.home.x;z.y=z.home.y;}z.tug=null;z.box=null;continue;}
    z.t80=(z.t80||0)+dt;const mine=G.enemies.filter(e=>e.alive&&e.zone===z);
    if(z.k80==='convoy'&&z.tug){const T=z.tug,B=z.box;if(!z.prov80&&mine.some(e=>e.hp<e.maxHp-.5))z.prov80=1;
      const halt=W80.alarm&&W80.alarm.st==='on'&&W80.pults[W80.alarm.i]&&Math.hypot(T.x-W80.pults[W80.alarm.i].x,T.y-W80.pults[W80.alarm.i].y)<2000;
      if(B&&B.alive&&!halt&&!z.out80){const q=T.route[T.i];if(q){const dx=q.x-T.x,dy=q.y-T.y,d=Math.hypot(dx,dy);if(d<20)T.i++;else{T.x+=dx/d*55*dt;T.y+=dy/d*55*dt;T.ang=Math.atan2(dy,dx);}}
        else{z.out80='melted';for(const e of mine)e.alive=false;radioLine('БЮРО','#e8d27a','Партия списана.',.1);floater(p.x,p.y-40,'КОНТЕЙНЕР НА ПЕРЕПЛАВКЕ','#ff7a3d');}}
      if(B&&B.alive){B.x=T.x-Math.cos(T.ang)*46;B.y=T.y-Math.sin(T.ang)*46;B.vx=B.vy=0;}
      else if(B&&!B.alive&&!z.out80)convoyBroken80(z,B);
      z.x=T.x;z.y=T.y;}
    if(z.k80==='audit'&&z.ap){if(!z.alarm&&mine.some(e=>e.hp<e.maxHp-.5)){z.alarm=1;z.stealth=1;}
      if(!z.alarm){const q=z.path[z.wp%z.path.length],dx=q.x-z.ap.x,dy=q.y-z.ap.y,d=Math.hypot(dx,dy);if(d<20)z.wp++;else{z.ap.x+=dx/d*70*dt;z.ap.y+=dy/d*70*dt;z.dir={x:dx/d,y:dy/d};}}
      z.x=z.ap.x;z.y=z.ap.y;}
    if(z.k80==='pilgrims'&&z.pg){const g=z.pg,live=g.ships.filter(e=>e.alive);
      if(live.length){const cx=live.reduce((a,e)=>a+e.x,0)/live.length,cy=live.reduce((a,e)=>a+e.y,0)/live.length;z.x=cx;z.y=cy;
        if(!g.hostile){if(p.hp>0&&Math.hypot(p.x-cx,p.y-cy)<500)z.esc+=dt;z.atkT-=dt;
          if(z.atkT<=0&&z.t80<120){z.atkT=20;for(let i=0;i<2;i++){const a=rnd(0,TAU);w74Sp(z,Math.random()<.5?'echo80':'loop',cx+Math.cos(a)*420,cy+Math.sin(a)*420,{pilgAtk:z});}floater(cx,cy-40,'НА ПАЛОМНИКОВ НАПАЛИ','#ff4f6e');}
          for(const e of mine){if(!e.pilgAtk||e.tr80>0)continue;e.pat80=(e.pat80===undefined?1:e.pat80)-dt;if(e.pat80<=0){let t_=null,td=320;for(const o of live){const q=Math.hypot(o.x-e.x,o.y-e.y);if(q<td){td=q;t_=o;}}if(t_){e.pat80=1.4;x74().tracers.push({x1:e.x,y1:e.y,x2:t_.x,y2:t_.y,t:.18,c:EDEF[e.type].col});t_.hp-=12;t_.flash=.1;if(t_.hp<=0){t_.alive=false;explode(t_.x,t_.y,'#dfe8ff',12,.6);g.lost=(g.lost||0)+1;}}else e.pat80=.3;}}
          if(Math.hypot(cx-g.dest.x,cy-g.dest.y)<160){const atk=mine.filter(e=>e.pilgAtk&&e.alive).length;z.out80=z.esc>=40&&!atk?'escorted':'passed';for(const e of mine)e.alive=false;}}
        else if(!live.some(e=>e.hostile80))z.out80='killed';}
      else if(!z.out80)z.out80=g.hostile?'killed':'lost';}}}
function convoyBroken80(z,B){z.out80='broken';G.res80={x:B.x,y:B.y,a:0,cd:.5,t:120};floater(B.x,B.y-30,'КОПИЯ СПАСЕНА · ЛЕТИТ С ВАМИ 2 МИН','#dfe8ff');radioLine('КОПИЯ','#dfe8ff','…я с тобой. Недолго.',.3);conEvent('convoyBreak');conEvent('rescue80');sfx('level');}
function w80ZoneDone(z){if(z.k80==='convoy'&&!z.out80&&z.box)convoyBroken80(z,z.box);if(z.k80==='pilgrims'&&!z.out80)z.out80=z.pg&&z.pg.hostile?'killed':'lost';const S=G.save,p=G.player,ws=w80S(),zd=ws.zd||(ws.zd={}),first=!zd[z.k80];zd[z.k80]=1;z.active=false;z.cool=240;let v=Math.round((first?10+z.n*3:3)*3),msg='ПАТРУЛЬ РАЗБИТ';
  if(z.k80==='convoy'){if(z.out80==='melted'){v=0;msg='ПАРТИЯ СПИСАНА · НАГРАДЫ НЕТ';}else{v+=60;msg='КОНВОЙ РАЗБИТ · КОПИЯ СПАСЕНА';}}
  if(z.k80==='audit'&&z.stealth){v+=30;msg='РЕВИЗИЯ НЕ ЗАМЕТИЛА';conEvent('auditStealth');}
  if(z.k80==='pilgrims'){const g=z.pg||{};if(z.out80==='escorted'){if(storyFlag('well38')==='silence')conEvent('exodus85');v=30;msg='ПАЛОМНИКИ ДОШЛИ · ГОЛОС ИСТОКА';const k=ws.voices||0;if(storyFlag('well38')==='silence'){}else if(k<VOICES80.length){toast('ГОЛОС ИСТОКА '+(k+1)+'/'+VOICES80.length,VOICES80[k]);ws.voices=k+1;}else radioLine('ИСТОК','#6b8cff',VOICES80[Math.floor(Math.random()*VOICES80.length)],.2);if(!g.hitByP)conEvent('pilgrimsSafe');}
    else if(z.out80==='killed'){v=0;msg='ЗВЕНО УНИЧТОЖЕНО';}else{v=0;msg=z.out80==='lost'?'ПАЛОМНИКИ ПОГИБЛИ':'ПАЛОМНИКИ ПРОШЛИ';}
    if(storyFlag('fleet27')==='engine'&&!ws.karr&&z.out80==='escorted'){ws.karr=1;radioLine('ПАЛОМНИК','#dfe8ff','Карр жив. Он тоже летит сюда.',2);}}
  if(z.home){z.x=z.home.x;z.y=z.home.y;}z.tug=null;z.box=null;z.pg=null;
  if(v>0){S.carry+=v;if(first)addPilotXP(25);}floater(p.x,p.y-40,msg+(v>0?' · +'+v+' ЛОМА'+(first?'':' · ПОВТОР'):''),'#c9d2de');sfx('level');if(v>0){conEvent('patrol');conEvent('patrol');}if(G.event==='zone')G.event=null;saveWorld();return true;}
// --- мировой тик ---
function w80WorldTick(dt){const S=G.save,p=G.player;if(!S||!p)return;w80Gen();if(!W80.gen)return;w85WorldTick(dt);w90WorldTick(dt);const ws=w80S();c80Tick(dt);w80ZoneTick(dt);
  const sec=sec80();
  if(sec>=0&&!ws.seen[sec]){ws.seen[sec]=1;if(sec===6)radioLine('БЮРО','#e8d27a','Цех «Предел». Изделие вне партии обнаружено. Вернуть на линию.',1);else radioLine('ИСТОК','#6b8cff','…ты дошёл. Все доходят. Не все возвращаются…',1);}
  // свет по циклу сектора
  if(sec>=0&&!(sec===6&&storyFlag('line31')==='break')){const cyc=sec===6?[150,5,40,3]:[120,5,45,3],L=cyc[0]+cyc[1]+cyc[2]+cyc[3],ph=((ws.clk||0)+(sec===6?0:90))%L;let st,k;
    if(ph<cyc[0]){st=0;k=0;}else if(ph<cyc[0]+cyc[1]){st=1;k=Math.sin(G.t*22)>.3?.45:0;}else if(ph<cyc[0]+cyc[1]+cyc[2]){st=2;k=1;}else{st=3;k=clamp(1-(ph-cyc[0]-cyc[1]-cyc[2])/cyc[3],0,1);}
    if(st===1&&W80.boPh!==1){radioLine(sec===6?'БЮРО':'ИСТОК',sec===6?'#e8d27a':'#6b8cff',sec===6?'Смена окончена. Свет — по регламенту.':'…тише… слушай…',0);buzz('ready');}W80.boPh=st;G.bo80=k;}
  else{G.bo80=Math.max(0,G.bo80-dt*2);W80.boPh=-1;}
  // утечки рядом
  W80.nearT-=dt;if(W80.nearT<=0){W80.nearT=.5;W80.near=W80.leaks.filter(q=>Math.hypot(q.x-p.x,q.y-p.y)<1700);}
  if(p.hp>0&&W80.near.some(q=>Math.hypot(p.x-q.x,p.y-q.y)<q.r))d80H('leak','УТЕЧКА ОХЛАЖДЕНИЯ · СНАРЯДЫ ×3 МЕДЛЕННЕЕ','#bfe8ff');
  // пульты тревоги
  for(const q of W80.pults){const ready=(ws.clk||0)>=(ws.alarmAt[q.i]||0);if(ready&&!W80.alarm&&p.hp>0&&Math.hypot(p.x-q.x,p.y-q.y)<44){q.ch+=dt;if(q.ch>=.6){q.ch=0;W80.alarm={i:q.i,st:'count',t:10,sec:10};floater(q.x,q.y-40,'ТРЕВОГА ЧЕРЕЗ 10 С','#ff4f6e');sfx('warn');buzz('ready');}}else q.ch=0;}
  if(W80.alarm){const A=W80.alarm,q=W80.pults[A.i];A.t-=dt;
    if(A.st==='count'){const s=Math.ceil(A.t);if(s!==A.sec){A.sec=s;if(Math.hypot(p.x-q.x,p.y-q.y)<2200){floater(q.x,q.y-40,'ТРЕВОГА · '+s,'#ff4f6e');if(s<=5)buzz('tap');}}
      if(A.t<=0){A.st='on';A.t=60;radioLine('БЮРО','#e8d27a','Изделие вне партии. Всем постам.',0);sfx('bigboom');shake(6);}}
    else if(A.st==='on'){for(const e of G.enemies){if(!e.alive||EDEF[e.type].passive||STATIC.has(e.type)||e.alarm80)continue;if(sectorIdx(e.x,e.y)===6&&Math.hypot(e.x-q.x,e.y-q.y)<2000)e.alarm80=q;}
      if(A.t<=0){for(const e of G.enemies)e.alarm80=null;ws.alarmAt[A.i]=(ws.clk||0)+rnd(1200,1800);W80.alarm=null;saveWorld();}}}
  // полигон
  const r=W80.range;if(r){const d=Math.hypot(p.x-r.x,p.y-r.y);const dm=W80.dummy;
    if(d<900&&(!dm||!dm.alive)){W80.dummy=spawnEnemy('rangedummy',r.x,r.y,{noSec:true,noAffix:true,noLoot:true,spawnT:.3});W80.dummy.hp=W80.dummy.maxHp=1000;}
    else if(d>1400&&dm&&dm.alive){dm.alive=false;W80.dummy=null;}
    for(const e of G.enemies){if(!e.alive||e.type==='rangedummy'||STATIC.has(e.type))continue;if(inRange80(e.x,e.y,e.r)){const dx=e.x-r.x,dy=e.y-r.y,ox=r.w/2+e.r-Math.abs(dx),oy=r.h/2+e.r-Math.abs(dy);if(ox<oy)e.x+=Math.sign(dx||1)*ox;else e.y+=Math.sign(dy||1)*oy;}}
    const now=G.t;W80.rlog=W80.rlog.filter(q=>now-q.t<5);if(W80.rlog.length){const t0=Math.max(1,Math.min(5,now-W80.rlog[0].t+.25));const dps=Math.round(W80.rlog.reduce((a,q)=>a+q.v,0)/t0);W80.dps=dps;
      if(now-W80.rlog[0].t>=2&&dps>(ws.rangeBest||0)){ws.rangeBest=dps;W80.rec=1;}if(now-W80.rlog[0].t>=2&&S.contracts&&S.contracts.list.some(c=>c.tid==='c_range80')&&dps>=rangeGoal80()){conEvent('rangeDps');delete ws.rangeGoal;}
      W80.radioT-=dt;if(W80.radioT<=0&&now-W80.rlog[0].t>=3){W80.radioT=30;radioLine('СТЕНД','#e8d27a','Урон в секунду: '+dps+'. '+(W80.rec?'Выше нормы.':'Норма.'),0);W80.rec=0;}}else W80.dps=0;
    if(inRange80(p.x,p.y,0))d80H('range','СТЕНД ИСПЫТАНИЙ · БЕЙТЕ ПО МИШЕНИ','#e8d27a');}}
// ===== отрисовка =====
function leakDraw80(q,t){const g=ctx.createRadialGradient(q.x,q.y,q.r*.2,q.x,q.y,q.r);g.addColorStop(0,'rgba(191,232,255,.16)');g.addColorStop(1,'rgba(191,232,255,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(q.x,q.y,q.r,0,TAU);ctx.fill();
  ctx.strokeStyle='#dff6ff';ctx.globalAlpha=.35;ctx.lineWidth=1.5;ctx.setLineDash([3,7]);ctx.lineDashOffset=t*8;ctx.beginPath();for(let i=0;i<=28;i++){const a=i/28*TAU,rr=q.r*(1+.04*Math.sin(a*6+t*1.5));ctx.lineTo(q.x+Math.cos(a)*rr,q.y+Math.sin(a)*rr);}ctx.closePath();ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.globalAlpha=1;}
// под врагами: утечки, рельсы
function d80Under(t){sb85Under(t);under90(t);under110(t);const L=G.world?W80.near:(G.x80&&G.x80.leaks);if(L)for(const q of L)if(!G.world||inView(q.x,q.y,q.r))leakDraw80(q,t);
  for(const e of G.enemies){if(!e.alive||e.type!=='railshield'||!e.rail)continue;const R_=e.rail;ctx.strokeStyle='#c9d2de';ctx.globalAlpha=.3;ctx.lineWidth=2;ctx.setLineDash([10,8]);ctx.beginPath();ctx.moveTo(R_.x-R_.ux*220,R_.y-R_.uy*220);ctx.lineTo(R_.x+R_.ux*220,R_.y+R_.uy*220);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}}
// над врагами
function d80Draw(t){draw90(t);draw110(t);const p=G.player;if(!p)return;
  for(const k of G.pick){if(k.k!=='part80')continue;ctx.save();ctx.translate(k.x,k.y);ctx.rotate(k.t*2);ctx.globalAlpha=k.life<3?(Math.sin(k.life*14)>0?1:.3):1;ctx.fillStyle='#1a2030';ctx.strokeStyle='#c9d2de';ctx.lineWidth=1.5;ctx.fillRect(-5,-3,10,6);ctx.strokeRect(-5,-3,10,6);ctx.restore();ctx.globalAlpha=1;}
  for(const k of G.pick){if(!k.rc80||!k.rc80.alive)continue;ctx.strokeStyle='#9fb0c4';ctx.globalAlpha=.35;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(k.x,k.y);ctx.lineTo(k.rc80.x,k.rc80.y);ctx.stroke();ctx.globalAlpha=1;}
  for(const e of G.enemies){if(!e.alive)continue;
    if(e.insB80>0&&!EDEF[e.type].passive){ctx.strokeStyle='#ffd36b';ctx.globalAlpha=.6;ctx.lineWidth=1.5;ctx.strokeRect(e.x-e.r-4,e.y-e.r-4,e.r*2+8,e.r*2+8);ctx.globalAlpha=1;}
    switch(e.type){
      case 'labrat':if(e.beam&&e.beam.alive){const b=e.beam;ctx.strokeStyle='#7affc9';ctx.globalAlpha=.55+.3*Math.sin(t*16);ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.globalAlpha=1;glow(b.x,b.y,b.r*1.6,'#7affc9',.3);}break;
      case 'inspector':if(e.ca!==undefined&&e.spawnT<=0){const len=e.clen||420,k=Math.min(1,(e.seeT||0)/.8);ctx.fillStyle=k>0?`rgba(255,211,107,${.12+.16*k})`:'rgba(255,211,107,.08)';ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.arc(e.x,e.y,len,e.ca-.436,e.ca+.436);ctx.closePath();ctx.fill();
        ctx.strokeStyle='#ffd36b';ctx.globalAlpha=.4;ctx.lineWidth=1;ctx.stroke();ctx.globalAlpha=1;if(e.seeT>0){ctx.strokeStyle='#ffd36b';ctx.lineWidth=3;ctx.beginPath();ctx.arc(p.x,p.y,p.r+10,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();}}break;
      case 'defect':if(e.mode){const c=DEF_COL80[e.mode];worldLabel(e.x,e.y-e.r-12,DEF_TXT80[e.mode],c);if(e.mode==='ram'&&e.rst==='aim'&&!G.noTele){const T0=.8,lk=e.rt<=.22;teleLane(e.x,e.y,e.aim,420*.6*(G.eSpd||1),e.r+14,1-clamp(e.rt/T0,0,1),lk,'#ff4f6e',{r:e.r+2,flash:lk?Math.max(0,1-(.22-e.rt)/.12):0});}}break;
      case 'recycler':{const n=e.hopper?e.hopper.length:0;if(n)worldLabel(e.x,e.y-e.r-12,'БУНКЕР '+n+'/12','#ffb84d');if(e.fire80>0&&!G.noTele){glow(e.x,e.y,e.r*2,'#ffd36b',.4+.4*Math.sin(t*30));}break;}
      case 'echo80':{const q=G.echoQ80?G.echoQ80.length:0;ctx.strokeStyle='#b48cff';ctx.globalAlpha=.5;ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+8,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,q/12));ctx.stroke();ctx.globalAlpha=1;break;}
      case 'loop':if(e.tr80>0){ctx.strokeStyle='#6b8cff';ctx.globalAlpha=.4+.3*Math.sin(t*8);ctx.lineWidth=2;ctx.setLineDash([4,5]);ctx.beginPath();ctx.arc(e.x,e.y,e.r+6,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=.9;ctx.lineWidth=3;ctx.beginPath();ctx.arc(e.x,e.y,e.r+12,-Math.PI/2,-Math.PI/2+TAU*(1-e.tr80/5));ctx.stroke();ctx.globalAlpha=1;worldLabel(e.x,e.y-e.r-18,'СЛЕД · '+Math.ceil(e.tr80),'#6b8cff');}
        else if(e.win80>0&&e.win80<90&&e.spawnT<=0){ctx.strokeStyle='#ffffff';ctx.globalAlpha=.7;ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+7,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,e.win80/2));ctx.stroke();ctx.globalAlpha=1;}
        if(e.lr80){for(let i=0;i<e.lr80;i++){ctx.fillStyle='#6b8cff';ctx.beginPath();ctx.arc(e.x-6+i*6,e.y+e.r+7,2,0,TAU);ctx.fill();}}break;
      case 'inverse':if(e.itel>0&&!G.noTele){ctx.strokeStyle='#e86bff';ctx.globalAlpha=.8;ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+40*(e.itel/1),0,TAU);ctx.stroke();ctx.globalAlpha=1;}if(e.iw){ctx.strokeStyle='#e86bff';ctx.globalAlpha=.7*(1-e.iw.r/380);ctx.lineWidth=5;ctx.beginPath();ctx.arc(e.iw.x,e.iw.y,e.iw.r,0,TAU);ctx.stroke();ctx.globalAlpha=1;}break;
      case 'pilgrim':if(!e.hostile80)worldLabel(e.x,e.y-e.r-12,'ПАЛОМНИК','#dfe8ff');break;
      case 'convoybox':worldLabel(e.x,e.y-e.r-12,'НА СПИСАНИЕ','#e8d27a');ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(e.x-24,e.y+e.r+6,48,4);ctx.fillStyle='#e8d27a';ctx.fillRect(e.x-24,e.y+e.r+6,48*Math.max(0,e.hp/e.maxHp),4);break;}}
  // штамп на корабле
  if(G.stamp80&&p.hp>0){const s=G.stamp80,k=s.t/s.max;ctx.strokeStyle='#ff7a3d';ctx.lineWidth=3;ctx.globalAlpha=.9;ctx.beginPath();ctx.arc(p.x,p.y,p.r+12,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();ctx.globalAlpha=1;worldLabel(p.x,p.y-p.r-24,'ПРОВЕРЕНО · '+Math.ceil(s.t)+' · РЫВОК','#ff7a3d');}
  // Изнанка: рамка и значок
  if((G.inv80>0||G.slow80>0)&&p.hp>0){const k=(G.inv80||G.slow80)/2;ctx.strokeStyle='#e86bff';ctx.globalAlpha=.55;ctx.lineWidth=6;ctx.strokeRect(CX+3,CY+3,W-6,H-6);ctx.globalAlpha=1;ctx.lineWidth=2;ctx.beginPath();ctx.arc(p.x,p.y,p.r+16,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();worldLabel(p.x,p.y+p.r+26,G.inv80>0?'⇄ '+G.inv80.toFixed(1):'ЗАМЕДЛЕНИЕ','#e86bff');}
  // спасённая копия
  if(G.res80){const R_=G.res80;ctx.save();ctx.translate(R_.x,R_.y);ctx.rotate(R_.a+Math.PI/2);ctx.strokeStyle='#dfe8ff';ctx.fillStyle='#0b0f18';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(9,0);ctx.lineTo(-6,-6);ctx.lineTo(-3,0);ctx.lineTo(-6,6);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
  // числа урона
  ctx.textAlign='center';ctx.font='700 '+fpx(isMob()?17:12)+'px "JetBrains Mono",monospace';for(const n of G.dmgN80||[]){ctx.globalAlpha=Math.min(1,n.t*2);ctx.fillStyle='#04060c';ctx.fillText(String(Math.round(n.v)),n.x+1,n.y+1);ctx.fillStyle=n.col;ctx.fillText(String(Math.round(n.v)),n.x,n.y);}ctx.globalAlpha=1;
  // снаряды в утечке — иней
  const L=G.world?W80.near:(G.x80&&G.x80.leaks);if(L&&L.length&&SET.fx){ctx.fillStyle='rgba(223,246,255,.35)';for(const b of G.pb)if(leakK80(b.x,b.y)<1){ctx.beginPath();ctx.arc(b.x,b.y,5,0,TAU);ctx.fill();}for(const b of G.eb)if(leakK80(b.x,b.y)<1){ctx.beginPath();ctx.arc(b.x,b.y,b.r+3,0,TAU);ctx.fill();}}}
// мир: пульты, полигон, переплавка, конвой
function w80Draw(t){if(!W80.gen)return;const ws=w80S(),p=G.player;w85Draw(t);w90Draw(t);
  for(const q of W80.pults){if(!inView(q.x,q.y,120))continue;const ready=(ws.clk||0)>=(ws.alarmAt[q.i]||0),act=W80.alarm&&W80.alarm.i===q.i,col=act?'#ff4f6e':ready?'#ff7a3d':'#6b7280';
    glow(q.x,q.y,40,col,act?.5+.4*Math.sin(t*12):ready?.35:.12);ctx.save();ctx.translate(q.x,q.y);ctx.fillStyle='#10141c';ctx.strokeStyle=col;ctx.lineWidth=2;ctx.fillRect(-16,-12,32,24);ctx.strokeRect(-16,-12,32,24);ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,6,0,TAU);ctx.fill();
    if(q.ch>0){ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,26,-Math.PI/2,-Math.PI/2+TAU*q.ch/.6);ctx.stroke();}ctx.restore();
    const sub=act?(W80.alarm.st==='count'?'ТРЕВОГА ЧЕРЕЗ '+Math.ceil(W80.alarm.t):'ТРЕВОГА · '+Math.ceil(W80.alarm.t)+' С'):ready?'ВСЕМ ПОСТАМ · ДЕРЖИТЕ 0,6 С':'ПЕРЕЗАРЯДКА · '+fmtMS80((ws.alarmAt[q.i]||0)-(ws.clk||0));worldLabel(q.x,q.y-30,'ПУЛЬТ ТРЕВОГИ',col);worldLabel(q.x,q.y+34,sub,col);}
  const r=W80.range;if(r&&inView(r.x,r.y,r.w)){ctx.strokeStyle='#e8d27a';ctx.globalAlpha=.5;ctx.lineWidth=2;ctx.setLineDash([12,8]);ctx.strokeRect(r.x-r.w/2,r.y-r.h/2,r.w,r.h);ctx.setLineDash([]);ctx.globalAlpha=.08;ctx.fillStyle='#e8d27a';ctx.fillRect(r.x-r.w/2,r.y-r.h/2,r.w,r.h);ctx.globalAlpha=.25;
    for(let i=1;i<4;i++){ctx.beginPath();ctx.moveTo(r.x-r.w/2+i*r.w/4,r.y-r.h/2);ctx.lineTo(r.x-r.w/2+i*r.w/4,r.y+r.h/2);ctx.stroke();}ctx.globalAlpha=1;
    worldLabel(r.x,r.y-r.h/2-30,'СТЕНД ИСПЫТАНИЙ','#e8d27a');worldLabel(r.x,r.y-r.h/2-12,'ПОСЛЕДНЕЕ '+Math.round(W80.last||0)+' · УРОН/С '+(W80.dps||0)+' · РЕКОРД '+(ws.rangeBest||0),'#e8d27a');}
  const m=W80.melt;if(m&&inView(m.x,m.y,200)){glow(m.x,m.y,110,'#ff7a3d',.35+.15*Math.sin(t*2));ctx.strokeStyle='#ff7a3d';ctx.lineWidth=3;ctx.beginPath();ctx.arc(m.x,m.y,60,0,TAU);ctx.stroke();worldLabel(m.x,m.y-80,'ПЕРЕПЛАВКА','#ff7a3d');}
  for(const z of W80.zones){if(!z.active)continue;
    if(z.k80==='convoy'&&z.tug){const T=z.tug;ctx.strokeStyle='#e8d27a';ctx.globalAlpha=.25;ctx.setLineDash([6,10]);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(T.x,T.y);for(let i=T.i;i<T.route.length;i++)ctx.lineTo(T.route[i].x,T.route[i].y);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
      if(inView(T.x,T.y,80)){ctx.save();ctx.translate(T.x,T.y);ctx.rotate(T.ang);ctx.fillStyle='#10141c';ctx.strokeStyle='#c9d2de';ctx.lineWidth=2;ctx.fillRect(-18,-11,36,22);ctx.strokeRect(-18,-11,36,22);ctx.restore();if(z.box&&z.box.alive){ctx.strokeStyle='#c9d2de';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(T.x,T.y);ctx.lineTo(z.box.x,z.box.y);ctx.stroke();}}}
    if(z.k80==='audit'&&z.ap&&!z.alarm&&inView(z.ap.x,z.ap.y,900)){ctx.strokeStyle='#ffd36b';ctx.globalAlpha=.12;ctx.lineWidth=1;ctx.strokeRect(z.home.x-820,z.home.y-520,1640,1040);ctx.globalAlpha=1;}}}
function fmtMS80(s){s=Math.max(0,Math.ceil(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0');}
// карта
function w80MapAdd(add,lod,S){w80Gen();if(!W80.gen)return;w90MapAdd(add,lod,S);if(storyFlag('well38')==='third'){const q=w85Node();if(q)add('sig85',q.x,q.y,{},lod===2?{t:'СИГНАЛ ЗА ПРЕДЕЛОМ · СКОРО',p:6,c:'#ffffff'}:null);}for(const q of W80.pults)if(revealedAt(q.x,q.y))add('pult80',q.x,q.y,{},lod===2?{t:'ПУЛЬТ ТРЕВОГИ',p:6,c:'#ff7a3d'}:null);
  if(W80.range&&revealedAt(W80.range.x,W80.range.y))add('range80',W80.range.x,W80.range.y,{},lod===2?{t:'СТЕНД',p:6,c:'#e8d27a'}:null);
  if(W80.melt&&revealedAt(W80.melt.x,W80.melt.y))add('melt80',W80.melt.x,W80.melt.y,{},lod===2?{t:'ПЕРЕПЛАВКА',p:6,c:'#ff7a3d'}:null);}
function w80MapIcon(g,kind,o,t){if(w90MapIcon(g,kind,o,t))return true;if(kind==='sig85'){g.strokeStyle='#ffffff';g.beginPath();g.arc(0,0,6,0,TAU);g.stroke();g.beginPath();g.arc(0,0,2,0,TAU);g.stroke();return true;}switch(kind){case 'pult80':g.strokeStyle='#ff7a3d';g.strokeRect(-4,-3,8,6);return true;case 'range80':g.strokeStyle='#e8d27a';g.strokeRect(-6,-4,12,8);g.beginPath();g.moveTo(0,-4);g.lineTo(0,4);g.stroke();return true;case 'melt80':g.strokeStyle='#ff7a3d';g.beginPath();g.arc(0,0,5,0,TAU);g.stroke();return true;}return false;}
// маска отключения света: видно рядом с кораблём, снаряды врагов и вспышки
let c80=null,c80x=null;
function w80Mask(ox,oy){const k0=G.bo80||0;if(k0<=.01||!G.player)return;const lo=isMob()?.5:Math.min(.5,Math.sqrt(9e5/Math.max(1,cv.width*cv.height)));const w_=Math.ceil(cv.width*lo),h_=Math.ceil(cv.height*lo);
  if(!c80||c80.width!==w_||c80.height!==h_){c80=document.createElement('canvas');c80.width=w_;c80.height=h_;c80x=c80.getContext('2d');}
  const g=c80x,k=DPR*SC*lo,p=G.player,R=Math.max(300,Math.min(W,H)*.4);g.globalCompositeOperation='source-over';g.clearRect(0,0,w_,h_);g.fillStyle=`rgba(1,2,7,${((SET.fx?.88:.55)*k0).toFixed(3)})`;g.fillRect(0,0,w_,h_);g.globalCompositeOperation='destination-out';
  const hole=(x,y,r)=>{const X=(x+ox)*k,Y=(y+oy)*k,RR=r*k;if(X<-RR||Y<-RR||X>w_+RR||Y>h_+RR)return;const gr=g.createRadialGradient(X,Y,RR*.35,X,Y,RR);gr.addColorStop(0,'rgba(0,0,0,1)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.beginPath();g.arc(X,Y,RR,0,TAU);g.fill();};
  hole(p.x,p.y,R);holes85(hole,(y0,y1)=>{const Y0=(y0+oy)*k,Y1=(y1+oy)*k;if(Y0>h_)return;const gr=g.createLinearGradient(0,Y0,0,Y1);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(0,0,0,1)');g.fillStyle=gr;g.fillRect(0,Y0,w_,h_-Y0);});let n=0;for(const b of G.eb){if(n>=80)break;hole(b.x,b.y,16);n++;}n=0;for(const s of G.shock){if(n>=24)break;hole(s.x,s.y,Math.max(30,s.r));n++;}
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(c80,0,0,cv.width,cv.height);ctx.restore();}
// рисунки новых врагов (из drawE74; true = нарисован)
function drawE80(e,t,icon,col,face,alpha,P){if(D90T.has(e.type))return drawE90(e,t,icon,col,face,alpha,P);if(SB85T.has(e.type))return drawE85(e,t,icon,col,face,alpha,P);if(!S80T.has(e.type))return false;const r=e.r;
  switch(e.type){
    case 'labrat':ctx.rotate(face);ctx.beginPath();ctx.arc(0,0,r*.8,0,TAU);ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-r*.5,0);ctx.lineTo(r*.5,0);ctx.moveTo(0,-r*.5);ctx.lineTo(0,r*.5);ctx.stroke();for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(r*.6,s*r*.4);ctx.lineTo(r*1.2,s*r*.8);ctx.stroke();}break;
    case 'defect':{const c=icon?col:(e.mT!==undefined&&e.mT<.5&&Math.sin(t*40)>0?'#ffffff':DEF_COL80[e.mode||'shoot']);ctx.strokeStyle=e.flash>0?'#ffffff':c;ctx.rotate(face+(e.mode==='ram'&&e.aim!==undefined?angDiff(e.aim,face):0));
      ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(r*.2,-r*.9);ctx.lineTo(-r*.7,-r*.5);ctx.lineTo(-r,r*.2);ctx.lineTo(-r*.3,r*.9);ctx.lineTo(r*.5,r*.6);ctx.closePath();ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-r*.3,-r*.4);ctx.lineTo(r*.1,r*.3);ctx.stroke();break;}
    case 'inspector':ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();{const a=icon?0:(e.ca||0);ctx.fillStyle=col;ctx.beginPath();ctx.arc(Math.cos(a)*r*.45,Math.sin(a)*r*.45,r*.35,0,TAU);ctx.fill();ctx.strokeStyle=col;ctx.beginPath();ctx.arc(0,0,r*.65,0,TAU);ctx.stroke();}break;
    case 'railshield':{const a=icon?0:(e.fa||0);ctx.rotate(a);ctx.fillStyle=e.shieldFlash>0?'#ffffff':'#141a26';ctx.fillRect(-6,-30,12,60);ctx.strokeRect(-6,-30,12,60);ctx.strokeStyle=col;ctx.globalAlpha=alpha*.6;for(let i=-2;i<=2;i++){ctx.beginPath();ctx.moveTo(-6,i*11);ctx.lineTo(6,i*11+4);ctx.stroke();}ctx.globalAlpha=alpha;
      if(!icon){ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(-14,-38,28,4);ctx.fillStyle=col;ctx.fillRect(-14,-38,28*Math.max(0,e.hp/e.maxHp),4);}break;}
    case 'stamp':ctx.rotate(t*3);ctx.beginPath();for(let i=0;i<8;i++){const a=i/8*TAU,rr=i%2?r*.6:r;ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,r*.3,0,TAU);ctx.fill();break;
    case 'recycler':{ctx.rotate(face);ctx.beginPath();ctx.moveTo(r,-r*.4);ctx.lineTo(r,r*.4);ctx.lineTo(-r*.8,r*.8);ctx.lineTo(-r,0);ctx.lineTo(-r*.8,-r*.8);ctx.closePath();ctx.fill();ctx.stroke();const n=e.hopper?e.hopper.length:0;ctx.fillStyle='#ffb84d';for(let i=0;i<Math.min(6,Math.ceil(n/2));i++)ctx.fillRect(-r*.6+i*5,-2,3,4);
      ctx.strokeStyle=col;ctx.beginPath();ctx.arc(r*.9,0,r*.35,-1.2,1.2);ctx.stroke();break;}
    case 'echo80':{ctx.globalAlpha=alpha*(.75+.25*Math.sin(t*6+e.seed));ctx.rotate(icon?-Math.PI/2:Math.atan2(P.y-e.y,P.x-e.x));ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(-r*.8,-r*.7);ctx.lineTo(-r*.4,0);ctx.lineTo(-r*.8,r*.7);ctx.closePath();ctx.fill();ctx.stroke();ctx.setLineDash([3,3]);ctx.beginPath();ctx.arc(0,0,r*1.25,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=alpha;break;}
    case 'loop':{if(e.tr80>0&&!icon){ctx.globalAlpha=alpha*.3;}ctx.rotate(t*2*(e.dir||1));ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(-r*.35,0,r*.55,r*.4,0,0,TAU);ctx.stroke();ctx.beginPath();ctx.ellipse(r*.35,0,r*.55,r*.4,0,0,TAU);ctx.stroke();ctx.lineWidth=2;ctx.globalAlpha=alpha;break;}
    case 'inverse':{ctx.rotate(-t*2);ctx.beginPath();ctx.moveTo(0,-r);ctx.lineTo(r,0);ctx.lineTo(0,r);ctx.lineTo(-r,0);ctx.closePath();ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-r*.5,-r*.2);ctx.lineTo(r*.5,-r*.2);ctx.moveTo(r*.5,r*.2);ctx.lineTo(-r*.5,r*.2);ctx.stroke();break;}
    case 'pilgrim':{ctx.rotate(icon?-Math.PI/2:face);ctx.strokeStyle=e.hostile80?'#ff4f6e':col;ctx.beginPath();ctx.moveTo(r,0);ctx.lineTo(-r*.8,-r*.7);ctx.lineTo(-r*.4,0);ctx.lineTo(-r*.8,r*.7);ctx.closePath();ctx.fill();ctx.stroke();if(!e.hostile80){glow(0,0,r*1.4,'#dfe8ff',.2);}break;}
    case 'rangedummy':{ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();ctx.beginPath();ctx.arc(0,0,r*.6,0,TAU);ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,r*.22,0,TAU);ctx.fill();break;}
    case 'convoybox':{ctx.fillStyle='#1a1a10';ctx.fillRect(-r,-r*.7,r*2,r*1.4);ctx.strokeRect(-r,-r*.7,r*2,r*1.4);ctx.beginPath();ctx.moveTo(-r,-r*.7);ctx.lineTo(r,r*.7);ctx.moveTo(r,-r*.7);ctx.lineTo(-r,r*.7);ctx.globalAlpha=alpha*.5;ctx.stroke();ctx.globalAlpha=alpha;break;}}
  return true;}
// ===== музыка секторов VII–VIII: «Бюро» и «Исток», тёмные варианты, плавная смена =====
SC_.s6={name:'Предел · бюро',root:41,v:[[0,7,14,17],[-2,5,12,14],[0,7,10,14],[-5,2,7,14]],chordT:[10,16],pad:['sawtooth',360,900,.026],sub:.085,noise:['bandpass',1400,.01,.05],bell:['metal',8,14,.02],rev:.32,alert:1,vol:.7,bpm:96,mech:1};
SC_.s6d={name:'Предел · без света',root:41,v:[[0,7,14,17],[-2,5,12,14]],chordT:[14,20],pad:['triangle',260,520,.03],sub:.1,noise:['lowpass',380,.016,.04],bell:['metal',12,20,.014],rev:.45,alert:1,vol:.66,bpm:96,relay:1};
SC_.s7={name:'Исток · хор',root:36,v:[[0,7,12,19],[5,12,17,24],[-2,5,14,19],[0,7,14,19]],chordT:[14,22],pad:['sine',500,1300,.05],sub:.07,noise:['bandpass',900,.008,.04],bell:['glass',9,15,.022],rev:.62,alert:1,vol:.72,bpm:60,vib:[4.6,9],choir:1};
SC_.s7d={name:'Исток · один голос',root:36,v:[[0,12,19,24]],chordT:[20,30],pad:['sine',420,800,.035],sub:.06,noise:['lowpass',300,.01,.03],bell:['glass',14,22,.016],rev:.7,alert:1,vol:.62,bpm:60,vib:[4.2,7]};
SC_.mx6=Object.assign({},SC_.mx6,{name:'Бой · Предел',root:41,bpm:102,metal:1,heavy:1,mech:1,brass:.03});SC_.mx6d=Object.assign({},SC_.mx6,{name:'Бой · Предел без света',pad:['triangle',260,600,.03],toms:'fight',heavy:0,relay:1,brass:0});
SC_.mx7=Object.assign({},SC_.mx7,{name:'Бой · Исток',root:36,bpm:66,vib:[4.6,9],pulse:'q',brass:.025});SC_.mx7d=Object.assign({},SC_.mx7,{name:'Бой · Исток во тьме',pad:['sine',380,700,.03],brass:0});
function scape80(P,c,t){const S=P.sc;if(!S.vib||!P.pad)return;const l=c.createOscillator();l.frequency.value=S.vib[0];const lg=c.createGain();lg.gain.value=S.vib[1];l.connect(lg);for(const v of P.pad)if(v&&v.o)lg.connect(v.o.detune);vStart(l,t);P.nodes.push(l);}
function step80(P,t,st,bar){const S=P.sc,X=P.ext||{},root=S.root+(P.semi||0);step85(P,t,st,bar);step90(P,t,st,bar);
  if(S.mech&&!X.darkOff&&!X.mechOff){if(st===0||st===6||st===10)evNoise(t,.07,.05,P.L.toms,'lowpass',420);if(st===4||st===12)evNoise(t,.04,.03,P.L.tick,'bandpass',3600,9);if(st===14&&bar%2===0)ev(t,mtof(root+24),.18,'square',.012,P.L.fx,.004);}
  if(S.relay&&st%8===3&&Math.random()<.5)evNoise(t,.02,.03,P.L.tick,'highpass',5200);
  if(S.choir&&!X.choirOff&&st===0&&bar%2===0){const iv=P.chord[Math.random()*P.chord.length|0];ev(t,mtof(root+24+iv),3.2,'sine',.018,P.L.bell,.6,null,rnd(-.5,.5));tonal(t,P.id);}
  if(X.siren&&(st===0||st===8)){ev(t,mtof(root+30),.9,'triangle',.03,P.L.fx,.05,mtof(root+33));}}
const SECSC80=new Set(['s6','s7','s6d','s7d','mx6','mx7','mx6d','mx7d']);
function mus80(T){const st=G.state;if(SECSC80.has(T.id)){if(G.bo80>=.5&&SC_[T.id+'d'])T.id=T.id+'d';}
  if(W80.alarm&&G.world)T.ext.siren=1;
  // гистерезис на границе секторов: новая тема — через 2 с в новом секторе
  if(G.world&&st==='world'&&/^s\d+d?$/.test(T.id)){const base=T.id.replace('d','');const H_=MUS.h80||(MUS.h80={id:base,since:G.t});if(H_.cand!==base){H_.cand=base;H_.since=G.t;}if(base!==H_.id&&G.t-H_.since>=2)H_.id=base;if(base!==H_.id){const keep=H_.id+(T.id.endsWith('d')&&SC_[H_.id+'d']?'d':'');if(SC_[keep])T.id=keep;}}
  return mus90(mus85(T));}
function fade80(cur,id,fade){if(!cur)return fade;{const f85=fade85(cur.id,id);if(f85)return f85;}const a=cur.id,b=id;if(SECSC80.has(a)||SECSC80.has(b)){const ba=a.replace(/d$/,''),bb=b.replace(/d$/,'');if(ba===bb)return 3;if(/^s\d+$/.test(ba)&&/^s\d+$/.test(bb))return 6;}return fade;}
// --- миссии VIII: не больше 2 Изнанок за миссию и 1 в волне ---
for(let m=32;m<=38;m++){const M=MISSIONS[m-1];if(!M||!M.wavesT)continue;let n=0;for(const wv of M.wavesT){let k=0;for(let i=0;i<wv.length;i++){if(wv[i]==='inverse'){if(n>=2||k>=1)wv[i]='loop';else{n++;k++;}}}}}
// --- мастерство миссий 28–37 ---
Object.assign(MASTERY,{27:{t:'Порвать луч Лаборанта рывком',ok:()=>!!G.mc&&!!G.mc.beam80},28:{t:'Ни разу не взорваться штампом',ok:()=>!!G.mc&&!G.mc.stampBoom80},29:{t:'Ни разу не вызвать «нарушение регламента»',ok:()=>!!G.mc&&!G.mc.seen80},
  31:{t:'Ни разу не получить от себя же',ok:()=>!!G.mc&&!G.mc.echoHit80},32:{t:'Разорвать все Петли с первого раза',ok:()=>!!G.mc&&(G.mc.loopK80||0)>0&&!G.mc.loopBad80},33:{t:'Ни разу не попасть под волну Изнанки',ok:()=>!!G.mc&&!G.mc.inv80},
  34:{t:'Импульсом стереть память Отзвука',ok:()=>!!G.mc&&!!G.mc.echoWipe80},35:{t:'Не задеть ни одного Паломника',ok:()=>!!G.mc&&!G.mc.pilHit80},36:{t:'Уничтожить 10 врагов в темноте',ok:()=>!!G.mc&&(G.mc.dark80||0)>=10}});


// ===== 0.8.5 «Лекало и Колодец»: боссы секторов VII–VIII — каркас =====
const SB85T=new Set(['lekalo','lpart','blank85','serial85','wellcore','wemit','anchor85','ghost85','note85']);
['lekalo','lpart','blank85','wellcore','wemit','anchor85','ghost85','note85'].forEach(k=>STATIC.add(k));
['lekalo','lpart','wellcore','wemit','anchor85'].forEach(k=>HEAVY.add(k));
['blank85','serial85','ghost85','note85','anchor85'].forEach(k=>H74.add(k));
SB85T.forEach(k=>STORY_NORETREAT.add(k));
// 0.9: реестр новых боссов на каркасе 0.8.5 (Сердце, Берег). Лекало и Колодец идут прежними ветками.
const SBX={},HOST85=new Set(['lekalo','wellcore']),AI85X={},HURT85X={},KILL85X={};
function sbx(b){return b&&SBX[b.sbk]||null;}
SB_NAMES.lek='ЛЕКАЛО';SB_NAMES.well='ПЕРВЫЙ СИГНАЛ';
Object.assign(SB_FLAG,{lek:'line31',well:'well38'});Object.assign(SB_FLAG_M,{31:'line31',38:'well38'});
SB_DEATH.lek=['ЛИНИЯ ОСТАНОВЛЕНА','СЕКТОР VII ПРОЙДЕН','Цех ноль закрыт. Дальше — без меня.'];SB_DEATH.well=['СИГНАЛ ПРИНЯТ','СЕКТОР VIII ПРОЙДЕН','Дальше сигнал не ведёт.'];
const LEK_PH=['ПРИЁМКА','СБОРКА','ОТК','СПИСАНИЕ'],WELL_PH=['СИГНАЛ','ЗОВ','ЭХО','ПЕТЛЯ','ТИШИНА'];
const C85={lek:'#e8d27a',well:'#6b8cff',voidc:'#dfe8ff',red:'#ff4f6e',hot:'#ff7a3d',pil:'#dfe8ff'};
// общая прочность относительно «Последнего довода» (EDEF.*.hp = 12 500 — как у флагмана); подобрано ботами
const K85={lek:1.15,well:1.3};
function is85(b){return !!b&&(b.sbk==='lek'||b.sbk==='well'||!!SBX[b.sbk]);}
function sb85(){const b=G.sb;return b&&b.alive&&is85(b)?b:null;}
function rk85(){return curDiff().rank||0;}
function pk85(a,b,c){const r=rk85();return r<=0?a:r===1?b:c;}
function tl85(){return G.noTele?.5:1;}
function x85(){return G.x85||(G.x85={rk:{},bl:[],trk:[],calm:0,stun:0,cs:0,tap:0,tapUsed:0});}
function fmt85(v){return (Math.max(0,v)).toFixed(1).replace('.',',');}
// радио боя: не чаще одной реплики в 6 с; ключ — своя пауза; force — фазовые реплики
function say85(tag,col,txt,o){o=o||{};const X=x85();if(!o.force){if(X.rLast&&G.t-X.rLast<6)return false;if(o.key){const R=X.rk;if(R[o.key]&&G.t-R[o.key]<(o.cd||20))return false;R[o.key]=G.t;}}X.rLast=G.t;radioLine(tag,col,txt,o.d||0);return true;}
function RB85(t,o){return say85('БЮРО',C85.lek,t,o);}
function RI85(t,o){return say85('ИСТОК',C85.well,t,o);}
// --- появление ---
function sb85Spawn(kind){if(SBX[kind])return SBX[kind].spawn();ambSting('boss');radioClear();const lek=kind==='lek';
  const b=spawnEnemy(lek?'lekalo':'wellcore',W/2,lek?-220:H/2,{noAffix:true,noLoot:true});sb85Init(b,kind,lek?4:5);
  if(lek){banner('ЛЕКАЛО · ЦЕХ №0','ФАЗА 0 · ПРИЁМКА');RB85('Изделие 013 поступило. Основание: возврат.',{force:1,d:.6});}
  else{banner('ПЕРВЫЙ СИГНАЛ','ИСТОЧНИК НЕ ОПОЗНАН');RI85('…я у самого дна… если слышишь — лети на голос…',{force:1,d:1.6});}
  return b;}
function sb85Init(b,kind,enterT){const lek=kind==='lek',XX=SBX[kind];const P=Math.round(EDEF[b.type].hp*(XX?XX.K:K85[kind])*sbRank()*cycHp()*(rk85()>=2&&!XX?.85:1));
  b.hp=b.maxHp=P;b.th=XX?XX.th.slice():lek?[.7,.4]:[.7,.4,.15];
  Object.assign(b,{sbk:kind,phase:1,st:'enter',timer:enterT,enterT,t:0,rot:0,flash:0,open:0,inv0:0,fails:0,choice:null,domeFlash:0,deathT:0,noAffix:true,noLoot:true,docks:null,tr:0,dmgT:G.t,phT:0,parts:[],t0:G.t});
  G.sb=b;const X=x85();X.b=b;X.calm=0;X.done=0;if(XX){if(G.mc)G.mc[XX.mc]=1;XX.init(b);return;}if(G.mc)G.mc[lek?'lek85':'well85']=1;
  if(lek)lekInit(b);else wellInit(b);}
// --- общий урон по «телу»: пул прочности, пороги фаз, пол для частей ---
function pool85(b,d,fk,e){if(!(d>0)||!b||b.st!=='fight'||b.inv0>0)return 0;const fl=fk?b.maxHp*fk:0;let nd=d;
  if(b.hp-nd<fl){nd=Math.max(0,b.hp-fl);if(nd<d&&b.sbk==='lek'&&!b.floorHint){b.floorHint=1;floater(b.x,b.y-70,'РАМА ДЕРЖИТ · БЕЙТЕ В МАТРИЦУ','#ffffff');}
    if(nd<d&&b.sbk==='well'&&b.phase>=4&&!b.floorHint){b.floorHint=1;floater(b.x,b.y-70,'СЛУШАЙТЕ','#dfe8ff');}
    if(nd<d&&SBX[b.sbk]&&!b.floorHint){const ft=SBX[b.sbk].floorTxt&&SBX[b.sbk].floorTxt(b);if(ft){b.floorHint=1;floater(b.hx!==undefined?b.hx:b.x,(b.hy!==undefined?b.hy:b.y)-70,ft,'#ffffff');}}}
  if(nd<=0){if(e)e.domeFlash=.1;return 0;}b.hp-=nd;b.flash=.07;if(e)e.flash=.07;sfx('hit');b.dmgT=G.t;sb85CheckTh(b);return nd;}
function sb85CheckTh(b){if(!(b.hp>=1))b.hp=1;if(b.st!=='fight')return;const th=b.th;
  if(b.phase<=th.length){const lim=b.maxHp*th[b.phase-1];if(b.hp<=lim){b.hp=lim;sb85Phase(b);}return;}
  if(b.hp<=1)sb85Final(b);}
function sb85Phase(b){ambSting('phase');b.phase++;b.inv0=2.5;b.tr=2.5;b.phT=0;b.floorHint=0;G.eb=G.eb.filter(x=>x.rift);const X=x85();X.calm=Math.max(X.calm||0,2.5);X.bl=[];
  G.shock.push({x:b.hx!==undefined?b.hx:b.x,y:b.hy!==undefined?b.hy:b.y,r:20,R:Math.max(W,H),t:0,col:EDEF[b.type].col,slow:true});sfx('bigboom');shake(10);buzz('ready');if(typeof hs90==='function')hs90(.12,1);
  if(SBX[b.sbk])SBX[b.sbk].phase(b);else if(b.sbk==='lek')lekPhase(b);else wellPhase(b);}
function sb85Hurt(e,dmg,src){src=src||{};const b=G.sb,host=HOST85.has(e.type);
  if(!b||!b.alive||!is85(b)||(!host&&e.host85!==b))return host?0:dmg;
  if(b.st!=='fight'||b.inv0>0||e.spawnT>0){sbBlock(e);return 0;}
  if(SBX[b.sbk])return SBX[b.sbk].hurt(b,e,dmg,src);return b.sbk==='lek'?lekHurt(b,e,dmg,src):wellHurt(b,e,dmg,src);}
function sb85Targetable(e){const b=G.sb,host=HOST85.has(e.type);if(!b||!b.alive||!is85(b)||(!host&&e.host85!==b))return !host;
  if(b.st!=='fight'||e.spawnT>0||e.corona)return false;if(SBX[b.sbk])return SBX[b.sbk].targ?SBX[b.sbk].targ(b,e):true;if(e.type==='lpart'&&e.role==='core')return lekCoreOpen(b);return true;}
function sb85Auto(p,b){if(b.sbk==='lek'&&lekCoreOpen(b)&&targetable(b.core)&&Math.hypot(b.core.x-p.x,b.core.y-p.y)<900)return b.core;if(SBX[b.sbk]&&SBX[b.sbk].auto0){const q=SBX[b.sbk].auto0(p,b);if(q)return q;}const near=nearestEnemy(p.x,p.y,210);if(near&&!near.host85&&near!==b&&near.type!=='anchor85')return near;if(SBX[b.sbk])return SBX[b.sbk].auto(p,b);return b.sbk==='lek'?lekAuto(p,b):wellAuto(p,b);}
function sb85Hud(b){const k=SB_NAMES[b.sbk];if(SBX[b.sbk])return SBX[b.sbk].hud(b,k);if(b.st==='dying')return k+(b.sbk==='lek'?' · ЛИНИЯ СТОИТ':' · СИГНАЛ ПРИНЯТ');if(b.st==='final')return k+' · ВЫБОР';if(b.st==='scene')return k+(b.sbk==='lek'?' · ЗАПИСЬ':' · СВЯЗЬ');if(b.st==='enter')return k;
  return b.sbk==='lek'?lekHud(b):wellHud(b);}
function sb85Update(b,dt){if(sbCommon(b,dt)){if(b.fx85){b.fx85.t+=dt;dying85(b,dt);}return;}if(b.tr>0)b.tr-=dt;if(SBX[b.sbk])SBX[b.sbk].update(b,dt);else if(b.sbk==='lek')lekUpdate(b,dt);else wellUpdate(b,dt);}
// --- финал: сцена (монолог) → выбор у причалов ---
function sb85Final(b){if(b.st!=='fight')return;b.st='scene';b.hp=1;b.inv0=0;b.scT=0;b.docks=null;b.dockT=0;G.eb=G.eb.filter(x=>x.rift);const X=x85();X.calm=99;X.bl=[];X.trk=[];radioClear();
  for(const o of G.enemies.slice()){if(!o.alive||o===b||o.host85===b&&(o.type==='lpart'||o.type==='wemit'||o.keep85))continue;if(o.type==='pilgrim'){o.alive=false;continue;}kill(o,true);}
  if(G.stamp80){G.stamp80=null;document.body.classList.remove('stamp80');}G.inv80=0;G.slow80=0;G.latch74=null;
  sfx('level');buzz('boss');if(typeof hs90==='function')hs90(.25,2);if(SBX[b.sbk])SBX[b.sbk].final(b);else if(b.sbk==='lek')lekFinal(b);else wellFinal(b);}
function sub85(cap,col,lines,onDone){const X=x85();X.sub={cap,col,lines,i:0,t:0,onDone};X.tapUsed=X.tap;}
function subDur85(s){return Math.max(2.2,s.length*.045);}
function subTick85(dt){const X=G.x85,S=X&&X.sub;if(!S)return;S.t+=dt;const line=S.lines[S.i];if(line===undefined){X.sub=null;if(S.onDone)S.onDone();return;}
  if(S.t>=subDur85(line)||(S.t>=.6&&X.tap&&X.tap!==X.tapUsed)){X.tapUsed=X.tap;S.i++;S.t=0;if(S.i>=S.lines.length){X.sub=null;if(S.onDone)S.onDone();}}}
window.addEventListener('pointerdown',()=>{if(G.x85&&G.x85.sub)G.x85.tap=performance.now();},{passive:true});
window.addEventListener('keydown',e=>{if(G.x85&&G.x85.sub&&(e.code==='Space'||e.code==='Enter'||e.code==='KeyF'||e.code==='KeyE'))G.x85.tap=performance.now();});
function sb85Docks(b,dt){const p=G.player;if(!b.docks||!p||p.hp<=0)return false;b.dockT=(b.dockT||0)+dt;
  for(const d of b.docks){if(d.off||d.lock)continue;if(b.dockT>.6&&Math.hypot(p.x-d.x,p.y-d.y)<48){d.ch+=dt;if(d.ch>=.6){sbChoose(b,d.kind);return true;}}else d.ch=Math.max(0,d.ch-dt*2);}return false;}
// разнос причалов по горизонтали: на узком экране телефона (портрет) — ближе к центру, чтобы подписи не уходили за край
function dock85dx(k){const vw=typeof VW==='number'&&VW>0?VW:W;return Math.min(170*(k||1),vw*.22);}
function sb85SetDocks(b,list){const prev=G.mode==='world'?storyFlag(SB_FLAG[b.sbk]):null;b.docks=list.map(d=>Object.assign({ch:0},d));
  for(const d of b.docks){d.x=clamp(d.x,70,W-70);d.y=clamp(d.y,70,H-70);if(prev){if(d.kind===prev)d.prev=true;else d.off=true;}}b.dockT=0;b.prev85=prev||null;}
function sb85Choose(b,ch){if(b.choice||(b.st!=='final'&&b.st!=='scene'&&b.st!=='fight'))return;const S=G.save,world=G.mode==='world'&&!!S&&!!S.story;
  const prev=world?storyFlag(SB_FLAG[b.sbk]):null;const opts=SBX[b.sbk]?SBX[b.sbk].opts(b):b.sbk==='lek'?['break','write']:third85(b)?['silence','answer','third']:['silence','answer'];
  if(prev)ch=prev;else if(!ch||!opts.includes(ch))ch=opts[Math.random()*opts.length|0];
  b.choice=ch;b.docks=null;b.fx85={kind:ch,t:0};x85().calm=99;x85().sub=null;
  if(SBX[b.sbk])SBX[b.sbk].choose(b,ch,world,prev);else if(b.sbk==='lek')lekChoose(b,ch,world,prev);else wellChoose(b,ch,world,prev);
  sbDeath(b);}
// --- ИИ сущностей 0.8.5 (из s74Update0) ---
function s85Update(e,dt,c){if(AI85X[e.type]){AI85X[e.type](e,dt,c);return true;}switch(e.type){
    case 'lekalo':case 'wellcore':{if(!e.sbk){if(G.sb&&G.sb!==e&&G.sb.alive){e.alive=false;return true;}sb85Init(e,e.type==='lekalo'?'lek':'well',1);}e.vx=e.vy=0;sb85Update(e,dt);return true;}
    case 'lpart':case 'wemit':{e.vx=e.vy=0;if(!e.host85||!e.host85.alive||G.sb!==e.host85)kill(e,true);return true;}
    case 'serial85':serialAI85(e,dt,c);return true;
    case 'blank85':e.vx=e.vy=0;return true;
    case 'ghost85':ghostAI85(e,dt);return true;
    case 'note85':noteAI85(e,dt);return true;
    case 'anchor85':e.vx=e.vy=0;return true;}
  return false;}
function s85Hurt(e,dmg,src){if(HURT85X[e.type])return HURT85X[e.type](e,dmg,src||{});if(e.type==='anchor85'){const b=sb85();if(b&&(b.inv0>0||b.st!=='fight')){sbBlock(e);return 0;}}return dmg;}
function s85Killed(e,silent){if(KILL85X[e.type]){KILL85X[e.type](e,silent);return;}const b=G.sb&&is85(G.sb)?G.sb:null;if(!b)return;
  switch(e.type){
    case 'lpart':if(!silent&&b.alive&&b.sbk==='lek'&&e.host85===b)lekPartDied(b,e);break;
    case 'wemit':if(!silent&&b.alive&&b.sbk==='well'&&e.host85===b)wellEmitDied(b,e);break;
    case 'blank85':if(b.sbk==='lek')lekBlankGone(b,e,silent);break;
    case 'ghost85':if(b.sbk==='well'&&!silent&&b.alive)wellGhostDied(b,e);break;
    case 'anchor85':if(b.sbk==='well'&&!silent&&b.alive)wellAnchorDied(b,e);break;}}
// снаряды игрока (до общих попаданий; true — поглощён)
function b85Hit(bu){if(bu.a85)a85Pass(bu);const b=sb85();if(!b)return false;if(SBX[b.sbk])return SBX[b.sbk].bullet?SBX[b.sbk].bullet(b,bu):false;return b.sbk==='lek'?lekBullet(b,bu):wellBullet(b,bu);}
// снаряды союзников 0.8.5 пролетают мирных Паломников насквозь (их ошибки — не ваши)
function a85Pass(bu){for(const e of G.enemies){if(!e.alive||e.type!=='pilgrim'||e.hostile80||(e.pg85&&e.pg85.st==='hostile')||bu.hit.includes(e))continue;if(segDist(bu.px,bu.py,bu.x,bu.y,e.x,e.y)<e.r+8)bu.hit.push(e);}}
// импульс
function pulse85(p,R){const X=G.x85;
  if(inMission()&&G.mode==='world'&&X&&!X.cs&&storyFlag('well38')==='answer'){X.cs=1;p.shieldUp=true;p.shieldT=0;p.inv=Math.max(p.inv||0,2);floater(p.x,p.y-48,'ПОЗЫВНОЙ · ЩИТ',C85.voidc);sfx('cell');}
  if(G.world&&typeof w85Pulse==='function')w85Pulse(p,R);
  const b=sb85();if(!b)return;if(SBX[b.sbk]){if(SBX[b.sbk].pulse)SBX[b.sbk].pulse(b,p,R);return;}if(b.sbk==='lek')lekPulse(b,p,R);else wellPulse(b,p,R);}
// движение корабля после ввода: конвейеры, хват, печь, колодец, оглушение
function drift85(p,dt){const X=G.x85;if(!X||!inMission())return;
  if(X.stun>0){X.stun-=dt;if(p.dashT>0)X.stun=0;else{p.x=p.px;p.y=p.py;}}
  const b=sb85();if(!b)return;if(SBX[b.sbk]){if(SBX[b.sbk].drift)SBX[b.sbk].drift(b,p,dt);}else if(b.sbk==='lek')lekDrift(b,p,dt);else wellDrift(b,p,dt);
  p.x=clamp(p.x,p.r,BW-p.r);p.y=clamp(p.y,p.r,BH-p.r);}
// --- миссия ---
function t85Init(M){G.x85={rk:{},bl:[],trk:[],calm:0,stun:0,cs:0,tap:0,tapUsed:0,b:null,ally:null,sub:null,done:0,self:0};
  if(G.mode==='endless'||!M||!M.gen)return;const m=G.m;
  if(m>=32&&m<=37&&storyFlag('well38')==='silence'&&G.mode==='world')thin85();}
// «Заглушить»: в миссиях 32–37 Отзвуков и Петель на 25% меньше
function thin85(){let n=0;for(const wv of G.waves||[])for(let i=wv.length-1;i>=0;i--){if(wv[i]==='echo80'||wv[i]==='loop'){if(n++%4===0)wv.splice(i,1);}}}
function t85Tick(dt){const X=G.x85;if(!X||!inMission())return;if(X.calm>0)X.calm-=dt;if(X.silence>0)X.silence-=dt;if(X.rew>0)X.rew-=dt;
  const b=G.sb&&is85(G.sb)?G.sb:null;if(b&&!b.alive&&!X.done){X.done=1;clean85();}
  bl85Tick(dt);if(X.ally)ally85Tick(dt);subTick85(dt);hud85();}
function clean85(){const X=G.x80;if(X&&X.leaks)X.leaks=X.leaks.filter(q=>!q.w85);const Y=G.x85;if(Y){Y.bl=[];Y.trk=[];Y.stun=0;}}
function r85Reset(){G.x85=null;const el=document.getElementById('b85G');if(el)el.hidden=true;tick85(false);}
// взрывы «Разрыва»-копий и учёт попаданий своих же копий
function bl85Tick(dt){const X=G.x85,p=G.player;if(!X||!p)return;if(!X.bl.length&&!X.trk.length)return;const live=new Set(G.eb);
  for(const q of X.bl){if(q.life>0&&live.has(q))continue;if(q.bx85)continue;q.bx85=1;const R=q.bl85||60,col=q.gh85?'#f2f6ff':'#ffd36b';explode(q.x,q.y,col,12,.6);if(G.shock.length<60)G.shock.push({x:q.x,y:q.y,r:6,R,t:0,col,thin:true});sfx('boom');
    const d=Math.hypot(q.x-p.x,q.y-p.y);if(p.hp>0&&d>=q.r+14&&d<R&&p.dashT<=0){const hp0=p.hp;damagePlayer(q.dmg*.5);if(p.hp<hp0)X.self+=hp0-p.hp;}}
  X.bl=X.bl.filter(q=>!q.bx85);
  for(const q of X.trk){if(q.life>0&&live.has(q))continue;q.td85=1;if(p.hp>0&&Math.hypot(q.x-p.x,q.y-p.y)<q.r+14){X.self+=q.dmg;if(q.gh85){const b=sb85();if(b)b.ghostHit=1;}}}
  X.trk=X.trk.filter(q=>!q.td85);}
// --- полоса под полоской босса (паспорт, ОТК, бункер, запись, петля) ---
function tick85(on){const bar=document.getElementById('bossBar');if(!bar)return;
  for(const s of bar.querySelectorAll('.tick')){if(s.classList.contains('t85'))s.style.display=on?'':'none';else if(s.id!=='tick10')s.style.display=on?'none':'';}
  if(on){const b=G.sb,ths=b&&b.th||[];['a','b','c'].forEach((k,i)=>{let s=document.getElementById('t85'+k);if(!s){s=document.createElement('span');s.className='tick t85';s.id='t85'+k;bar.appendChild(s);}
    if(ths[i]!==undefined){s.style.left=(ths[i]*100)+'%';s.style.display='';}else s.style.display='none';});}}
let hud85K='',hud85On=null;
function hud85(){const b=G.sb&&is85(G.sb)&&G.sb.alive?G.sb:null;const show=!!b&&inMission()&&['enter','fight','scene','final'].includes(b.st);
  if(show!==hud85On){hud85On=show;tick85(show);}
  let el=document.getElementById('b85G');
  if(!el){if(!show)return;const bar=document.getElementById('bossBar');if(!bar)return;
    if(!document.getElementById('b85css')){const st=document.createElement('style');st.id='b85css';st.textContent='#b85G{display:flex;align-items:center;gap:8px;margin-top:5px;font:700 11px "JetBrains Mono",monospace;letter-spacing:.06em;color:#c9d2de;min-height:14px;text-shadow:0 1px 0 #04060c}#b85G[hidden]{display:none}#b85G .l{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:72%}#b85G .g{flex:1;height:5px;border:1px solid #3a3a2a;position:relative;overflow:hidden;min-width:48px;background:rgba(0,0,0,.35)}#b85G .g i{position:absolute;inset:0;transform-origin:left;background:#e8d27a;transition:transform .12s}#b85G.nog .g{display:none}#b85G .r{white-space:nowrap}#b85G.wrap .l{white-space:normal;max-width:100%}@media (max-width:820px){#b85G{font-size:12px;gap:6px}}';document.head.appendChild(st);}
    el=document.createElement('div');el.id='b85G';el.innerHTML='<span class="l"></span><span class="g"><i></i></span><span class="r"></span>';bar.insertAdjacentElement('afterend',el);}
  if(!show){if(!el.hidden)el.hidden=true;hud85K='';return;}
  if(el.hidden)el.hidden=false;const I=SBX[b.sbk]?SBX[b.sbk].strip(b):b.sbk==='lek'?lekStrip(b):wellStrip(b);
  const key=I.l+'|'+(I.k===null||I.k===undefined?'-':I.k.toFixed(3))+'|'+(I.r||'')+'|'+(I.col||'')+'|'+(I.wrap?1:0);if(key===hud85K)return;hud85K=key;
  el.querySelector('.l').textContent=I.l;el.querySelector('.l').style.color=I.lc||'';el.querySelector('.r').textContent=I.r||'';el.classList.toggle('nog',I.k===null||I.k===undefined);el.classList.toggle('wrap',!!I.wrap);
  const gi=el.querySelector('.g i');if(I.k!==null&&I.k!==undefined){gi.style.transform='scaleX('+clamp(I.k,0,1).toFixed(3)+')';gi.style.background=I.col||'#e8d27a';}}

// ===== «Лекало» · Цех №0 =====
function lekGeo(b){const k=Math.min(1,W/980,H/700),bh=Math.min(140,H*.17),wo=b&&b.wo&&b.wo.st==='go'?40*clamp(b.wo.k||0,0,1):0;
  return {k,bh,rail:H*.14,belts:[H*.34,H*.56,H*.78],dir:[-1,1,-1],furY:H-60-wo,fur0:H-60,pultY:H-134};}
function lekBand(g,y){for(let i=0;i<3;i++)if(Math.abs(y-g.belts[i])<g.bh/2)return i;return -1;}
function lekBeltSpd(){return pk85(45,60,80);}
function lekAlive(q){return !!q&&q.alive;}
function lekArms(b){return (lekAlive(b.armL)?1:0)+(lekAlive(b.armR)?1:0);}
function lekCoreOpen(b){return !!b&&b.sbk==='lek'&&b.st==='fight'&&b.inv0<=0&&b.win>0;}
function lekScan(){const st=G.st||{},bl=st.weapon==='blast';return {w:bl?'blast':'gun',n:clamp(st.shots||1,1,5),spd:(bl?620:980)*.7,dmg:(st.dmg||10)*(st.shotK||1),R:(st.blastR||110)*.6,rate:st.rate||.2,
  name:(typeof ARS!=='undefined'&&ARS[bl?'blast':'gun']&&ARS[bl?'blast':'gun'].name||(bl?'«Разрыв»':'Орудие')).toUpperCase(),mods:Object.values(G.mods||{}).reduce((a,v)=>a+v,0)};}
function lekInit(b){const g=lekGeo(b);b.g=g;b.fx=W/2;b.fy=-170;b.x=b.fx;b.y=b.fy;
  Object.assign(b,{blanks:[],asm:null,pressT:4.5,press:null,grabT:7,grab:null,blankT:2.5,stopT:0,otk:0,cone:0,otk100:0,otk50:0,wo:null,stamps:[],stampT:5,hop:[],salvoT:9,salvo:null,last:false,last5:false,win:0,winMax:1.6,labT:3,lab:null,scan:null,scanT:0,light:0,crush:0,hitT0:-1,utT:0,openK:0,inCone:false,beltT:0,
    pults:[{x:Math.max(96,W*.075),y:g.pultY,cd:0,ch:0},{x:Math.min(W-96,W*.925),y:g.pultY,cd:0,ch:0}]});
  const mk=(role,ox,oy,share,r)=>{const q=spawnEnemy('lpart',b.fx+ox,b.fy+oy,{noAffix:true,noLoot:true,spawnT:.9,role,ox,oy,host85:b});q.r=r;q.hp=q.maxHp=share?Math.round(b.maxHp*share):1e6;b.parts.push(q);return q;};
  b.core=mk('core',0,0,0,24);b.core.ghost=true;b.core.contact=0;
  {const i=G.enemies.indexOf(b.core),j=G.enemies.indexOf(b);if(i>j&&j>=0){G.enemies.splice(i,1);G.enemies.splice(j,0,b.core);}}
  b.armL=mk('armL',-172,-58,.09,22);b.armR=mk('armR',172,-58,.09,22);b.pr=mk('press',0,96,.16,26);lekPlace(b);}
function lekPlace(b){const k=(b.g||lekGeo(b)).k;b.x=b.fx;b.y=b.fy;for(const q of b.parts){if(!q.alive)continue;q.x=b.fx+q.ox*k;q.y=b.fy+q.oy*k;q.vx=q.vy=0;}}
function lekFyT(b){const g=b.g;return b.phase>=3&&b.st==='fight'?H*.30:g.rail+72*g.k;}
// окно ПК поменяло размер посреди боя (полный экран, масштаб): цех перестраивается, всё остаётся на арене
function lekResize(b){if(b.gW===W&&b.gH===H)return;const first=b.gW===undefined;b.gW=W;b.gH=H;if(first)return;
  for(const e of G.enemies){if(!e.alive||e===b||e.host85===b&&e.type==='lpart')continue;e.x=clamp(e.x,e.r,W-e.r);e.y=clamp(e.y,e.r,H-e.r);}
  for(const k of G.pick){k.x=clamp(k.x,8,W-8);k.y=clamp(k.y,8,H-8);}b.stamps=b.stamps.filter(s=>s.x>-40&&s.x<W+40&&s.y>-40&&s.y<H+40);
  if(b.docks)for(const d of b.docks){d.x=clamp(W/2+(d.kind==='break'?-1:1)*dock85dx(),70,W-70);d.y=clamp(H*.62,70,H-70);}}
function lekUpdate(b,dt){lekResize(b);const p=G.player,g=lekGeo(b);b.g=g;b.beltT+=dt*(b.stopT>0?0:1);
  const dk=b.st==='fight'&&b.phase>=3?1:(b.st==='scene'||b.st==='final')?.68:0;G.bo80+=(dk-G.bo80)*Math.min(1,dt*1.6);if(Math.abs(G.bo80-dk)<.01)G.bo80=dk;
  if(b.st==='enter'){b.timer-=dt;b.light=Math.min(1,b.light+dt/1.6);b.fy+=(lekFyT(b)-b.fy)*Math.min(1,dt*2.2);lekPlace(b);
    if(!b.scan&&b.timer<=b.enterT-1.6){b.scan=lekScan();b.scanT=0;RB85('Партия: вне. Приёмка начата.',{force:1,d:2.4});snd85('scan');}
    if(b.scan)b.scanT+=dt;
    if(b.timer<=0){b.st='fight';b.phT=0;b.light=1;if(!b.scan)b.scan=lekScan();banner('ЛЕКАЛО · ФАЗА 1','СБОРКА · РАЗБИВАЙТЕ ЗАГОТОВКИ');RB85('Заготовка на линии. Сборка по лекалу.',{force:1,d:.6});lekLabSpawn(b,true);}
    return;}
  if(b.st==='scene'||b.st==='final'){lekScene(b,dt);return;}
  b.phT+=dt;lekRail(b,dt);lekPlace(b);lekBelts(b,dt);lekPults(b,dt);
  if(b.win>0)b.win-=dt;b.core.ghost=!lekCoreOpen(b);
  if(b.phase===2)lekOtk(b,dt);
  if(b.tr>0)return;
  if(b.phase<=2)lekBlanks(b,dt);
  lekPress(b,dt);lekGrab(b,dt);lekLab(b,dt);
  if(b.phase===2)lekStamps(b,dt);
  if(b.phase===3){lekUtil(b,dt);lekSalvo(b,dt);lekLast(b);}
  lekStampMove(b,dt);
  // страховка от затяжки: 45 с без урона по телу — линия перегревается, матрица открыта 3 с
  if(G.t-b.dmgT>45&&b.win<=0&&b.inv0<=0){b.dmgT=G.t;b.win=3;b.winMax=3;floater(b.fx,b.fy-70,'ЛИНИЯ ПЕРЕГРЕЛАСЬ · МАТРИЦА ОТКРЫТА','#ffffff');snd85('open');}}
// рама едет по рельсу за игроком с отставанием 1,5 с; во время сборки, удара пресса и залпа — стоит
function lekRail(b,dt){const p=G.player,g=b.g,L=G.posLog;let q=p;if(L&&L.length){q=L[0];for(let i=L.length-1;i>=0;i--){if(G.t-L[i].t>=1.5){q=L[i];break;}}}
  const hold=!!b.asm||(b.press&&b.press.st!=='up')||!!b.salvo;const m=190*g.k+20;let tx=clamp(q.x,m,W-m);if(hold)tx=b.fx;
  const sp=b.phase>=3?52:40;b.fx+=clamp(tx-b.fx,-sp*dt,sp*dt);b.fx=clamp(b.fx,m,W-m);b.fy+=(lekFyT(b)-b.fy)*Math.min(1,dt*1.2);}
function lekBelts(b,dt){const g=b.g;if(b.stopT>0)b.stopT-=dt;const on=b.stopT<=0,wo=b.wo&&b.wo.st==='go',v=lekBeltSpd();
  if(on){for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||e.spawnT>0||(e.pg85&&e.pg85.st==='woke'))continue;const i=lekBand(g,e.y);if(i<0)continue;if(wo)e.y+=140*dt;else e.x+=g.dir[i]*v*dt;}
    for(const k of G.pick){if(k.lek85)continue;const i=lekBand(g,k.y);if(i<0)continue;if(wo)k.y+=140*dt;else k.x+=g.dir[i]*v*dt;}}
  for(const e of G.enemies){if(!e.alive||e===b||e.host85===b&&e.type==='lpart'||EDEF[e.type].sbp)continue;if(e.y>g.furY+6){explode(e.x,g.furY+12,C85.hot,12,.6);kill(e,true);}}
  for(const k of G.pick)if(k.y>g.furY+8&&k.life>0){if(k.story||k.quest||k.anom){k.y=g.furY-12;k.vy=-Math.abs(k.vy||0)-40;continue;}k.life=0;if(SET.fx)part(k.x,g.furY+10,vrnd3(-20,20),-60,.5,C85.hot,3);}}
function lekPults(b,dt){const p=G.player,xs=[Math.max(96,W*.075),Math.min(W-96,W*.925)];for(let i=0;i<b.pults.length;i++){const q=b.pults[i];q.x=xs[i];q.y=b.g.pultY;if(q.cd>0)q.cd-=dt;
  if(q.cd<=0&&p.hp>0&&Math.hypot(p.x-q.x,p.y-q.y)<56){q.ch+=dt;if(q.ch>=.6){q.ch=0;q.cd=25;b.stopT=8;floater(q.x,q.y-46,'КОНВЕЙЕРЫ СТОП · 8 С',C85.lek);snd85('pult');buzz('ready');if(G.mc)G.mc.pult85=(G.mc.pult85||0)+1;}}else q.ch=0;}}
// игрок: снос лентой, хват, печь
function lekDrift(b,p,dt){const X=x85(),g=b.g||lekGeo(b);if(p.hp<=0)return;
  if(b.st==='fight'&&b.stopT<=0){const i=lekBand(g,p.y);if(i>=0){const tk=touchMode?.7:1;if(b.wo&&b.wo.st==='go')p.y+=140*tk*dt;else p.x+=g.dir[i]*lekBeltSpd()*tk*dt;}}
  const Gr=b.grab;if(Gr&&Gr.st==='hold'&&p.dashT<=0){p.x=p.px+(p.x-p.px)*.15;p.y=Math.max(p.y,p.py)+160*dt;}
  if(b.st==='fight'&&p.y+p.r*.6>g.furY&&!(X.knock>0)){damagePlayer(8);X.knock=.2;hintOnce('fur85','ПЕЧЬ УТИЛИЗАЦИИ · ДЕРЖИТЕСЬ ВЫШЕ',C85.hot);if(Gr&&Gr.st==='hold'){Gr.st='back';Gr.t=.5;}}
  if(X.knock>0){X.knock-=dt;p.y-=600*dt;}}
// заготовки: едут по верхней ленте к точке сборки под рамой
function lekBlanks(b,dt){const g=b.g,armN=lekArms(b);b.blanks=b.blanks.filter(e=>e.alive);
  if(armN>0){b.blankT-=dt;if(b.blankT<=0){b.blankT=pk85(10,8,7)*(b.phase===2?2:1);if(b.blanks.length<4){const e=spawnEnemy('blank85',-26,g.belts[0],{noAffix:true,noLoot:true,spawnT:.3,host85:b});b.blanks.push(e);if(!b.blHint){b.blHint=1;floater(80,g.belts[0]-40,'ЗАГОТОВКА · РАЗБЕЙТЕ ДО СБОРКИ','#c9d2de');}}}}
  const lim=pk85(1,2,3),ser=G.enemies.filter(e=>e.alive&&e.type==='serial85').length,full=ser>=lim,ax=b.fx;
  if(b.asm&&(!b.asm.e.alive||armN===0))b.asm=null;
  b.blanks.sort((a,c)=>c.x-a.x);let prevX=null;
  for(const e of b.blanks){e.y=g.belts[0];if(b.asm&&b.asm.e===e){e.x+=(ax-e.x)*Math.min(1,dt*4);prevX=e.x;continue;}
    const head=prevX===null,tx=head?((b.asm||full||armN===0)?ax-140*g.k:ax):prevX-46;e.x+=clamp(tx-e.x,-80*dt,80*dt);prevX=e.x;
    if(head&&!b.asm&&!full&&armN>0&&!(b.asmCd>0)&&Math.abs(e.x-ax)<4&&e.spawnT<=0){b.asm={e,t:0};snd85('weld');}}
  if(b.asmCd>0)b.asmCd-=dt;
  if(b.asm){const A=b.asm;A.t+=dt/(armN===1?2:1);if(A.t>=3)lekAssemble(b,A.e);}}
function lekAssemble(b,e){b.asm=null;b.asmCd=pk85(7,5,4);e.alive=false;const S=G.save;let no=serialNo85()+1;serialNo85(no);
  const s=spawnEnemy('serial85',e.x,e.y+8,{noAffix:true,spawnT:.5,no85:no});s.scan85=b.scan;s.vy=180;if(G.mc)G.mc.serial85=1;
  explode(e.x,e.y,C85.lek,16,.7);sfx('killBig');floater(e.x,e.y-34,'СЕРИЙНИК '+String(no).padStart(3,'0'),C85.lek);
  if(!b.ser1){b.ser1=1;if(storyFlag('cradle22')==='keep')RB85('Отметка Кормилицы на изделии. Не предусмотрено.',{force:1});else RB85('Изделие повторено. Серия '+String(no).padStart(3,'0')+'.',{force:1});}}
function serialNo85(v){try{if(v!==undefined){LS.setItem('void_serial85',String(v));return v;}const n=parseInt(LS.getItem('void_serial85')||'13',10);return Number.isFinite(n)&&n>=13?Math.min(n,99999):13;}catch(e){if(v!==undefined)G.ser85=v;return G.ser85||13;}}
function lekBlankGone(b,e,silent){if(b.asm&&b.asm.e===e)b.asm=null;if(silent||!b.alive)return;
  for(let i=0;i<3;i++)G.pick.push({k:'part80',x:e.x+rnd(-14,14),y:e.y+rnd(-14,14),vx:rnd(-80,80),vy:rnd(-80,80),r:6,t:0,life:12,noMag:true});
  RB85('Заготовка испорчена. Списать.',{key:'blank',cd:18});}
// пресс: бьёт по ленте с игроком; давит и своих; после удара (фаза 2) рама раскрывается
function lekPress(b,dt){const g=b.g,p=G.player;if(!lekAlive(b.pr)){b.press=null;return;}
  if(!b.press){b.pressT-=dt;if(b.pressT<=0&&p.hp>0){let i=lekBand(g,p.y);if(i<0){let bd=1e9;for(let j=0;j<3;j++){const d=Math.abs(p.y-g.belts[j]);if(d<bd){bd=d;i=j;}}}
      const T=pk85(1.3,1,.7);b.press={st:'tele',t:T,T,i,x:b.fx,n:b.phase===3?2:1};snd85('press0');}}
  else{const P=b.press;P.t-=dt;
    if(P.st==='tele'){P.x=b.fx;if(P.t<=0)lekStrike(b,P);}
    else if(P.st==='up'){if(P.t<=0){b.press=null;b.pressT=(b.phase===3?6.5:5)*atkK();}}}}
function lekStrike(b,P){const g=b.g,p=G.player,y=g.belts[P.i],x=P.x,hw=80,hh=g.bh/2;
  snd85('press');shake(6);P.hitT=G.t;
  if(SET.fx)for(let i=0;i<14;i++)part(x+vrnd3(-hw,hw),y+vrnd3(-hh*.6,hh*.6),vrnd3(-160,160),vrnd3(-40,40),.5,'#9fb0c4',3);
  G.shock.push({x,y,r:8,R:110,t:0,col:C85.lek,thin:true});
  if(p.hp>0&&Math.abs(p.x-x)<hw+p.r*.5&&Math.abs(p.y-y)<hh+p.r*.5&&p.dashT<=0&&!(x85().calm>0)){const h0=p.hp;damagePlayer(26);if(p.hp<h0){x85().stun=.3;floater(p.x,p.y-36,'ПРЕСС · ДВИГАТЕЛЬ ОГЛУШЁН','#ff4f6e');}}
  for(const e of G.enemies.slice()){if(!e.alive||(e.type!=='blank85'&&e.type!=='serial85')||e.spawnT>0)continue;if(Math.abs(e.x-x)<hw+e.r&&Math.abs(e.y-y)<hh+e.r){if(e.type==='blank85'){b.crush++;if(G.mc)G.mc.crush85=b.crush;}explode(e.x,e.y,C85.lek,18,.8);kill(e,true);RB85('Брак пресса. Записано.',{key:'crush',cd:16});}}
  if(b.phase===2){const near=Math.hypot(p.x-x,p.y-y)<240;b.winMax=pk85(2.2,1.6,1.2)+(near?.4:0);b.win=b.winMax;snd85('open');floater(b.fx,b.fy-70,near?'МАТРИЦА ОТКРЫТА · ВЫ РЯДОМ':'МАТРИЦА ОТКРЫТА','#ffffff');}
  P.n--;if(P.n>0){P.st='tele';P.T=Math.max(.6,P.T*.7);P.t=P.T;{const pb=lekBand(g,p.y);P.i=P.i===1?(pb===0||pb===2?pb:(Math.random()<.5?0:2)):1;}snd85('press0');}else{P.st='up';P.t=.5;}}
// хват манипулятора: летит по прямой; поймал — тянет к печи; рывок или импульс рвут
function lekGrab(b,dt){const p=G.player,arms=[b.armL,b.armR].filter(lekAlive);
  if(!b.grab){if(!arms.length||b.phase===3)return;b.grabT-=dt;if(b.grabT<=0&&p.hp>0){const arm=arms.length===2?(Math.abs(p.x-b.armL.x)<Math.abs(p.x-b.armR.x)?b.armL:b.armR):arms[0];
      if(Math.hypot(p.x-arm.x,p.y-arm.y)>600){b.grabT=1;return;}const T=pk85(1.2,.9,.6);b.grab={st:'tele',t:T,T,arm,a:Math.atan2(p.y-arm.y,p.x-arm.x),L:0,hx:arm.x,hy:arm.y};snd85('grab');}}
  else{const Gr=b.grab,arm=Gr.arm;if(!lekAlive(arm)){b.grab=null;b.grabT=9;return;}Gr.t-=dt;
    if(Gr.st==='tele'){if(Gr.t>Gr.T*.25)Gr.a=Math.atan2(p.y-arm.y,p.x-arm.x);Gr.hx=arm.x;Gr.hy=arm.y;if(Gr.t<=0){Gr.st='fly';Gr.t=1.2;Gr.L=0;}}
    else if(Gr.st==='fly'){Gr.L=Math.min(520,Gr.L+520/1.2*dt);Gr.hx=arm.x+Math.cos(Gr.a)*Gr.L;Gr.hy=arm.y+Math.sin(Gr.a)*Gr.L;
      if(p.hp>0&&p.dashT<=0&&p.inv<=0&&!(x85().calm>0)&&Math.hypot(p.x-Gr.hx,p.y-Gr.hy)<p.r+18){Gr.st='hold';Gr.t=1.5;floater(p.x,p.y-38,'ХВАТ · РЫВОК ИЛИ ИМПУЛЬС','#ff4f6e');buzz('hit');sfx('block');if(G.mc)G.mc.grab85=1;}
      else if(Gr.t<=0||Gr.L>=520){Gr.st='back';Gr.t=.6;}}
    else if(Gr.st==='hold'){Gr.hx=p.x;Gr.hy=p.y;Gr.L=Math.hypot(p.x-arm.x,p.y-arm.y);Gr.a=Math.atan2(p.y-arm.y,p.x-arm.x);if(p.dashT>0){lekGrabBreak(b,'РЫВОК');return;}if(Gr.t<=0||p.hp<=0){Gr.st='back';Gr.t=.6;}}
    else{Gr.L=Math.max(0,Gr.L-1300*dt);Gr.hx=arm.x+Math.cos(Gr.a)*Gr.L;Gr.hy=arm.y+Math.sin(Gr.a)*Gr.L;if(Gr.L<=0||Gr.t<=0){b.grab=null;b.grabT=(b.phase===2?12:9)*atkK();}}}}
function lekGrabBreak(b,how){const Gr=b.grab;if(!Gr)return;Gr.st='back';Gr.t=.6;const arm=Gr.arm;floater(G.player.x,G.player.y-38,'ХВАТ ПОРВАН · '+how,'#ffffff');sfx('block');
  if(lekAlive(arm)&&b.st==='fight'&&b.inv0<=0)hurt(arm,arm.maxHp*.1,{ram:true});RB85('Изделие сопротивляется. Не предусмотрено.',{key:'grab',cd:24});}
// персонал цеха: один Лаборант лечит только Серийников и заготовки (не на «Лёгком»)
function lekLabSpawn(b,first){if(rk85()<=0)return;const s=Math.random()<.5;const e=spawnEnemy('labrat',s?W-40:40,H*.46,{noAffix:true,spawnT:.6});e.lab85=1;b.lab=e;if(first)floater(e.x,e.y-26,'ЛАБОРАНТ ЦЕХА','#7affc9');}
function lekLab(b,dt){if(rk85()<=0)return;const L=b.lab;if(!L||!L.alive){b.labT-=dt;if(b.labT<=0){b.labT=30;lekLabSpawn(b,false);}return;}
  if(!L.beam&&!(L.bcut>0)&&!(L.hot>0)){let best=null,bk=1;for(const e of b.blanks){if(!e.alive||e.spawnT>0)continue;const k=e.hp/e.maxHp;if(k<bk&&Math.hypot(e.x-L.x,e.y-L.y)<300){bk=k;best=e;}}if(best){L.beam=best;best.healBy=L;L.bt80=0;}}}
// ОТК: лампы, шкала брака, списание
const LAMP85={ha:.4,len:540};
function lekLamp(b,i){const g=b.g,off=Math.floor((b.phT||0)/7)%3;return {x:W*(.2+.3*i),y:g.rail,a:Math.PI/2+.6*Math.sin(G.t*.5+i*2.1),on:i!==off};}
function lekOtk(b,dt){const p=G.player;if(b.wo)lekWriteOff(b,dt);
  let inC=false;if(p.hp>0&&!b.wo&&b.tr<=0)for(let i=0;i<3;i++){const L=lekLamp(b,i);if(!L.on)continue;const d=Math.hypot(p.x-L.x,p.y-L.y);if(d<LAMP85.len&&Math.abs(angDiff(Math.atan2(p.y-L.y,p.x-L.x),L.a))<LAMP85.ha){inC=true;break;}}
  b.inCone=inC;if(inC){b.cone+=dt;if(b.cone>=.8){b.cone=0;lekOtkAdd(b,25,'ОТКЛОНЕНИЕ');}}else{b.cone=Math.max(0,b.cone-dt*2);if(!b.wo)b.otk=Math.max(0,b.otk-3*dt);}
  if(p.hitT!==undefined&&p.hitT>b.hitT0){b.hitT0=p.hitT;if(!b.wo)lekOtkAdd(b,4);}}
function lekOtkAdd(b,v,txt){if(b.wo||b.phase!==2)return;const p=G.player;b.otk=Math.min(100,b.otk+v);if(txt){floater(p.x,p.y-40,txt+' · +'+v+'% БРАКА',C85.lek);sfx('warn');}
  if(b.otk>=50&&!b.otk50){b.otk50=1;RB85('Отклонение от нормы: память.',{force:1});}
  if(b.otk>=100){b.wo={st:'warn',t:1.5,k:0};b.otk100++;if(G.mc)G.mc.otk85=1;RB85('Списание изделия. Всем лентам — к печи.',{force:1});snd85('siren');buzz('ready');banner('СПИСАНИЕ ИЗДЕЛИЯ','ЛЕНТЫ — К ПЕЧИ · ПУЛЬТ СМЕНЫ ИЛИ ВЕРХНЯЯ ЛЕНТА');}}
function lekWriteOff(b,dt){const W_=b.wo;W_.t-=dt;if(W_.st==='warn'){if(W_.t<=0){W_.st='go';W_.t=5;W_.k=0;}}
  else{W_.k=Math.min(1,W_.k+dt*2);if(W_.t<=0){b.wo=null;b.otk=0;if(G.player.hp>0)RB85('Изделие не списано. Повторить осмотр.',{force:1});}}}
// печати ОТК
function lekStamps(b,dt){b.stampT-=dt;if(b.stampT<=0){b.stampT=8*atkK();const p=G.player,a0=Math.atan2(p.y-b.fy,p.x-b.fx);
    for(let i=0;i<3;i++){const a=a0+(i-1)*.45;b.stamps.push({x:b.fx+(i-1)*44*b.g.k,y:b.fy+70*b.g.k,a,t:6,sp:rnd(0,TAU)});}snd85('stamp');}}
function lekStampMove(b,dt){const p=G.player,X=x85();for(const s of b.stamps){if(s.t<=0)continue;s.t-=dt;const ta=Math.atan2(p.y-s.y,p.x-s.x);s.a+=clamp(angDiff(ta,s.a),-1.1*dt,1.1*dt);s.x+=Math.cos(s.a)*110*dt;s.y+=Math.sin(s.a)*110*dt;s.sp+=dt*3;
    if(p.hp>0&&Math.hypot(p.x-s.x,p.y-s.y)<p.r+12){s.t=0;if(p.dashT>0)continue;if(X.calm>0)continue;
      if(!G.stamp80&&p.inv<=0){const t=rk85()===0?5:4;G.stamp80={t,max:t};document.body.classList.add('stamp80');floater(p.x,p.y-34,'ПРОВЕРЕНО · СБРОСЬТЕ РЫВКОМ','#ff7a3d');buzz('hit');sfx('block');}
      lekOtkAdd(b,20,'ПЕЧАТЬ ОТК');}}
  b.stamps=b.stamps.filter(s=>s.t>0&&s.x>-40&&s.x<W+40&&s.y>-40&&s.y<H+40);}
// списание: рама втягивает добычу (бункер 24) и бьёт ею веером «Вся смена»
function lekUtil(b,dt){b.utT++;const p=G.player,mag=(G.st&&G.st.mag)||0;
  for(const k of G.pick){if(k.life<=0||k.anom||k.story||k.quest)continue;if(k.k!=='xp'&&k.k!=='lom'&&k.k!=='cell'&&k.k!=='part80'&&k.k!=='wreck85')continue;
    if(!k.lek85){if(b.utT%4)continue;if(p.hp>0&&Math.hypot(k.x-p.x,k.y-p.y)<mag+10)continue;k.lek85=1;k.noMag=true;k.rc80=null;}
    if(p.hp>0&&k.k!=='part80'&&k.k!=='wreck85'&&Math.hypot(k.x-p.x,k.y-p.y)<mag*.55){k.lek85=0;k.noMag=false;continue;}
    const dx=b.fx-k.x,dy=b.fy-k.y,d=Math.hypot(dx,dy)||1;k.vx=dx/d*190-dy/d*55;k.vy=dy/d*190+dx/d*55;k.life=Math.max(k.life,2);
    if(d<36){if(b.hop.length<24){b.hop.push({k:k.k,v:k.v||1});k.life=0;}else{k.vx=k.vy=0;}}}}
function lekSalvo(b,dt){const p=G.player;
  if(!b.salvo){b.salvoT-=dt;if((b.hop.length>=24||b.salvoT<=0)&&p.hp>0){const T=pk85(1.2,.9,.65);b.salvo={t:T,T,a:Math.atan2(p.y-b.fy,p.x-b.fx)};snd85('salvo0');RB85('Утилизация отходов смены.',{key:'salvo',cd:26});}return;}
  const S=b.salvo;S.t-=dt;if(S.t>S.T*.3)S.a+=clamp(angDiff(Math.atan2(p.y-b.fy,p.x-b.fx),S.a),-.8*dt,.8*dt);if(S.t>0)return;
  const items=b.hop.splice(0,18),n=items.length,X=x85();
  if(!n){for(let i=0;i<6;i++){shootE(b.fx,b.fy+30*b.g.k,S.a+(i-2.5)*.16,240,6,'#ffb84d',4);}}
  else{const step=Math.min(.12,1.3/Math.max(1,n-1));for(let i=0;i<n;i++){const it=items[i],a=S.a+(i-(n-1)/2)*step;const heavy=it.k==='wreck85';
      const dmg=heavy?30:it.k==='lom'?Math.min(14,8+Math.floor((it.v||1)/10)):it.k==='part80'?12:8,col=heavy?'#c9d2de':it.k==='lom'?'#ffb84d':it.k==='xp'?'#d9c8ff':it.k==='cell'?'#ffb84d':'#c9d2de';
      const q=shootE(b.fx,b.fy+30*b.g.k,a,heavy?230:265,dmg,col,heavy?9:it.k==='part80'?7:5);if(q){q.rc80=it;if(G.rcB80)G.rcB80.push(q);}}}
  sfx('bigboom');shake(8);snd85('salvo');b.salvo=null;b.salvoT=8.5*atkK();b.win=pk85(2.6,2,1.5);b.winMax=b.win;floater(b.fx,b.fy-70,'ПЕРЕГРЕВ · МАТРИЦА ОТКРЫТА','#ffffff');snd85('open');}
// «Последняя партия»: на 15% собираются сразу до двух Серийников; пока они живы, матрица берёт ×0,5
function lekLast(b){const k=b.hp/b.maxHp;
  if(!b.last&&k<=.15){b.last=true;banner('ПОСЛЕДНЯЯ ПАРТИЯ','ПОКА СЕРИЙНИКИ ЖИВЫ — МАТРИЦА ×0,5');RB85('Последняя партия. Линия не может остановиться.',{force:1});
    if(lekArms(b)>0){const al=G.enemies.filter(e=>e.alive&&e.type==='serial85').length;for(let i=0;i<Math.max(0,2-al);i++){const no=serialNo85()+1;serialNo85(no);const s=spawnEnemy('serial85',b.fx+(i?60:-60)*b.g.k,b.fy+90*b.g.k,{noAffix:true,spawnT:.6,no85:no,last85:true});s.hp=s.maxHp=s.maxHp*.6;s.scan85=b.scan;s.vy=200;if(G.mc)G.mc.serial85=1;explode(s.x,s.y,C85.lek,14,.6);}}}
  if(!b.last5&&k<=.05){b.last5=true;RB85('Линия не может… линия не…',{force:1});}}
// повреждения
function lekHurt(b,e,dmg,src){
  if(e.type==='lekalo'){pool85(b,dmg*(lekAlive(b.pr)?.7:1),.08,e);return 0;}
  if(e.role==='core'){if(!lekCoreOpen(b)){sbBlock(e);return 0;}const lb=G.enemies.some(q=>q.alive&&q.last85);pool85(b,dmg*1.5*(lb?.5:1),0,b);e.flash=.07;return 0;}
  const d=Math.min(dmg,e.hp);pool85(b,d,.08,null);return dmg;}
function lekPartDied(b,e){explode(e.x,e.y,C85.lek,34,1.2);sfx('bigboom');shake(7);
  if(e.role==='armL'||e.role==='armR'){const g=b.g;for(let i=0;i<3;i++)G.pick.push({k:'wreck85',x:e.x+rnd(-30,30),y:clamp(e.y+rnd(40,140),0,g.furY-30),vx:rnd(-40,40),vy:rnd(40,120),r:9,t:0,life:240,noMag:true});
    if(b.grab&&b.grab.arm===e)b.grab=null;
    if(lekArms(b)===0){floater(e.x,e.y-30,'МАНИПУЛЯТОРЫ ВЫБИТЫ · КОПИЙ БОЛЬШЕ НЕТ',C85.lek);b.asm=null;}else floater(e.x,e.y-30,'МАНИПУЛЯТОР ВЫБИТ · СБОРКА ВДВОЕ ДОЛЬШЕ',C85.lek);}
  else if(e.role==='press'){b.press=null;floater(e.x,e.y-30,b.phase<3?'ПРЕСС ВЫБИТ · РАМА БЕРЁТ ПОЛНЫЙ УРОН':'ПРЕСС ВЫБИТ',C85.lek);}}
function lekBullet(b,bu){const C=b.core;
  // открытая матрица: рама её не заслоняет — попадание в глаз засчитывается по всему проёму рамы
  if(C&&C.alive&&lekCoreOpen(b)&&!bu.hit.includes(C)&&segDist(bu.px,bu.py,bu.x,bu.y,C.x,C.y)<50){if(bu.blast){bu.x=C.x;bu.y=C.y;bu.life=0;return true;}bu.hit.push(C);hurt(C,bu.dmg,{charged:!!bu.charged,drone:!!(bu.drone||bu.turret)});if(SET.fx)part(bu.x,bu.y,vrnd3(-60,60),vrnd3(-60,60),.2,'#ffffff',2);if(!bu.charged){bu.life=0;return true;}}
  for(const s of b.stamps){if(s.t>0&&segDist(bu.px,bu.py,bu.x,bu.y,s.x,s.y)<13){s.t=0;explode(s.x,s.y,'#ff7a3d',8,.4);if(!bu.charged&&!bu.blast){bu.life=0;return true;}}}return false;}
function lekPulse(b,p,R){if(b.grab&&b.grab.st==='hold')lekGrabBreak(b,'ИМПУЛЬС');for(const s of b.stamps)if(Math.hypot(s.x-p.x,s.y-p.y)<R+12)s.t=0;}
// автоприцел: открытая матрица → заготовка в сборке → Серийник → манипулятор → пресс → рама
function lekAuto(p,b){let best=null,bs=1e9;const cand=(e,w)=>{if(!e||!e.alive||!targetable(e))return;const d=Math.hypot(e.x-p.x,e.y-p.y)/w;if(d<bs){bs=d;best=e;}};
  if(lekCoreOpen(b))cand(b.core,1.8);for(const e of b.blanks)cand(e,b.asm&&b.asm.e===e?1.4:1.1);
  for(const e of G.enemies){if(e.type==='serial85')cand(e,1.05);else if(e.type==='labrat'&&e.beam)cand(e,1.15);}cand(b.armL,1.12);cand(b.armR,1.12);cand(b.pr,.92);cand(b,.85);
  return best&&bs<1000?best:null;}
function lekHud(b){if(b.win>0)return (b.phase===3?'ПЕРЕГРЕВ · ':'')+'МАТРИЦА ОТКРЫТА · '+fmt85(b.win)+' С';
  if(b.phase===1)return b.asm?'СБОРКА '+Math.round(b.asm.t/3*100)+'% · РАЗБЕЙТЕ ЗАГОТОВКУ':'СБОРКА · РАЗБИВАЙТЕ ЗАГОТОВКИ';
  if(b.phase===2)return b.wo?'СПИСАНИЕ · ПУЛЬТ СМЕНЫ ИЛИ ВЕРХНЯЯ ЛЕНТА':'ОТК · ЖДИТЕ УДАРА ПРЕССА · БРАК '+Math.round(b.otk)+'%';
  return b.salvo?'ЗАЛП «ВСЯ СМЕНА» · УХОДИТЕ С ВЕЕРА':'СПИСАНИЕ · СОБИРАЙТЕ ДОБЫЧУ РАНЬШЕ РАМЫ';}
function lekStrip(b){
  if(b.st==='enter'){if(!b.scan)return {l:'ПРИЁМКА · СВЕТ ПО ЛИНИЯМ',k:null};const s=b.scan;return {l:'ПАСПОРТ ИЗДЕЛИЯ · VØID-013 · ОРУЖИЕ: '+s.name+(s.n>1?' ×'+s.n:'')+' · МОДУЛЕЙ: '+s.mods+' · ИЗНОС 12% · ПАРТИЯ: ВНЕ',k:null,wrap:true,lc:C85.lek};}
  if(b.st==='scene')return {l:'ЗАПИСЬ · Э. В. · ЦЕХ №0',k:null,lc:'#ffd36b'};
  if(b.st==='final')return {l:b.prev85?'ВЫ УЖЕ СДЕЛАЛИ ВЫБОР · ЛЕТИТЕ К ПРИЧАЛУ':'РАЗБИТЬ ЛЕКАЛО ИЛИ ПЕРЕПИСАТЬ ЕГО СОБОЙ',k:null,lc:C85.lek};
  const lim=pk85(1,2,3),ser=G.enemies.filter(e=>e.alive&&e.type==='serial85').length;
  if(b.phase===1)return {l:b.asm?'СБОРКА СЕРИЙНИКА':lekArms(b)?'ЛИНИЯ · ЗАГОТОВОК '+b.blanks.filter(e=>e.alive).length:'МАНИПУЛЯТОРЫ ВЫБИТЫ',k:b.asm?b.asm.t/3:null,col:'#ff4f6e',r:'СЕРИЙНИКИ '+ser+'/'+lim};
  if(b.phase===2){const k=b.otk/100,c=k<.5?'#7affc9':k<.8?'#ffd36b':'#ff4f6e';return {l:b.wo?(b.wo.st==='warn'?'СПИСАНИЕ ЧЕРЕЗ '+fmt85(b.wo.t):'СПИСАНИЕ · '+fmt85(b.wo.t)+' С'):'ОТК: НОРМА → БРАК',lc:b.wo?'#ff4f6e':'',k,col:c,r:Math.round(b.otk)+'%'};}
  return {l:'ОТХОДЫ СМЕНЫ',k:b.hop.length/24,col:'#ffb84d',r:b.hop.length+'/24'};}
// финал: линия останавливается, рама раскрывается, запись Э. В.
function lekFinal(b){for(const k of G.pick)if(k.lek85){k.lek85=0;k.noMag=k.k==='part80'||k.k==='wreck85';k.vx*=.2;k.vy*=.2;}b.press=null;b.grab=null;b.salvo=null;b.stamps=[];b.wo=null;b.win=0;b.asm=null;b.stopT=0;b.scT=0;b.subOn=false;b.beltStop=[0,0,0];
  banner('МАТРИЦА ПОГАСЛА','ЛИНИЯ ОСТАНАВЛИВАЕТСЯ');snd85('stop');}
function lekScene(b,dt){b.scT+=dt;b.openK=Math.min(1,b.openK+dt/1.6);for(let i=0;i<3;i++)if(b.scT>.6+i*.6)b.beltStop[i]=1;b.stopT=99;
  b.fy+=((b.g.rail+72*b.g.k)-b.fy)*Math.min(1,dt*.8);lekPlace(b);
  if(b.st==='scene'&&b.scT>=2.4&&!b.subOn){b.subOn=true;
    sub85('ЗАПИСЬ · Э. В. · ЦЕХ №0','#ffd36b',['«Если ты слышишь это в Цехе ноль — ты дошёл дальше всех, кого мы сделали».','«Это лекало. С него сняли тебя. И всех, кто летал до тебя».','«Первая копия висит перед тобой. Она так и не проснулась. Я счёл это милосердием».','«Разбей его — и больше никто не проснётся в чужом корпусе».','«Или оставь в нём себя. Тогда следующий проснётся, помня тебя».','«Я не смог выбрать. Прости, что выбирать тебе».'],
      ()=>{if(b.st!=='scene')return;b.st='final';sb85SetDocks(b,[{kind:'break',x:W/2-dock85dx(),y:H*.62,lab:'РАЗБИТЬ ЛЕКАЛО',sub:'копий больше не будет'},{kind:'write',x:W/2+dock85dx(),y:H*.62,lab:'ПЕРЕПИСАТЬ ЛЕКАЛО',sub:'следующий проснётся, помня вас'}]);
        banner('ЛЕКАЛО','РАЗБИТЬ ИЛИ ПЕРЕПИСАТЬ · ЛЕТИТЕ К ПРИЧАЛУ');sfx('level');});}
  if(b.st==='final')sb85Docks(b,dt);}
function lekChoose(b,ch,world,prev){const badges=[];if(b.crush>=3)badges.push('«Брак пресса»');if(!b.otk100)badges.push('«Норма»');const bt=badges.length?' Бейджи: '+badges.join(', ')+'.':'';
  if(ch==='break'){G.sbLomK=prev?1:2;
    G.sbChoiceTxt=(prev?'Вы уже сделали выбор: лекало разбито. ':'Лекало разбито: лом ×2. Копий больше не делают — в секторе VII всегда светло, бюро молчит. Скин «Осколок лекала» в ангаре. ')+'«Лекало разбито. В Цехе №0 горит свет, и больше нечего проверять».'+bt;
    SB_DEATH.lek=['ЛЕКАЛО РАЗБИТО','СЕКТОР VII ПРОЙДЕН','Если ты разбил его — значит, решил за всех нас. Я рад, что это был не я.'];if(world&&!prev)own85('shard85');}
  else{G.sbLomK=1;
    G.sbChoiceTxt=(prev?'Вы уже сделали выбор: лекало переписано. ':'Лекало переписано вами: лом ×1. В секторе VII появится союзный «Ученик», Паломники терпят на один выстрел больше, в Колодце поможет Серийник 013. Скин «Серия 013» в ангаре. ')+'«Лекало тёплое. Следующая копия будет помнить, как тебя звали».'+bt;
    SB_DEATH.lek=['ЛЕКАЛО ПЕРЕПИСАНО','СЕКТОР VII ПРОЙДЕН','Если ты оставил себя в нём — следующий узнает твой почерк. Как ты узнал мой.'];if(world&&!prev)own85('serial013');}
  RB85(ch==='break'?'Линия… остановлена.':'Линия работает по новому лекалу.',{force:1,d:.2});}
// Серийник: держится на 300–420 и стреляет шаблоном оружия игрока (скорость ×0,7, темп ×0,5, урон ×0,4 с потолком Отзвука)
function serialAI85(e,dt,c){const p=G.player,b=sb85(),pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,sc=e.scan85||(b&&b.scan)||(e.scan85=lekScan());
  const dk=G.bo80>=.5?260:360,k=clamp((pd-dk)/80,-1,1);let vx=pdx/pd*k-pdy/pd*.6*e.dir,vy=pdy/pd*k+pdx/pd*.6*e.dir;
  if(b&&b.sbk==='lek'&&b.g){const g=b.g;if(e.y>g.furY-80)vy-=1.4;if(e.y<g.rail+50)vy+=.9;}
  steer(e,vx,vy,e.spd*((c&&c.sm)||1),dt,2.4);if(Math.random()<dt*.3)e.dir*=-1;
  const S=e.sf||(e.sf={st:'cd',t:rnd(1,2)});S.t-=dt;if(b&&(b.tr>0||b.st!=='fight'))return;
  if(S.st==='cd'){if(S.t<=0&&p.hp>0&&pd<760&&onScreen(e)){S.st='tele';S.t=.5;}}
  else if(S.st==='tele'){if(S.t<=0){S.st='burst';S.n=pk85(1,1,2);S.t=0;}}
  else if(S.st==='burst'){if(S.t<=0){S.n--;S.t=Math.max(.22,(sc.rate||.2)*2);serialShot85(e,sc);if(S.n<=0){S.st='cd';S.t=rnd(1.6,2.3)*atkK();}}}}
function serialShot85(e,sc){const p=G.player,a0=Math.atan2(p.y-e.y,p.x-e.x),cap=[8,11,15][rk85()],d=clamp((sc.dmg||10)*.3,2,cap),X=x85(),n=clamp(sc.n||1,1,3);
  for(let i=0;i<n;i++){const a=a0+(i-(n-1)/2)*.11;const q=shootE(e.x,e.y,a,sc.spd||686,d,'#ffd36b',sc.w==='blast'?6:4);if(q){q.ser85=1;X.trk.push(q);if(sc.w==='blast'){q.bl85=sc.R||66;q.life=1.1;X.bl.push(q);}}}sfx('shot');}
function lekPhase(b){const p=G.player;
  if(b.phase===2){banner('ЛЕКАЛО · ФАЗА 2','ОТК · НЕ СТОЙТЕ В КОНУСАХ ЛАМП');RB85('Отдел технического контроля. Изделие — к осмотру.',{force:1,d:.5});b.scan=lekScan();b.otk=0;b.cone=0;b.stampT=4;b.blankT=Math.max(b.blankT,5);b.hitT0=p&&p.hitT!==undefined?p.hitT:-1;b.pressT=Math.min(b.pressT,3);}
  if(b.phase===3){banner('ЛЕКАЛО · ФАЗА 3','СПИСАНИЕ · СВЕТ ПО РЕГЛАМЕНТУ');RB85('Смена окончена. Свет — по регламенту.',{force:1,d:.5});b.wo=null;b.stamps=[];b.asm=null;b.otk=0;b.win=0;b.salvoT=6;b.grab=null;b.pressT=Math.max(b.pressT,3);
    for(const e of b.blanks){if(e.alive){b.hop.push({k:'part80',v:1},{k:'part80',v:1});kill(e,true);}}b.blanks=[];}}

// ===== «Первый сигнал» · Колодец Истока =====
function wellRing(b,id){return b.rings[id==='O'?0:1];}
function wellInit(b){const R=Math.min(W,H)*.48,k=clamp(R/365,.7,1.15);b.cx=W/2;b.cy=H/2;b.R=R;b.k=k;b.x=b.cx;b.y=b.cy;
  Object.assign(b,{rings:[{id:'O',r:150*k,rot:0,v:12*Math.PI/180,n:8,arc:30*Math.PI/180,share:.03},{id:'I',r:96*k,rot:Math.PI/6,v:-20*Math.PI/180,n:6,arc:36*Math.PI/180,share:.035}],
    emit:[],sons:[],sonT:2.5,son2:0,pilT:3,pilN:0,woke:0,absorbed:0,rec:null,recT:2,ghosts:[],echoT:5,anchors:[],loopT:0,loopMax:pk85(26,20,16),loops:0,loopCap:pk85(1,2,3),hist:[],histT:0,stun:0,anchorT:1.5,karr:0,
    iw:null,invT:2.5,invN:0,p4i:0,p4T:2.5,p4t:0,p4last:false,lit:0,ghostHit:0,sos:0,flashK:0,collapse:0,scT:0,brkN:0});
  for(const ring of b.rings)for(let i=0;i<ring.n;i++)wellEmit(b,ring,i,.5+i*(ring.id==='O'?.42:.5)+(ring.id==='I'?.2:0),1);
  wellPlace(b);
  const X=G.x80;if(X&&X.leaks){X.leaks=X.leaks.filter(q=>!q.w85);for(let i=0;i<3;i++){const a=-Math.PI/2+Math.PI/3+i*TAU/3;X.leaks.push({x:b.cx+Math.cos(a)*(R-120*k),y:b.cy+Math.sin(a)*(R-120*k),r:140*k,w85:1});}}
  if(storyFlag('line31')==='write'&&G.mode==='world')x85().allyPending=1;}
function wellEmit(b,ring,i,spawnT,hpK){const q=spawnEnemy('wemit',b.cx,b.cy,{noAffix:true,noLoot:true,spawnT,host85:b,ring:ring.id,idx:i});q.maxHp=Math.round(b.maxHp*ring.share);q.hp=Math.round(q.maxHp*(hpK||1));q.cd85=rnd(1.5,3.5);q.ringR=ring.r;b.emit.push(q);return q;}
function wellPlace(b){const col=b.collapse||0;for(const e of b.emit){if(!e.alive)continue;const ring=wellRing(b,e.ring);const a=ring.rot+e.idx*TAU/ring.n,r=ring.r+(64*b.k-ring.r)*col;e.ang85=a;e.ringR=r;e.x=b.cx+Math.cos(a)*r;e.y=b.cy+Math.sin(a)*r;e.vx=e.vy=0;}
  b.x=b.cx;b.y=b.cy;}
function wellCoreK(b){return (b.ghosts.some(g=>g.alive&&g.rec)?1.3:1)*(b.stun>0?1.5:1);}
// окно ПК поменяло размер посреди боя: колодец пересобирается вокруг нового центра, всё внутри переносится подобием
function wellResize(b){if(b.gW===W&&b.gH===H)return;const first=b.gW===undefined;b.gW=W;b.gH=H;if(first)return;
  const R=Math.min(W,H)*.48,k=clamp(R/365,.7,1.15),ox=b.cx,oy=b.cy,s=R/b.R,cx=W/2,cy=H/2,mv=q=>{q.x=cx+(q.x-ox)*s;q.y=cy+(q.y-oy)*s;};
  b.cx=cx;b.cy=cy;b.R=R;b.k=k;b.rings[0].r=150*k;b.rings[1].r=96*k;
  for(const e of G.enemies)if(e.alive&&e!==b&&e.type!=='wemit')mv(e);for(const q of G.eb)mv(q);for(const q of G.pick)mv(q);
  const X=G.x80;if(X&&X.leaks)for(const q of X.leaks)if(q.w85){mv(q);q.r=140*k;}
  for(const g of b.ghosts)if(g.rec&&!g.rec.mv85){g.rec.mv85=1;g.rec.path.forEach(mv);}if(b.rec){b.rec.path.forEach(mv);const o={x:b.rec.x0,y:b.rec.y0};mv(o);b.rec.x0=o.x;b.rec.y0=o.y;}for(const g of b.ghosts)if(g.rec)g.rec.mv85=0;
  const p=G.player;if(p){mv(p);p.px=p.x;p.py=p.y;}
  if(b.docks)for(const d of b.docks){mv(d);d.x=clamp(d.x,70,W-70);d.y=clamp(d.y,70,H-70);}wellPlace(b);}
function wellUpdate(b,dt){wellResize(b);const p=G.player;b.emit=b.emit.filter(e=>e.alive);
  const sp=b.phase>=4&&b.st==='fight'?.25:1;for(const ring of b.rings)ring.rot+=ring.v*dt*sp*(b.stun>0?.3:1);
  const dk=b.st==='enter'?.45*Math.min(1,(b.enterT-b.timer)/2):b.st==='fight'?(b.phase>=4?1:.45):b.st==='scene'||b.st==='final'?Math.max(0,.8-(b.scT||0)*.25):0;G.bo80+=(dk-G.bo80)*Math.min(1,dt*1.4);if(Math.abs(G.bo80-dk)<.01)G.bo80=dk;
  if(b.phase>=4)b.collapse=Math.min(1,b.collapse+dt*.8);
  wellPlace(b);wellConfine(b,dt);wellPilMove(b,dt);
  if(b.st==='enter'){b.timer-=dt;b.lit=Math.min(1,b.lit+dt/4.2);
    const el=b.enterT-b.timer;if(b.sos<1&&el>.6){b.sos=1;snd85('sos');}
    if(b.timer<=0){b.st='fight';b.phT=0;banner('ПЕРВЫЙ СИГНАЛ · ФАЗА 1','ЗОВ · БУДИТЕ ПАЛОМНИКОВ ИМПУЛЬСОМ');RI85('…идите сюда. Все. Здесь не страшно…',{force:1,d:.4});wellAlly(b);}
    return;}
  if(b.st==='scene'||b.st==='final'){wellScene(b,dt);return;}
  b.phT+=dt;wellHist(b,dt);if(b.stun>0)b.stun-=dt;
  if(b.tr>0)return;
  wellSonar(b,dt);if(b.phase<=3)wellEmitFire(b,dt);
  if(b.phase===1)wellPilgrims(b,dt);
  if(b.phase===2)wellEcho(b,dt);
  if(b.phase===3)wellLoop(b,dt);
  if(b.phase===4)wellSilence(b,dt);}
// стена колодца и тяга к центру
function wellConfine(b,dt){for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||e.spawnT>0)continue;if(e.pg85&&e.pg85.st==='woke')continue;const dx=e.x-b.cx,dy=e.y-b.cy,d=Math.hypot(dx,dy)||1,lim=b.R-e.r-4;if(d>lim){e.x=b.cx+dx/d*lim;e.y=b.cy+dy/d*lim;e.vx*=.5;e.vy*=.5;}}}
function wellDrift(b,p,dt){if(p.hp<=0)return;const dx=p.x-b.cx,dy=p.y-b.cy,d=Math.hypot(dx,dy)||1;
  if(b.st==='fight'&&p.dashT<=0&&d>b.r+30){const pull=pk85(15,25,35)*(touchMode?.8:1);p.x-=dx/d*pull*dt;p.y-=dy/d*pull*dt;}
  const lim=b.R-p.r;if(d>lim){p.x=b.cx+dx/d*lim;p.y=b.cy+dy/d*lim;p.vx*=.6;p.vy*=.6;if(!b.wallH){b.wallH=1;hintOnce('well85','СТЕНА КОЛОДЦА','#6b8cff');}}
  if(b.st==='scene'&&b.scT<2.2){const tx=b.cx,ty=b.cy+92*b.k,q=Math.hypot(p.x-tx,p.y-ty);if(q>160){p.x+=(tx-p.x)*Math.min(1,dt*1.3);p.y+=(ty-p.y)*Math.min(1,dt*1.3);}}}
// сонар: расширяющееся кольцо с проходами; рывок сквозь волну — без урона
function wellSon(b,second){const p=G.player,n=pk85(3,2,2),w=pk85(52,44,34)*Math.PI/180,pa=Math.atan2(p.y-b.cy,p.x-b.cx);const a0=pa+rnd(.45,1.1)*(Math.random()<.5?-1:1)+(second?Math.PI/n:0);
  const gaps=[];for(let i=0;i<n;i++)gaps.push({a:a0+i*TAU/n,w});const T=pk85(1.1,.9,.65);b.sons.push({r:b.r+6,v:b.phase>=4?176:220,t:T,T,gaps,hit:false,dmg:14});snd85('ping');}
function wellSonar(b,dt){const p=G.player;b.sonT-=dt;const every=b.phase===1?4:b.phase===2?6:5;
  if(b.sonT<=0&&p.hp>0&&!(b.stun>0)){b.sonT=every*atkK()*(b.phase>=4?1.25:1);wellSon(b,0);if(b.phase===3)b.son2=.7;}
  if(b.son2>0){b.son2-=dt;if(b.son2<=0){b.son2=0;wellSon(b,1);}}
  for(const S of b.sons){if(S.t>0){S.t-=dt;continue;}S.r+=S.v*dt;
    if(!S.hit&&p.hp>0){const dd=Math.hypot(p.x-b.cx,p.y-b.cy);if(Math.abs(dd-S.r)<9+p.r*.6){const a=Math.atan2(p.y-b.cy,p.x-b.cx);if(!S.gaps.some(g=>Math.abs(angDiff(a,g.a))<g.w/2)){S.hit=true;if(p.dashT<=0&&!(x85().calm>0)){damagePlayer(S.dmg);if(G.mc)G.mc.son85=(G.mc.son85||0)+1;}}}}}
  b.sons=b.sons.filter(S=>S.r<b.R+30);}
// излучатели: очередь по 3, когда игрок перед ними (±30°); одновременно не больше двух
function wellEmitFire(b,dt){const p=G.player;if(b.stun>0||p.hp<=0)return;const pa=Math.atan2(p.y-b.cy,p.x-b.cx),pd=Math.hypot(p.x-b.cx,p.y-b.cy);let busy=b.emit.filter(e=>e.alive&&(e.tel85>0||e.bn85>0)).length;
  for(const e of b.emit){if(!e.alive||e.spawnT>0||e.corona)continue;if(e.cd85>0)e.cd85-=dt;
    if(e.tel85>0){e.tel85-=dt;if(e.tel85<=0){e.bn85=3;e.bt85=0;}continue;}
    if(e.bn85>0){e.bt85-=dt;if(e.bt85<=0){e.bn85--;e.bt85=.13;shootE(e.x,e.y,Math.atan2(p.y-e.y,p.x-e.x)+rnd(-.04,.04),250,9,'#9fb8ff',4);sfx('shot');if(e.bn85<=0)e.cd85=3*atkK();}continue;}
    if(e.cd85<=0&&busy<2&&G.t>=(b.emitGap||0)&&pd>e.ringR+24&&Math.abs(angDiff(pa,e.ang85))<.52){e.tel85=pk85(.8,.6,.6);busy++;b.emitGap=G.t+pk85(2.2,1.6,1.2);}}}
// паломники летят на зов; долетевший питает ядро и становится нотой; импульс будит
function tol85(){const s=G.save&&G.save.story;return ((s&&s.spared||0)>=5?1:0)+(storyFlag('line31')==='write'?1:0);}
function wellPilgrims(b,dt){b.pilT-=dt;if(b.pilT<=0&&b.pilN<8){b.pilT=10;const a=rnd(0,TAU);
    for(let i=0;i<2&&b.pilN<8;i++){const aa=a+(i?.28:0),e=spawnEnemy('pilgrim',b.cx+Math.cos(aa)*(b.R-26),b.cy+Math.sin(aa)*(b.R-26),{noAffix:true,noLoot:true,spawnT:.6});e.hp=e.maxHp=60;e.peace=true;e.pg85={st:'go',tol:tol85()};b.pilN++;}
    if(!b.pilH){b.pilH=1;floater(G.player.x,G.player.y-44,'ПАЛОМНИКИ ЛЕТЯТ НА ЗОВ · БУДИТЕ ИМПУЛЬСОМ',C85.pil);}}}
function wellPilMove(b,dt){for(const e of G.enemies){if(!e.alive||e.type!=='pilgrim'||!e.pg85||e.spawnT>0)continue;const g=e.pg85;
    if(g.st==='go'){const dx=b.cx-e.x,dy=b.cy-e.y,d=Math.hypot(dx,dy)||1;steer(e,dx,dy,b.st==='fight'?50:0,dt,2);if(d<b.r+22&&b.st==='fight'&&b.phase<4)wellAbsorb(b,e);}
    else if(g.st==='woke'){const dx=e.x-b.cx,dy=e.y-b.cy,d=Math.hypot(dx,dy)||1;steer(e,dx,dy,140,dt,2.5);if(d>b.R+50)e.alive=false;}
    else pil85Hostile(e,dt);}}
function wellAbsorb(b,e){e.alive=false;b.absorbed++;if(G.mc)G.mc.absorb38=1;const up=b.phase===1?b.maxHp:b.maxHp*b.th[b.phase-2]-1;b.hp=Math.min(up,b.hp+b.maxHp*.02);explode(e.x,e.y,C85.pil,14,.6);snd85('absorb');
  floater(b.cx,b.cy-b.r-30,'ГОЛОС КОЛОДЦУ · +2%',C85.pil);RI85('…ещё один голос. Громче…',{key:'absorb',cd:16});
  if(G.enemies.filter(o=>o.alive&&o.type==='note85').length<6){const n=spawnEnemy('note85',b.cx,b.cy,{noAffix:true,noLoot:true,spawnT:.4,host85:b});n.oa=rnd(0,TAU);n.or=b.r+42+rnd(0,34);n.fc=rnd(1,3);}}
function wellWake(b,e){const g=e.pg85;if(!g||g.st!=='go')return false;g.st='woke';e.peace=true;b.woke++;const S=G.save;if(S&&S.story&&G.mode==='world')S.story.woke=(S.story.woke||0)+1;
  floater(e.x,e.y-24,'ПРОСНУЛСЯ',C85.pil);explode(e.x,e.y,C85.pil,8,.4);say85('ПАЛОМНИК',C85.pil,'Где я? Я… поворачиваю.',{key:'woke',cd:14});return true;}
function pil85Hurt(e,dmg,src){const g=e.pg85;if(!g)return dmg;const b=sb85();
  if(src&&src.pulse){if(b&&b.sbk==='well'&&g.st==='go')wellWake(b,e);return g.st==='hostile'?dmg:0;}
  if(g.st==='hostile')return dmg;if(G.mc)G.mc.pilHit38=1;
  if(g.tol>0){g.tol--;floater(e.x,e.y-24,'ОНИ СЧИТАЮТ ЭТО ОШИБКОЙ',C85.pil);e.flash=.1;return 0;}
  g.st='hostile';e.peace=false;e.hostile80=true;e.cd=1;floater(e.x,e.y-24,'ПАЛОМНИК: ТЫ НЕ ИЗ НАС',C85.red);RI85('…ты не из нас…',{key:'hostile',cd:20});sfx('warn');return dmg;}
function pil85Hostile(e,dt){const p=G.player,pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1,k=clamp((pd-300)/100,-1,1);steer(e,pdx/pd*k-pdy/pd*.5*e.dir,pdy/pd*k+pdx/pd*.5*e.dir,e.spd*1.3,dt,2);
  e.cd-=dt;if(e.cd<=0&&p.hp>0&&pd<700){e.cd=1.3;const a=Math.atan2(pdy,pdx),n=Math.min(3,(G.st&&G.st.shots)||1);for(let i=0;i<n;i++)shootE(e.x,e.y,a+(i-(n-1)/2)*.12,520,6,'#dfe8ff',4);}}
function noteAI85(e,dt){e.vx=e.vy=0;const b=e.host85&&e.host85.alive?e.host85:null;if(!b){e.oa=(e.oa||0)+dt;return;}const p=G.player,slow=b.phase>=4?1.25:1;
  e.oa=(e.oa||0)+dt*.9/slow;e.x=b.cx+Math.cos(e.oa)*(e.or||b.r+50);e.y=b.cy+Math.sin(e.oa)*(e.or||b.r+50);
  e.fc=(e.fc===undefined?2:e.fc)-dt;if(e.fc<=0&&p.hp>0&&b.st==='fight'&&b.tr<=0){e.fc=3*slow*atkK();const q=shootE(e.x,e.y,Math.atan2(p.y-e.y,p.x-e.x),120,8,'#9fb8ff',5);if(q){q.homing=true;q.life=6;}}}
// эхо: запись 8 с полёта и выстрелов → Отзвук-0 повторяет; импульс рядом стирает
function wellEcho(b,dt){const p=G.player,overlap=rk85()>0&&b.hp<=b.maxHp*.55,R=b.rec;
  if(R){R.t+=dt;R.st+=dt;if(R.st>=.1&&p.hp>0){R.st=0;if(R.path.length<80)R.path.push({t:R.t,x:p.x,y:p.y});}
    for(const q of G.pb){if(q.e85)continue;q.e85=1;if(q.drone||q.turret||q.jr||q.test||(q.age||0)>.08||Math.hypot(q.x-p.x,q.y-p.y)>60)continue;
      if(R.shots.length>=120)R.shots=R.shots.filter((_,i)=>i%2===0);R.shots.push({t:R.t,a:Math.atan2(q.vy,q.vx),spd:Math.hypot(q.vx,q.vy),dmg:q.dmg,blast:q.blast?(q.R||110):0,charged:!!q.charged});}
    if(R.t>=8){b.rec=null;wellPlay(b,R);b.recT=overlap?.05:99;}}
  else{for(const q of G.pb)q.e85=1;b.recT-=dt;if(b.recT<=0&&b.ghosts.filter(g=>g.alive).length<2&&p.hp>0){b.rec={t:0,st:0,x0:p.x,y0:p.y,path:[{t:0,x:p.x,y:p.y}],shots:[]};snd85('rec');if(!b.recH){b.recH=1;floater(p.x,p.y-42,'● REC · КОЛОДЕЦ ЗАПИСЫВАЕТ ВАС',C85.red);}}}
  b.ghosts=b.ghosts.filter(g=>g.alive);if(!b.rec&&b.recT>50&&!b.ghosts.length)b.recT=1.5;
  b.echoT-=dt;if(b.echoT<=0){b.echoT=22;if(G.enemies.filter(e=>e.alive&&e.type==='echo80').length<pk85(1,1,2)){const a=rnd(0,TAU);spawnEnemy('echo80',b.cx+Math.cos(a)*(b.R-40),b.cy+Math.sin(a)*(b.R-40),{noAffix:true,spawnT:.6,escort:true});}}}
function wellPlay(b,R){const g=spawnEnemy('ghost85',R.x0,R.y0,{noAffix:true,noLoot:true,spawnT:.3,host85:b});g.rec=R;g.pt=0;g.si=0;g.rl=12;g.trail=[];b.ghosts.push(g);snd85('play');
  if(!RI85('…вот так ты летал восемь секунд назад…',{key:'ghost',cd:30})&&!b.ghH){}b.ghH=1;}
function ghostAI85(e,dt){e.vx=e.vy=0;const R=e.rec;if(!R){e.t85=(e.t85||0)+dt;e.x+=Math.cos(e.t85*.8)*20*dt;e.y+=Math.sin(e.t85*1.1)*20*dt;return;}
  const p=G.player,b=e.host85;e.pt+=dt;const P=R.path;let i=0;while(i<P.length-1&&P[i+1].t<=e.pt)i++;const a=P[i],c=P[Math.min(P.length-1,i+1)],k=c.t>a.t?clamp((e.pt-a.t)/(c.t-a.t),0,1):0;
  const nx=a.x+(c.x-a.x)*k,ny=a.y+(c.y-a.y)*k;e.face=Math.atan2(ny-e.y,nx-e.x)||e.face||0;e.x=nx;e.y=ny;e.trail.push({x:nx,y:ny});if(e.trail.length>18)e.trail.shift();
  e.rl=Math.min(12,(e.rl||0)+12*dt);const cap=[12,18,22][rk85()],X=x85();
  while(e.si<R.shots.length&&R.shots[e.si].t<=e.pt){const s=R.shots[e.si++];if(e.rl<1||p.hp<=0||!b||b.tr>0)continue;e.rl-=1;const q=shootE(e.x,e.y,s.a,Math.min(700,s.spd*.7),clamp(s.dmg*.4,2,cap),'#f2f6ff',s.charged?7:s.blast?6:4);
    if(q){q.gh85=1;X.trk.push(q);if(s.blast){q.bl85=s.blast*.6;q.life=1.1;X.bl.push(q);}}}
  if(e.pt>=R.t+.05){e.alive=false;explode(e.x,e.y,'#f2f6ff',10,.5);}}
function wellGhostDied(b,e){floater(e.x,e.y-26,'ЗАПИСЬ ОБОРВАНА','#f2f6ff');RI85('…ты стёр себя. Хорошо. Я тоже так делал…',{key:'wipe',cd:30});if(G.mc)G.mc.wipe85=1;}
function wellPulse(b,p,R){const rw=Math.max(220,R);for(const e of G.enemies){if(e.alive&&e.type==='pilgrim'&&e.pg85&&Math.hypot(e.x-p.x,e.y-p.y)<rw+e.r)wellWake(b,e);}
  if(b.phase===2){let wiped=false;for(const g of b.ghosts){if(g.alive&&Math.hypot(g.x-p.x,g.y-p.y)<260+g.r){kill(g,false);wiped=true;}}
    if(b.rec){b.rec=null;b.recT=2;wiped=true;}if(wiped){floater(p.x,p.y-44,'ЗАПИСЬ СТЁРТА','#f2f6ff');RI85('…ты стёр себя. Хорошо. Я тоже так делал…',{key:'wipe',cd:30});if(G.mc)G.mc.wipe85=1;}}}
// петля: три якоря держат счётчик; на нуле колодец отматывает себя на 6 с назад
function wellHist(b,dt){b.histT-=dt;if(b.histT>0)return;b.histT=.5;b.hist.push({t:G.t,hp:b.hp,alive:b.emit.filter(e=>e.alive).map(e=>e.ring+e.idx)});if(b.hist.length>14)b.hist.shift();}
function wellAnchors(b){const a0=rnd(0,TAU);b.anchors=[];for(let i=0;i<3;i++){const a=a0+i*TAU/3,e=spawnEnemy('anchor85',b.cx+Math.cos(a)*(b.R-60*b.k),b.cy+Math.sin(a)*(b.R-60*b.k),{noAffix:true,noLoot:true,spawnT:.6,host85:b});e.hp=e.maxHp=Math.round(b.maxHp*.025);b.anchors.push(e);}
  b.loopT=b.loopMax;b.anchT0=G.t;floater(b.cx,b.cy-b.r-46,'ПЕТЛЯ ЗАМЫКАЕТСЯ · РАЗБЕЙТЕ ТРИ ЯКОРЯ',C85.well);snd85('anchor');}
function wellLoop(b,dt){const al=b.anchors.filter(a=>a.alive);b.anchors=al;
  if(!al.length){if(b.loops>=b.loopCap)return;b.anchorT-=dt;if(b.anchorT<=0)wellAnchors(b);return;}
  if(al.some(a=>a.spawnT>0))return;b.loopT-=dt;
  if(!b.karr&&storyFlag('fleet27')==='engine'&&G.t-(b.anchT0||G.t)>3){b.karr=1;say85('ФЛОТ','#b8c4d6','Это Карр. Держу якорь. Бей остальные.',{force:1});const a=al[0],ea=Math.atan2(a.y-b.cy,a.x-b.cx);
    x74().tracers.push({x1:b.cx+Math.cos(ea)*(b.R+200),y1:b.cy+Math.sin(ea)*(b.R+200),x2:a.x,y2:a.y,t:.4,c:'#ffb84d'});explode(a.x,a.y,'#ffb84d',24,1);sfx('bigboom');floater(a.x,a.y-30,'ЗАЛП КАРРА','#ffb84d');a.hp=1;hurt(a,10,{force:true,pulse:true});if(a.alive)kill(a);}
  if(b.loopT<=0&&b.anchors.some(a=>a.alive))wellLoopFire(b);}
function wellLoopFire(b){const X=x85();X.rew=.8;snd85('rewind');b.loops++;if(G.mc)G.mc.loop38=1;
  let h=null;for(let i=b.hist.length-1;i>=0;i--){if(G.t-b.hist[i].t>=6){h=b.hist[i];break;}}if(!h)h=b.hist[0];
  if(h){const cap=b.maxHp*pk85(.06,.05,.05),hi=b.maxHp*b.th[1]-1,nh=Math.min(h.hp,b.hp+cap,hi);if(nh>b.hp)b.hp=nh;
    for(const key of h.alive){if(b.emit.some(e=>e.alive&&e.ring+e.idx===key))continue;const ring=wellRing(b,key[0]),i=+key.slice(1);const q=wellEmit(b,ring,i,.4,.5);q.back85=1;}}
  const a=b.anchors.find(q=>q.alive);if(a)spawnEnemy('loop',a.x,a.y,{noAffix:true,spawnT:.5,escort:true});
  RI85('…и снова. Как всегда…',{key:'loop',cd:8});banner('ПЕТЛЯ','КОЛОДЕЦ ОТМОТАЛ СЕБЯ НАЗАД');buzz('hit2');
  if(b.loops>=b.loopCap){for(const q of b.anchors)if(q.alive){q.alive=false;explode(q.x,q.y,C85.well,16,.7);}b.anchors=[];floater(b.cx,b.cy-b.r-46,'ПЕТЛЯ ИСЧЕРПАНА',C85.well);}else b.loopT=b.loopMax;}
function wellAnchorDied(b,e){explode(e.x,e.y,C85.well,22,.9);sfx('boom');if(b.anchors.some(a=>a!==e&&a.alive)){floater(e.x,e.y-26,'ЯКОРЬ РАЗБИТ · '+b.anchors.filter(a=>a!==e&&a.alive).length+' ОСТАЛОСЬ',C85.well);return;}
  b.stun=4;b.anchorT=25;b.brkN++;banner('ПЕТЛЯ РАЗОРВАНА','ЯДРО ОГЛУШЕНО · УРОН ×1,5');RI85('…так далеко ещё никто…',{key:'brk',cd:30});snd85('break');shake(8);}
// тишина: кольца становятся короной, один голос в эфире
function wellSilence(b,dt){const p=G.player;b.p4t+=dt;
  if(rk85()>0){b.invT-=dt;if(!b.iw&&b.invT<=0&&(rk85()>=2||b.invN<1)){b.iw={st:'tele',t:1,r:b.r};b.invN++;b.invT=30;snd85('inv');}}
  if(b.iw){const I=b.iw;if(I.st==='tele'){I.t-=dt;if(I.t<=0){I.st='go';I.hit=false;}}else{I.r+=500*dt;if(!I.hit&&p.hp>0&&Math.abs(Math.hypot(p.x-b.cx,p.y-b.cy)-I.r)<22){I.hit=true;if(p.dashT<=0&&!(x85().calm>0))invHit80();}if(I.r>b.R+20)b.iw=null;}}
  b.p4T-=dt;const L=wellP4();if(b.p4T<=0&&b.p4i<L.length){const q=L[b.p4i++];say85(q[0],q[0]==='ИСТОК'?C85.well:C85.voidc,q[1],{force:1});b.p4T=7;}
  if(!b.p4last&&b.hp<=b.maxHp*.03){b.p4last=true;say85('VØID',C85.voidc,storyFlag('line31')==='write'?'Ты оставил себя в лекале. Значит, тебя запомнят дважды.':'Теперь ты у самого дна.',{force:1});}}
function wellP4(){const L=[['ИСТОК','…Курсант Тео… прошу разрешения вернуться…'],['VØID',storyFlag('fleet27')==='bridge'?'…журнал обрывается на вопросе…':'…почему не в рубку… почему не в рубку…'],['VØID','Страж не добил меня. Сказал: «Опять рано».']];
  if(storyFlag('cradle22')==='cut')L.push(['VØID','…партия Кормилицы закрыта…']);L.push(['VØID','Я тоже летел на голос. Потом стал им.']);return L;}
// урон: ядро — в пул (×1,3, пока играет Отзвук; ×1,5 после разрыва петли); излучатель — свой запас и пул
function wellHurt(b,e,dmg,src){if(e.type==='wellcore'){const fl=b.phase>=4&&(b.p4t<18||b.p4i<3)?.03:0;pool85(b,dmg*wellCoreK(b),fl,e);return 0;}
  if(e.corona)return 0;const d=Math.min(dmg,e.hp);pool85(b,d,0,null);return dmg;}
function wellEmitDied(b,e){explode(e.x,e.y,C85.well,16,.7);sfx('boom');if(!b.gapH){b.gapH=1;floater(e.x,e.y-24,'ПРОХОД В КОЛЬЦЕ',C85.well);}}
// снаряды игрока: кольца глотают обычные, заряд и «Разрыв» проходят насквозь с уроном по излучателю
function wellBullet(b,bu){if(b.st!=='fight'||b.phase>=4)return false;
  // попадание в сам излучатель (раньше пересечения кольца) — по тем же правилам щита
  for(const e of b.emit){if(!e.alive||e.corona||e.spawnT>0||bu.hit.includes(e))continue;if(segDist(bu.px,bu.py,bu.x,bu.y,e.x,e.y)>e.r+3)continue;
    if(bu.charged||bu.blast){bu.hit.push(e);hurt(e,bu.dmg*1.5,{charged:!!bu.charged,blast:!!bu.blast});continue;}hurt(e,bu.dmg,{ring:true});bu.life=0;e.shieldFlash=.08;return true;}
  for(const ring of b.rings){const d0=Math.hypot(bu.px-b.cx,bu.py-b.cy),d1=Math.hypot(bu.x-b.cx,bu.y-b.cy),R=ring.r;if((d0-R)*(d1-R)>0)continue;
    const k=Math.abs(d0-d1)<1e-6?0:(d0-R)/(d0-d1),x=bu.px+(bu.x-bu.px)*k,y=bu.py+(bu.y-bu.py)*k,a=Math.atan2(y-b.cy,x-b.cx);
    const e=b.emit.find(q=>q.alive&&q.ring===ring.id&&!q.corona&&q.spawnT<=0&&Math.abs(angDiff(a,q.ang85))<ring.arc/2);if(!e)continue;
    if(bu.charged||bu.blast){if(!bu.hit.includes(e)){bu.hit.push(e);hurt(e,bu.dmg*1.5,{charged:!!bu.charged,blast:!!bu.blast});}continue;}
    hurt(e,bu.dmg,{ring:true});bu.life=0;e.shieldFlash=.08;if(SET.fx)part(x,y,vrnd3(-40,40),vrnd3(-40,40),.25,'#9fb8ff',2);return true;}
  return false;}
function wellBlocker(b,x,y){if(b.phase>=4)return null;const a=Math.atan2(y-b.cy,x-b.cx),d=Math.hypot(x-b.cx,y-b.cy);
  for(const ring of b.rings){if(d<ring.r)continue;const e=b.emit.find(q=>q.alive&&q.ring===ring.id&&!q.corona&&q.spawnT<=0&&Math.abs(angDiff(a,q.ang85))<ring.arc/2);if(e)return e;}return null;}
function wellAuto(p,b){let best=null,bs=1e9;const cand=(e,w)=>{if(!e||!e.alive||!targetable(e))return;const d=Math.hypot(e.x-p.x,e.y-p.y)/w;if(d<bs){bs=d;best=e;}};
  for(const a of b.anchors)cand(a,1.6);for(const g of b.ghosts)cand(g,1.15);for(const e of G.enemies){if(!e.alive)continue;if(e.type==='echo80')cand(e,1.25);else if(e.type==='loop'||e.type==='inverse'||(e.type==='pilgrim'&&e.hostile80))cand(e,1);}if(best&&bs<720)return best;
  const blk=wellBlocker(b,p.x,p.y);if(blk&&targetable(blk))return blk;return targetable(b)?b:null;}
function wellHud(b){if(b.stun>0)return 'ПЕТЛЯ РАЗОРВАНА · ЯДРО ОГЛУШЕНО ×1,5';if(b.phase===1)return 'ЗОВ · КОЛЬЦА ГЛОТАЮТ СНАРЯДЫ · БЕЙТЕ В ПРОХОДЫ';
  if(b.phase===2)return b.ghosts.some(g=>g.alive)?'ОТЗВУК-0 ИГРАЕТ · ЯДРО СЛУШАЕТ ×1,3':b.rec?'● REC · НЕ ПОВТОРЯЙТЕ СВОЙ ПУТЬ':'ЭХО';
  if(b.phase===3)return b.anchors.some(a=>a.alive)?'ЯКОРЯ ПЕТЛИ · РАЗБЕЙТЕ ДО НУЛЯ':b.loops>=b.loopCap?'ПЕТЛЯ ИСЧЕРПАНА':'ПЕТЛЯ';return 'ТИШИНА · СЛУШАЙТЕ';}
function wellStrip(b){
  if(b.st==='enter')return {l:'ПЕРВЫЙ СИГНАЛ · ИСТОЧНИК НЕ ОПОЗНАН',k:null,lc:C85.well};
  if(b.st==='scene')return {l:'VØID-013 · ЦИКЛ ??',k:null,lc:C85.voidc};
  if(b.st==='final')return {l:b.prev85?'ВЫ УЖЕ СДЕЛАЛИ ВЫБОР · ЛЕТИТЕ К ПРИЧАЛУ':'РЕШАЙТЕ, ЧТО УСЛЫШИТ СЛЕДУЮЩИЙ',k:null,lc:C85.voidc};
  if(b.phase===1)return {l:'ПРОБУЖДЕНО '+b.woke+' · ГОЛОСОВ КОЛОДЦУ '+b.absorbed,k:null,lc:C85.pil};
  if(b.phase===2){const g=b.ghosts.find(q=>q.alive&&q.rec);if(g)return {l:'▶ ОТЗВУК-0 · ЯДРО СЛУШАЕТ ×1,3',k:1-g.pt/8,col:'#f2f6ff',r:fmt85(8-g.pt)+' С'};if(b.rec)return {l:'● REC',lc:C85.red,k:b.rec.t/8,col:C85.red,r:fmt85(8-b.rec.t)+' С'};return {l:'ЭХО · ЗАПИСЬ СКОРО',k:null};}
  if(b.phase===3){const al=b.anchors.filter(a=>a.alive).length;if(al)return {l:'ПЕТЛЯ ЗАМЫКАЕТСЯ · '+Math.max(0,Math.ceil(b.loopT)),lc:b.loopT<5?C85.red:C85.well,k:b.loopT/b.loopMax,col:C85.well,r:'ЯКОРЯ '+al+'/3'};
    return {l:b.loops>=b.loopCap?'ПЕТЛЯ ИСЧЕРПАНА':b.stun>0?'ПЕТЛЯ РАЗОРВАНА · ЯДРО ОГЛУШЕНО':'ЯКОРЯ ВЕРНУТСЯ · '+Math.ceil(b.anchorT)+' С',k:null,lc:C85.well,r:'ПЕТЕЛЬ '+b.loops+'/'+b.loopCap};}
  return {l:'ТИШИНА',k:null,lc:C85.voidc};}
// третья кнопка: «write» + милость раньше + ни одного убитого паломника + ≥4 разбуженных в этом бою
function third85(b){const s=G.save&&G.save.story||{};return storyFlag('line31')==='write'&&(storyFlag('cradle22')==='keep'||storyFlag('fleet27')==='engine')&&!((s.pilgrimsKilled||0)>0)&&((b&&b.woke)||0)>=4;}
// фазы
function wellPhase(b){const X=x85();
  if(b.phase===2){banner('ПЕРВЫЙ СИГНАЛ · ФАЗА 2','ЭХО · ТАМ, ГДЕ ВЫ БЫЛИ, СТАНЕТ ОПАСНО');RI85('…постой. Я запомню, как ты летаешь…',{force:1,d:.5});b.recT=2.6;b.echoT=9;}
  if(b.phase===3){banner('ПЕРВЫЙ СИГНАЛ · ФАЗА 3','ПЕТЛЯ · РАЗБЕЙТЕ ТРИ ЯКОРЯ');RI85('…ещё раз. Ещё раз. Это не должно кончиться…',{force:1,d:.5});b.rec=null;for(const g of b.ghosts)if(g.alive)kill(g,true);b.ghosts=[];b.anchorT=1.2;
    if(X.ally&&X.ally.kind==='serial'){X.ally.t=Math.min(X.ally.t,1.5);floater(X.ally.x,X.ally.y-24,'СЕРИЙНИК 013 УХОДИТ',C85.lek);}}
  if(b.phase===4){banner('ПЕРВЫЙ СИГНАЛ · ФАЗА 4','ТИШИНА');b.anchors.forEach(a=>{if(a.alive){a.alive=false;explode(a.x,a.y,C85.well,12,.6);}});b.anchors=[];b.p4T=2.6;b.p4t=0;
    for(const e of b.emit){e.corona=true;e.ghost=true;e.tel85=0;e.bn85=0;}radioClear();X.silence=0;}}
function wellAlly(b){const X=x85();if(!X.allyPending)return;X.allyPending=0;const hp=Math.round(EDEF.serial85.hp*SEC_SCALE[7].hp*.6);
  X.ally={kind:'serial',x:G.player.x-60,y:G.player.y+40,a:0,cd:1,t:1e9,hp,maxHp:hp,no:13};say85('СЕРИЙНИК 013',C85.lek,'Сделан по новому лекалу. Лечу с тобой.',{force:1,d:1.2});floater(G.player.x,G.player.y-50,'СЕРИЙНИК 013 · СОЮЗНИК',C85.lek);}
// финал: белая вспышка, корабль на дне, голос
function wellFinal(b){if(G.x80&&G.x80.leaks)G.x80.leaks=G.x80.leaks.filter(q=>!q.w85);b.sons=[];b.iw=null;b.rec=null;b.scT=0;b.subOn=false;b.flashK=0;for(const e of b.emit)if(e.alive)kill(e,true);b.emit=[];snd85('final');banner('ГОЛОС ГАСНЕТ','НА ДНЕ — КОРАБЛЬ');}
function wellScene(b,dt){b.scT+=dt;b.flashK=b.scT<1.2?b.scT/1.2:Math.max(0,1-(b.scT-1.2)/1.6);
  if(b.st==='scene'&&b.scT>=2.6&&!b.subOn){b.subOn=true;
    sub85('VØID-013 · ЦИКЛ ??',C85.voidc,['«Это не чужой сигнал. Это мой. И твой».','«Каждый из нас долетает до дна и зовёт следующего».','«Стражи летят отсюда, чтобы остановить нас раньше. Паломники — чтобы звать громче».','«Это и есть последний сигнал. Последний — потому что каждый раз кажется последним».','«Решай, что услышит следующий».'],
      ()=>{if(b.st!=='scene')return;b.st='final';const t3=third85(b);
        const L=[{kind:'silence',x:b.cx-dock85dx(b.k),y:b.cy+b.R*.28,lab:'ЗАГЛУШИТЬ',sub:'тишина для всех'},{kind:'answer',x:b.cx+dock85dx(b.k),y:b.cy+b.R*.28,lab:'ОТВЕТИТЬ',sub:'сигнал — вашими словами'}];
        L.push({kind:'third',x:b.cx,y:b.cy+b.R*.72,lab:t3?'ПРОДОЛЖИТЬ ПОИСК':'…есть третья частота, но она не ловится…',sub:t3?'координаты за краем карты':'',lock:!t3});
        sb85SetDocks(b,L);banner('ПЕРВЫЙ СИГНАЛ','ЗАГЛУШИТЬ ИЛИ ОТВЕТИТЬ · ЛЕТИТЕ К ПРИЧАЛУ');sfx('level');});}
  if(b.st==='final')sb85Docks(b,dt);}
function epi85(l,w){const T={'break|silence':'«Больше никто не проснётся и никто не полетит. Ты — последний. Это тихо».','break|answer':'«Копий больше не будет, но твой голос остался. Его услышат другие — не копии».',
  'write|silence':'«Следующий проснётся, помня тебя, и не услышит никакого зова. Ему придётся искать самому».','write|answer':'«Следующий проснётся с твоей памятью и полетит на твой голос. Круг стал короче».',
  'write|third':'«Ты не позвал сюда и не замолчал. Ты позвал дальше».'};return T[l+'|'+w]||(w==='silence'?'«Колодец замолчал. Следующий проснётся в тишине».':w==='answer'?'«Сигнал теперь звучит твоими словами».':'«Ты позвал дальше».');}
function wellChoose(b,ch,world,prev){const badges=[];if(!b.ghostHit)badges.push('«Не оглядывайся»');if(!b.loops)badges.push('«Разомкнутый»');const bt=badges.length?' Бейджи: '+badges.join(', ')+'.':'';const ep=epi85(storyFlag('line31')||'',ch),X=x85();
  if(ch==='silence'){G.sbLomK=prev?1:2;X.silence=3;G.sbChoiceTxt=(prev?'Вы уже сделали выбор: колодец заглушён. ':'Колодец заглушён: лом ×2. Паломники сектора VIII разворачиваются, Исток молчит, Отзвуков и Петель в миссиях 32–37 меньше. Скин «Тишина». ')+ep+bt;
    SB_DEATH.well=['КОЛОДЕЦ ЗАМОЛЧАЛ','СЕКТОР VIII ПРОЙДЕН','Тишина — тоже ответ. Я так и не решился его дать.'];if(world&&!prev)own85('silence85');}
  else if(ch==='answer'){G.sbLomK=1;G.sbChoiceTxt=(prev?'Вы уже сделали выбор: вы ответили. ':'Вы ответили: лом ×1. Паломники видят в вас своего, модуль «Позывной» — первый импульс в миссии даёт щит и короткую неуязвимость. Скин «Позывной 013». ')+ep+bt;
    SB_DEATH.well=['СИГНАЛ ПРИНЯТ','СЕКТОР VIII ПРОЙДЕН','Ты ответил. Значит, следующий услышит не просьбу, а голос.'];if(world&&!prev)own85('callsign013');}
  else{G.sbLomK=prev?1:1.5;G.sbChoiceTxt=(prev?'Вы уже сделали выбор: поиск продолжается. ':'Сигнал перестроен на координаты за краем карты: лом ×1,5. На карте — «Сигнал за Пределом». Скин «Несущая». ')+ep+bt;
    SB_DEATH.well=['ТРЕТЬЯ ЧАСТОТА','СИГНАЛ ЗА ПРЕДЕЛОМ · СКОРО','Если слышишь это — значит, ты нашёл. Третий путь не здесь. Он там, куда сигнал никогда не звал.'];if(world&&!prev){own85('carrier85');if(G.save.story)G.save.story.third85=1;}}}

// ===== 0.8.5: отрисовка, звук, музыка =====
const CF85=(()=>{try{return 'filter' in document.createElement('canvas').getContext('2d');}catch(e){return false;}})();
function gray85(on,br){if(!CF85)return;ctx.filter=on?'grayscale(1) brightness('+(br||.75)+')':'none';}
function shipPath85(s){ctx.beginPath();ctx.moveTo(19*s,0);ctx.lineTo(-11*s,-12*s);ctx.lineTo(-5*s,0);ctx.lineTo(-11*s,12*s);ctx.closePath();}
// --- арена «Цех №0» (под врагами) ---
function lekUnder(b,t){const g=b.g||lekGeo(b),on=b.st==='fight'&&b.stopT<=0,wo=b.wo&&b.wo.st==='go',v=lekBeltSpd(),lit=b.st==='enter'?b.light:1;
  ctx.fillStyle='rgba(16,14,8,.55)';ctx.fillRect(0,0,W,H);
  ctx.strokeStyle='rgba(232,210,122,.05)';ctx.lineWidth=1;ctx.beginPath();for(let x=0;x<=W;x+=48){ctx.moveTo(x,0);ctx.lineTo(x,H);}for(let y=0;y<=H;y+=48){ctx.moveTo(0,y);ctx.lineTo(W,y);}ctx.stroke();
  // рельс крана
  const ry=g.rail;ctx.fillStyle='#14120a';ctx.fillRect(0,ry-7,W,14);ctx.save();ctx.beginPath();ctx.rect(0,ry-7,W,14);ctx.clip();ctx.fillStyle='rgba(232,210,122,.55)';for(let x=-20;x<W+20;x+=28){ctx.beginPath();ctx.moveTo(x,ry+7);ctx.lineTo(x+14,ry-7);ctx.lineTo(x+24,ry-7);ctx.lineTo(x+10,ry+7);ctx.closePath();ctx.fill();}ctx.restore();
  ctx.strokeStyle='#5a5230';ctx.lineWidth=2;ctx.strokeRect(-2,ry-7,W+4,14);
  // конвейеры
  for(let i=0;i<3;i++){const y=g.belts[i],h=g.bh,d=g.dir[i],stp=!on||b.beltStop&&b.beltStop[i];
    ctx.fillStyle='rgba(8,8,6,.78)';ctx.fillRect(0,y-h/2,W,h);ctx.fillStyle='#3a3420';ctx.fillRect(0,y-h/2-3,W,4);ctx.fillRect(0,y+h/2-1,W,4);
    const off=((b.beltT||0)*v)%48;ctx.fillStyle='#2a2616';for(let x=-48;x<W+48;x+=48){const xx=x+(stp?0:d*off);ctx.beginPath();ctx.arc(xx,y-h/2,3,0,TAU);ctx.arc(xx,y+h/2,3,0,TAU);ctx.fill();}
    ctx.save();ctx.beginPath();ctx.rect(0,y-h/2+4,W,h-8);ctx.clip();
    if(wo&&!stp){const o=((b.beltT||0)*140)%44;ctx.strokeStyle='rgba(255,79,110,'+(.35+.2*Math.sin(t*10))+')';ctx.lineWidth=4;for(let x=30;x<W;x+=110)for(let yy=y-h/2-44+o;yy<y+h/2+44;yy+=44){ctx.beginPath();ctx.moveTo(x-16,yy-8);ctx.lineTo(x,yy+6);ctx.lineTo(x+16,yy-8);ctx.stroke();}}
    else{const o=stp?0:((b.beltT||0)*v)%90;ctx.strokeStyle=stp?'rgba(232,210,122,.08)':'rgba(232,210,122,.17)';ctx.lineWidth=6;for(let x=-90;x<W+90;x+=90){const xx=x+d*o;ctx.beginPath();ctx.moveTo(xx-12*d,y-h*.28);ctx.lineTo(xx+8*d,y);ctx.lineTo(xx-12*d,y+h*.28);ctx.stroke();}}
    ctx.restore();if(stp&&b.st==='fight'&&b.stopT>0){ctx.globalAlpha=.6;worldLabel(W/2,y+4,'ЛЕНТА СТОИТ · '+Math.ceil(b.stopT)+' С',C85.lek);ctx.globalAlpha=1;}}
  // шлюзы
  for(const [x,lab] of [[18,'ПРИЁМКА'],[W-18,'ОТК']]){const y=g.belts[lab==='ОТК'?1:0];ctx.fillStyle='#0a0904';ctx.strokeStyle='#8a7a3a';ctx.lineWidth=2;ctx.fillRect(x-14,y-g.bh/2,28,g.bh);ctx.strokeRect(x-14,y-g.bh/2,28,g.bh);ctx.save();ctx.translate(x,y);ctx.rotate(-Math.PI/2);ctx.globalAlpha=.7;ctx.font='700 '+fpx(9)+'px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle=C85.lek;ctx.fillText(lab,0,3);ctx.restore();ctx.globalAlpha=1;}
  // печь утилизации
  const fy=g.furY,fh=H-fy;const gr=ctx.createLinearGradient(0,fy-30,0,H);gr.addColorStop(0,'rgba(255,122,61,0)');gr.addColorStop(.35,'rgba(255,122,61,.35)');gr.addColorStop(1,'rgba(255,60,30,.75)');ctx.fillStyle=gr;ctx.fillRect(0,fy-30,W,fh+30);
  ctx.strokeStyle='rgba(255,180,100,'+(.45+.25*Math.sin(t*3))+')';ctx.lineWidth=2;ctx.beginPath();for(let x=0;x<=W;x+=12)ctx.lineTo(x,fy+3*Math.sin(x*.05+t*4));ctx.stroke();
  if(SET.fx&&Math.random()<.5)part(rnd(0,W),fy+rnd(4,fh),rnd(-10,10),-rnd(30,90),.7,Math.random()<.5?'#ff7a3d':'#ffb84d',2.5);
  ctx.globalAlpha=.5*lit;ctx.font='700 '+fpx(10)+'px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#ffd0a0';ctx.fillText('ПЕЧЬ УТИЛИЗАЦИИ',W/2,g.furY+24);ctx.globalAlpha=1;
  // пульты смены
  for(const q of b.pults){const ready=q.cd<=0,col=b.stopT>0&&b.st==='fight'?'#7affc9':ready?C85.lek:'#6b7280';glow(q.x,q.y,40,col,ready?.4+.2*Math.sin(t*5):.15);
    ctx.save();ctx.translate(q.x,q.y);ctx.fillStyle='#10100a';ctx.strokeStyle=col;ctx.lineWidth=2;ctx.fillRect(-18,-13,36,26);ctx.strokeRect(-18,-13,36,26);ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,6,0,TAU);ctx.fill();
    if(q.ch>0){ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,28,-Math.PI/2,-Math.PI/2+TAU*q.ch/.6);ctx.stroke();}
    else if(!ready){ctx.strokeStyle=col;ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,24,-Math.PI/2,-Math.PI/2+TAU*(1-q.cd/25));ctx.stroke();}ctx.restore();
    if(b.st==='fight'||b.st==='enter'){label85(q.x,q.y-40,'ПУЛЬТ СМЕНЫ',col);label85(q.x,q.y-25,ready?'СТОП ЛЕНТ · 0,6 С':'ПЕРЕЗАРЯДКА '+Math.ceil(q.cd)+' С',col);}}
  // лампы ОТК
  if(b.phase===2&&b.st==='fight'){for(let i=0;i<3;i++){const L=lekLamp(b,i),hot=b.inCone;if(!L.on){ctx.fillStyle='#3a3420';ctx.beginPath();ctx.arc(L.x,L.y+6,6,0,TAU);ctx.fill();continue;}ctx.fillStyle=hot?'rgba(255,211,107,.16)':'rgba(255,211,107,.07)';ctx.beginPath();ctx.moveTo(L.x,L.y);ctx.arc(L.x,L.y,LAMP85.len,L.a-LAMP85.ha,L.a+LAMP85.ha);ctx.closePath();ctx.fill();
      ctx.strokeStyle='rgba(255,211,107,.35)';ctx.lineWidth=1;ctx.stroke();ctx.fillStyle='#ffd36b';ctx.beginPath();ctx.arc(L.x,L.y+6,7,0,TAU);ctx.fill();glow(L.x,L.y+6,22,'#ffd36b',.5);}
    if(b.cone>0){const p=G.player;ctx.strokeStyle='#ffd36b';ctx.lineWidth=3;ctx.beginPath();ctx.arc(p.x,p.y,p.r+12,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,b.cone/.8));ctx.stroke();}}
  // обломки манипуляторов
  for(const k of G.pick){if(k.k!=='wreck85')continue;ctx.save();ctx.translate(k.x,k.y);ctx.rotate(k.t*.7+k.x*.01);ctx.fillStyle='#1c1a10';ctx.strokeStyle='#c9b15a';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-11,-5);ctx.lineTo(9,-8);ctx.lineTo(12,4);ctx.lineTo(-6,8);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}}
// --- арена «Колодец» (под врагами) ---
function wellUnder(b,t){const p=G.player,R=b.R,lit=b.st==='enter'?b.lit:1;
  ctx.fillStyle='rgba(2,3,8,.9)';ctx.beginPath();ctx.rect(-4000,-4000,8000+W,8000+H);ctx.arc(b.cx,b.cy,R,0,TAU,true);ctx.fill('evenodd');
  const gr=ctx.createRadialGradient(b.cx,b.cy,R*.08,b.cx,b.cy,R);gr.addColorStop(0,'rgba(1,2,8,.92)');gr.addColorStop(.6,'rgba(8,14,40,.55)');gr.addColorStop(1,'rgba(18,30,80,.35)');ctx.fillStyle=gr;ctx.beginPath();ctx.arc(b.cx,b.cy,R,0,TAU);ctx.fill();
  const n=G.q===0||G.lowFx?3:6,ox=p?(p.x-b.cx):0,oy=p?(p.y-b.cy):0;
  for(let i=1;i<=n;i++){const k=i/(n+1),rr=R*k,par=(1-k)*.12;ctx.strokeStyle='rgba(107,140,255,'+((.04+.08*k)*lit).toFixed(3)+')';ctx.lineWidth=1+k*2;ctx.beginPath();ctx.arc(b.cx-ox*par,b.cy-oy*par,rr,0,TAU);ctx.stroke();}
  ctx.strokeStyle='rgba(107,140,255,'+(.5*lit).toFixed(3)+')';ctx.lineWidth=3;ctx.setLineDash([14,10]);ctx.lineDashOffset=-t*6;ctx.beginPath();ctx.arc(b.cx,b.cy,R,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;
  // дорожки колец
  if(b.st==='fight'||b.st==='enter'){for(const ring of b.rings){const rr=ring.r+(64*b.k-ring.r)*(b.collapse||0);ctx.strokeStyle='rgba(107,140,255,.12)';ctx.lineWidth=2;ctx.setLineDash([3,7]);ctx.beginPath();ctx.arc(b.cx,b.cy,rr,0,TAU);ctx.stroke();ctx.setLineDash([]);}}}
function sb85Under(t){const b=sb85();if(!b||!inMission())return;if(SBX[b.sbk]){if(SBX[b.sbk].under)SBX[b.sbk].under(b,t);return;}if(b.sbk==='lek')lekUnder(b,t);else wellUnder(b,t);}
// --- над врагами ---
function dock85Draw(b,t){if(!b.docks)return;for(const d of b.docks){const col=d.lock?'#5a6478':d.off?'#4a4f5c':d.col?d.col:d.kind==='break'?'#ff7a3d':d.kind==='write'?C85.lek:d.kind==='silence'?'#9fb0c4':d.kind==='answer'?C85.voidc:'#ffffff';
    ctx.globalAlpha=d.off?.45:d.lock?.6:1;glow(d.x,d.y,54,col,d.off||d.lock?.15:.35+.15*Math.sin(t*4));ctx.strokeStyle=col;ctx.lineWidth=d.lock?1.5:2.5;if(d.lock)ctx.setLineDash([4,6]);ctx.beginPath();ctx.arc(d.x,d.y,46,0,TAU);ctx.stroke();ctx.setLineDash([]);
    if(!d.off&&!d.lock){ctx.lineWidth=1;ctx.beginPath();ctx.arc(d.x,d.y,30+4*Math.sin(t*3),0,TAU);ctx.stroke();}
    if(d.ch>0){ctx.strokeStyle='#ffffff';ctx.lineWidth=4;ctx.beginPath();ctx.arc(d.x,d.y,52,-Math.PI/2,-Math.PI/2+TAU*Math.min(1,d.ch/.6));ctx.stroke();}
    worldLabel(d.x,d.y-58,d.lab,col);if(d.sub){const st=d.off?'ДРУГОЙ ВЫБОР':d.prev?'ВАШ ВЫБОР':d.sub;let gap=1e9;for(const o of b.docks)if(o!==d&&Math.abs(o.y-d.y)<30)gap=Math.min(gap,Math.abs(o.x-d.x));ctx.font='700 '+fpx(11)+'px "JetBrains Mono",monospace';const L=gap<1e9&&ctx.measureText(st).width>gap-18?wrap85(st,Math.max(90,gap-18)):[st];L.forEach((ln,i)=>worldLabel(d.x,d.y+64+i*fpx(13),ln,col));}ctx.globalAlpha=1;}}
function armIK85(sx,sy,tx,ty,L,side){const dx=tx-sx,dy=ty-sy,d=Math.min(Math.hypot(dx,dy)||1,2*L-1),a=Math.atan2(dy,dx),c=Math.acos(clamp(d/(2*L),-1,1));const ea=a+side*c;return {ex:sx+Math.cos(ea)*L,ey:sy+Math.sin(ea)*L,hx:sx+Math.cos(a)*d,hy:sy+Math.sin(a)*d};}
function lekDraw(b,t){const p=G.player,g=b.g;
  // руки манипуляторов (от плеча к цели: хват → заготовка → покой)
  for(const arm of [b.armL,b.armR]){if(!lekAlive(arm)||arm.spawnT>0)continue;const side=arm.role==='armL'?-1:1,Gr=b.grab&&b.grab.arm===arm?b.grab:null;let tx,ty;
    if(Gr&&Gr.st!=='tele'){tx=Gr.hx;ty=Gr.hy;}else if(b.asm){tx=b.asm.e.x+side*24;ty=b.asm.e.y-10;}else{tx=arm.x+side*40*g.k;ty=arm.y+130*g.k+10*Math.sin(t*1.5+side);}
    const L=150*g.k,ik=armIK85(arm.x,arm.y,tx,ty,L,side>0?-1:1);
    ctx.strokeStyle=arm.flash>0?'#ffffff':'#c9b15a';ctx.lineWidth=10*g.k;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(arm.x,arm.y);ctx.lineTo(ik.ex,ik.ey);ctx.lineTo(ik.hx,ik.hy);ctx.stroke();
    ctx.strokeStyle='#14120a';ctx.lineWidth=3*g.k;ctx.beginPath();ctx.moveTo(arm.x,arm.y);ctx.lineTo(ik.ex,ik.ey);ctx.lineTo(ik.hx,ik.hy);ctx.stroke();ctx.lineCap='butt';
    ctx.fillStyle='#1c1a10';ctx.strokeStyle='#e8d27a';ctx.lineWidth=2;ctx.beginPath();ctx.arc(ik.ex,ik.ey,7*g.k,0,TAU);ctx.fill();ctx.stroke();
    // трос хвата дальше досягаемости
    let cx=ik.hx,cy=ik.hy;if(Gr&&Gr.st!=='tele'&&Math.hypot(Gr.hx-ik.hx,Gr.hy-ik.hy)>4){ctx.strokeStyle='#9fb0c4';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(ik.hx,ik.hy);ctx.lineTo(Gr.hx,Gr.hy);ctx.stroke();cx=Gr.hx;cy=Gr.hy;}
    const ca=Gr&&Gr.st!=='tele'?Gr.a:Math.atan2(ty-ik.ey,tx-ik.ex),open=Gr&&Gr.st==='fly'?.7:Gr&&Gr.st==='hold'?.15:b.asm?.3+.2*Math.sin(t*12):.45;
    ctx.save();ctx.translate(cx,cy);ctx.rotate(ca);ctx.strokeStyle=Gr&&Gr.st==='hold'?'#ff4f6e':'#e8d27a';ctx.lineWidth=4*g.k;for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(10*g.k,s*12*open*g.k+s*4);ctx.lineTo(20*g.k,s*4*g.k);ctx.stroke();}ctx.restore();
    if(b.asm&&SET.fx&&Math.random()<.5)part(ik.hx+rnd(-4,4),ik.hy+rnd(-4,4),rnd(-120,120),rnd(-160,20),.25,Math.random()<.5?'#ffffff':'#ffd36b',2);}
  // сборка: кольцо прогресса
  if(b.asm&&b.asm.e.alive){const e=b.asm.e,k=b.asm.t/3;ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.85;ctx.lineWidth=3;ctx.beginPath();ctx.arc(e.x,e.y,e.r+12,-Math.PI/2,-Math.PI/2+TAU*k);ctx.stroke();ctx.globalAlpha=1;worldLabel(e.x,e.y-e.r-20,'СБОРКА '+Math.round(k*100)+'%','#ff4f6e');}
  // печати ОТК
  for(const s of b.stamps){if(s.t<=0)continue;ctx.save();ctx.translate(s.x,s.y);ctx.rotate(s.sp);ctx.fillStyle='#2a1406';ctx.strokeStyle='#ff7a3d';ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<8;i++){const a=i/8*TAU,rr=i%2?6:11;ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#ffd36b';ctx.beginPath();ctx.arc(0,0,3,0,TAU);ctx.fill();ctx.restore();}
  // Серийники: номер на борту, вспышка стволов
  for(const e of G.enemies){if(!e.alive||e.type!=='serial85'||e.spawnT>0)continue;worldLabel(e.x,e.y-e.r-12,String(e.no85||14).padStart(3,'0'),C85.lek);
    if(e.sf&&e.sf.st==='tele'){glow(e.x,e.y,30,'#ffd36b',(.5+.4*Math.sin(t*40))*tl85());}}
  dock85Draw(b,t);}
function wellDraw(b,t){const p=G.player;
  // якоря: цепь к ядру и счётчик
  for(const a of b.anchors){if(!a.alive)continue;ctx.strokeStyle=C85.well;ctx.globalAlpha=.35+.2*Math.sin(t*6);ctx.lineWidth=2;ctx.setLineDash([6,6]);ctx.lineDashOffset=-t*30;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.cx,b.cy);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.globalAlpha=1;}
  if(b.anchors.some(a=>a.alive)&&b.st==='fight')worldLabel(b.cx,b.cy-b.r-28,'ПЕТЛЯ · '+Math.max(0,Math.ceil(b.loopT)),b.loopT<5?C85.red:C85.well);
  // запись: тонкий красный след; Отзвук-0: впереди его путь
  if(b.rec&&b.rec.path.length>1){ctx.strokeStyle=C85.red;ctx.globalAlpha=.55;ctx.lineWidth=1.5;ctx.beginPath();for(const q of b.rec.path)ctx.lineTo(q.x,q.y);if(p)ctx.lineTo(p.x,p.y);ctx.stroke();ctx.globalAlpha=1;const q=b.rec.path[0];ctx.fillStyle=C85.red;ctx.beginPath();ctx.arc(q.x,q.y,4,0,TAU);ctx.fill();}
  for(const g of b.ghosts){if(!g.alive||!g.rec)continue;const P_=g.rec.path;ctx.strokeStyle='#f2f6ff';ctx.globalAlpha=.25;ctx.lineWidth=1;ctx.setLineDash([3,6]);ctx.beginPath();ctx.moveTo(g.x,g.y);for(const q of P_)if(q.t>g.pt&&q.t<g.pt+2)ctx.lineTo(q.x,q.y);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
  // паломники: разбуженные
  for(const e of G.enemies){if(e.alive&&e.type==='pilgrim'&&e.pg85&&e.pg85.st==='woke')worldLabel(e.x,e.y-e.r-26,'ПРОСНУЛСЯ',C85.pil);}
  // корабль на дне
  if(b.st==='scene'||b.st==='final'||b.st==='dying'){const sx=b.cx,sy=b.cy,fx=b.fx85;ctx.save();ctx.translate(sx,sy);ctx.rotate(-Math.PI/2+.25*Math.sin(t*.4));ctx.globalAlpha=.9;gray85(true,.65);drawShip(curSkin(),t,0,{});gray85(false);
    ctx.strokeStyle='rgba(10,12,20,.8)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-4,-6);ctx.lineTo(6,2);ctx.moveTo(-8,5);ctx.lineTo(0,9);ctx.stroke();ctx.restore();ctx.globalAlpha=1;
    const on=!(fx&&fx.kind==='silence'),blink=Math.sin(t*(fx&&fx.kind==='answer'?6:3.2))>.2,dc=fx&&fx.kind==='answer'?shipCol():fx&&fx.kind==='third'?'#ffffff':'#ff4f6e';
    if(on&&blink){glow(sx+8,sy-12,16,dc,.9);ctx.fillStyle=dc;ctx.beginPath();ctx.arc(sx+8,sy-12,2.5,0,TAU);ctx.fill();}worldLabel(sx,sy+34,'013','#9fb0c4');}
  dock85Draw(b,t);}
function ally85Draw(t){const X=G.x85,A=X&&X.ally;if(!A)return;ctx.save();ctx.translate(A.x,A.y);ctx.rotate(A.ang||0);ctx.fillStyle='#2a2408';ctx.strokeStyle=shipCol();ctx.lineWidth=2;shipPath85(.8);ctx.fill();ctx.stroke();ctx.restore();
  worldLabel(A.x,A.y-20,(A.kind==='appr'?'УЧЕНИК':'013')+(A.maxHp&&A.kind==='serial'?' '+Math.ceil(A.hp/A.maxHp*100)+'%':''),shipCol());}
function sb85Draw(b,t){if(SBX[b.sbk]){if(SBX[b.sbk].draw)SBX[b.sbk].draw(b,t);}else if(b.sbk==='lek')lekDraw(b,t);else wellDraw(b,t);if(inMission())ally85Draw(t);}
// --- поверх маски темноты: телеграфы, сонар, сцены, субтитры ---
function edge85(x,y,col){const m=18;if(x>CX+m&&x<CX+VW-m&&y>CY+m&&y<CY+VH-m)return;const cx=CX+VW/2,cy=CY+VH/2,a=Math.atan2(y-cy,x-cx);const ex=clamp(x,CX+m,CX+VW-m),ey=clamp(y,CY+m,CY+VH-m);
  ctx.save();ctx.translate(ex,ey);ctx.rotate(a);ctx.fillStyle=col;ctx.globalAlpha=.6+.35*Math.sin(G.t*14);ctx.beginPath();ctx.moveTo(10,0);ctx.lineTo(-6,-8);ctx.lineTo(-6,8);ctx.closePath();ctx.fill();ctx.restore();ctx.globalAlpha=1;}
function lekTop(b,t){const p=G.player,g=b.g,tk=tl85();
  if(b.st==='enter'){const rows=8;ctx.fillStyle='#030304';for(let i=0;i<rows;i++){const k=clamp(b.light*rows*1.15-i,0,1);if(k>=1)continue;ctx.globalAlpha=.92*(1-k);ctx.fillRect(-10,H*i/rows,W+20,H/rows+1);}ctx.globalAlpha=1;
    if(b.scan&&b.scanT<1.6){const k=b.scanT/1.6,y=p.y-80+160*k;ctx.strokeStyle=C85.lek;ctx.globalAlpha=.8;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(b.fx,b.fy+40);ctx.lineTo(p.x-40,y);ctx.lineTo(p.x+40,y);ctx.closePath();ctx.stroke();ctx.globalAlpha=.12;ctx.fillStyle=C85.lek;ctx.fill();ctx.globalAlpha=1;worldLabel(p.x,p.y+40,'СКАН ИЗДЕЛИЯ',C85.lek);}}
  if(b.press){const P=b.press,y=g.belts[P.i],hh=g.bh/2;if(P.st==='tele'){const k=1-P.t/P.T;ctx.fillStyle='rgba(255,79,110,'+((.12+.2*k)*tk).toFixed(3)+')';ctx.fillRect(P.x-80,y-hh,160,g.bh);ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=(.5+.45*Math.sin(t*26))*tk;ctx.lineWidth=3;ctx.strokeRect(P.x-80,y-hh,160,g.bh);ctx.globalAlpha=tk;
      ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(P.x-80*k,y-hh,160*k,g.bh);ctx.globalAlpha=1;worldLabel(P.x,y+4,'ПРЕСС',C85.red);edge85(P.x,y,C85.red);}
    const top=b.pr&&b.pr.alive?b.pr.y+14*g.k:b.fy+100*g.k,hy=P.st==='tele'?top+(y-hh-top)*(1-P.t/P.T)*.85:P.st==='up'?y-hh+(top-(y-hh))*(1-P.t/.5):y-hh;
    ctx.strokeStyle='#8a8060';ctx.lineWidth=14*g.k;ctx.beginPath();ctx.moveTo(P.x,top);ctx.lineTo(P.x,hy);ctx.stroke();ctx.fillStyle='#1c1a10';ctx.strokeStyle=C85.lek;ctx.lineWidth=2;ctx.fillRect(P.x-80,hy-10,160,12);ctx.strokeRect(P.x-80,hy-10,160,12);
    if(P.hitT&&G.t-P.hitT<.25){ctx.fillStyle='rgba(255,255,255,'+(.32*(1-(G.t-P.hitT)/.25)).toFixed(3)+')';ctx.fillRect(P.x-80,y-hh,160,g.bh);}}
  const Gr=b.grab;if(Gr&&Gr.st==='tele'&&lekAlive(Gr.arm)){const a=Gr.arm;ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=(.45+.4*Math.sin(t*24))*tk;ctx.lineWidth=2;ctx.setLineDash([8,8]);ctx.lineDashOffset=-t*40;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(a.x+Math.cos(Gr.a)*520,a.y+Math.sin(Gr.a)*520);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.globalAlpha=1;
    const hx=a.x+Math.cos(Gr.a)*60,hy=a.y+Math.sin(Gr.a)*60;worldLabel(hx,hy-14,'ХВАТ',C85.red);}
  if(b.salvo){const S=b.salvo,k=1-S.t/S.T,n=Math.max(6,Math.min(18,b.hop.length)),sp=Math.min(.12,1.3/Math.max(1,n-1))*(n-1)/2+.06;ctx.fillStyle='rgba(255,79,110,'+((.1+.18*k)*tk).toFixed(3)+')';ctx.beginPath();ctx.moveTo(b.fx,b.fy);ctx.arc(b.fx,b.fy,560,S.a-sp,S.a+sp);ctx.closePath();ctx.fill();
    ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=(.5+.4*Math.sin(t*22))*tk;ctx.lineWidth=2;ctx.stroke();ctx.globalAlpha=1;worldLabel(b.fx+Math.cos(S.a)*150,b.fy+Math.sin(S.a)*150,'ВСЯ СМЕНА · '+b.hop.length,C85.red);}
  if(b.wo){const W_=b.wo;if(W_.st==='warn'||Math.sin(t*8)>0){ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.5;ctx.lineWidth=8;ctx.strokeRect(CX+4,CY+4,VW-8,VH-8);ctx.globalAlpha=1;}if(W_.st==='warn')worldLabel(p.x,p.y-46,'СПИСАНИЕ · '+fmt85(W_.t),C85.red);}
  // матрица и печь видны в темноте
  if(G.bo80>.3&&b.st==='fight'){const op=lekCoreOpen(b);glow(b.fx,b.fy,op?60:30,op?'#ffffff':C85.lek,op?.9:.5);if(op){ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(b.fx,b.fy,32*g.k,-Math.PI/2,-Math.PI/2+TAU*(b.win/b.winMax));ctx.stroke();}}}
function wellTop(b,t){const p=G.player,tk=tl85();
  for(const S of b.sons){if(S.t>0){const k=1-S.t/S.T;ctx.strokeStyle='#ffffff';ctx.globalAlpha=(.55+.4*Math.sin(t*24))*tk;ctx.lineWidth=5;for(const gp of S.gaps){ctx.beginPath();ctx.arc(b.cx,b.cy,b.r+10+8*k,gp.a-gp.w/2,gp.a+gp.w/2);ctx.stroke();}
      ctx.globalAlpha=.25*tk;ctx.lineWidth=2;ctx.setLineDash([4,8]);for(const gp of S.gaps){ctx.beginPath();ctx.moveTo(b.cx+Math.cos(gp.a)*(b.r+14),b.cy+Math.sin(gp.a)*(b.r+14));ctx.lineTo(b.cx+Math.cos(gp.a)*b.R,b.cy+Math.sin(gp.a)*b.R);ctx.stroke();}ctx.setLineDash([]);ctx.globalAlpha=1;continue;}
    ctx.strokeStyle='#eef3ff';ctx.globalAlpha=.9;ctx.lineWidth=7;ctx.beginPath();const gs=S.gaps.slice().sort((a,c)=>((a.a%TAU)+TAU)%TAU-((c.a%TAU)+TAU)%TAU);
    for(let i=0;i<gs.length;i++){const a0=gs[i].a+gs[i].w/2,a1=gs[(i+1)%gs.length].a-gs[(i+1)%gs.length].w/2+(i===gs.length-1?TAU:0);let e1=a1;while(e1<a0)e1+=TAU;ctx.moveTo(b.cx+Math.cos(a0)*S.r,b.cy+Math.sin(a0)*S.r);ctx.arc(b.cx,b.cy,S.r,a0,e1);}ctx.stroke();ctx.globalAlpha=1;}
  for(const e of b.emit){if(e.alive&&e.tel85>0){glow(e.x,e.y,30,'#9fb8ff',(.6+.35*Math.sin(t*30))*tk);ctx.strokeStyle='#9fb8ff';ctx.globalAlpha=.5*tk;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(p.x,p.y);ctx.stroke();ctx.globalAlpha=1;}}
  if(b.iw){const I=b.iw;if(I.st==='tele'){ctx.strokeStyle='#e86bff';ctx.globalAlpha=.8*tk;ctx.lineWidth=2;ctx.beginPath();ctx.arc(b.cx,b.cy,b.r+40*(I.t/1),0,TAU);ctx.stroke();ctx.globalAlpha=1;worldLabel(b.cx,b.cy+b.r+30,'ИЗНАНКА','#e86bff');}
    else{ctx.strokeStyle='#e86bff';ctx.globalAlpha=.75*(1-I.r/(b.R+20));ctx.lineWidth=5;ctx.beginPath();ctx.arc(b.cx,b.cy,I.r,0,TAU);ctx.stroke();ctx.globalAlpha=1;}}
  if(b.phase>=4&&b.st==='fight'){glow(b.cx,b.cy,80,'#dfe8ff',.5+.2*Math.sin(t*2));}
  for(const a of b.anchors)if(a.alive)edge85(a.x,a.y,C85.well);
  if(b.st==='scene'&&b.flashK>0){ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#ffffff';ctx.globalAlpha=Math.min(SET.fx?1:.6,b.flashK)*(SET.fx?.95:.6);ctx.fillRect(0,0,cv.width,cv.height);ctx.restore();ctx.globalAlpha=1;}}
function rew85Draw(){const X=G.x85;if(!X||!(X.rew>0))return;const k=X.rew/.8;ctx.save();ctx.setTransform(1,0,0,1,0,0);const w=cv.width,h=cv.height;ctx.globalAlpha=.22*k;
  for(let i=0;i<9;i++){const y=((G.t*900+i*h/9)%h);ctx.fillStyle=i%2?'#6b8cff':'#ff4f6e';ctx.fillRect(0,y,w,Math.max(2,h/60));}
  ctx.globalAlpha=.12*k;ctx.fillStyle='#ff004c';ctx.fillRect(6*DPR,0,w,h);ctx.fillStyle='#00c8ff';ctx.fillRect(-6*DPR,0,w,h);ctx.restore();ctx.globalAlpha=1;}
// подпись, которая не уходит за край видимой части арены (телефон: камера ходит по арене 1280×760)
function label85(x,y,text,col){ctx.font='700 '+fpx(11)+'px "JetBrains Mono",monospace';const hw=ctx.measureText(text).width/2+4,l=G.arena?CX:0,r=l+(G.arena?VW:W);worldLabel(hw*2<r-l?clamp(x,l+hw,r-hw):x,y,text,col);}
function wrap85(text,maxW){const words=text.split(' '),lines=[];let cur='';for(const w of words){const t=cur?cur+' '+w:w;if(ctx.measureText(t).width>maxW&&cur){lines.push(cur);cur=w;}else cur=t;}if(cur)lines.push(cur);return lines;}
function sub85Draw(){const X=G.x85,S=X&&X.sub;if(!S)return;const line=S.lines[S.i];if(!line)return;const d=subDur85(line),a=clamp(Math.min(S.t*4,(d-S.t)*4),0,1);
  ctx.save();ctx.setTransform(1,0,0,1,0,0);const k=DPR,w=cv.width,h=cv.height,mob=isMob(),fs=(mob?15:17)*k;ctx.font='600 '+fs+'px "JetBrains Mono",monospace';const L=wrap85(line,Math.min(w*.84,760*k));
  const lh=fs*1.35,boxH=lh*L.length+48*k,y0=h*(mob&&!isPortrait()?.56:.66)-boxH/2,bw=Math.min(w*.9,800*k);
  ctx.globalAlpha=.78*a;ctx.fillStyle='#04060c';ctx.fillRect(w/2-bw/2,y0,bw,boxH);ctx.globalAlpha=a;ctx.strokeStyle=S.col;ctx.lineWidth=1*k;ctx.strokeRect(w/2-bw/2,y0,bw,boxH);
  ctx.textAlign='center';ctx.fillStyle=S.col;ctx.font='700 '+(11*k)+'px "JetBrains Mono",monospace';ctx.fillText(S.cap+'  ·  '+(S.i+1)+'/'+S.lines.length,w/2,y0+16*k);
  ctx.fillStyle='#eef3ff';ctx.font='600 '+fs+'px "JetBrains Mono",monospace';L.forEach((s,i)=>ctx.fillText(s,w/2,y0+30*k+lh*(i+.8)));
  if(S.t>.6){ctx.globalAlpha=.45*a;ctx.fillStyle='#9fb0c4';ctx.font='600 '+(10*k)+'px "JetBrains Mono",monospace';ctx.fillText(touchMode?'КАСАНИЕ — ДАЛЬШЕ':'ПРОБЕЛ / КЛИК — ДАЛЬШЕ',w/2,y0+boxH-7*k);}
  ctx.restore();ctx.globalAlpha=1;}
function sb85Top(t){const b=G.sb&&is85(G.sb)&&G.sb.alive?G.sb:null;if(b&&inMission()){if(SBX[b.sbk]){if(SBX[b.sbk].top)SBX[b.sbk].top(b,t);}else if(b.sbk==='lek')lekTop(b,t);else wellTop(b,t);}rew85Draw();sub85Draw();}
// дыры в маске темноты: печь, глаз матрицы, пульты; ядро колодца
function holes85(hole,band){const b=sb85();if(!b)return;if(SBX[b.sbk])return;if(b.sbk==='lek'){const g=b.g||lekGeo(b);if(band)band(H-125,H-48);else for(let x=40;x<W;x+=120)hole(x,H-24,95);hole(b.fx,b.fy,lekCoreOpen(b)?110:70);for(const q of b.pults)hole(q.x,q.y,60);}
  else{hole(b.cx,b.cy,b.phase>=4||b.st!=='fight'?130:110);}}
// --- рисунки сущностей (из drawE80) ---
function drawE85(e,t,icon,col,face,alpha,P){const r=e.r;
  switch(e.type){
    case 'lekalo':{const b=!icon&&G.sb===e?e:null,g=b&&b.g?b.g:{k:1,rail:-80};const k=icon?.32:g.k,fx=b&&b.fx85,br=fx&&fx.kind==='break',wr=fx&&fx.kind==='write';
      if(br&&fx.t>.25){/* рама рассыпалась */}else{
      if(!icon){ctx.strokeStyle='#5a5230';ctx.lineWidth=2;const ry=g.rail-e.y;for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(s*176*k,-72*k);ctx.lineTo(s*120*k,ry);ctx.stroke();}ctx.fillStyle='#1c1a10';ctx.strokeStyle=C85.lek;ctx.fillRect(-60*k,ry-9,120*k,18);ctx.strokeRect(-60*k,ry-9,120*k,18);}
      const open=b?(b.st==='scene'||b.st==='final'?b.openK:0):0,frameCol=e.flash>0?'#ffffff':wr?shipCol():col;
      ctx.lineJoin='miter';ctx.beginPath();ctx.moveTo(0,104*k);ctx.lineTo(182*k,-74*k);ctx.lineTo(0,-36*k-open*30*k);ctx.lineTo(-182*k,-74*k);ctx.closePath();ctx.fillStyle='rgba(12,10,4,.55)';ctx.fill();
      // VØID-001
      if(!icon){const sw=Math.sin(t*1.1)*.05,dy=br?Math.min(600,fx.t*fx.t*420):0;ctx.save();ctx.translate(0,46*k+dy);ctx.rotate(Math.PI/2+sw+(br?fx.t*2:0));ctx.globalAlpha=alpha*(wr?.95:.62+.3*open);if(!wr)gray85(true,.8);ctx.scale(2.1*k,2.1*k);drawShip(curSkin(),t,0,{});gray85(false);if(!wr){ctx.strokeStyle='rgba(223,232,255,.35)';ctx.lineWidth=.8;shipPath85(1.05);ctx.stroke();}ctx.restore();ctx.globalAlpha=alpha;
        if(!br){ctx.strokeStyle='rgba(201,210,222,.4)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-34*k,-28*k);ctx.lineTo(-10*k,30*k);ctx.moveTo(34*k,-28*k);ctx.lineTo(10*k,30*k);ctx.stroke();worldLabel(0,82*k,'VØID-001','rgba(201,210,222,.75)');}}
      ctx.strokeStyle=frameCol;ctx.lineWidth=12*k;ctx.beginPath();ctx.moveTo(0,104*k);ctx.lineTo(182*k,-74*k);ctx.lineTo(0,-36*k-open*30*k);ctx.lineTo(-182*k,-74*k);ctx.closePath();ctx.stroke();
      ctx.strokeStyle='#14120a';ctx.lineWidth=3*k;ctx.stroke();ctx.lineJoin='round';
      if(!icon){ctx.save();for(const s of [-1,1]){ctx.translate(0,0);const x0=s*182*k,y0=-74*k,ang=Math.atan2(104*k-y0,0-x0);for(let i=0;i<4;i++){const q=i*12*k+8*k,x=x0+Math.cos(ang)*q,y=y0+Math.sin(ang)*q;ctx.fillStyle=i%2?'#14120a':C85.lek;ctx.beginPath();ctx.arc(x,y,4.5*k,0,TAU);ctx.fill();}}ctx.restore();
        ctx.fillStyle=C85.lek;ctx.fillRect(-64*k,-66*k,128*k,14*k);ctx.fillStyle='#14120a';ctx.font='700 '+Math.max(7,10*k)+'px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText('ЛЕКАЛО · ИЗД. 000',0,-55.5*k);}
      // матрица
      ctx.save();ctx.translate(0,-8*k);const cr=20*k,op=b&&lekCoreOpen(b),oK=b?(op?1:open):0,dead=b&&(b.st==='scene'||b.st==='final'||b.st==='dying');
      ctx.fillStyle='#050604';ctx.beginPath();ctx.arc(0,0,cr+4*k,0,TAU);ctx.fill();
      if(op){glow(0,0,cr*2.4,'#ffffff',.9);ctx.fillStyle=b.core&&b.core.flash>0?'#ffe9a8':'#ffffff';ctx.beginPath();ctx.arc(0,0,cr*(.7+.08*Math.sin(t*14)),0,TAU);ctx.fill();}
      else if(!dead){ctx.fillStyle=C85.lek;ctx.globalAlpha=alpha*(.55+.25*Math.sin(t*3));ctx.beginPath();ctx.arc(0,0,cr*.28,0,TAU);ctx.fill();ctx.globalAlpha=alpha;}
      ctx.fillStyle='#1c1a10';ctx.strokeStyle=op?'#ffffff':C85.lek;ctx.lineWidth=2;const sh=cr*(op?1:oK);for(const s of [-1,1]){ctx.beginPath();ctx.ellipse(s*(cr*.5+sh*.6),0,cr*.5,cr,0,0,TAU);ctx.fill();ctx.stroke();}
      if(b&&b.inv0>0&&b.st==='fight'){ctx.strokeStyle='#ffffff';ctx.globalAlpha=alpha*.35;ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,cr+16*k,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}ctx.restore();}
      break;}
    case 'lpart':{const k=e.host85&&e.host85.g?e.host85.g.k:1;if(e.role==='core')break;
      if(e.role==='press'){ctx.fillStyle='#1c1a10';ctx.strokeStyle=e.flash>0?'#ffffff':col;ctx.lineWidth=2.5;ctx.fillRect(-36*k,-18*k,72*k,32*k);ctx.strokeRect(-36*k,-18*k,72*k,32*k);ctx.fillStyle='#8a8060';for(const s of [-1,1])ctx.fillRect(s*24*k-4*k,14*k,8*k,10*k);ctx.fillStyle=col;ctx.fillRect(-20*k,-6*k,40*k,4*k);break;}
      ctx.beginPath();ctx.arc(0,0,r*.8,0,TAU);ctx.fill();ctx.stroke();ctx.fillStyle=col;for(let i=0;i<6;i++){const a=i/6*TAU+t*.2;ctx.beginPath();ctx.arc(Math.cos(a)*r*.55,Math.sin(a)*r*.55,2,0,TAU);ctx.fill();}break;}
    case 'blank85':{ctx.rotate(icon?-Math.PI/2:0);ctx.fillStyle='rgba(20,24,32,.7)';ctx.strokeStyle=e.flash>0?'#ffffff':col;ctx.lineWidth=2;ctx.setLineDash([4,3]);shipPath85(r/13);ctx.fill();ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='rgba(159,176,196,.4)';ctx.fillRect(-6,-2,10,4);break;}
    case 'serial85':{const a=icon?-Math.PI/2:Math.atan2(P.y-e.y,P.x-e.x);ctx.rotate(a);ctx.fillStyle='#2a2408';ctx.strokeStyle=e.flash>0?'#ffffff':col;ctx.lineWidth=2;shipPath85(r/12);ctx.fill();ctx.stroke();
      ctx.fillStyle='#14120a';for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(-6*r/12,s*5*r/12);ctx.lineTo(-9*r/12,s*9*r/12);ctx.lineTo(-5*r/12,s*9*r/12);ctx.lineTo(-3*r/12,s*5*r/12);ctx.closePath();ctx.fill();}
      if(!icon&&e.sf&&e.sf.st==='tele'){ctx.fillStyle='#fff3b0';ctx.beginPath();ctx.arc(19*r/12,0,4+2*Math.sin(t*40),0,TAU);ctx.fill();}break;}
    case 'wellcore':{const b=!icon&&G.sb===e?e:null,R_=icon?r*.9:r,dead=b&&(b.st==='scene'||b.st==='final'||b.st==='dying');if(dead)break;
      const gr=ctx.createRadialGradient(0,0,R_*.1,0,0,R_);gr.addColorStop(0,e.flash>0?'#ffffff':'#eef3ff');gr.addColorStop(.45,'#8fa8ff');gr.addColorStop(1,'#141c40');ctx.fillStyle=gr;ctx.beginPath();ctx.arc(0,0,R_,0,TAU);ctx.fill();
      ctx.strokeStyle=b&&b.inv0>0&&b.st==='fight'?'#ffffff':col;ctx.lineWidth=2;ctx.stroke();
      const beat=MUS&&MUS.cur?.5+.5*Math.sin((MUS.cur.step||0)*Math.PI/2):.5;ctx.strokeStyle='#dfe8ff';ctx.globalAlpha=alpha*.8;ctx.lineWidth=1.5;ctx.beginPath();for(let i=0;i<=72;i++){const a=i/72*TAU,amp=(icon?3:5+4*beat)*Math.sin(a*9+t*6)*Math.sin(a*3-t*2);ctx.lineTo(Math.cos(a)*(R_+7+amp),Math.sin(a)*(R_+7+amp));}ctx.closePath();ctx.stroke();ctx.globalAlpha=alpha;
      if(icon){ctx.strokeStyle=col;ctx.lineWidth=4;for(const [rr,a0] of [[R_*1.6,0],[R_*1.3,1]]){for(let i=0;i<4;i++){const a=a0+i*Math.PI/2;ctx.beginPath();ctx.arc(0,0,rr,a-.3,a+.3);ctx.stroke();}}break;}
      if(b&&b.phase>=4){ctx.fillStyle='#04060c';ctx.globalAlpha=alpha*.75;ctx.font='700 18px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText('013',0,6);ctx.globalAlpha=alpha;}
      if(b&&b.stun>0){ctx.strokeStyle='#ffffff';ctx.globalAlpha=.6;ctx.lineWidth=2;for(let i=0;i<3;i++){ctx.beginPath();ctx.arc(0,0,R_+12+i*9+Math.sin(t*10+i)*3,0,TAU);ctx.stroke();}ctx.globalAlpha=alpha;}break;}
    case 'wemit':{const rr=e.ringR||96,b=e.host85,arc=b&&b.rings?(e.ring==='O'?b.rings[0].arc:b.rings[1].arc):.5;if(icon){ctx.strokeStyle=col;ctx.lineWidth=7;ctx.beginPath();ctx.arc(-40,0,40,-.5,.5);ctx.stroke();break;}
      ctx.rotate(e.ang85||0);const c2=e.flash>0||e.shieldFlash>0?'#ffffff':e.tel85>0?'#cfe0ff':e.corona?'#4a5a8c':col;ctx.strokeStyle=c2;ctx.lineWidth=e.corona?4:9;ctx.beginPath();ctx.arc(-rr,0,rr,-arc/2,arc/2);ctx.stroke();ctx.strokeStyle='#0a0f1c';ctx.lineWidth=e.corona?1:3;ctx.stroke();
      if(!e.corona){ctx.strokeStyle=c2;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(13,0);ctx.stroke();ctx.fillStyle=c2;ctx.beginPath();ctx.arc(15,0,3,0,TAU);ctx.fill();if(e.back85){ctx.globalAlpha=alpha*.5;ctx.setLineDash([2,3]);ctx.beginPath();ctx.arc(-rr,0,rr,-arc/2,arc/2);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=alpha;}}break;}
    case 'anchor85':{ctx.fillStyle='#0a1028';ctx.strokeStyle=e.flash>0?'#ffffff':col;ctx.lineWidth=2.5;ctx.beginPath();ctx.moveTo(0,-r*1.4);ctx.lineTo(r*.7,0);ctx.lineTo(0,r*1.4);ctx.lineTo(-r*.7,0);ctx.closePath();ctx.fill();ctx.stroke();ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,-r*.9);ctx.lineTo(0,r*.9);ctx.stroke();if(!icon)glow(0,0,r*1.6,col,.35+.25*Math.sin(t*5));break;}
    case 'ghost85':{if(!icon&&e.trail){for(let i=0;i<(G.q===0||G.lowFx?1:3);i++){const q=e.trail[Math.max(0,e.trail.length-1-(i+1)*5)];if(!q)continue;ctx.save();ctx.translate(q.x-e.x,q.y-e.y);ctx.rotate(e.face||0);ctx.globalAlpha=alpha*(.22-.06*i);ctx.strokeStyle='#f2f6ff';ctx.lineWidth=1.5;shipPath85(1);ctx.stroke();ctx.restore();}}
      ctx.rotate(icon?-Math.PI/2:(e.face||0));ctx.globalAlpha=alpha*(.6+.2*Math.sin(t*8));gray85(true,1.7);drawShip(icon?'base':curSkin(),t,0,{});gray85(false);ctx.strokeStyle='#ffffff';ctx.lineWidth=1.5;shipPath85(1.05);ctx.stroke();ctx.globalAlpha=alpha;break;}
    case 'note85':{ctx.fillStyle='#16204a';ctx.strokeStyle=e.flash>0?'#ffffff':col;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(r*.4,0);ctx.lineTo(r*.4,-r*2);ctx.quadraticCurveTo(r*1.4,-r*1.6,r*1.2,-r*.8);ctx.stroke();if(!icon)glow(0,0,r*2,col,.4);break;}}
  return true;}
// --- скины 0.8.5 ---
function w85DrawSkin(id,t,sp,o,A,fl,edge){
  if(id==='shard85'){glow(-12,0,fl,'#ffd36b',.6);ctx.fillStyle='#14120a';ctx.strokeStyle=edge;ctx.lineWidth=2.5;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.fill();ctx.stroke();ctx.strokeStyle='#ffffff';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(8,-2);ctx.lineTo(0,3);ctx.lineTo(-6,-4);ctx.moveTo(2,5);ctx.lineTo(-4,8);ctx.stroke();return true;}
  if(id==='serial013'){glow(-12,0,fl,'#ffd36b',.7);ctx.fillStyle='#2a2408';ctx.strokeStyle=edge;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#14120a';for(const s of [-1,1]){ctx.fillRect(-9,s*8-1.5,5,3);}ctx.fillStyle=edge;ctx.font='700 5px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText('013',3,2);return true;}
  if(id==='silence85'){ctx.fillStyle='#020306';ctx.strokeStyle='#3a4258';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.fill();ctx.stroke();return true;}
  if(id==='callsign013'){const k=.5+.5*Math.sin(t*6);glow(-12,0,fl,'#6b8cff',.6);ctx.fillStyle='#0a1028';ctx.strokeStyle=edge;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='rgba(159,184,255,'+(.4+.6*k).toFixed(2)+')';for(const [x,y] of [[-9,-9],[-9,9],[6,0]]){ctx.beginPath();ctx.arc(x,y,1.8,0,TAU);ctx.fill();}return true;}
  if(id==='carrier85'){glow(-12,0,fl,'#ffffff',.6);ctx.fillStyle='#e8eef8';ctx.strokeStyle=edge;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.fill();ctx.stroke();ctx.strokeStyle='#6b8cff';ctx.lineWidth=1.2;ctx.beginPath();for(let i=0;i<=20;i++){const x=-10+i*1.4;ctx.lineTo(x,Math.sin(i*.9+t*8)*2.2);}ctx.stroke();return true;}
  return false;}
// --- гибель босса: эффекты выбора ---
function dying85(b,dt){const fx=b.fx85;if(!fx)return;const t0=fx.t-dt;if(SBX[b.sbk]){if(SBX[b.sbk].dying)SBX[b.sbk].dying(b,dt,t0);return;}
  if(b.sbk==='lek'){if(fx.kind==='break'){if(t0<=0){for(let i=0;i<(SET.fx?160:40);i++){const a=rnd(0,TAU),v=rnd(80,520);part(b.fx+rnd(-170,170)*b.g.k,b.fy+rnd(-70,90)*b.g.k,Math.cos(a)*v,Math.sin(a)*v-120,rnd(.6,1.6),Math.random()<.6?C85.lek:'#14120a',rnd(2,5));}sfx('bigboom');shake(16);}G.bo80=Math.max(0,G.bo80-dt*1.2);}
    else{G.bo80=Math.max(.3,G.bo80-dt*.4);if(SET.fx&&Math.random()<.6)part(b.fx+rnd(-180,180)*b.g.k,b.fy+rnd(-60,80)*b.g.k,0,-40,.6,shipCol(),3);}}
  else{G.bo80=Math.max(0,G.bo80-dt*.35);if(fx.kind==='third'&&t0<=0&&G.shock.length<60)G.shock.push({x:b.cx,y:b.cy,r:20,R:Math.max(W,H)*1.2,t:0,col:'#ffffff',slow:true});
    if(fx.kind==='answer'&&SET.fx&&vR3()<.4)part(b.cx+vrnd3(-20,20),b.cy+vrnd3(-20,20),vrnd3(-60,60),vrnd3(-60,60),.8,shipCol(),2.5);}}
// --- звуки телеграфов (громче музыки) ---
function snd85(kind){if(!AU.ctx||!SET.sfx||!AU.sfx)return;const c=AU.ctx,t=c.currentTime;
  const tone=(f0,f1,dur,type,vol,delay)=>{delay=delay||0;const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(f0,t+delay);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+delay+dur);g.gain.setValueAtTime(0.0001,t+delay);g.gain.linearRampToValueAtTime(vol,t+delay+.01);g.gain.exponentialRampToValueAtTime(.0001,t+delay+dur);o.connect(g);g.connect(AU.sfx);o.start(t+delay);o.stop(t+delay+dur+.03);};
  const noise=(dur,vol,f,type,delay,f2)=>{delay=delay||0;const len=Math.max(1,c.sampleRate*dur|0),bf=c.createBuffer(1,len,c.sampleRate),d=bf.getChannelData(0);for(let i=0;i<len;i++)d[i]=(Math.random()*2-1)*(1-i/len);const s=c.createBufferSource();s.buffer=bf;const fl=c.createBiquadFilter();fl.type=type||'lowpass';fl.frequency.setValueAtTime(f,t+delay);if(f2)fl.frequency.exponentialRampToValueAtTime(f2,t+delay+dur);const g=c.createGain();g.gain.value=vol;s.connect(fl);fl.connect(g);g.connect(AU.sfx);s.start(t+delay);};
  switch(kind){
    case 'press0':noise(.7,.25,300,'lowpass',0,120);tone(140,70,.7,'sine',.14);break;
    case 'press':noise(.45,.7,500);tone(70,30,.5,'sine',.45);tone(1200,400,.08,'square',.04);break;
    case 'grab':for(let i=0;i<6;i++)tone(240+i*30,200+i*30,.04,'square',.05,i*.07);break;
    case 'siren':for(let i=0;i<3;i++){tone(660,660,.24,'triangle',.09,i*.5);tone(880,880,.24,'triangle',.09,i*.5+.25);}break;
    case 'salvo0':noise(.9,.35,380,'lowpass',0,900);tone(60,90,.9,'sawtooth',.06);break;
    case 'salvo':noise(.6,.6,700);tone(90,40,.6,'sine',.35);break;
    case 'open':tone(400,900,.25,'triangle',.1);tone(800,1800,.2,'sine',.05,.05);break;
    case 'scan':tone(1800,600,.6,'sine',.05);noise(.6,.08,3000,'bandpass');break;
    case 'weld':noise(.4,.12,4200,'highpass');break;
    case 'pult':tone(520,520,.08,'square',.06);tone(390,390,.12,'square',.06,.1);noise(.5,.2,600,'lowpass',.1,150);break;
    case 'stamp':tone(300,150,.12,'square',.06);break;
    case 'stop':for(let i=0;i<3;i++)noise(.3,.3,400,'lowpass',i*.6,100);tone(200,40,2.4,'sawtooth',.05);break;
    case 'ping':tone(1320,1290,.6,'sine',.11);tone(2640,2600,.3,'sine',.03);break;
    case 'emit':tone(900,1400,.12,'triangle',.05);break;
    case 'rec':tone(2000,2000,.02,'square',.07);tone(1200,1200,.03,'square',.06,.04);break;
    case 'play':tone(600,900,.3,'sine',.06);break;
    case 'rewind':tone(300,1800,.8,'sawtooth',.05);noise(.8,.18,2400,'highpass');break;
    case 'anchor':tone(110,110,.6,'triangle',.12);tone(165,165,.6,'triangle',.08,.15);break;
    case 'break':tone(880,220,.6,'triangle',.1);noise(.4,.3,2000,'bandpass');break;
    case 'inv':tone(300,600,1,'sine',.08);break;
    case 'absorb':tone(500,1000,.5,'sine',.06);break;
    case 'sos':{const S=[0,1,2,4,5.4,6.8,8.6,9.1,9.6];S.forEach((d,i)=>{const long=i>=3&&i<=5;tone(1046,1046,long?.38:.12,'sine',.07,d*.18+.1);});break;}
    case 'final':noise(1.2,.25,800,'lowpass',0,6000);tone(220,880,1.2,'sine',.06);break;}}
// --- музыка боёв: из темы сектора, слои по фазам ---
SC_.b31=Object.assign({},SC_.s6,{name:'Цех №0',chordT:[8,12],pad:['sawtooth',360,1000,.028],sub:.1,noise:['bandpass',1400,.012,.08],bell:['metal',10,16,.018],rev:.3,fight:1,boss:1,bpm:104,pulse:'q',toms:'boss',metal:1,mech:1,heavy:1,brass:.04,vol:.9,press85:1});
SC_.b31d=Object.assign({},SC_.s6d,{name:'Цех №0 · без света',fight:1,bpm:100,pulse:'q',toms:'fight',relay:1,mech:0,brass:0,vol:.85,furnace85:1});
SC_.b31e={name:'Цех №0 · линия стоит',root:41,v:[[0,7,14,17]],chordT:[30,30],pad:['triangle',300,600,.04],sub:.08,noise:['lowpass',300,.01,.03],bell:['metal',12,20,.014],rev:.55,vol:.7,bpm:96,end85:1};
SC_.b38=Object.assign({},SC_.s7,{name:'Колодец',chordT:[12,18],fight:1,bpm:60,pulse:'q',toms:'fight',brass:0,vol:.85,sos85:1});
SC_.b38s={name:'Колодец · тишина',root:36,v:[[0,12,19,24]],chordT:[30,30],pad:['sine',300,520,.012],sub:.05,noise:['lowpass',200,.004,.02],bell:null,rev:.7,vol:.55,bpm:60,heart85:1,sos85:1};
SECSC80.add('b31');SECSC80.add('b31d');SECSC80.add('b38');
function step85(P,t,st,bar){const S=P.sc,X=P.ext||{},root=S.root+(P.semi||0);if(!AU.ctx)return;
  if(S.press85&&st===8&&(X.ph85||1)>=1){evNoise(t,.12,.09,P.L.toms,'lowpass',260);ev(t,52,.4,'sine',.24,P.L.toms,.003,34);}
  if(S.press85&&X.siren85&&bar%8===0&&(st===0||st===8))ev(t,mtof(root+30),.7,'triangle',.022,P.L.fx,.05,mtof(root+33));
  if(S.furnace85&&st%4===0)evNoise(t,.5,.03,P.L.noise,'lowpass',160);
  if(S.end85&&st===0&&bar%4===0)for(const iv of [12,19,24])ev(t,mtof(root+iv),3.5,'triangle',.03,P.L.bell,.4);
  if(S.sos85&&!X.mute85){const ph=X.ph85||0,every=ph>=3?1:2;if(bar%every===0){const pat=[[0,.1],[1,.1],[2,.1],[4,.32],[6,.32],[8,.32],[11,.1],[12,.1],[13,.1]];for(const [s,d] of pat)if(st===s){ev(t,mtof(root+31+(X.fin85==='answer'?4:0)),d,'sine',.03,P.L.bell,.005);if(ph===2)ev(t+60/((S.bpm||60))*2,mtof(root+31),d,'sine',.012,P.L.bell,.005);}
      if(X.fin85==='third'&&st===15)ev(t,mtof(root+38),.6,'sine',.03,P.L.bell,.01);}}
  if(S.heart85&&(st===0||st===3))ev(t,56,.32,'sine',.22,P.L.toms,.004,38);}
function mus85(T){const X=G.x85,b=G.sb&&is85(G.sb)?G.sb:null;
  if(G.world&&G.state==='world'){if(T.id==='s6'&&storyFlag('line31')==='break')T.ext.mechOff=1;if(T.id==='s7'&&storyFlag('well38')==='silence')T.ext.choirOff=1;}
  if(!b||!inMission()||T.calm){if(X&&X.silence>0)T.duck=0;return T;}
  if(SBX[b.sbk]){if(SBX[b.sbk].music)SBX[b.sbk].music(b,T);}else if(b.sbk==='lek'){if(b.st==='fight'){T.id=b.phase>=3?'b31d':'b31';T.I=1;T.ext.ph85=b.phase;if(b.phase===2)T.ext.siren85=1;if(b.phase===3&&b.hp<=b.maxHp*.15)T.ext.bpmAdd=8;}
    else if(b.st==='scene'||b.st==='final'||b.st==='dying'){T.id='b31e';T.I=.2;T.ext.bpmAdd=b.st==='scene'?-Math.min(76,(b.scT||0)*19):-76;}}
  else{if(b.st==='enter'){T.id='b38s';T.I=0;T.ext.ph85=0;T.ext.mute85=1;}
    else if(b.st==='fight'){T.id=b.phase>=4?'b38s':'b38';T.I=b.phase>=4?0:.8+.05*b.phase;T.ext.ph85=b.phase;}
    else{T.id='b38s';T.I=0;T.ext.ph85=4;T.ext.fin85=b.choice||null;if(b.choice==='silence')T.ext.mute85=1;}}
  if(X&&X.rew>0){T.lp=700;T.ext.bpmAdd=(T.ext.bpmAdd||0)-30;}if(X&&X.silence>0)T.duck=0;
  return T;}
function fade85(a,b){const A=/^b(3[18]|42|46)/.test(a||''),B=/^b(3[18]|42|46)/.test(b||'');if(!A&&!B)return 0;if(A&&B)return 3;return B?2.5:6;}

// ===== 0.8.5: мир после выборов, награды, справочник, хроника =====
function own85(k){const S=G.save;if(S&&S.ownSkins&&!S.ownSkins.includes(k))S.ownSkins.push(k);}
Object.assign(SKINS,{
  shard85:{name:'Осколок лекала',col:'#e8d27a',bul:'#fff0b0',trail:'#ffd36b',d:'Жёлтая балка рамы, вся в трещинах.',unlock:0,find:'СЕКТОР VII · РАЗБИТЬ ЛЕКАЛО'},
  serial013:{name:'Серия 013',col:'#8fe9ff',bul:'#c9f4ff',trail:'#e8d27a',d:'Корпус по вашему лекалу: ваш цвет и номер 013 на борту.',unlock:0,find:'СЕКТОР VII · ПЕРЕПИСАТЬ ЛЕКАЛО'},
  silence85:{name:'Тишина',col:'#3a4258',bul:'#9fb0c4',trail:'#1a2030',d:'Чёрный корпус без огней.',unlock:0,find:'СЕКТОР VIII · ЗАГЛУШИТЬ'},
  callsign013:{name:'Позывной 013',col:'#6b8cff',bul:'#cfe0ff',trail:'#6b8cff',d:'Синие огни мигают в ритм сигнала.',unlock:0,find:'СЕКТОР VIII · ОТВЕТИТЬ'},
  carrier85:{name:'Несущая',col:'#ffffff',bul:'#ffffff',trail:'#9fb8ff',d:'Белый корпус, по контуру бежит волна.',unlock:0,find:'СЕКТОР VIII · ???'}});
Object.assign(STORY_HULL,{shard85:'Обшивка из балки разбитого лекала. «ИЗД. 000» — теперь просто металл.',serial013:'Корпус по новому лекалу. Номер 013 — ваш, а не партии.',silence85:'Корпус без огней. После колодца ему нечего передавать.',
  callsign013:'Огни мигают позывным: три коротких, три длинных, три коротких — вашими словами.',carrier85:'Несущая частота за краем карты. Корпус светится, как сигнал, который ещё никто не слышал.'});
for(const k of ['shard85','serial013','silence85','callsign013','carrier85'])SKINS[k].d=STORY_HULL[k];
Object.assign(HULL_NUM,{shard85:'000',serial013:'013',silence85:'—',callsign013:'013',carrier85:'∞'});
{const ALT={shard85:['line31','break'],serial013:['line31','write'],silence85:['well38','silence'],callsign013:['well38','answer'],carrier85:['well38','third']};
  for(const k in ALT){const [f,v]=ALT[k],base=SKINS[k].find;Object.defineProperty(SKINS[k],'find',{get(){const c=storyFlag(f);return c&&c!==v?'ДРУГОЙ ВЫБОР':base;},configurable:true,enumerable:true});}}
// мастерство (индекс — номер миссии минус один)
MASTERY[30]={t:'Ни одного Серийника в серии: разбить все заготовки до конца сборки',ok:()=>!!G.mc&&!!G.mc.lek85&&!G.mc.serial85};
MASTERY[37]={t:'Ни одного голоса колодцу: ни один Паломник не долетел и не пострадал',ok:()=>!!G.mc&&!!G.mc.well85&&!G.mc.absorb38&&!G.mc.pilHit38};
// справочник: лор боссов открывается после победы
function beat85(m){const S=G.save;return !!(S&&S.medals&&S.medals[m]&&S.medals[m].clear)||!!storyFlag(m===31?'line31':'well38');}
Object.defineProperty(EDEF.lekalo,'lore',{get(){return beat85(31)?'«ЛЕКАЛО · ИЗД. 000». С него сняли первую копию — и все следующие. Внутри рамы висел VØID-001: он так и не проснулся.':'ИСТОЧНИК НЕ ОПОЗНАН';},configurable:true,enumerable:true});
Object.defineProperty(EDEF.wellcore,'lore',{get(){return beat85(38)?'Передатчик на дне колодца не выключался с первого цикла. Долетев до дна, каждый становится его голосом.':'ИСТОЧНИК НЕ ОПОЗНАН';},configurable:true,enumerable:true});
// обломки боссов в мире
Object.assign(SB_WRECK,{31:{break:['ОСКОЛОК ЛЕКАЛА','Жёлтая балка с трафаретом «ИЗД. 000». Линия стоит. На обороте кто-то нацарапал: «013 — не брак».'],write:['ОСКОЛОК ЛЕКАЛА','Балка ещё тёплая. В пазу матрицы — ваш скан: оружие, модули, износ 12%. Следующая копия начнёт с этого.']},
  38:{silence:['ПЕРЕДАТЧИК КОЛОДЦА','Передатчик молчит. На панели — счётчик вызовов: он больше не растёт.'],answer:['ПЕРЕДАТЧИК КОЛОДЦА','Передатчик повторяет ваши слова. Где-то далеко кто-то впервые слышит не просьбу, а ответ.'],third:['ПЕРЕДАТЧИК КОЛОДЦА','Частота сдвинута за край карты. На ленте записи — координаты, которых нет ни в одном каталоге.']}});
const SB_WM85=[14,18,22,27,31,38];
// хроника: исходы и открытия
function chron85(s){if(!s)return '';let h='';
  if(s.line31){h+=`<dt>Паспорт изделия 013</dt><dd>Оружие, модули, износ 12%. Партия: вне. Основание приёмки: возврат. Так бюро записывало каждую копию.</dd><dt>VØID-001</dt><dd>Первая копия висела внутри лекала и так и не проснулась. Э. В. счёл это милосердием.</dd>`;
    h+=`<dt>Лекало</dt><dd>${s.line31==='break'?'Лекало разбито. В Цехе №0 горит свет, и больше нечего проверять. Копий больше не делают.':'Лекало переписано. Следующая копия будет помнить, как тебя звали. Линия работает по новому лекалу.'}</dd>`;}
  if(s.well38){h+=`<dt>Первый сигнал</dt><dd>Сигнал, за которым летят все копии, — голос VØID из прошлого цикла. Долетев до дна, каждый зовёт следующего.</dd><dt>Корабль на дне</dt><dd>Потёртый корпус с номером 013 и передатчиком, который не выключался с первого цикла. ${s.well38==='silence'?'Теперь передатчик молчит.':s.well38==='answer'?'Теперь он говорит вашими словами.':'Теперь он смотрит за край карты.'}</dd>`;
    if(s.well38==='third')h+=`<dt>Третий путь</dt><dd>Сигнал перестроен на координаты за краем карты. Запись Э. В.: «Третий путь не здесь. Он там, куда сигнал никогда не звал».</dd>`;}
  const n=serialNo85();if(n>13)h+=`<dt>Серия</dt><dd>Линия Цеха №0 собрала копий с вашим оружием: ${n-13}. Последний номер на борту — ${String(n).padStart(3,'0')}. Линия помнит, даже если вы начнёте заново.</dd>`;
  return h;}
// контракты после побед
CTPL.push({id:'c_clean85',s:'VII · Партия без брака',t:()=>'Пройти миссию сектора VII, не вызвав нарушения регламента',ev:'clean85',n:[1,1],after:31,sec:6},
  {id:'c_wake85',s:'VIII · Разбудить',t:n=>`Разбудить импульсом ${n} Паломников в секторе VIII`,ev:'wake85',n:[3,5],after:38,sec:7,alive:()=>storyFlag('well38')!=='silence'},
  {id:'c_exodus85',s:'VIII · Исход',t:()=>'Сопроводить Исход Паломников до сектора VII',ev:'exodus85',n:[1,1],after:38,sec:7,alive:()=>storyFlag('well38')==='silence'});
// --- открытый мир VII–VIII ---
const W85={sec:-1,exo:false,voice:false};
function w85S(){const S=G.save;if(!S)return {apprAt:0};return S.w85||(S.w85={apprAt:0});}
function w85Node(){const s=WORLD.sectors[7];if(!s||!s.box)return null;const b=s.box;return {x:b[2]-280,y:(b[1]+b[3])/2};}
function w85WorldTick(dt){const S=G.save,p=G.player;if(!S||!p)return;const sec=sec80();
  if(sec===6&&W85.sec!==6&&storyFlag('line31')==='write'&&!G.ally85w&&p.hp>0){G.ally85w={kind:'appr',x:p.x-60,y:p.y+40,a:0,cd:1,t:90};radioLine('БЮРО',C85.lek,'Линия работает по новому лекалу.',.6);floater(p.x,p.y-50,'УЧЕНИК · СОЮЗНИК НА 90 С',shipCol());}
  W85.sec=sec;if(G.ally85w){if(sec!==6||p.hp<=0)G.ally85w=null;else ally85Tick(dt,G.ally85w);}
  if(storyFlag('line31')==='break')for(const z of W80.zones)if(z.k80==='audit'&&!z.active)z.cool=Math.max(z.cool||0,30);
  const w38=storyFlag('well38');
  if(w38!=='silence'&&W85.exo){W85.exo=false;if(W80.dest0)W80.dest=W80.dest0;else{const n38=WORLD.nodes.find(n=>n.m===38);if(n38)W80.dest={x:n38.x,y:n38.y};}for(const z of W80.zones)if(z.k80==='pilgrims')z.name='ПАЛОМНИКИ';}
  if(w38==='silence'&&!W85.exo){W85.exo=true;const n=WORLD.nodes[27];if(n){W80.dest0=W80.dest;W80.dest={x:n.x,y:n.y};}for(const z of W80.zones)if(z.k80==='pilgrims')z.name='ИСХОД';}
  if((w38==='answer'||w38==='third')&&!W85.voice){W85.voice=true;VOICES80.push('«…кто-то ответил с самого дна. Не «помогите». Сказал: «я слышу. Лети дальше». Это был ты?…»');}
  if(w38==='answer'||w38==='third'){for(const z of W80.zones){if(z.k80!=='pilgrims'||!z.active||!z.pg)continue;z.pg.tol=99;
      for(const e of z.pg.ships){if(!e.alive||e.hostile80||Math.hypot(e.x-p.x,e.y-p.y)>340)continue;for(const b of G.eb){if(b.life>0&&!b.rift&&Math.hypot(b.x-e.x,b.y-e.y)<e.r+6&&Math.random()<.35){b.life=0;e.flash=.1;if(!e.cov85){e.cov85=1;floater(e.x,e.y-22,'ПРИКРЫЛ',C85.pil);}}}}}}}
function w85Pulse(p,R){if(sec80()!==7||!storyFlag('well38'))return;const rw=Math.max(220,R);for(const z of W80.zones){if(z.k80!=='pilgrims'||!z.active||!z.pg)continue;for(const e of z.pg.ships){if(!e.alive||e.hostile80||e.woke85||Math.hypot(e.x-p.x,e.y-p.y)>rw+e.r)continue;e.woke85=1;floater(e.x,e.y-24,'ПРОСНУЛСЯ',C85.pil);conEvent('wake85');}}}
function w85Draw(t){const A=G.ally85w;if(A){ctx.save();ctx.translate(A.x,A.y);ctx.rotate(A.ang||0);ctx.fillStyle='#2a2408';ctx.strokeStyle=shipCol();ctx.lineWidth=2;shipPath85(.8);ctx.fill();ctx.stroke();ctx.restore();worldLabel(A.x,A.y-20,'УЧЕНИК · '+Math.ceil(A.t),shipCol());}
  if(storyFlag('well38')==='third'){const q=w85Node();if(q&&inView(q.x,q.y,260)){glow(q.x,q.y,120,'#ffffff',.25+.1*Math.sin(t*2));ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.setLineDash([10,8]);ctx.lineDashOffset=-t*10;ctx.beginPath();ctx.arc(q.x,q.y,90,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;
      for(let i=0;i<3;i++){ctx.globalAlpha=.5-i*.15;ctx.beginPath();ctx.arc(q.x,q.y,30+i*18+6*Math.sin(t*3+i),0,TAU);ctx.stroke();}ctx.globalAlpha=1;worldLabel(q.x,q.y-110,'СИГНАЛ ЗА ПРЕДЕЛОМ','#ffffff');worldLabel(q.x,q.y+112,'СКОРО','#9fb0c4');}}}
// союзник: Серийник 013 (бой 38) и «Ученик» (мир VII)
function ally85Tick(dt,A0){const X=G.x85,A=A0||(X&&X.ally);if(!A)return;const p=G.player;if(!p)return;
  A.t-=dt;if(A.t<=0||p.hp<=0){if(A.kind==='appr'&&A.t<=0)radioLine('УЧЕНИК',C85.lek,'Смена окончена. Я запомнил, как ты летаешь.',.2);if(A0)G.ally85w=null;else if(X)X.ally=null;return;}
  A.a+=dt*1.1;const tx=p.x+Math.cos(A.a)*80,ty=p.y+Math.sin(A.a)*80;A.x+=(tx-A.x)*Math.min(1,dt*3);A.y+=(ty-A.y)*Math.min(1,dt*3);
  A.cd-=dt;if(A.cd<=0){const t_=nearestEnemy(A.x,A.y,480);if(t_&&t_.type!=='rangedummy'){const sc=lekScan(),n=Math.min(3,sc.n),a0=Math.atan2(aimPt(t_).y-A.y,aimPt(t_).x-A.x);A.ang=a0;
      for(let i=0;i<n;i++){const a=a0+(i-(n-1)/2)*.11;G.pb.push({x:A.x,y:A.y,px:A.x,py:A.y,vx:Math.cos(a)*820,vy:Math.sin(a)*820,dmg:sc.dmg*.45,pierce:0,rico:0,life:.7,hit:[],drone:true,jr:true,a85:1});}A.cd=Math.max(.35,sc.rate*2.2);}else A.cd=.25;}
  if(A.kind==='serial'&&A.maxHp){for(const b of G.eb){if(b.life>0&&!b.rift&&Math.hypot(b.x-A.x,b.y-A.y)<12){A.hp-=b.dmg;b.life=0;}}
    if(A.hp<=0){explode(A.x,A.y,C85.lek,20,.8);floater(A.x,A.y-24,'СЕРИЙНИК 013 ПОТЕРЯН',C85.lek);if(X)X.ally=null;}}}


