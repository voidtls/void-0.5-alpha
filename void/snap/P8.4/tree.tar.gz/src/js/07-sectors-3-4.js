// ===== 0.5.5: сектора III–IV — механики (лёд, износ, новые враги) =====
function secScale(){if(!inMission()||G.mode==='endless')return null;const M=MISSIONS[G.m-1];return M&&M.gen&&SEC_SCALE[M.sec]||null;}
function secRew(m){const M=MISSIONS[m-1];if(M&&M.gen&&SEC_SCALE[M.sec])return SEC_SCALE[M.sec].rew*(storyFlag('shore46')==='carry'?1.1:1);return m>18?2:1;}
function secReset(){Object.assign(G,{eng74:0,engT74:0,latch74:null,flag74T:0,box74c:false,ice:0,iceT:0,frozen:0,iceImm:0,wear:0,wearT:0,slick:false,posLog:[],waveHold:0,rustN:0,shieldPen:0,sb:null,lockShield:0,lockDash:0,lockGun:0,tiredT:0,waveForce:false,iceRing:null});}
// --- лёд ---
function addIce(n){const p=G.player;if(!p||p.hp<=0||G.iceImm>0||G.frozen>0)return;G.ice=Math.min(3,(G.ice||0)+n);G.iceT=2.5;sfx('block');
  if(G.ice>=3){G.frozen=.8;G.ice=0;G.iceImm=2;p.vx=p.vy=0;p.chg=0;floater(p.x,p.y-30,'КОРПУС ЗАМЁРЗ','#bfe8ff');shake(6);if(SET.fx)for(let i=0;i<14;i++)part(p.x,p.y,vrnd3(-120,120),vrnd3(-120,120),.5,'#dff6ff',2.5);}
  else hintOnce('ice','ОБЛЕДЕНЕНИЕ '+G.ice+'/3','#bfe8ff');}
function clearIce(){if(G.ice>0||G.frozen>0){G.ice=0;G.frozen=0;}}
function iceSpeedK(){return G.frozen>0?0:(1-.12*(G.ice||0))*(G.mode==='endless'?1:(1-.1*(G.eng74||0))*(G.latch74&&G.latch74.alive?.7:1)*(G.box74c?.85:1)*(G.slow80>0?.5:1));}
// --- износ (сектор IV) ---
function addWear(v){const st=G.st;if(!st||!st.maxHp0)return;const cap=Math.max(0,Math.min(st.maxHp0*.3,st.maxHp0-50));const w0=G.wear||0;G.wear=clamp(w0+v,0,cap);
  if(Math.floor(G.wear)!==Math.floor(w0)){computeStats();const p=G.player;if(p&&p.hp>st.maxHp)p.hp=st.maxHp;}}
function wearPct(){const st=G.st;return st&&st.maxHp0?Math.round((G.wear||0)/st.maxHp0*100):0;}
// --- каркасы и ржавые ---
function dropHull(e){const SS=SSW();if(!SS||!SS.rust||e.rebuilt||e.escort||EDEF[e.type].passive||['mite','mine','seeker','hull','icecopy','guard','hive','vortex','frost','archivist','repairer','corroder','cpart','shell','rustcopy','inventor','invcell','invcore','obheart','obseg'].includes(e.type))return;
  if(G.enemies.filter(o=>o.alive&&o.type==='hull').length>=4)return;
  spawnEnemy('hull',e.x,e.y,{hullOf:e.type,life:12,noAffix:true});}
function rebuild(h){if(!h.alive)return;h.alive=false;const e=spawnEnemy(h.hullOf,h.x,h.y,{noAffix:true,rebuilt:true,noLoot:true,spawnT:.6});e.hp=e.maxHp=Math.round(e.maxHp*.5);
  explode(h.x,h.y,'#a0522d',10,.7);floater(h.x,h.y-18,'СОБРАН ЗАНОВО','#ffb060');sfx('warn');}
// --- луч архиватора ---
function recBeamHit(e){const p=G.player;if(e.st!=='rec'||p.dashT<=0)return false;return segDist(p.px,p.py,p.x,p.y,e.x,e.y)<p.r+4||segDistP(p.x,p.y,e.x,e.y,e.bx,e.by)<p.r+6;}
function spawnCopy(e){const p=G.player,crystal=()=>{const a=Math.atan2(p.y-e.y,p.x-e.x);const q=shootE(e.x,e.y,a,300,10,'#dff6ff',6);if(q)q.frost=true;};
  if(storyFlag('inv14')==='cold'){crystal();floater(e.x,e.y-34,'КАТАЛОГ СОЖЖЁН · ЗАПИСЫВАТЬ НЕКУДА','#8fd8ff');return;}
  const log=G.posLog.filter(q=>G.t-q.t<=3);if(log.length<4){crystal();return;}let len=0,turn=0,pa=null;
  for(let i=1;i<log.length;i++){const dx=log[i].x-log[i-1].x,dy=log[i].y-log[i-1].y,l=Math.hypot(dx,dy);len+=l;if(l>4){const a=Math.atan2(dy,dx);if(pa!==null)turn+=Math.abs(angDiff(a,pa));pa=a;}}
  if(len<120||G.enemies.filter(o=>o.alive&&o.type==='icecopy').length>=3){crystal();return;}
  const path=log.map(q=>({x:q.x,y:q.y,t:q.t-log[0].t}));
  const c=spawnEnemy('icecopy',path[0].x,path[0].y,{path,pt:0,noAffix:true,noLoot:true,spawnT:.25,fire:true,frate:Math.max(.5,G.st.rate*2)*atkK()*(turn>9.4?2:1),fdmg:clamp(G.st.dmg*.5,6,22),skin:curSkin()});c.contact=14;
  if(turn>9.4)floater(c.x,c.y-22,'ЛОМАНЫЙ МАРШРУТ · КОПИЯ ЦЕЛИТСЯ ВДВОЕ РЕЖЕ','#8fd8ff');}
// --- обновление новых врагов (вызывается из updateEnemies перед switch; true = обработан) ---
function secEnemyUpdate(e,dt,ctx_){if(e.zb){zbAI(e,dt,ctx_);return true;}const p=G.player,{ux,uy,d,sm,T,pd}=ctx_;if(s74Update(e,dt,ctx_))return true;
  if(e.type==='rustcopy'&&G.world&&(e.pack||e.conv||e.peace!==undefined)){w58CopyAI(e,dt,ctx_);return true;}
  switch(e.type){
    case 'frost':{const m=clamp((d-240)/120,-1,1);steer(e,ux*m-uy*.6*e.dir,uy*m+ux*.6*e.dir,e.spd*sm,dt,3);if(Math.random()<dt*.25)e.dir*=-1;
      e.cd-=dt;if(e.cd<=0&&onScreen(e)){const b=shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x)+rnd(-.08,.08),170,6,'#bfe8ff',6,!!T.isBc);if(b)b.frost=true;e.cd=rnd(1.6,2.1);}return true;}
    case 'archivist':{if(e.wander){w58WanderAI(e,dt,ctx_);return true;}
      if(e.st==='rec'){e.timer-=dt;e.bx=p.x;e.by=p.y;e.vx*=.9;e.vy*=.9;
        if(e.hp<=e.recHp-e.maxHp*.3||recBeamHit(e)){e.st='seek';e.cd=3;floater(e.x,e.y-20,'ЗАПИСЬ ПРЕРВАНА','#8fd8ff');sfx('block');}
        else if(e.timer<=0){e.st='seek';e.cd=rnd(4,5.5);spawnCopy(e);floater(e.x,e.y-20,'ЗАПИСЬ ПРИНЯТА · ДУБЛИКАТ','#8fd8ff');}return true;}
      const m=clamp((d-300)/120,-1,1);steer(e,ux*m-uy*.5*e.dir,uy*m+ux*.5*e.dir,e.spd*sm,dt,3);if(Math.random()<dt*.2)e.dir*=-1;
      e.cd-=dt;if(e.cd<=0&&d<520&&onScreen(e)&&p.hp>0){e.st='rec';e.timer=G.ice>0?2:3;e.recHp=e.hp;e.bx=p.x;e.by=p.y;sfx('warn');}return true;}
    case 'icecopy':{const P=e.path;e.pt+=dt;
      if(!P||!P.length){e.alive=false;return true;}if(!(e.tailT>0)){let i=0;while(i<P.length-1&&P[i+1].t<e.pt)i++;
        if(i>=P.length-1){e.tailT=1.5;const n=P.length,a=P[n-1],b0=P[Math.max(0,n-2)],dtp=Math.max(.05,a.t-b0.t);let vx=(a.x-b0.x)/dtp,vy=(a.y-b0.y)/dtp;const sp=Math.hypot(vx,vy)||1,s2=Math.min(sp,320);e.tvx=vx*s2/sp;e.tvy=vy*s2/sp;if(s2<20){const f=e.face||0;e.tvx=Math.cos(f)*120;e.tvy=Math.sin(f)*120;}}
        else{const a=P[i],b=P[i+1],k=clamp((e.pt-a.t)/Math.max(.001,b.t-a.t),0,1);if(!e.fire)e.face=Math.atan2(b.y-a.y,b.x-a.x);e.x=a.x+(b.x-a.x)*k;e.y=a.y+(b.y-a.y)*k;}}
      if(e.tailT>0){e.tailT-=dt;e.x+=e.tvx*dt;e.y+=e.tvy*dt;if(e.tailT<=0||e.x<-40||e.x>W+40||e.y<-40||e.y>H+40){e.alive=false;explode(e.x,e.y,'#dff6ff',8,.5);return true;}}
      e.vx=e.vy=0;
      if(e.fire&&p.hp>0&&e.spawnT<=0){e.face=Math.atan2(p.y-e.y,p.x-e.x);e.fcd=(e.fcd||0)-dt;if(e.fcd<=0&&onScreen(e)){e.fcd=e.frate;const tx=p.x+p.vx*.25,ty=p.y+p.vy*.25,a=Math.atan2(ty-e.y,tx-e.x);const q=shootE(e.x+Math.cos(a)*16,e.y+Math.sin(a)*16,a,540,e.fdmg,'#dff6ff',4);if(q){q.frost=true;q.copy=true;}}}
      return true;}
    case 'rustcopy':{const pdx=p.x-e.x,pdy=p.y-e.y,m=clamp((pd-220)/100,-1,1);steer(e,pdx/pd*m-pdy/pd*.7*e.dir,pdy/pd*m+pdx/pd*.7*e.dir,e.spd*sm,dt,3);if(Math.random()<dt*.3)e.dir*=-1;e.face=Math.atan2(pdy,pdx);
      e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0){e.cd=rnd(1.2,1.6);const a=Math.atan2(p.y+p.vy*.2-e.y,p.x+p.vx*.2-e.x);const q=shootE(e.x+Math.cos(a)*14,e.y+Math.sin(a)*14,a,430,8,'#ffb060',4);if(q)q.copy=true;}return true;}
    case 'inventor':if(!e.sbk&&!sbAdopt(e))return true;updateInv(e,dt);return true;
    case 'obheart':if(!e.sbk&&!sbAdopt(e))return true;updateOb(e,dt);return true;
    case 'invcell':case 'invcore':case 'obseg':e.vx=e.vy=0;return true;
    case 'corroder':{const m=clamp((d-260)/120,-1,1);steer(e,ux*m-uy*.4*e.dir,uy*m+ux*.4*e.dir,e.spd*sm,dt,1.5);
      e.cd-=dt;if(e.cd<=0&&onScreen(e)){e.cd=rnd(4.5,5.5);const n=G.fields.filter(f=>f.rust&&!f.strip).length;
        if(n<3){G.fields.push({x:e.x+rnd(-20,20),y:e.y+rnd(-20,20),r:90,t:6,max:6,hit:true,rust:true});sfx('warn');}
        else{const b=shootE(e.x,e.y,Math.atan2(T.y-e.y,T.x-e.x),220,0,'#c96a2a',7,false);if(b)b.rust=true;}}return true;}
    case 'repairer':{const pdx=p.x-e.x,pdy=p.y-e.y;
      if(e.hunt>0){e.hunt-=dt;if(e.huntCd>0)e.huntCd-=dt;steer(e,pdx,pdy,e.spd*sm,dt,3.5);e.fix=null;e.chan=0;
        if(pd<e.r+p.r+6&&!(e.huntCd>0)&&p.hp>0&&p.dashT<=0&&p.inv<=0){e.huntCd=1;addWear(G.st.maxHp0*.02);floater(p.x,p.y-26,'ИЗНОС','#ffb060');sfx('block');}return true;}
      let tg=null,td=1e9;for(const o of G.enemies){if(!o.alive||o===e||o.spawnT>0)continue;if(o.type==='hull'){const q=Math.hypot(o.x-e.x,o.y-e.y)-400;if(q<td){td=q;tg=o;}}
        else if(o.hp<o.maxHp*.9&&(!EDEF[o.type].passive||o.type==='obseg')&&o.type!=='repairer'&&!o.sbk){const q=Math.hypot(o.x-e.x,o.y-e.y);if(q<td){td=q;tg=o;}}}
      if(!tg){const m=clamp((pd-330)/100,-1,1);steer(e,(p.x-e.x)/pd*m-(p.y-e.y)/pd*.6*e.dir,(p.y-e.y)/pd*m+(p.x-e.x)/pd*.6*e.dir,e.spd*.6*sm,dt,2);e.chan=0;e.fix=null;return true;}
      const q=Math.hypot(tg.x-e.x,tg.y-e.y);if(q>42){steer(e,tg.x-e.x,tg.y-e.y,e.spd*sm,dt,3);e.chan=0;return true;}
      e.vx*=.8;e.vy*=.8;e.fix=tg;
      if(tg.type==='hull'){e.chan=(e.chan||0)+dt;if(e.chan>=4){e.chan=0;rebuild(tg);}}
      else{tg.hp=Math.min(tg.maxHp,tg.hp+8*dt);if(SET.fx&&vR3()<.3)part(tg.x+vrnd3(-8,8),tg.y+vrnd3(-8,8),0,-30,.3,'#ffb060',2);}return true;}
    case 'hull':{e.life-=dt;e.vx*=.95;e.vy*=.95;if(e.life<=0)e.alive=false;return true;}
  }return false;}
// --- тик (из update) ---
function secTick(dt){const SS=SSW(),p=G.player;if(!SS||!p)return;
  G.posLog.push({t:G.t,x:p.x,y:p.y});if(G.posLog.length>240)G.posLog.splice(0,G.posLog.length-240);
  if(G.iceT>0){G.iceT-=dt;if(G.iceT<=0&&G.ice>0){G.ice--;G.iceT=2.5;}}
  if(G.frozen>0){G.frozen-=dt;p.vx=p.vy=0;}
  if(p.hp>G.st.maxHp)p.hp=G.st.maxHp;
  if(G.iceImm>0)G.iceImm-=dt;if(G.shieldPen>0)G.shieldPen-=dt;if(G.waveHold>0)G.waveHold-=dt;
  if(G.lockShield>0){G.lockShield-=dt;p.shieldUp=false;p.shieldT=0;}if(G.lockDash>0)G.lockDash-=dt;if(G.lockGun>0)G.lockGun-=dt;
  G.slick=false;let inRust=false;
  for(const f of G.fields){if(!f.ice&&!f.rust)continue;const dd=Math.hypot(p.x-f.x,p.y-f.y);
    if(f.ice&&dd<f.r)G.slick=true;if(f.rust&&!f.strip&&dd<f.r&&p.hp>0)inRust=true;
    if(f.strip)for(const e of G.enemies){if(e.alive&&Math.hypot(e.x-f.x,e.y-f.y)<f.r)e.noArm=.5;}}
  if(inRust){addWear(dt);if(Math.random()<dt*2)hintOnce('rust','ИЗНОС КОРПУСА','#c96a2a');}
  if(SS.rust&&inMission()&&p.hp>0&&!G.sb&&storyFlag('obod18')!=='scrap'){G.wearT=(G.wearT||0)+dt;const per=storyFlag('factory')?90:45;if(G.wearT>=per){G.wearT-=per;if(wearPct()<12)addWear(G.st.maxHp0*.01);}}
  for(const e of G.enemies){if(e.noArm>0)e.noArm-=dt;if(e.shieldDown>0)e.shieldDown-=dt;if(e.type==='guard'&&SS.ice)e.iceGuard=true;}
  for(const e of G.enemies)if(e.alive)e.slick=G.fields.some(f=>f.ice&&Math.hypot(e.x-f.x,e.y-f.y)<f.r);
}
// --- отрисовка (из render, после врагов) ---
function secDraw(t){const SS=SSW(),p=G.player;if(!SS)return;
  for(const f of G.fields){const k=f.t/f.max;if(f.ice){ctx.fillStyle='#bfe8ff';ctx.globalAlpha=(.08+.1*k)*COLD_A;ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,TAU);ctx.fill();ctx.strokeStyle='#dff6ff';ctx.globalAlpha=.35*k*COLD_A;ctx.lineWidth=1;ctx.stroke();}
    if(f.rust){ctx.fillStyle=f.strip?'#ffb060':'#8a3a12';ctx.globalAlpha=(f.strip?.12:.22)*Math.min(1,k*3);ctx.beginPath();for(let i=0;i<=20;i++){const a=i/20*TAU,rr=f.r*(1+.08*Math.sin(a*5+t*2));ctx.lineTo(f.x+Math.cos(a)*rr,f.y+Math.sin(a)*rr);}ctx.closePath();ctx.fill();
      ctx.strokeStyle='#c96a2a';ctx.globalAlpha=.4*k;ctx.lineWidth=1.5;ctx.stroke();}}
  ctx.globalAlpha=1;
  for(const e of G.enemies){if(!e.alive)continue;
    if(e.type==='archivist'&&e.st==='rec'&&!G.noTele){ctx.strokeStyle='#8fd8ff';ctx.globalAlpha=.35+.35*Math.sin(t*20);ctx.lineWidth=2;ctx.setLineDash([4,5]);ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.bx,e.by);ctx.stroke();ctx.setLineDash([]);
      ctx.globalAlpha=.8;ctx.beginPath();ctx.arc(e.x,e.y,e.r+6,-Math.PI/2,-Math.PI/2+TAU*(1-e.timer/(G.ice>0?2:3)));ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='repairer'&&e.fix&&e.fix.alive&&Math.hypot(e.fix.x-e.x,e.fix.y-e.y)<60){ctx.strokeStyle='#ffb060';ctx.globalAlpha=.6;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.fix.x,e.fix.y);ctx.stroke();
      if(e.fix.type==='hull'&&e.chan>0){ctx.beginPath();ctx.arc(e.fix.x,e.fix.y,16,-Math.PI/2,-Math.PI/2+TAU*e.chan/4);ctx.lineWidth=3;ctx.stroke();}ctx.globalAlpha=1;}
    if(e.secArm&&!(e.noArm>0)&&e.spawnT<=0&&!EDEF[e.type].passive){ctx.strokeStyle=SS.col;ctx.globalAlpha=.55;ctx.lineWidth=1;ctx.beginPath();ctx.arc(e.x,e.y,e.r+3,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='guard'&&e.iceGuard&&e.cracks>0&&!(e.shieldDown>0)){ctx.strokeStyle='#dff6ff';ctx.globalAlpha=.5;ctx.lineWidth=1;const a0=e.face-1.05;ctx.beginPath();ctx.arc(e.x,e.y,e.r+9,a0,a0+2.1*e.cracks/10);ctx.stroke();ctx.globalAlpha=1;}}
  if(p&&p.hp>0&&(G.ice>0||G.frozen>0)){ctx.strokeStyle='#dff6ff';ctx.lineWidth=1.5;const n=G.frozen>0?3:G.ice;for(let i=0;i<n;i++){const a=t*1.5+i*TAU/3;const x=p.x+Math.cos(a)*22,y=p.y+Math.sin(a)*22;ctx.globalAlpha=.9;ctx.beginPath();for(let k=0;k<3;k++){const b=k*Math.PI/3;ctx.moveTo(x-Math.cos(b)*4,y-Math.sin(b)*4);ctx.lineTo(x+Math.cos(b)*4,y+Math.sin(b)*4);}ctx.stroke();}
    if(G.frozen>0){ctx.globalAlpha=.5;ctx.fillStyle='#dff6ff';ctx.beginPath();ctx.arc(p.x,p.y,p.r+6,0,TAU);ctx.fill();}ctx.globalAlpha=1;}}
// виньетка сектора (экранные координаты)
function secVignette(){const SS=secScale();if(!SS||!G.player||G.state==='menu')return;ctx.setTransform(1,0,0,1,0,0);const k=SS.ice?Math.min(1,.35+.3*(G.ice||0)+(G.frozen>0?.6:0)):.35,CW_=cv.width,CH_=cv.height;
  const V=SS.ice?['191,232,255',.22*k*COLD_A]:SS.brood?['255,107,138',.14+.04*Math.sin(G.t*TAU/1.2)]:SS.mercy?['120,135,160',.2]:SS.bureau?['232,210,122',.1+.05*(G.bo80||0)]:SS.ark?['216,54,74',.12+.08*beat90(G.t)]:SS.zero?(G.x110&&G.x110.k==='launch'?['159,216,255',.07]:['255,159,224',.07+.08*(G.x110&&G.x110.vig||0)]):SS.shore?['122,255,201',.08]:SS.source?['107,140,255',.12+.03*Math.sin(G.t*TAU/3)]:['138,58,18',.18+.015*wearPct()];
  const a=clamp(V[1],0,1)*(isMob()?.67:1);if(a<=.002)return;ctx.globalAlpha=a;ctx.drawImage(secVigSpr96(V[0],CW_,CH_),0,0,CW_,CH_);ctx.globalAlpha=1;}

// ===== 0.5.6: боссы секторов III–IV — «Инвентаризатор» (14) и «Обод» (18) =====
const SB_NAMES={inv:'ИНВЕНТАРИЗАТОР',obod:'ОБОД'};
const INV_PHASES=['ПРИЁМКА','ДУБЛИКАТЫ','КОНСЕРВАЦИЯ'];
const OB_PHASES=['ПРИЁМ','СБОРКА','СЖАТИЕ'];
const COPY_SKINS=['falcon','manta','prism','reaper','halo','comet','hornet','obsidian','sail','pulsar'];
function romanN(n){const M=[[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']];let r='';for(const [v,k] of M)while(n>=v){r+=k;n-=v;}return r||'I';}
function sbRank(){return 1+.25*(curDiff().rank||0);}
function sbHard(){return !!curDiff().hideTele;}
// ===== 0.5.7: скорость, темп атаки, без ремонта, звенья у боссов =====
SEC_SCALE[2].spd2=.05;SEC_SCALE[3].spd2=.10;
function diffK(){return curDiff().k57||1;}
function secSpdK(SS,D){D=D||curDiff();return SS.spd*(1+(SS.pace||0)*(D.hideTele?2:1))*(1+(SS.spd2||0)*(D.k57||1));}
function atkK(){const SS=SSW();if(!SS)return 1;return 1/(1+.15*(inMission()?diffK():1));}
function atkPct(D){return Math.round(15*((D||curDiff()).k57||1));}
function healAllowed(){return !inMission();}
function noHeal(){return !healAllowed();}
function escortCfg(){return curDiff().esc||{every:14,cap:5};}
function secHintFmt(h,m){const M=MISSIONS[(m||G.m)-1],SS=M&&M.gen&&SEC_SCALE[M.sec];if(!SS)return h;const D=curDiff();
  return h.replace('{DMG}',String(playerDmgK()).replace('.',',')).replace('{SPD}',Math.round((secSpdK(SS,D)-1)*100)).replace('{ATK}',atkPct(D));}
function ebK(){const SS=SSW();if(!SS||!SS.pace)return 1;if(!inMission())return (1+SS.pace/2)*(1+(SS.spd2||0)/2);return (1+SS.pace/2*(sbHard()?2:1))*(1+(SS.spd2||0)/2*diffK());}
function storyFlag(k){const S=G.save;return S&&S.story?S.story[k]:undefined;}
// --- радио: произвольная строка (босс, Э. В.) ---
function radioLine(tag,col,txt,delay){const S=G.save;if(!S||!S.story||!SET.radio||STORY_OFF.radio)return;if(G.world&&((tag==='БЮРО'&&storyFlag('line31')==='break')||(tag==='ИСТОК'&&storyFlag('well38')==='silence')))return;const st=radioState();st.q.push({txt,tag,col,d:delay||0});}
function radioSayTxt(q){const st=radioState();radioClear();st.cur={g:'sb',txt:q.txt,tag:q.tag,col:q.col,rift:false,t:0,len:q.txt.length};st.n++;
  const el=radioEl();if(!el)return;el.hidden=false;el.style.opacity='1';el.style.borderColor=q.col;el.classList.remove('rift');
  el.querySelector('.rtag').textContent='ПЕРЕХВАТ · '+q.tag;el.querySelector('.rtag').style.color=q.col;el.querySelector('.rtxt').textContent='';}
// --- общее ---
function spawnSB(kind){if(SBX[kind]||kind==='lek'||kind==='well')return sb85Spawn(kind);if(kind==='nurse'||kind==='flag')return sb74Spawn(kind);ambSting('boss');radioClear();
  const type=kind==='inv'?'inventor':'obheart';const b=spawnEnemy(type,W/2,kind==='inv'?-120:H/2,{noAffix:true,noLoot:true});
  b.hp=b.maxHp=Math.round(EDEF[type].hp*sbRank()*cycHp());b.th=[b.maxHp*.67,b.maxHp*.33,b.maxHp*.10];
  Object.assign(b,{sbk:kind,phase:1,st:'enter',timer:2.6,t:0,rot:0,flash:0,open:0,inv0:0,fails:0,choice:null,domeFlash:0,deathT:0});
  if(kind==='inv')invInit(b);else obInit(b);G.sb=b;sfx('warn');
  banner(SB_NAMES[kind]+(kind==='inv'?' ПРОСЫПАЕТСЯ':' ПРИНИМАЕТ КЛИЕНТА'),'ФАЗА 1 · '+(kind==='inv'?INV_PHASES:OB_PHASES)[0]);
  if(kind==='inv')radioLine('ИНВЕНТАРИЗАТОР','#9fd8ff','Объект 013. Цикл '+romanN(cycN()+31)+'. Отклонение от эталона зафиксировано. Привести.',1.5);
  else{radioLine('ОБОД','#ffb060','Клиент 013, посещение '+fmtN(4102+cycN())+'. Износ корпуса '+Math.max(12,wearPct())+'%. Начинаю обслуживание.',1.5);
    if(storyFlag('inv14')==='memory')radioLine('ОБОД','#ffb060','Клиент 013. Архив сообщает, что вы помните. Это не входит в гарантию.',9);}
  return b;}
function sbAdopt(b){const kind=b.type==='inventor'?'inv':'obod';if(G.sb&&G.sb!==b&&G.sb.alive){b.alive=false;return false;}
  b.hp=b.maxHp=Math.round(EDEF[b.type].hp*sbRank()*cycHp());b.th=[b.maxHp*.67,b.maxHp*.33,b.maxHp*.10];
  Object.assign(b,{sbk:kind,phase:1,st:'enter',timer:1,t:0,rot:0,flash:0,open:0,inv0:0,fails:0,choice:null,domeFlash:0,deathT:0,noAffix:true,noLoot:true});
  if(kind==='inv')invInit(b);else obInit(b);G.sb=b;return true;}
function sbPhase(b){if(is85(b))return sb85Phase(b);if(b.sbk==='nurse'||b.sbk==='flag')return sb74Phase(b);ambSting('phase');b.phase++;b.open=0;b.inv0=2;G.eb=G.eb.filter(x=>x.rift);
  G.shock.push({x:b.x,y:b.y,r:20,R:Math.max(W,H),t:0,col:EDEF[b.type].col,slow:true});sfx('bigboom');shake(14);
  const names=b.sbk==='inv'?INV_PHASES:OB_PHASES;banner(SB_NAMES[b.sbk]+' · ФАЗА '+b.phase,names[b.phase-1]);
  if(b.sbk==='inv'){b.inv=null;for(const c of b.cells){c.label=null;c.locked=false;}
    if(b.phase===2)radioLine('ИНВЕНТАРИЗАТОР','#9fd8ff','Предъявляю предыдущие версии. Сравните.',1);
    if(b.phase===3){b.beams.push({a:b.beams[0].a+Math.PI,dir:b.beams[0].dir});b.ring={x:W/2,y:H/2,r:Math.hypot(W,H)/2*.9,r0:Math.hypot(W,H)/2*.9,acc:0};b.seals=[];b.sealT=1;
      radioLine('ИНВЕНТАРИЗАТОР','#9fd8ff','Консервация. Вы будете храниться хорошо.',1);}}
  else{b.svc=null;b.spokes=[];
    if(b.phase===2)radioLine('ОБОД','#ffb060','Обнаружены запасные корпуса клиента. Использую.',1);
    if(b.phase===3){b.rotV=TAU/8;radioLine('ОБОД','#ffb060','Клиент сопротивляется обслуживанию. Протокол не предусматривает отказ.',1);}}}
function sbCheckTh(b){if(is85(b))return sb85CheckTh(b);if(b.hp<=0)b.hp=1;if(b.st!=='fight')return;if(b.phase<3&&b.hp<=b.th[b.phase-1]){b.hp=b.th[b.phase-1];sbPhase(b);}
  else if(b.phase===3&&b.hp<=b.th[2]){b.hp=b.th[2];sbFinal(b);}}
function sbBlock(e){e.domeFlash=.15;sfx('block');}
function sbHurt(e,dmg,src){if(SB85T.has(e.type))return sb85Hurt(e,dmg,src);if(SB74T.has(e.type))return sb74Hurt(e,dmg,src);const b=G.sb;if(!b||!b.alive)return 0;
  if(e.type==='inventor'||e.type==='obheart'){if(b.st!=='fight'||b.inv0>0){sbBlock(e);return 0;}
    if(e.type==='inventor')return dmg*(b.open>0?1.5:.5);
    if(!obHeartOpen(b)){sbBlock(e);return 0;}return dmg;}
  if(e.type==='invcell'){const c=e.cell;if(c&&c.locked){sbBlock(e);return 0;}
    if(c&&c.open>0&&b.st==='fight'&&b.inv0<=0){b.hp-=dmg*2;b.flash=.07;e.flash=.07;sfx('hit');sbCheckTh(b);return 0;}return dmg;}
  if(e.type==='invcore')return b.st==='final'&&e.spawnT<=0&&!(src&&(src.drone||src.pulse))?dmg:0;
  return dmg;}
function sbTargetable(e){if(SB85T.has(e.type))return sb85Targetable(e);if(SB74T.has(e.type))return sb74Targetable(e);const b=G.sb;if(!b)return false;
  if(e.type==='inventor')return b.st==='fight';if(e.type==='obheart')return b.st==='fight'&&obHeartOpen(b);
  if(e.type==='invcell')return !e.cell||!e.cell.locked;if(e.type==='invcore')return b.st==='final';return true;}
function sbHud(b){if(is85(b))return sb85Hud(b);if(b.sbk==='nurse'||b.sbk==='flag')return sb74Hud(b);const k=SB_NAMES[b.sbk];if(b.st==='dying')return k+' · РАЗРУШЕН';if(b.st==='final')return k+' · ВЫБОР · '+Math.ceil(b.timer)+' С';
  if(b.sbk==='inv'){if(b.inv)return 'ИНВЕНТАРИЗАЦИЯ · '+b.inv.t.toFixed(1)+' С';if(b.open>0)return 'КОРПУС ОТКРЫТ · '+b.open.toFixed(1)+' С';return k+' · ФАЗА '+b.phase;}
  if(b.svc)return 'СЕРВИСНОЕ ОКНО · '+b.svc.t.toFixed(1)+' С';if(b.expo>0)return 'УЗЕЛ ОТКРЫТ · '+b.expo.toFixed(1)+' С';if(b.hop)return 'УЗЕЛ ПЕРЕЕЗЖАЕТ';return k+' · ФАЗА '+b.phase;}
function sbDeath(b){if(!b.alive||b.st==='dying')return;ambSting('bossDown');buzz('boss');b.alive=true;b.st='dying';b.deathT=2.8;b.hp=0;G.eb=G.eb.filter(x=>x.rift);
  G.enemies.forEach(o=>{if(o!==b&&o.alive)kill(o,true);});G.score+=EDEF[b.type].pts;G.kills++;
  G.lockShield=G.lockDash=G.lockGun=0;G.iceRing=null;
  if(b.lostMods&&b.lostMods.length){for(const k of b.lostMods)G.mods[k]=(G.mods[k]||0)+1;b.lostMods=[];computeStats();}
  if(SB_DEATH[b.sbk])banner(SB_DEATH[b.sbk][0],SB_DEATH[b.sbk][1]);else banner(b.sbk==='inv'?'КАРТОТЕКА РАЗРУШЕНА':'ЗАКАЗ ЗАКРЫТ',b.sbk==='inv'?'СЕКТОР III ПРОЙДЕН':'СЕКТОР IV ПРОЙДЕН');
  const S=G.save;if(G.mode==='world'&&S&&S.story){S.story[SB_FLAG[b.sbk]]=b.choice;if(b.sbk==='obod'&&b.choice==='service')S.story.factory=1;}
  radioLine('Э. В.','#ffd36b',SB_DEATH[b.sbk]?SB_DEATH[b.sbk][2]:b.sbk==='inv'?'Я строил Архив, чтобы ты не повторял ошибок. Он решил, что проще не дать тебе меняться.':'Обод был первым, что я построил. Он должен был чинить людей. Людей не осталось, и он стал чинить тебя.',3.5);}
function sbCommon(b,dt){b.t+=dt;if(b.flash>0)b.flash-=dt;if(b.domeFlash>0)b.domeFlash-=dt;if(b.inv0>0)b.inv0-=dt;if(b.open>0)b.open-=dt;
  if(b.st==='dying'){b.deathT-=dt;shake(6);if(Math.random()<.5)explode(b.x+rnd(-50,50),b.y+rnd(-50,50),Math.random()<.5?EDEF[b.type].col:'#ffffff',8,.8);
    if(b.deathT<=0){b.alive=false;explode(b.x,b.y,'#ffffff',120,2.2);sfx('bigboom');shake(20);G.sb=null;G.endT=2.2;}return true;}return false;}
function sbFinal(b){if(is85(b))return sb85Final(b);if(b.sbk==='nurse'||b.sbk==='flag')return sb74Final(b);b.st='final';b.timer=20;b.open=0;G.eb=G.eb.filter(x=>x.rift);
  if(b.sbk==='inv'){b.inv=null;for(const c of b.cells){c.label=null;c.locked=false;}
    b.cores=[['memory',-84],['cold',84]].map(([k,ox])=>{const c=spawnEnemy('invcore',b.x+ox,b.y+46,{noAffix:true,noLoot:true,spawnT:.6,core:k});c.hp=c.maxHp=Math.round(300*sbRank());return c;});
    banner('ЭТАЛОН','ЯДРО ПАМЯТИ ИЛИ ЯДРО ХОЛОДА · 20 С');radioLine('ИНВЕНТАРИЗАТОР','#9fd8ff','Выберите, что стереть. Эталон всегда выбирал холод.',.5);}
  else{b.svc=null;b.spokes=[];b.hop=null;b.tele=false;b.rotV=0;b.expo=0;b.fx0=b.x;b.fy0=b.y;b.fT=0;
    b.docks=[{kind:'fix',ox:-96,ch:0},{kind:'scrap',ox:96,ch:0}];
    banner('ЗАКАЗ-НАРЯД','ВОССТАНОВИТЬ ДО ЗАВОДСКОГО ИЛИ СПИСАТЬ СТАНЦИЮ · 20 С');radioLine('ОБОД','#ffb060','Вопросов не задаю. Но вы можете задать один.',.5);}
  sfx('level');}
function sbTimeout(b){if(is85(b))return;if(b.sbk==='nurse'||b.sbk==='flag')return sb74Timeout(b);b.fails++;
  if(b.fails>=2){sbChoose(b,null);return;}
  b.hp=Math.min(b.maxHp,b.hp+b.maxHp*.2);b.st='fight';b.inv0=1.5;banner(b.sbk==='inv'?'ОТКЛОНЕНИЕ НЕ ЗАФИКСИРОВАНО':'ЗАКАЗ НЕ ПОДТВЕРЖДЁН','ПОВТОР · +20% ПРОЧНОСТИ');sfx('warn');
  if(b.sbk==='inv'){for(const c of (b.cores||[]))if(c.alive)kill(c,true);b.cores=null;}
  else{b.docks=null;b.rotV=TAU/8;b.seatT=3;}}
function sbChoose(b,ch){if(is85(b))return sb85Choose(b,ch);if(b.sbk==='nurse'||b.sbk==='flag')return sb74Choose(b,ch);if(b.choice||(b.st!=='final'&&b.st!=='fight'))return;if(!ch)ch=b.sbk==='inv'?(Math.random()<.5?'memory':'cold'):(Math.random()<.5?'service':'scrap');b.choice=ch;const p=G.player;
  if(ch==='cold'){G.sbLomK=2;G.sbChoiceTxt='Ядро памяти сожжено: лом ×2, Архив замолчал.';banner('ЯДРО ПАМЯТИ СОЖЖЕНО','31 ЗАПИСЬ ИСЧЕЗЛА · ЛОМ ×2');}
  else if(ch==='memory'){G.sbLomK=1;G.sbChoiceTxt='Ядро холода разрушено: записи оттаяли (см. Хронику).';banner('ЯДРО ХОЛОДА РАЗРУШЕНО','ЗАПИСИ ОТТАИВАЮТ · ЦИКЛЫ I–XXXI');}
  else if(ch==='scrap'){G.sbLomK=2;G.sbChoiceTxt='Станция списана: лом ×2, фоновый износ в Хрониках снят.';banner('СТАНЦИЯ СПИСАНА','ЛОМ ×2 · ФОНОВЫЙ ИЗНОС В ХРОНИКАХ СНЯТ');}
  else{G.sbLomK=.5;G.sbChoiceTxt='Корабль восстановлен до заводского: оплата ломом (×0,5), перк «Заводской корпус».';G.mods={};G.wear=0;computeStats();if(p){p.hp=G.st.maxHp;}banner('ВОССТАНОВЛЕНО ДО ЗАВОДСКОГО','ОПЛАТА ЛОМОМ · ПЕРК «ЗАВОДСКОЙ КОРПУС»');}
  if(b.sbk==='inv'){for(const c of (b.cores||[]))if(c.alive)kill(c,true);b.cores=null;}
  sbDeath(b);}
// --- вспомогательное: стая, спавн у края, автоприцел, отрисовка сектора ---
function packSpawn(t){if(!EDEF[t]){edgeSpawn(t);return;}[0,1,3].forEach((s,i)=>edgeSpawn(t,{side:s,delay:i*.08}));floater(W/2,H*.3,'СТАЯ · '+EDEF[t].name.toUpperCase(),EDEF[t].col);sfx('warn');}
const SB_ESC={inv:{1:['scout','scout','gunner','phantom'],2:['frost','rammer','shade','gunner'],3:['hunter','rammer','lancer']},
  obod:{1:['gunner','gunner','scout','shocker'],2:['rammer','hunter','frost'],3:['shade','shade','hunter','lancer']}};
function sbEscort(b,dt){const p=G.player;if(b.st!=='fight'&&b.st!=='final')return;if(b.noEsc&&b.phase===1)return;if(!p||p.hp<=0)return;
  const C=escortCfg();if(b.escT===undefined){b.escT=b.sbk==='inv'&&storyFlag('arcSilence')?14:8;b.escN=0;b.escFinal=false;}
  if(b.st==='final'){if(b.escFinal)return;b.escFinal=true;}
  else{b.escT-=dt;if(b.escT>0)return;b.escT=C.every;}
  const alive=G.enemies.filter(e=>e.alive&&e.escort&&e.type!=='rustcopy').length;if(b.st!=='final'&&alive>=C.cap)return;
  const pool=SB_ESC[b.sbk][Math.min(3,Math.max(1,b.phase))],n=Math.min(Math.random()<.5?3:2,C.cap-alive);if(n<=0)return;
  for(let i=0;i<n;i++){const ty=pool[Math.floor(Math.random()*pool.length)];
    if(b.sbk==='obod'){const a=rnd(0,TAU),x=clamp(b.cx+Math.cos(a)*(b.R-50),20,W-20),y=clamp(b.cy+Math.sin(a)*(b.R-50),20,H-20);spawnEnemy(ty,x,y,{noAffix:true,spawnT:.8,escort:true});}
    else sbEdge(ty,{escort:true});}
  sfx('warn');floater(b.sbk==='obod'?b.cx:b.x,(b.sbk==='obod'?b.cy:b.y)-40,b.escN?'ЗВЕНО ОХРАНЫ':'ОХРАНА ВЫЗВАНА','#ff9a4d');
  if(!b.escN&&SB_ESC_R[b.sbk])radioLine(SB_ESC_R[b.sbk][0],SB_ESC_R[b.sbk][1],SB_ESC_R[b.sbk][2],.3);else if(!b.escN)radioLine(b.sbk==='inv'?'ИНВЕНТАРИЗАТОР':'ОБОД',b.sbk==='inv'?'#9fd8ff':'#ffb060',b.sbk==='inv'?'Отклонение сопротивляется описанию. Архив вызывает охрану хранилища.':'Клиент беспокоит других клиентов. Вызываю других клиентов.',.3);
  b.escN++;}
function sbEdge(type,o){const s=Math.random()*4|0,u=rnd(.1,.9);const x=s===0?u*W:s===1?W+30:s===2?u*W:-30,y=s===0?-30:s===1?u*H:s===2?H+30:u*H;return spawnEnemy(type,x,y,Object.assign({noAffix:true,spawnT:.4},o||{}));}
function sbAutoTarget(p){const b=G.sb;if(!b||!b.alive||b.st!=='fight')return null;if(is85(b))return sb85Auto(p,b);if(b.sbk==='nurse'||b.sbk==='flag')return sb75Auto(p,b);
  if(b.sbk==='inv'){const I=b.inv;if(I){if(I.auto&&I.auto.alive&&I.auto.cell&&I.auto.cell.label&&!I.auto.cell.locked&&targetable(I.auto))return I.auto;
      let best=null,bd=1e9;for(const c of I.cs){const e=c.e;if(!e||!e.alive||!c.label||c.locked||!targetable(e))continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<bd){bd=d;best=e;}}if(best){I.auto=best;return best;}}
    if(b.open>0&&targetable(b)&&Math.hypot(b.x-p.x,b.y-p.y)<700)return b;return null;}
  if(targetable(b)&&Math.hypot(b.x-p.x,b.y-p.y)<700)return b;return null;}
function secDraw2(t){const SS=secScale();if(!SS)return;
  for(const e of G.enemies){if(!e.alive||e.spawnT>0||EDEF[e.type].passive||STATIC.has(e.type)||e.ghost)continue;const sp=Math.hypot(e.vx,e.vy);
    if(sp>190){ctx.strokeStyle=EDEF[e.type].col;ctx.globalAlpha=.28;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.x-e.vx*.08,e.y-e.vy*.08);ctx.stroke();}
    if(e.tired){ctx.strokeStyle='#9fb0c4';ctx.globalAlpha=.6;ctx.lineWidth=1;ctx.setLineDash([2,4]);ctx.beginPath();ctx.arc(e.x,e.y,e.r+8,0,TAU);ctx.stroke();ctx.setLineDash([]);}}
  ctx.globalAlpha=1;sbDraw(t);}
// --- усталость: затянувшаяся концовка из бронированных (все сгенерированные миссии 11+) ---
function tiredTick(dt){if(!inMission()||G.mode==='endless'||G.sb||G.deadT>0||G.endT>0||!G.player)return;const M=MISSIONS[G.m-1];if(!M||!M.gen)return;
  const live=G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive&&e.spawnT<=0);
  const slowOnly=live.length>0&&!G.spawnQ.length&&!G.warns.length&&live.every(e=>SEC_SLOW.has(e.type)||e.tired);
  if(!slowOnly){G.tiredT=0;return;}
  G.tiredT=(G.tiredT||0)+dt;if(G.tiredT<12)return;G.tiredT=0;
  if(G.waveIdx<G.waves.length){G.waveForce=true;G.gapT=0;return;}
  for(const e of live){if(e.tired)continue;e.tired=true;e.secArm=0;if(e.type==='guard')e.shieldDown=999;floater(e.x,e.y-e.r-12,'УСТАЛОСТЬ · БРОНЯ СНЯТА','#9fb0c4');}}
// ---------- Инвентаризатор ----------
function invInit(b){b.cells=[];for(let i=0;i<6;i++)b.cells.push({i,e:null,t:0,label:null,open:0,locked:false});
  b.beams=[{a:rnd(0,TAU),dir:Math.random()<.5?1:-1,acc:0}];b.crysT=3.5;b.invT=storyFlag('arcSilence')?12:7;b.inv=null;b.copyT=5;b.ring=null;b.seals=[];b.sealT=0;b.cores=null;}
function invCellPos(b,i){const a=b.t*.5+i/6*TAU;return {x:b.x+Math.cos(a)*96,y:b.y+Math.sin(a)*72};}
function invSpawnCell(b,c){const q=invCellPos(b,c.i);c.e=spawnEnemy('invcell',q.x,q.y,{noAffix:true,noLoot:true,spawnT:.8,cell:c});c.e.hp=c.e.maxHp=Math.round(160*sbRank());c.label=null;c.locked=false;c.open=0;}
function invMoveCells(b){for(const c of b.cells){if(c.e&&c.e.alive){const q=invCellPos(b,c.i);c.e.x=q.x;c.e.y=q.y;c.e.vx=c.e.vy=0;}}}
function invCellDied(e){const b=G.sb,c=e.cell;if(!b||!c||b.sbk!=='inv')return;c.e=null;c.t=sbHard()?12:15;if(b.st==='dying')return;
  if(c.label&&b.inv){const L=c.label;b.inv.saved.push(L);c.label=null;floater(e.x,e.y-20,L+' · СИСТЕМА СПАСЕНА','#dff6ff');for(const o of b.inv.cs)if(o!==c&&o.label)o.locked=true;}
  c.label=null;c.locked=false;if(b.st==='fight'){b.open=Math.max(b.open,6);floater(b.x,b.y-b.r-16,'КОРПУС ОТКРЫТ · 6 С','#dff6ff');if(Math.random()<.55)dropCell(e.x,e.y,0);}sfx('level');}
function invCoreDied(e){const b=G.sb;if(!b||b.sbk!=='inv'||b.st!=='final'||b.choice)return;sbChoose(b,e.core);}
function invLock(sys){const p=G.player;if(sys==='ЩИТ'){G.lockShield=8;p.shieldUp=false;p.shieldT=0;}else if(sys==='РЫВОК')G.lockDash=8;else G.lockGun=8;
  floater(p.x,p.y-30,sys+' · ПРИНЯТО НА ХРАНЕНИЕ · 8 С','#8fd8ff');sfx('block');}
function invCopy(b){const p=G.player,hard=sbHard();let path=null;const log=G.posLog.filter(q=>G.t-q.t<=3);
  if(log.length>=4){let len=0;for(let i=1;i<log.length;i++)len+=Math.hypot(log[i].x-log[i-1].x,log[i].y-log[i-1].y);if(len>=120)path=log.map(q=>({x:q.x,y:q.y,t:q.t-log[0].t}));}
  if(!path){const a0=rnd(0,TAU),R_=250,dir=Math.random()<.5?1:-1;path=[];for(let i=0;i<=24;i++){const a=a0+dir*i/24*1.6;path.push({x:clamp(p.x+Math.cos(a)*R_,20,W-20),y:clamp(p.y+Math.sin(a)*R_,20,H-20),t:i/24*3});}}
  const skin=COPY_SKINS[Math.floor(Math.random()*COPY_SKINS.length)];
  const c=spawnEnemy('icecopy',path[0].x,path[0].y,{path,pt:0,noAffix:true,noLoot:true,spawnT:1,fire:true,frate:Math.max(.5,G.st.rate*2)*atkK(),fdmg:clamp(G.st.dmg*.5,6,22),skin,hull:HULL_NUM[skin]||''});c.contact=14;
  const alive=b.cells.filter(x=>x.e&&x.e.alive&&x.e.spawnT<=0);if(alive.length){const cc=alive[Math.floor(Math.random()*alive.length)];cc.open=5;floater(cc.e.x,cc.e.y-18,'ЯЧЕЙКА ОТКРЫТА · УРОН В КОРПУС ×2','#dff6ff');}
  floater(c.x,c.y-22,'ЗАПИСЬ ЦИКЛА · VØID-'+(c.hull||'0??'),'#8fd8ff');sfx('warn');}
function updateInv(b,dt){const p=G.player,hard=sbHard();if(sbCommon(b,dt))return;sbEscort(b,dt);
  if(b.st==='enter'){b.y+=(H*.24-b.y)*Math.min(1,dt*1.4);b.timer-=dt;if(b.timer<=0){b.st='fight';for(const c of b.cells)invSpawnCell(b,c);}invMoveCells(b);return;}
  if(b.st==='final'){b.timer-=dt;invMoveCells(b);if(b.cores)b.cores.forEach((c,i)=>{if(c.alive){c.x=b.x+(i?84:-84);c.y=b.y+46;}});if(b.timer<=0)sbTimeout(b);return;}
  // движение
  if(b.phase<3){const tx=W/2+Math.sin(b.t*.3)*W*.28,ty=H*.22+Math.sin(b.t*.6)*H*.06,k=Math.min(1,dt*.6);b.x+=(tx-b.x)*k;b.y+=(ty-b.y)*k;}
  else{const k=Math.min(1,dt*.8);b.x+=(W/2-b.x)*k;b.y+=(H*.42-b.y)*k;}
  invMoveCells(b);
  for(const c of b.cells){if(c.open>0)c.open-=dt;if(c.e&&!c.e.alive)c.e=null;if(!c.e){c.t-=dt;if(c.t<=0)invSpawnCell(b,c);}
    else if(c.e.spawnT<=0&&p.hp>0&&b.inv0<=0){c.cd=(c.cd===undefined?rnd(1.5,4):c.cd)-dt;if(c.cd<=0&&onScreen(c.e)){c.cd=(b.phase===3?rnd(2.6,3.4):rnd(3.2,4.4))*atkK();const a=Math.atan2(p.y-c.e.y,p.x-c.e.x)+rnd(-.06,.06);const q=shootE(c.e.x,c.e.y,a,175,8,'#bfe8ff',5);if(q){q.frost=true;q.boss=true;}}}}
  // инвентаризация
  if(!b.inv){b.invT-=dt;if(b.invT<=0){const alive=b.cells.filter(c=>c.e&&c.e.alive&&c.e.spawnT<=0);
      if(alive.length>=2){const sys=shuffle(['ЩИТ','РЫВОК','ОРУДИЕ']).slice(0,2),cs=shuffle(alive.slice()).slice(0,2);cs[0].label=sys[0];cs[1].label=sys[1];
        b.inv={t:4,saved:[],cs};banner('ИНВЕНТАРИЗАЦИЯ · '+sys.join(' / '),'РАЗБЕЙТЕ ЯЧЕЙКУ С НУЖНОЙ СИСТЕМОЙ · 4 С');sfx('warn');b.invT=hard?9:12;}
      else b.invT=2;}}
  else{const I=b.inv;I.t-=dt;if(I.t<=0){for(const c of I.cs){if(c.label&&c.e&&c.e.alive)invLock(c.label);c.label=null;c.locked=false;}b.inv=null;}}
  // индекс-лучи
  for(const B of b.beams){B.a+=B.dir*(b.phase===3?.61:.436)*dt;
    if(p.hp>0&&p.dashT<=0){const dx=p.x-b.x,dy=p.y-b.y,d=Math.hypot(dx,dy);if(d<520&&Math.abs(angDiff(Math.atan2(dy,dx),B.a))<.52){B.acc+=dt;if(B.acc>=.7){B.acc=0;addIce(1);}}else B.acc=0;}}
  // кристаллы
  b.crysT-=dt;if(b.crysT<=0&&p.hp>0){b.crysT=(b.phase===3?2.2:b.phase===2?2.6:3)*atkK();const n=b.phase===3?7:5,a0=Math.atan2(p.y-b.y,p.x-b.x);
    for(let i=0;i<n;i++){const q=shootE(b.x,b.y,a0+(i-(n-1)/2)*.17,190,10,'#bfe8ff',6);if(q){q.frost=true;q.boss=true;}}}
  // фаза 2: записи циклов
  if(b.phase>=2){b.copyT-=dt;if(b.copyT<=0){b.copyT=(hard?7:9)*atkK();if(G.enemies.filter(e=>e.alive&&e.type==='icecopy').length<(hard?4:3))invCopy(b);}}
  // фаза 3: консервация
  if(b.phase===3&&b.ring){const R_=b.ring;R_.r=Math.max(170,R_.r-14*dt);
    b.sealT-=dt;if(b.seals.length<3&&b.sealT<=0){b.sealT=3;b.seals.push({a:rnd(0,TAU),t:0});}
    if(p.hp>0){const d=Math.hypot(p.x-R_.x,p.y-R_.y);if(d>R_.r){R_.acc+=dt;if(R_.acc>=1){R_.acc=0;addIce(1);hintOnce('icering','ЛЁД · ВЕРНИТЕСЬ В КРУГ','#bfe8ff');}}else R_.acc=0;}
    if(p.dashT>0)for(let i=b.seals.length-1;i>=0;i--){const s=b.seals[i],sx=R_.x+Math.cos(s.a)*R_.r,sy=R_.y+Math.sin(s.a)*R_.r;
      if(segDist(p.px,p.py,p.x,p.y,sx,sy)<26){b.seals.splice(i,1);R_.r=Math.min(R_.r0,R_.r+80);explode(sx,sy,'#dff6ff',16,.8);floater(sx,sy-18,'ПЕЧАТЬ СЛОМАНА · КРУГ +80','#dff6ff');sfx('boom');b.sealT=Math.max(b.sealT,6);}}}}
// ---------- Обод ----------
function obInit(b){b.cx=W/2;b.cy=H/2;b.R=260;b.R0=260;b.Rmin=sbHard()?120:150;b.rot=0;b.rotV=TAU/18;b.segs=[];for(let i=0;i<8;i++)b.segs.push({i,e:null,t:0});
  b.seat=2;b.seatT=8;b.hop=null;b.tele=false;b.next=0;b.expo=0;b.svcT=9;b.svc=null;b.spokeT=3;b.spokes=[];b.rcT=6;b.rustT=5;b.repT=15;b.lostMods=[];b.docks=null;b.shrink=0;
  b.memory=storyFlag('inv14')==='memory';b.x=b.cx+Math.cos(obSegAng(b,b.seat))*b.R;b.y=b.cy+Math.sin(obSegAng(b,b.seat))*b.R;}
function obSegAng(b,i){return b.rot+i*TAU/8;}
function obSegPos(b,i){const a=obSegAng(b,i);return {x:b.cx+Math.cos(a)*b.R,y:b.cy+Math.sin(a)*b.R};}
function obSpawnSeg(b,s){const q=obSegPos(b,s.i);s.e=spawnEnemy('obseg',q.x,q.y,{noAffix:true,noLoot:true,spawnT:.8,seg:s});s.e.hp=s.e.maxHp=Math.round(350*sbRank());}
function obSegDied(e){const b=G.sb,s=e.seg;if(!b||!s||b.sbk!=='obod')return;s.e=null;s.t=10;if(b.st==='dying')return;floater(e.x,e.y-18,'ПРОБОИНА','#ffb060');if(Math.random()<.5)dropCell(e.x,e.y,0);}
function obHoleAt(b,a){for(const s of b.segs){const sa=obSegAng(b,s.i);const hole=!s.e||!s.e.alive||s.e.spawnT>0||(b.svc&&b.svc.docks.some(d=>d.i===s.i));
    if(hole&&Math.abs(angDiff(a,sa))<TAU/16-.05)return true;}return false;}
function obHeartOpen(b){if(b.st!=='fight')return false;if(b.hop||b.expo>0)return true;const s=b.segs[b.seat];return !s.e||!s.e.alive||s.e.spawnT>0;}
function obPickSeg(b){const ok=b.segs.filter(s=>s.i!==b.seat&&s.e&&s.e.alive),any=b.segs.filter(s=>s.i!==b.seat);const pool=ok.length&&Math.random()<.65?ok:any;return pool[Math.floor(Math.random()*pool.length)].i;}
function obRingBullet(b,q){const d0=Math.hypot(q.px-b.cx,q.py-b.cy),d1=Math.hypot(q.x-b.cx,q.y-b.cy);if((d0-b.R)*(d1-b.R)>0&&Math.abs(d1-b.R)>8)return false;
  const a=Math.atan2((q.y+q.py)/2-b.cy,(q.x+q.px)/2-b.cx);
  for(const s of b.segs){const e=s.e;if(!e||!e.alive||e.spawnT>0)continue;if(b.svc&&b.svc.docks.some(d=>d.i===s.i))continue;
    if(Math.abs(angDiff(a,obSegAng(b,s.i)))<TAU/16){if(q.hit.includes(e))return false;q.hit.push(e);hurt(e,q.dmg,{charged:!!q.charged});if(SET.fx)part(q.x,q.y,vrnd3(-50,50),vrnd3(-50,50),.2,'#ffb060',2);if(!q.charged)q.life=0;return true;}}
  return false;}
function obRingPlayer(b){const p=G.player;if(!p||p.hp<=0||b.st==='dying')return;const dx=p.x-b.cx,dy=p.y-b.cy,d=Math.hypot(dx,dy)||1,a=Math.atan2(dy,dx),th=7+p.r;
  if(Math.abs(d-b.R)>=th||obHoleAt(b,a))return;
  if(d<b.R){p.x=b.cx+dx/d*(b.R-th-1);p.y=b.cy+dy/d*(b.R-th-1);if(p.dashT<=0){damagePlayer(b.phase===3?20:10);if(b.phase===3)addWear(G.st.maxHp0*.03);}}
  else{p.x=b.cx+dx/d*(b.R+th+1);p.y=b.cy+dy/d*(b.R+th+1);}
  p.x=clamp(p.x,p.r,BW-p.r);p.y=clamp(p.y,p.r,BH-p.r);p.vx*=.3;p.vy*=.3;}
function obFix(b){const p=G.player;G.wear=0;computeStats();p.inv=Math.max(p.inv,6);p.shieldUp=true;p.shieldT=0;G.shieldPen=0;G.ice=0;
  const ks=Object.keys(G.mods).filter(k=>G.mods[k]>0);let txt='';if(ks.length){const k=ks[Math.floor(Math.random()*ks.length)];G.mods[k]--;if(!G.mods[k])delete G.mods[k];b.lostMods.push(k);computeStats();if(p.hp>G.st.maxHp)p.hp=G.st.maxHp;txt=' · УДАЛЕНО: '+(MODS[k]?MODS[k].name.toUpperCase():k);}
  banner('РЕМОНТ ВЫПОЛНЕН','ИЗНОС СНЯТ · ЩИТ · НЕУЯЗВИМОСТЬ 6 С'+txt);sfx('level');}
function obScrap(b,i){const s=b.segs[i];if(s.e&&s.e.alive)kill(s.e,true);s.e=null;s.t=9;b.expo=9;
  let n=0;for(const e of G.enemies)if(e.alive&&e.type==='repairer'){e.hunt=8;n++;}
  if(n<2)for(let k=n;k<2;k++)sbEdge('repairer',{hunt:8});
  banner('УТИЛИЗАЦИЯ','ПРОБОИНА · УЗЕЛ ОТКРЫТ 8 С · РЕМОНТНИКИ ИДУТ ЗА ВАМИ');sfx('bigboom');shake(8);}
function updateOb(b,dt){const p=G.player,hard=sbHard();if(sbCommon(b,dt))return;sbEscort(b,dt);
  if(b.st==='enter'){b.timer-=dt;b.cx+=(p.x-b.cx)*Math.min(1,dt);b.cy+=(p.y-b.cy)*Math.min(1,dt);if(b.timer<=0){b.st='fight';for(const s of b.segs)obSpawnSeg(b,s);for(let k=0;k<2;k++)edgeSpawn('repairer');}
    const q=obSegPos(b,b.seat);b.x=q.x;b.y=q.y;obPlaceSegs(b);return;}
  if(b.st==='final'){b.timer-=dt;b.fT=Math.min(1,(b.fT||0)+dt/1.5);b.x=b.fx0+(b.cx-b.fx0)*b.fT;b.y=b.fy0+(b.cy-b.fy0)*b.fT;obPlaceSegs(b);
    if(b.docks&&b.fT>=1&&p.hp>0)for(const d of b.docks){const x=b.cx+d.ox,y=b.cy;if(Math.hypot(p.x-x,p.y-y)<40){d.ch+=dt;if(d.ch>=.6){sbChoose(b,d.kind==='fix'?'service':'scrap');return;}}else d.ch=0;}
    if(b.timer<=0)sbTimeout(b);return;}
  // кольцо следует за игроком
  {const lo=Math.min(b.R+30,W/2),hi=Math.max(W-b.R-30,W/2),lo2=Math.min(b.R+30,H/2),hi2=Math.max(H-b.R-30,H/2);const tx=clamp(p.x,lo,hi),ty=clamp(p.y,lo2,hi2);
    const sp=70*dt,ddx=tx-b.cx,ddy=ty-b.cy,dd=Math.hypot(ddx,ddy);if(dd>sp){b.cx+=ddx/dd*sp;b.cy+=ddy/dd*sp;}else{b.cx=tx;b.cy=ty;}}
  b.rot+=b.rotV*dt;
  if(b.phase===3){b.shrink+=dt;b.R=Math.max(b.Rmin,b.R0-(b.R0-b.Rmin)*Math.min(1,b.shrink/20));}
  // сегменты
  for(const s of b.segs){if(s.e&&!s.e.alive)s.e=null;if(!s.e){s.t-=dt;if(s.t<=0){obSpawnSeg(b,s);floater(s.e.x,s.e.y-18,'СЕГМЕНТ ВОССТАНОВЛЕН','#ffb060');}}}
  obPlaceSegs(b);
  // узел: переезды
  if(b.expo>0)b.expo-=dt;
  if(!b.hop){b.seatT-=dt;if(b.seatT<=1&&!b.tele){b.tele=true;b.next=obPickSeg(b);}
    if(b.seatT<=0){const q0=obSegPos(b,b.seat);b.hop={x0:q0.x,y0:q0.y,to:b.next,t:0};b.tele=false;b.seatT=b.phase===3?5:8;}
    const q=obSegPos(b,b.seat);b.x=q.x;b.y=q.y;}
  else{const h=b.hop;h.t+=dt;const k=Math.min(1,h.t/1.5),q=obSegPos(b,h.to);b.x=h.x0+(q.x-h.x0)*k;b.y=h.y0+(q.y-h.y0)*k;if(k>=1){b.seat=h.to;b.hop=null;}}
  // ржавый веер узла
  b.fanT=(b.fanT===undefined?2:b.fanT)-dt;if(b.fanT<=0&&p.hp>0&&onScreen(b)){b.fanT=(b.phase===3?3.2:4)*atkK();const a0=Math.atan2(p.y-b.y,p.x-b.x);for(let i=-1;i<=1;i++){const q=shootE(b.x,b.y,a0+i*.16,230,8,'#ffb060',5);if(q)q.boss=true;}}
  // спицы ржавчины
  b.spokeT-=dt;if(b.spokeT<=0){b.spokeT=(b.phase===3?2.4:2.7)*atkK();for(let k=0;k<2;k++){const i=Math.floor(Math.random()*8);if(b.segs[i].e&&b.segs[i].e.alive&&!b.spokes.some(s=>s.i===i))b.spokes.push({i,t:0,tele:.8,act:b.phase>=2?1:.3,hit:false});}}
  for(const s of b.spokes){s.t+=dt;if(s.t>s.tele&&s.t<=s.tele+s.act&&!s.hit&&p.hp>0&&p.dashT<=0&&p.inv<=0){const q=obSegPos(b,s.i);
      if(segDist(q.x,q.y,b.cx,b.cy,p.x,p.y)<16){s.hit=true;damagePlayer(14);if(p.shieldUp){p.shieldUp=false;p.shieldT=0;}G.shieldPen=10;hintOnce('rustsh','РЖАВЧИНА · ЩИТ СБИТ','#c96a2a');}}}
  b.spokes=b.spokes.filter(s=>s.t<s.tele+s.act);
  // сервисные окна
  if(!b.svc){b.svcT-=dt;if(b.svcT<=0){let i=Math.floor(Math.random()*8);if(i===b.seat||(i+4)%8===b.seat)i=(i+1)%8;b.svc={t:5,docks:[{i,kind:'fix',ch:0},{i:(i+4)%8,kind:'scrap',ch:0}]};b.svcT=b.memory?11:(hard?10:14);
      banner('СЕРВИСНОЕ ОКНО · 5 С','ЗЕЛЁНЫЙ ДОК — РЕМОНТ · КРАСНЫЙ — УТИЛИЗАЦИЯ');sfx('warn');}}
  else{const S_=b.svc;S_.t-=dt;let done=false;
    for(const d of S_.docks){const q=obSegPos(b,d.i),near=p.hp>0&&Math.hypot(p.x-q.x,p.y-q.y)<46;
      if(d.kind==='fix'){if(near){d.ch+=dt;if(d.ch>=2){obFix(b);done=true;break;}}else d.ch=0;}
      else if(near){obScrap(b,d.i);done=true;break;}}
    if(done||S_.t<=0)b.svc=null;}
  // ремонтники
  b.repT-=dt;if(b.repT<=0){b.repT=15;if(G.enemies.filter(e=>e.alive&&e.type==='repairer').length<2)edgeSpawn('repairer');}
  // фаза 2: ржавые копии
  if(b.phase>=2){b.rcT-=dt;if(b.rcT<=0){b.rcT=12*atkK();const n=G.enemies.filter(e=>e.alive&&e.type==='rustcopy').length;
      for(let k=0;k<2&&n+k<4;k++){const a=rnd(0,TAU),x=clamp(b.cx+Math.cos(a)*(b.R-40),20,W-20),y=clamp(b.cy+Math.sin(a)*(b.R-40),20,H-20);
        const c=spawnEnemy('rustcopy',x,y,{noAffix:true,noLoot:true,spawnT:.8,skin:COPY_SKINS[Math.floor(Math.random()*COPY_SKINS.length)]});c.hp=c.maxHp=Math.round(60*sbRank());c.spd*=1+.10*diffK();}
      floater(b.cx,b.cy-30,'ЗАПАСНЫЕ КОРПУСА КЛИЕНТА','#c96a2a');sfx('warn');}}
  // фаза 3: ржавчина внутри
  if(b.phase===3){b.rustT-=dt;if(b.rustT<=0){b.rustT=5;if(G.fields.filter(f=>f.rust&&!f.strip).length<3){const a=rnd(0,TAU),r=rnd(0,b.R*.5);G.fields.push({x:b.cx+Math.cos(a)*r,y:b.cy+Math.sin(a)*r,r:70,t:6,max:6,hit:true,rust:true});}}}
  obRingPlayer(b);}
function obPlaceSegs(b){for(const s of b.segs){if(s.e&&s.e.alive){const q=obSegPos(b,s.i);s.e.x=q.x;s.e.y=q.y;s.e.vx=s.e.vy=0;}}}
// ---------- отрисовка боссов (мировые координаты, после врагов) ----------
function sbDraw(t){const b=G.sb;if(!b||!b.alive)return;const p=G.player;if(is85(b))return sb85Draw(b,t);if(b.sbk==='nurse'||b.sbk==='flag')return sb74Draw(b,t);
  if(b.sbk==='inv'){
    if(b.st==='fight'||b.st==='final'){
      // лучи
      if(b.st==='fight')for(const B of b.beams){ctx.save();ctx.translate(b.x,b.y);ctx.rotate(B.a);const g=ctx.createLinearGradient(0,0,520,0);g.addColorStop(0,'rgba(191,232,255,.28)');g.addColorStop(1,'rgba(191,232,255,0)');
        ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(0,0);ctx.arc(0,0,520,-.52,.52);ctx.closePath();ctx.fill();ctx.strokeStyle='rgba(223,246,255,.5)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(Math.cos(-.52)*520,Math.sin(-.52)*520);ctx.moveTo(0,0);ctx.lineTo(Math.cos(.52)*520,Math.sin(.52)*520);ctx.stroke();ctx.restore();}
      // подписи ячеек
      ctx.font='700 10px "JetBrains Mono",monospace';ctx.textAlign='center';
      for(const c of b.cells){const e=c.e;if(!e||!e.alive)continue;
        if(c.label&&b.inv&&!(sbHard()&&b.inv.t>1)){ctx.fillStyle='#04060c';ctx.fillText(c.label,e.x+1,e.y-e.r-9);ctx.fillStyle=c.locked?'#5a6b80':'#ffffff';ctx.fillText(c.label,e.x,e.y-e.r-10);
          if(!c.locked){ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.globalAlpha=.9;ctx.beginPath();ctx.arc(e.x,e.y,e.r+7,-Math.PI/2,-Math.PI/2+TAU*(b.inv.t/4));ctx.stroke();ctx.globalAlpha=1;}}
        if(c.open>0){ctx.strokeStyle='#ffffff';ctx.globalAlpha=.4+.4*Math.sin(t*12);ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+5,0,TAU);ctx.stroke();ctx.globalAlpha=1;}}
      // кольцо льда (фаза 3)
      if(b.ring&&b.st==='fight'){const R_=b.ring;ctx.fillStyle='rgba(191,232,255,.16)';ctx.beginPath();ctx.rect(-4000,-4000,8000,8000);ctx.arc(R_.x,R_.y,R_.r,0,TAU,true);ctx.fill('evenodd');
        ctx.strokeStyle='#dff6ff';ctx.globalAlpha=.6;ctx.lineWidth=2;ctx.setLineDash([8,6]);ctx.lineDashOffset=-t*20;ctx.beginPath();ctx.arc(R_.x,R_.y,R_.r,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.globalAlpha=1;
        for(const s of b.seals){const x=R_.x+Math.cos(s.a)*R_.r,y=R_.y+Math.sin(s.a)*R_.r;glow(x,y,30,'#dff6ff',.7);ctx.save();ctx.translate(x,y);ctx.rotate(t*2);ctx.strokeStyle='#ffffff';ctx.fillStyle='#0b1a28';ctx.lineWidth=2;poly(6,12,0);ctx.fill();ctx.stroke();ctx.restore();worldLabel(x,y-22,'ПЕЧАТЬ · РЫВОК','#dff6ff');}}
      // ядра финала
      if(b.st==='final'&&b.cores)for(const c of b.cores){if(!c.alive)continue;worldLabel(c.x,c.y-c.r-14,c.core==='memory'?'ЯДРО ПАМЯТИ':'ЯДРО ХОЛОДА',c.core==='memory'?'#ffd36b':'#bfe8ff');}
      if(b.st==='final'){ctx.strokeStyle='#ffffff';ctx.globalAlpha=.8;ctx.lineWidth=3;ctx.beginPath();ctx.arc(b.x,b.y,b.r+22,-Math.PI/2,-Math.PI/2+TAU*(b.timer/20));ctx.stroke();ctx.globalAlpha=1;}
      // маршруты копий (пока появляются)
      for(const e of G.enemies){if(e.type!=='icecopy'||!e.alive||e.spawnT<=0||!e.path)continue;ctx.strokeStyle='#dff6ff';ctx.globalAlpha=.5;ctx.lineWidth=1.5;ctx.setLineDash([4,6]);ctx.beginPath();e.path.forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
    }
  }else{
    // кольцо Обода
    const segs=b.segs,hard=sbHard();
    for(const s of segs){const e=s.e,a=obSegAng(b,s.i),alive=e&&e.alive;const dock=b.svc&&b.svc.docks.find(d=>d.i===s.i);
      if(alive){const k=e.hp/e.maxHp;let col=e.flash>0?'#ffffff':dock?(hard&&b.svc.t>2?'#c9d2de':dock.kind==='fix'?'#7affc9':'#ff4f6e'):(b.tele&&b.next===s.i&&!b.hop)?'#ffb060':'#c96a2a';
        ctx.strokeStyle=col;ctx.lineWidth=dock?8:14;ctx.globalAlpha=e.spawnT>0?Math.max(0,1-e.spawnT):(.55+.45*k);ctx.beginPath();ctx.arc(b.cx,b.cy,b.R,a-TAU/16+.03,a+TAU/16-.03);ctx.stroke();
        if(dock){ctx.setLineDash([4,5]);ctx.lineWidth=2;ctx.globalAlpha=.9;ctx.beginPath();ctx.arc(b.cx,b.cy,b.R+12,a-TAU/16,a+TAU/16);ctx.stroke();ctx.setLineDash([]);
          const q=obSegPos(b,s.i);worldLabel(q.x,q.y-26,hard&&b.svc.t>2?'ДОК · ?':dock.kind==='fix'?'РЕМОНТ · 2 С':'УТИЛИЗАЦИЯ',col);
          if(dock.kind==='fix'&&dock.ch>0){ctx.strokeStyle='#7affc9';ctx.lineWidth=3;ctx.beginPath();ctx.arc(q.x,q.y,30,-Math.PI/2,-Math.PI/2+TAU*dock.ch/2);ctx.stroke();}}
        ctx.globalAlpha=1;}
      else{ctx.strokeStyle='#5a2e14';ctx.lineWidth=3;ctx.globalAlpha=.5;ctx.setLineDash([3,7]);ctx.beginPath();ctx.arc(b.cx,b.cy,b.R,a-TAU/16+.03,a+TAU/16-.03);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
        if(SET.fx&&Math.random()<.15){const q=obSegPos(b,s.i);part(q.x+rnd(-20,20),q.y+rnd(-20,20),rnd(-20,20),rnd(-20,20),.4,'#ffb060',2);}}}
    // спицы
    for(const s of b.spokes){const q=obSegPos(b,s.i);if(s.t<=s.tele){if(G.noTele)continue;ctx.strokeStyle='#c96a2a';ctx.globalAlpha=.3+.5*(s.t/s.tele);ctx.lineWidth=2;ctx.setLineDash([6,8]);ctx.beginPath();ctx.moveTo(q.x,q.y);ctx.lineTo(b.cx,b.cy);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
      else{ctx.globalCompositeOperation='lighter';ctx.strokeStyle='#ff8a3d';ctx.globalAlpha=.6;ctx.lineWidth=18;ctx.beginPath();ctx.moveTo(q.x,q.y);ctx.lineTo(b.cx,b.cy);ctx.stroke();ctx.strokeStyle='#ffffff';ctx.lineWidth=4;ctx.globalAlpha=1;ctx.stroke();ctx.globalCompositeOperation='source-over';}}
    // переезд узла
    if(b.hop){ctx.strokeStyle='#ffb060';ctx.globalAlpha=.5;ctx.lineWidth=2;ctx.setLineDash([5,6]);const q=obSegPos(b,b.hop.to);ctx.beginPath();ctx.moveTo(b.hop.x0,b.hop.y0);ctx.lineTo(q.x,q.y);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
    if(b.st==='fight'&&obHeartOpen(b))worldLabel(b.x,b.y-b.r-16,b.expo>0?'УЗЕЛ ОТКРЫТ · '+Math.ceil(b.expo)+' С':'УЗЕЛ ОТКРЫТ','#ffffff');
    // финал: доки
    if(b.st==='final'&&b.docks&&b.fT>=1)for(const d of b.docks){const x=b.cx+d.ox,y=b.cy,col=d.kind==='fix'?'#7affc9':'#ff4f6e';glow(x,y,46,col,.5);ctx.strokeStyle=col;ctx.lineWidth=2;ctx.setLineDash([5,5]);ctx.lineDashOffset=-t*15;ctx.beginPath();ctx.arc(x,y,34,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;
      worldLabel(x,y-46,d.kind==='fix'?'ВОССТАНОВИТЬ ДО ЗАВОДСКОГО':'СПИСАТЬ СТАНЦИЮ',col);worldLabel(x,y+52,d.kind==='fix'?'ОПЛАТА ЛОМОМ · ПЕРК':'ЛОМ ×2',col);}
    if(b.st==='final'){ctx.strokeStyle='#ffffff';ctx.globalAlpha=.8;ctx.lineWidth=3;ctx.beginPath();ctx.arc(b.cx,b.cy,b.r+24,-Math.PI/2,-Math.PI/2+TAU*(b.timer/20));ctx.stroke();ctx.globalAlpha=1;}
  }}
// ---------- обломки боссов в открытом мире ----------
const SB_WRECK={14:{memory:['ОБЛОМОК КАРТОТЕКИ','Ядро холода разрушено. Записи оттаяли: тридцать одна копия, один почерк. В одной из них рука Э. В. дописала: «ищи третий путь».'],cold:['ОБЛОМОК КАРТОТЕКИ','Ядро памяти сожжено. Вы сожгли 31 себя. Теперь никто не скажет, как именно они ошиблись.']},
  18:{service:['ОБЛОМОК ОБОДА','Заказ закрыт. На листе обшивки — копия списка колонистов «Тихой». Строка 118: «Лоран, сын техника». Список был.'],scrap:['ОБЛОМОК ОБОДА','Станция списана. Кольцо больше не вращается. Автомат обслуживания в мастерской пишет: «следующих не будет».']}};
function sbWreckPos(m){const n=WORLD.nodes[m-1];return {x:n.x+150,y:n.y-120};}
function sbWorldDraw(t){const S=G.save;if(!S||!S.story)return;for(const m of SB_WM85){const ch=S.story[SB_FLAG_M[m]];if(!ch)continue;const q=sbWreckPos(m);if(!inView(q.x,q.y,90))continue;const read=S.story.bwRead&&S.story.bwRead[m];
    ctx.save();ctx.translate(q.x,q.y);ctx.globalAlpha=read?.55:.9;ctx.strokeStyle=m===14?'#9fd8ff':m===22?'#ff6b8a':m===27?'#b8c4d6':m===31?'#e8d27a':m===38?'#6b8cff':m===42?'#ffd36b':m===46?'#7affc9':'#c96a2a';ctx.fillStyle='#0b1220';ctx.lineWidth=2;
    if(m===14){ctx.rotate(.35);ctx.beginPath();ctx.moveTo(-44,-10);ctx.lineTo(-30,-18);ctx.lineTo(20,-18);ctx.lineTo(34,-6);ctx.lineTo(10,16);ctx.lineTo(-40,12);ctx.closePath();ctx.fill();ctx.stroke();ctx.lineWidth=1;for(let i=-3;i<=1;i++){ctx.beginPath();ctx.moveTo(i*11,-16);ctx.lineTo(i*11,12);ctx.stroke();}}
    else{ctx.lineWidth=7;ctx.beginPath();ctx.arc(0,0,34,.3,2.6);ctx.stroke();ctx.beginPath();ctx.arc(0,0,34,3.4,4.9);ctx.stroke();ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,10,0,TAU);ctx.fill();ctx.stroke();}
    ctx.restore();ctx.globalAlpha=1;if(!read)glow(q.x,q.y,40,m===14?'#9fd8ff':'#ffb060',.4+.3*Math.sin(t*3));worldLabel(q.x,q.y-50,SB_WRECK[m][ch]?SB_WRECK[m][ch][0]:'ОБЛОМОК','#9fb0c4');}}
function sbWorldPOI(){const S=G.save,p=G.player;if(!S||!S.story||!p||p.hp<=0)return;for(const m of SB_WM85){const ch=S.story[SB_FLAG_M[m]];if(!ch)continue;const R=S.story.bwRead||(S.story.bwRead={});if(R[m])continue;
    const q=sbWreckPos(m);if(Math.hypot(p.x-q.x,p.y-q.y)<95){R[m]=1;const W_=SB_WRECK[m][ch]||['ОБЛОМОК',''];toast(W_[0],W_[1]+' (+25 лома)');S.lom+=25;sfx('pick');saveWorld();}}}

// ===== 0.5.8: открытый мир секторов III–IV («Холод и ржавчина») =====
// --- инфраструктура ---
function worldSS(x,y){if(!G.world||!G.save)return null;const p=G.player;if(x===undefined){if(!p)return null;x=p.x;y=p.y;}if(!inSectors(x,y))return null;const i=sectorIdx(x,y);return SEC_SCALE[i]||null;}
function SSW(){return secScale()||(G.world?worldSS():null);}
const W58={shelves:[],rust:[],recs:[],beacons:[],zones:[],depot:null,core:null,gen:false};
const W58_NAMES={tug:['ТИХАЯ-ГРУЗ 4','ИНЕЙ-9','ПОСЛЕДНИЙ РЕЙС','КОЛЫБЕЛЬНАЯ','СТАРЫЙ ВАРГ']};
function w58S(){const S=G.save;if(!S)return null;if(!S.w58)S.w58={iceRocks:[],arcRec:[],rustBox:[],arcBeacons:[],tugs:{esc:0,rob:0},wander:{},conveyor:{},packs:{}};const w=S.w58;
  w.iceRocks=w.iceRocks||[];w.arcRec=w.arcRec||[];w.rustBox=w.rustBox||[];w.arcBeacons=w.arcBeacons||[];w.tugs=w.tugs||{esc:0,rob:0};w.wander=w.wander||{};w.conveyor=w.conveyor||{};w.packs=w.packs||{};return w;}
function w58Reset(){G.w={storms:{},tug:null,tugT:40,wander:null,wanderT:0,packs:[],ambush:null,chill:0,chillT:0,onShelf:false,inRust:false,inRain:false,slide:0,wsec:-1,noSpawnT:0,snow:[],rain:[],vis:0,beaconFights:{},digs:null,respT:0};G.event=null;}
function w58After(m){const S=G.save;return !!S&&nodeState(m)==='done';}
function w58SecOpen(i){const S=G.save;return !!S&&S.cleared>=CORE&&S.gate;}
function w58Pt(sec,R,ok,m){m=m||300;const sc=WORLD.sectors[sec],b=sc.box;for(let k=0;k<400;k++){const x=b[0]+m+R()*(b[2]-b[0]-2*m),y=b[1]+m+R()*(b[3]-b[1]-2*m);if(ok(x,y))return {x:Math.round(x),y:Math.round(y)};}return {x:(b[0]+b[2])/2,y:(b[1]+b[3])/2};}
function w58Far(x,y,list,d){return list.every(q=>Math.hypot(q.x-x,q.y-y)>d);}
function w58Gen(){if(W58.gen)return;W58.gen=true;
  const N=WORLD.nodes,pois=[...WORLD.journals,...WORLD.anomalies,...WORLD.shops,...WORLD.caches];
  const nodesOf=s=>N.filter(n=>n.sec===s);const bea=s=>({x:WORLD.sectors[s].bx,y:WORLD.sectors[s].by});
  const placed=[];
  const okAt=(x,y,dn,dp)=>w58Far(x,y,N,dn)&&w58Far(x,y,pois,dp)&&w58Far(x,y,placed,dp)&&w58Far(x,y,[bea(2),bea(3)],dp)&&inSectors(x,y);
  // 61: зоны патрулей
  // 0.5.9: зон 8 → 4 (off — точка выбирается, чтобы генерация мира не сдвинулась, но зона не создаётся); set — пул сопровождения
  const ZS=[[2,10,'ИНЕЙ',['frost','scout','gunner'],['gunner',['fast']],{},0],
    [2,11,'ИНДЕКС',['phantom','gunner','frost'],['phantom',['armor']],{},1],
    [2,12,'КАТАЛОГ',['lancer','frost','archivist'],['shade',['fast']],{},0],
    [2,13,'ХРАНИЛИЩЕ',['hunter','shocker','frost'],['hunter',['armor']],{},1],
    [3,14,'ПРИЧАЛ',['gunner','corroder','scout'],['rammer',['fast','boom']],{},1],
    [3,15,'ВЕРФЬ',['repairer','gunner','rammer'],['hunter',['armor','fast']],{},0],
    [3,16,'ДЕПО',['repairer','lancer','gunner'],['shade',['boom','armor']],{},1],
    [3,17,'СВАЛКА',['shocker','rammer','corroder','repairer'],['hunter',['fast','boom']],{},0]];
  ZS.forEach(([sec,after,name,set,lead,reinf,off],i)=>{const R=mulberry(6100+i*31);const q=w58Pt(sec,R,(x,y)=>okAt(x,y,700,600));placed.push(q);
    if(off)return;const z={x:q.x,y:q.y,req:0,set,w58:1,sec,after,name,lead,reinf,idx:1000+i};WORLD.zones.push(z);W58.zones.push(z);});
  // 62: шельфы
  const R2=mulberry(5101),n11=nodesOf(2);
  for(let i=0;i<6;i++){let q;const r=380+R2()*270,dn=r*1.15+120;
    if(i<2&&n11.length>=3){const a=n11[i],b=n11[i+1];const f=.5;const nx=-(b.y-a.y),ny=(b.x-a.x),l=Math.hypot(nx,ny)||1;const off=(R2()<.5?-1:1)*(dn*.75);q={x:Math.round(a.x+(b.x-a.x)*f+nx/l*off),y:Math.round(a.y+(b.y-a.y)*f+ny/l*off)};const bb=WORLD.sectors[2].box,mg=r*1.15+60;if(!okAt(q.x,q.y,dn,300)||q.x<bb[0]+mg||q.x>bb[2]-mg||q.y<bb[1]+mg||q.y>bb[3]-mg)q=w58Pt(2,R2,(x,y)=>okAt(x,y,dn,500),mg);}
    else q=w58Pt(2,R2,(x,y)=>okAt(x,y,dn,500)&&w58Far(x,y,W58.shelves,900),r*1.15+60);
    const pts=[];for(let k=0;k<14;k++){const a=k/14*TAU,rr=r*(.72+R2()*.4);pts.push({x:q.x+Math.cos(a)*rr,y:q.y+Math.sin(a)*rr});}
    const cracks=[];const nc=6+Math.floor(R2()*4);for(let k=0;k<nc;k++){const a=R2()*TAU,l=[];let cx=q.x+(R2()-.5)*r*.4,cy=q.y+(R2()-.5)*r*.4,ang=a;for(let s=0;s<4;s++){l.push([cx,cy]);cx+=Math.cos(ang)*r*.22;cy+=Math.sin(ang)*r*.22;ang+=(R2()-.5)*1.2;}cracks.push(l);}
    const blinks=[];for(let k=0;k<4+Math.floor(R2()*3);k++)blinks.push({x:q.x+(R2()-.5)*r*1.1,y:q.y+(R2()-.5)*r*1.1,ph:R2()*TAU,per:3+R2()*2});
    const rocks=[];const nr=2+Math.floor(R2()*3);for(let k=0;k<nr;k++){const a=R2()*TAU,d=R2()*r*.6;rocks.push({id:'s'+i+'r'+k,x:Math.round(q.x+Math.cos(a)*d),y:Math.round(q.y+Math.sin(a)*d),r:14+R2()*8,rot:R2()*TAU});}
    W58.shelves.push({id:i,x:q.x,y:q.y,r,pts,cracks,blinks,rocks,rec:false});placed.push(q);}
  // 66: ржавые поля
  const R3=mulberry(5202),n15=nodesOf(3);
  for(let i=0;i<7;i++){let q;
    if(i<3&&n15.length>=3){const a=n15[i],b=n15[i+1];const f=.3+R3()*.4;const px=a.x+(b.x-a.x)*f,py=a.y+(b.y-a.y)*f;const nx=-(b.y-a.y),ny=(b.x-a.x),l=Math.hypot(nx,ny)||1;const off=(R3()<.5?-1:1)*(260+R3()*120);q={x:Math.round(px+nx/l*off),y:Math.round(py+ny/l*off)};const bb=WORLD.sectors[3].box;if(!okAt(q.x,q.y,300,300)||q.x<bb[0]+600||q.x>bb[2]-600||q.y<bb[1]+600||q.y>bb[3]-600)q=w58Pt(3,R3,(x,y)=>okAt(x,y,300,400),600);}
    else q=w58Pt(3,R3,(x,y)=>okAt(x,y,300,400)&&w58Far(x,y,W58.rust,800),600);
    const r=300+R3()*220;const dots=[];for(let k=0;k<12+Math.floor(R3()*9);k++)dots.push({a:R3()*TAU,d:R3(),ph:R3()*TAU});
    const rocks=[];for(let k=0;k<6+Math.floor(R3()*4);k++){const a=R3()*TAU,d=R3()*r*.8;rocks.push({id:'f'+i+'r'+k,x:Math.round(q.x+Math.cos(a)*d),y:Math.round(q.y+Math.sin(a)*d),r:16+R3()*18,rot:R3()*TAU,rust:true});}
    W58.rust.push({id:i,x:q.x,y:q.y,r,dots,rocks,box:false});placed.push(q);}
  W58.rust.slice().sort((a,b)=>b.r-a.r).slice(0,3).forEach(f=>f.box=true);
  // 70: маяки Архива (треугольником, один на краю шельфа)
  const R4=mulberry(5303);const sc2=WORLD.sectors[2].box;
  const corners=[[sc2[0]+700,sc2[1]+700],[sc2[2]-700,sc2[1]+900],[sc2[0]+900,sc2[3]-800]];
  corners.forEach(([cx,cy],i)=>{let q={x:cx,y:cy};if(i===2&&W58.shelves.length){const s=W58.shelves[W58.shelves.length-1];q={x:Math.round(s.x+s.r*1.05),y:Math.round(s.y)};}
    if(!okAt(q.x,q.y,900,500))q=w58Pt(2,R4,(x,y)=>okAt(x,y,900,500));W58.beacons.push({id:'b'+i,x:q.x,y:q.y,seeds:0});placed.push(q);});
  // 72: холодное ядро — дальняя часть III, рядом шельф
  const R5=mulberry(5404);let qc=null,qd=-1;{const b=WORLD.sectors[2].box;for(let k=0;k<600;k++){const x=b[0]+600+R5()*(b[2]-b[0]-1200),y=b[1]+600+R5()*(b[3]-b[1]-1200);if(!okAt(x,y,600,600))continue;const d=Math.min(...N.filter(n=>n.sec===2).map(n=>Math.hypot(n.x-x,n.y-y)));if(d>qd){qd=d;qc={x:Math.round(x),y:Math.round(y)};}}if(!qc)qc=w58Pt(2,R5,(x,y)=>okAt(x,y,600,600));}W58.core={x:qc.x,y:qc.y};placed.push(qc);
  if(!WORLD.anomalies.some(a=>a.id==='a4'))WORLD.anomalies.push({id:'a4',x:qc.x,y:qc.y,kind:'coldcore',name:'ХОЛОДНОЕ ЯДРО',d:'Внутри сферы время врагов идёт вдвое медленнее, но корабль обрастает льдом. За 35 секунд соберите 5 осколков тепла — каждый снимает лёд. Дальше 900 от ядра — провал.'});
  {const r=460,pts=[];for(let k=0;k<14;k++){const a=k/14*TAU,rr=r*(.8+R5()*.3);pts.push({x:qc.x+Math.cos(a)*rr,y:qc.y+Math.sin(a)*rr});}W58.shelves.push({id:6,x:qc.x,y:qc.y,r,pts,cracks:[],blinks:[],rocks:[],rec:false,core:true});}
  // 63: записи — 4 свободно, 1 вморожена в дальний шельф, 1 в ядре
  const R6=mulberry(5505);const far=W58.shelves.slice(0,6).reduce((a,b)=>Math.hypot(b.x-WORLD.sectors[2].bx,b.y-WORLD.sectors[2].by)>Math.hypot(a.x-WORLD.sectors[2].bx,a.y-WORLD.sectors[2].by)?b:a);far.rec=true;
  const RT=[['ЦИКЛ IV · ЗАПИСЬ 0007','Объект 013 вошёл в сектор на скорости сверх эталона. Скорость приведена.','На полях: «Ты всегда летишь слишком быстро. Это хорошо». — Э. В.'],
    ['ЦИКЛ IX · ЗАПИСЬ 0213','Объект 013 отказался от модуля «Щит». Причина не зафиксирована. Цикл завершён на передаче 14.','«Он хотел что-то доказать. Мне или себе».'],
    ['ЦИКЛ XIII · ЗАПИСЬ 0090','Во время сверки объект 013 вышел из кадра и не вернулся в течение 41 с. Копия продолжила маршрут без него.','«Запись не знает, куда ты повернёшь. Помни об этом».'],
    ['ЦИКЛ XX · ЗАПИСЬ 1144','Выбор объекта 013 у маяка: холод. Выбор совпал с эталоном. Отклонений нет.','«Двадцать раз одно и то же. Не будь эталоном».'],
    ['ЦИКЛ XXVII · ЗАПИСЬ 0001','Объект 013 принял сигнал Архива за свой. Принят на хранение.','«Этот цикл я потерял. Прости».'],
    ['ЦИКЛ XXXI · ЗАПИСЬ 4102','Последняя сверка перед циклом XXXII. Объект 013 спросил: «Сколько нас было?» Ответ не предусмотрен.','«Тридцать один. Ты тридцать второй. И единственный, кто спросил».']];
  RT.forEach(([title,text,memo],i)=>{let rec={id:i,title,text,memo,cyc:['IV','IX','XIII','XX','XXVII','XXXI'][i]};
    if(i<4){const q=w58Pt(2,R6,(x,y)=>okAt(x,y,500,500));const Rr=300+R6()*300,b=WORLD.sectors[2].box;Object.assign(rec,{x:clamp(q.x,b[0]+Rr+80,b[2]-Rr-80),y:clamp(q.y,b[1]+Rr+80,b[3]-Rr-80),R:Rr,ph:R6()*TAU,sp:(25+R6()*15)/300,drift:true});placed.push(q);}
    else if(i===4)Object.assign(rec,{x:far.x,y:far.y,frozen:true,drift:false});
    else Object.assign(rec,{x:qc.x,y:qc.y,core:true,drift:false});
    W58.recs.push(rec);});
  // 68: депо у узла 17 (юго-восток)
  const n17=N.find(n=>n.m===17);if(n17){let q={x:n17.x+640,y:n17.y+640};const b=WORLD.sectors[3].box;q.x=clamp(q.x,b[0]+1300,b[2]-1300);q.y=clamp(q.y,b[1]+900,b[3]-900);W58.depot={x:Math.round(q.x),y:Math.round(q.y)};}
}
function w58RecPos(r){if(r.drift){const a=r.ph+G.t*r.sp;return {x:r.x+Math.cos(a)*r.R,y:r.y+Math.sin(a)*r.R*.6};}return {x:r.x,y:r.y};}
function w58InPoly(x,y,pts){let c=false;for(let i=0,j=pts.length-1;i<pts.length;j=i++){const a=pts[i],b=pts[j];if((a.y>y)!==(b.y>y)&&x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x)c=!c;}return c;}
function w58OnShelf(x,y){for(const s of W58.shelves){if(Math.abs(s.x-x)>s.r*1.2||Math.abs(s.y-y)>s.r*1.2)continue;if(w58InPoly(x,y,s.pts))return s;}return null;}
function w58InRust(x,y){for(const f of W58.rust){if(Math.hypot(f.x-x,f.y-y)<f.r)return f;}return null;}
function w58InStorm(x,y){const w=G.w;if(!w)return null;for(const k in w.storms){const s=w.storms[k];if(!s||s.ph==='wait'||s.k<=0)continue;const dx=(x-s.x)/700,dy=(y-s.y)/400;if(dx*dx+dy*dy<1)return s;}return null;}
// --- главный тик мира (после updateEnemies) ---
function secWorldTick(dt){const S=G.save,p=G.player,w=G.w;if(!S||!p||!w)return;w58Gen();const ws=w58S();
  const sec=inSectors(p.x,p.y)?sectorIdx(p.x,p.y):-1;if(sec!==w.wsec){w.wsec=sec;computeStats();if(p.hp>G.st.maxHp)p.hp=G.st.maxHp;}
  if(w.noSpawnT>0)w.noSpawnT-=dt;
  const inW=sec===2||sec===3;
  // шельф и холод
  if(!SSW())G.slick=false;
  const sh=p.hp>0?w58OnShelf(p.x,p.y):null;w.onShelf=!!sh;if(p.dashT>0)w58DashRocks(p);
  if(sh){G.slick=true;G.slickK=2.5;w.chillT+=dt;const sp=Math.hypot(p.vx,p.vy);if(sp>260){w.slide+=sp*dt;if(w.slide>=100){w.slide-=100;conEvent('shelf');}
      if(SET.fx){w.trail=w.trail||[];const a=Math.atan2(p.vy,p.vx),nx=-Math.sin(a)*7,ny=Math.cos(a)*7;w.trail.push({x1:p.x+nx,y1:p.y+ny,x2:p.x-nx,y2:p.y-ny,t:2});if(w.trail.length>40)w.trail.shift();}}}
  else G.slickK=undefined;
  const snow=w58InStorm(p.x,p.y);const cold=!!sh||(snow&&snow.kind==='snow');
  if(cold){if(!sh)w.chillT+=dt;w.chill=Math.min(1,w.chill+dt*.5);}else{w.chill=Math.max(0,w.chill-dt/1.5);w.chillT=0;}
  if(w.chillT>4&&!w.iced){w.iced=true;floater(p.x,p.y-30,'ОБЛЕДЕНЕНИЕ','#bfe8ff');}
  if(w.iced&&(p.dashT>0||!cold||w.pulsed)){w.iced=false;w.chillT=Math.min(w.chillT,0);if(SET.fx)for(let i=0;i<10;i++)part(p.x,p.y,rnd(-120,120),rnd(-120,120),.4,'#ffffff',2);}
  w.pulsed=0;G.chillK=w.iced?.92:1;G.chillD=w.iced?1.15:1;
  if(w.trail)for(const q of w.trail)q.t-=dt;if(w.trail)w.trail=w.trail.filter(q=>q.t>0);
  // ржавые поля и дождь
  const rf=p.hp>0?w58InRust(p.x,p.y):null;w.inRust=!!rf;const rain=snow&&snow.kind==='rain';w.inRain=!!rain;
  const cap=G.st.maxHp0*(storyFlag('factory')?.10:.15);
  if(rf){const k=(w.boxing?2:1)*(storyFlag('obod18')==='scrap'?.5:1);if((G.wear||0)<cap)addWear(G.st.maxHp0*.01*dt/5*k);if(!w.rustHint){w.rustHint=1;floater(p.x,p.y-30,'РЖАВОЕ ПОЛЕ · ИЗНОС КОРПУСА','#c96a2a');}G.shieldPen=Math.max(G.shieldPen||0,.2);}
  if(rain){const rcap=Math.min(cap,(w.rainW0!==undefined?w.rainW0:(w.rainW0=G.wear||0))+G.st.maxHp0*.05);if((G.wear||0)<rcap)addWear(G.st.maxHp0*.01*dt/10);G.shieldPen=Math.max(G.shieldPen||0,.2);}else w.rainW0=undefined;
  if(!rf&&!rain&&(G.wear||0)>0&&p.hp>0){w.wearDec=(w.wearDec||0)+dt;if(w.wearDec>=20){w.wearDec-=20;addWear(-G.st.maxHp0*.01);}}
  for(const e of G.enemies){if(!e.alive||!e.secArm)continue;if(e.type!=='corroder'&&e.type!=='rustcopy'&&w58InRust(e.x,e.y))e.noArm=Math.max(e.noArm||0,.2);}
  // системы
  w58StormTick(dt,sec);w58ZonesTick(dt);w58RecTick(dt);w58BeaconTick(dt);w58WanderTick(dt,sec);w58PackTick(dt,sec);w58TugTick(dt,sec);w58DigTick(dt);w58ShelfRocks(dt);
  G.calm=G.event?0:G.calm;
  if(G.cruise){const k=snow&&snow.kind==='snow'?1.5/1.75:1;w.cruiseK=k;}
}
// --- 61: патрули III–IV ---
function w58Quiet(x,y){// 0.5.9: тихие зоны — патрули не активируются рядом с Бездной, узлами, мастерскими, Хранилищем, маяками секторов и во время аномалий
  if(G.anom)return true;const A=WORLD.abyss;if(Math.hypot(x-A.x,y-A.y)<1500)return true;
  for(const n of WORLD.nodes)if(Math.hypot(x-n.x,y-n.y)<1000)return true;
  for(const q of WORLD.shops)if(Math.hypot(x-q.x,y-q.y)<600)return true;
  if(Math.hypot(x-WORLD.hangar.x,y-WORLD.hangar.y)<600)return true;if(Math.hypot(x-WORLD.arsenal.x,y-WORLD.arsenal.y)<600)return true;
  for(const sc of WORLD.sectors)if(sc.bx&&Math.hypot(x-sc.bx,y-sc.by)<600)return true;return false;}
function w58ZoneReady(z){return (ALPHA_OPEN/* ВРЕМЕННО (альфа 0.7.4): мир открыт целиком — патрули III–IV не ждут прохождения своих узлов */||w58After(z.after))&&!(G.w&&G.w.noSpawnT>0)&&!(G.event&&G.event!=='zone'&&G.event!=='beacon')&&!w58Quiet(G.player.x,G.player.y)&&!W58.zones.some(q=>q.active&&q!==z);}// 0.5.9: не больше одного патруля одновременно
function w58RollEsc(){const r=Math.random();return r<.3?1:r<.7?2:3;}// 0.5.9: 1–3 сопровождающих (30/40/30) + вожак = 2–4
function w58ZonesTick(dt){const S=G.save,p=G.player,w=G.w;
  for(const z of W58.zones){if(z.cool>0)z.cool-=dt;const d=Math.hypot(p.x-z.x,p.y-z.y);const st=w58InStorm(z.x,z.y);const actR=st&&st.kind==='snow'?450:800;
    if(!z.active){if(z.cool<=0&&d<actR&&p.hp>0&&w58ZoneReady(z)){z.active=true;z.n=0;z.leader=null;z.reinf=z.reinf||{};z.reinfDone=false;z.leadFirst=false;z.killed=0;z.t=0;
        if(z.k74)w74ZoneSpawn(z);else{{const pool=z.set.slice(),ne=w58RollEsc();for(let i=0;i<ne;i++){if(!pool.length)pool.push(...z.set);const t=pool.splice(Math.floor(Math.random()*pool.length),1)[0];const e=spawnEnemy(t,z.x+rnd(-220,220),z.y+rnd(-220,220),{spawnT:.7,zone:z,noAffix:true});if(e){e.hp*=PATROL_HP_K;e.maxHp=e.hp;}z.n++;}}
        const L=spawnEnemy(z.lead[0],z.x+rnd(-120,120),z.y+rnd(-120,120),{spawnT:.7,zone:z,noAffix:true});L.affix=z.lead[1].slice();if(L.affix.includes('armor'))L.armor=3;if(L.affix.includes('fast'))L.spd*=1.35;L.leader=true;L.hp*=PATROL_HP_K*1.5;L.maxHp=L.hp;z.leader=L;z.n++;}
        G.event=G.event||'zone';floater(p.x,p.y-40,'ПАТРУЛЬ · '+z.name,'#ff4f6e');sfx('warn');
        const ws=w58S();const rk=z.k80?'radioZ'+z.k80:z.k74?'radioZ'+z.k74:z.z80g?'radioZg'+z.sec:z.sec===2?'radioZ3':'radioZ4';if(!ws[rk]){ws[rk]=1;if(z.k74)w74ZoneRadio(z);else if(z.z80g)w80ZoneRadio(z);else radioLine(z.sec===2?'АРХИВ':'ОБОД',z.sec===2?'#9fd8ff':'#ffb060',z.sec===2?'Объект вне каталога. Высылаю сверку.':'Выездная бригада направлена. Клиент не обслуживается.',.4);}}}
    else{z.t+=dt;const mine=G.enemies.filter(e=>e.alive&&e.zone===z);const left=mine.length;
      if(z.leader&&z.leader.alive){for(const e of mine)if(e!==z.leader&&Math.hypot(e.x-z.leader.x,e.y-z.leader.y)<400)e.buff=Math.max(e.buff||1,1.15);}
      else if(z.leader&&!z.ldChk){z.ldChk=true;z.leadFirst=(z.n-left)<=1;}
      if(false&&!z.reinfDone&&z.leader&&z.leader.alive&&left<=Math.ceil(z.n*.5)&&left>0){z.reinfDone=true;/* 0.5.9: подкрепление патрулей убрано */const a=Math.atan2(p.y-z.y,p.x-z.x)+Math.PI;
        for(const [t,c] of Object.entries(z.reinf))for(let i=0;i<c;i++){const x=clamp(z.x+Math.cos(a+rnd(-.5,.5))*700,20,WW-20),y=clamp(z.y+Math.sin(a+rnd(-.5,.5))*700,20,WH-20);G.warns.push({x,y,t:1.2,type:t,zone:z});}}
      if(left===0&&z.k74&&w74ZoneDone(z)){}
      else if(left===0){z.active=false;const first=!S.zonesDone['w'+z.idx];z.cool=first?900:1200;const mul=z.sec>=6?3:z.sec===2?1.5:2;let v=Math.round((first?10+z.n*3:3)*mul);if(z.leadFirst)v=Math.round(v*1.25);S.zonesDone['w'+z.idx]=1;S.carry+=v;if(first)addPilotXP(z.sec===2?15:20);
        floater(p.x,p.y-40,'ПАТРУЛЬ РАЗБИТ · +'+v+' ЛОМА'+(first?'':' · ПОВТОР')+(z.leadFirst?' · ВОЖАК ПЕРВЫМ':''),'#c9d2de');sfx('level');conEvent('patrol');conEvent('patrol');if(z.leadFirst)conEvent('patrolLeader');if(G.event==='zone')G.event=null;}
      else if(d>1800){G.enemies.forEach(e=>{if(e.zone===z)e.alive=false;});z.active=false;z.cool=120;if(G.event==='zone')G.event=null;}}}
  if(G.event==='zone'&&!W58.zones.some(z=>z.active))G.event=null;
  // подкрепление из предупреждений
  for(let i=G.warns.length-1;i>=0;i--){const q=G.warns[i];if(!q.zone)continue;q.t-=dt;if(q.t<=0){G.warns.splice(i,1);const e=spawnEnemy(q.type,q.x,q.y,{spawnT:.3,zone:q.zone,noAffix:true});q.zone.n++;}}
}
// --- 62: вмёрзшие обломки ---
function w58ShelfRocks(dt){}
function w58IceRockHit(b,charged){const ws=w58S();for(const s of W58.shelves)for(const r of s.rocks){if(ws.iceRocks.includes(r.id))continue;if(Math.hypot(b.x-r.x,b.y-r.y)<r.r+6){if(!charged){b.life=0;if(SET.fx)part(b.x,b.y,rnd(-40,40),rnd(-40,40),.2,'#bfe8ff',2);return true;}w58IceRockBreak(r,s);return true;}}return false;}
function w58IceRockBreak(r,s){const ws=w58S();if(ws.iceRocks.includes(r.id))return;ws.iceRocks.push(r.id);explode(r.x,r.y,'#bfe8ff',16,.8);for(let i=0;i<3;i++)G.pick.push({k:'lom',x:r.x+rnd(-10,10),y:r.y+rnd(-10,10),vx:rnd(-80,80),vy:rnd(-80,80),r:5,t:0,life:30,v:1});
  if(s.rec){const rec=W58.recs.find(q=>q.frozen);if(rec&&!ws.arcRec.includes(rec.id)){rec.frozen=false;rec.drift=false;rec.x=r.x;rec.y=r.y-30;floater(r.x,r.y-24,'ЗАПИСЬ ОСВОБОЖДЕНА','#bfe8ff');}}
  sfx('boom');}
function w58RustRockHit(b,charged){const S=G.save;if(!S)return false;for(const f of W58.rust){if(Math.abs(f.x-b.x)>f.r+60||Math.abs(f.y-b.y)>f.r+60)continue;for(const r of f.rocks){if(S.rocksGone&&S.rocksGone.includes(r.id))continue;if(Math.hypot(b.x-r.x,b.y-r.y)<r.r+(b.r||4)){r.hp=(r.hp===undefined?(r.r>25?60:25):r.hp)-b.dmg;if(!charged)b.life=0;if(SET.fx)part(b.x,b.y,rnd(-60,60),rnd(-60,60),.2,'#8a5a3a',2);
        if(r.hp<=0){if(S.rocksGone&&!S.rocksGone.includes(r.id))S.rocksGone.push(r.id);explode(r.x,r.y,'#8a5a3a',14,.8);const n=(r.r>25?2:1)*2;for(let i=0;i<n;i++)G.pick.push({k:'lom',x:r.x+rnd(-10,10),y:r.y+rnd(-10,10),vx:rnd(-80,80),vy:rnd(-80,80),r:5,t:0,life:30,v:1});sfx('boom');}return true;}}}return false;}
function w58DashRocks(p){if(!G.world||p.dashT<=0)return;for(const s of W58.shelves)for(const r of s.rocks){if(w58S().iceRocks.includes(r.id))continue;if(segDist(p.px,p.py,p.x,p.y,r.x,r.y)<r.r+p.r)w58IceRockBreak(r,s);}}
// --- 69: бури ---
function w58StormTick(dt,sec){const w=G.w,S=G.save,p=G.player;
  for(const k of [2,3]){let s=w.storms[k];if(!s){const ws=w58S();const first=!ws['storm'+k];s=w.storms[k]={sec:k,kind:k===2?'snow':'rain',ph:'wait',t:first?180:60+Math.random()*60,k:0,x:0,y:0,warned:false};}
    const playerIn=sec===k;if(!playerIn&&s.ph==='wait')continue;
    s.t-=dt;
    if(s.ph==='wait'){if(!s.warned&&s.t<=20&&playerIn&&!G.anom){s.warned=true;radioLine('МЕТЕО','#9fb0c4',k===2?'Снежный фронт входит в сектор с запада. Видимость упадёт.':'Ржавый дождь с севера. Берегите щит.',0);}
      if(s.t<=0){if(G.anom||G.event==='conv'){s.t=15;continue;}const b=WORLD.sectors[k].box;const side=Math.random()<.5?0:1;if(k===2){s.x=b[0]+200;s.y=b[1]+800+Math.random()*(b[3]-b[1]-1600);s.dir=0;if(Math.hypot(s.x-WORLD.abyss.x,s.y-WORLD.abyss.y)<2000)s.y=b[1]+800;}else{s.x=b[0]+800+Math.random()*(b[2]-b[0]-1600);s.y=b[1]+200;s.dir=Math.PI/2;}
        s.ph='born';s.t=20;s.k=0;s.warned=false;s.box=null;w58S()['storm'+k]=1;}}
    else if(s.ph==='born'){s.k=Math.min(1,1-s.t/20);if(s.t<=0){s.ph='move';s.t=90;s.k=1;s.box={got:false};}}
    else if(s.ph==='move'){const b=WORLD.sectors[k].box;if(!(s.dir>-1e9))s.dir=0;s.dir+=(Math.random()-.5)*dt*.3;s.x+=Math.cos(s.dir)*40*dt;s.y+=Math.sin(s.dir)*40*dt;s.x=clamp(s.x,b[0]+300,b[2]-300);s.y=clamp(s.y,b[1]+300,b[3]-300);
      if(G.anom){const a=G.anom.a;const dx=s.x-a.x,dy=s.y-a.y,d=Math.hypot(dx,dy)||1;if(d<1300){s.x+=dx/d*60*dt;s.y+=dy/d*60*dt;}}
      {const A=WORLD.abyss,dx=s.x-A.x,dy=s.y-A.y,d=Math.hypot(dx,dy)||1;if(d<2000){s.x+=dx/d*80*dt;s.y+=dy/d*80*dt;s.dir=Math.atan2(dy,dx);}}// 0.5.9: бури обходят Бездну
      if(s.t<=0){s.ph='fade';s.t=20;}}
    else if(s.ph==='fade'){s.k=Math.max(0,s.t/20);if(s.t<=0){s.ph='wait';s.t=60+Math.random()*60;s.k=0;s.box=null;}}
    // груз в центре
    if(s.box&&!s.box.got&&(s.ph==='move'||s.ph==='fade')&&p.hp>0&&Math.hypot(p.x-s.x,p.y-s.y)<60){s.box.got=true;const v=k===2?30:40;S.carry+=v;if(k===2)dropCell(s.x,s.y,0);floater(p.x,p.y-30,(k===2?'ЗАМЁРЗШИЙ ГРУЗ':'СМЫТЫЙ КОНТЕЙНЕР')+' · +'+v+' ЛОМА','#ffb84d');sfx('level');conEvent('stormBox');
      if(k===3&&!s.box.guards){s.box.guards=1;}}
    if(s.box&&!s.box.got&&k===3&&!s.box.guards&&s.ph==='move'&&playerIn&&Math.hypot(p.x-s.x,p.y-s.y)<700){s.box.guards=1;for(let i=0;i<2;i++)w58SpawnCopy(s.x+rnd(-80,80),s.y+rnd(-80,80),null);}
  }
}
function w58Hidden(e){const w=G.w;if(!w)return false;const p=G.player;if(!p)return false;const s=w58InStorm(e.x,e.y);if(!s||s.kind!=='snow')return false;return Math.hypot(e.x-p.x,e.y-p.y)>420*(2-s.k);}
function w58NoFire(x,y){if(!G.world||!G.w)return false;const s=w58InStorm(x,y);if(!s||s.kind!=='snow')return false;const p=G.player;return p&&Math.hypot(x-p.x,y-p.y)>420;}

// --- 63: дрейфующие записи ---
function w58RecText(r){const ws=w58S(),ch=storyFlag('inv14');let t=r.text;if(ch==='cold')t=t.split(' ').map((w,i)=>i%3===2?'░░░':w).join(' ');if(ch==='memory')t+=' '+r.memo;return t;}
function w58RecTick(dt){const ws=w58S(),p=G.player,S=G.save;if(!w58SecOpen()||p.hp<=0)return;
  for(const r of W58.recs){if(ws.arcRec.includes(r.id)||r.frozen||r.core&&!(G.anom&&G.anom.a.kind==='coldcore'&&G.anom.t>=20&&G.anom.t<30))continue;
    const q=w58RecPos(r);const d=Math.hypot(p.x-q.x,p.y-q.y);
    if(r.drift&&d<240&&d>60&&p.dashT<=0){r.esc=(r.esc||0)+dt;const a=Math.atan2(q.y-p.y,q.x-p.x);r.x+=Math.cos(a)*60*dt;r.y+=Math.sin(a)*60*dt;const b=WORLD.sectors[2].box;r.x=clamp(r.x,b[0]+300,b[2]-300);r.y=clamp(r.y,b[1]+300,b[3]-300);}
    if(d<60){ws.arcRec.push(r.id);const v=storyFlag('inv14')==='cold'?30:15;S.lom+=v;conEvent('arcRec');const n=ws.arcRec.length;toast(r.title,w58RecText(r)+` (ЗАПИСЬ ${n}/6 · +${v} ЛОМА · J — бортжурнал)`);sfx('pick');explode(q.x,q.y,'#bfe8ff',10,.6);
      if(n>=6&&S.story&&!S.story.arcAll){S.story.arcAll=1;addPilotXP(60);banner('КАТАЛОГ ЦИКЛОВ СОБРАН','+60 ОПЫТА ПИЛОТА · ЗАПИСЬ В ХРОНИКЕ');radioLine('Э. В.','#ffd36b','Теперь ты знаешь их поимённо.',2);}
      saveWorld();}
    if(d<1200)r.seen=true;}
}
// --- 70: радиомаяки Архива ---
function w58BeaconDead(){return w58S().arcBeacons.length>=3;}
function w58BeaconTick(dt){const ws=w58S(),p=G.player,w=G.w;if(!w58After(11)||p.hp<=0||w.noBeacons)return;
  for(const b of W58.beacons){if(ws.arcBeacons.includes(b.id))continue;const d=Math.hypot(p.x-b.x,p.y-b.y);const F=w.beaconFights[b.id]||(w.beaconFights[b.id]={hp:900,guards:[],regen:0,scanT:6,ring:null,active:false,ghosts:false});
    b.F=F;
    if(!F.active){if(d<1000&&w58ZoneReady({after:11})){F.active=true;F.regen=0;if(!F.guards.some(g=>g.alive)){F.guards=[];[['frost',0],['guard',1],['frost',2]].forEach(([t,i])=>{const a=i/3*TAU,e=spawnEnemy(t,b.x+Math.cos(a)*150,b.y+Math.sin(a)*150,{spawnT:.7,noAffix:true,beacon:b.id});F.guards.push(e);});}G.event=G.event||'beacon';}
      else{if(F.guards.length&&!F.guards.some(g=>g.alive)){F.regen+=dt;if(F.regen>=60){F.guards=[];F.regen=0;}}continue;}}
    if(d>2000){F.active=false;G.enemies.forEach(e=>{if(e.beacon===b.id)e.alive=false;});F.guards=[];F.regen=0;if(G.event==='beacon')G.event=null;continue;}
    const shielded=F.guards.some(g=>g.alive);F.shield=shielded;
    if(!shielded&&!F.ghosts){F.ghosts=true;for(let i=0;i<2;i++){const a=rnd(0,TAU);spawnEnemy('phantom',p.x+Math.cos(a)*700,p.y+Math.sin(a)*700,{spawnT:.5,noAffix:true,beacon:b.id});}floater(b.x,b.y-50,'КУПОЛ СНЯТ · ПРИЗРАКИ','#9fd8ff');}
    F.scanT-=dt;if(F.scanT<=0){F.scanT=6;F.ring={r:0,t:0};}
    if(F.ring){F.ring.r+=600*dt;F.ring.t+=dt;if(!F.ring.hit&&Math.abs(Math.hypot(p.x-b.x,p.y-b.y)-F.ring.r)<24&&p.dashT<=0&&p.hp>0){F.ring.hit=true;G.w.chillT=Math.max(G.w.chillT,2);addIce(1);floater(p.x,p.y-28,'ОБНАРУЖЕН','#9fd8ff');if(w.wander&&w.wander.alive&&Math.hypot(w.wander.x-p.x,w.wander.y-p.y)<2500)w.wander.mark=8;}if(F.ring.r>900)F.ring=null;}
    if(F.hp<=0){ws.arcBeacons.push(b.id);G.enemies.forEach(e=>{if(e.beacon===b.id)e.alive=false;});explode(b.x,b.y,'#9fd8ff',40,1.4);sfx('bigboom');G.save.lom+=35;revealAround(b.x,b.y,1500);const n=ws.arcBeacons.length;banner('МАЯК АРХИВА УНИЧТОЖЕН · '+n+'/3','+35 ЛОМА · КАРТА РАСКРЫТА');conEvent('arcBeacon');if(G.event==='beacon')G.event=null;
      if(n>=3){G.save.lom+=100;addPilotXP(50);if(G.save.story)G.save.story.arcSilence=1;radioLine('ИНВЕНТАРИЗАТОР','#9fd8ff','Связь с сектором ░░░ потеряна. Объект 013 ░░░ вне каталога.',1);setTimeout(()=>banner('АРХИВ ОГЛОХ','+100 ЛОМА · +50 ОПЫТА · ЛОМ СЕКТОРА III ×1,25'),2800);}
      saveWorld();}}
}
function w58BeaconHit(b,charged){if(!w58After(11))return false;const ws=w58S();for(const bc of W58.beacons){if(ws.arcBeacons.includes(bc.id))continue;const F=bc.F;if(!F||!F.active)continue;
    if(Math.hypot(b.x-bc.x,b.y-bc.y)<34+(b.r||4)){if(F.shield){b.life=0;sfx('block');if(SET.fx)part(b.x,b.y,rnd(-60,60),rnd(-60,60),.2,'#bfe8ff',2);return true;}F.hp-=b.dmg;F.flash=.08;if(!charged)b.life=0;sfx('hit');return true;}}return false;}
// --- 67: Архиватор-блуждатель ---
function w58WanderTick(dt,sec){const w=G.w,ws=w58S(),p=G.player;if(!w58After(12))return;
  if(w.wanderT>0)w.wanderT-=dt;
  const e=w.wander;if(e&&!e.alive){w.wander=null;return;}
  if(e){const A=WORLD.abyss,dx=e.x-A.x,dy=e.y-A.y,d=Math.hypot(dx,dy)||1;if(d<1500){e.x=A.x+dx/d*1500;e.y=A.y+dy/d*1500;}}// 0.5.9: блуждатель не подходит к Бездне
  if(!e){if(w.wanderT>0||(G.event&&G.event!=='zone'&&G.event!=='beacon'))return;const ns=WORLD.nodes.filter(n=>n.sec===2);const far=ns.filter(n=>Math.hypot(n.x-p.x,n.y-p.y)>2200);if(!far.length)return;const n=far[Math.floor(Math.random()*far.length)];
    const b=WORLD.sectors[2].box;const sx=clamp(n.x+600,b[0]+200,b[2]-200),sy=clamp(n.y+300,b[1]+200,b[3]-200);const a=spawnEnemy('archivist',sx,sy,{noAffix:true,wander:true,spawnT:.5});a.hp*=3;a.maxHp=a.hp;a.affix=['screen'];a.r*=1.25;a.wst='roam';a.wt=0;a.wnode=n;a.cd=0;a.recCd=0;w.wander=a;
    for(let i=0;i<2;i++){const f=spawnEnemy('frost',a.x+rnd(-60,60),a.y+rnd(-60,60),{noAffix:true,spawnT:.5});f.escortOf=a;f.orb=i*Math.PI;}return;}
  if(e.escortOf)return;
  for(const f of G.enemies){if(f.escortOf===e&&f.alive&&e.alive){const a=f.orb+G.t*.8;const tx=e.x+Math.cos(a)*200,ty=e.y+Math.sin(a)*200;if(Math.hypot(p.x-f.x,p.y-f.y)>900){f.x+=(tx-f.x)*Math.min(1,dt*2);f.y+=(ty-f.y)*Math.min(1,dt*2);}}}
  // засада
  const A=w.ambush;if(A){A.t-=dt;if(A.t<=0||sec!==2)w.ambush=null;else{const pts=[...WORLD.nodes.filter(n=>n.sec===2),...W58.shelves,...W58.recs.map(w58RecPos),...W58.beacons];
      for(const q of pts){if(Math.hypot(p.x-q.x,p.y-q.y)<300){w.ambush=null;const n=w58BeaconDead()?1:2;for(let i=0;i<n;i++)w58AmbushCopy(q,A.path,i);floater(p.x,p.y-40,'ЗАСАДА · ЗАПИСЬ ПРЕЖНЕГО МАРШРУТА','#8fd8ff');sfx('warn');break;}}}}
}
function w58AmbushCopy(q,path,i){const p=G.player;const ox=q.x-path[0].x+rnd(-80,80),oy=q.y-path[0].y+rnd(-80,80);const pth=path.map(s=>({x:s.x+ox,y:s.y+oy,t:s.t}));
  const c=spawnEnemy('icecopy',pth[0].x,pth[0].y,{path:pth,pt:0,noAffix:true,noLoot:true,spawnT:.4,fire:true,frate:Math.max(.5,G.st.rate*2)*atkK(),fdmg:clamp(G.st.dmg*.5,6,22),skin:curSkin()});c.contact=14;}
function w58WanderAI(e,dt,c){const p=G.player,w=G.w;const d=c.d;e.wt+=dt;
  if(e.st==='rec'){e.timer-=dt;e.bx=p.x;e.by=p.y;e.vx*=.9;e.vy*=.9;
    if(e.hp<=e.recHp-e.maxHp*.25||recBeamHit(e)){e.st='seek';e.wst='flee';e.wt=0;e.recCd=6;floater(e.x,e.y-20,'ЗАПИСЬ ПРЕРВАНА','#8fd8ff');sfx('block');}
    else if(e.timer<=0){e.st='seek';e.wst='flee';e.wt=0;e.recCd=12;const log=G.posLog.filter(q=>G.t-q.t<=3);if(log.length>=4){w.ambush={t:180,path:log.map(q=>({x:q.x,y:q.y,t:q.t-log[0].t}))};floater(e.x,e.y-20,'ЗАПИСЬ ПРИНЯТА · ЗАСАДА ВПЕРЕДИ','#8fd8ff');}}
    return;}
  e.recCd=Math.max(0,(e.recCd||0)-dt);if(e.mark>0)e.mark-=dt;
  if(e.wst==='roam'){if(d<1400||e.mark>0){e.wst='watch';e.wt=0;if(!e.seenOnce){e.seenOnce=1;radioLine('АРХИВ','#9fd8ff','Объект 013 в поле зрения. Сверка возможна.',.3);}w58S().wander.seen={x:Math.round(e.x),y:Math.round(e.y)};}
    const n=e.wnode;if(!n||Math.hypot(n.x-e.x,n.y-e.y)<560){const ns=WORLD.nodes.filter(q=>q.sec===2&&q!==e.wnode);e.wnode=ns[Math.floor(Math.random()*ns.length)];}
    const tx=e.wnode.x,ty=e.wnode.y;steer(e,tx-e.x,ty-e.y,70,dt,2);if(e.hp<e.maxHp)e.hp=Math.min(e.maxHp,e.hp+e.maxHp/30*dt);return;}
  if(d>2200){e.wst='roam';return;}
  if(e.wst==='flee'){const a=Math.atan2(e.y-p.y,e.x-p.x);steer(e,Math.cos(a),Math.sin(a),G.st.speed*.85,dt,3);if(e.wt>5)e.wst='watch';return;}
  // watch
  if(d<300){e.wst='flee';e.wt=0;return;}
  const m=clamp((d-700)/100,-1,1);steer(e,c.ux*m-c.uy*.5*e.dir,c.uy*m+c.ux*.5*e.dir,e.spd,dt,3);if(Math.random()<dt*.2)e.dir*=-1;
  if(d<800&&e.recCd<=0&&p.hp>0&&onScreen(e)){e.st='rec';e.timer=w58BeaconDead()?5:3.5;e.recHp=e.hp;e.bx=p.x;e.by=p.y;sfx('warn');}
}
function w58WanderDied(e){const w=G.w,ws=w58S(),S=G.save;w.wander=null;w.wanderT=600;w.ambush=null;G.enemies.forEach(f=>{if(f.escortOf===e)f.alive=false;});
  const first=!ws.wander.killed;ws.wander.killed=(ws.wander.killed||0)+1;const v=first?60:30;for(let i=0;i<v;i++)G.pick.push({k:'lom',x:e.x+rnd(-20,20),y:e.y+rnd(-20,20),vx:rnd(-120,120),vy:rnd(-120,120),r:5,t:0,life:30,v:1});
  dropCell(e.x,e.y,0);dropCell(e.x+10,e.y,0);addPilotXP(25);conEvent('wander');floater(e.x,e.y-30,'СТРАНСТВУЮЩИЙ АРХИВАТОР УНИЧТОЖЕН · +'+v,'#8fd8ff');
  if(first){const r=W58.recs.find(q=>!ws.arcRec.includes(q.id)&&q.drift);if(r){r.drift=false;r.x=e.x;r.y=e.y+40;}}}
// --- 73: стаи ржавых копий ---
function w58SpawnCopy(x,y,pack){const c=spawnEnemy('rustcopy',x,y,{noAffix:true,noLoot:true,spawnT:.8,skin:COPY_SKINS[Math.floor(Math.random()*COPY_SKINS.length)],pack});c.hp=c.maxHp=220;c.secArm=.19;c.spd=Math.min(150*1.45,G.st.speed*1.10);c.cd=rnd(.5,1.5);return c;}
function w58PackTick(dt,sec){const w=G.w,S=G.save,p=G.player;if(!w58After(18)||w.noPacks)return;const ch=storyFlag('obod18');const nP=ch==='service'?3:2;
  while(w.packs.length<nP){const f=W58.rust[Math.floor(Math.random()*W58.rust.length)];w.packs.push({x:f.x+rnd(-100,100),y:f.y+rnd(-100,100),st:'roam',t:rnd(20,40),tgt:null,ships:[],dead:0,hostile:ch!=='service',hostT:0,uid:++G.uid});}
  for(const P of w.packs){
    if(P.dead>0){P.dead-=dt;if(P.dead<=0){const f=W58.rust[Math.floor(Math.random()*W58.rust.length)];Object.assign(P,{x:f.x,y:f.y,st:'roam',t:20,ships:[],hostile:ch!=='service',hostT:0});}continue;}
    if(P.hostT>0){P.hostT-=dt;if(P.hostT<=0&&ch==='service'){P.hostile=false;}}
    const live=P.ships.filter(e=>e.alive);
    if(!live.length&&P.ships.length){P.ships=[];P.dead=900;const pk=w58S().packs;pk.n=(pk.n||0)+1;const v=pk.n<=2?(ch==='service'?30:45):(ch==='service'?15:20);S.carry+=v;addPilotXP(15);floater(p.x,p.y-40,'СТАЯ РАЗБИТА · +'+v+' ЛОМА','#c96a2a');sfx('level');if(ch==='service'&&!w58S().packs.evWarn){w58S().packs.evWarn=1;radioLine('Э. В.','#ffd36b','Ты стреляешь в тех, кто тебе доверял.',1);}continue;}
    const d=Math.hypot(p.x-P.x,p.y-P.y);
    if(!P.ships.length){if(d<1600&&sec===3&&w.noSpawnT<=0&&!(G.event&&G.event!=='zone')){for(let i=0;i<3;i++){const c=w58SpawnCopy(P.x+rnd(-60,60),P.y+rnd(-60,60),P);c.peace=!P.hostile;c.contact=c.peace?0:12;P.ships.push(c);}}
      else{// абстрактное движение
        if(P.st==='roam'){P.t-=dt;if(P.t<=0){P.tgt=W58.rust[Math.floor(Math.random()*W58.rust.length)];P.st='go';}}
        else{const dx=P.tgt.x-P.x,dy=P.tgt.y-P.y,l=Math.hypot(dx,dy);if(l<40){P.st='roam';P.t=rnd(20,40);}else{P.x+=dx/l*90*dt;P.y+=dy/l*90*dt;}}}
      continue;}
    // корабли есть: центр = средняя точка
    P.x=live.reduce((a,e)=>a+e.x,0)/live.length;P.y=live.reduce((a,e)=>a+e.y,0)/live.length;
    if(d>2400||sec!==3){P.ships.forEach(e=>e.alive=false);P.ships=[];continue;}
    for(const e of live){e.peace=!P.hostile;e.contact=e.peace?0:12;}
  }
}
function w58CopyAI(e,dt,c){const p=G.player,P=e.pack;const d=c.d;
  if(e.peace){// мирная: летит рядом, стреляет по врагам игрока
    const a=(e.uid%7)/7*TAU+G.t*.5;const tx=p.x+Math.cos(a)*400,ty=p.y+Math.sin(a)*400;steer(e,tx-e.x,ty-e.y,e.spd,dt,2.5);
    e.cd-=dt;if(e.cd<=0){e.cd=rnd(1.2,1.6);let best=null,bd=400;for(const o of G.enemies){if(!o.alive||o===e||o.type==='rustcopy'||o.peace||o.spawnT>0||o.tug)continue;const q=Math.hypot(o.x-e.x,o.y-e.y);if(q<bd){bd=q;best=o;}}
      if(best){const a2=Math.atan2(best.y-e.y,best.x-e.x);G.pb.push({x:e.x,y:e.y,px:e.x,py:e.y,vx:Math.cos(a2)*600,vy:Math.sin(a2)*600,dmg:4,pierce:0,rico:0,life:.9,hit:[e],turret:true});}}
    return;}
  if(e.hp<e.maxHp*.4&&!e.retreating){e.retreating=true;e.rf=W58.rust.reduce((a,b)=>Math.hypot(b.x-e.x,b.y-e.y)<Math.hypot(a.x-e.x,a.y-e.y)?b:a);}
  if(e.retreating){const f=e.rf;steer(e,f.x-e.x,f.y-e.y,e.spd,dt,3);if(Math.hypot(f.x-e.x,f.y-e.y)<f.r*.6){e.hp=Math.min(e.maxHp*.8,e.hp+10*dt);if(e.hp>=e.maxHp*.8)e.retreating=false;}return;}
  const m=clamp((d-450)/150,-1,1);const spread=((e.uid%3)-1)*.6;steer(e,c.ux*m-c.uy*spread,c.uy*m+c.ux*spread,e.spd,dt,3);
  e.cd-=dt;if(e.cd<=0&&onScreen(e)&&p.hp>0&&d<900){e.cd=rnd(1.2,1.6)*atkK();const a=Math.atan2(p.y+p.vy*.2-e.y,p.x+p.vx*.2-e.x);const q=shootE(e.x+Math.cos(a)*14,e.y+Math.sin(a)*14,a,430,8,'#ffb060',4);if(q)q.copy=true;}
}
function w58CopyHurt(e){const P=e.pack;if(P&&!P.hostile){P.hostile=true;P.hostT=300;for(const o of P.ships)o.peace=false;floater(e.x,e.y-24,'КЛИЕНТЫ: ВРАЖДЕБНЫ · 5 МИН','#c96a2a');}}
// --- 65: гражданские буксиры ---
function w58TugTick(dt,sec){const w=G.w,S=G.save,p=G.player,ws=w58S();const T=w.tug;
  if(!T){if(!(sec===2&&w58After(11))&&!(sec===3&&w58After(15)))return;w.tugT-=dt;if(w.tugT>0)return;w.tugT=90;if(Math.random()>.18&&!w.forceTug)return;if((G.event&&G.event!=='zone')||w58InStorm(p.x,p.y)||(ws.tugs.last&&G.t-ws.tugs.last<480&&!w.forceTug))return;w.forceTug=0;
    const a=rnd(0,TAU),d=rnd(1400,1800);const x0=p.x+Math.cos(a)*d,y0=p.y+Math.sin(a)*d;const a2=a+Math.PI+rnd(-.35,.35);const L=rnd(3000,3600);const x1=x0+Math.cos(a2)*L,y1=y0+Math.sin(a2)*L;if([[x0,y0],[x1,y1],[p.x,p.y]].some(([qx,qy])=>Math.hypot(qx-WORLD.abyss.x,qy-WORLD.abyss.y)<1500))return;// 0.5.9: буксир не идёт мимо Бездны
    const guard=ws.tugs.rob>0&&sec!==3;
    w.tug={x:x0,y:y0,x1,y1,vx:0,vy:0,name:W58_NAMES.tug[Math.floor(Math.random()*5)],hp:400,maxHp:400,st:'idle',t:0,sec,cont:[],amb:[0,0],near:0,warn:0,alive:true,r:30,spd:110,guard,contR:3,done:false};
    ws.tugs.last=G.t;if(guard){const g=spawnEnemy('hunter',x0,y0,{noAffix:true,spawnT:.5,tugGuard:true});g.tugG=true;}return;}
  if(!T.alive)return;T.t+=dt;if(T.warnT>0)T.warnT-=dt;
  const dx=T.x1-T.x,dy=T.y1-T.y,L=Math.hypot(dx,dy);
  const sp=T.st==='rob'?T.spd*1.6:(T.guard&&Math.hypot(p.x-T.x,p.y-T.y)<700&&T.st==='idle'?T.spd*1.5:T.spd);
  if(L>20){T.vx=dx/L*sp;T.vy=dy/L*sp;T.x+=T.vx*dt;T.y+=T.vy*dt;}
  for(const r of G.rocks){if(!r.alive)continue;const q=Math.hypot(T.x-r.x,T.y-r.y),m=r.r+T.r;if(q<m&&q>0){T.x=r.x+(T.x-r.x)/q*m;T.y=r.y+(T.y-r.y)/q*m;}}
  const dP=Math.hypot(p.x-T.x,p.y-T.y);
  if(T.st==='idle'){if(dP<350&&p.hp>0){T.near+=dt;if(T.near>=3){T.st='escort';G.event='tug';radioLine(T.name,'#7affc9','Спасибо, пилот. Держитесь рядом — впереди неспокойно.',0);T.len0=Math.hypot(T.x1-T.x,T.y1-T.y);T.x0=T.x;T.y0=T.y;}}else T.near=0;}
  if(T.st==='escort'){const pr=1-Math.hypot(T.x1-T.x,T.y1-T.y)/T.len0;
    for(const [i,f] of [[0,.35],[1,.7]]){if(!T.amb[i]&&pr>=f){T.amb[i]=1;const set=T.sec===2?(i?{archivist:1,phantom:2}:{frost:2,phantom:2}):(i?{shade:2,rammer:1}:{rammer:3,repairer:1});const a=Math.atan2(T.vy,T.vx);
        for(const [t,c] of Object.entries(set))for(let k=0;k<c;k++){const ax=T.x+Math.cos(a+rnd(-.6,.6))*650,ay=T.y+Math.sin(a+rnd(-.6,.6))*650;const e=spawnEnemy(t,ax,ay,{noAffix:true,spawnT:.6,tugAtk:true});if(e&&T.sec===3){e.hp*=.6;e.maxHp=e.hp;}}
        floater(T.x,T.y-40,'ЗАСАДА','#ff4f6e');sfx('warn');}}
    if(dP>3000){T.alive=false;G.event=null;floater(p.x,p.y-40,'БУКСИР УШЁЛ','#7a8ea5');}}
  // урон буксиру
  if(T.st!=='rob'){for(const b of G.eb){if(b.life<=0)continue;if(Math.hypot(b.x-T.x,b.y-T.y)<T.r+(b.r||4)){b.life=0;T.hp-=Math.min(8,b.dmg);T.flash=.1;}}
    for(const e of G.enemies){if(!e.alive||!e.tugAtk)continue;if(e.tugCd>0)e.tugCd-=dt;if(Math.hypot(e.x-T.x,e.y-T.y)<T.r+e.r+4&&!(e.tugCd>0)){e.tugCd=2;T.hp-=15;T.flash=.1;}}
    if(T.flash>0)T.flash-=dt;
    if(T.hp<=0){T.alive=false;explode(T.x,T.y,'#7affc9',40,1.4);sfx('bigboom');G.enemies.forEach(e=>{if(e.tugAtk)e.alive=false;});if(G.event==='tug')G.event=null;floater(T.x,T.y-40,'БУКСИР ПОТЕРЯН','#ff4f6e');return;}}
  if(T.st==='rob'){T.robT=(T.robT||0)+dt;if(T.robT>=6&&!T.robG){T.robG=1;for(let i=0;i<2;i++){const a=rnd(0,TAU);spawnEnemy('hunter',p.x+Math.cos(a)*800,p.y+Math.sin(a)*800,{noAffix:true,spawnT:.5});}floater(p.x,p.y-40,'ОХРАНА ГРАЖДАНСКИХ','#ff4f6e');}
    for(const c of T.cont){if(c.hp<=0)continue;c.x+=c.vx*dt;c.y+=c.vy*dt;c.vx*=.98;c.vy*=.98;}
    if(T.cont.every(c=>c.hp<=0)||dP>3000||T.robT>60){if(dP<=3000)for(const c of T.cont)if(c.hp>0){}T.alive=false;if(G.event==='tug')G.event=null;}}
  if(L<=20&&T.st!=='rob'){T.alive=false;if(T.st==='escort'){const v=T.sec===2?70:90;S.lom+=v;addPilotXP(30);p.en=100;ws.tugs.esc++;banner('БУКСИР ДОШЁЛ','+'+v+' ЛОМА НА СКЛАД · +30 ОПЫТА · НАКОПИТЕЛЬ ПОЛОН');radioLine(T.name,'#7affc9','Дошли. Если ещё раз пересечёмся — мы вас узнаем.',0);if(S.story)S.story.tugEsc=(S.story.tugEsc||0)+1;
      if(ws.tugs.esc===3&&!ws.tugs.cache){ws.tugs.cache=1;const f=W58.rust[0];WORLD.caches.push({id:'c58',x:f.x+600,y:f.y-600,skin:null,civ:true});banner('ГРАЖДАНСКИЕ ОСТАВИЛИ ТАЙНИК','СЕКТОР IV · 120 ЛОМА');}
      G.enemies.forEach(e=>{if(e.tugAtk)e.alive=false;});saveWorld();}if(G.event==='tug')G.event=null;}
}
function w58TugHit(b){const T=G.w&&G.w.tug;if(!T||!T.alive)return false;
  if(T.st==='rob'){for(const c of T.cont){if(c.hp<=0)continue;if(Math.hypot(b.x-c.x,b.y-c.y)<16+(b.r||4)){c.hp-=b.dmg;b.life=0;if(c.hp<=0){explode(c.x,c.y,'#7affc9',12,.7);G.save.carry+=25;dropCell(c.x,c.y,0);floater(c.x,c.y-20,'+25 ЛОМА · ЯЧЕЙКА','#ffb84d');sfx('boom');}return true;}}return false;}
  if(Math.hypot(b.x-T.x,b.y-T.y)<T.r+(b.r||4)){if(T.st==='escort'&&G.enemies.some(e=>e.alive&&e.tugAtk))return false;b.life=0;T.warn=(T.warn||0);if(T.warnT>0&&T.warn>=1){w58TugRob(T);}else{T.warn=1;T.warnT=5;floater(T.x,T.y-40,'«НЕ СТРЕЛЯЙТЕ!»','#7affc9');radioLine(T.name,'#7affc9','Не стреляйте! Мы гражданские!',0);}return true;}return false;}
function w58TugRob(T){const ws=w58S();T.st='rob';G.event='tug';ws.tugs.rob++;for(let i=0;i<3;i++){const a=rnd(0,TAU);T.cont.push({x:T.x-T.vx*.3+Math.cos(a)*40,y:T.y-T.vy*.3+Math.sin(a)*40,vx:Math.cos(a)*30,vy:Math.sin(a)*30,hp:120});}
  G.enemies.forEach(e=>{if(e.tugAtk)e.alive=false;});floater(T.x,T.y-40,'БУКСИР СБРОСИЛ ГРУЗ И УХОДИТ','#ff4f6e');sfx('warn');
  if(ws.tugs.rob===3)radioLine('Э. В.','#ffd36b','Они были последними, кто ещё летал сам.',2);}
// --- 64: раскопки у обломка Инвентаризатора ---
function w58DigTick(dt){const S=G.save,p=G.player,w=G.w;if(!S||!S.story||!S.story.inv14)return;const ws=w58S();const q=sbWreckPos(14);const d=Math.hypot(p.x-q.x,p.y-q.y);
  const prog=S.story.invDig||0;if(prog>=4||d>1600){if(w.digs&&d>2200){w.digs.forEach(c=>{if(c.alive)c.alive=false;});w.digs=null;}return;}
  if(!w.digs){w.digs=[];const L=['ЩИТ','РЫВОК','ОРУДИЕ','013'];for(let i=0;i<4;i++){if(i<prog){w.digs.push(null);continue;}const a=i/4*TAU-Math.PI/2;const c=spawnEnemy('invcell',q.x+Math.cos(a)*160,q.y+Math.sin(a)*160,{noAffix:true,noLoot:true,spawnT:.3,dig:i,digL:L[i]});c.hp=c.maxHp=300;c.cell=null;w.digs.push(c);}}
}
function w58DigHurt(e,dmg){const S=G.save,prog=S.story.invDig||0;if(e.dig!==prog){e.domeFlash=.15;sfx('block');return 0;}return dmg;}
function w58DigDied(e){const S=G.save,ws=w58S(),w=G.w;S.story.invDig=(S.story.invDig||0)+1;const n=S.story.invDig;S.carry+=20;const q=sbWreckPos(14);
  const lines=['ЩИТ: отказано в циклах IX, XVII. Хранится как образец.','РЫВОК: 4 102 записи. Эталон — цикл XX.','ОРУДИЕ: калибр менялся 31 раз. Результат один.',''];
  if(n===1||n===3){for(let i=0;i<2;i++){const a=rnd(0,TAU);const path=[];for(let k=0;k<=20;k++)path.push({x:q.x+Math.cos(a)*300+Math.cos(a+k*.3)*120,y:q.y+Math.sin(a)*300+Math.sin(a+k*.3)*120,t:k/5});const c=spawnEnemy('icecopy',path[0].x,path[0].y,{path,pt:0,noAffix:true,noLoot:true,spawnT:.5,fire:true,frate:Math.max(.5,G.st.rate*2)*atkK(),fdmg:clamp(G.st.dmg*.5,6,22),skin:curSkin()});c.contact=14;}
    if(n===3)spawnEnemy('frost',q.x+rnd(-200,200),q.y-300,{noAffix:true,spawnT:.5});floater(q.x,q.y-100,'ЗАЩИТА КАРКАСА','#8fd8ff');}
  if(n<4){toast('ЯЧЕЙКА КАТАЛОГА · '+e.digL,lines[n-1]+' (+20 лома)');}
  else{const ch=storyFlag('inv14');if(!S.ownSkins.includes('archive')){S.ownSkins.push('archive');banner('СКИН НАЙДЕН · «АРХИВНЫЙ»','ЯЧЕЙКА 013 · АНГАР «ЗЕРКАЛО»');}
    if(ch==='memory')toast('ЯЧЕЙКА 013','На дне ячейки — записка не по форме: «Я вписал тебя в каталог сам, чтобы Архив не мог тебя стереть. Прости за номер». — Э. В. (+20 лома)');else{S.carry+=40;toast('ЯЧЕЙКА 013','Ячейка пуста. Холод стёр записи, остался лом. (+60 лома)');}}
  sfx('level');saveWorld();}
// --- 72: Холодное ядро (аномалия) ---
function w58CoreStart(a){const A=G.anom;A.dur=35;A.need=5;A.got=0;A.iceT=2.5;A.shard=null;A.wave=0;A.recT=0;w58CoreShard(a);banner('АНОМАЛИЯ · ХОЛОДНОЕ ЯДРО','5 ОСКОЛКОВ ТЕПЛА ЗА 35 С · ЛЁД РАСТЁТ · РЫВОК СБРАСЫВАЕТ');}
function w58CoreShard(a){const A=G.anom;let x,y,k=0;do{const ang=rnd(0,TAU),d=rnd(120,380);x=a.x+Math.cos(ang)*d;y=a.y+Math.sin(ang)*d;}while(A.shard&&Math.hypot(x-A.shard.x,y-A.shard.y)<250&&++k<20);A.shard={x,y,t:0};}
function w58CoreTick(dt,fail,win){const A=G.anom,a=A.a,p=G.player;const inS=Math.hypot(p.x-a.x,p.y-a.y)<420;
  if(A.got>=A.need){win(120);const S=G.save;if(!S.ownSkins.includes('rime')){S.ownSkins.push('rime');banner('СКИН НАЙДЕН · «НАСТ»','ЯДРО РАСКОЛОТО · АНГАР «ЗЕРКАЛО»');}return true;}
  if(A.t>A.dur){fail('ВРЕМЯ ВЫШЛО');return true;}if(Math.hypot(p.x-a.x,p.y-a.y)>900){fail('ВЫ ПОКИНУЛИ ЯДРО');return true;}
  if(inS){A.iceT-=dt;if(A.iceT<=0){A.iceT=2.5;addIce(1);}}
  if(A.shard){A.shard.t+=dt;if(Math.hypot(p.x-A.shard.x,p.y-A.shard.y)<24&&p.hp>0){A.got++;clearIce();G.iceImm=3;explode(A.shard.x,A.shard.y,'#ffb84d',10,.6);floater(p.x,p.y-26,'ТЕПЛО · '+A.got+'/5','#ffb84d');sfx('cell');if(A.got<A.need)w58CoreShard(a);else A.shard=null;}}
  const ph=A.t<12?0:A.t<24?1:2;if(A.wave<=ph){A.wave=ph+1;const sets=[{frost:2},{phantom:2,frost:1},{shade:2,hunter:1}];for(const [t,c] of Object.entries(sets[ph]))for(let i=0;i<c;i++){const ang=rnd(0,TAU);const e=spawnEnemy(t,a.x+Math.cos(ang)*600,a.y+Math.sin(ang)*600,{noAffix:true,spawnT:.5,anomObj:true});A.objs.push(e);}}
  for(const e of G.enemies){if(!e.alive)continue;e.tK=Math.hypot(e.x-a.x,e.y-a.y)<420?.5:1;}
  if(A.t>=20&&A.t<30){const r=W58.recs.find(q=>q.core);if(r&&!w58S().arcRec.includes(r.id)){r.x=a.x;r.y=a.y;}}
  return false;}
// --- 68: спецзадание «Конвейер» ---
const CONV={L:2400,W:180,cells:[[0,800,'ПРИЁМКА'],[800,1600,'СОРТИРОВКА'],[1600,2200,'ПРЕСС']]};
function w58ConvAvail(){const S=G.save;return !!W58.depot&&w58After(17)&&!(G.anom);}
function w58ConvStart(){const D=W58.depot,S=G.save,ws=w58S();if(!w58ConvAvail()||G.state!=='world')return;G.enemies.forEach(e=>{if(e.zone||e.tugAtk||e.pack)e.alive=false;});G.w.packs.forEach(P=>{P.ships=[];});W58.zones.forEach(z=>{z.active=false;});
  const a={id:'conv',kind:'conveyor',name:'КОНВЕЙЕР',x:D.x-CONV.L/2,y:D.y,hud:()=>{const A=G.anom;return 'КОНВЕЙЕР · ЦЕХ '+Math.min(3,A.cell+1)+' ИЗ 3 · '+Math.round(A.prog/CONV.L*100)+'% · БАРЖА '+Math.max(0,Math.ceil(A.bhp))+'/600';}};
  G.anom={a,t:0,got:0,objs:[],dur:1e9,x0:D.x-CONV.L/2,y0:D.y,prog:0,bhp:600,cell:0,phase:'set',pt:0,arms:[],press:[],sucks:[],lamps:[],gate:0,gateT:0,fin:false,ch:storyFlag('obod18')};
  const A=G.anom;for(let i=0;i<3;i++)A.arms.push({x:A.x0+950+i*230,side:i%2?1:-1,t:rnd(0,4),jam:0,hits:0,ph:'idle',sw:0});
  for(let i=0;i<2;i++)A.press.push({x:A.x0+1750+i*300,t:2+i*2.5,ph:'up',hold:0,shadow:0});
  G.event='conv';G.cardKey=null;banner('КОНВЕЙЕР','ВЫВЕДИТЕ БАРЖУ ЧЕРЕЗ ТРИ ЦЕХА');sfx('warn');radioLine('КОЛЫБЕЛЬНАЯ','#7affc9','Трое в криосне. Мы не можем остановиться — лента держит.',.5);
  const p=G.player;p.x=A.x0+80;p.y=A.y0-120;}
function w58ConvFail(why){const A=G.anom;banner('ЗАДАНИЕ ПРОВАЛЕНО',why+' · ПОВТОР ЧЕРЕЗ 60 С');(G.anomCd||(G.anomCd={})).conv=G.t+60;G.enemies.forEach(e=>{if(e.conv||e.anomObj)e.alive=false;});G.anom=null;G.event=null;G.cardKey=null;G.enemies.forEach(e=>{e.tK=1;});}
function w58ConvTick(dt){const A=G.anom,a=A.a,p=G.player,S=G.save,ws=w58S();A.pt+=dt;const bx=A.x0+A.prog,by=A.y0;A.bx=bx;A.by=by;
  if(p.hp<=0){w58ConvFail('КОРАБЛЬ ПОТЕРЯН');return;}
  const out=Math.abs(p.y-A.y0)>700||p.x<A.x0-400||p.x>A.x0+CONV.L+500;A.outT=out?(A.outT||0)+dt:0;if(A.outT>3){w58ConvFail('ВЫ ПОКИНУЛИ ДЕПО');return;}
  if(A.bhp<=0){explode(bx,by,'#7affc9',50,1.5);sfx('bigboom');w58ConvFail('БАРЖА РАЗРУШЕНА');return;}
  if(A.phase==='set'){if(A.pt>5){A.phase='run';}return;}
  if(A.phase==='run'){let sp=24;const inCloud=G.fields.some(f=>f.rust&&Math.hypot(f.x-bx,f.y-by)<f.r);if(inCloud)sp*=.5;A.prog+=sp*dt;A.cell=A.prog<800?0:A.prog<1600?1:2;
    if(A.prog>=2200){A.prog=2200;A.phase='gate';A.gateT=0;banner('ШЛЮЗ','ЗАРЯДИТЕ КОЛЬЦО · 6 С В ЗЕЛЁНОМ КРУГЕ');for(let i=0;i<4;i++){const c=w58SpawnCopy(A.x0+1900+rnd(-60,60),by+rnd(-200,200),null);c.conv=true;c.peace=false;}}
    // цех 1: ремонтники
    if(A.cell===0){A.sT=(A.sT||0)-dt;if(A.sT<=0){A.sT=8;const n=G.enemies.filter(e=>e.alive&&e.conv&&e.type==='repairer').length,cap=A.ch==='scrap'?2:4;for(let i=0;i<2&&n+i<cap;i++){const e=spawnEnemy('repairer',bx+rnd(-100,100),by+(Math.random()<.5?-1:1)*600,{noAffix:true,spawnT:.5,conv:true,suck:true});}}
      if(!A.turrets){A.turrets=1;for(const s of [-1,1]){const e=spawnEnemy('gunner',A.x0+500,by+s*260,{noAffix:true,spawnT:.5,conv:true,fixedPos:true});e.spd=0;}}}
    for(const e of G.enemies){if(!e.alive||!e.suck||e.spawnT>0)continue;const q=Math.hypot(e.x-bx,e.y-by)||1;if(q<46){e.stuck=true;e.vx=e.vy=0;e.x=bx+(e.x-bx)/q*40;e.y=by+(e.y-by)/q*40;A.bhp-=6*dt;if(!A.suckHint){A.suckHint=1;floater(bx,by-40,'ИДЁТ РЕМОНТ КЛИЕНТА','#ffb060');}}else{e.x+=(bx-e.x)/q*150*dt;e.y+=(by-e.y)/q*150*dt;}}
    // цех 2: манипуляторы и коррозийник
    if(A.cell>=1){if(!A.cor){A.cor=1;spawnEnemy('corroder',A.x0+1200,by-500,{noAffix:true,spawnT:.5,conv:true});spawnEnemy('shade',A.x0+1000,by+500,{noAffix:true,spawnT:.5,conv:true});spawnEnemy('shade',A.x0+1400,by+500,{noAffix:true,spawnT:.5,conv:true});}
      for(const m of A.arms){if(m.jam>0){m.jam-=dt;continue;}m.t-=dt;if(m.ph==='idle'&&m.t<=0){m.ph='tele';m.t=1.2;}else if(m.ph==='tele'&&m.t<=0){m.ph='sweep';m.t=.4;if(Math.abs(bx-m.x)<140)A.bhp-=60;if(Math.abs(p.x-m.x)<140&&Math.abs(p.y-by)<CONV.W/2+20)damagePlayer(14);}else if(m.ph==='sweep'&&m.t<=0){m.ph='idle';m.t=4;}}}
    // цех 3: прессы
    if(A.cell>=2){if(!A.ram){A.ram=1;for(let i=0;i<3;i++)spawnEnemy('rammer',A.x0+2000+rnd(-100,100),by+(i%2?-1:1)*600,{noAffix:true,spawnT:.5,conv:true});A.ramT=15;}
      A.ramT-=dt;if(A.ramT<=0&&!A.ram2){A.ram2=1;for(let i=0;i<2;i++)spawnEnemy('rammer',A.x0+2000,by+(i%2?-1:1)*600,{noAffix:true,spawnT:.5,conv:true});}
      const per=A.ch==='service'?4:5;for(const P of A.press){if(P.hold>0){P.hold-=dt;P.ph='up';P.t=1.5;continue;}P.t-=dt;if(P.ph==='up'&&P.t<=0){P.ph='warn';P.t=1.5;sfx('warn');}else if(P.ph==='warn'&&P.t<=0){P.ph='down';P.t=.5;shake(8);if(Math.abs(bx-P.x)<110)A.bhp-=200;if(Math.abs(p.x-P.x)<110&&Math.abs(p.y-by)<CONV.W/2+10)damagePlayer(30);}else if(P.ph==='down'&&P.t<=0){P.ph='up';P.t=per-2;}}}
    return;}
  if(A.phase==='gate'){const gx=A.x0+2300,gy=A.y0+220;if(Math.hypot(p.x-gx,p.y-gy)<80&&p.hp>0)A.gateT+=dt;A.gate=Math.min(1,A.gateT/6);
    if(A.gate>=1){A.phase='done';A.pt=0;G.enemies.forEach(e=>{if(e.conv)e.alive=false;});banner('БАРЖА ВЫВЕДЕНА','ТРОЕ ЖИВЫ');radioLine('КОЛЫБЕЛЬНАЯ','#7affc9','Трое живы. Мы не знаем, кто вы, но запомним.',.5);
      const first=!ws.conveyor.done;const v=(first?240:80)+(A.bhp>=450?(first?60:20):0);S.lom+=v;addPilotXP(first?80:30);ws.conveyor.done=1;ws.conveyor.cyc=S.cycle||1;if(S.story)S.story.conveyor=1;S.anomalies.conv=1;conEvent('anom');
      setTimeout(()=>banner('ЗАДАНИЕ ВЫПОЛНЕНО','+'+v+' ЛОМА · +'+(first?80:30)+' ОПЫТА ПИЛОТА'),2700);saveWorld();}return;}
  if(A.phase==='done'){A.prog+=120*dt;if(A.pt>4){G.anom=null;G.event=null;G.cardKey=null;}}
}
function w58ConvHit(b){const A=G.anom;if(!A||A.a.kind!=='conveyor')return false;
  for(const m of A.arms){const jx=m.x,jy=A.y0+m.side*(CONV.W/2+150);if(Math.hypot(b.x-jx,b.y-jy)<22+(b.r||4)){b.life=0;m.hits+=b.charged?3:1;if(m.hits>=3){m.hits=0;m.jam=5;m.ph='idle';m.t=4;floater(jx,jy-20,'СУСТАВ ЗАКЛИНИЛ · 5 С','#ffb84d');sfx('boom');}else sfx('hit');return true;}}
  for(const P of A.press){const kx=P.x,ky=A.y0-(CONV.W/2+230);if(Math.hypot(b.x-kx,b.y-ky)<18+(b.r||4)){b.life=0;if(P.hold<=0){P.hold=6;floater(kx,ky-20,'АВАРИЙНЫЙ СТОП · 6 С','#ff4f6e');sfx('block');}return true;}}
  return false;}

// --- отрисовка: под объектами (шельфы, поля, депо) ---
function w58Draw(t){if(!W58.gen)return;const ws=w58S(),S=G.save;
  for(const s of W58.shelves){if(!inView(s.x,s.y,s.r*1.2))continue;
    const g=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,s.r);g.addColorStop(0,`rgba(191,232,255,${.10*COLD_A})`);g.addColorStop(1,`rgba(191,232,255,${.04*COLD_A})`);ctx.fillStyle=g;ctx.beginPath();s.pts.forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));ctx.closePath();ctx.fill();
    ctx.strokeStyle='#bfe8ff';ctx.globalAlpha=.35*COLD_A;ctx.lineWidth=1.5;ctx.stroke();
    ctx.globalAlpha=.18*COLD_A;ctx.lineWidth=1;for(const c of s.cracks){ctx.beginPath();c.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]));ctx.stroke();}
    if(SET.fx)for(const b of s.blinks){const k=.5+.5*Math.sin(t*TAU/b.per+b.ph);ctx.globalAlpha=k*.6*COLD_A;ctx.fillStyle='#ffffff';ctx.fillRect(b.x-1,b.y-1,2,2);}
    ctx.globalAlpha=1;
    for(const r of s.rocks){if(ws&&ws.iceRocks.includes(r.id))continue;ctx.save();ctx.translate(r.x,r.y);ctx.rotate(r.rot);ctx.fillStyle='#1c2a3a';ctx.strokeStyle='#5b7f99';ctx.lineWidth=1.5;ctx.beginPath();for(let i=0;i<7;i++){const a=i/7*TAU,rr=r.r*(.8+.2*Math.sin(i*2.3));ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle='rgba(223,246,255,.55)';ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,r.r+5,0,TAU);ctx.stroke();ctx.restore();}
    if(s.core)continue;}
  for(const f of W58.rust){if(!inView(f.x,f.y,f.r+40))continue;const sc=storyFlag('obod18')==='scrap';
    const g=ctx.createRadialGradient(f.x,f.y,0,f.x,f.y,f.r);g.addColorStop(0,`rgba(201,106,42,${sc?.04:.07})`);g.addColorStop(1,'rgba(201,106,42,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,TAU);ctx.fill();
    ctx.strokeStyle='#c96a2a';ctx.globalAlpha=.12;ctx.lineWidth=1;ctx.setLineDash([6,14]);ctx.lineDashOffset=t*8;ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;
    if(SET.fx){ctx.fillStyle='#c96a2a';ctx.globalAlpha=.25;for(const d of f.dots){const a=d.a+t*.05,rr=f.r*(.2+.75*((d.d+t*.01)%1));ctx.fillRect(f.x+Math.cos(a)*rr,f.y+Math.sin(a)*rr,1.5,1.5);}}
    ctx.globalAlpha=1;
    for(const r of f.rocks){if(S.rocksGone&&S.rocksGone.includes(r.id))continue;ctx.save();ctx.translate(r.x,r.y);ctx.rotate(r.rot+t*.1);ctx.fillStyle='#2a1a10';ctx.strokeStyle='#8a5a3a';ctx.lineWidth=1.5;ctx.beginPath();for(let i=0;i<7;i++){const a=i/7*TAU,rr=r.r*(.8+.2*Math.sin(i*2.3));ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr);}ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
    if(f.box&&ws&&!ws.rustBox.includes(f.id)){ctx.save();ctx.translate(f.x,f.y);glow(0,0,40,'#ffb84d',.3);ctx.rotate(t*.3);ctx.fillStyle='#1a1206';ctx.strokeStyle='#c96a2a';ctx.lineWidth=2;ctx.fillRect(-14,-10,28,20);ctx.strokeRect(-14,-10,28,20);ctx.restore();worldLabel(f.x,f.y-30,'КОНТЕЙНЕР УТИЛИЗАЦИИ','#ffb84d');
      if(f.rep>0){ctx.strokeStyle='#ffb84d';ctx.lineWidth=3;ctx.beginPath();ctx.arc(f.x,f.y,30,-Math.PI/2,-Math.PI/2+TAU*f.rep/3);ctx.stroke();}}}
  // депо
  const D=W58.depot;if(D&&w58After(17)&&inView(D.x,D.y,CONV.L/2+360)){const A=G.anom&&G.anom.a.kind==='conveyor'?G.anom:null;const x0=D.x-CONV.L/2,y=D.y;const done=w58S().conveyor.done;
    ctx.strokeStyle='#5a3a2a';ctx.lineWidth=6;ctx.globalAlpha=done&&!A?.35:.9;ctx.beginPath();ctx.moveTo(x0,y-CONV.W/2);ctx.lineTo(x0+CONV.L,y-CONV.W/2);ctx.moveTo(x0,y+CONV.W/2);ctx.lineTo(x0+CONV.L,y+CONV.W/2);ctx.stroke();
    if(A||!done){ctx.fillStyle='#c96a2a';ctx.globalAlpha=.35;const off=(t*24)%60;for(let x=x0+off;x<x0+CONV.L;x+=60){ctx.beginPath();ctx.moveTo(x,y-10);ctx.lineTo(x+12,y);ctx.lineTo(x,y+10);ctx.lineTo(x+4,y);ctx.closePath();ctx.fill();}}
    ctx.globalAlpha=1;
    // мостки и фонари
    for(const s of [-1,1]){const yy=y+s*260;ctx.strokeStyle='#4a5566';ctx.lineWidth=2;ctx.globalAlpha=.6;ctx.beginPath();ctx.moveTo(x0,yy);ctx.lineTo(x0+CONV.L,yy);ctx.stroke();ctx.globalAlpha=1;
      for(let x=x0+100;x<x0+CONV.L;x+=200){if(!inView(x,yy,40))continue;const lit=A?x>A.prog+x0-200:!done;ctx.fillStyle=lit?'#ffd36b':'#2a2a2a';ctx.fillRect(x-3,yy-3,6,6);if(lit&&SET.fx)glow(x,yy,30,'#ffd36b',.25);}}
    // цеха
    CONV.cells.forEach(([a,b,name],i)=>{if(!inView(x0+(a+b)/2,y,(b-a)/2+260))return;ctx.fillStyle='rgba(0,0,0,'+(.08*(i+1))+')';ctx.fillRect(x0+a,y-CONV.W/2-230,b-a,CONV.W+460);ctx.strokeStyle='#ffb84d';ctx.lineWidth=2;ctx.globalAlpha=.5;ctx.setLineDash([12,8]);ctx.beginPath();ctx.moveTo(x0+a,y-CONV.W/2-230);ctx.lineTo(x0+a,y+CONV.W/2+230);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;worldLabel(x0+a+(b-a)/2,y-CONV.W/2-240,name,'#ffb84d');});
    // шлюз
    {const gx=x0+2300,open=A?A.gate:done?1:0;ctx.fillStyle='#1a2230';ctx.strokeStyle='#7affc9';ctx.lineWidth=2;for(const s of [-1,1]){const h=(CONV.W/2+60)*(1-open);ctx.fillRect(gx-20,s>0?y:y-h-(s<0?0:0),40,0);ctx.beginPath();ctx.rect(gx-20,s<0?y-CONV.W/2-60:y+CONV.W/2+60-h,40,h);ctx.fill();ctx.stroke();}
      ctx.strokeStyle='#7affc9';ctx.globalAlpha=A&&A.phase==='gate'?.9:.3;ctx.lineWidth=2;ctx.beginPath();ctx.arc(gx,y+220,80,0,TAU);ctx.stroke();if(A&&A.phase==='gate'){ctx.lineWidth=4;ctx.beginPath();ctx.arc(gx,y+220,80,-Math.PI/2,-Math.PI/2+TAU*A.gate);ctx.stroke();worldLabel(gx,y+320,'КОЛЬЦО ЗАРЯДКИ · '+Math.round(A.gate*100)+'%','#7affc9');}ctx.globalAlpha=1;}
    if(!A){worldLabel(D.x,y-CONV.W/2-300,done?'ДЕПО · ЛИНИЯ ОСТАНОВЛЕНА':'ДЕПО · ЛИНИЯ УТИЛИЗАЦИИ','#ffb84d');}
    else{// баржа, руки, прессы
      const bx=A.bx||x0,by=y;ctx.save();ctx.translate(bx,by);glow(0,0,70,'#7affc9',.3);ctx.fillStyle='#0f2a22';ctx.strokeStyle='#7affc9';ctx.lineWidth=2.5;ctx.fillRect(-55,-23,110,46);ctx.strokeRect(-55,-23,110,46);
        for(let i=-1;i<=1;i++){ctx.fillStyle=`rgba(255,255,255,${.5+.4*Math.sin(t*2+i)})`;ctx.beginPath();ctx.arc(i*30,0,8,0,TAU);ctx.fill();}
        if(A.bhp<400){ctx.fillStyle='#000';ctx.globalAlpha=.5;for(let i=0;i<3;i++)ctx.fillRect(-40+i*30,-15+(i%2)*20,14,8);ctx.globalAlpha=1;if(SET.fx&&Math.random()<.3)part(bx+rnd(-50,50),by+rnd(-20,20),rnd(-40,40),rnd(-60,-10),.4,'#ffb84d',2);}
        ctx.restore();worldLabel(bx,by-40,'«КОЛЫБЕЛЬНАЯ» · '+Math.max(0,Math.ceil(A.bhp)),'#7affc9');
      if(A.cell>=1)for(const m of A.arms){const jx=m.x,jy=y+m.side*(CONV.W/2+150),base={x:m.x,y:y+m.side*260};ctx.strokeStyle=m.jam>0?'#7a8ea5':'#8a9bb0';ctx.lineWidth=8;ctx.lineCap='round';
          const sw=m.ph==='sweep'?1:m.ph==='tele'?.3:0;const ex=m.x+(m.side*-1)*0,ey=y+m.side*(CONV.W/2+150-sw*150);ctx.beginPath();ctx.moveTo(base.x,base.y);ctx.lineTo(jx,jy);ctx.lineTo(ex+sw*0,ey);ctx.stroke();ctx.lineCap='butt';
          ctx.fillStyle=m.jam>0?'#ffb84d':'#c96a2a';ctx.beginPath();ctx.arc(jx,jy,m.jam>0?12:10,0,TAU);ctx.fill();if(m.jam>0&&SET.fx&&Math.random()<.4)part(jx,jy,rnd(-80,80),rnd(-80,80),.2,'#ffd36b',2);
          if(m.ph==='tele'){ctx.fillStyle='rgba(255,79,110,.25)';ctx.fillRect(m.x-140,y-CONV.W/2,280,CONV.W);}if(m.ph==='sweep'){ctx.fillStyle='rgba(255,255,255,.35)';ctx.fillRect(m.x-140,y-CONV.W/2,280,CONV.W);}}
      if(A.cell>=2)for(const P of A.press){const kx=P.x,ky=y-(CONV.W/2+230);const down=P.ph==='down'?1:0;ctx.fillStyle='#1a1a1a';ctx.strokeStyle='#ffd36b';ctx.lineWidth=2;const ph=120+down*(CONV.W+100);ctx.fillRect(P.x-110,y-CONV.W/2-230,220,ph);ctx.strokeRect(P.x-110,y-CONV.W/2-230,220,ph);
          ctx.fillStyle='#000';for(let i=0;i<5;i++)ctx.fillRect(P.x-110+i*44+(i%2)*22,y-CONV.W/2-230,22,ph);
          if(P.ph==='warn'){ctx.fillStyle='rgba(255,40,70,.3)';ctx.fillRect(P.x-110,y-CONV.W/2,220,CONV.W);}
          ctx.fillStyle=P.hold>0?'#3a1a1a':'#ff4f6e';ctx.beginPath();ctx.arc(kx,ky,16,0,TAU);ctx.fill();ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.stroke();worldLabel(kx,ky-26,P.hold>0?'СТОП · '+Math.ceil(P.hold)+' С':'АВАРИЙНЫЙ СТОП','#ff4f6e');}
      ctx.strokeStyle='#ffb84d';ctx.globalAlpha=.15;ctx.setLineDash([4,10]);ctx.strokeRect(x0-400,y-700,CONV.L+900,1400);ctx.setLineDash([]);ctx.globalAlpha=1;}}
  // раскопки
  if(G.w&&G.w.digs){const q=sbWreckPos(14);for(const c of G.w.digs){if(!c||!c.alive)continue;worldLabel(c.x,c.y-24,c.digL,(G.save.story.invDig||0)===c.dig?'#dff6ff':'#5b7f99');}}
}
// --- отрисовка: над врагами (маяки, записи, буксир, засада, бури) ---
function w58DrawTop(t){if(!W58.gen||!G.w)return;const ws=w58S(),p=G.player,w=G.w,S=G.save;
  // след на льду
  if(w.trail)for(const q of w.trail){ctx.strokeStyle='#ffffff';ctx.globalAlpha=q.t/2*.35*COLD_A;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(q.x1,q.y1);ctx.lineTo(q.x1+1,q.y1+1);ctx.moveTo(q.x2,q.y2);ctx.lineTo(q.x2+1,q.y2+1);ctx.stroke();}ctx.globalAlpha=1;
  // записи
  if(w58SecOpen())for(const r of W58.recs){if(ws.arcRec.includes(r.id))continue;if(r.core&&!(G.anom&&G.anom.a.kind==='coldcore'&&G.anom.t>=20&&G.anom.t<30))continue;const q=w58RecPos(r);if(!inView(q.x,q.y,60))continue;
    glow(q.x,q.y,40,'#bfe8ff',.4);ctx.save();ctx.translate(q.x,q.y);ctx.fillStyle='#0b1628';ctx.strokeStyle=r.frozen?'#5b7f99':'#bfe8ff';ctx.lineWidth=2;poly(6,11,t*.4);ctx.fill();ctx.stroke();ctx.restore();
    ctx.font='700 9px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#dff6ff';ctx.globalAlpha=.6+.4*Math.sin(t*3);ctx.fillText(r.cyc,q.x,q.y+3);ctx.globalAlpha=1;
    const k=(t/4)%1;if(k<.5){ctx.strokeStyle='#bfe8ff';ctx.globalAlpha=(1-k*2)*.4;ctx.lineWidth=1;ctx.beginPath();ctx.arc(q.x,q.y,12+k*60,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
    worldLabel(q.x,q.y-22,r.frozen?'ЗАПИСЬ · ВМОРОЖЕНА':'ЗАПИСЬ АРХИВА','#bfe8ff');}
  // маяки
  if(w58After(11))for(const b of W58.beacons){const dead=ws.arcBeacons.includes(b.id);if(!inView(b.x,b.y,120))continue;
    ctx.save();ctx.translate(b.x,b.y);if(dead){ctx.strokeStyle='#3a4558';ctx.lineWidth=2;poly(3,26,-Math.PI/2);ctx.stroke();ctx.restore();worldLabel(b.x,b.y-44,'МАЯК АРХИВА · РАЗБИТ','#3a4558');continue;}
    const F=b.F;glow(0,0,70,'#9fd8ff',.3);ctx.fillStyle='#0b1628';ctx.strokeStyle=F&&F.flash>0?'#ffffff':'#9fd8ff';ctx.lineWidth=2.5;poly(3,30,-Math.PI/2);ctx.fill();ctx.stroke();ctx.rotate(t*1.2);ctx.strokeStyle='#dff6ff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,16,-.6,.6);ctx.stroke();ctx.rotate(-t*1.2);
    for(let i=0;i<3;i++){const a=i/3*TAU-Math.PI/2;ctx.fillStyle=Math.sin(t*4+i)>0?'#9fd8ff':'#1c3a55';ctx.beginPath();ctx.arc(Math.cos(a)*22,Math.sin(a)*22,3,0,TAU);ctx.fill();}
    if(F&&F.shield){ctx.strokeStyle='#bfe8ff';ctx.globalAlpha=.5+.2*Math.sin(t*5);ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,42,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
    if(F&&F.flash>0)F.flash-=VDT74;/* ARCH·75 A-22 */ctx.restore();
    if(F&&F.shield)for(const g of F.guards){if(!g.alive)continue;ctx.strokeStyle='#bfe8ff';ctx.globalAlpha=.3;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(g.x,g.y);ctx.stroke();ctx.globalAlpha=1;}
    if(F&&F.ring){ctx.strokeStyle='#9fd8ff';ctx.globalAlpha=.5*(1-F.ring.r/900);ctx.lineWidth=2;ctx.beginPath();ctx.arc(b.x,b.y,F.ring.r,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
    if(F&&F.active){ctx.strokeStyle='#9fd8ff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(b.x,b.y,36,-Math.PI/2,-Math.PI/2+TAU*F.hp/900);ctx.stroke();}
    worldLabel(b.x,b.y-50,F&&F.shield?'МАЯК АРХИВА · КУПОЛ':'МАЯК АРХИВА','#9fd8ff');}
  // блуждатель: кольцо карточек и подпись
  if(w.wander&&w.wander.alive){const e=w.wander;if(inView(e.x,e.y,80)){ctx.save();ctx.translate(e.x,e.y);ctx.rotate(t*.6);for(let i=0;i<6;i++){ctx.rotate(TAU/6);ctx.fillStyle='rgba(191,232,255,.6)';ctx.fillRect(34,-4,10,8);}ctx.restore();worldLabel(e.x,e.y-e.r-26,'СТРАНСТВУЮЩИЙ АРХИВАТОР','#9fd8ff');
      if(e.st==='rec'){ctx.font='700 11px "JetBrains Mono",monospace';ctx.fillStyle='#8fd8ff';ctx.textAlign='center';ctx.fillText('ЗАПИСЬ '+Math.round((1-e.timer/(w58BeaconDead()?5:3.5))*100)+'%',e.x,e.y+e.r+22);}}}
  // буксир
  const T=w.tug;if(T&&T.alive){const a=Math.atan2(T.vy,T.vx);
    if(T.st!=='rob'){for(let i=0;i<T.contR;i++){const cx=T.x-Math.cos(a)*(60+i*34),cy=T.y-Math.sin(a)*(60+i*34);ctx.strokeStyle='#7affc9';ctx.lineWidth=1;ctx.globalAlpha=.6;ctx.beginPath();ctx.moveTo(i?T.x-Math.cos(a)*(60+(i-1)*34):T.x,i?T.y-Math.sin(a)*(60+(i-1)*34):T.y);ctx.lineTo(cx,cy);ctx.stroke();ctx.globalAlpha=1;
        ctx.save();ctx.translate(cx,cy);ctx.rotate(a);ctx.fillStyle='#0f2a22';ctx.strokeStyle='#7affc9';ctx.lineWidth=1.5;ctx.fillRect(-13,-9,26,18);ctx.strokeRect(-13,-9,26,18);ctx.restore();}}
    else for(const c of T.cont){if(c.hp<=0)continue;ctx.save();ctx.translate(c.x,c.y);ctx.rotate(t);ctx.fillStyle='#0f2a22';ctx.strokeStyle='#7affc9';ctx.lineWidth=1.5;ctx.fillRect(-13,-9,26,18);ctx.strokeRect(-13,-9,26,18);ctx.restore();}
    ctx.save();ctx.translate(T.x,T.y);ctx.rotate(a);glow(0,0,50,'#7affc9',.25);ctx.fillStyle='#0f2a22';ctx.strokeStyle=T.flash>0?'#ffffff':'#7affc9';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(30,0);ctx.lineTo(10,-12);ctx.lineTo(-30,-12);ctx.lineTo(-30,12);ctx.lineTo(10,12);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.fillStyle=Math.sin(t*TAU)>0?'#ffffff':'#7affc9';ctx.fillRect(-28,-14,3,3);ctx.fillRect(-28,11,3,3);ctx.restore();
    worldLabel(T.x,T.y-34,T.name+(T.st==='escort'?' · '+Math.ceil(T.hp):T.st==='rob'?' · УХОДИТ':''),'#7affc9');
    if(T.st==='escort'){ctx.fillStyle='#1a2230';ctx.fillRect(T.x-30,T.y-26,60,4);ctx.fillStyle='#7affc9';ctx.fillRect(T.x-30,T.y-26,60*clamp(T.hp/T.maxHp,0,1),4);}}
  // подкрепление патрулей (метки)
  for(const q of G.warns){if(!q.zone)continue;ctx.strokeStyle=EDEF[q.type].col;ctx.globalAlpha=.4+.6*Math.abs(Math.sin(q.t*18));ctx.lineWidth=2;ctx.beginPath();ctx.arc(q.x,q.y,14,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
  // вожак
  for(const e of G.enemies){if(!e.alive||!e.leader||e.spawnT>0)continue;ctx.save();ctx.translate(e.x,e.y-e.r-10);ctx.fillStyle='#ffb84d';ctx.beginPath();ctx.moveTo(-8,4);ctx.lineTo(-8,-4);ctx.lineTo(-3,0);ctx.lineTo(0,-6);ctx.lineTo(3,0);ctx.lineTo(8,-4);ctx.lineTo(8,4);ctx.closePath();ctx.fill();ctx.restore();worldLabel(e.x,e.y-e.r-18,'ВОЖАК','#ffb84d');}
  for(const e of G.enemies){if(!e.alive||!e.peace||e.spawnT>0)continue;ctx.strokeStyle='#7affc9';ctx.globalAlpha=.5;ctx.lineWidth=1;ctx.beginPath();ctx.arc(e.x,e.y,e.r+6,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
  if(G.enemies.some(e=>e.alive&&e.peace&&Math.hypot(e.x-p.x,e.y-p.y)<600)&&p.hp>0)worldLabel(p.x,p.y+34,'КЛИЕНТЫ СОПРОВОЖДАЮТ','#7affc9');
  // холодное ядро
  const a4=WORLD.anomalies.find(q=>q.id==='a4');if(a4&&inView(a4.x,a4.y,480)&&!S.anomalies.a4){const act=G.anom&&G.anom.a===a4;const g=ctx.createRadialGradient(a4.x,a4.y,0,a4.x,a4.y,420);g.addColorStop(0,'rgba(230,246,255,.12)');g.addColorStop(1,'rgba(191,232,255,.02)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(a4.x,a4.y,420,0,TAU);ctx.fill();
    for(let i=1;i<=3;i++){ctx.strokeStyle='#dff6ff';ctx.globalAlpha=.12;ctx.lineWidth=1;ctx.setLineDash([20,30]);ctx.lineDashOffset=t*(10*i)*(i%2?1:-1);ctx.beginPath();ctx.arc(a4.x,a4.y,140*i,0,TAU);ctx.stroke();}ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.globalAlpha=1;
    ctx.save();ctx.translate(a4.x,a4.y);glow(0,0,60,'#ffffff',.4+.2*Math.sin(t*2));ctx.rotate(t*.3);ctx.fillStyle='#dff6ff';ctx.strokeStyle='#ffffff';ctx.lineWidth=2;poly(6,18+Math.sin(t*2)*3,0);ctx.fill();ctx.stroke();ctx.restore();
    if(act){const A=G.anom;if(A.shard){glow(A.shard.x,A.shard.y,30,'#ffb84d',.7);ctx.fillStyle='#ffd36b';ctx.beginPath();ctx.arc(A.shard.x,A.shard.y,10,0,TAU);ctx.fill();worldLabel(A.shard.x,A.shard.y-20,'ТЕПЛО','#ffb84d');}
      ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.25;ctx.setLineDash([8,12]);ctx.beginPath();ctx.arc(a4.x,a4.y,900,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
      for(const e of G.enemies){if(e.alive&&e.tK===.5){ctx.strokeStyle=EDEF[e.type].col;ctx.globalAlpha=.3;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.x-e.vx*.15,e.y-e.vy*.15);ctx.stroke();ctx.globalAlpha=1;}}}}
  // бури (мировые): стена/дымка
  for(const k in w.storms){const s=w.storms[k];if(!s||s.ph==='wait'||s.k<=0||!inView(s.x,s.y,800))continue;const snow=s.kind==='snow';
    ctx.save();ctx.translate(s.x,s.y);ctx.scale(1,400/700);const g=ctx.createRadialGradient(0,0,100,0,0,700);g.addColorStop(0,snow?`rgba(230,240,255,${.18*s.k})`:`rgba(201,106,42,${.14*s.k})`);g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,700,0,TAU);ctx.fill();
    if(SET.fx){ctx.strokeStyle=snow?'rgba(255,255,255,.25)':'rgba(120,60,20,.35)';ctx.lineWidth=snow?8:2;for(let i=0;i<10;i++){const a=t*.3+i*.63,r=200+((i*97+t*40)%400);const x=Math.cos(a)*r,y=Math.sin(a)*r;ctx.globalAlpha=s.k*.5;ctx.beginPath();if(snow){ctx.arc(x,y,40,0,TAU);}else{ctx.moveTo(x,y);ctx.lineTo(x-20,y+60);}ctx.stroke();}}
    ctx.restore();ctx.globalAlpha=1;
    if(s.box&&!s.box.got&&(s.ph==='move'||s.ph==='fade')){glow(s.x,s.y,30,'#ffb84d',.5);ctx.save();ctx.translate(s.x,s.y);ctx.rotate(t);ctx.fillStyle='#1a1206';ctx.strokeStyle='#ffb84d';ctx.lineWidth=2;ctx.fillRect(-12,-9,24,18);ctx.strokeRect(-12,-9,24,18);ctx.restore();worldLabel(s.x,s.y-24,snow?'ЗАМЁРЗШИЙ ГРУЗ':'СМЫТЫЙ КОНТЕЙНЕР','#ffb84d');}}
  secDraw(t);
}
// --- экранные эффекты (после мира, до стрелок) ---
function w58Screen(t){if(!G.w||!G.player)return;const w=G.w,p=G.player,S=G.save;const CW_=cv.width,CH_=cv.height;ctx.setTransform(1,0,0,1,0,0);
  const snow=w58InStorm(p.x,p.y);const inSnow=snow&&snow.kind==='snow'?snow.k:0,inRain=snow&&snow.kind==='rain'?snow.k:0;
  // маска видимости в снегу
  if(inSnow>0){const px=(p.x-CX)*SC*DPR,py=(p.y-CY)*SC*DPR;const R=420*SC*DPR;const g=ctx.createRadialGradient(px,py,R*.8,px,py,R*1.6);g.addColorStop(0,'rgba(220,235,250,0)');g.addColorStop(1,`rgba(220,235,250,${.85*inSnow*COLD_A})`);ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);}
  // иней-виньетка
  const ch=w.chill;if(ch>0){const g=ctx.createRadialGradient(CW_/2,CH_/2,Math.min(CW_,CH_)*.4,CW_/2,CH_/2,Math.max(CW_,CH_)*.72);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,`rgba(200,230,255,${.22*ch*COLD_A*(isMob()?.67:1)})`);ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);}
  if(w.inRust||inRain>0){const g=ctx.createRadialGradient(CW_/2,CH_/2,Math.min(CW_,CH_)*.45,CW_/2,CH_/2,Math.max(CW_,CH_)*.72);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,`rgba(138,58,18,${(w.inRust?.10:.08*inRain)*(isMob()?.67:1)})`);ctx.fillStyle=g;ctx.fillRect(0,0,CW_,CH_);}
  // снежинки / снег / дождь — экранные пулы
  if(SET.fx){const mob=CW<520;
    if(ch>.05||inSnow>0){const n=Math.round((inSnow>0?80:12)*(mob?.5:1)*Math.max(ch,inSnow));if(w.snow.length<n)for(let i=w.snow.length;i<n;i++)w.snow.push({x:Math.random(),y:Math.random(),s:Math.random()});w.snow.length=Math.min(w.snow.length,n);
      ctx.strokeStyle='#ffffff';ctx.lineWidth=1.5*DPR;for(const f of w.snow){f.x=(f.x+(inSnow>0?.25:.02)*(VDT74)+.0003)%1;f.y=(f.y+(.04+f.s*.06)*(VDT74))%1;/* ARCH·75 A-22 */ctx.globalAlpha=(.3+.4*f.s)*(inSnow>0?1:COLD_A);const x=f.x*CW_,y=f.y*CH_;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+(inSnow>0?14:2)*DPR,y+3*DPR);ctx.stroke();}ctx.globalAlpha=1;}
    else w.snow.length=0;
    if(inRain>0){const n=Math.round(70*(mob?.5:1)*inRain);if(w.rain.length<n)for(let i=w.rain.length;i<n;i++)w.rain.push({x:Math.random(),y:Math.random(),s:Math.random()});w.rain.length=Math.min(w.rain.length,n);
      ctx.strokeStyle='#c96a2a';ctx.lineWidth=1*DPR;for(const f of w.rain){f.x=(f.x-.1*(VDT74))%1;if(f.x<0)f.x+=1;f.y=(f.y+(.6+f.s*.3)*(VDT74))%1;/* ARCH·75 A-22 */ctx.globalAlpha=.25+.3*f.s;const x=f.x*CW_,y=f.y*CH_;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-6*DPR,y+22*DPR);ctx.stroke();}ctx.globalAlpha=1;}
    else w.rain.length=0;}
  // иней на корпусе
  if(w.iced&&p.hp>0){const px=(p.x-CX)*SC*DPR,py=(p.y-CY)*SC*DPR;ctx.strokeStyle='rgba(223,246,255,.7)';ctx.lineWidth=1.5*DPR;for(let i=0;i<3;i++){const a=t*1.2+i*TAU/3,x=px+Math.cos(a)*20*SC*DPR,y=py+Math.sin(a)*20*SC*DPR;ctx.beginPath();for(let k=0;k<3;k++){const b=k/3*TAU+a;ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(b)*5*DPR,y+Math.sin(b)*5*DPR);}ctx.stroke();}}
  ctx.setTransform(DPR*SC,0,0,DPR*SC,0,0);
}
// --- карта ---
function w58MapBlobs(g,X,Y,k,vis){if(!W58.gen)return;const ws=w58S();const S=G.save;
  for(const s of W58.shelves){if(!revealedAt(s.x,s.y)||!vis(s.x,s.y,s.r*k))continue;g.fillStyle='rgba(191,232,255,.14)';g.beginPath();s.pts.forEach((q,i)=>i?g.lineTo(X(q.x),Y(q.y)):g.moveTo(X(q.x),Y(q.y)));g.closePath();g.fill();}
  for(const f of W58.rust){if(!revealedAt(f.x,f.y)||!vis(f.x,f.y,f.r*k))continue;g.fillStyle='rgba(201,106,42,.15)';g.beginPath();g.arc(X(f.x),Y(f.y),f.r*k,0,TAU);g.fill();}
  if(G.w)for(const kk in G.w.storms){const s=G.w.storms[kk];if(!s||s.ph==='wait'||s.k<=0)continue;const snow=s.kind==='snow';g.save();g.translate(X(s.x),Y(s.y));g.scale(1,400/700);const gr=g.createRadialGradient(0,0,0,0,0,700*k);gr.addColorStop(0,snow?`rgba(255,255,255,${.35*s.k})`:`rgba(201,106,42,${.35*s.k})`);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.beginPath();g.arc(0,0,700*k,0,TAU);g.fill();g.restore();
    g.strokeStyle=snow?'#ffffff':'#c96a2a';g.globalAlpha=.6;g.lineWidth=1.5;const ex=X(s.x)+Math.cos(s.dir)*14,ey=Y(s.y)+Math.sin(s.dir)*14;g.beginPath();g.moveTo(X(s.x),Y(s.y));g.lineTo(ex,ey);g.stroke();g.globalAlpha=1;}
}
function w58MapAdd(add,lod,S){if(!W58.gen)return;const ws=w58S(),w=G.w;
  if(w58SecOpen())for(const r of W58.recs){if(ws.arcRec.includes(r.id)||!r.seen||r.core)continue;const q=w58RecPos(r);add('arcrec',q.x,q.y,{},lod===2?{t:'ЗАПИСЬ АРХИВА',p:6,c:'#bfe8ff'}:null);}
  if(w58After(11))for(const b of W58.beacons){if(!revealedAt(b.x,b.y))continue;add('arcbeacon',b.x,b.y,{dead:ws.arcBeacons.includes(b.id)},lod>=1?{t:'МАЯК АРХИВА',p:5,c:ws.arcBeacons.includes(b.id)?'#3a4558':'#9fd8ff'}:null);}
  for(const f of W58.rust){if(f.box&&!ws.rustBox.includes(f.id)&&revealedAt(f.x,f.y))add('rustbox',f.x,f.y,{},lod===2?{t:'КОНТЕЙНЕР',p:7,c:'#ffb84d'}:null);}
  if(W58.depot&&w58After(17)&&revealedAt(W58.depot.x,W58.depot.y))add('depot',W58.depot.x,W58.depot.y,{done:!!ws.conveyor.done},lod>=1?{t:'ДЕПО · КОНВЕЙЕР',p:3,c:'#ffb84d'}:null);
  if(ws.wander.seen&&!(w&&w.wander&&w.wander.alive&&false))add('eye',ws.wander.seen.x,ws.wander.seen.y,{},lod===2?{t:'АРХИВАТОР · ПОСЛЕДНИЙ РАЗ',p:7,c:'#9fd8ff'}:null);
  if(w&&w.tug&&w.tug.alive)add('tug',w.tug.x,w.tug.y,{},{t:w.tug.name,p:2,c:'#7affc9'});
}
function w58MapIcon(g,kind,o,t){switch(kind){
    case 'arcrec':g.strokeStyle='#bfe8ff';g.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;g.lineTo(Math.cos(a)*5,Math.sin(a)*5);}g.closePath();g.stroke();return true;
    case 'arcbeacon':g.strokeStyle=o.dead?'#3a4558':'#9fd8ff';g.beginPath();g.moveTo(0,-7);g.lineTo(6,5);g.lineTo(-6,5);g.closePath();g.stroke();if(o.dead){g.beginPath();g.moveTo(-6,-6);g.lineTo(6,6);g.stroke();}return true;
    case 'rustbox':g.strokeStyle='#ffb84d';g.strokeRect(-5,-4,10,8);return true;
    case 'depot':g.strokeStyle=o.done?'#5a4a3a':'#ffb84d';g.strokeRect(-8,-4,16,8);g.beginPath();g.moveTo(-8,0);g.lineTo(8,0);g.stroke();return true;
    case 'eye':g.strokeStyle='#9fd8ff';g.beginPath();g.ellipse(0,0,7,4,0,0,TAU);g.stroke();g.fillStyle='#9fd8ff';g.beginPath();g.arc(0,0,2,0,TAU);g.fill();return true;
    case 'tug':g.fillStyle='#7affc9';g.beginPath();g.arc(0,0,4,0,TAU);g.fill();g.strokeStyle='#7affc9';g.setLineDash([2,2]);g.beginPath();g.moveTo(0,0);g.lineTo(-12,0);g.stroke();g.setLineDash([]);return true;}
  return false;}
// --- карточки POI ---
function w58POI(card){const S=G.save,p=G.player,ws=w58S();
  const D=W58.depot;if(D&&w58After(17)&&!ws.conveyor.done&&!G.anom&&!(G.anomCd&&G.anomCd.conv>G.t)&&Math.hypot(p.x-D.x,p.y-D.y)<260)return {kind:'conv',key:'conv'};
  // контейнеры в ржавых полях
  for(const f of W58.rust){if(!f.box||ws.rustBox.includes(f.id))continue;const d=Math.hypot(p.x-f.x,p.y-f.y);if(d<70){f.rep=(f.rep||0)+arch70Dt();/* ARCH·70 A-9 */G.w.boxing=true;if(f.rep>=3){ws.rustBox.push(f.id);f.rep=0;S.lom+=40;conEvent('rustBox');banner('КОНТЕЙНЕР ВСКРЫТ','+40 ЛОМА НА СКЛАД');sfx('level');saveWorld();}}else{f.rep=Math.max(0,(f.rep||0)-arch70Dt());/* ARCH·70 A-9 */}}
  G.w.boxing=W58.rust.some(f=>f.rep>0);
  // гражданский тайник
  const c=WORLD.caches.find(q=>q.civ);if(c&&!S.found[c.id]&&Math.hypot(p.x-c.x,p.y-c.y)<75){S.found[c.id]=1;S.lom+=120;addPilotXP(20);banner('ТАЙНИК ГРАЖДАНСКИХ','+120 ЛОМА НА СКЛАД · +20 ОПЫТА');sfx('level');explode(c.x,c.y,'#7affc9',30,1);saveWorld();}
  return card;}
function w58Card(card){if(card.kind!=='conv')return '';const first=!w58S().conveyor.done;return `<div class="eyebrow">ДЕПО · ЛИНИЯ УТИЛИЗАЦИИ</div><h3>Спецзадание «Конвейер»</h3><p>Гражданская баржа «Колыбельная» с тремя криокапсулами идёт по ленте утилизации «Обода» через приёмку, сортировку и пресс. Лента не останавливается — расчищайте путь и выведите баржу через аварийный шлюз.</p><p class="note">Награда: ${first?'240':'80'} лома на склад, +${first?'80':'30'} опыта пилота, бонус за целую баржу.</p><div class="wc-row"><button class="wbtn amber" data-act="conv">НАЧАТЬ [F]</button></div>`;}
// --- скины ---
Object.assign(SKINS,{
  archive:{name:'Архивный',col:'#9fd8ff',bul:'#dff6ff',trail:'#bfe8ff',d:'Корпус из картотеки. На борту — инвентарный номер, который никто не выдавал.',unlock:0,find:'СЕКТОР III · ОБЛОМОК'},
  rime:{name:'Наст',col:'#e6f6ff',bul:'#ffffff',trail:'#dff6ff',d:'Тонкий лёд на каркасе. Держится, пока ты движешься.',unlock:0,find:'СЕКТОР III · ХОЛОДНОЕ ЯДРО'}});
HULL_NUM.archive='013';HULL_NUM.rime='014';
function w58DrawSkin(id,t,sp,o,A,fl,edge){
  if(id==='archive'){for(const s of [-1,1]){const x=-14,y=s*6;ctx.fillStyle='#9fd8ff';ctx.globalAlpha=A*.5;for(let i=0;i<3;i++)ctx.fillRect(x-8-i*5-fl*.2,y-1.5,3,3);}ctx.globalAlpha=A;
    ctx.fillStyle='#0b1628';ctx.strokeStyle=edge;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(18,-8);ctx.lineTo(18,8);ctx.lineTo(-16,8);ctx.lineTo(-16,-8);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.strokeStyle='rgba(191,232,255,.6)';ctx.lineWidth=1;for(let i=-3;i<=3;i++){ctx.beginPath();ctx.moveTo(i*4,-6);ctx.lineTo(i*4,-3);ctx.moveTo(i*4,3);ctx.lineTo(i*4,6);ctx.stroke();}
    ctx.strokeStyle=edge;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(-6,-8);ctx.lineTo(-10,-16);ctx.lineTo(2,-16);ctx.moveTo(-6,8);ctx.lineTo(-10,16);ctx.lineTo(2,16);ctx.stroke();
    ctx.fillStyle='#dff6ff';ctx.font='700 5px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText('013',2,2);return true;}
  if(id==='rime'){glow(-12,0,fl,'#dff6ff',.5);ctx.fillStyle='rgba(230,246,255,.35)';ctx.strokeStyle=edge;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(20,0);ctx.lineTo(-10,-7);ctx.lineTo(-6,0);ctx.lineTo(-10,7);ctx.closePath();ctx.fill();ctx.stroke();
    ctx.strokeStyle='#9fd8ff';ctx.lineWidth=1;for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(-2,s*4);ctx.lineTo(-14,s*18);ctx.moveTo(-6,s*5);ctx.lineTo(-18,s*12);ctx.moveTo(2,s*3);ctx.lineTo(-8,s*20);ctx.stroke();}
    if(SET.fx&&sp>60&&Math.random()<.4)part(-14+rnd(-4,4),rnd(-6,6),rnd(-30,0),rnd(-20,20),.5,'#ffffff',1.5);
    ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(6,0,2,0,TAU);ctx.fill();return true;}
  return false;}
// --- панель разработчика мира ---
function w58Dev(k){const w=G.w,p=G.player;if(!w)return;
  if(k==='storm'){const sec=inSectors(p.x,p.y)?sectorIdx(p.x,p.y):2;const s=w.storms[sec]||(w.storms[sec]={sec,kind:sec===2?'snow':'rain',ph:'wait',t:0,k:0,x:0,y:0});s.ph='born';s.t=20;s.k=0;s.x=p.x+600;s.y=p.y;s.dir=Math.PI;s.box=null;w58S()['storm'+sec]=1;}
  if(k==='tug'){w.tug=null;w.tugT=0;w.forceTug=1;w58S().tugs.last=-1e9;}
  if(k==='wander'){if(w.wander)w.wander.alive=false;w.wander=null;w.wanderT=0;}
  if(k==='pack'){w.packs.push({x:p.x+500,y:p.y,st:'roam',t:30,ships:[],dead:0,hostile:storyFlag('obod18')!=='service',hostT:0,uid:++G.uid});}
  if(k==='reset'){G.save.w58=null;w58S();W58.recs.forEach(r=>{r.frozen=r.id===4;r.drift=r.id<4;});}
}


