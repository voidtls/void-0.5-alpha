const G={state:'menu',m:0,t:0,player:null,enemies:[],pb:[],eb:[],pick:[],parts:[],float:[],warns:[],waves:[],waveIdx:0,spawnQ:[],waveT:0,gapT:0,waveSize:1,
  mods:{},st:null,xp:0,lvl:1,need:10,lvlQ:0,bpQ:0,score:0,kills:0,taken:0,mT:0,prio:null,shake:0,hurtV:0,boss:null,endT:0,shock:[],runStart:null,dashId:0,deadT:0,uid:0,
  bc:null,relays:[],rocks:[],fields:[],meteors:[],storm:null,stormT:0,flare:0,fake:null,lureP:null,dashLog:[],dark:false,lightFull:0,jam:null,script:[],evAt:[],evUsed:[],dirT:0,affixCh:0,loseBeacon:false,bcTaken:0,rockN:0,rockT:0};
function need(l){const b=Math.round(6+l*3.6);return G.mode==='endless'?Math.max(3,Math.round(b/1.6)):b;}
function computeStats(){
  const m=G.mods,V=k=>MODS[k].v[m[k]||0];
  G.st={dmg:10*V('cal')*(1+.05*perk('aim')),rate:.27*V('rof'),shots:V('multi')[0],shotK:V('multi')[1],pierce:V('pierce'),speed:290*V('eng')*(G.mode==='world'&&G.save&&G.save.speedBoost?1.15:1),dashCd:Math.max(.9,V('dash')-.15*perk('dash')),
    maxHp:100+V('hull')+10*perk('hull'),mag:V('mag')+25*perk('mag'),ram:V('ram'),shieldCd:V('shield'),drones:V('drone'),eGain:V('pulse')[0]*(1+.15*perk('energy')),pR:V('pulse')[1],
    cargo:V('tractor')+perk('cargo'),sync:V('sync'),rico:V('rico'),phase:V('phase'),light:V('light'),linek:V('linekit')};
  {const aw=arsWeapon();G.st.weapon=aw;G.st.dmg*=arsK(aw,'pow');if(aw==='gun')G.st.rate/=arsK('gun','rate');else G.st.rate*=1.6;G.st.blastR=110*arsK('blast','rad');const wc=$('#wpnC');if(wc)wc.hidden=aw!=='blast';}
  {G.st.dmg*=playerDmgK()*memK90();G.st.maxHp0=G.st.maxHp;if(G.wear>0)G.st.maxHp=Math.max(50,Math.round(G.st.maxHp-G.wear));}/* 0.7.4: урон и максимум прочности — по силе пилота, а не по сектору под кораблём */
}

// ---------- Игрок ----------
function newPlayer(){return{x:W/2,y:H*.7,vx:0,vy:0,r:14,hp:100,en:0,ang:-Math.PI/2,fireT:0,dashCd:0,dashT:0,dx:0,dy:0,inv:1,shieldUp:false,shieldT:0,droneA:0,droneT:[0,0],px:W/2,py:H*.7,trail:[],cargo:0,noDash:0,chg:0,chgCd:0,hitT:-99};}
const KEYS={};const CHG={m:false,t:false};
const MOUSE={sx:0,sy:0,moved:false,down:false};
/* ARCH·81 → aimLockable перенесена в блок «ПОДСИСТЕМА НАВЕДЕНИЯ» после nearestEnemy */
/* ARCH·81 → aimManual перенесена в блок «ПОДСИСТЕМА НАВЕДЕНИЯ» после nearestEnemy */
function mouseWorld(){return{x:MOUSE.sx/SC+CX,y:MOUSE.sy/SC+CY};}
function updateCursor(){cv.style.cursor=(G.state==='play'||G.state==='world')&&SET.manual&&!touchMode?'none':'';}
const joy={on:false,id:null,ox:0,oy:0,x:0,y:0,lx:null,ly:null,locked:false,lockable:false,lockA:0,lockHold:0,fl:[],flT:0};
function inputVec(){
  let x=0,y=0;
  if(KEYS.KeyA||KEYS.ArrowLeft)x--; if(KEYS.KeyD||KEYS.ArrowRight)x++; if(KEYS.KeyW||KEYS.ArrowUp)y--; if(KEYS.KeyS||KEYS.ArrowDown)y++;
  if(joy.on||joy.locked){x+=joy.x;y+=joy.y;}
  if(G.padOn){x+=G.padX;y+=G.padY;}
  const l=Math.hypot(x,y);if(l>1){x/=l;y/=l;}const k80=inputK80();return[x*k80,y*k80];
}
function dashBlocked(){const p=G.player;return p.noDash>0||G.frozen>0||G.lockDash>0||inStorm(p.x,p.y);}
function tryDash(dir){
  const p=G.player;if((G.state!=='play'&&G.state!=='world')||!p||p.dashCd>0||p.hp<=0)return;
  if(dashBlocked()){hintOnce('nodash',p.noDash>0?'РЫВОК ПОДАВЛЕН РАЗРЯДОМ':G.lockDash>0?'РЫВОК НА ХРАНЕНИИ · '+G.lockDash.toFixed(1)+' С':G.frozen>0?'КОРПУС ЗАМЁРЗ':'РЫВОК НЕДОСТУПЕН В БУРЕ','#6bf0ff');return;}
  let [x,y]=dir||inputVec();const l=Math.hypot(x,y);if(l<.1){const da=ARCH.a24&&A24P.dash==='aim'?a24Hull(p):p.ang;/* ARCH·80 A-24 */x=Math.cos(da);y=Math.sin(da);}else{x/=l;y/=l;}
  clearIce();p.dx=x;p.dy=y;p.dashT=.15;p.dashCd=G.st.dashCd*(G.anom&&G.anom.a.kind==='storm'?2:1)*(G.world&&G.chillD||1);p.dashCdMax=p.dashCd;buzz('dash');p.inv=Math.max(p.inv,.22);G.dashId++;sfx('dash');
  G.dashLog.push({t:G.t,x:clamp(p.x+x*225,20,BW-20),y:clamp(p.y+y*225,20,BH-20)});if(G.mc)G.mc.dashes++;
  if(G.st.phase)G.lureP={x:p.x,y:p.y,t:1};
  if(SET.fx)for(let i=0;i<10;i++)part(p.x,p.y,-x*vrnd1(80,260)+vrnd1(-60,60),-y*vrnd1(80,260)+vrnd1(-60,60),.35,(SKINS[curSkin()]||SKINS.base).trail,2.2);
}
function tryPulse(){
  const p=G.player;if((G.state!=='play'&&G.state!=='world')||!p||p.en<100||p.hp<=0)return;
  p.en=0;clearIce();buzz('pulse');if(G.w)G.w.pulsed=1;if(G.mc)G.mc.pulses++;const R=G.st.pR;G.shock.push({x:p.x,y:p.y,r:10,R,t:0,col:'#ffb84d'});if(G.world||inMission()){const X_=x74();X_.spores=X_.spores.filter(s=>Math.hypot(s.x-p.x,s.y-p.y)>R+s.r*.5);pulse80(p,R);}sfx('pulse');shake(10);if(typeof zbPulse==='function')zbPulse(p,R);
  G.eb=G.eb.filter(b=>{if(Math.hypot(b.x-p.x,b.y-p.y)<R){part(b.x,b.y,0,0,.3,'#ffb84d',3);return false;}return true;});
  for(const e of G.enemies.slice()){if(!e.alive||e.spawnT>0||e.down>0||e.ghost)continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<R+e.r){
    if(e.affix&&e.affix.includes('screen')){floater(e.x,e.y-e.r-10,'ЭКРАН','#8fe9ff');continue;}
    hurt(e,e.type==='pylon'||e.type==='antenna'?70:45,{pulse:true});
    if(!HEAVY.has(e.type)){const k=(1-d/(R+e.r))*520;e.vx+=(e.x-p.x)/(d||1)*k;e.vy+=(e.y-p.y)/(d||1)*k;}}}
}
function updatePlayer(dt){
  const p=G.player,st=G.st;p.px=p.x;p.py=p.y;
  if(p.hp<=0)return;
  p.dashCd=Math.max(0,p.dashCd-dt);p.inv=Math.max(0,p.inv-dt);p.noDash=Math.max(0,p.noDash-dt);
  // заряженный выстрел
  p.chgCd=Math.max(0,(p.chgCd||0)-dt);
  const hold=(KEYS.KeyQ||CHG.m||CHG.t||CHG.p)&&chargeAllowed();
  if(hold&&p.chgCd<=0)p.chg=(p.chg||0)+dt;else{if(p.chg>=CHG_T)fireCharged(p);p.chg=0;}
  const spd=st.speed*(p.chg>0?.7:1)*iceSpeedK()*(G.world&&G.chillK||1);
  const [ix,iy]=inputVec();
  if(p.dashT>0){p.dashT-=dt;p.vx=p.dx*1500;p.vy=p.dy*1500;if(p.dashT<=0){p.vx=p.dx*spd;p.vy=p.dy*spd;}}
  else{const k=Math.min(1,dt*(G.slick?(G.slickK||3):11));p.vx+=(ix*spd-p.vx)*k;p.vy+=(iy*spd-p.vy)*k;}
  p.x=clamp(p.x+p.vx*dt,p.r,BW-p.r);p.y=clamp(p.y+p.vy*dt,p.r,BH-p.r);drift85(p,dt);drift90(p,dt);
  if(st.shieldCd>0&&!p.shieldUp&&!(G.lockShield>0)){p.shieldT+=dt*(G.shieldPen>0?.5:1);if(p.shieldT>=st.shieldCd){p.shieldUp=true;p.shieldT=0;}}
  if(SET.fx){p.trail.push({x:p.x,y:p.y,t:p.dashT>0?.25:.12});}
  for(const t of p.trail)t.t-=dt;p.trail=p.trail.filter(t=>t.t>0);
  const man=aimManual();
  const tg=aimStep(p,dt,man);/* ARCH·82: шаги 4–12 — в подсистеме наведения · ARCH·87: ветка отката A-26 снята (1.5.27) */
  p.fireT-=dt;
  const shoot=autoFireWanted(man,tg);/* ARCH·82 · ARCH·87 */
  if(shoot&&p.fireT<=0&&!(p.chg>0)){p.fireT=st.rate*(G.bc&&G.bc.inRing?st.sync:1)*(G.lockGun>0?3:1)*(G.milk75>0?.83:1);fire(p,tg,man?p.ang:undefined);}
  p.droneA+=dt*2.2;
  for(let i=0;i<st.drones;i++){p.droneT[i]-=dt;if(p.droneT[i]<=0){const a=p.droneA+i*Math.PI,dx=p.x+Math.cos(a)*34,dy=p.y+Math.sin(a)*34;
    const t=nearestEnemy(dx,dy,480);if(t){p.droneT[i]=.6;const an=Math.atan2(t.y-dy,t.x-dx);G.pb.push({x:dx,y:dy,px:dx,py:dy,vx:Math.cos(an)*820,vy:Math.sin(an)*820,dmg:6*MODS.cal.v[G.mods.cal||0],pierce:0,rico:0,life:.7,hit:[],drone:true});}else p.droneT[i]=.2;}}
  for(const e of G.enemies){
    if(!e.alive||e.spawnT>0||e.type==='mine'||e.ghost||e.down>0)continue;
    const d=segDist(p.px,p.py,p.x,p.y,e.x,e.y);
    if(e.type==='hull'){if(p.dashT>0&&d<e.r+p.r)kill(e,true);continue;}
    if(d<e.r+p.r*.7){
      if(p.dashT>0&&st.ram>0&&e.ramId!==G.dashId){e.ramId=G.dashId;hurt(e,st.ram,{ram:true});}
      else if(p.dashT<=0&&e.contact>0&&!cg95(e)){if(e.type==='guard'&&SSW()&&SSW().mercy)mercyHit(e.contact);else damagePlayer(e.contact);if(e.type==='seeker'||e.type==='unborn'){kill(e,true);continue;}
        if(!HEAVY.has(e.type)){const a=Math.atan2(e.y-p.y,e.x-p.x);e.vx+=Math.cos(a)*260;e.vy+=Math.sin(a)*260;}}
    }
  }
}
function damagePlayer(d){
  if(devAny()&&G.dev.god)return;if(G.x85&&G.x85.calm>0&&inMission())return;
  const p=G.player;if(!p||p.inv>0||p.dashT>0||p.hp<=0||G.deadT>0)return;
  if(inMission())d*=(curDiff().dmg||1)*missionK('dmg');
  if(G.insp80>0&&(G.world||inMission()))d*=1.2;
  if(p.shieldUp){p.shieldUp=false;p.shieldT=0;p.inv=.45;sfx('shield');for(let i=0;i<16;i++){const a=rnd(0,TAU);part(p.x+Math.cos(a)*22,p.y+Math.sin(a)*22,Math.cos(a)*120,Math.sin(a)*120,.4,'#8fe9ff',2);}return;}
  p.hp-=d;G.taken+=d;p.inv=.75;shake(9);G.hurtV=1;sfx('hurt');p.hitT=G.t;comboBreak();buzz(d>=20?'hit2':'hit');
  if(p.hp<=0&&!lc95(p)){p.hp=0;explode(p.x,p.y,'#8fe9ff',60,1.6);sfx('bigboom');G.deadT=1.6;storyDeath(false);buzz('death');}
}
function shake(v){if(SET.fx){v*=(SET.shake===undefined?1:SET.shake)*(SET.lessFx?.5:1);if(isMob())v*=(RMQ&&RMQ.matches?.3:1)*[.3,.6,1][G.q];G.shake=Math.max(G.shake,v);}}

// ---------- Видимость (тьма) ----------
function beaconLight(){const bc=G.bc;if(!bc)return 0;return (bc.cool>0?210:300)*(1+.04*Math.sin(G.t*3));}
function visibleAt(x,y){
  if(!G.dark||G.lightFull>.5)return true;
  const p=G.player;if(p&&Math.hypot(x-p.x,y-p.y)<G.st.light*.85)return true;
  if(G.bc&&Math.hypot(x-G.bc.x,y-G.bc.y)<beaconLight()*.85)return true;
  return false;
}

// ---------- Стрельба и выбор цели ----------
/* ARCH·81 → targetable перенесена в блок «ПОДСИСТЕМА НАВЕДЕНИЯ» после nearestEnemy */
/* ARCH·85 · снято недостижимое объявление nearestEnemy (1 из 3; действует последнее объявление) */
/* ARCH·81 → pickTarget перенесена в блок «ПОДСИСТЕМА НАВЕДЕНИЯ» после nearestEnemy */
function fire(p,tg,ang){
  const st=G.st,n=st.shots;let base;if(ang!==undefined)base=ang;else{const q=aimPt(tg);base=Math.atan2(q.y-p.y,q.x-p.x);}const spread=.11;
  if(inStorm(p.x,p.y))base+=rnd(-.4,.4);
  const tw=perk('twin')>0&&st.weapon!=='blast';
  for(let i=0;i<n;i++){const a=base+(i-(n-1)/2)*spread;const ma=ARCH.a24&&p===G.player?a24Muz(p,a):p.ang,sx=p.x+Math.cos(ma)*16,sy=p.y+Math.sin(ma)*16;/* ARCH·80 A-24 */
    if(st.weapon==='blast'){G.pb.push({x:sx,y:sy,px:sx,py:sy,vx:Math.cos(a)*620,vy:Math.sin(a)*620,dmg:st.dmg*st.shotK,pierce:0,rico:0,life:.75,hit:[],blast:true,R:st.blastR,age:0});continue;}
    if(tw){for(const o of [-5,5]){const ox=-Math.sin(a)*o,oy=Math.cos(a)*o;G.pb.push({x:sx+ox,y:sy+oy,px:sx+ox,py:sy+oy,vx:Math.cos(a)*980,vy:Math.sin(a)*980,dmg:st.dmg*st.shotK*.65,pierce:st.pierce,rico:st.rico,life:.75,hit:[]});}continue;}
    G.pb.push({x:sx,y:sy,px:sx,py:sy,vx:Math.cos(a)*980,vy:Math.sin(a)*980,dmg:st.dmg*st.shotK,pierce:st.pierce,rico:st.rico,life:.75,hit:[]});}
  sfx('shot');
}
function shootE(x,y,a,spd,dmg,col,r=5,bc=false){if(G.eb.length>=420||w58NoFire(x,y))return null;spd*=ebK();if(G.curE&&G.curE.dmgK90)dmg*=G.curE.dmgK90;const b={x,y,vx:Math.cos(a)*spd,vy:Math.sin(a)*spd,dmg,col,r,life:9,bc};G.eb.push(b);return b;}
// взрыв «Разрыва»: всем в радиусе, сильнее в центре; щиты гвардии и зеркальщиков, купол босса — уважаются; броня сектора — как у обычного снаряда
function blastAt(x,y,R,dmg,charged){
  for(const e of G.enemies){if(!e.alive||e.spawnT>0||e.ghost||e.down>0)continue;if(e.type==='obseg')continue;
    if(e.type==='boss'&&(!G.boss||G.boss.st!=='fight'||bossShielded()))continue;if(e.type==='jam'&&(!G.jam||G.jam.st!=='fight'||jamShielded()))continue;
    if(EDEF[e.type].sbp&&G.sb&&(G.sb.st==='enter'||G.sb.st==='dying'))continue;
    const d=Math.max(0,Math.hypot(e.x-x,e.y-y)-e.r);if(d>R)continue;const a=Math.atan2(y-e.y,x-e.x);
    if(e.type==='guard'&&!(e.shieldDown>0)&&Math.abs(angDiff(a,e.face))<1.05){e.shieldFlash=.12;continue;}
    if(e.type==='mirror'&&Math.abs(angDiff(a,e.face))<1.0){e.shieldFlash=.12;continue;}
    hurt(e,dmg*(1.4-.9*clamp(d/R,0,1)),{blast:true,charged:!!charged});}
  for(const r of G.rocks){if(r.alive&&Math.hypot(r.x-x,r.y-y)<R+r.r)rockHit(r,dmg*.7);}
  if(G.shock.length<60)G.shock.push({x,y,r:6,R,t:0,col:'#9fe3ff',thin:true});explode(x,y,'#9fe3ff',charged?26:12,charged?1.1:.7);sfx('boom');shake(charged?4:1.5);
}
function updateBullets(dt){
  const vx=G.enemies.filter(e=>e.alive&&e.type==='vortex'&&e.spawnT<=0);
  for(const b of G.pb){
    b.px=b.x;b.py=b.y;b.age=(b.age||0)+dt;
    for(const v of vx){const dx=v.x-b.x,dy=v.y-b.y,d=Math.hypot(dx,dy);if(d<240&&d>1){const k=650*(1-d/240)*dt;b.vx+=dx/d*k;b.vy+=dy/d*k;}}
    {const k_=leakK80(b.x,b.y)*bK110(b);b.x+=b.vx*dt*k_;b.y+=b.vy*dt*k_;b.life-=dt*k_;}
    // перебить трос буксира
    for(const e of G.enemies){if(e.type==='tug'&&e.alive&&e.rock&&segInter(b.px,b.py,b.x,b.y,e.x,e.y,e.rock.x,e.rock.y)){releaseTug(e,true);b.life=0;break;}}
    if(b.life<=0)continue;
    // астероиды — укрытие
    for(const r of G.rocks){if(!r.alive)continue;if(segDist(b.px,b.py,b.x,b.y,r.x,r.y)<r.r){if(b.blast){b.life=0;break;}if(b.charged){if(!b.hit.includes(r)){b.hit.push(r);rockHit(r,b.dmg);}continue;}rockHit(r,b.dmg);b.life=0;if(SET.fx)part(b.x,b.y,vrnd1(-60,60),vrnd1(-60,60),.2,'#9fb0c4',2);break;}}
    if(b.life<=0)continue;
    if(G.sb&&G.sb.sbk==='obod'&&G.sb.alive&&obRingBullet(G.sb,b)&&b.life<=0)continue;
    if(b74Hit(b)&&b.life<=0)continue;
    if(G.world&&G.w&&(w58TugHit(b)||w58BeaconHit(b,b.charged)||w58IceRockHit(b,b.charged)||w58RustRockHit(b,b.charged)||w58ConvHit(b))&&b.life<=0)continue;
    for(const e of G.enemies){
      if(b.life<=0)break;if(!e.alive||e.spawnT>0||e.ghost||e.down>0||b.hit.includes(e))continue;
      if(e.type==='boss'&&G.boss&&G.boss.st!=='fight')continue;
      if(e.type==='obseg')continue;if(EDEF[e.type].sbp&&G.sb&&(G.sb.st==='enter'||G.sb.st==='dying'))continue;
      if(e.type==='jam'&&G.jam&&G.jam.st!=='fight')continue;
      if(segDist(b.px,b.py,b.x,b.y,e.x,e.y)>e.r+3)continue;
      if(e.type==='guard'&&!(e.shieldDown>0)){const a=Math.atan2(b.py-e.y,b.px-e.x);if(Math.abs(angDiff(a,e.face))<1.05){b.life=0;sfx('block');if(e.iceGuard){e.cracks=(e.cracks||0)+1;if(e.cracks>=10){e.cracks=0;e.shieldDown=5;floater(e.x,e.y-e.r-12,'ЛЕДЯНОЙ ЩИТ РАСКОЛОТ · 5 С','#dff6ff');}}part(b.x,b.y,rnd(-80,80),rnd(-80,80),.2,'#ffb84d',2);e.shieldFlash=.12;break;}}
      if(e.type==='mirror'){const a=Math.atan2(b.py-e.y,b.px-e.x);if(Math.abs(angDiff(a,e.face))<1.0){b.life=0;sfx('block');e.shieldFlash=.12;const p=G.player;
        shootE(b.x,b.y,Math.atan2(p.y-b.y,p.x-b.x)+rnd(-.15,.15),330,6,'#dfe8ff',4);break;}}
      if(e.type==='boss'&&bossShielded()){b.life=0;sfx('block');part(b.x,b.y,rnd(-60,60),rnd(-60,60),.25,'#b48cff',2);G.boss.domeFlash=.15;break;}
      if(e.type==='jam'&&jamShielded()){b.life=0;sfx('block');part(b.x,b.y,rnd(-60,60),rnd(-60,60),.25,'#4dd0ff',2);G.jam.domeFlash=.15;break;}
      if(b.blast){if(b.age<.06)continue;b.life=0;break;}
      b.hit.push(e);hurt(e,b.dmg,{charged:!!b.charged,drone:!!(b.drone||b.turret),bt95:b.bt95,refl:!!b.refl});
      if(SET.fx)part(b.x,b.y,-b.vx*.08+vrnd1(-50,50),-b.vy*.08+vrnd1(-50,50),.18,'#d8f8ff',1.6);
      if(b.rico>0){let nb=null,nd=260;for(const o of G.enemies){if(o===e||!targetable(o)||b.hit.includes(o)||NOAUTO.has(o.type))continue;const d=Math.hypot(o.x-b.x,o.y-b.y);if(d<nd){nd=d;nb=o;}}
        if(nb){b.rico--;const a=Math.atan2(nb.y-b.y,nb.x-b.x),s=Math.hypot(b.vx,b.vy);b.vx=Math.cos(a)*s;b.vy=Math.sin(a)*s;b.life=Math.max(b.life,.4);b.px=b.x;b.py=b.y;break;}}
      if(b.pierce-->0)continue;b.life=0;
    }
  }
  for(const b of G.pb)if(b.blast&&b.life<=0&&!b.det){b.det=true;blastAt(b.x,b.y,(b.R||G.st.blastR||110)*(b.charged?1.5:1),b.dmg,b.charged);}
  if(G.world)for(const b of G.pb)if(b.life>.5&&!inSectors(b.x,b.y))b.life=.5;
  G.pb=G.pb.filter(b=>b.life>0&&b.x>CX-40&&b.x<CX+W+40&&b.y>CY-40&&b.y<CY+H+40);
  const p=G.player,bc=G.bc;
  for(const b of G.eb){
    for(const v of vx){const dx=v.x-b.x,dy=v.y-b.y,d=Math.hypot(dx,dy);if(d<200&&d>1){const k=120*(1-d/200)*dt;b.vx+=dx/d*k;b.vy+=dy/d*k;}}
    {const A=G.anom;const k=(A&&A.a.kind==='coldcore'&&Math.hypot(b.x-A.a.x,b.y-A.a.y)<420?.5:1)*leakK80(b.x,b.y)*bK110(b);b.x+=b.vx*dt*k;b.y+=b.vy*dt*k;b.life-=dt*k;}
    if(b.homing){const a=Math.atan2(p.y-b.y,p.x-b.x),c=Math.atan2(b.vy,b.vx),n=c+clamp(angDiff(a,c),-1.6*dt,1.6*dt),s=Math.hypot(b.vx,b.vy);b.vx=Math.cos(n)*s;b.vy=Math.sin(n)*s;}
    if(b.rift){if(p.hp>0&&p.dashT<=0&&G.deadT<=0&&segDist(b.x-b.vx*dt,b.y-b.vy*dt,b.x,b.y,p.x,p.y)<13){b.life=0;riftKill();}continue;}
    for(const r of G.rocks){if(r.alive&&Math.hypot(b.x-r.x,b.y-r.y)<r.r+b.r){b.life=0;break;}}
    if(b.life<=0)continue;
    if(bc&&b.bc&&Math.hypot(b.x-bc.x,b.y-bc.y)<bc.r+b.r){b.life=0;
      if(bc.mods.reflect){const a=Math.atan2(-b.vy,-b.vx)+rnd(-.2,.2);G.pb.push({x:b.x,y:b.y,px:b.x,py:b.y,vx:Math.cos(a)*700,vy:Math.sin(a)*700,dmg:8,pierce:0,rico:0,life:.8,hit:[],turret:true});}
      else dmgBeacon(b.dmg,null);continue;}
    if(p.hp>0&&Math.hypot(b.x-p.x,b.y-p.y)<b.r+9){if(p.dashT>0||p.inv>0){continue;}
      if(b.rust){b.life=0;if(p.shieldUp){p.shieldUp=false;p.shieldT=0;}G.shieldPen=10;hintOnce('rustsh','РЖАВЧИНА · ЩИТ СБИТ','#c96a2a');continue;}
      if(b.mercy){mercyHit(b.dmg);b.life=0;continue;}damagePlayer(b.dmg);if(b.frost)addIce(1);if(b.slow95)G.slowP95=Math.max(G.slowP95||0,b.slow95);b.life=0;}}
  G.eb=G.eb.filter(b=>b.life>0&&(b.rift||b.x>CX-60&&b.x<CX+W+60&&b.y>CY-60&&b.y<CY+H+60));
}

// ---------- Враги ----------
function spawnEnemy(type,x,y,o={}){
  const d=EDEF[type];
  const e=Object.assign({type,x,y,vx:0,vy:0,hp:d.hp,maxHp:d.hp,r:d.r,spd:d.spd*rnd(.92,1.08),contact:d.contact,alive:true,t:0,seed:rnd(0,TAU),flash:0,spawnT:0,
    cd:rnd(.8,2),st:'seek',timer:0,dir:Math.random()<.5?-1:1,face:0,shieldK:1,aim:0,uid:++G.uid,buff:1,stun:0,bcT:0,lureT:0,down:0,ghost:false},o);
  if(G.player&&(type==='guard'||type==='mirror'))e.face=Math.atan2(G.player.y-y,G.player.x-x);
  // группа
  if(G.bc&&!e.group){if(d.grp)e.group=d.grp;else if(d.act===1&&!d.passive&&!STATIC.has(type)&&type!=='seeker'){const R=MISSIONS[G.m-1].ratio;e.group=Math.random()<R.siege/(R.siege+R.hunt)?'siege':'hunt';}}
  // аффиксы
  if(AFX_OK.has(type)&&!o.noAffix&&(o.elite||(G.affixCh&&Math.random()<G.affixCh))){const keys=shuffle(Object.keys(AFX));e.affix=[keys[0]];if(o.elite||Math.random()<(G.affix2||0))e.affix.push(keys[1]);
    if(e.affix.includes('armor'))e.armor=3;if(e.affix.includes('fast'))e.spd*=1.35;}
  if(type==='hunter')e.seen=G.t;
  if(inMission()&&!d.passive&&cycHp()>1){e.hp*=cycHp();e.maxHp=e.hp;}
  if(inMission()&&!d.passive&&!d.sb&&!d.fixed&&MISSIONS[G.m-1]&&MISSIONS[G.m-1].hpMul){e.hp*=MISSIONS[G.m-1].hpMul;e.maxHp=e.hp;}
  if(inMission()&&!d.passive){const hk=missionK('hp');if(hk!==1){e.hp*=hk;e.maxHp=e.hp;}}
  {const SS=secScale()||(G.world&&!o.noSec?worldSS(x,y):null);if(SS&&!d.passive&&!d.sb&&!d.fixed&&type!=='boss'&&type!=='jam'){e.hp*=SS.hp;e.spd*=secSpdK(SS,inMission()?curDiff():DIFF.easy);if(SEC_CHASER.has(type)&&G.st)e.spd=Math.min(e.spd,G.st.speed*1.10);e.cd*=atkK();e.secArm=SS.arm;if(e.hp>d.hp*8)e.hp=d.hp*8;e.maxHp=e.hp;}}
  if(G.mode==='endless'&&G.end&&!d.passive&&type!=='boss'&&type!=='jam'){e.hp*=G.end.hpMul;e.maxHp=e.hp;e.spd*=G.end.spdMul;}
  if(!d.passive){const k129=hpX129();if(k129!==1){e.hp*=k129;e.maxHp*=k129;}}
  if(type==='boss'||type==='jam'){if(G.bossMul){e.hp*=G.bossMul;e.maxHp=e.hp;}e.th=[e.maxHp*2/3,e.maxHp/3,0];}
  if(type==='twin'&&o.pair){const mate=G.enemies.find(q=>q.type==='twin'&&q.pair===o.pair&&q.alive&&!q.mate);if(mate){mate.mate=e;e.mate=mate;}}
  if(G.x90&&inMission()&&(G.x90.sec===8||G.x90.sec===9))e.cg95=G.t+(e.spawnT||0)+.6;
  G.enemies.push(e);
  if(type==='cruiser'){e.ang=Math.atan2(H/2-y,W/2-x);e.parts=[];[['eng',-34,-16],['eng',-34,16],['gun',35,0]].forEach(([role,ox,oy])=>{const q=spawnEnemy('cpart',x,y,{role,ox,oy,host:e,group:'siege',noAffix:true});e.parts.push(q);});}
  if(d.desc&&!REC.seen.includes(type)){REC.seen.push(type);saveRec();}
  return e;
}
function edgeSpawn(type,o={}){if(spawn95(type,o))return;if(spawn110(type,o))return;
  const p=G.player;let x,y,mx,my,tries=0;
  do{const s=o.side!==undefined?o.side:Math.random()*4|0;const u=clamp(o.u!==undefined?o.u:Math.random(),.03,.97);
    if(s===0){x=u*W;y=-34;mx=x;my=22;}else if(s===1){x=W+34;y=u*H;mx=W-22;my=y;}else if(s===2){x=u*W;y=H+34;mx=x;my=H-22;}else{x=-34;y=u*H;mx=22;my=y;}
  }while(o.side===undefined&&Math.hypot(mx-p.x,my-p.y)<240&&++tries<8);
  G.warns.push({x,y,mx,my,type,t:.7+(o.delay||0),o});
}
function steer(e,dx,dy,spd,dt,k){const l=Math.hypot(dx,dy)||1;const q=Math.min(1,k*dt*(e.slick?.3:1));e.vx+=(dx/l*spd-e.vx)*q;e.vy+=(dy/l*spd-e.vy)*q;}
const onScreen=e=>e.x>CX&&e.x<CX+W&&e.y>CY&&e.y<CY+H;
function enemyTarget(e){{const q90=cloak90(e)||witT100(e)||door90(e);if(q90)return q90;}
  const p=G.player,bc=G.bc;if(e.boatAtk&&G.w74b&&G.w74b.alive)return G.w74b;if(e.tugAtk&&G.w&&G.w.tug&&G.w.tug.alive&&G.w.tug.st!=='rob')return G.w.tug;
  if(!bc||!e.group)return p;
  if(e.group==='siege'){
    if(G.fake&&e.uid%2===0)return G.fake;
    if(!EDEF[e.type].noRet&&p.hp>0&&Math.hypot(p.x-e.x,p.y-e.y)<110)return p;
    return bc;}
  if(e.group==='hunt'){if(G.lureP)return G.lureP;if(e.lureT>0)return bc;}
  return p;
}
function settle(e,dt,margin){if(e.sx===undefined){e.sx=clamp(e.x,margin,W-margin);e.sy=clamp(e.y,margin,H-margin);}
  const dx=e.sx-e.x,dy=e.sy-e.y;if(Math.hypot(dx,dy)>6)steer(e,dx,dy,110,dt,3);else{e.vx*=.8;e.vy*=.8;}}
function updateEnemies(dt){
  G.eSpd=inMission()?(curDiff().spd||1)*missionK('spd'):1;G.atkK=atkK()/missionK('rate');
  const p=G.player,bc=G.bc;
  for(const e of G.enemies){e.shieldK=1;e.linkBy=null;e.buff=1;}
  for(const s of G.enemies){if(s.type!=='shielder'||!s.alive)continue;s.links=[];
    const c=PERF.off['O-3']?G.enemies.filter(o=>o.alive&&o!==s&&o.type!=='shielder'&&!HEAVY.has(o.type)&&o.type!=='moth'&&Math.hypot(o.x-s.x,o.y-s.y)<240).sort((a,b)=>Math.hypot(a.x-s.x,a.y-s.y)-Math.hypot(b.x-s.x,b.y-s.y)).slice(0,3):o3Near(s);/* PERF·OPT O-3 */
    for(const o of c){o.shieldK=.35;o.linkBy=s;s.links.push(o);}}
  for(const c of G.enemies){if(c.type!=='commander'||!c.alive||c.spawnT>0)continue;{const f3=!PERF.off['O-3'],cx=c.x,cy=c.y;for(const o of G.enemies){if(f3){const dx=o.x-cx,dy=o.y-cy;if(dx>=220||dx<=-220||dy>=220||dy<=-220)continue;}if(o!==c&&o.alive&&!HEAVY.has(o.type)&&Math.hypot(o.x-c.x,o.y-c.y)<220)o.buff=1.25;}}/* PERF·OPT O-3 */}s74Buffs();buffs90();
  const gm=G.flare>0?1.25:1;
  for(const e of G.enemies){
    if(!e.alive)continue;
    e.t+=dt;if(e.flash>0)e.flash-=dt;if(e.shieldFlash>0)e.shieldFlash-=dt;if(e.bcT>0)e.bcT-=dt;if(e.lureT>0)e.lureT-=dt;
    if(e.spawnT>0){e.spawnT-=dt;if(e.type==='pylon'&&G.boss){e.x=G.boss.x+Math.cos(e.orb)*e.R;e.y=G.boss.y+Math.sin(e.orb)*e.R*.8;}continue;}
    if(e.down>0){e.down-=dt;e.vx*=.9;e.vy*=.9;e.x+=e.vx*dt;e.y+=e.vy*dt;if(e.down<=0){e.hp=e.maxHp*.5;floater(e.x,e.y-20,'ВОССТАНОВЛЕН','#ff6bd0');}continue;}
    if(e.stun>0&&!STATIC.has(e.type)){e.stun-=dt;e.vx*=.9;e.vy*=.9;e.x+=e.vx*dt;e.y+=e.vy*dt;continue;}
    if(e.retreat){storyRetreatMove(e,dt);continue;}
    const dtS=dt;if(e.tK&&e.tK!==1)dt=dt*e.tK;
    const T=enemyTarget(e);
    const dx=T.x-e.x,dy=T.y-e.y,d=Math.hypot(dx,dy)||1,ux=dx/d,uy=dy/d;
    const pdx=p.x-e.x,pdy=p.y-e.y,pd=Math.hypot(pdx,pdy)||1;
    const sm=e.buff*gm,toBc=!!T.isBc;
    const cd0=e.cd;G.curE=e;
    if(!secEnemyUpdate(e,dt,{ux,uy,d,sm,T,pd}))switch(e.type){
      case 'scout':case 'mite':{const w=Math.sin(e.t*3+e.seed)*.55;steer(e,ux-uy*w,uy+ux*w,e.spd*sm,dt,3.5);break;}
      case 'gunner':{const m=clamp((d-270)/120,-1,1);steer(e,ux*m-uy*.6*e.dir,uy*m+ux*.6*e.dir,e.spd*sm,dt,3);
        if(Math.random()<dt*.2)e.dir*=-1;e.cd-=dt;e.charging=e.cd<.4;
        if(e.cd<=0){if(onScreen(e))shootE(e.x,e.y,Math.atan2(dy,dx),275,10,'#ff9a4d',5,toBc);e.cd=rnd(1.7,2.2);}break;}
      case 'rammer':{
        if(e.st==='seek'){steer(e,ux,uy,e.spd*sm,dt,3);e.cd-=dt;if(e.cd<=0&&d<470&&onScreen(e)){e.st='aim';e.timer=.85;e.aim=Math.atan2(dy,dx);}}
        else if(e.st==='aim'){e.vx*=.88;e.vy*=.88;if(e.timer>.22)e.aim+=clamp(angDiff(Math.atan2(dy,dx),e.aim),-3*dt,3*dt);e.timer-=dt;
          if(e.timer<=0){e.st='charge';e.timer=.55;e.vx=Math.cos(e.aim)*660;e.vy=Math.sin(e.aim)*660;}}
        else if(e.st==='charge'){e.timer-=dt;if(SET.fx&&vR3()<.6)part(e.x,e.y,vrnd3(-30,30),vrnd3(-30,30),.3,'#ff4545',2.5);if(e.timer<=0){e.st='rest';e.timer=.7;}}
        else{e.vx*=.92;e.vy*=.92;e.timer-=dt;if(e.timer<=0){e.st='seek';e.cd=rnd(1.5,2.5);}}
        break;}
      case 'splitter':steer(e,ux,uy,e.spd*sm,dt,2);break;
      case 'miner':{
        if(!e.tx||Math.hypot(e.tx-e.x,e.ty-e.y)<30){let tries=0;do{e.tx=rnd(80,W-80);e.ty=rnd(80,H-80);}while(Math.hypot(e.tx-p.x,e.ty-p.y)<200&&++tries<6);}
        steer(e,e.tx-e.x,e.ty-e.y,e.spd*sm,dt,2);e.cd-=dt;
        if(e.cd<=0&&onScreen(e)){e.cd=rnd(2.4,3.1);spawnEnemy('mine',e.x,e.y,{arm:.95,fuse:0,life:13,noAffix:true});}break;}
      case 'mine':{
        e.vx*=.9;e.vy*=.9;e.arm-=dt;e.life-=dt;
        if(e.arm<=0&&!e.fuse&&pd<64){e.fuse=.42;sfx('warn');}
        if(e.fuse>0){e.fuse-=dt;if(e.fuse<=0){mineBlast(e,82,20);}}
        if(e.life<=0&&e.alive){e.alive=false;part(e.x,e.y,0,0,.4,'#ffd24d',4);}
        break;}
      case 'shielder':{
        const allies=G.enemies.filter(o=>o.alive&&o!==e&&o.type!=='mine'&&o.type!=='shielder'&&o.type!=='moth');
        let cx=0,cy=0;allies.forEach(o=>{cx+=o.x;cy+=o.y;});
        const pux=pdx/pd,puy=pdy/pd;let tx,ty;if(allies.length){cx/=allies.length;cy/=allies.length;tx=cx-pux*110;ty=cy-puy*110;}else{tx=e.x-pux*100;ty=e.y-puy*100;}
        if(pd<260){tx=e.x-pux*200;ty=e.y-puy*200;}
        tx=clamp(tx,40,W-40);ty=clamp(ty,40,H-40);steer(e,tx-e.x,ty-e.y,e.spd*sm,dt,2);break;}
      case 'lancer':{
        if(e.st==='seek'){const m=clamp((d-400)/140,-1,1);steer(e,ux*m-uy*.5*e.dir,uy*m+ux*.5*e.dir,e.spd*sm,dt,2.5);e.cd-=dt;
          if(e.cd<=0&&onScreen(e)){e.st='aim';e.timer=1.15;e.aim=Math.atan2(dy,dx)+rnd(-.4,.4);}}
        else if(e.st==='aim'){e.vx*=.9;e.vy*=.9;e.aim+=clamp(angDiff(Math.atan2(dy,dx),e.aim),-1.5*dt,1.5*dt);e.timer-=dt;if(e.timer<=0){e.st='lock';e.timer=.3;sfx('warn');}}
        else if(e.st==='lock'){e.timer-=dt;if(e.timer<=0){e.st='fire';e.timer=.2;e.hitDone=false;}}
        else if(e.st==='fire'){e.timer-=dt;if(!e.hitDone){e.hitDone=true;const ex=e.x+Math.cos(e.aim)*1800,ey=e.y+Math.sin(e.aim)*1800;
            if(segDist(e.x,e.y,ex,ey,p.x,p.y)<17){if(G.mc&&p.inv<=0&&p.dashT<=0)G.mc.lanceHits++;damagePlayer(20);}
            else if(bc&&toBc&&segDist(e.x,e.y,ex,ey,bc.x,bc.y)<bc.r+4)dmgBeacon(20,e);shake(4);}
          if(e.timer<=0){e.st='seek';e.cd=rnd(3,3.8);}}
        break;}
      case 'guard':{
        e.face+=clamp(angDiff(Math.atan2(dy,dx),e.face),-1.35*dt,1.35*dt);
        const m=clamp((d-190)/100,-1,1);steer(e,ux*m,uy*m,e.spd*sm,dt,2);
        e.cd-=dt;if(e.cd<=0){e.cd=rnd(2.4,2.9);if(onScreen(e))for(let i=-1;i<=1;i++)shootE(e.x+Math.cos(e.face)*22,e.y+Math.sin(e.face)*22,e.face+i*.22,240,11,'#ffb84d',6,toBc);}
        break;}
      case 'pylon':{const b=G.boss;if(!b){e.alive=false;break;}e.orb+=dt*(.45+.15*b.phase)*e.dir;e.x=b.x+Math.cos(e.orb)*e.R;e.y=b.y+Math.sin(e.orb)*e.R*.8;e.vx=e.vy=0;
        if(b.phase>=2&&b.over<=0){e.cd-=dt;if(e.cd<=0){e.cd=rnd(3.8,4.8);for(let i=0;i<6;i++)shootE(e.x,e.y,i/6*TAU+e.orb,135,9,'#b48cff',5);}}break;}
      case 'seeker':{const c=Math.atan2(e.vy,e.vx);const n=c+clamp(angDiff(Math.atan2(pdy,pdx),c),-2.2*dt,2.2*dt);const s=Math.min(e.spd,Math.hypot(e.vx,e.vy)+300*dt);e.vx=Math.cos(n)*s;e.vy=Math.sin(n)*s;
        e.life-=dt;if(e.life<=0)kill(e,true);break;}
      case 'boss':updateBoss(e,dt);break;
      // ---- Акт II ----
      case 'moth':{const w=Math.sin(e.t*7+e.seed)*.9;steer(e,ux-uy*w,uy+ux*w,e.spd*sm,dt,3);break;}
      case 'leech':{
        if(!bc){steer(e,pdx,pdy,e.spd,dt,3);break;}
        if(e.att){e.ang+=dt*.3;e.x=bc.x+Math.cos(e.ang)*(bc.r+6);e.y=bc.y+Math.sin(e.ang)*(bc.r+6);e.vx=e.vy=0;}
        else{steer(e,bc.x-e.x,bc.y-e.y,e.spd*sm,dt,3);if(Math.hypot(bc.x-e.x,bc.y-e.y)<bc.r+e.r+4){e.att=true;e.ang=Math.atan2(e.y-bc.y,e.x-bc.x);floater(e.x,e.y-14,'ПИЯВКА НА МАЯКЕ','#c46bff');}}
        break;}
      case 'carrier':{
        if(d>230)steer(e,ux,uy,e.spd*sm,dt,2);else steer(e,-uy*e.dir,ux*e.dir,e.spd*sm,dt,2);
        e.cd-=dt;if(d<270&&e.cd<=0&&onScreen(e)){e.cd=6;for(let i=0;i<4;i++){const a=i/4*TAU;const m=spawnEnemy('moth',e.x+Math.cos(a)*12,e.y+Math.sin(a)*12,{group:'siege'});m.vx=Math.cos(a)*160;m.vy=Math.sin(a)*160;}}
        break;}
      case 'jammerS':settle(e,dt,60);break;
      case 'hive':{settle(e,dt,70);e.cd-=dt;if(e.cd<=0&&onScreen(e)){e.cd=4;for(let i=0;i<2;i++){const m=spawnEnemy('moth',e.x+rnd(-14,14),e.y+rnd(-14,14),{group:'siege'});m.vx=rnd(-120,120);m.vy=rnd(-120,120);}}break;}
      case 'cutter':{
        const L=nearestLine(e);
        if(!L){steer(e,pdx,pdy,e.spd*sm,dt,3);break;}
        const q=segPoint(L.x,L.y,bc.x,bc.y,e.x,e.y),qd=Math.hypot(q.x-e.x,q.y-e.y);
        if(qd<16){e.vx*=.7;e.vy*=.7;e.cutT=(e.cutT||0)+dt;e.cutting=true;if(e.cutT>.9){L.cut=true;L.rep=0;e.cutT=0;floater(q.x,q.y-12,'ЛИНИЯ ПЕРЕРЕЗАНА','#ff4f6e');sfx('warn');}}
        else{e.cutT=0;e.cutting=false;steer(e,q.x-e.x,q.y-e.y,e.spd*sm,dt,4);}
        break;}
      case 'tug':{
        if(e.rock&&!e.rock.alive)e.rock=null;
        e.cd-=dt;
        if(!e.rock){
          let r=null,rd=1e9;if(e.cd<=0)for(const k of G.rocks){if(!k.alive||k.tow||k.flung)continue;const q=Math.hypot(k.x-e.x,k.y-e.y);if(q<rd){rd=q;r=k;}}
          if(r){steer(e,r.x-e.x,r.y-e.y,e.spd*sm,dt,3);if(rd<r.r+e.r+10){e.rock=r;r.tow=e;}}
          else steer(e,ux,uy,e.spd*sm,dt,2);
        }else{
          const r=e.rock;steer(e,ux,uy,e.spd*.8*sm,dt,2);
          const ddx=r.x-e.x,ddy=r.y-e.y,dl=Math.hypot(ddx,ddy)||1,L=r.r+e.r+30;if(dl>L){r.x=e.x+ddx/dl*L;r.y=e.y+ddy/dl*L;}r.vx=e.vx;r.vy=e.vy;
          if(bc&&toBc&&Math.hypot(bc.x-e.x,bc.y-e.y)<270){const a=Math.atan2(bc.y-r.y,bc.x-r.x);r.vx=Math.cos(a)*240;r.vy=Math.sin(a)*240;r.flung=true;r.tow=null;e.rock=null;e.cd=4;e.vx=-ux*120;e.vy=-uy*120;sfx('warn');}
        }
        break;}
      case 'mortar':{
        const m=clamp((d-430)/120,-1,1);steer(e,ux*m-uy*.5*e.dir,uy*m+ux*.5*e.dir,e.spd*sm,dt,2);
        e.cd-=dt;if(e.cd<=0&&onScreen(e)){e.cd=rnd(3.6,4.4);spawnEnemy('shell',e.x,e.y,{sx:e.x,sy:e.y,tx:T.x+rnd(-10,10),ty:T.y+rnd(-10,10),ft:0,dur:1.6,toBc,h:0,noAffix:true});}
        break;}
      case 'shell':{e.ft+=dt;const k=Math.min(1,e.ft/e.dur);e.x=e.sx+(e.tx-e.sx)*k;e.y=e.sy+(e.ty-e.sy)*k;e.h=Math.sin(Math.PI*k)*90;if(k>=1)shellLand(e);break;}
      case 'phantom':{e.ghost=((e.t+e.seed)%4)<1.6;const w=Math.sin(e.t*2+e.seed)*.4;steer(e,ux-uy*w,uy+ux*w,e.spd*sm,dt,3);break;}
      case 'shade':{
        if(e.st==='dash'){e.timer-=dt;if(e.timer<=0){e.st='seek';e.cd=rnd(2,3);}}
        else if(e.st==='rev'){e.vx*=.85;e.vy*=.85;e.timer-=dt;if(e.timer<=0){e.st='dash';e.timer=.35;const a=Math.atan2(dy,dx);e.vx=Math.cos(a)*560;e.vy=Math.sin(a)*560;}}
        else{steer(e,ux,uy,e.spd*sm,dt,3);e.cd-=dt;if(e.cd<=0&&d<180){e.st='rev';e.timer=.5;}}
        e.reveal=e.st==='rev'||e.st==='dash'?1:0;break;}
      case 'mirror':{
        e.face+=clamp(angDiff(Math.atan2(pdy,pdx),e.face),-1.2*dt,1.2*dt);
        const m=clamp((d-160)/100,-1,1);steer(e,ux*m,uy*m,e.spd*sm,dt,2);break;}
      case 'shocker':{
        if(e.st==='charge'){e.vx*=.85;e.vy*=.85;e.timer-=dt;if(e.timer<=0){e.st='seek';e.cd=rnd(3,4);G.fields.push({x:e.x,y:e.y,r:115,t:.45,max:.45,hit:false});sfx('warn');}}
        else{const m=clamp((d-150)/100,-1,1);steer(e,ux*m-uy*.5*e.dir,uy*m+ux*.5*e.dir,e.spd*sm,dt,3);e.cd-=dt;if(e.cd<=0&&d<230){e.st='charge';e.timer=.6;}}
        break;}
      case 'vortex':{const tx=bc?(p.x+bc.x)/2:p.x,ty=bc?(p.y+bc.y)/2:p.y;steer(e,tx-e.x,ty-e.y,e.spd*sm,dt,1.5);break;}
      case 'twin':{const m=clamp((d-210)/100,-1,1);steer(e,ux*m-uy*.7*e.dir,uy*m+ux*.7*e.dir,e.spd*sm,dt,3);
        e.cd-=dt;if(e.cd<=0){e.cd=rnd(2.2,2.8);if(onScreen(e))shootE(e.x,e.y,Math.atan2(dy,dx),260,9,'#ff6bd0',5,toBc);}break;}
      case 'thief':{
        if(e.flee){steer(e,e.fx-e.x,e.fy-e.y,e.spd*1.1,dt,3);if(e.x<-40||e.x>BW+40||e.y<-40||e.y>BH+40){e.alive=false;if(e.loot)floater(e.x,e.y,'ПОХИТИТЕЛЬ УШЁЛ','#9dff6b');}break;}
        if(p.cargo>0&&p.hp>0){steer(e,pdx,pdy,e.spd*sm,dt,4);if(pd<e.r+p.r+6){p.cargo--;e.loot=(e.loot||0)+1;startFlee(e);floater(p.x,p.y-26,'ГРУЗ ПОХИЩЕН','#9dff6b');sfx('warn');}}
        else{let c=null,cd=1e9;for(const k of G.pick){if(k.k!=='cell'||k.life<=0)continue;const q=Math.hypot(k.x-e.x,k.y-e.y);if(q<cd){cd=q;c=k;}}
          if(c){steer(e,c.x-e.x,c.y-e.y,e.spd*sm,dt,4);if(cd<16){c.life=0;e.loot=(e.loot||0)+1;startFlee(e);}}
          else{const m=clamp((pd-220)/100,-1,1);steer(e,pdx/pd*m-pdy/pd*.8*e.dir,pdy/pd*m+pdx/pd*.8*e.dir,e.spd*.7*sm,dt,3);}}
        break;}
      case 'hunter':{
        if(e.dT>0){e.dT-=dt;if(SET.fx)part(e.x,e.y,vrnd3(-30,30),vrnd3(-30,30),.25,'#ff2e4a',2);}
        else{steer(e,ux,uy,e.spd*sm,dt,3);
          for(const ev of G.dashLog){if(ev.t>e.seen&&G.t-ev.t>=.5){e.seen=ev.t;const a=Math.atan2(ev.y-e.y,ev.x-e.x);e.vx=Math.cos(a)*1150;e.vy=Math.sin(a)*1150;e.dT=.2;break;}}}
        e.cd-=dt;if(e.cd<=0&&onScreen(e)){e.cd=rnd(2.2,2.8);shootE(e.x,e.y,Math.atan2(dy,dx),300,10,'#ff2e4a',5,toBc);}
        break;}
      case 'commander':{if(d>300)steer(e,ux,uy,e.spd*sm,dt,2);else steer(e,-uy*e.dir,ux*e.dir,e.spd*.6,dt,2);break;}
      case 'cruiser':{
        const eng=e.parts.filter(q=>q.alive&&q.role==='eng').length;const spd=e.spd*(eng===2?1:eng===1?.55:.3)*sm;
        if(d>230)steer(e,ux,uy,spd,dt,1.5);else{e.vx*=.95;e.vy*=.95;}
        e.ang+=clamp(angDiff(Math.atan2(dy,dx),e.ang),-.8*dt,.8*dt);
        const gun=e.parts.find(q=>q.role==='gun'&&q.alive);
        e.cd-=dt;if(gun&&e.cd<=0&&onScreen(e)){e.cd=2.2;const a=Math.atan2(T.y-gun.y,T.x-gun.x);for(let i=-1;i<=1;i++)shootE(gun.x,gun.y,a+i*.12,230,12,'#ff7a5a',6,toBc);}
        break;}
      case 'cpart':{const h=e.host;if(!h||!h.alive){kill(e,true);break;}const c=Math.cos(h.ang),s=Math.sin(h.ang);e.x=h.x+c*e.ox-s*e.oy;e.y=h.y+s*e.ox+c*e.oy;break;}
      case 'antenna':break;
      case 'decoy':break;
      case 'crate':{if(onScreen(e))e.entered=true;else if(e.entered)e.alive=false;break;}
      case 'jam':updateJam(e,dt);break;
    }
    if(G.atkK<1&&e.cd>cd0+1e-6&&!e.sbk)e.cd=cd0>0?cd0+(e.cd-cd0)*G.atkK:e.cd*G.atkK;
    if(!STATIC.has(e.type)&&!(e.type==='leech'&&e.att)&&!e.stuck){e.x+=e.vx*dt*G.eSpd;e.y+=e.vy*dt*G.eSpd;
      if(e.type==='rammer'&&e.st==='charge'){if(e.x<e.r||e.x>BW-e.r){e.vx*=-.6;e.x=clamp(e.x,e.r,BW-e.r);}if(e.y<e.r||e.y>BH-e.r){e.vy*=-.6;e.y=clamp(e.y,e.r,BH-e.r);}}}
    dt=dtS;
  }
  G.curE=null;
  // разведение
  const es=G.enemies;
  const sep=e=>e.alive&&!STATIC.has(e.type)&&e.type!=='mine'&&!(e.type==='leech'&&e.att)&&e.down<=0&&!e.zbHide;
  if(!PERF.off['O-3'])o3Sep(es,sep);else{/* PERF·OPT O-3: старый путь */
  for(let i=0;i<es.length;i++){const a=es[i];if(!sep(a))continue;
    for(let j=i+1;j<es.length;j++){const b=es[j];if(!sep(b))continue;
      const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy),m=a.r+b.r+2;if(d>0&&d<m){const k=(m-d)/d*.5;a.x-=dx*k;a.y-=dy*k;b.x+=dx*k;b.y+=dy*k;}}}
  }
  if(!G.world)for(const e of es){if(!e.alive||STATIC.has(e.type)||e.type==='thief'&&e.flee||e.retreat||e.type==='crate')continue;const mg=120;if(e.x<-mg||e.x>BW+mg||e.y<-mg||e.y>BH+mg){e.x=clamp(e.x,-mg,BW+mg);e.y=clamp(e.y,-mg,BH+mg);}}
  G.enemies=G.enemies.filter(e=>e.alive);
}
function startFlee(e){e.flee=true;const cx=e.x<W/2?-80:W+80;e.fx=cx;e.fy=e.y;}
function mineBlast(e,R,pd){
  e.alive=false;const p=G.player;G.shock.push({x:e.x,y:e.y,r:8,R,t:0,col:'#ffd24d'});explode(e.x,e.y,'#ffd24d',22,.9);sfx('boom');shake(6);
  if(p&&Math.hypot(p.x-e.x,p.y-e.y)<R+p.r*.5)damagePlayer(pd);
  for(const o of G.enemies)if(o.alive&&o!==e&&!STATIC.has(o.type)&&o.type!=='mine'&&Math.hypot(o.x-e.x,o.y-e.y)<R)hurt(o,30,{});
}
function shellLand(e){
  e.alive=false;const p=G.player,bc=G.bc;explode(e.tx,e.ty,'#ff8f5a',12,.7);sfx('boom');
  const pd=Math.hypot(p.x-e.tx,p.y-e.ty);
  if(e.toBc&&bc){if(pd<34&&p.hp>0){damagePlayer(6);floater(p.x,p.y-24,'ЗАКРЫЛИ МАЯК','#ffb84d');}else if(Math.hypot(e.tx-bc.x,e.ty-bc.y)<bc.r+14)dmgBeacon(16,null);}
  else if(pd<44)damagePlayer(12);
}
function hurt(e,dmg,src){
  if(!e.alive||e.down>0)return;if(e.zb){zbHurt(e,dmg,src);return;}if(e.retreat&&mercySurrender(e))return;
  if(e.type==='boss'){const b=G.boss;if(!b||b.st!=='fight')return;if(bossShielded()&&!src.force)return;if(b.over>0)dmg*=1.5;}
  else if(e.type==='jam'){const j=G.jam;if(!j||j.st!=='fight'||jamShielded())return;}
  else if(e.dig!==undefined){dmg=w58DigHurt(e,dmg);if(dmg<=0)return;}
  else if(EDEF[e.type].sbp){dmg=sbHurt(e,dmg,src);if(dmg<=0)return;}
  if(H74.has(e.type)||e.n74){dmg=s74Hurt(e,dmg,src);if(dmg<=0)return;}
  if(e.peace&&G.world)w58CopyHurt(e);
  else dmg*=e.shieldK;
  if(e.secArm&&!(e.noArm>0)&&!src.pulse)dmg*=1-e.secArm;
  if(e.armor>0&&!src.pulse&&!src.ram){e.armor--;e.flash=.07;sfx('block');part(e.x,e.y,rnd(-60,60),rnd(-60,60),.2,'#cfd8e6',2);return;}
  if(G.x90&&inMission()){if(G.x90.pud.length)dmg*=pud90K(e);if(e.weak95>0&&!S90T.has(e.type))dmg*=weakK95(e);if(G.x90.sec>=9)dl100(e,dmg);}
  e.hp-=dmg;e.flash=.07;sfx('hit');
  if(e.type==='boss'){const b=G.boss;const th=e.th[b.phase-1];if(b.phase<3&&e.hp<=th){e.hp=th;phaseShift(b);}}
  if(e.type==='jam'){const th=e.th[e.phase-1];if(e.phase<3&&e.hp<=th){e.hp=th;jamPhase(e);}}
  if(e.sbk)sbCheckTh(e);
  if(e.hp>0)storyRetreatRoll(e);
  if(e.hp<=0){if(src&&src.charged)e.lastCh=true;kill(e);}
}
function dropCell(x,y,stab=2){G.pick.push({k:'cell',x,y,vx:rnd(-40,40),vy:rnd(-40,40),r:9,t:0,stab,life:20});}
function kill(e,silent){
  if(!e.alive)return;if(e.rebuilt)silent=true;if(e.type==='loop'&&!silent&&loopIntercept80(e))return;
  // Близнецы: если напарник жив и не повержен — уходим в восстановление
  if(e.type==='twin'&&!silent&&e.mate&&e.mate.alive&&!(e.mate.down>0)){e.down=3;e.hp=0;prioClear(e);explode(e.x,e.y,'#ff6bd0',8,.6);floater(e.x,e.y-18,'ВОССТАНОВЛЕНИЕ 3 С','#ff6bd0');return;}
  e.alive=false;const d=EDEF[e.type];storyRetreatKilled(e);
  if(e.type==='invcell'&&e.dig!==undefined)w58DigDied(e);else if(e.type==='invcell')invCellDied(e);else if(e.type==='invcore')invCoreDied(e);else if(e.type==='obseg')obSegDied(e);
  if(e.wander&&G.w)w58WanderDied(e);
  s74Killed(e,silent);s75Killed(e,silent);s80Killed(e,silent);s85Killed(e,silent);s90Killed(e,silent);
  if(G.prio===e){prioSet(null);if(G.mc&&!silent)G.mc.prioKills++;}
  if(e.type==='boss'){bossDeath(e);return;}
  if(e.type==='jam'){jamDeath(e);return;}
  if(e.sbk){sbDeath(e);return;}
  const big=e.type==='guard'||e.type==='cruiser'||e.type==='hive';
  explode(e.x,e.y,d.col,big?36:e.type==='moth'?6:16,big?1.3:.8);sfx(big||['mirror','hunter','commander','shielder'].includes(e.type)?'killBig':'kill');shake(big?8:e.type==='moth'?0:3);
  if(e.type==='twin'&&e.mate&&e.mate.alive&&e.mate.down>0){e.mate.down=0;e.mate.hp=0;kill(e.mate,false);}
  if(e.type==='cruiser'&&e.parts)e.parts.forEach(q=>{if(q.alive)kill(q,true);});
  if(e.type==='cpart'&&!silent&&e.host&&e.host.alive)floater(e.x,e.y-14,e.role==='gun'?'ОРУДИЕ УНИЧТОЖЕНО':'ДВИГАТЕЛЬ УНИЧТОЖЕН','#ff9a7a');
  if(e.type==='shocker'&&!silent)G.fields.push({x:e.x,y:e.y,r:90,t:2,max:2,hit:false});
  if(e.type==='frost'&&!silent)G.fields.push({x:e.x,y:e.y,r:70,t:4,max:4,hit:true,ice:true});
  if(e.type==='corroder'&&!silent){G.fields.push({x:e.x,y:e.y,r:150,t:5,max:5,hit:true,rust:true,strip:true});sfx('boom');}
  if(!silent)dropHull(e);
  if(e.type==='decoy'&&G.jam)G.jam.decoyT=8;
  if(e.type==='thief'&&e.loot)for(let i=0;i<e.loot;i++)dropCell(e.x+rnd(-10,10),e.y+rnd(-10,10),0);
  if(silent)return;
  if(e.affix){if(e.affix.includes('split'))for(let i=0;i<2;i++){const a=rnd(0,TAU);const m=spawnEnemy('mite',e.x,e.y,{group:e.group,noAffix:true,zone:e.zone,noLoot:true});m.vx=Math.cos(a)*240;m.vy=Math.sin(a)*240;}
    if(e.affix.includes('boom'))mineBlast({x:e.x,y:e.y,alive:true},64,12);}
  G.kills++;G.score+=Math.round(d.pts*(e.escort?.5:1));
  if(G.mode==='world'){conEvent('kill',e.type);if(!G.world)addPilotXP(rewMul()*(e.escort?.5:1));}
  if(e.lastCh)conEvent('chargedKill');
  comboKill();
  if(e.type==='crate'){runGrant6('lvl');floater(e.x,e.y-20,'ВНЕОЧЕРЕДНОЙ МОДУЛЬ','#8fe9ff');sfx('level');return;}
  if(e.type==='antenna'&&G.jam&&!G.enemies.some(o=>o.alive&&o.type==='antenna'))banner('АНТЕННЫ СБИТЫ','ЯДРО ГЛУШИТЕЛЯ ОТКРЫТО');
  if(d.passive||e.type==='antenna'||e.type==='decoy')return;
  if(e.type==='lock'){shake(12);if(G.save){const LD=G.save.locksDown||(G.save.locksDown=[]);if(!LD.includes(e.li)){LD.push(e.li);G.save.lom+=50;floater(e.x,e.y-48,'+50 ЛОМА','#c9d2de');}saveWorld();}if(G.save&&!G.enemies.some(o=>o.alive&&o.type==='lock')){G.save.gate=true;banner('ВОРОТА ОТКРЫТЫ','ДРЕЙФ МАЯКА · МИССИЯ 07 ДОСТУПНА');sfx('flash');
      const n=WORLD.nodes[6];G.unlockFx={x0:WORLD.gate.x,y0:WORLD.gate.y,x1:n.x,y1:n.y,t:0};saveWorld();}else floater(e.x,e.y-30,'ЗАМОК СНЯТ · ОСТАЛСЯ ОДИН','#b48cff');return;}
  if(G.world){if(!e.zone&&!e.noLoot&&Math.random()<.5)G.pick.push({k:'lom',x:e.x+rnd(-8,8),y:e.y+rnd(-8,8),vx:rnd(-90,90),vy:rnd(-90,90),r:5,t:0,life:30,v:1});
    if(Math.random()<.06)dropCell(e.x,e.y,0);
    if(e.type==='splitter')for(let i=0;i<3;i++){const a=i/3*TAU;const m=spawnEnemy('mite',e.x+Math.cos(a)*10,e.y+Math.sin(a)*10,{noAffix:true,zone:e.zone,noLoot:true});m.vx=Math.cos(a)*240;m.vy=Math.sin(a)*240;}
    return;}
  const xp=e.type==='moth'?(Math.random()<.5?1:0):e.escort?Math.round(d.xp*.5):d.xp;
  for(let i=0;i<xp;i++)G.pick.push({k:'xp',x:e.x+rnd(-8,8),y:e.y+rnd(-8,8),vx:rnd(-90,90),vy:rnd(-90,90),r:5,t:0,life:22});
  let cellCh=G.m<2?0:e.type==='guard'||e.type==='cruiser'?.6:e.type==='pylon'||e.type==='hive'?.35:e.type==='shielder'||e.type==='lancer'||e.type==='mirror'||e.type==='hunter'?.18:e.type==='moth'?.02:.075;
  if(G.bc)cellCh=e.type==='moth'||e.type==='mite'?.004:Math.min(1,cellCh*.9);
  if(Math.random()<cellCh)dropCell(e.x,e.y);
  const repCh=noHeal()?0:(G.mode==='endless'?Math.max(.005,.03-.003*(G.end.step-1)):e.type==='guard'||e.type==='cruiser'?.4:e.type==='moth'?.005:.03)*(inMission()?curDiff().rep:1);
  if(Math.random()<repCh)G.pick.push({k:'rep',x:e.x,y:e.y,vx:rnd(-40,40),vy:rnd(-40,40),r:10,t:0,life:25});
  if(e.type==='splitter')for(let i=0;i<3;i++){const a=i/3*TAU+rnd(-.3,.3);const m=spawnEnemy('mite',e.x+Math.cos(a)*10,e.y+Math.sin(a)*10,{group:e.group,noAffix:true});m.vx=Math.cos(a)*240;m.vy=Math.sin(a)*240;}
  if(e.type==='pylon'){const b=G.boss;if(b&&b.over<=0&&!G.enemies.some(o=>o.alive&&o.type==='pylon'))startOverload(b);}
}

// ---------- Страж ----------
const PHASE_NAMES=['ПРОБУЖДЕНИЕ','ПРИЦЕЛЬНЫЙ КОНТУР','АГОНИЯ ЯДРА'];
const PATTERNS=[['spiral','aimed'],['spiral','sweep','aimed'],['rings','sweep','seekers','spiral']];
function spawnBoss(){ambSting('boss');
  const b=spawnEnemy('boss',W/2,-120);
  Object.assign(b,{st:'enter',timer:2.6,phase:1,over:0,atk:null,atkT:1.6,patI:0,rot:0,domeFlash:0,deathT:0});
  G.boss=b;banner('СТРАЖ ПРОБУЖДАЕТСЯ','ФАЗА 1 · '+PHASE_NAMES[0]);sfx('warn');storyWarden();
}
function bossShielded(){return G.enemies.some(o=>o.alive&&o.type==='pylon');}
function spawnPylons(b){
  const n=2+b.phase;const R=150+b.phase*12;const dir=Math.random()<.5?1:-1;
  for(let i=0;i<n;i++){const orb=i/n*TAU;spawnEnemy('pylon',b.x+Math.cos(orb)*R,b.y+Math.sin(orb)*R*.8,{orb,R,dir,spawnT:1,cd:rnd(1.5,4)});}
}
function startOverload(b){if(G.mc)G.mc.overloads++;b.over=6.5;b.atk=null;G.eb=G.eb.filter(x=>!x.boss);banner('ПЕРЕГРУЗКА ЯДРА','ЯДРО УЯЗВИМО · УРОН ×1,5');sfx('level');shake(8);}
function phaseShift(b){ambSting('phase');
  b.phase++;b.over=0;b.atk=null;b.atkT=2.4;b.patI=0;
  G.shock.push({x:b.x,y:b.y,r:20,R:Math.max(W,H),t:0,col:'#b48cff',slow:true});G.eb=[];
  G.enemies.forEach(o=>{if(o.type==='pylon')o.alive=false;});
  spawnPylons(b);
  if(b.phase===2){edgeSpawn('guard');edgeSpawn('guard');}
  if(b.phase===3){edgeSpawn('guard');}
  banner('ФАЗА '+b.phase,PHASE_NAMES[b.phase-1]);sfx('bigboom');shake(14);
}
function bossDeath(b){ambSting('bossDown');buzz('boss');
  b.alive=true;b.st='dying';b.deathT=2.6;b.hp=0;G.eb=[];G.enemies.forEach(o=>{if(o!==b&&o.alive){kill(o,true);}});
  if(G.mode!=='endless')banner('ЯДРО РАЗРУШЕНО','АКТ I ЗАВЕРШЁН');G.score+=EDEF.boss.pts;G.kills++;
}
function updateBoss(b,dt){
  const p=G.player;b.rot+=dt*(b.over>0?.25:.6+b.phase*.15);if(b.domeFlash>0)b.domeFlash-=dt;
  if(b.st==='dying'){b.deathT-=dt;shake(6);if(Math.random()<.5)explode(b.x+rnd(-50,50),b.y+rnd(-50,50),Math.random()<.5?'#b48cff':'#8fe9ff',8,.8);
    if(b.deathT<=0){b.alive=false;explode(b.x,b.y,'#ffffff',120,2.2);sfx('bigboom');shake(20);G.boss=null;G.endT=2.2;}return;}
  if(b.st==='enter'){b.y+=(H*.26-b.y)*Math.min(1,dt*1.4);b.timer-=dt;if(b.timer<=0){b.st='fight';spawnPylons(b);}return;}
  b.t+=dt;const amp=b.phase===3?W*.3:W*.2;
  const tx=W/2+Math.sin(b.t*.27)*amp,ty=H*.26+Math.sin(b.t*.53)*H*.05;const k=Math.min(1,dt*(b.over>0?.3:1.2)*G.eSpd);b.x+=(tx-b.x)*k;b.y+=(ty-b.y)*k;
  if(b.over>0){b.over-=dt;if(SET.fx&&vR3()<.4)part(b.x+vrnd3(-30,30),b.y+vrnd3(-30,30),vrnd3(-80,80),vrnd3(-80,80),.4,'#ffffff',2);
    if(b.over<=0){spawnPylons(b);banner('ЯДРО СТАБИЛИЗИРОВАНО','ЗАРЯДЫ ВОССТАНАВЛИВАЮТСЯ');b.atkT=1.8;}return;}
  if(!b.atk){b.atkT-=dt*missionK('rate');if(b.atkT<=0){const list=PATTERNS[b.phase-1];b.atk={type:list[b.patI%list.length],t:0,n:0,dir:Math.random()<.5?1:-1};b.patI++;
    if(b.atk.type==='sweep'){b.atk.a0=Math.atan2(p.y-b.y,p.x-b.x)-b.atk.dir*.95;}}return;}
  const A=b.atk;A.t+=dt;const ph=b.phase;
  const emit=(a,s,dmg=10,col='#d7c4ff',r=5)=>{const q=shootE(b.x+Math.cos(a)*40,b.y+Math.sin(a)*40,a,s,dmg,col,r);if(q)q.boss=true;};
  let done=false;
  switch(A.type){
    case 'spiral':{const dur=3.2,step=ph===3?.09:.11,arms=2+ph;while(A.n*step<Math.min(A.t,dur)){const base=A.n*step*1.7*A.dir;for(let i=0;i<arms;i++)emit(base+i/arms*TAU,160+28*ph);A.n++;}done=A.t>dur;break;}
    case 'aimed':{const times=[0,.45,.9];while(A.n<times.length&&A.t>=times[A.n]){const a=Math.atan2(p.y-b.y,p.x-b.x);for(let i=-2;i<=2;i++)emit(a+i*.17,255,10,'#ffffff');A.n++;}done=A.t>1.4;break;}
    case 'sweep':{A.ang=A.t<1?A.a0:A.a0+A.dir*1.9*clamp((A.t-1)/2.4,0,1);
      if(A.t>1&&A.t<3.4){const ex=b.x+Math.cos(A.ang)*2000,ey=b.y+Math.sin(A.ang)*2000;if(segDist(b.x,b.y,ex,ey,p.x,p.y)<20)damagePlayer(16);}
      done=A.t>3.5;break;}
    case 'rings':{const times=[0,.8,1.6];while(A.n<times.length&&A.t>=times[A.n]){const gapA=Math.atan2(p.y-b.y,p.x-b.x)+rnd(-.7,.7);const N=30;for(let i=0;i<N;i++){const a=i/N*TAU;if(Math.abs(angDiff(a,gapA))<.42)continue;emit(a,150,10,'#ff9fd0',6);}A.n++;}done=A.t>2.2;break;}
    case 'seekers':{if(A.n===0){for(let i=0;i<3;i++){const a=Math.PI/2+(i-1)*.9;const s=spawnEnemy('seeker',b.x+Math.cos(a)*50,b.y+Math.sin(a)*50,{life:7});s.vx=Math.cos(a)*120;s.vy=Math.sin(a)*120;}A.n=1;}done=A.t>1;break;}
  }
  if(done){b.atk=null;b.atkT=[1.4,1.1,.9][ph-1];}
}

// ---------- Маяк ----------
function makeBeacon(M){return{x:W/2,y:H/2,r:30,hp:M.bcHp,maxHp:M.bcHp,charge:0,peak:0,thr:curDiff().thr.slice(),thrI:0,coolAt:(M.cool||[]).slice(),coolI:0,cool:0,
  trans:0,transStarted:false,transDone:false,done:false,mods:{},barrier:0,barF:0,turT:0,turA:0,hitF:0,rot:0,inRing:false,lureT:4,isBc:true,drain:0,rate:0};}
function bcRing(){return 125*(G.bc&&G.bc.mods.ring?1.4:1);}
function layoutBeacon(){
  const bc=G.bc;bc.x=W/2;bc.y=H/2;
  const R=Math.min(W,H)*.36;G.relays.forEach((r,i)=>{const a=-Math.PI/2+i*TAU/3+Math.PI/3;r.x=clamp(bc.x+Math.cos(a)*R,40,W-40);r.y=clamp(bc.y+Math.sin(a)*R,40,H-40);});
}
function dmgBeacon(d,src){
  if(devAny()&&G.dev.bcGod)return;
  const bc=G.bc;if(!bc||bc.done||G.deadT>0)return;if(bc.cool>0)d*=1.5;d*=(curDiff().bcDmg||1)*missionK('dmg');
  if(bc.barrier>0){const a=Math.min(bc.barrier,d);bc.barrier-=a;d-=a;bc.barF=.15;if(d<=0)return;}
  bc.hp-=d;bc.hitF=.25;G.bcTaken+=d;sfx('bhit');
  if(src&&src.affix&&src.affix.includes('vamp'))src.hp=Math.min(src.maxHp,src.hp+d);
  if(bc.hp<=0){bc.hp=0;G.loseBeacon=true;explode(bc.x,bc.y,'#ffb84d',80,1.8);sfx('bigboom');shake(18);G.deadT=1.8;banner('МАЯК РАЗРУШЕН','СИГНАЛ ПОТЕРЯН');}
}
function beaconFlash(){
  const bc=G.bc;if(!bc)return;G.eb=[];G.lightFull=1;sfx('flash');shake(6);
  G.shock.push({x:bc.x,y:bc.y,r:20,R:Math.max(W,H)*.7,t:0,col:'#ffb84d',slow:true});
  if(bc.mods.barrier)bc.barrier=100;
  for(const e of G.enemies){if(!e.alive||e.spawnT>0)continue;const d=Math.hypot(e.x-bc.x,e.y-bc.y);
    if(d<420&&!HEAVY.has(e.type)){const k=(1-d/420)*480;e.vx+=(e.x-bc.x)/(d||1)*k;e.vy+=(e.y-bc.y)/(d||1)*k;if(e.type==='leech'&&e.att){e.att=false;}}
    if(bc.mods.flashdmg&&d<420){hurt(e,60,{pulse:true});if(e.alive&&!STATIC.has(e.type))e.stun=1.5;}}
}
function finishBeacon(){
  const bc=G.bc;beaconFlash();G.enemies.slice().forEach(e=>{if(e.alive&&e!==G.jam)kill(e,true);});G.eb=[];
  banner(MISSIONS[G.m-1].transmit?'СИГНАЛ ПЕРЕДАН':'МАЯК ЗАРЯЖЕН','ИСТОРИЯ ЗАФИКСИРОВАНА');G.endT=2.6;bc.done=true;
}
function updateBeacon(dt){
  const bc=G.bc,p=G.player,st=G.st;if(!bc)return;
  bc.rot+=dt;bc.hitF=Math.max(0,bc.hitF-dt);bc.barF=Math.max(0,bc.barF-dt);
  const inRing=p.hp>0&&Math.hypot(p.x-bc.x,p.y-bc.y)<bcRing();bc.inRing=inRing;
  if(bc.done)return;
  if(inRing&&bc.mods.repair&&!p.shieldUp&&!(G.lockShield>0)){p.shieldT+=dt;if(!(st.shieldCd>0)&&p.shieldT>=8){p.shieldUp=true;p.shieldT=0;sfx('shield');}}
  if(bc.mods.turret){bc.turT-=dt;if(bc.turT<=0){const t=nearestEnemy(bc.x,bc.y,380,true);
    if(t){bc.turT=bc.mods.turret>1?.5:.8;const a=Math.atan2(t.y-bc.y,t.x-bc.x);bc.turA=a;G.pb.push({x:bc.x+Math.cos(a)*30,y:bc.y+Math.sin(a)*30,px:bc.x,py:bc.y,vx:Math.cos(a)*850,vy:Math.sin(a)*850,dmg:8,pierce:0,rico:0,life:.6,hit:[],turret:true});}else bc.turT=.2;}}
  if(bc.mods.lure){bc.lureT-=dt;if(bc.lureT<=0){bc.lureT=4;for(const e of G.enemies)if(e.alive&&e.group==='hunt'&&Math.random()<.3)e.lureT=4;}}
  if(bc.cool>0){bc.cool-=dt;if(bc.cool<=0)banner('ОХЛАЖДЕНИЕ ЗАВЕРШЕНО','ЗАРЯДКА ВОЗОБНОВЛЕНА');}
  let rate=0;
  if(bc.cool<=0){rate=(inRing?.55:.08)*(MISSIONS[G.m-1].chargeMul||1);
    if(G.relays.length)rate*=1+.2*G.relays.filter(r=>!r.cut).length;
    const nj=G.enemies.filter(e=>e.alive&&e.type==='jammerS'&&e.spawnT<=0&&onScreen(e)).length;rate*=Math.pow(.7,nj);
    if(G.flare>0)rate*=2;}
  bc.rate=rate;
  if(inRing&&p.cargo>0){if(bc.cool>0)hintOnce('cool','МАЯК ОХЛАЖДАЕТСЯ · ГРУЗ ПОЗЖЕ','#ffb84d');else{const add=6*p.cargo;bc.charge+=add;floater(bc.x,bc.y-bc.r-18,'+ЗАРЯД','#ffb84d');p.cargo=0;sfx('cell');}}
  const leech=G.enemies.filter(e=>e.alive&&e.type==='leech'&&e.att).length;
  const ant=G.enemies.filter(e=>e.alive&&e.type==='antenna'&&e.spawnT<=0).length;
  const drain=leech*.7+ant*1.2;bc.drain=drain;
  bc.charge+=(rate-drain)*dt;
  let floor=0;if(bc.mods.battery)for(const t of bc.thr)if(bc.peak>=t)floor=t;
  bc.charge=clamp(bc.charge,floor,100);bc.peak=Math.max(bc.peak,bc.charge);
  while(bc.thrI<bc.thr.length&&bc.charge>=bc.thr[bc.thrI]){bc.thrI++;beaconFlash();ambSting('flash');runGrant6('bp');banner('ВСПЫШКА МАЯКА',bc.thr[bc.thrI-1]+'% · МОДУЛЬ МАЯКА');}
  while(bc.coolI<bc.coolAt.length&&bc.charge>=bc.coolAt[bc.coolI]){bc.coolI++;bc.cool=10;banner('ПРОДУВКА ОХЛАЖДЕНИЯ','10 С · МАЯК УЯЗВИМ, ЗАРЯД СТОИТ');sfx('warn');}
  const M=MISSIONS[G.m-1];
  if(bc.charge>=100){
    if(M.transmit){if(!bc.transStarted){bc.transStarted=true;bc.trans=M.transmit;spawnJam();banner('ПЕРЕДАЧА НАЧАТА','ГЛУШИТЕЛЬ ПРИБЛИЖАЕТСЯ');}}
    else{finishBeacon();return;}
  }
  if(bc.transStarted&&!bc.transDone&&bc.charge<80&&G.mc)G.mc.transPaused=true;
  if(bc.transStarted&&!bc.transDone&&bc.charge>=80){bc.trans-=dt;if(bc.trans<=0){bc.trans=0;bc.transDone=true;banner('ПЕРЕДАЧА ЗАВЕРШЕНА',G.jam?'УНИЧТОЖЬТЕ ГЛУШИТЕЛЯ':'СИГНАЛ ДОШЁЛ');}}
  if(bc.transDone&&!G.jam)finishBeacon();
  // контакт врагов с маяком
  for(const e of G.enemies){
    if(!e.alive||e.spawnT>0||e.ghost||e.down>0||NOBC.has(e.type))continue;
    const d=Math.hypot(e.x-bc.x,e.y-bc.y);if(d>=e.r+bc.r)continue;
    if(e.type==='moth'){dmgBeacon(3,e);kill(e,true);continue;}
    if(e.bcT<=0&&e.contact>0){dmgBeacon(e.contact*(e.group==='siege'?1:.5)*(e.type==='rammer'&&e.st==='charge'?1.5:1),e);e.bcT=1;}
    const a=Math.atan2(e.y-bc.y,e.x-bc.x);e.x=bc.x+Math.cos(a)*(e.r+bc.r);e.y=bc.y+Math.sin(a)*(e.r+bc.r);e.vx=Math.cos(a)*180;e.vy=Math.sin(a)*180;
  }
}

// ---------- Режиссёр миссий 7–10 ----------
const LOAD={moth:.25,mite:.3,shell:0,mine:0,crate:0,antenna:0,decoy:0,cpart:0,cruiser:3,hive:1.5,jam:0,seeker:.3};
function enemyLoad(){let s=G.warns.reduce((a,w)=>a+(LOAD[w.type]??1),0);for(const e of G.enemies)if(e.alive)s+=LOAD[e.type]??1;return s;}
function pickPool(pool){let tot=0;for(const k in pool)tot+=pool[k];let r=Math.random()*tot;for(const k in pool){r-=pool[k];if(r<=0)return k;}return Object.keys(pool)[0];}
function directorSpawn(type){
  if(type==='moth'){const side=Math.random()*4|0,u=rnd(.15,.85),n=6+(Math.random()*4|0);for(let i=0;i<n;i++)edgeSpawn('moth',{side,u:u+rnd(-.06,.06),delay:i*.08});}
  else if(type==='twin'){const id=++G.uid;const side=Math.random()*4|0,u=rnd(.2,.8);edgeSpawn('twin',{pair:id,side,u});edgeSpawn('twin',{pair:id,side,u:u+.08});}
  else edgeSpawn(type);
}
function updateDirector(dt){
  const M=MISSIONS[G.m-1],bc=G.bc;G.mT+=dt;
  if(G.endT>0){G.endT-=dt;if(G.endT<=0)missionComplete();return;}
  if(bc.done)return;
  let ph=M.phases[0];for(const q of M.phases)if(bc.peak>=q.at)ph=q;
  for(const ev of G.script)if(!ev.done&&bc.peak>=ev.at){ev.done=true;edgeSpawn(ev.spawn);if(ev.msg)banner(ev.msg[0],ev.msg[1]);}
  while(G.evAt.length&&bc.peak>=G.evAt[0]){G.evAt.shift();startEvent();}
  G.dirT-=dt;const tr=bc.transStarted?1.1:1;
  const em=enemyMul();
  if(G.dirT<=0&&enemyLoad()<Math.min(40,ph.max*tr*em)){G.dirT=ph.every*rnd(.8,1.2)/(tr*em);directorSpawn(pickPool(ph.pool));}
}

// ---------- Уровень: ретрансляторы, астероиды, буря, поля ----------
function nearestLine(e){if(!G.bc)return null;let b=null,bd=1e9;for(const r of G.relays){if(r.cut)continue;const q=segDist(r.x,r.y,G.bc.x,G.bc.y,e.x,e.y);if(q<bd){bd=q;b=r;}}return b;}
function updateRelays(dt){
  const p=G.player,bc=G.bc;if(!bc)return;
  for(const r of G.relays){if(!r.cut)continue;
    if(p.hp>0&&segDist(r.x,r.y,bc.x,bc.y,p.x,p.y)<28){r.rep+=dt*G.st.linek;if(r.rep>=2){r.cut=false;r.rep=0;floater(p.x,p.y-26,'ЛИНИЯ ВОССТАНОВЛЕНА','#8fe9ff');sfx('cell');}}
    else r.rep=Math.max(0,r.rep-dt*.5);}
}
function makeRock(x,y,r){const n=9,v=[];for(let i=0;i<n;i++)v.push(r*rnd(.75,1.1));return{x,y,vx:rnd(-22,22),vy:rnd(-22,22),r,hp:r>25?60:25,v,rot:rnd(0,TAU),vr:rnd(-.4,.4),alive:true,tow:null,flung:false,hitF:0};}
function spawnRocks(n){const bc=G.bc,p=G.player;for(let i=0;i<n;i++){let x,y,t=0;do{x=rnd(60,W-60);y=rnd(60,H-60);}while((Math.hypot(x-bc.x,y-bc.y)<bcRing()+70||Math.hypot(x-p.x,y-p.y)<120)&&++t<20);G.rocks.push(makeRock(x,y,rnd(28,36)));}}
function rockHit(r,dmg){r.hp-=dmg;r.hitF=.06;if(r.hp<=0&&r.alive){r.alive=false;if(r.tow){releaseTug(r.tow,false);}explode(r.x,r.y,'#8a9bb0',14,.8);
  const list=G.world?G.wrocks:G.rocks;
  if(r.r>25&&!G.world)for(let i=0;i<2;i++){const s=makeRock(r.x+rnd(-10,10),r.y+rnd(-10,10),rnd(15,19));if(G.world){s.vx=0;s.vy=0;}else{s.vx=rnd(-60,60);s.vy=rnd(-60,60);}list.push(s);}
  if(G.world){const rk=(G.w&&storyFlag('arcSilence')&&worldSS(r.x,r.y)===SEC_SCALE[2])?1.25:1;for(let i=0;i<Math.round((r.r>25?2:1)*rk);i++)G.pick.push({k:'lom',x:r.x+rnd(-10,10),y:r.y+rnd(-10,10),vx:rnd(-80,80),vy:rnd(-80,80),r:5,t:0,life:30,v:1});if(r.id!==undefined&&G.save&&G.save.rocksGone&&!G.save.rocksGone.includes(r.id))G.save.rocksGone.push(r.id);}
  else if(Math.random()<.25)dropCell(r.x,r.y);}}
function releaseTug(e,byShot){if(e.rock){e.rock.tow=null;e.rock.vx*=.3;e.rock.vy*=.3;}e.rock=null;e.cd=3;if(byShot){floater(e.x,e.y-18,'ТРОС ПЕРЕБИТ','#c9a36b');sfx('block');}}
function updateRocks(dt){
  const bc=G.bc,p=G.player;
  for(const r of G.rocks){if(!r.alive)continue;r.rot+=r.vr*dt;r.hitF=Math.max(0,r.hitF-dt);
    if(r.tow&&!r.tow.alive)r.tow=null;
    if(!r.tow){r.x+=r.vx*dt;r.y+=r.vy*dt;}
    if(r.flung){if(bc&&Math.hypot(r.x-bc.x,r.y-bc.y)<r.r+bc.r){dmgBeacon(r.r>25?40:22,null);r.alive=false;explode(r.x,r.y,'#c9a36b',20,1);shake(8);continue;}
      if(r.x<-60||r.x>W+60||r.y<-60||r.y>H+60){r.alive=false;continue;}}
    else{if(r.x<r.r&&r.vx<0||r.x>W-r.r&&r.vx>0)r.vx*=-1;if(r.y<r.r&&r.vy<0||r.y>H-r.r&&r.vy>0)r.vy*=-1;
      r.x=clamp(r.x,-r.r,W+r.r);r.y=clamp(r.y,-r.r,H+r.r);
      if(bc&&!r.tow){const d=Math.hypot(r.x-bc.x,r.y-bc.y);if(d<r.r+bc.r+20){const a=Math.atan2(r.y-bc.y,r.x-bc.x);r.x=bc.x+Math.cos(a)*(r.r+bc.r+20);r.y=bc.y+Math.sin(a)*(r.r+bc.r+20);r.vx=Math.cos(a)*25;r.vy=Math.sin(a)*25;}}}
    if(p.hp>0){const d=Math.hypot(p.x-r.x,p.y-r.y),m=r.r+p.r*.8;if(d<m&&d>0){p.x=clamp(r.x+(p.x-r.x)/d*m,p.r,W-p.r);p.y=clamp(r.y+(p.y-r.y)/d*m,p.r,H-p.r);}}
    for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||e===r.tow||e.type==='mine')continue;const d=Math.hypot(e.x-r.x,e.y-r.y),m=r.r+e.r;if(d<m&&d>0){e.x=r.x+(e.x-r.x)/d*m;e.y=r.y+(e.y-r.y)/d*m;}}
  }
  G.rocks=G.rocks.filter(r=>r.alive);
  if(G.rockN){G.rockT-=dt;if(G.rockT<=0&&G.rocks.length<Math.ceil(G.rockN*.6)){G.rockT=8;const s=Math.random()*4|0;const x=s===1?W+40:s===3?-40:rnd(80,W-80),y=s===0?-40:s===2?H+40:rnd(80,H-80);
    const r=makeRock(x,y,rnd(28,36));const a=Math.atan2(H/2-y,W/2-x)+rnd(-.5,.5);r.vx=Math.cos(a)*35;r.vy=Math.sin(a)*35;G.rocks.push(r);}}
}
function inStorm(x,y){const s=G.storm;if(!s||s.warn>0)return false;return s.axis==='x'?Math.abs(x-s.pos)<s.w/2:Math.abs(y-s.pos)<s.w/2;}
function updateStorm(dt){
  const M=MISSIONS[G.m-1];if(!M.storm)return;
  if(!G.storm){G.stormT-=dt;if(G.stormT<=0){const axis=Math.random()<.5?'x':'y',L=axis==='x'?W:H,dir=Math.random()<.5?1:-1;
    G.storm={axis,dir,w:200,pos:dir>0?-100:L+100,warn:3,L};banner('ИОННАЯ БУРЯ','РЫВОК И ПРИЦЕЛ СБОЯТ В ПОЛОСЕ');sfx('warn');}}
  else{const s=G.storm;if(s.warn>0)s.warn-=dt;else{s.pos+=s.dir*110*dt;if(s.dir>0?s.pos>s.L+120:s.pos<-120){G.storm=null;G.stormT=rnd(16,24);}}}
}
function updateFields(dt){
  const p=G.player;
  for(const f of G.fields){f.t-=dt;if(!f.hit&&p.hp>0&&Math.hypot(p.x-f.x,p.y-f.y)<f.r){f.hit=true;p.noDash=3;damagePlayer(5);floater(p.x,p.y-26,'РЫВОК ПОДАВЛЕН','#6bf0ff');}}
  G.fields=G.fields.filter(f=>f.t>0);
  // гравитация вихрей
  for(const v of G.enemies){if(!v.alive||v.type!=='vortex'||v.spawnT>0)continue;
    if(p.hp>0&&p.dashT<=0){const dx=v.x-p.x,dy=v.y-p.y,d=Math.hypot(dx,dy);if(d<240&&d>v.r){const k=95*(1-d/240)*dt;p.x=clamp(p.x+dx/d*k,p.r,BW-p.r);p.y=clamp(p.y+dy/d*k,p.r,BH-p.r);}}
    for(const e of G.enemies){if(e===v||!e.alive||HEAVY.has(e.type)||STATIC.has(e.type)||(e.type==='leech'&&e.att))continue;const dx=v.x-e.x,dy=v.y-e.y,d=Math.hypot(dx,dy);if(d<240&&d>v.r+e.r){const k=110*(1-d/240)*dt;e.x+=dx/d*k;e.y+=dy/d*k;}}
    for(const k of G.pick){const dx=v.x-k.x,dy=v.y-k.y,d=Math.hypot(dx,dy);if(d<240&&d>8){k.vx+=dx/d*200*dt;k.vy+=dy/d*200*dt;}}}
}

// ---------- Случайные события ----------
const EVENTS=['meteor','flare','crate','fake'];
function startEvent(){
  const left=EVENTS.filter(e=>!G.evUsed.includes(e));const type=left.length?left[Math.random()*left.length|0]:EVENTS[Math.random()*4|0];G.evUsed.push(type);
  if(type==='meteor'){G.meteorT=8;G.meteorN=0;banner('МЕТЕОРНЫЙ ДОЖДЬ','8 С · ОБЛОМКИ БЬЮТ ВСЕХ, ВКЛЮЧАЯ ВРАГОВ');}
  if(type==='flare'){G.flare=8;banner('СОЛНЕЧНАЯ ВСПЫШКА','8 С · ЗАРЯДКА ×2, ВРАГИ БЫСТРЕЕ');}
  if(type==='crate'){const s=Math.random()<.5;const y=rnd(H*.2,H*.8);spawnEnemy('crate',s?-30:W+30,y,{vx:s?70:-70,vy:rnd(-15,15),noAffix:true});banner('ДРЕЙФУЮЩИЙ КОНТЕЙНЕР','СБЕЙТЕ — ВНЕОЧЕРЕДНОЙ МОДУЛЬ');}
  if(type==='fake'){const a=rnd(0,TAU);G.fake={x:clamp(W/2+Math.cos(a)*W*.42,70,W-70),y:clamp(H/2+Math.sin(a)*H*.42,70,H-70),t:10,isFake:true};banner('ЛОЖНЫЙ СИГНАЛ','10 С · ЧАСТЬ ВРАГОВ ОТВЛЕЧЕНА');}
  sfx('warn');
}
function updateEvents(dt){
  if(G.flare>0)G.flare-=dt;
  if(G.fake){G.fake.t-=dt;if(G.fake.t<=0)G.fake=null;}
  if(G.lureP){G.lureP.t-=dt;if(G.lureP.t<=0)G.lureP=null;}
  G.dashLog=G.dashLog.filter(e=>G.t-e.t<2);
  if(G.meteorT>0){G.meteorT-=dt;G.meteorN-=dt;if(G.meteorN<=0){G.meteorN=.45;G.meteors.push({x:rnd(40,W-40),y:rnd(40,H-40),t:1.1});}}
  const p=G.player,bc=G.bc;
  for(const m of G.meteors){m.t-=dt;if(m.t<=0&&!m.done){m.done=true;explode(m.x,m.y,'#ffb07a',14,.8);G.shock.push({x:m.x,y:m.y,r:5,R:46,t:0,col:'#ffb07a',thin:true});
    if(p.hp>0&&Math.hypot(p.x-m.x,p.y-m.y)<46)damagePlayer(12);
    for(const e of G.enemies)if(e.alive&&!STATIC.has(e.type)&&e.type!=='crate'&&Math.hypot(e.x-m.x,e.y-m.y)<46+e.r)hurt(e,30,{});
    if(bc&&Math.hypot(bc.x-m.x,bc.y-m.y)<46+bc.r)dmgBeacon(8,null);}}
  G.meteors=G.meteors.filter(m=>m.t>-.1);
}

// ---------- Глушитель ----------
const JAM_NAMES=['ПОМЕХИ','ОТРАЖЕНИЕ','ПОЛНАЯ ТИШИНА'];
function spawnJam(){ambSting('boss');if(G.mode==='world'&&!G.world&&G.m===10){radioClear();radioSay('А',3);}const j=spawnEnemy('jam',W/2,-110,{noAffix:true});Object.assign(j,{st:'enter',timer:2.6,phase:1,orb:-Math.PI/2,antT:0,atkA:1.5,atkB:2.5,decoyT:0,window:0,rot:0,domeFlash:0,spT:0,spOn:0,flashT:4});j.group=null;G.jam=j;sfx('warn');}
function jamShielded(){const j=G.jam;if(!j)return true;if(j.phase===1)return G.enemies.some(o=>o.alive&&o.type==='antenna');if(j.phase===3)return j.window<=0;return false;}
function jamPhase(j){ambSting('phase');
  j.phase++;G.eb=[];G.enemies.forEach(o=>{if(o.type==='antenna'||o.type==='decoy'||o.type==='seeker')o.alive=false;});
  G.shock.push({x:j.x,y:j.y,r:20,R:Math.max(W,H),t:0,col:'#4dd0ff',slow:true});sfx('bigboom');shake(14);
  banner('ГЛУШИТЕЛЬ · ФАЗА '+j.phase,JAM_NAMES[j.phase-1]);
  if(j.phase===2){j.decoyT=1.2;}
  if(j.phase===3){G.dark=true;j.flashT=4;j.window=0;}
}
function jamDeath(j){ambSting('bossDown');buzz('boss');
  j.alive=true;j.st='dying';j.deathT=2.4;j.hp=0;G.dark=false;G.eb=[];
  G.enemies.forEach(o=>{if(o.alive&&(o.type==='antenna'||o.type==='decoy'||o.type==='seeker'))kill(o,true);});
  G.score+=EDEF.jam.pts;G.kills++;banner('ГЛУШИТЕЛЬ УНИЧТОЖЕН',G.bc&&G.bc.transDone?'СИГНАЛ СВОБОДЕН':'УДЕРЖИТЕ ПЕРЕДАЧУ');
}
function updateJam(j,dt){
  const p=G.player,bc=G.bc||{x:W/2,y:H/2};j.rot+=dt*.8;if(j.domeFlash>0)j.domeFlash-=dt;
  if(j.st==='dying'){j.deathT-=dt;shake(5);if(Math.random()<.5)explode(j.x+rnd(-40,40),j.y+rnd(-40,40),Math.random()<.5?'#4dd0ff':'#ffffff',8,.8);
    if(j.deathT<=0){j.alive=false;explode(j.x,j.y,'#ffffff',120,2.2);sfx('bigboom');shake(20);G.jam=null;}return;}
  const R=Math.min(W,H)*.38;j.orb+=dt*.22*G.eSpd;const tx=bc.x+Math.cos(j.orb)*R,ty=bc.y+Math.sin(j.orb)*R*.75;
  if(j.st==='enter'){j.x+=(tx-j.x)*Math.min(1,dt*1.5);j.y+=(ty-j.y)*Math.min(1,dt*1.5);j.timer-=dt;if(j.timer<=0){j.st='fight';banner('ГЛУШИТЕЛЬ · ФАЗА 1',JAM_NAMES[0]);}return;}
  j.t+=dt;j.x+=(tx-j.x)*Math.min(1,dt*2);j.y+=(ty-j.y)*Math.min(1,dt*2);
  if(j.window>0)j.window-=dt;
  const ph=j.phase;j.atkA-=dt;j.atkB-=dt;
  const emit=(a,s,dmg,col,r,toBc)=>shootE(j.x+Math.cos(a)*40,j.y+Math.sin(a)*40,a,s,dmg,col,r,toBc);
  if(ph===1){
    if(!G.enemies.some(o=>o.alive&&o.type==='antenna')){j.antT-=dt;if(j.antT<=0){j.antT=7;for(let i=0;i<3;i++){const a=rnd(0,TAU),r=rnd(140,240);spawnEnemy('antenna',clamp(bc.x+Math.cos(a)*r,40,W-40),clamp(bc.y+Math.sin(a)*r,40,H-40),{spawnT:.8});}banner('АНТЕННЫ ПОМЕХ','ТЯНУТ ЗАРЯД · ЗАКРЫВАЮТ ЯДРО');}}
    if(j.atkA<=0){j.atkA=2;const a=Math.atan2(p.y-j.y,p.x-j.x);for(let i=-1;i<=1;i++)emit(a+i*.2,250,10,'#4dd0ff',5,false);}
    if(j.atkB<=0){j.atkB=3.5;const a=Math.atan2(bc.y-j.y,bc.x-j.x);for(let i=-2;i<=2;i++)emit(a+i*.12,200,9,'#9fe8ff',5,true);}
  }else if(ph===2){
    if(!G.enemies.some(o=>o.alive&&o.type==='decoy')){j.decoyT-=dt;if(j.decoyT<=0){let x,y,t=0;do{x=rnd(80,W-80);y=rnd(80,H-80);}while(Math.hypot(x-bc.x,y-bc.y)<300&&++t<20);
      spawnEnemy('decoy',x,y,{spawnT:.6});banner('ЛОЖНЫЙ МАЯК','АВТОПРИЦЕЛ СБИТ · ОТМЕЧАЙТЕ ЦЕЛИ КЛИКОМ');}}
    j.spT-=dt;if(j.spT<=0){j.spOn=j.spOn>0?0:3;j.spT=j.spOn>0?3:1.6;}
    if(j.spOn>0){j.spAcc=(j.spAcc||0)+dt;while(j.spAcc>.12){j.spAcc-=.12;const base=j.t*1.6;for(let i=0;i<3;i++)emit(base+i/3*TAU,170,10,'#9fe8ff',5,false);}}
    if(j.atkA<=0){j.atkA=2.4;const a=Math.atan2(p.y-j.y,p.x-j.x);for(let i=-2;i<=2;i++)emit(a+i*.16,260,10,'#ffffff',5,false);}
  }else{
    G.dark=true;
    j.flashT-=dt;if(j.flashT<=0){j.flashT=16;j.window=4.5;if(G.bc){beaconFlash();banner('ВСПЫШКА МАЯКА','ЯДРО ГЛУШИТЕЛЯ ОТКРЫТО · 4,5 С');}else{G.lightFull=1;G.eb=[];sfx('flash');banner('ОКНО СВЕТА','ЯДРО ЭХА ОТКРЫТО · 4,5 С');}}
    if(j.atkA<=0){j.atkA=3.2;const gapA=Math.atan2(p.y-j.y,p.x-j.x)+rnd(-.6,.6);for(let i=0;i<28;i++){const a=i/28*TAU;if(Math.abs(angDiff(a,gapA))<.45)continue;emit(a,145,10,'#ff9fd0',6,false);}}
    if(j.atkB<=0){j.atkB=7;for(let i=0;i<2;i++){const a=rnd(0,TAU);const s=spawnEnemy('seeker',j.x+Math.cos(a)*50,j.y+Math.sin(a)*50,{life:7});s.vx=Math.cos(a)*120;s.vy=Math.sin(a)*120;}}
  }
}

// ---------- Предметы и подбор ----------
let hintCd={};
function hintOnce(key,text,col){const t=G.t;if(hintCd[key]&&t-hintCd[key]<2.6)return;hintCd[key]=t;if(G.player)floater(G.player.x,G.player.y-30,text,col);}
function updatePickups(dt){
  const p=G.player,st=G.st,bc=G.bc;
  for(const k of G.pick){
    k.t+=dt;k.life-=dt;if(k.stab>0)k.stab-=dt;
    k.vx*=Math.pow(.05,dt);k.vy*=Math.pow(.05,dt);
    const d=Math.hypot(p.x-k.x,p.y-k.y);
    const cargoFree=bc&&p.cargo<st.cargo;
    const full=!k.anom&&((k.k==='rep'&&p.hp>=st.maxHp)||(k.k==='cell'&&p.en>=100&&!cargoFree));
    const attract=p.hp>0&&!full&&!(k.stab>0)&&!k.noMag&&(d<st.mag||G.endT>0);
    if(attract){const s=G.endT>0?900:clamp(600-d*2,220,600);k.vx+=(p.x-k.x)/(d||1)*s*dt*6;k.vy+=(p.y-k.y)/(d||1)*s*dt*6;const v=Math.hypot(k.vx,k.vy);if(v>700){k.vx*=700/v;k.vy*=700/v;}}
    k.x+=k.vx*dt;k.y+=k.vy*dt;k.x=clamp(k.x,8,BW-8);k.y=clamp(k.y,8,BH-8);
    if(p.hp>0){
      const hd=segDist(p.px,p.py,p.x,p.y,k.x,k.y);
      if(hd<p.r+k.r+6){
        if(k.k==='xp'){k.life=0;runXp6(xpMul());G.score+=2;sfx('pick');}
        else if(k.k==='lom'){k.life=0;if(G.save)G.save.carry+=k.v;sfx('pick');}
        else if(k.anom){k.life=0;if(G.anom)G.anom.got++;p.en=Math.min(100,p.en+8);sfx('cell');floater(k.x,k.y-14,'ЯЧЕЙКА '+(G.anom?G.anom.got:0)+'/'+(G.anom?G.anom.need:8),'#ffb84d');}
        else if(k.stab>0){hintOnce('stab','ЯЧЕЙКА СТАБИЛИЗИРУЕТСЯ · '+k.stab.toFixed(1)+' с','#ffb84d');}
        else if(k.k==='cell'){
          const got=()=>{if(G.mc){G.mc.cells++;conEvent('cell');}};
          if(cargoFree){k.life=0;p.cargo++;got();sfx('cell');floater(k.x,k.y-14,'ЯЧЕЙКА В ТРЮМЕ · '+p.cargo+'/'+st.cargo,'#ffb84d');}
          else if(p.en>=100)hintOnce('enfull',bc?'ТРЮМ И НАКОПИТЕЛЬ ПОЛНЫ':'НАКОПИТЕЛЬ ПОЛОН · ИМПУЛЬС: E','#ffb84d');
          else{k.life=0;got();p.en=Math.min(100,p.en+34*st.eGain);sfx('cell');floater(k.x,k.y-14,'+ЭНЕРГИЯ','#ffb84d');}}
        else if(k.k==='rep'){if(noHeal()){k.life=0;p.en=Math.min(100,p.en+34*st.eGain);sfx('cell');floater(k.x,k.y-14,'+ЭНЕРГИЯ','#8fe9ff');}else if(p.hp>=st.maxHp)hintOnce('hpfull','КОРПУС ЦЕЛ · РЕМКОМПЛЕКТ ОСТАЁТСЯ','#8fe9ff');else{k.life=0;if(G.wear>0)addWear(-st.maxHp0*(storyFlag('factory')?.1:.05));const h=Math.min(st.maxHp-p.hp,30);p.hp+=h;sfx('cell');floater(k.x,k.y-14,'+'+Math.round(h)+' КОРПУС','#8fe9ff');}}
      }
    }
  }
  G.pick=G.pick.filter(k=>k.life>0);
  if(G.m>=2&&p.hp>0)p.en=Math.min(100,p.en+dt*1.2*st.eGain*(secScale()&&secScale().ice?1.15:1));
}

// ---------- Эффекты ----------
let PMAX=900,GLOWMAX=0;
function part(x,y,vx,vy,life,col,size){if(G.parts.length>=PMAX||(G.lowFx&&Math.random()<.5)||(SET.lessFx&&Math.random()<.5))return;G.parts.push({x,y,vx,vy,life,max:life,col,size});}
function explode(x,y,col,n,s){const m=SET.fx?n:Math.ceil(n/4);for(let i=0;i<m;i++){const a=rnd(0,TAU),v=rnd(40,320)*s;part(x,y,Math.cos(a)*v,Math.sin(a)*v,rnd(.3,.8)*s,Math.random()<.3?'#ffffff':col,rnd(1.5,3.5));}
  if(G.shock.length<60)G.shock.push({x,y,r:4,R:30*s+10,t:0,col,thin:true});}
function floater(x,y,text,col){text=tclean(text);if(G.float.length>24)G.float.shift();G.float.push({x:clamp(x,CX+60,CX+W-60),y:clamp(y,CY+30,CY+H-20),text,col,life:1.3});}
let banT=0;
/* 1.1.0: чистка всплывающих надписей */
function tclean(s){if(typeof s!=='string'||!s||G.devRun)return s;let t=s.replace(/\s·\s~?\d+(?:[,.]\d+)?\s?[сС](?![А-ЯЁа-яё])/g,'').replace(/^~?\d+(?:[,.]\d+)?\s?[сС]\s·\s/,'');
  const seg=t.split(' · ');if(seg.length>1){const k=seg.filter(x=>!/×\s?\d/.test(x)&&!/[+−-]?\d+(?:[,.]\d+)?\s?%/.test(x));if(k.length)t=k.join(' · ');}
  t=t.replace(/\s*×\s?\d+(?:[,.]\d+)?(?=$|\s·|,)/g,'').replace(/\s+,/g,',').trim();return t||s;}
function banner(b,s){s=tclean(s);if(/^(ЛОМ|УРОН|ЗАРЯД|ОПЫТ)$/.test(s||''))s='';$('#banB').textContent=b;$('#banS').textContent=s||'';$('#banner').classList.add('show');banT=2.6;}

// ---------- Прогрессия: волны и миссии ----------
function setupMission(i){const _r=Math.random;Math.random=mulberry(G.layoutSeed||1);try{setupMission0(i);}finally{Math.random=_r;}}
function setupMission0(i){
  G.m=i+1;const M=MISSIONS[i];
  Object.assign(G,{enemies:[],pb:[],eb:[],pick:[],parts:[],float:[],warns:[],shock:[],prio:null,boss:null,endT:0,deadT:0,bc:null,relays:[],rocks:[],fields:[],meteors:[],meteorT:0,meteorN:0,
    affix2:M.gen?M.affix2:i+1>=10?.25:0,lowFx:false,
    storm:null,stormT:rnd(10,16),flare:0,fake:null,lureP:null,dashLog:[],dark:!!M.dark,lightFull:0,jam:null,bpQ:0,loseBeacon:false,bcTaken:0,affixCh:(M.affix||0),dirT:1.5,evUsed:[],rockN:M.rocks||0,rockT:8,
    mc:{dashes:0,cells:0,pulses:0,prioKills:0,lanceHits:0,overloads:0,transPaused:false},combo:null,bossMul:0,aimLock:null,sb:null,sbLomK:1,lom74:0,sbChoiceTxt:'',tiredT:0,waveForce:false,noTele:!!(inMission()&&curDiff().hideTele)});
  G.waves=M.waves?M.waves.map(parseWave):M.wavesT?M.wavesT.map(w=>shuffle(w.slice())):[];G.waveBase=G.waves.map(w=>w.length);G.waves=G.waves.map(scaleWave);G.waveCap=99;G.waveIdx=0;G.spawnQ=[];G.gapT=1.2;G.waveT=0;G.mT=0;G.missionKills=G.kills;G.missionTaken=G.taken;G.bossSpawned=false;
  const p=G.player;p.x=W/2;p.y=H*.7;p.px=p.x;p.py=p.y;p.vx=p.vy=0;p.inv=1.2;p.dashT=0;p.dashCd=0;p.trail=[];p.cargo=0;p.noDash=0;
  if(perk('pre'))p.en=Math.max(p.en,30*perk('pre'));
  if(M.beacon){
    G.bc=makeBeacon(M);if(curDiff().bcHp){G.bc.hp*=curDiff().bcHp;G.bc.maxHp=G.bc.hp;}{const tk=document.querySelectorAll('#bcBar .tick');tk.forEach((t,ix)=>t.style.display=G.bc.thr.includes([25,50,75][ix])?'':'none');}const ba=60*perk('bcar');G.bc.hp+=ba;G.bc.maxHp+=ba;
    if(M.relays)G.relays=[0,1,2].map(()=>({x:0,y:0,cut:false,rep:0}));
    layoutBeacon();p.x=G.bc.x;p.y=G.bc.y+bcRing()*.6;p.px=p.x;p.py=p.y;
    if(M.rocks)spawnRocks(M.rocks);
    G.script=M.script.map(o=>({...o,done:false}));
    G.evAt=[];for(let k=0;k<(M.events||0);k++)G.evAt.push(rnd(25,85));G.evAt.sort((a,b)=>a-b);
  }else{G.script=[];G.evAt=[];}
  secReset();computeStats();t74Init(M);t80Init(M);
}
function updateWaves(dt){
  G.mT+=dt;
  const M=MISSIONS[G.m-1];
  const alive=G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive).length+G.warns.length,aliveW=alive-(G.x90&&G.x90.alarmOn?ob96N():0);
  if(G.spawnQ.length){G.spawnT-=dt;if(G.spawnT<=0&&aliveW<G.waveCap){const ty=G.spawnQ.shift();if(typeof ty==='string'&&ty.startsWith('pack:'))packSpawn(ty.slice(5));else if(typeof ty==='string'&&ty.startsWith('mem:'))mem100Spawn(ty.slice(4));else if(typeof ty==='string'&&ty.startsWith('e95:'))edgeSpawn(EDEF[ty.slice(4)]?ty.slice(4):'gunner',{e95:1});else edgeSpawn(ty);G.spawnT=clamp(3.2/G.waveSize,.18,.5);}}
  else if(G.waveIdx<G.waves.length){
    G.waveT+=dt;const SSw=secScale();
    const ready=!(G.waveHold>0)&&(G.waveIdx===0||G.waveForce||aliveW<=Math.max(SSw?2:1,Math.floor(G.waveSize*.3))||G.waveT>24);
    if(ready){G.gapT-=dt;if(G.gapT<=0){G.waveCap=Math.max(1,Math.round(G.waveBase[G.waveIdx]*liveMul()));G.spawnQ=G.waves[G.waveIdx].slice();G.waveSize=G.spawnQ.length;G.waveIdx++;if(M.debut&&G.waveIdx===1)G.waveHold=6;G.spawnT=0;G.waveT=0;G.gapT=SSw?1.2:1.6;G.waveForce=false;
      if(!noHeal()&&G.player.hp<G.st.maxHp*.6&&Math.random()<.5*curDiff().rep)G.pick.push({k:'rep',x:rnd(W*.25,W*.75),y:rnd(H*.3,H*.7),vx:0,vy:0,r:10,t:0,life:25});}}
  }
  else if((M.boss||M.sboss)&&!G.bossSpawned){if(alive===0){G.gapT-=dt;if(G.gapT<=0){G.bossSpawned=true;if(M.sboss)spawnSB(M.sboss);else spawnBoss();}}}
  else if(!M.boss&&!M.sboss&&alive===0&&G.endT<=0&&!x110Block()){G.endT=1.6;G.enemies.forEach(e=>{if(e.type==='mine')e.life=0;});banner('ЗОНА ЧИСТА','СБОР ДАННЫХ');return;}
  if(G.endT>0){G.endT-=dt;if(G.endT<=0)missionComplete();}
}
function sigProgress(){const n=G.waves.length;if(!n||!G.waveIdx)return 0;const alive=G.enemies.filter(e=>e.alive&&!EDEF[e.type].passive).length+G.warns.length+G.spawnQ.length;return clamp((G.waveIdx-1+clamp(1-alive/Math.max(1,G.waveSize),0,1))/n,0,1);}

// ---------- Обновление кадра ----------
function update(dt){
  applyWH();BW=W;BH=H;missionCam(dt);
  G.t+=dt;
  if(G.mode==='world'&&G.state==='play')radioTick(dt,'mission');
  if(G.deadT>0){G.deadT-=dt;updateFx(dt);if(G.deadT<=0)gameOver();return;}
  updatePlayer(dt);t75Tick(dt);t80Tick(dt);secTick(dt);if(inMission())t74Tick(dt);tiredTick(dt);regenTick(dt);comboTick();
  for(const w of G.warns){w.t-=dt;if(w.t<=0){const o2={};if(w.o){if(w.o.pair)o2.pair=w.o.pair;if(w.o.elite)o2.elite=true;if(w.o.mem100)o2.mem100=1;}const e=spawnEnemy(w.type,w.x,w.y,o2);const a=Math.atan2(H/2-w.y,W/2-w.x);e.vx=Math.cos(a)*e.spd;e.vy=Math.sin(a)*e.spd;spawned95(e,w);}}
  G.warns=G.warns.filter(w=>w.t>0);
  updateEnemies(dt);
  if(G.bc){updateRocks(dt);updateRelays(dt);updateStorm(dt);updateEvents(dt);}
  updateFields(dt);
  updateBullets(dt);updatePickups(dt);
  if(G.bc){updateBeacon(dt);if(G.deadT<=0)updateDirector(dt);}else if(G.mode==='endless')updateEndless(dt);else updateWaves(dt);
  if(G.mode==='endless'&&G.endT>0)G.endT=Math.max(0,G.endT-dt);
  updateFx(dt);
  runLvlUp6(G.player);
  if((G.lvlQ>0||G.bpQ>0)&&G.state==='play'&&G.endT<=0&&G.deadT<=0)nextPick();
}
function updateFx(dt){
  for(const q of G.parts){q.x+=q.vx*dt;q.y+=q.vy*dt;q.vx*=Math.pow(.15,dt);q.vy*=Math.pow(.15,dt);q.life-=dt;}G.parts=G.parts.filter(q=>q.life>0);
  for(const f of G.float){f.y-=28*dt;f.life-=dt;}G.float=G.float.filter(f=>f.life>0);
  for(const s of G.shock){s.t+=dt*(s.slow?.9:2.6);s.r=s.R*Math.min(1,s.t);}G.shock=G.shock.filter(s=>s.t<1);
  G.shake=Math.max(0,G.shake-dt*30);G.hurtV=Math.max(0,G.hurtV-dt*2);G.lightFull=Math.max(0,G.lightFull-dt*.9);
  if(banT>0){banT-=dt;if(banT<=0)$('#banner').classList.remove('show');}
}

// ---------- Отрисовка ----------
function render(now){
  const t=now/1000;
  ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  if(nebula)ctx.drawImage(nebula,0,0,cv.width,cv.height);
  const sx=G.shake?rnd(-G.shake,G.shake):0,sy=G.shake?rnd(-G.shake,G.shake):0;
  ctx.setTransform(DPR*SC,0,0,DPR*SC,sx*DPR*SC,sy*DPR*SC);
  const p=G.player;
  const ox=p?(p.x-W/2):Math.sin(t*.05)*200,oy=p?(p.y-H/2):Math.cos(t*.04)*120;
  for(const s of stars){const x=((s.x-ox*s.k-t*6*s.k*10)%(VW*1.2)+VW*1.2)%(VW*1.2)-VW*.1,y=((s.y-oy*s.k)%(VH*1.2)+VH*1.2)%(VH*1.2)-VH*.1;
    ctx.globalAlpha=.45+.4*Math.sin(t*1.3+s.tw);ctx.fillStyle=s.k>.06?'#cfeeff':'#7f9ab5';ctx.fillRect(x,y,s.s,s.s);}
  ctx.globalAlpha=1;
  if(!p||G.state==='menu'||G.state==='codex'&&!G.inRun)return;
  if(G.arena)ctx.setTransform(DPR*SC,0,0,DPR*SC,(sx-CX)*DPR*SC,(sy-CY)*DPR*SC);
  if(G.arena)drawArenaEdge(p,t);bg110(t);
  const bc=G.bc;

  // маяк: линии и кольцо
  if(bc){
    for(const r of G.relays){
      if(r.cut){ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.35+.35*(Math.sin(t*10)>0?1:0);ctx.setLineDash([4,10]);}
      else{ctx.strokeStyle='#8fe9ff';ctx.globalAlpha=.45;ctx.setLineDash([]);}
      ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(r.x,r.y);ctx.lineTo(bc.x,bc.y);ctx.stroke();ctx.setLineDash([]);
      if(!r.cut){const k=(t*.6+r.x*.001)%1;ctx.globalAlpha=.9;ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(r.x+(bc.x-r.x)*k,r.y+(bc.y-r.y)*k,2,0,TAU);ctx.fill();}
      ctx.globalAlpha=1;glow(r.x,r.y,24,r.cut?'#ff4f6e':'#8fe9ff',.5);
      ctx.fillStyle='#0b1220';ctx.strokeStyle=r.cut?'#ff4f6e':'#8fe9ff';ctx.lineWidth=2;ctx.save();ctx.translate(r.x,r.y);poly(3,12,-Math.PI/2);ctx.fill();ctx.stroke();ctx.restore();
      if(r.cut&&r.rep>0){ctx.strokeStyle='#8fe9ff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(r.x,r.y,18,-Math.PI/2,-Math.PI/2+TAU*r.rep/2);ctx.stroke();}
    }
    const rr=bcRing();ctx.strokeStyle=bc.inRing?'#ffb84d':'#7a5a24';ctx.globalAlpha=bc.inRing?.75:.5;ctx.lineWidth=1.5;ctx.setLineDash([6,8]);ctx.lineDashOffset=-t*20;ctx.beginPath();ctx.arc(bc.x,bc.y,rr,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.globalAlpha=1;
    if(bc.inRing&&bc.rate>0&&SET.fx&&Math.random()<.5){const a=rnd(0,TAU);part(bc.x+Math.cos(a)*rr,bc.y+Math.sin(a)*rr,-Math.cos(a)*rr*1.6,-Math.sin(a)*rr*1.6,.5,'#ffb84d',2);}
  }
  drawRocks(G.rocks);if(G.s1)s1DrawUnder(t);if(G.post)postDrawUnder(t);
  drawPickups();

  // предупреждения о появлении
  for(const w of G.warns){if(w.t>.7||G.noTele)continue;const a=1-w.t/.7;ctx.save();ctx.translate(w.mx,w.my);ctx.rotate(Math.atan2(H/2-w.my,W/2-w.mx));ctx.strokeStyle=EDEF[w.type].col;ctx.globalAlpha=.4+.6*Math.abs(Math.sin(w.t*18));ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(-6,-8);ctx.lineTo(4,0);ctx.lineTo(-6,8);ctx.stroke();ctx.beginPath();ctx.arc(0,0,10+a*8,0,TAU);ctx.globalAlpha*=.4;ctx.stroke();ctx.restore();}
  ctx.globalAlpha=1;

  // поля, метеоры, гравитация
  for(const f of G.fields){if(f.ice||f.rust)continue;const k=f.t/f.max;ctx.strokeStyle='#6bf0ff';ctx.globalAlpha=.3+.4*k;ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<=24;i++){const a=i/24*TAU,rr=f.r*(1+rnd(-.06,.06));ctx.lineTo(f.x+Math.cos(a)*rr,f.y+Math.sin(a)*rr);}ctx.stroke();
    ctx.fillStyle='#6bf0ff';ctx.globalAlpha=.06+.08*k;ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,TAU);ctx.fill();ctx.globalAlpha=1;}
  for(const m of G.meteors){if(m.t<=0)continue;ctx.strokeStyle='#ffb07a';ctx.globalAlpha=.5+.4*Math.sin(t*20);ctx.lineWidth=2;ctx.beginPath();ctx.arc(m.x,m.y,46,0,TAU);ctx.stroke();
    ctx.globalAlpha=1-m.t/1.1;ctx.beginPath();ctx.arc(m.x,m.y,46*(1-m.t/1.1),0,TAU);ctx.stroke();
    const k=m.t/1.1;ctx.globalAlpha=1;glow(m.x-k*160,m.y-k*260,14,'#ffb07a',.9);ctx.globalAlpha=1;}
  for(const e of G.enemies){if(e.type==='vortex'&&e.alive&&e.spawnT<=0){ctx.strokeStyle='#7d6bff';ctx.lineWidth=1.5;for(let i=0;i<3;i++){ctx.globalAlpha=.18;ctx.beginPath();const ph=t*2+i*2.1;for(let s=0;s<40;s++){const rr=240*(1-s/40),a=ph+s*.25;ctx.lineTo(e.x+Math.cos(a)*rr,e.y+Math.sin(a)*rr);}ctx.stroke();}ctx.globalAlpha=1;}}

  // связи, телеграфы, тросы
  for(const e of G.enemies){
    if(!e.alive)continue;
    if(e.type==='shielder'&&e.links){ctx.strokeStyle='#9c8cff';ctx.lineWidth=1.5;ctx.globalAlpha=.35+.2*Math.sin(t*6);for(const o of e.links){ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(o.x,o.y);ctx.stroke();}ctx.globalAlpha=1;}
    if(e.type==='commander'&&e.spawnT<=0){ctx.strokeStyle='#ffa63d';ctx.globalAlpha=.15;ctx.lineWidth=1;ctx.setLineDash([3,6]);ctx.beginPath();ctx.arc(e.x,e.y,220,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
    if(e.type==='twin'&&e.mate&&e.mate.alive&&e.uid<e.mate.uid){ctx.strokeStyle='#ff6bd0';ctx.globalAlpha=e.down>0||e.mate.down>0?.8:.3;ctx.lineWidth=e.down>0||e.mate.down>0?3:1.5;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.mate.x,e.mate.y);ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='leech'&&e.att&&bc){ctx.strokeStyle='#c46bff';ctx.globalAlpha=.6+.3*Math.sin(t*12+e.seed);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(bc.x,bc.y);ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='antenna'&&bc&&e.spawnT<=0){ctx.strokeStyle='#4dd0ff';ctx.globalAlpha=.5;ctx.lineWidth=1.5;ctx.setLineDash([2,6]);ctx.lineDashOffset=t*30;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(bc.x,bc.y);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;ctx.globalAlpha=1;}
    if(e.type==='tug'&&e.rock){ctx.strokeStyle='#c9a36b';ctx.lineWidth=2;ctx.globalAlpha=.9;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.rock.x,e.rock.y);ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='shell'&&!G.noTele){ctx.strokeStyle='#ff8f5a';ctx.globalAlpha=.5+.4*Math.sin(t*16);ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.tx,e.ty,30,0,TAU);ctx.stroke();ctx.beginPath();ctx.arc(e.tx,e.ty,30*(e.ft/e.dur),0,TAU);ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='cutter'&&e.cutting&&!G.noTele){ctx.strokeStyle='#ff4f6e';ctx.globalAlpha=.8;ctx.beginPath();ctx.arc(e.x,e.y,e.r+6,-Math.PI/2,-Math.PI/2+TAU*(e.cutT/.9));ctx.lineWidth=2;ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='rammer')laneRammer(e);
    if(e.type==='shocker'&&e.st==='charge'&&!G.noTele){ctx.strokeStyle='#6bf0ff';ctx.globalAlpha=.3+.5*(1-e.timer/.6);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(e.x,e.y,115*(1-e.timer/.6),0,TAU);ctx.stroke();ctx.globalAlpha=1;}
    if(e.type==='lancer'&&e.st!=='seek'){const ex=e.x+Math.cos(e.aim)*2000,ey=e.y+Math.sin(e.aim)*2000;
      if(e.st==='fire'){ctx.globalCompositeOperation='lighter';ctx.strokeStyle='#ff3dbb';ctx.lineWidth=14;ctx.globalAlpha=.5;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(ex,ey);ctx.stroke();ctx.strokeStyle='#ffffff';ctx.lineWidth=4;ctx.globalAlpha=1;ctx.stroke();ctx.globalCompositeOperation='source-over';}
      else if(!G.noTele){ctx.strokeStyle='#ff3dbb';ctx.lineWidth=e.st==='lock'?2.5:1;ctx.globalAlpha=e.st==='lock'?(Math.sin(t*50)>0?1:.4):.5;ctx.setLineDash(e.st==='lock'?[]:[8,8]);ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(ex,ey);ctx.stroke();ctx.setLineDash([]);}
      ctx.globalAlpha=1;}
  }
  const B=G.boss;
  if(B&&B.atk&&B.atk.type==='sweep'&&B.atk.ang!==undefined){const A=B.atk,ex=B.x+Math.cos(A.ang)*2000,ey=B.y+Math.sin(A.ang)*2000;
    if(A.t<1){if(!G.noTele){ctx.strokeStyle='#b48cff';ctx.globalAlpha=.4+.4*Math.sin(t*30);ctx.lineWidth=2;ctx.setLineDash([12,10]);ctx.beginPath();ctx.moveTo(B.x,B.y);ctx.lineTo(ex,ey);ctx.stroke();ctx.setLineDash([]);
      ctx.beginPath();ctx.arc(B.x,B.y,90,A.a0,A.a0+A.dir*1.9,A.dir<0);ctx.stroke();}}
    else{ctx.globalCompositeOperation='lighter';ctx.strokeStyle='#b48cff';ctx.globalAlpha=.45;ctx.lineWidth=30;ctx.beginPath();ctx.moveTo(B.x,B.y);ctx.lineTo(ex,ey);ctx.stroke();ctx.strokeStyle='#ffffff';ctx.globalAlpha=1;ctx.lineWidth=6;ctx.stroke();ctx.globalCompositeOperation='source-over';}
    ctx.globalAlpha=1;}

  if(bc)drawBeacon(bc,t);
  if(G.fake){ctx.globalAlpha=.5+.5*(Math.sin(t*14)>0?1:.4);drawMiniBeacon(G.fake.x,G.fake.y,'#ffb84d',t);ctx.globalAlpha=1;}
  if(G.lureP){ctx.globalAlpha=G.lureP.t;ctx.save();ctx.translate(G.lureP.x,G.lureP.y);ctx.strokeStyle='#8fe9ff';ctx.setLineDash([3,4]);ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.stroke();ctx.setLineDash([]);ctx.restore();ctx.globalAlpha=1;}

  if(inMission())d74Under(t);
  if(inMission())d80Under(t);
  for(const e of G.enemies){if(e.type==='shade'&&G.dark&&!visibleAt(e.x,e.y)&&!(e.reveal>0)&&!inStorm(e.x,e.y))continue;drawEnemy(e,t);}
  secDraw(t);secDraw2(t);if(inMission())d74Draw(t);if(inMission())d80Draw(t);

  ctx.globalCompositeOperation='lighter';
  const BC=shipBul();for(const b of G.pb){if(b.blast){glow(b.x,b.y,b.charged?34:22,'#9fe3ff',.8);ctx.strokeStyle='#9fe3ff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(b.x-b.vx*.03,b.y-b.vy*.03);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.fillStyle='#dff6ff';ctx.beginPath();ctx.arc(b.x,b.y,b.charged?7:4.5,0,TAU);ctx.fill();continue;}if(b.charged){glow(b.x,b.y,34,BC,.9);ctx.strokeStyle='#ffffff';ctx.lineWidth=7;ctx.beginPath();ctx.moveTo(b.x-b.vx*.05,b.y-b.vy*.05);ctx.lineTo(b.x,b.y);ctx.stroke();continue;}ctx.strokeStyle=b.drone?'#c9b6ff':b.turret?'#ffcf80':BC;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(b.x-b.vx*.018,b.y-b.vy*.018);ctx.lineTo(b.x,b.y);ctx.stroke();}
  ctx.globalCompositeOperation='source-over';

  if(inMission())w80Mask(G.arena?sx-CX:sx,G.arena?sy-CY:sy);if(inMission()){sb85Top(t);top90(t);top110(t);}
  if(G.s1)s1DrawOver(t);if(G.post)postDrawOver(t);
  if(G.dark){drawDark(G.arena?sx-CX:sx,G.arena?sy-CY:sy);
    if(G.storm&&G.storm.warn<=0){ctx.strokeStyle='#8fd8ff';ctx.lineWidth=1.5;ctx.setLineDash([3,4]);ctx.lineDashOffset=-t*20;for(const e of G.enemies){if(!e.alive||e.spawnT>0||!inStorm(e.x,e.y)||visibleAt(e.x,e.y))continue;ctx.globalAlpha=.75;ctx.beginPath();ctx.arc(e.x,e.y,e.r+6,0,TAU);ctx.stroke();}ctx.setLineDash([]);ctx.globalAlpha=1;}}

  ctx.globalCompositeOperation='lighter';
  for(const b of G.eb){if(b.rift)continue;glow(b.x,b.y,Math.max(b.r*3.2,BMIN*4.5),b.col,.8);}
  ctx.globalCompositeOperation='source-over';
  for(const b of G.eb){if(b.k95){eb95Draw(b,t);continue;}if(b.copy){ctx.strokeStyle=b.col;ctx.lineWidth=3;ctx.globalAlpha=.9;ctx.beginPath();ctx.moveTo(b.x-b.vx*.02,b.y-b.vy*.02);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.globalAlpha=1;continue;}if(b.rift){ctx.strokeStyle='#ff4f6e';ctx.lineWidth=4;ctx.globalAlpha=.5;ctx.beginPath();ctx.moveTo(b.x-b.vx*.03,b.y-b.vy*.03);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.globalAlpha=1;ctx.stroke();continue;}ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(b.x,b.y,Math.max(b.r*.55,BMIN),0,TAU);ctx.fill();if(BMIN||G.ol95){ctx.strokeStyle='#04060c';ctx.lineWidth=(G.ol95?1.5:1)/SC;ctx.stroke();}}

  drawPlayer(p,t);

  ctx.globalCompositeOperation='lighter';
  for(const q of G.parts){ctx.globalAlpha=q.life/q.max;ctx.fillStyle=q.col;ctx.fillRect(q.x-q.size/2,q.y-q.size/2,q.size,q.size);}
  for(const s of G.shock){ctx.globalAlpha=(1-s.t)*(s.thin?.5:.8);ctx.strokeStyle=s.col;ctx.lineWidth=s.thin?2:5*(1-s.t)+1;ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,TAU);ctx.stroke();}
  ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';

  // ионная буря
  const S=G.storm;if(S){const x0=S.axis==='x'?S.pos-S.w/2:0,y0=S.axis==='y'?S.pos-S.w/2:0,w=S.axis==='x'?S.w:W,h=S.axis==='y'?S.w:H;
    if(S.warn>0){ctx.strokeStyle='#7d9bff';ctx.globalAlpha=.4+.4*Math.sin(t*12);ctx.setLineDash([10,8]);ctx.lineWidth=2;
      const entry=S.dir>0?0:(S.axis==='x'?W:H);ctx.beginPath();if(S.axis==='x'){ctx.moveTo(entry,0);ctx.lineTo(entry,H);}else{ctx.moveTo(0,entry);ctx.lineTo(W,entry);}ctx.stroke();ctx.setLineDash([]);}
    else{ctx.font='700 11px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#bcd0ff';ctx.globalAlpha=.75;if(S.axis==='x')ctx.fillText('ИОННАЯ БУРЯ',S.pos,((t*60)%(H+40))-20);else ctx.fillText('ИОННАЯ БУРЯ',((t*80)%(W+120))-60,S.pos+4);
      ctx.fillStyle='#4a5cff';ctx.globalAlpha=.12;ctx.fillRect(x0,y0,w,h);ctx.strokeStyle='#9fb4ff';ctx.globalAlpha=.25;ctx.lineWidth=1;
      for(let i=0;i<14;i++){ctx.beginPath();if(S.axis==='x'){const x=x0+Math.random()*w,y=Math.random()*H;ctx.moveTo(x,y);ctx.lineTo(x+rnd(-20,20),y+rnd(20,60));}else{const x=Math.random()*W,y=y0+Math.random()*h;ctx.moveTo(x,y);ctx.lineTo(x+rnd(20,60),y+rnd(-20,20));}ctx.stroke();}}
    ctx.globalAlpha=1;}
  if(G.flare>0){ctx.fillStyle='#ffb84d';ctx.globalAlpha=.05+.03*Math.sin(t*4);ctx.fillRect(0,0,W,H);ctx.globalAlpha=1;}

  if(G.prio&&G.prio.alive){const e=G.prio,r=e.r+10,a=t*2;ctx.strokeStyle='#ffffff';ctx.lineWidth=2;
    for(let i=0;i<4;i++){const q=a+i*Math.PI/2;ctx.beginPath();ctx.arc(e.x,e.y,r,q,q+.5);ctx.stroke();}
    ctx.font='700 '+fpx(10)+'px "JetBrains Mono",monospace';ctx.fillStyle='#ffffff';ctx.textAlign='center';ctx.fillText('ЦЕЛЬ',e.x,e.y-r-6);}

  ctx.textAlign='center';ctx.font='700 '+fpx(12)+'px "JetBrains Mono",monospace';
  for(const f of G.float){ctx.globalAlpha=Math.min(1,f.life*2);ctx.fillStyle='#04060c';ctx.fillText(f.text,f.x+1,f.y+1);ctx.fillStyle=f.col;ctx.fillText(f.text,f.x,f.y);}
  ctx.globalAlpha=1;

  if(aimManual()&&p&&p.hp>0&&(G.state==='play'||G.state==='world')){const m=mouseWorld(),c=shipCol();ctx.strokeStyle=c;ctx.lineWidth=1;ctx.globalAlpha=.85;
    for(let i=0;i<4;i++){const a=i*Math.PI/2;ctx.beginPath();ctx.moveTo(m.x+Math.cos(a)*3,m.y+Math.sin(a)*3);ctx.lineTo(m.x+Math.cos(a)*6,m.y+Math.sin(a)*6);ctx.stroke();}
    ctx.fillStyle=c;ctx.fillRect(m.x-.75,m.y-.75,1.5,1.5);
    const L=G.aimLock;if(L&&L.alive){const r=L.r+7,q=5;ctx.lineWidth=1.5;ctx.globalAlpha=.95;for(const [sx2,sy2] of [[-1,-1],[1,-1],[1,1],[-1,1]]){ctx.beginPath();ctx.moveTo(L.x+sx2*r,L.y+sy2*(r-q));ctx.lineTo(L.x+sx2*r,L.y+sy2*r);ctx.lineTo(L.x+sx2*(r-q),L.y+sy2*r);ctx.stroke();}}
    ctx.globalAlpha=1;}
  const lowHp=p.hp>0&&p.hp<G.st.maxHp*.25,lowBc=bc&&bc.hp<bc.maxHp*.3&&bc.hp>0;
  if(G.hurtV>0||lowHp||lowBc){ctx.setTransform(1,0,0,1,0,0);const v=Math.max(G.hurtV*.55,lowHp||lowBc?.16+.08*Math.sin(t*5):0);
    const g=ctx.createRadialGradient(cv.width/2,cv.height/2,Math.min(cv.width,cv.height)*.35,cv.width/2,cv.height/2,Math.max(cv.width,cv.height)*.7);g.addColorStop(0,'rgba(255,40,70,0)');g.addColorStop(1,`rgba(255,40,70,${v})`);ctx.fillStyle=g;ctx.fillRect(0,0,cv.width,cv.height);}
}
function drawRocks(list){
  for(const r of list){ctx.save();ctx.translate(r.x,r.y);ctx.rotate(r.rot);ctx.beginPath();r.v.forEach((v,i)=>{const a=i/r.v.length*TAU;ctx.lineTo(Math.cos(a)*v,Math.sin(a)*v);});ctx.closePath();
    ctx.fillStyle=r.hitF>0?'#3a4658':'#151d2a';ctx.fill();ctx.strokeStyle=r.flung?'#ff8f5a':'#5d6e86';ctx.lineWidth=2;ctx.stroke();ctx.restore();
    if(r.flung){ctx.strokeStyle='#ff8f5a';ctx.globalAlpha=.4;ctx.beginPath();ctx.moveTo(r.x,r.y);ctx.lineTo(r.x-r.vx*.25,r.y-r.vy*.25);ctx.lineWidth=r.r;ctx.stroke();ctx.globalAlpha=1;}}
}
function drawLomIcon(s){ctx.lineWidth=1.4;ctx.strokeStyle='#c9d2de';ctx.fillStyle='#141c28';ctx.beginPath();for(let i=0;i<6;i++){const a=-Math.PI/2+i*Math.PI/3;ctx.lineTo(Math.cos(a)*s*.75,Math.sin(a)*s*.75);}ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle='#ffb84d';ctx.beginPath();ctx.moveTo(0,-s*.75);ctx.lineTo(Math.cos(-Math.PI/6)*s*.75,Math.sin(-Math.PI/6)*s*.75);ctx.lineTo(0,0);ctx.closePath();ctx.fill();
  ctx.fillStyle='#04060c';ctx.beginPath();ctx.arc(0,0,s*.24,0,TAU);ctx.fill();ctx.stroke();}
function drawPickups(){
  for(const k of G.pick){
    const fade=k.life<3?(Math.sin(k.life*14)>0?1:.3):1;ctx.globalAlpha=fade;
    if(k.k==='lom'){glow(k.x,k.y,12,'#ffb84d',.35);ctx.save();ctx.translate(k.x,k.y);ctx.rotate(k.t*1.5);drawLomIcon(9);ctx.restore();}
    else if(k.k==='xp'){glow(k.x,k.y,12,'#b48cff',.7);ctx.fillStyle='#d9c8ff';ctx.save();ctx.translate(k.x,k.y);ctx.rotate(k.t*3);ctx.fillRect(-3,-3,6,6);ctx.restore();}
    else if(k.k==='cell'){const unstable=k.stab>0;glow(k.x,k.y,24,'#ffb84d',unstable?.35+.3*Math.sin(k.t*20):.8);
      ctx.save();ctx.translate(k.x,k.y);ctx.strokeStyle='#ffb84d';ctx.lineWidth=2;ctx.fillStyle=unstable?'#3a2a10':'#ffb84d';
      poly(6,8,Math.PI/6);ctx.fill();ctx.stroke();
      if(unstable){ctx.beginPath();ctx.arc(0,0,14,-Math.PI/2,-Math.PI/2+TAU*(1-k.stab/2));ctx.stroke();}ctx.restore();}
    else{glow(k.x,k.y,22,'#8fe9ff',.6);ctx.save();ctx.translate(k.x,k.y);ctx.fillStyle='#0b1a28';ctx.strokeStyle='#8fe9ff';ctx.lineWidth=2;ctx.fillRect(-9,-9,18,18);ctx.strokeRect(-9,-9,18,18);
      ctx.fillStyle='#8fe9ff';ctx.fillRect(-2,-6,4,12);ctx.fillRect(-6,-2,12,4);ctx.restore();}
  }
  ctx.globalAlpha=1;
}
function drawDark(sx,sy){
  if(!darkC||darkC.width!==cv.width||darkC.height!==cv.height){darkC=document.createElement('canvas');darkC.width=cv.width;darkC.height=cv.height;dctx=darkC.getContext('2d');}
  const k=DPR*SC,p=G.player;
  dctx.globalCompositeOperation='source-over';dctx.clearRect(0,0,darkC.width,darkC.height);
  dctx.fillStyle=`rgba(1,2,7,${(.93*(1-G.lightFull)).toFixed(3)})`;dctx.fillRect(0,0,darkC.width,darkC.height);
  dctx.globalCompositeOperation='destination-out';
  const hole=(x,y,r)=>{const X=(x+sx)*k,Y=(y+sy)*k,R=r*k;const g=dctx.createRadialGradient(X,Y,R*.35,X,Y,R);g.addColorStop(0,'rgba(0,0,0,1)');g.addColorStop(1,'rgba(0,0,0,0)');dctx.fillStyle=g;dctx.beginPath();dctx.arc(X,Y,R,0,TAU);dctx.fill();};
  if(G.bc)hole(G.bc.x,G.bc.y,beaconLight());
  if(p)hole(p.x,p.y,G.st.light);
  for(const e of G.enemies)if(e.reveal>0)hole(e.x,e.y,55);
  {const S=G.storm;if(S&&S.warn<=0){dctx.fillStyle='rgba(0,0,0,.5)';if(S.axis==='x')dctx.fillRect((S.pos-S.w/2+sx)*k,0,S.w*k,darkC.height);else dctx.fillRect(0,(S.pos-S.w/2+sy)*k,darkC.width,S.w*k);}}
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(darkC,0,0);ctx.restore();
}
function drawMiniBeacon(x,y,col,t){ctx.save();ctx.translate(x,y);glow(0,0,50,col,.5);ctx.fillStyle='#0b1220';ctx.strokeStyle=col;ctx.lineWidth=2;poly(8,24,t*.3);ctx.fill();ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,7,0,TAU);ctx.fill();ctx.restore();}
function drawBeacon(bc,t){
  const R=bc.r,col=bc.cool>0?'#ff6b4d':'#ffb84d';
  ctx.save();ctx.translate(bc.x,bc.y);
  if(SET.fx){ctx.globalCompositeOperation='lighter';const len=bc.cool>0?260:440;
    for(let k=0;k<2;k++){const ang=t*.9+k*Math.PI;const g=ctx.createLinearGradient(0,0,Math.cos(ang)*len,Math.sin(ang)*len);g.addColorStop(0,col+'40');g.addColorStop(1,col+'00');ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(0,0);ctx.arc(0,0,len,ang-.15,ang+.15);ctx.closePath();ctx.fill();}
    ctx.globalCompositeOperation='source-over';}
  glow(0,0,R*2.6,col,.55+.25*bc.charge/100);
  ctx.fillStyle=bc.hitF>0?'#3a1a1a':'#0b1220';ctx.strokeStyle=bc.hitF>0?'#ff4f6e':col;ctx.lineWidth=2.5;poly(8,R,Math.PI/8);ctx.fill();ctx.stroke();
  ctx.save();ctx.rotate(bc.rot*.7);ctx.lineWidth=2;for(let i=0;i<6;i++){ctx.beginPath();ctx.arc(0,0,R*.68,i/6*TAU,i/6*TAU+.6);ctx.stroke();}ctx.restore();
  ctx.fillStyle=col;ctx.globalAlpha=.4+.6*bc.charge/100;ctx.beginPath();ctx.arc(0,0,R*.36,0,TAU);ctx.fill();ctx.globalAlpha=1;
  ctx.strokeStyle='rgba(255,184,77,.18)';ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,0,R+9,0,TAU);ctx.stroke();
  ctx.strokeStyle=bc.transStarted?'#8fe9ff':'#ffb84d';ctx.beginPath();ctx.arc(0,0,R+9,-Math.PI/2,-Math.PI/2+TAU*bc.charge/100);ctx.stroke();
  ctx.strokeStyle='#04060c';ctx.lineWidth=2;for(const q of [25,50,75]){const a=-Math.PI/2+TAU*q/100;ctx.beginPath();ctx.moveTo(Math.cos(a)*(R+6),Math.sin(a)*(R+6));ctx.lineTo(Math.cos(a)*(R+12),Math.sin(a)*(R+12));ctx.stroke();}
  if(bc.mods.turret){ctx.save();ctx.rotate(bc.turA);ctx.fillStyle='#ffcf80';ctx.fillRect(R*.3,-3,R*.9,6);ctx.restore();}
  if(bc.barrier>0){ctx.strokeStyle=bc.barF>0?'#ffffff':'#8fe9ff';ctx.globalAlpha=.25+.35*bc.barrier/100;ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,R+20,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
  if(bc.cool>0&&SET.fx&&Math.random()<.5)part(bc.x+rnd(-10,10),bc.y+rnd(-10,10),rnd(-40,40),rnd(-90,-30),.7,'#ff8a6b',3);
  if(bc.transStarted&&!bc.transDone){ctx.strokeStyle='#8fe9ff';ctx.globalAlpha=.6;ctx.lineWidth=1.5;const k=(t*1.2)%1;ctx.beginPath();ctx.arc(0,0,R+20+k*120,0,TAU);ctx.globalAlpha=.6*(1-k);ctx.stroke();ctx.globalAlpha=1;}
  ctx.restore();
}
function drawPlayer(p,t){
  if(p.hp<=0)return;
  const SKID=curSkin(),SKC=SKINS[SKID].trail;
  for(const tr of p.trail){glow(tr.x,tr.y,10,SKC,Math.min(1,tr.t*3));}
  const st=G.st;
  for(let i=0;i<st.drones;i++){const a=p.droneA+i*Math.PI,x=p.x+Math.cos(a)*34,y=p.y+Math.sin(a)*34;glow(x,y,12,'#b48cff',.7);ctx.fillStyle='#e2d6ff';ctx.beginPath();ctx.arc(x,y,4,0,TAU);ctx.fill();}
  ctx.globalAlpha=p.inv>0&&p.dashT<=0&&Math.sin(t*40)<0?.4:1;
  ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.ang);
  const sp=Math.hypot(p.vx,p.vy);
  drawShip(SKID,t,sp,{noDash:p.noDash>0});
  for(let i=0;i<p.cargo;i++){ctx.fillStyle='#ffb84d';ctx.fillRect(-9-i*6,-2.5,4,5);}
  ctx.restore();ctx.globalAlpha=1;
  if(p.chg>0){const q=Math.min(1,p.chg/CHG_T);ctx.strokeStyle=q>=1?'#ffffff':shipCol();ctx.lineWidth=q>=1?3:2;ctx.globalAlpha=q>=1?.7+.3*Math.sin(t*20):.8;ctx.beginPath();ctx.arc(p.x,p.y,30,-Math.PI/2,-Math.PI/2+TAU*q);ctx.stroke();ctx.globalAlpha=1;if(q>=1)glow(p.x+Math.cos(p.ang)*18,p.y+Math.sin(p.ang)*18,22,'#ffffff',.6);}
  if(p.shieldUp){ctx.strokeStyle='#8fe9ff';ctx.globalAlpha=.35+.15*Math.sin(t*4);ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(p.x,p.y,24,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
  if(p.noDash>0){ctx.strokeStyle='#6bf0ff';ctx.globalAlpha=.5;ctx.lineWidth=1;for(let i=0;i<3;i++){const a=rnd(0,TAU);ctx.beginPath();ctx.moveTo(p.x+Math.cos(a)*10,p.y+Math.sin(a)*10);ctx.lineTo(p.x+Math.cos(a+.4)*22,p.y+Math.sin(a+.4)*22);ctx.stroke();}ctx.globalAlpha=1;}
}
function poly(n,r,rot=0){ctx.beginPath();for(let i=0;i<n;i++){const a=rot+i/n*TAU;ctx.lineTo(Math.cos(a)*r,Math.sin(a)*r);}ctx.closePath();}
function drawEnemy(e,t,icon){
  if(EDEF[e.type].zb){if(icon)zbIcon(e);else if(e.zb===2)zbDrawCopy(e,t);else zbDrawBoss(e,t);return;}
  const d=EDEF[e.type],col=e.flash>0?'#ffffff':e.rebuilt?'#b5652e':e.mem100?'#a8b4b0':d.col;
  if(!icon&&e.type!=='mine'&&e.type!=='shell'&&e.type!=='obseg'&&!e.ghost&&!e.hid90)glow(e.x,e.y,e.r*2.6,d.col,e.type==='boss'||e.type==='jam'||e.sbk?.5:.35);
  ctx.save();ctx.translate(e.x,e.y);
  let alpha=1;if(e.spawnT>0)alpha=Math.max(0,1-e.spawnT);if(e.ghost)alpha*=.22;if(e.down>0)alpha*=.35+.2*Math.sin(t*10);
  ctx.globalAlpha=alpha;
  ctx.fillStyle='#0a0f1c';ctx.strokeStyle=col;ctx.lineWidth=2;
  const face=Math.atan2(e.vy,e.vx);
  const P=G.player||{x:e.x+100,y:e.y};
  switch(e.type){
    case 'scout':case 'mite':ctx.rotate(face);ctx.beginPath();ctx.moveTo(e.r,0);ctx.lineTo(-e.r*.8,-e.r*.75);ctx.lineTo(-e.r*.4,0);ctx.lineTo(-e.r*.8,e.r*.75);ctx.closePath();ctx.fill();ctx.stroke();break;
    case 'gunner':{const a=icon?0:Math.atan2(P.y-e.y,P.x-e.x);ctx.rotate(a);poly(4,e.r);ctx.fill();ctx.stroke();ctx.fillStyle=e.charging?'#ffffff':col;ctx.fillRect(4,-2.5,e.r+2,5);
      if(e.charging&&!icon)glow(e.r+6,0,10,'#ff9a4d',G.noTele?.45:.9);break;}
    case 'rammer':ctx.rotate(e.st==='aim'||e.st==='charge'?e.aim:face);ctx.beginPath();ctx.moveTo(e.r+4,0);ctx.lineTo(-e.r,-e.r);ctx.lineTo(-e.r*.5,0);ctx.lineTo(-e.r,e.r);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.beginPath();ctx.moveTo(e.r+4,0);ctx.lineTo(0,0);ctx.stroke();break;
    case 'splitter':ctx.rotate(e.t*.8);for(let i=0;i<3;i++){const a=i/3*TAU;ctx.save();ctx.translate(Math.cos(a)*6,Math.sin(a)*6);poly(6,e.r*.55,0);ctx.fill();ctx.stroke();ctx.restore();}break;
    case 'miner':ctx.rotate(e.t*1.5);ctx.fillRect(-e.r*.7,-e.r*.7,e.r*1.4,e.r*1.4);ctx.strokeRect(-e.r*.7,-e.r*.7,e.r*1.4,e.r*1.4);ctx.rotate(Math.PI/4);ctx.strokeRect(-e.r*.45,-e.r*.45,e.r*.9,e.r*.9);break;
    case 'mine':{const armed=icon||e.arm<=0;const blink=e.fuse>0?Math.sin(t*60)>0:Math.sin(t*4)>0;
      if(!icon&&armed){ctx.globalAlpha=alpha*.12;ctx.beginPath();ctx.arc(0,0,64,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}
      poly(8,e.r,e.t);ctx.fill();ctx.stroke();ctx.fillStyle=armed&&blink?(e.fuse>0?'#ffffff':'#ffd24d'):'#5a4a20';ctx.beginPath();ctx.arc(0,0,3.5,0,TAU);ctx.fill();break;}
    case 'shielder':ctx.beginPath();ctx.arc(0,0,e.r,0,TAU);ctx.fill();ctx.stroke();ctx.rotate(e.t);ctx.setLineDash([5,5]);ctx.beginPath();ctx.arc(0,0,e.r+6,0,TAU);ctx.stroke();ctx.setLineDash([]);
      ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,4,0,TAU);ctx.fill();break;
    case 'lancer':ctx.rotate(e.st==='seek'?Math.atan2(P.y-e.y,P.x-e.x)||0:e.aim);ctx.beginPath();ctx.moveTo(e.r+10,0);ctx.lineTo(-e.r,-6);ctx.lineTo(-e.r+4,0);ctx.lineTo(-e.r,6);ctx.closePath();ctx.fill();ctx.stroke();
      if(e.st==='aim'||e.st==='lock'){ctx.fillStyle='#ff3dbb';ctx.beginPath();ctx.arc(e.r+10,0,3+2*Math.sin(t*20),0,TAU);ctx.fill();}break;
    case 'guard':ctx.rotate(e.face);poly(6,e.r,0);ctx.fill();ctx.stroke();poly(6,e.r*.5,0);ctx.stroke();
      if(!icon&&e.shieldDown>0){ctx.strokeStyle='#6b5a3a';ctx.lineWidth=2;ctx.setLineDash([3,5]);ctx.beginPath();ctx.arc(0,0,e.r+7,-1.05,1.05);ctx.stroke();ctx.setLineDash([]);}else{ctx.strokeStyle=e.shieldFlash>0?'#ffffff':'#ffb84d';ctx.lineWidth=5;ctx.beginPath();ctx.arc(0,0,e.r+7,-1.05,1.05);ctx.stroke();}ctx.lineWidth=2;break;
    case 'pylon':ctx.rotate(e.t*2);poly(4,e.r,0);ctx.fill();ctx.stroke();ctx.fillStyle=col;poly(4,e.r*.4,0);ctx.fill();break;
    case 'seeker':ctx.rotate(face);ctx.beginPath();ctx.moveTo(e.r+2,0);ctx.lineTo(-e.r,-e.r*.7);ctx.lineTo(-e.r,e.r*.7);ctx.closePath();ctx.fillStyle=col;ctx.fill();break;
    case 'boss':drawBoss(e,t);break;
    // ---- Акт II ----
    case 'moth':{ctx.rotate(face);const f=.4+.6*Math.abs(Math.sin(e.t*18+e.seed));ctx.fillStyle=col;ctx.globalAlpha=alpha*.85;
      ctx.beginPath();ctx.moveTo(2,0);ctx.lineTo(-4,-e.r*1.3*f);ctx.lineTo(-6,0);ctx.lineTo(-4,e.r*1.3*f);ctx.closePath();ctx.fill();ctx.globalAlpha=alpha;ctx.fillStyle='#ffffff';ctx.fillRect(-3,-1,6,2);break;}
    case 'leech':ctx.rotate(e.att?e.ang+Math.PI:face);ctx.beginPath();ctx.ellipse(0,0,e.r*1.2,e.r*.7,0,0,TAU);ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-e.r*1.2,0);ctx.quadraticCurveTo(-e.r*2,Math.sin(e.t*8)*6,-e.r*2.6,0);ctx.stroke();
      ctx.fillStyle=col;ctx.beginPath();ctx.arc(e.r*.7,0,2.5,0,TAU);ctx.fill();break;
    case 'carrier':ctx.rotate(face);ctx.beginPath();ctx.rect(-e.r,-e.r*.65,e.r*2,e.r*1.3);ctx.fill();ctx.stroke();for(let i=-1;i<=1;i++){ctx.beginPath();ctx.moveTo(i*7,-e.r*.65);ctx.lineTo(i*7,e.r*.65);ctx.stroke();}
      ctx.fillStyle=col;ctx.fillRect(e.r-4,-3,6,6);break;
    case 'jammerS':{ctx.beginPath();ctx.arc(0,0,e.r*.7,0,TAU);ctx.fill();ctx.stroke();for(let i=0;i<6;i++){const a=i/6*TAU+e.t;ctx.beginPath();ctx.moveTo(Math.cos(a)*e.r*.7,Math.sin(a)*e.r*.7);ctx.lineTo(Math.cos(a)*e.r*1.3,Math.sin(a)*e.r*1.3);ctx.stroke();}
      if(!icon){const k=(e.t*.8)%1;ctx.globalAlpha=alpha*(1-k)*.6;ctx.beginPath();ctx.arc(0,0,e.r+k*60,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}break;}
    case 'cutter':ctx.rotate(e.t*(e.cutting?18:6));for(let i=0;i<2;i++){ctx.save();ctx.rotate(i*Math.PI/2);ctx.beginPath();ctx.moveTo(-e.r*1.2,-2);ctx.lineTo(e.r*1.2,-2);ctx.lineTo(e.r*1.2,2);ctx.lineTo(-e.r*1.2,2);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
      ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,3,0,TAU);ctx.fill();break;
    case 'tug':ctx.rotate(face);ctx.fillRect(-e.r*.8,-e.r*.8,e.r*1.6,e.r*1.6);ctx.strokeRect(-e.r*.8,-e.r*.8,e.r*1.6,e.r*1.6);ctx.beginPath();ctx.arc(-e.r*1.1,0,5,-Math.PI/2,Math.PI/2,true);ctx.stroke();break;
    case 'mortar':ctx.beginPath();ctx.moveTo(-e.r,e.r*.6);ctx.lineTo(e.r,e.r*.6);ctx.lineTo(e.r*.6,-e.r*.4);ctx.lineTo(-e.r*.6,-e.r*.4);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.save();ctx.rotate(-Math.PI/2+.3*Math.sin(e.t));ctx.fillStyle=col;ctx.fillRect(0,-3,e.r*1.1,6);ctx.restore();break;
    case 'shell':{const h=icon?0:e.h||0;ctx.fillStyle='rgba(0,0,0,.4)';ctx.beginPath();ctx.ellipse(0,0,7,4,0,0,TAU);ctx.fill();ctx.translate(0,-h);glow(0,0,14,'#ff8f5a',.9);ctx.fillStyle='#ffd0b0';ctx.beginPath();ctx.arc(0,0,5,0,TAU);ctx.fill();break;}
    case 'phantom':ctx.rotate(face);ctx.beginPath();ctx.moveTo(e.r,0);ctx.lineTo(-e.r,-e.r*.8);ctx.quadraticCurveTo(-e.r*.3,0,-e.r,e.r*.8);ctx.closePath();ctx.fill();ctx.stroke();break;
    case 'shade':{ctx.rotate(face);if(e.reveal>0&&!icon)glow(0,0,26,'#ffffff',.6);poly(4,e.r,0);ctx.fillStyle='#05040c';ctx.fill();ctx.stroke();ctx.fillStyle=e.reveal>0?'#ffffff':col;ctx.fillRect(2,-1.5,5,3);break;}
    case 'mirror':ctx.rotate(e.face);poly(6,e.r,Math.PI/6);ctx.fill();ctx.stroke();ctx.strokeStyle=e.shieldFlash>0?'#ffffff':'#c7d6ff';ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,0,e.r+6,-1,1);ctx.stroke();
      ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,e.r+10,-1,1);ctx.stroke();break;
    case 'hive':{poly(8,e.r,Math.PI/8);ctx.fill();ctx.stroke();ctx.fillStyle=col;for(let i=0;i<6;i++){const a=i/6*TAU+e.t*.3;ctx.globalAlpha=alpha*(.4+.6*Math.abs(Math.sin(e.t*2+i)));ctx.beginPath();ctx.arc(Math.cos(a)*e.r*.5,Math.sin(a)*e.r*.5,3.5,0,TAU);ctx.fill();}ctx.globalAlpha=alpha;break;}
    case 'shocker':{ctx.beginPath();ctx.arc(0,0,e.r,0,TAU);ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(-4,-7);ctx.lineTo(2,-1);ctx.lineTo(-2,1);ctx.lineTo(4,7);ctx.stroke();if(e.st==='charge'&&!icon)glow(0,0,24,'#6bf0ff',.9);break;}
    case 'vortex':{ctx.rotate(-e.t*3);for(let i=0;i<3;i++){ctx.save();ctx.rotate(i/3*TAU);ctx.beginPath();ctx.arc(e.r*.4,0,e.r*.6,Math.PI,TAU);ctx.stroke();ctx.restore();}ctx.fillStyle=col;ctx.beginPath();ctx.arc(0,0,4,0,TAU);ctx.fill();break;}
    case 'twin':ctx.rotate(e.t*2);ctx.beginPath();ctx.arc(0,0,e.r,Math.PI/2,Math.PI*1.5);ctx.closePath();ctx.fill();ctx.stroke();ctx.beginPath();ctx.arc(3,0,e.r*.7,-Math.PI/2,Math.PI/2);ctx.stroke();
      if(e.down>0&&!icon){ctx.rotate(-e.t*2);ctx.strokeStyle='#ffffff';ctx.beginPath();ctx.arc(0,0,e.r+6,-Math.PI/2,-Math.PI/2+TAU*(1-e.down/3));ctx.stroke();}break;
    case 'thief':ctx.rotate(face);ctx.beginPath();ctx.moveTo(e.r+3,0);ctx.lineTo(-e.r,-e.r*.6);ctx.lineTo(-e.r*.5,0);ctx.lineTo(-e.r,e.r*.6);ctx.closePath();ctx.fill();ctx.stroke();
      if(e.loot){ctx.fillStyle='#ffb84d';ctx.fillRect(-e.r-6,-3,6,6);}break;
    case 'hunter':ctx.rotate(face);ctx.beginPath();ctx.moveTo(e.r+6,0);ctx.lineTo(-e.r,-e.r);ctx.lineTo(-e.r*.2,0);ctx.lineTo(-e.r,e.r);ctx.closePath();ctx.fill();ctx.stroke();ctx.beginPath();ctx.moveTo(e.r+6,0);ctx.lineTo(-e.r*.2,0);ctx.stroke();
      ctx.fillStyle=col;ctx.beginPath();ctx.arc(e.r*.2,0,2.5,0,TAU);ctx.fill();break;
    case 'commander':ctx.rotate(face);ctx.beginPath();ctx.moveTo(e.r,0);ctx.lineTo(-e.r*.6,-e.r);ctx.lineTo(-e.r*.2,0);ctx.lineTo(-e.r*.6,e.r);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.fillStyle=col;for(let i=-1;i<=1;i++){ctx.beginPath();ctx.arc(-e.r*.5,i*6,2,0,TAU);ctx.fill();}break;
    case 'cruiser':{ctx.rotate(icon?0:e.ang);ctx.beginPath();ctx.moveTo(e.r*1.8,0);ctx.lineTo(e.r*.4,-e.r);ctx.lineTo(-e.r*1.7,-e.r);ctx.lineTo(-e.r*1.7,e.r);ctx.lineTo(e.r*.4,e.r);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.beginPath();ctx.arc(0,0,e.r*.45,0,TAU);ctx.fillStyle=col;ctx.globalAlpha=alpha*.6;ctx.fill();ctx.globalAlpha=alpha;
      if(icon){ctx.strokeStyle='#ff9a7a';ctx.strokeRect(-e.r*1.9,-e.r*.9,8,8);ctx.strokeRect(-e.r*1.9,e.r*.5,8,8);}break;}
    case 'cpart':{const h=e.host;ctx.rotate(h?h.ang:0);if(e.role==='gun'){ctx.fillRect(-e.r,-e.r*.7,e.r*2,e.r*1.4);ctx.strokeRect(-e.r,-e.r*.7,e.r*2,e.r*1.4);ctx.fillStyle=col;ctx.fillRect(e.r*.2,-2.5,e.r*1.4,5);}
      else{ctx.beginPath();ctx.arc(0,0,e.r,0,TAU);ctx.fill();ctx.stroke();if(!icon)glow(-e.r,0,12,'#ffb070',.8);}break;}
    case 'antenna':{ctx.beginPath();ctx.moveTo(0,e.r);ctx.lineTo(0,-e.r*1.6);ctx.stroke();ctx.beginPath();ctx.moveTo(-e.r*.8,e.r);ctx.lineTo(e.r*.8,e.r);ctx.stroke();
      for(let i=0;i<3;i++){const k=((e.t*1.5+i/3)%1);ctx.globalAlpha=alpha*(1-k);ctx.beginPath();ctx.arc(0,-e.r*1.6,3+k*14,0,TAU);ctx.stroke();}ctx.globalAlpha=alpha;break;}
    case 'decoy':ctx.restore();ctx.save();ctx.globalAlpha=alpha*(.6+.4*(Math.sin(t*14)>0?1:.5));drawMiniBeacon(e.x,e.y,'#8fe9ff',t);ctx.translate(e.x,e.y);break;
    case 'crate':ctx.rotate(e.t*.5);ctx.fillRect(-e.r*.8,-e.r*.8,e.r*1.6,e.r*1.6);ctx.strokeRect(-e.r*.8,-e.r*.8,e.r*1.6,e.r*1.6);ctx.beginPath();ctx.moveTo(-e.r*.8,-e.r*.8);ctx.lineTo(e.r*.8,e.r*.8);ctx.moveTo(e.r*.8,-e.r*.8);ctx.lineTo(-e.r*.8,e.r*.8);ctx.stroke();break;
    case 'frost':{ctx.rotate(e.t*.6);for(let i=0;i<3;i++){const a=i*Math.PI/3;ctx.beginPath();ctx.moveTo(Math.cos(a)*e.r,Math.sin(a)*e.r);ctx.lineTo(-Math.cos(a)*e.r,-Math.sin(a)*e.r);ctx.stroke();}
      poly(6,e.r*.55);ctx.fill();ctx.stroke();ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(0,0,2.2,0,TAU);ctx.fill();break;}
    case 'archivist':{const a=icon?0:Math.atan2(P.y-e.y,P.x-e.x);ctx.rotate(a);ctx.fillRect(-e.r*.9,-e.r*.6,e.r*1.6,e.r*1.2);ctx.strokeRect(-e.r*.9,-e.r*.6,e.r*1.6,e.r*1.2);
      ctx.strokeStyle='rgba(143,216,255,.6)';ctx.lineWidth=1;ctx.beginPath();for(let i=-2;i<=2;i++){ctx.moveTo(-e.r*.7,i*e.r*.25);ctx.lineTo(e.r*.5,i*e.r*.25);}ctx.stroke();ctx.strokeStyle=col;ctx.lineWidth=2;
      ctx.fillStyle=e.st==='rec'?'#ffffff':col;ctx.beginPath();ctx.arc(e.r*.9,0,3,0,TAU);ctx.fill();break;}
    case 'icecopy':{ctx.rotate(e.face||0);ctx.globalAlpha=alpha*.85;drawShip(SKINS[e.skin]?e.skin:curSkin(),t,160,{});ctx.globalAlpha=alpha*.7;ctx.strokeStyle='#dff6ff';ctx.lineWidth=1.5;poly(6,20,t*.8);ctx.stroke();break;}
    case 'rustcopy':{ctx.rotate(e.face||face);ctx.globalAlpha=alpha*.9;drawShip(SKINS[e.skin]?e.skin:'base',t,120,{});ctx.globalAlpha=alpha*.5;ctx.fillStyle='#8a3a12';ctx.beginPath();ctx.arc(0,0,15,0,TAU);ctx.fill();ctx.globalAlpha=alpha;ctx.strokeStyle='#c96a2a';ctx.lineWidth=1.5;poly(4,19,t*.5);ctx.stroke();break;}
    case 'inventor':{const b=!icon&&G.sb===e?e:null,open=b&&b.open>0&&b.st==='fight';ctx.rotate(Math.sin(e.t*.3)*.08);ctx.fillStyle='#0b1628';ctx.strokeStyle=open?'#ffffff':col;ctx.lineWidth=2.5;
      const k=icon?.42:1;ctx.scale(k,k);ctx.beginPath();ctx.moveTo(-65,-14);ctx.lineTo(-50,-24);ctx.lineTo(50,-24);ctx.lineTo(65,-14);ctx.lineTo(65,14);ctx.lineTo(50,24);ctx.lineTo(-50,24);ctx.lineTo(-65,14);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle='rgba(159,216,255,.55)';ctx.lineWidth=1;for(let i=-4;i<=4;i++){ctx.beginPath();ctx.moveTo(i*13,-20);ctx.lineTo(i*13,20);ctx.stroke();}
      for(let i=-4;i<4;i++){ctx.fillStyle=((i+4+(e.t*2|0))%3===0)?'#bfe8ff':'#1c3a55';ctx.fillRect(i*13+3,-8,7,16);}
      glow(0,0,36,open?'#ffffff':'#9fd8ff',open?1:.5);ctx.fillStyle=open||e.flash>0?'#ffffff':'#dff6ff';ctx.beginPath();ctx.arc(0,0,12,0,TAU);ctx.fill();
      if(b&&(b.inv0>0||b.st==='enter'||b.st==='final')){ctx.strokeStyle=e.domeFlash>0?'#ffffff':'#9fd8ff';ctx.globalAlpha=alpha*.35;ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,e.r+12,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}break;}
    case 'invcell':{const c=e.cell,b=G.sb;ctx.rotate(icon?0:Math.atan2(e.y-(b?b.y:e.y-1),e.x-(b?b.x:e.x-1)));ctx.fillStyle='#0b1a28';ctx.strokeStyle=c&&c.locked?'#5a6b80':col;ctx.lineWidth=2;ctx.fillRect(-11,-9,22,18);ctx.strokeRect(-11,-9,22,18);
      ctx.strokeStyle='rgba(191,232,255,.6)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(-6,-9);ctx.lineTo(-6,9);ctx.moveTo(4,-9);ctx.lineTo(4,9);ctx.stroke();ctx.fillStyle=c&&c.label?'#ffffff':'#8fd8ff';ctx.fillRect(-3,-2,6,4);break;}
    case 'invcore':{const mem=e.core==='memory',cc=mem?'#ffd36b':'#bfe8ff';glow(0,0,44,cc,.6);ctx.fillStyle='#0b1220';ctx.strokeStyle=e.flash>0?'#ffffff':cc;ctx.lineWidth=2.5;ctx.beginPath();ctx.arc(0,0,e.r,0,TAU);ctx.fill();ctx.stroke();
      ctx.strokeStyle=cc;ctx.lineWidth=1.2;if(mem){for(let i=-2;i<=2;i++){ctx.beginPath();ctx.moveTo(-10,i*5);ctx.lineTo(10,i*5);ctx.stroke();}}else{for(let i=0;i<3;i++){const a=i*Math.PI/3+e.t*.5;ctx.beginPath();ctx.moveTo(Math.cos(a)*12,Math.sin(a)*12);ctx.lineTo(-Math.cos(a)*12,-Math.sin(a)*12);ctx.stroke();}}break;}
    case 'obheart':{const b=!icon&&G.sb===e?e:null,open=b&&obHeartOpen(b);ctx.rotate(e.t*.4);const k=icon?.7:1;ctx.scale(k,k);ctx.fillStyle='#1a0e06';ctx.strokeStyle=open||e.flash>0?'#ffffff':col;ctx.lineWidth=3;poly(8,e.r,0);ctx.fill();ctx.stroke();
      ctx.strokeStyle='#c96a2a';ctx.lineWidth=1.5;for(let i=0;i<4;i++){const a=i*Math.PI/4;ctx.beginPath();ctx.moveTo(Math.cos(a)*e.r*.45,Math.sin(a)*e.r*.45);ctx.lineTo(-Math.cos(a)*e.r*.45,-Math.sin(a)*e.r*.45);ctx.stroke();}
      glow(0,0,e.r*1.2,open?'#ffffff':'#ffb060',open?1:.5);ctx.fillStyle=open?'#ffffff':'#ffd0a0';ctx.beginPath();ctx.arc(0,0,e.r*.3,0,TAU);ctx.fill();
      if(b&&!open&&b.st!=='dying'){ctx.strokeStyle=e.domeFlash>0?'#ffffff':'#c96a2a';ctx.globalAlpha=alpha*.4;ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,e.r+12,0,TAU);ctx.stroke();ctx.globalAlpha=alpha;}break;}
    case 'obseg':{if(icon){ctx.strokeStyle=col;ctx.lineWidth=8;ctx.beginPath();ctx.arc(0,30,44,-2.2,-.95);ctx.stroke();}break;}
    case 'corroder':{ctx.rotate(face);ctx.fillRect(-e.r,-e.r*.7,e.r*1.7,e.r*1.4);ctx.strokeRect(-e.r,-e.r*.7,e.r*1.7,e.r*1.4);ctx.fillStyle='#5a2e14';for(const [x,y] of [[-e.r*.6,-e.r*.3],[0,e.r*.2],[e.r*.3,-e.r*.4]]){ctx.beginPath();ctx.arc(x,y,3,0,TAU);ctx.fill();}
      ctx.fillStyle='#2a1a10';ctx.fillRect(e.r*.7,-e.r*.9,e.r*.4,e.r*1.8);ctx.strokeRect(e.r*.7,-e.r*.9,e.r*.4,e.r*1.8);break;}
    case 'repairer':{ctx.rotate(face);ctx.fillRect(-e.r*.7,-e.r*.6,e.r*1.4,e.r*1.2);ctx.strokeRect(-e.r*.7,-e.r*.6,e.r*1.4,e.r*1.2);ctx.lineWidth=1.5;ctx.beginPath();for(const s of [-1,1]){ctx.moveTo(e.r*.5,s*e.r*.4);ctx.lineTo(e.r*1.2,s*e.r*.9);ctx.lineTo(e.r*1.6,s*e.r*.5);}ctx.stroke();
      ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(0,0,2.5,0,TAU);ctx.fill();if(!icon){ctx.rotate(-face);ctx.fillStyle='#ffb060';ctx.font='700 10px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText('🔧',0,-e.r-6);}break;}
    case 'hull':{ctx.rotate(e.seed);ctx.globalAlpha=alpha*(.5+.25*Math.sin(t*4));ctx.strokeStyle='#8b96a6';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(-e.r,-e.r*.5);ctx.lineTo(e.r*.8,-e.r*.3);ctx.lineTo(e.r*.5,e.r*.6);ctx.lineTo(-e.r*.6,e.r*.5);ctx.closePath();ctx.stroke();ctx.beginPath();ctx.moveTo(-e.r*.6,0);ctx.lineTo(e.r*.6,0);ctx.stroke();break;}
    case 'jam':drawJam(e,t,icon);break;
    default:drawE74(e,t,icon,col,face,alpha,P);
  }
  ctx.restore();ctx.globalAlpha=1;
  if(icon)return;
  if(e.shieldK<1){ctx.strokeStyle='#9c8cff';ctx.globalAlpha=.6;ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(e.x,e.y,e.r+5,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
  if(e.buff>1){ctx.strokeStyle='#ffa63d';ctx.globalAlpha=.5;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(e.x-e.r,e.y+e.r+3);ctx.lineTo(e.x+e.r,e.y+e.r+3);ctx.stroke();ctx.globalAlpha=1;}
  if(e.affix){e.affix.forEach((a,i)=>{ctx.strokeStyle=AFX[a].col;ctx.globalAlpha=.75;ctx.lineWidth=1.5;ctx.setLineDash([3,4]);ctx.lineDashOffset=t*10*(i?-1:1);ctx.beginPath();ctx.arc(e.x,e.y,e.r+6+i*4,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;});
    if(e.armor>0){ctx.fillStyle='#cfd8e6';for(let i=0;i<e.armor;i++)ctx.fillRect(e.x-6+i*5,e.y-e.r-6,3,3);}ctx.globalAlpha=1;}
  if(G.bc&&e.group&&!(e.type==='leech'&&e.att)&&e.spawnT<=0&&!e.ghost&&e.type!=='cpart'){const x=e.x,y=e.y-e.r-11;ctx.globalAlpha=.85;
    if(e.group==='siege'){ctx.fillStyle='#ffb84d';ctx.beginPath();ctx.moveTo(x,y-3.5);ctx.lineTo(x+3.5,y);ctx.lineTo(x,y+3.5);ctx.lineTo(x-3.5,y);ctx.closePath();ctx.fill();}
    else if(e.group==='hunt'){ctx.fillStyle='#ff4f6e';ctx.beginPath();ctx.moveTo(x,y+3.5);ctx.lineTo(x+4,y-3);ctx.lineTo(x-4,y-3);ctx.closePath();ctx.fill();}
    else{ctx.strokeStyle='#4dd0ff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(x,y,3,0,TAU);ctx.stroke();}
    ctx.globalAlpha=1;}
  if(e.type==='pylon'&&G.boss&&e.spawnT<=0){ctx.strokeStyle='#b48cff';ctx.globalAlpha=.25;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(G.boss.x,G.boss.y);ctx.stroke();ctx.globalAlpha=1;}
  if(e.hp<e.maxHp&&e.hp>0&&e.type!=='boss'&&e.type!=='jam'&&e.type!=='mine'&&!e.sbk&&e.maxHp>=30&&!e.noBar90&&!e.hid90){const w=Math.max(20,e.r*2);ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(e.x-w/2,e.y+e.r+6,w,3);ctx.fillStyle=d.col;ctx.fillRect(e.x-w/2,e.y+e.r+6,w*e.hp/e.maxHp,3);}
}
function drawBoss(b,t){
  const over=b.over>0,R=b.r;
  ctx.save();ctx.rotate(b.rot);ctx.lineWidth=5;
  for(let i=0;i<10;i++){const a=i/10*TAU;ctx.strokeStyle=over?(Math.sin(t*20+i)>0?'#ffffff':'#7c5cff'):'#7c5cff';ctx.beginPath();ctx.arc(0,0,R+16,a,a+TAU/10-.12);ctx.stroke();}
  ctx.restore();
  ctx.save();ctx.rotate(-b.rot*1.6);ctx.strokeStyle='#b48cff';ctx.lineWidth=2;poly(6,R,0);ctx.fillStyle='#0d0a1e';ctx.fill();ctx.stroke();poly(6,R*.72,Math.PI/6);ctx.stroke();ctx.restore();
  const cr=R*.38*(over?1+.12*Math.sin(t*25):1);
  glow(0,0,cr*3,over?'#ffffff':'#b48cff',over?1:.6);
  ctx.fillStyle=over||b.flash>0?'#ffffff':'#e0d2ff';ctx.beginPath();ctx.arc(0,0,cr,0,TAU);ctx.fill();
  if(over){ctx.strokeStyle='#8fe9ff';ctx.lineWidth=1.5;for(let i=0;i<5;i++){const a=rnd(0,TAU);ctx.beginPath();ctx.moveTo(Math.cos(a)*cr,Math.sin(a)*cr);ctx.lineTo(Math.cos(a+rnd(-.3,.3))*(R+10),Math.sin(a+rnd(-.3,.3))*(R+10));ctx.stroke();}}
  if(G.enemies.some(o=>o.type==='pylon'&&o.alive)){ctx.strokeStyle=b.domeFlash>0?'#ffffff':'#b48cff';ctx.globalAlpha=.35+.15*Math.sin(t*3);ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,R+30,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
}
function drawJam(j,t,icon){
  const R=j.r,open=!icon&&G.jam===j&&j.st==='fight'&&!jamShielded();
  ctx.save();ctx.rotate(j.rot||0);ctx.strokeStyle='#4dd0ff';ctx.lineWidth=2;
  for(let i=0;i<8;i++){const a=i/8*TAU;ctx.beginPath();ctx.moveTo(Math.cos(a)*R*.8,Math.sin(a)*R*.8);ctx.lineTo(Math.cos(a)*(R+18),Math.sin(a)*(R+18));ctx.stroke();ctx.beginPath();ctx.arc(Math.cos(a)*(R+18),Math.sin(a)*(R+18),3,0,TAU);ctx.stroke();}
  ctx.restore();
  ctx.fillStyle='#06121c';ctx.strokeStyle='#4dd0ff';ctx.lineWidth=2.5;ctx.beginPath();ctx.arc(0,0,R*.85,0,TAU);ctx.fill();ctx.stroke();
  ctx.save();ctx.rotate(-(j.rot||0)*2);ctx.setLineDash([6,6]);ctx.beginPath();ctx.arc(0,0,R*.6,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.restore();
  glow(0,0,R*.9,open?'#ffffff':'#4dd0ff',open?1:.5);
  ctx.fillStyle=open||j.flash>0?'#ffffff':'#b9f0ff';ctx.beginPath();ctx.arc(0,0,R*.28,0,TAU);ctx.fill();
  if(!icon&&G.jam===j&&j.st!=='dying'&&jamShielded()){ctx.strokeStyle=j.domeFlash>0?'#ffffff':'#4dd0ff';ctx.globalAlpha=.3+.15*Math.sin(t*3);ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,R+28,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
}

// ---------- HUD ----------
const hudEls={hud0:document.getElementById('hud')};['hpT','hpB','enT','enB','enBar','misT','sigT','sigB','sigBar','bossBar','bossB','score','dashC','pulseC','lvC','xpB','tDash','tPulse','bcBox','bcB','bcBar','biT','biB','biBar','jamBar','jamB','cargoC','wSec','wLom','wSub','eTime','eB','eStep','eRec','chgC','comboC','tCharge','aimC'].forEach(id=>hudEls[id]=document.getElementById(id));
const hudCache={};
function setT(id,v){if(touchMode)v=kh(v);if(hudCache[id]!==v){hudCache[id]=v;hudEls[id].textContent=v;}}
function setS(id,v){const k=id+'s';if(hudCache[k]!==v){hudCache[k]=v;hudEls[id].style.transform=`scaleX(${v})`;}}
function setC(id,c,on){const k=id+c;if(hudCache[k]!==on){hudCache[k]=on;hudEls[id].classList.toggle(c,on);}}
function setF(id,f){const k=id+'f',v=Math.round(clamp(f,0,1)*50)*2;if(hudCache[k]!==v){hudCache[k]=v;hudEls[id].style.setProperty('--f',v+'%');}}
function mName(M){return M?String(M.name).replace(/^Комната босса · /,''):'';}
function hudClean(v){return String(v==null?'':v).replace(/\s·\sФАЗА\s\d+/g,'').replace(/ФАЗА\s\d+\s·\s/g,'').replace(/(\d+)[,.](\d)\s?[сС](?![А-ЯЁа-яё])/g,(m,a,b)=>Math.ceil(+(a+'.'+b))+' С');}
function setH(id,h){const k=id+'h';if(hudCache[k]!==h){hudCache[k]=h;hudEls[id].hidden=h;}}
function updateHUD(){
  const p=G.player,st=G.st;if(!p)return;
  setT('hpT',Math.ceil(p.hp)+'/'+st.maxHp+(G.wear>0?' · ИЗНОС':''));setS('hpB',(p.hp/st.maxHp).toFixed(3));
  setS('enB',(p.en/100).toFixed(3));setC('enBar','full',p.en>=100);
  setT('misT',mName(MISSIONS[G.m-1]).toUpperCase());
  const bc=G.bc;
  setH('bcBox',!bc);
  if(G.lockGun>0||G.lockShield>0||G.lockDash>0)hintOnce('lockhud',(G.lockShield>0?'ЩИТ ':'')+(G.lockDash>0?'РЫВОК ':'')+(G.lockGun>0?'ОРУДИЕ ':'')+'НА ХРАНЕНИИ','#8fd8ff');
  if(bc){
    setH('sigBar',true);setH('bossBar',true);
    let s;if(bc.done)s=MISSIONS[G.m-1].transmit?'СИГНАЛ ПЕРЕДАН':'МАЯК ЗАРЯЖЕН';
    else if(bc.cool>0)s='ПРОДУВКА';
    else if(bc.transStarted&&!bc.transDone)s=(bc.charge>=80?'ПЕРЕДАЧА · ':'ПЕРЕДАЧА НА ПАУЗЕ · ')+Math.ceil(bc.trans)+' С';
    else if(bc.transDone)s='ПЕРЕДАЧА ЗАВЕРШЕНА';
    else s='ЗАРЯД'+(bc.drain>0?' ▼':bc.inRing?' ▲':'');
    setT('sigT',s);setS('bcB',(bc.charge/100).toFixed(3));setC('bcBar','cool',bc.cool>0);
    setT('biT',bc.barrier>0?'ЩИТ':'');setS('biB',(bc.hp/bc.maxHp).toFixed(3));setC('biBar','hit',bc.hitF>0);
    const j=G.jam&&G.jam.st!=='enter'?G.jam:null;setH('jamBar',!j);if(j)setS('jamB',(j.hp/j.maxHp).toFixed(4));
    setH('cargoC',false);setT('cargoC','ГРУЗ '+p.cargo+'/'+st.cargo);setC('cargoC','ok',p.cargo>0);
  }else{
    setH('cargoC',true);
    const SB=G.sb&&G.sb.st!=='enter'?G.sb:null,boss=!!SB||(G.boss&&G.boss.st!=='enter');
    setH('bossBar',!boss);setH('sigBar',!!boss);
    if(SB){setT('sigT',hudClean(sbHud(SB)));setS('bossB',(SB.hp/SB.maxHp).toFixed(4));}
    else if(boss){setT('sigT',G.boss.over>0?'ПЕРЕГРУЗКА':'СТРАЖ');setS('bossB',(G.boss.hp/G.boss.maxHp).toFixed(4));}
    else{const pr=G.bossSpawned?1:sigProgress()*((MISSIONS[G.m-1].boss||MISSIONS[G.m-1].sboss)?0.85:1);setT('sigT','СИГНАЛ');setS('sigB',pr.toFixed(3));}
  }
  hudEls.score.firstChild.nodeValue=fmt(G.score);
  const blocked=dashBlocked();const dr=p.dashCd<=0&&!blocked;
  setT('dashC',blocked?'РЫВОК · ПОМЕХИ':'РЫВОК');setF('dashC',p.dashCd>0?1-p.dashCd/(p.dashCdMax||st.dashCd||1):0);setC('dashC','ok',dr);setC('dashC','bad',blocked);setC('tDash','cd',!dr);
  const pr=p.en>=100;setT('pulseC',pr?'ИМПУЛЬС [E]':'ИМПУЛЬС');setF('pulseC',pr?0:p.en/100);setC('pulseC','ok',pr);setC('tPulse','cd',!pr);
  setT('lvC','ЩИТ');setH('lvC',!st.shieldCd);setC('lvC','ok',!!(st.shieldCd&&p.shieldUp));setS('xpB',(G.xp/G.need).toFixed(3));
  chargeChip();
}

// ---------- Экраны ----------
const SCREENS=['sMenu','sCodex','sIntro','sLevel','sDone','sPause','sOver','sMap','sShop','sSave','sDev','sHangar','sCycle','sReport','sSet','sArsenal'];
const TAPGUARD={sLevel:350,sDone:500,sOver:500};
function show(id){if(G.scrId!==id){G.scrId=id;G.scrAt=performance.now();}if(G.state!=='menu')histArm();if(id&&isMob()){$('#banner').classList.remove('show');}SCREENS.forEach(s=>$('#'+s).hidden=s!==id);if(G.state!=='play'&&G.state!=='world'&&typeof radioClear==='function')radioClear();$('#hud').hidden=!['play','levelup','pause','world'].includes(G.state)||isMob()&&(G.state==='levelup'||G.state==='pause');
  $('#hud').classList.toggle('world',!!G.world);$('#hud').classList.toggle('endless',G.mode==='endless');
  $('#scoreL').textContent=G.mode==='endless'?'УНИЧТОЖЕНО':'ОЧКИ';
  $('#devBar').hidden=!(G.devRun&&['play','levelup','pause','intro'].includes(G.state));$('#devBtn').hidden=!(G.devRun&&G.state==='play');
  if(G.state!=='play')$('#devPanel').hidden=true;
  $('#touch').hidden=!(touchMode&&(G.state==='play'||G.state==='world'));
  if(G.state!=='world'){$('#wcard').hidden=true;G.cardKey=null;}updateCursor();/*DEVW*/if(window.DEVW)DEVW.ui();
  if(G.state!=='world')joyUnlock();if(!$('#touch').hidden&&isMob())layoutTouch();ctxBtnSync();}
document.addEventListener('click',e=>{if(!touchMode)return;const sc=G.scrId,g=TAPGUARD[sc];if(!g||performance.now()-G.scrAt>=g)return;const el=e.target.closest&&e.target.closest('section');if(el&&el.id===sc){e.stopPropagation();e.preventDefault();}},true);
function renderSettings(){
  document.querySelectorAll('[data-settings]').forEach(box=>{
    if(box.closest('#sMenu,#sPause')){if(box.innerHTML)box.innerHTML='';return;}
    box.innerHTML=`
      <button class="tog ${SET.amb?'on':''}" data-k="amb"><span>МУЗЫКА${MUS.lastName&&SET.amb?' · «'+MUS.lastName+'»':''}</span><span>${SET.amb?'ВКЛ':'ВЫКЛ'}</span></button>
      <label class="vol"><span>ГРОМКОСТЬ МУЗЫКИ</span><input type="range" min="0" max="1" step="0.05" value="${SET.ambVol}" data-vol id="vol-${box.closest('section').id}"></label>
      <button class="tog ${SET.sfx?'on':''}" data-k="sfx"><span>ЗВУК</span><span>${SET.sfx?'ВКЛ':'ВЫКЛ'}</span></button>
      <button class="tog ${SET.fx?'on':''}" data-k="fx"><span>ЭФФЕКТЫ · частицы и тряска</span><span>${SET.fx?'ВКЛ':'ВЫКЛ'}</span></button>
      <button class="tog ${SET.manual?'on':''}" data-k="manual"><span>${touchMode?'ПРИЦЕЛ · НА ТЕЛЕФОНЕ ВСЕГДА АВТО':'ПРИЦЕЛ МЫШЬЮ · T'}</span><span>${SET.manual?'РУЧНОЙ':'АВТО'}</span></button>
      <button class="tog ${SET.radio?'on':''}" data-k="radio"><span>ПЕРЕХВАТЫ · радиоэфир</span><span>${SET.radio?'ВКЛ':'ВЫКЛ'}</span></button>${FS.rowPC()}`+(box.closest('#sMenu')?resetBlock():'');
  });
  renderSetScreen();
}
// ---- экран настроек (0.6.0) ----
const SEGS={fsMode:[['ПОЛНЫЙ ЭКРАН',[['off','ВЫКЛ'],['auto','ПРИ ПОЛЁТЕ'],['always','ВСЕГДА']]]],orient:[['ОРИЕНТАЦИЯ',[['auto','АВТО'],['land','АЛЬБОМ'],['port','КНИЖНАЯ']]]],zoom:[['МАСШТАБ',[[.85,'КРУПНЕЕ'],[1,'СТАНДАРТ'],[1.15,'ДАЛЬШЕ']]]],textScale:[['ТЕКСТ',[[1,'ОБЫЧНЫЙ'],[1.15,'КРУПНЫЙ'],[1.3,'ОЧЕНЬ КРУПНЫЙ']]]],
  quality:[['КАЧЕСТВО',[['auto','АВТО'],[0,'ЭКОНОМ'],[1,'СТАНДАРТ'],[2,'ВЫСОКОЕ']]]],fps:[['КАДРЫ',ARCH.fc27?[[30,'30'],[60,'60'],[0,'БЕЗ ОГРАНИЧЕНИЯ']]:[[60,'60'],[30,'30']]]],shake:[['ТРЯСКА',[[0,'НЕТ'],[.5,'СЛАБАЯ'],[1,'ПОЛНАЯ']]]],
  btnSize:[['РАЗМЕР КНОПОК',[[.85,'МЕНЬШЕ'],[1,'СТАНДАРТ'],[1.2,'КРУПНЕЕ']]]],btnAlpha:[['ПРОЗРАЧНОСТЬ КНОПОК',[[.45,'СИЛЬНАЯ'],[.7,'СРЕДНЯЯ'],[1,'НЕТ']]]],
  hand:[['РУКА',[['r','ПРАВАЯ'],['l','ЛЕВАЯ']]]],stick:[['СТИК',[['float','ПЛАВАЮЩИЙ'],['fixed','ЗАКРЕПЛЁННЫЙ']]]]};
function segHTML(k){const [lab,opts]=SEGS[k][0];return `<div class="setrow"><div class="eyebrow">${lab}</div><div class="seg" data-seg="${k}">${opts.map(([v,n])=>`<button data-v="${v}" class="${String(k==='fps'&&ARCH.fc27?fpsCur27():SET[k])===String(v)?'on':''}">${n}</button>`).join('')}</div></div>`;}
function togHTML(k,lab,on,off){return `<button class="tog ${SET[k]?'on':''}" data-k="${k}"><span>${lab}</span><span>${SET[k]?(on||'ВКЛ'):(off||'ВЫКЛ')}</span></button>`;}
function renderSetScreen(){const B=$('#setBody');if(!B||G.state!=='settings')return;const ios=/iP(hone|ad|od)/.test(navigator.userAgent)||navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1,tch=touchMode||isMob();
  const fxl=!SET.fx?'off':SET.lessFx?'less':'full',fxSeg=`<div class="setrow"><div class="eyebrow">ЭФФЕКТЫ</div><div class="seg">${[['full','ПОЛНЫЕ'],['less','МЕНЬШЕ'],['off','ВЫКЛ']].map(([v,n])=>`<button data-fxl="${v}" class="${fxl===v?'on':''}">${n}</button>`).join('')}</div></div>`;
  B.innerHTML=`<div class="setgrp"><div class="cx-h2">ЗВУК</div>${togHTML('amb','МУЗЫКА')}
      <label class="vol"><span>ГРОМКОСТЬ МУЗЫКИ</span><input type="range" min="0" max="1" step="0.05" value="${SET.ambVol}" data-vol id="vol-sSet"></label>${togHTML('sfx','ЗВУКИ')}
      ${ios?'<p class="note">Нет звука? Проверьте беззвучный режим.</p>':''}</div>
    <div class="setgrp"><div class="cx-h2">УПРАВЛЕНИЕ</div>${tch?`${segHTML('btnSize')}${segHTML('btnAlpha')}${segHTML('hand')}${segHTML('stick')}
      ${togHTML('dashSwipe','РЫВОК СВАЙПОМ')}${togHTML('oneHand','ОДНОЙ РУКОЙ')}${navigator.vibrate?togHTML('haptics','ВИБРАЦИЯ'):''}`:togHTML('manual','ПРИЦЕЛ МЫШЬЮ')}</div>
    <div class="setgrp"><div class="cx-h2">ЭКРАН</div>${segHTML('fsMode')}${FS.can()?'':`<p class="note" id="fsNote">${FS.noteText()}</p>`}${FS.hintKind()&&!FS.can()?'<div><button class="wbtn" data-fshint>КАК УБРАТЬ ПАНЕЛИ</button></div>':''}${FS.orientOK()?segHTML('orient'):''}
      ${segHTML('zoom')}${G.ff==='desk'?segHTML('uiSize'):''}${segHTML('textScale')}${segHTML('quality')}${segHTML('fps')}${segHTML('shake')}${fxSeg}${devUnlocked()?'<p class="fsdiag">'+FS.diag()+'</p>':''}</div>
    <div class="setgrp"><div class="cx-h2">ПРОЧЕЕ</div>${togHTML('radio','РАДИОЭФИР')}${togHTML('softInv','БЕЗ ПЕРЕВОРОТА УПРАВЛЕНИЯ')}${togHTML('noErase','БЕЗ СТИРАНИЯ ИНТЕРФЕЙСА')}${G.setFrom==='menu'?resetBlock():''}</div>`;}
document.addEventListener('click',e=>{const b=e.target.closest('[data-fxl]');if(!b)return;const v=b.dataset.fxl;SET.fx=v!=='off';SET.lessFx=v==='less';saveSet();applySettings();renderSettings();buzz('tap');});
function applySettings(){document.documentElement.style.setProperty('--fs',SET.textScale||1);ffUpdate();resize();layoutTouch();}
function openSettings(from){G.setFrom=from;G.setPrev=G.state;scr6('settings');renderSetScreen();show('sSet');}
function closeSettings(){if(G.state!=='settings')return;if(G.setFrom==='pause'){scr6('pause');renderSettings();show('sPause');}else{toMenu();}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-seg] [data-v]');if(!b)return;const k=b.closest('[data-seg]').dataset.seg,raw=b.dataset.v,opts=SET_OPT[k];if(!opts)return;if(k==='fps'&&ARCH.fc27){fpsPick27(raw);return;}/* ARCH·90a */
  const v=opts.find(o=>String(o)===raw);if(v===undefined)return;SET[k]=v;saveSet();applySettings();renderSetScreen();buzz('tap');});
