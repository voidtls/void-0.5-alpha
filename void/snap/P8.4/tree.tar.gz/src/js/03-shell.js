// ===== 0.6.2: полный экран — один модуль =====
const FS={caps:null,state:'off',lastErr:'',wanted:false,tried:false,src:'',chgAt:0,_t:0,
  probe(){const d=document,el=d.documentElement,ua=navigator.userAgent||'';const ipad=/iPad/.test(ua)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1),iphone=/iPhone|iPod/.test(ua)&&!ipad;
    let iframe=false;try{iframe=window.self!==window.top;}catch(e){iframe=true;}
    const webview=/Telegram|FBAN|FBAV|Instagram|VKClient|WhatsApp|Line\/|; wv\)/i.test(ua);let standalone=false;try{standalone=(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true;}catch(e){}
    const api=!!(el.requestFullscreen||el.webkitRequestFullscreen),policy=!!(d.fullscreenEnabled||d.webkitFullscreenEnabled);
    this.caps={api,prefixed:!el.requestFullscreen&&!!el.webkitRequestFullscreen,iframe,policy,iphone,ipad,ios:iphone||ipad,android:/Android/i.test(ua),webview,standalone,mac:/Mac/.test(navigator.platform||'')&&!ipad};
    if(api&&!policy&&!iphone&&!standalone){this.lastErr='policy';this.state='denied';this.immersive(true);}
    if(!iframe||standalone)this.immersive(true);return this.caps;},
  c(){return this.caps||this.probe();},
  can(){const c=this.c();return c.api&&c.policy&&!c.iphone&&!c.standalone&&this.lastErr!=='policy';},
  is(){return !!(document.fullscreenElement||document.webkitFullscreenElement);},
  enter(src){const c=this.c();if(this.is())return true;if(!this.can()){this.state='denied';this.sync();return false;}
    let act=true;try{if(navigator.userActivation&&!navigator.userActivation.isActive)act=false;}catch(e){}
    if(!act){this.lastErr='gesture';this.sync();return false;}
    const el=document.documentElement;this.state='pending';this.wanted=true;this.tried=true;this.src=src||'';if(this.lastErr==='gesture')this.lastErr='';
    let p=null;try{p=el.requestFullscreen?el.requestFullscreen({navigationUI:'hide'}):el.webkitRequestFullscreen();}catch(err){this.fail(err);return false;}
    this.curtain(true);clearTimeout(this._t);this._t=setTimeout(()=>{if(this.state==='pending')this.fail({name:'Timeout'});},1500);
    if(p&&p.then)p.then(()=>{},err=>this.fail(err));return true;},
  fail(err){clearTimeout(this._t);if(this.is()){this.onChange();return;}const n=(err&&err.name)||'';this.lastErr=(n==='TypeError'||n==='NotAllowedError'||n==='Timeout'||n==='SecurityError')?'policy':'other';
    this.state='denied';this.wanted=false;this.curtain(false);this.immersive(true);
    if(this.src==='auto'&&isMob()){if(!SET.fsHintShown){SET.fsHintShown=true;saveSet();toast('ПОЛНЫЙ ЭКРАН НЕДОСТУПЕН','Игра расширится на всё доступное место. Как убрать панели браузера — кнопка ⛶ в меню.');}}
    else if(this.src&&this.src!=='always')this.card(true);this.sync();},
  exit(){this.wanted=false;try{const p=document.exitFullscreen?document.exitFullscreen():document.webkitExitFullscreen&&document.webkitExitFullscreen();if(p&&p.catch)p.catch(()=>{});}catch(err){}},
  toggle(src){if(this.is())this.exit();else if(this.can())this.enter(src);else this.card(true);},
  immersive(on){document.documentElement.classList.toggle('fs-imm',!!on);},
  curtain(on){const el=$('#fsCurtain');if(!el)return;if(!SET.fx){el.classList.remove('show');return;}el.classList.toggle('show',!!on);},
  onChange(){clearTimeout(this._t);const on=this.is();this.chgAt=performance.now();this.state=on?'native':'off';
    if(on){this.lastErr='';this.immersive(true);if((G.state==='play'||G.state==='world')&&this.src==='key')G.resumeK=Math.max(G.resumeK||0,.5);
      if(this.c().android&&SET.orient!=='auto'&&screen.orientation&&screen.orientation.lock){try{screen.orientation.lock(SET.orient==='land'?'landscape':'portrait').catch(()=>{});}catch(e){}}}
    else{if(screen.orientation&&screen.orientation.unlock){try{screen.orientation.unlock();}catch(e){}}if(G.state==='play'||G.state==='world')pause();}
    requestAnimationFrame(()=>requestAnimationFrame(()=>{try{resize();if(typeof readSafe==='function')readSafe();if(typeof layoutTouch==='function')layoutTouch();}catch(e){}this.curtain(false);this.sync();}));
    this.sync();},
  orientOK(){const c=this.c();return !!(c.android&&screen.orientation&&screen.orientation.lock&&this.can());},
  hintKind(){const c=this.c();if(c.standalone)return null;if(c.webview)return 'open-browser';if(c.iphone)return c.iframe?'safari-toolbar':'home-screen';if(!isMob())return 'f11';if(c.ipad)return 'safari-toolbar';return 'direct-link';},
  hintText(){const k=this.hintKind(),mac=this.c().mac;switch(k){
    case 'f11':return `Сайт не пускает игру во весь экран сам. Нажмите <b>${mac?'⌃⌘F':'F11'}</b>: браузер скроет вкладки и адресную строку. Выход — то же сочетание.`;
    case 'safari-toolbar':return 'На iPhone и iPad Safari не разрешает играм открываться во весь экран. Сделайте это вручную: нажмите значок меню страницы слева в адресной строке → <b>«Скрыть панель инструментов»</b>, и поверните телефон горизонтально. Вернуть панель — касание верхнего края.';
    case 'open-browser':return 'Внутри приложения игра не может занять весь экран. Откройте её в Safari или Chrome: меню <b>«…»</b> → <b>«Открыть в браузере»</b>. Прогресс перенесите кодом сохранения.';
    case 'home-screen':return 'Чтобы игра открывалась без адресной строки: <b>«Поделиться»</b> → <b>«На экран Домой»</b>. Запускайте её с иконки — как приложение.';
    case 'direct-link':return 'Сайт не разрешает игре открываться во весь экран. Откройте ссылку на игру напрямую в Chrome (меню <b>⋮</b> → <b>«Открыть в Chrome»</b>) или добавьте её на главный экран.';
    default:return 'Игра уже занимает весь экран.';}},
  noteText(){const c=this.c();if(c.standalone)return 'Игра запущена как приложение — панелей браузера нет.';if(this.can())return 'Доступно: настоящий полный экран'+(this.is()?' · сейчас включён':'')+'.';return 'Этот браузер не пускает игру во весь экран — игра расширится на всё доступное место.';},
  diag(){const c=this.c();return `СРЕДА ${c.iframe?'вложена':'своя'} · API ${c.api?'да':'нет'} · РАЗРЕШЕНИЕ ${c.policy?'да':'нет'} · ${c.iphone?'iPhone':c.ipad?'iPad':c.android?'Android':'ПК'}${c.webview?' · WebView':''}${c.standalone?' · standalone':''} · попытка: ${this.lastErr?'отказ ('+this.lastErr+')':this.state==='native'?'успех':this.tried?'успех':'не было'}`;},
  rowPC(){if(isMob())return '';const L={off:'ВЫКЛ',auto:'ПРИ ПОЛЁТЕ',always:'ВСЕГДА'};return `<button class="tog ${SET.fsMode!=='off'?'on':''}" data-fscycle><span>ПОЛНЫЙ ЭКРАН · ${this.is()?'СЕЙЧАС ВКЛ':this.can()?'F11':'НЕДОСТУПЕН'}</span><span>${L[SET.fsMode]||'ВЫКЛ'}</span></button><p class="fsdiag">${this.diag()}</p>`;},
  card(on){const el=$('#fsCard');if(!el)return;if(on){$('#fsCardText').innerHTML=this.hintText();el.hidden=false;const b=$('#bFsCardOk');if(b&&!touchMode)b.focus();}else el.hidden=true;},
  sync(){const c=this.c(),on=this.is(),can=this.can();
    const b=$('#bFs');if(b){b.hidden=!(isMob()&&!c.standalone);b.classList.toggle('on',on);b.classList.toggle('q',!on&&!can);b.textContent=on?'✕':'⛶';b.setAttribute('aria-pressed',on?'true':'false');b.title=on?'Оконный режим':can?'Во весь экран':'Как убрать панели браузера';}
    const pc=$('#bFsPc');if(pc){pc.hidden=isMob()||c.standalone;pc.innerHTML=on?'ОКОННЫЙ РЕЖИМ <kbd>F11</kbd>':'ПОЛНЫЙ ЭКРАН <kbd>F11</kbd>';pc.setAttribute('aria-pressed',on?'true':'false');}
    const fr=$('#bFsResume'),pf=$('#bPauseFs'),rs=$('#bResume');if(fr&&pf&&rs){fr.hidden=!(this.wanted&&can&&!on);pf.hidden=!(can&&!on&&!this.wanted);rs.classList.toggle('primary',fr.hidden);}
    if(G.state==='settings'&&typeof renderSetScreen==='function')renderSetScreen();
    if(!isMob()&&(G.state==='menu'||G.state==='pause')){document.querySelectorAll('[data-fscycle]').forEach(el=>{el.outerHTML=this.rowPC().replace(/<p class="fsdiag">.*<\/p>$/,'');});document.querySelectorAll('.fsdiag').forEach(el=>{el.textContent=this.diag();});}}
};
function fsCan(){return FS.can();}function fsIs(){return FS.is();}function fsEnter(){return FS.enter('btn');}function fsExit(){FS.exit();}function fsSync(){FS.sync();}
document.addEventListener('click',e=>{if(e.target.closest('#bFs,#bFsPc')){FS.toggle('btn');buzz('tap');return;}
  if(e.target.closest('#bFsResume')){FS.enter('resume');resume();return;}
  if(e.target.closest('#bPauseFs')){FS.enter('pause');return;}
  if(e.target.closest('[data-fshint]')){FS.card(true);return;}
  if(e.target.closest('#bFsCardOk')){FS.card(false);return;}
  const cy=e.target.closest('[data-fscycle]');if(cy){const o=SET_OPT.fsMode;SET.fsMode=o[(o.indexOf(SET.fsMode)+1)%o.length];saveSet();renderSettings();FS.sync();return;}});
// режим «при полёте»: вход по кнопкам старта и по «продолжить», если игрок хотел полный экран (жест ещё активен)
document.addEventListener('click',e=>{const b=e.target.closest('#bWorld,#bEndless,#bWorldNew,#bResume');if(!b||SET.fsMode==='off'||FS.is())return;if(b.id==='bResume'&&!FS.wanted)return;
  if(!FS.can()){if(isMob()&&b.id!=='bResume'&&!SET.fsHintShown){SET.fsHintShown=true;saveSet();toast('БОЛЬШЕ МЕСТА','Скройте панели браузера — кнопка ⛶ в меню подскажет, как.');}return;}FS.enter('auto');},true);
// режим «всегда»: первое касание в меню или на паузе
document.addEventListener('pointerup',e=>{if(SET.fsMode!=='always'||FS.is()||!FS.can())return;if(G.state==='play'||G.state==='world'||G.state==='settings')return;if(e.pointerType==='mouse'&&e.button!==0)return;if(e.target.closest('#bFs,#bFsPc,#fsCard,[data-fscycle],[data-seg]'))return;FS.enter('always');},true);
document.addEventListener('fullscreenchange',()=>FS.onChange());
document.addEventListener('webkitfullscreenchange',()=>FS.onChange());
document.addEventListener('click',e=>{const b=e.target.closest('.tog[data-k]');if(!b)return;const k=b.dataset.k;SET[k]=!SET[k];saveSet();audioInit();applyAudio();renderSettings();updateCursor();});
document.addEventListener('input',e=>{if(e.target.matches('[data-vol]')){SET.ambVol=+e.target.value;saveSet();applyAudio();}});
function doneCountS(S){return saveWith6(S,doneCount);}
function renderMenu(){try{$('#wvNote').hidden=!/Telegram|FBAN|FBAV|Instagram|VKClient|WhatsApp|Line\/|; wv\)/i.test(navigator.userAgent);}catch(e){}
  renderRecord();const S=G.save&&validSave(G.save)?G.save:null;
  $('#bWorld').firstChild.nodeValue=S?'ПРОДОЛЖИТЬ ':'НАЧАТЬ ';
  $('#bWorldNew').hidden=!S;$('#bWorldNew').textContent='НОВЫЙ ПОЛЁТ';newConfirm=0;
  const eb=bestEndless();$('#bEndBest').textContent=eb?mmss(eb.t):'';$('#bDev').hidden=!devUnlocked();/*DEVW*/if(window.DEVW)DEVW.menu();
}
let newConfirm=0;
function renderRecord(){const S=G.save&&validSave(G.save)?G.save:null,risk=saveWhere()==='ВКЛАДКА',a=[];
  if(risk)a.push(`<span class="warn"><b>СОХРАНИТЕ КОД</b></span>`);
  $('#recLine').innerHTML=a.join('');}

function toMenu(){unlockArena();try{cloudMenuCheck();}catch(e){}r85Reset();G.ally85w=null;r90Reset();G.ally90w=null;G.inv80=0;G.slow80=0;G.bo80=0;G.insp80=0;G.stamp80=null;document.body.classList.remove('stamp80');G.res80=null;if(typeof W80!=='undefined'){W80.alarm=null;W80.dummy=null;W80.rlog=[];for(const q of W80.pults)q.ch=0;}G.course=null;riftReset();if(G.devRun)recReload();banT=0;$('#banner').classList.remove('show');if(G.prologue)prologueEnd();radioClear();if(G.mode==='world'&&G.world&&G.player)saveWorld();/*DEVW*/if(window.DEVW&&DEVW.on())DEVW.suspend();G.fromAbyss=false;G.devRun=false;G.mode=null;G.end=null;G.lowFx=false;$('#devPanel').hidden=true;scr6('menu');G.world=false;G.inRun=false;G.player=null;G.boss=null;G.jam=null;G.sb=null;G.bc=null;G.dark=false;CX=0;CY=0;$('#toast').hidden=true;renderMenu();show('sMenu');FS.sync();}
function snapshotRun(){G.runStart={mods:{...G.mods},hp:G.player.hp,en:G.player.en,xp:G.xp,lvl:G.lvl,need:G.need,score:G.score,kills:G.kills,taken:G.taken};}
function restoreRun(){const s=G.runStart;G.mods={...s.mods};computeStats();G.player=newPlayer();Object.assign(G.player,{hp:s.hp,en:s.en});runRestore6(s);Object.assign(G,{score:s.score,kills:s.kills,taken:s.taken});}
function openIntro(i){
  radioClear();if(G.radio){G.radio.mN=0;G.radio.t=20;G.radio.q=[];}G.retreatN=0;
  if(G.mode==='world'){const S=G.save;G.diff=DIFF[S.diff]?S.diff:'easy';G.mods={};computeStats();G.player.hp=G.st.maxHp;runZero6(true);}
  else if(G.mode==='dev')G.diff=G.dev.diff||'easy';
  if(!G.keepLayout)G.layoutSeed=(Math.random()*2147483647)|0;G.keepLayout=false;
  scr6('intro');lockArena();setupMission(i);snapshotRun();if(G.arena){G.camSnap=1;missionCam(0);}const M=MISSIONS[i];
  $('#inSector').textContent='МИССИЯ '+pad2(i+1)+' · '+M.sector;$('#inName').textContent=mTitle(M);
  $('#bIntroBack').hidden=G.mode!=='world'&&G.mode!=='dev';$('#bIntroBack').textContent=G.mode==='dev'?'К ВЫБОРУ МИССИЙ':'НАЗАД В СЕКТОР';
  $('#inThreat').innerHTML=(MISSION_K[i+1]?'<span class="tag threat">УСИЛЕНА</span>':'')+dangerTag(M)+(i+1===14&&storyFlag('arcSilence')?'<span class="tag">МАЯКИ АРХИВА СНЕСЕНЫ</span>':'')+mechTags(M).map(k=>`<span class="tag mech">${k}</span>`).join('')+M.intro.map(k=>`<span class="tag threat">НОВАЯ УГРОЗА · ${EDEF[k].name.toUpperCase()}</span>`).join('');
  $('#inHint').innerHTML=M.hint.map(h=>`<p>${kh(secHintFmt(h,i+1))}</p>`).join('')+(G.mode==='world'&&STORY_NOTES[i+1]?`<p class="note" style="color:#7a8ea5;font-size:12px">Примечание бортовой системы: ${STORY_NOTES[i+1]}</p>`:'');renderDiff();renderWpnSel();if(isMob()&&M.hint.length>1){$('#inHint').insertAdjacentHTML('beforeend',`<button class="rbtn more mobonly" id="bHintMore">ЕЩЁ ПОДСКАЗКИ</button>`);}$('#inHint').classList.remove('open');show('sIntro');(touchMode||$('#bGo').focus());
}
function renderWpnSel(){const box=$('#inWpnBox');if(!box)return;const S=G.save,ok=G.mode==='world'&&G.state==='intro'&&S&&S.ars&&S.ars.own.blast;box.hidden=!ok;if(!ok)return;
  $('#inWpn').innerHTML=['gun','blast'].map(w=>`<button data-wpn="${w}" class="${S.ars.weapon===w?'on':''}">${ARS[w].name}</button>`).join('');}
document.addEventListener('click',e=>{const b=e.target.closest('[data-wpn]');if(!b||!G.save||!G.save.ars||!G.save.ars.own[b.dataset.wpn])return;G.save.ars.weapon=b.dataset.wpn;computeStats();saveWorld();renderWpnSel();buzz('tap');});
function renderDiff(){
  const world=G.mode==='world';$('#inDiffBox').hidden=!(world||G.mode==='dev');if($('#inDiffBox').hidden)return;
  const cur=G.diff,D=DIFF[cur],K=briefK(G.m);
  $('#inDiff').innerHTML=DIFF_KEYS.map(k=>`<button class="d-${k} ${k===cur?'on':''}" data-diff="${k}">${DIFF[k].name}</button>`).join('');
  const M=MISSIONS[G.m-1],noRep=!!(M&&M.gen&&SEC_SCALE[M.sec]);
  $('#inDiffNote').textContent=(DIFF_NOTE[cur]||'')+(cycleN()>1?' Цикл '+roman(cycleN())+': враги крепче.':'');
}
$('#inHint').addEventListener('click',e=>{if(e.target.closest('#bHintMore')){$('#inHint').classList.add('open');e.target.remove();}});
$('#inDiffNote').addEventListener('click',()=>$('#inDiffNote').classList.toggle('open'));
$('#inDiff').addEventListener('click',e=>{const b=e.target.closest('[data-diff]');if(!b||G.state!=='intro')return;const k=b.dataset.diff;
  if(G.mode==='world'){G.save.diff=k;store(saveKey(),G.save);}else if(G.mode==='dev'){G.dev.diff=k;store('void_dev',G.dev);}
  if(G.mode==='dev')restoreRun();G.keepLayout=true;openIntro(G.m-1);});
function startMission(){if(G.state!=='intro')return;ambSting('start');const K=briefK(G.m);
  if(K>0){runBrief6(K);scr6('play');updateHUD();openLevelUp();return;}
  scr6('play');show('');}
function autoPick(){let n=0;while(G.state==='levelup'&&pickMode==='ship'&&G.briefQ>0&&choices.length&&n++<40)choose(Math.random()*choices.length|0);}
function missionComplete(){
  if(G.state!=='play')return;
  if(G.mode==='world'){worldMissionDone();/*DEVW*/if(window.DEVW&&DEVW.on())DEVW.after('done');return;}
  devMissionDone();
}
function gameOver(){ambSting('fail');
  if(G.mode==='endless'){endlessOver();return;}
  scr6('over');
  if(G.mode==='world'){REC.best=Math.max(REC.best,G.score);REC.maxMission=Math.max(REC.maxMission,G.m);saveRec();}
  $('#ovEyebrow').textContent=G.devRun?'ТЕСТ · СИГНАЛ ПОТЕРЯН':G.mode==='world'&&!G.loseBeacon?'СИГНАЛ ПОТЕРЯН':'СИГНАЛ ПОТЕРЯН';$('#ovName').textContent=G.loseBeacon?'Маяк разрушен':'Корабль уничтожен';
  $('#ovStats').innerHTML=statCells([['ВРЕМЯ',mmss(G.mT)]]);
  $('#ovNote').textContent=G.loseBeacon?'Пиявок и врагов с ромбом над головой снимайте первыми.':'';
  $('#bRetry').firstChild.nodeValue='ПОВТОРИТЬ МИССИЮ ';$('#bRetry').hidden=false;
  $('#bToWorld').hidden=false;$('#bToWorld').textContent=G.devRun?'К ВЫБОРУ МИССИЙ':'В СЕКТОР';
  show('sOver');(touchMode||$('#bRetry').focus());
  /*DEVW*/if(window.DEVW&&DEVW.on()&&G.mode==='world')DEVW.after('over');
}
const statCells=a=>a.map(([k,v])=>`<div>${k}<b>${v}</b></div>`).join('');
const mmss=s=>Math.floor(s/60)+':'+pad2(Math.floor(s%60));
function pause(){if(G.state!=='play'&&G.state!=='world')return;G.pausedWorld=G.state==='world';scr6('pause');renderSettings();FS.sync();
  $('#bRestart').hidden=G.pausedWorld;$('#bRestart').textContent=G.mode==='endless'?'НАЧАТЬ ЗАНОВО':'ПЕРЕЗАПУСК МИССИИ';
  $('#bPauseMap').hidden=!G.pausedWorld;$('#bAbandon').hidden=!(((G.mode==='world'||G.mode==='dev')&&!G.pausedWorld)||G.fromAbyss);$('#bAbandon').textContent=G.fromAbyss?'ПОКИНУТЬ БЕЗДНУ · БЕЗ РЕКОРДА':G.mode==='dev'?'К ВЫБОРУ МИССИЙ':'ПОКИНУТЬ МИССИЮ';
  ['bRestart','bAbandon','bQuit'].forEach(id=>{const el=$('#'+id);if(el.dataset.arm){el.dataset.arm='';el.textContent=el.dataset.lab;}el.dataset.lab='';});
  {const S=G.save;$('#pauseStat').textContent=G.pausedWorld&&S?`МИССИИ ${doneCount()}/${NM}`:G.mode==='endless'?`СТУПЕНЬ ${G.end?G.end.step:1}`:mName(MISSIONS[G.m-1]).toUpperCase();}
  show('sPause');(touchMode||$('#bResume').focus());/*DEVW*/if(window.DEVW)DEVW.pauseUI();}
function resume(){if(G.state!=='pause')return;scr6(G.pausedWorld?'world':'play');show('');if(touchMode&&isMob())G.resumeK=1.2;}

// выбор модуля корабля или маяка
let choices=[],pickMode='ship';
function nextPick(){if(G.bpQ>0)openBeaconPick();else if(G.lvlQ>0)openLevelUp();else{scr6(G.world?'world':'play');show('');}}
function openLevelUp(){
  scr6('levelup');pickMode='ship';sfx('level');
  const avail=shuffle(Object.keys(MODS).filter(k=>(G.mods[k]||0)<MODS[k].max&&G.m>=MODS[k].from&&!(G.mode==='endless'&&['tractor','sync','linekit','light'].includes(k))&&!(G.st.weapon==='blast'&&(k==='pierce'||k==='rico'))));
  choices=avail.slice(0,3);if(!choices.length)choices=['__repair'];
  $('#lvEyebrow').textContent=G.briefQ>0?'СТАРТОВЫЙ МОДУЛЬ · '+(G.briefN-G.briefQ+1)+' ИЗ '+G.briefN:'НОВЫЙ МОДУЛЬ'+(G.lvlQ>1?' · ЕЩЁ '+(G.lvlQ-1):'');
  $('#lvAuto').hidden=!(G.briefQ>0);
  $('#cards').classList.remove('bcm');
  $('#cards').innerHTML=choices.map((k,i)=>{
    if(k==='__repair')return `<button class="card" data-i="${i}"><div class="k"><span>${noHeal()?'ЗАРЯД':'РЕМОНТ'}</span><span>${i+1}</span></div><h3>${noHeal()?'Подзарядка':'Полевой ремонт'}</h3><p>Все модули на пределе. ${noHeal()?'Полный накопитель и щит.':'Подлатать корпус.'}</p></button>`;
    const M=MODS[k],l=G.mods[k]||0;
    const pips=Array.from({length:M.max},(_,j)=>`<i class="${j<l?'f':j===l?'n':''}"></i>`).join('');
    return `<button class="card" data-i="${i}"><div class="k"><span>${M.tag}</span><span>${i+1}</span></div><h3>${M.name}</h3><div class="pips">${pips}</div><p>${M.d}</p></button>`;}).join('');
  show('sLevel');const f=$('#cards .card');if(f&&!touchMode)f.focus();
}
function openBeaconPick(){
  scr6('levelup');pickMode='beacon';sfx('level');const bc=G.bc;
  const avail=shuffle(Object.keys(BMODS).filter(k=>(bc.mods[k]||0)<BMODS[k].max));
  choices=avail.slice(0,3);if(!choices.length)choices=['__bcrep'];
  $('#lvEyebrow').textContent='МОДУЛЬ МАЯКА';$('#lvAuto').hidden=true;
  $('#cards').classList.add('bcm');
  $('#cards').innerHTML=choices.map((k,i)=>{
    if(k==='__bcrep')return `<button class="card" data-i="${i}"><div class="k"><span>МАЯК</span><span>${i+1}</span></div><h3>Ремонт маяка</h3><p>Все модули маяка стоят. Починить маяк.</p></button>`;
    const M=BMODS[k],l=bc.mods[k]||0;
    return `<button class="card" data-i="${i}"><div class="k"><span>МАЯК</span><span>${i+1}</span></div><h3>${M.name}</h3>${M.max>1?'<div class="pips">'+Array.from({length:M.max},(_,j)=>`<i class="${j<l?'f':j===l?'n':''}"></i>`).join('')+'</div>':''}<p>${M.d}</p></button>`;}).join('');
  show('sLevel');const f=$('#cards .card');if(f&&!touchMode)f.focus();
}
function choose(i){
  if(G.state!=='levelup'||!choices[i])return;if(pickMode==='zbChoice'){zbChoose(i);return;}const k=choices[i];
  if(pickMode==='beacon'){const bc=G.bc;if(bc){if(k==='__bcrep')bc.hp=Math.min(bc.maxHp,bc.hp+120);else{bc.mods[k]=(bc.mods[k]||0)+1;if(k==='barrier')bc.barrier=100;}}runTake6('bp');}
  else{
    if(k==='__repair'){if(noHeal()){G.player.en=100;G.player.shieldUp=true;G.player.shieldT=0;}else G.player.hp=Math.min(G.st.maxHp,G.player.hp+40);}
    else{const before=G.st.maxHp;G.mods[k]=(G.mods[k]||0)+1;computeStats();if(k==='hull'&&(!noHeal()||G.briefQ>0))G.player.hp+=G.st.maxHp-before;if(k==='shield'&&G.mods.shield===1){G.player.shieldUp=true;}}
    runTake6('lvl');}
  G.player.inv=Math.max(G.player.inv,.6);
  nextPick();
}
$('#cards').addEventListener('click',e=>{const c=e.target.closest('.card');if(c)choose(+c.dataset.i);});
$('#bAuto').onclick=autoPick;

// справочник (1.1.0: семь разделов, коротко; «Версии» — только в режиме разработчика)
const CX_TABS=[['ctrl','УПРАВЛЕНИЕ'],['world','МИР'],['threat','УГРОЗЫ'],['mods','МОДУЛИ'],['endless','БЕСКОНЕЧНОСТЬ'],['chron','ХРОНИКА'],['journals','ЖУРНАЛЫ'],['log','ВЕРСИИ']];
let cxTab='ctrl',codexFrom='menu';
function cxTabs(){return CX_TABS.filter(([k])=>k!=='log'||devUnlocked()||cxTab==='log');}
function openCodex(from){codexFrom=from;scr6('codex');$('#cxTabs').innerHTML=cxTabs().map(([k,n])=>`<button class="tab ${k===cxTab?'on':''}" data-t="${k}">${n}</button>`).join('');renderCodex();show('sCodex');}
function closeCodex(){if(codexFrom==='pause'){scr6('pause');renderSettings();show('sPause');}else toMenu();}
const kv=a=>`<dl class="kv">${a.filter(Boolean).map(([t,d])=>`<dt>${t}</dt><dd>${d}</dd>`).join('')}</dl>`;
function renderCodexWorld(B){
  const S=G.save&&validSave(G.save)?G.save:null,F=touchMode?'кнопку над рывком':'F';
  if(cxTab==='world')B.innerHTML=kv([
    ['Сектора','Двенадцать секторов, пятьдесят миссий. Следующая миссия открывается после предыдущей, следующий сектор — после последней миссии текущего. Закрытое скрыто туманом.'],
    ['Узлы','Каждая миссия — источник сигнала. Голубой — пройден, янтарный — доступен. Подлетите и нажмите '+F+'.'],
    ['Модули и перки','Модули действуют до конца миссии: часть выбирается на брифинге, остальные — за осколки данных в бою. Перки мастерской — навсегда.'],
    ['Маяк','Миссии 7–10. Стойте в кольце вокруг маяка, чтобы заряжать его, и везите туда энергоячейки. На рисках шкалы маяк вспыхивает и даёт модуль маяка. Маяк разрушен — провал.'],
    ['Метки','Ромб — враг летит к маяку, треугольник — охотится на вас, кольцо — диверсант.'],
    ['Предметы','Осколки данных — опыт модулей. Энергоячейка — заряд импульса, на миссиях с маяком — груз для маяка.'],
    ['Лом','Обломки и награды. Лом при себе сдаётся в мастерской или при входе в миссию. Погибли — лом остаётся на месте гибели.'],
    ['Медали','Прохождение, чистота (почти без урона) и мастерство — своё условие у каждой миссии.'],
    ['Сложность','Выбирается на брифинге. Выше сложность — сильнее враги и больше лома.'],
    ['Без ремонта','В миссии корпус не чинится ничем: вы входите целым и держите то, что осталось. Чинят корпус мастерская и перк в секторе.'],
    ['Мастерская','Ремонт корпуса, перки за лом, контракты и новый цикл.'],
    ['Арсенал «Иней»','Открывается после победы над боссом Холодного архива: улучшения орудия и второе оружие «Разрыв».'],
    ['Пилот','Опыт пилота растёт за бой, миссии и находки. Уровень пилота открывает скины в Хранилище корпусов.'+(S?' Сейчас — уровень '+S.pilot.lvl+'.':'')],
    ['Находки','Тайники, бортжурналы, фрагменты памяти, аномалии и ретрансляторы. Ретрансляторы раскрывают карту и становятся точками прыжка.'],
    ['Карта',(touchMode?'Кнопка КАРТА':'M')+' — карта. Прыжок к пройденному узлу, мастерской или ретранслятору, если рядом нет врагов.'],
    ['Разлом','За краем секторов пространство нестабильно. В глубине живут Неизвестные: их снаряды смертельны, спасает только рывок.'],
    ['Бездна','Бесконечность на базовом корабле. Вход — за воротами у миссии 10.'],
    ['Новый цикл','Сектор начинается заново: враги сильнее, награды больше. Перки, скины, уровень пилота и лом остаются.']]);
  if(cxTab==='journals'){if(S){renderJournals(B,false);return;}}
  if(cxTab==='journals')B.innerHTML=WORLD.journals.map(j=>S&&S.journals[j.id]?`<div class="cx-row" style="grid-template-columns:minmax(0,1fr)"><div><h4>${j.title}</h4><p>${j.text}</p></div></div>`:`<div class="cx-row" style="grid-template-columns:minmax(0,1fr)"><div><h4 class="lock">ЗАПИСЬ НЕ НАЙДЕНА</h4></div></div>`).join('');
}
$('#cxTabs').addEventListener('click',e=>{const b=e.target.closest('.tab');if(!b)return;cxTab=b.dataset.t;openCodex(codexFrom);});
const GRP_NAME={siege:'К МАЯКУ',hunt:'ОХОТНИК',sab:'ДИВЕРСАНТ'};
function renderCodex(){
  const B=$('#cxBody');if(cxTab==='pilot'||cxTab==='items'||cxTab==='beacon')cxTab='world';
  if(cxTab==='chron'){B.innerHTML=chronicleHTML();return;}if(cxTab==='world'||cxTab==='journals'){renderCodexWorld(B);return;}
  if(cxTab==='endless'){const L=endRecords();B.innerHTML=kv([
    ['Цель','Продержитесь как можно дольше.'],
    ['Ступени','С каждой ступенью врагов больше, появляются новые.'],
    ['Эхо боссов','Время от времени приходит эхо Стража или Глушителя. Пока оно живо, ступень стоит.'],
    ['Корабль','Базовый, без модулей и перков сектора. Прогресс сектора не меняется.']])+
    `<div class="cx-h">ЛУЧШИЕ ЗАБЕГИ</div>`+(L.length?L.map((r,i)=>`<div class="cx-row" style="grid-template-columns:40px minmax(0,1fr)"><div class="eyebrow" style="color:var(--amber)">${pad2(i+1)}</div><div><h4>${mmss(r.t)}<small>СТУПЕНЬ ${r.s} · УНИЧТОЖЕНО ${r.k}</small></h4></div></div>`).join(''):'<p class="note">Забегов пока нет.</p>');return;}
  if(cxTab==='ctrl'&&touchMode&&isMob())B.innerHTML=kv([
    ['СТИК','Коснитесь '+(SET.hand==='l'?'правой':'левой')+' половины экрана — там появится стик. Дальше от центра — быстрее.'],
    ['РЫВОК','Кнопка справа или быстрый свайп по экрану — рывок туда, куда провели. Кольцо — перезарядка.'],
    ['ИМП','Импульс, когда кольцо кнопки заполнено: сносит снаряды и отбрасывает врагов.'],
    ['ЗАРЯД','Удерживайте и отпустите — мощный выстрел насквозь.'],
    ['КАСАНИЕ ВРАГА','Цель. Повторное касание снимает отметку.'],
    ['ОГОНЬ','Сам, по ближайшей цели.'],
    ['В СЕКТОРЕ','Кнопка над рывком: у узла или мастерской — войти, иначе — карта. Держите стик у края в спокойном полёте — корабль полетит сам.'],
    ['НАЗАД','Системная кнопка «назад» — пауза или закрыть экран.']]);
  else if(cxTab==='ctrl')B.innerHTML=kv([
    ['WASD / стрелки','Движение'],['ПРОБЕЛ','Рывок сквозь снаряды'],['E / SHIFT','Импульс, когда шкала полна'],['ПКМ / Q','Удерживать — заряженный выстрел насквозь'],
    ['МЫШЬ','Ручной прицел; наведите на врага — прицел захватит его. T — ручной или авто'],['КЛИК ПО ВРАГУ','Цель; клик по пустому месту снимает отметку'],
    ['F / ENTER','Войти в миссию, открыть мастерскую, начать аномалию'],['1 · 2 · 3 · A','Выбор модуля · автовыбор'],
    ['M / TAB · J','Карта · журналы'],['C','Справочник'],['ESC / P','Пауза'],['F11','Полный экран'],['Огонь','Сам, по ближайшей видимой цели']]);
  if(cxTab==='threat'){let html='',act=0,lk=0;const flush=()=>{if(lk)html+=`<p class="note cx-lockn">Не опознано: ${lk}. Встретьте их в бою.</p>`;lk=0;};
    CODEX_ORDER.forEach(k=>{const d=EDEF[k];if(d.act!==act){flush();act=d.act;html+=`<div class="cx-h">${act===1?'АКТ I · ПУТЬ К СТРАЖУ':act===2?'АКТ II · МАЯК':act===6?'НУЛЕВАЯ ТОЧКА И НУЛЕВОЙ МИГ':act===5?'СЕРДЦЕ КОВЧЕГА И СТЁРТЫЕ БЕРЕГА':act===4?'ПРЕДЕЛ И ИСТОК':'АРХИВ, ХРОНИКИ, КОЛЫБЕЛИ, ФЛОТ'}</div>`;}
      if(!REC.seen.includes(k)){lk++;return;}html+=`<div class="cx-row"><canvas data-icon="${k}" width="128" height="128"></canvas><div><h4>${d.name}${d.grp?`<small>${GRP_NAME[d.grp]}</small>`:''}</h4><p>${d.desc}</p>${d.lore?`<p class="lore">${d.lore}</p>`:''}</div></div>`;});flush();
    html+=`<div class="cx-h">ЭЛИТА · ЦВЕТНОЙ ПУНКТИР</div>`+Object.values(AFX).map(a=>`<div class="cx-row" style="grid-template-columns:110px minmax(0,1fr)"><div class="eyebrow" style="color:${a.col}">- - - -</div><div><h4>${a.name}</h4><p>${a.d[0].toUpperCase()+a.d.slice(1)}.</p></div></div>`).join('');
    B.innerHTML=html;drawIcons();}
  if(cxTab==='mods')B.innerHTML=`<p class="note">Модули действуют до конца миссии. У каждого — несколько уровней.</p>`+Object.values(MODS).map(M=>`<div class="cx-row" style="grid-template-columns:110px minmax(0,1fr)"><div class="eyebrow" style="color:var(--violet)">${M.tag}</div><div><h4>${M.name}</h4><p>${M.d}</p></div></div>`).join('')+
    `<div class="cx-h">МОДУЛИ МАЯКА</div>`+Object.values(BMODS).map(M=>`<div class="cx-row" style="grid-template-columns:110px minmax(0,1fr)"><div class="eyebrow" style="color:var(--amber)">МАЯК</div><div><h4>${M.name}</h4><p>${M.d}</p></div></div>`).join('');
  if(cxTab==='log')B.innerHTML=`<dl class="kv"><dt>1.5.35 α</dt><dd>Этапы 6 и 7 завершены по коду: смена экранов, замена прогресса и прокачка в забеге меняются каждая в своём месте и проверяются автоматически; старые копии функций и лишние надстройки убраны. Игра работает как раньше.</dd><dt>1.5.34 α</dt><dd>При пределе кадров на быстрых экранах движение отрисовывается плавнее (сглаживание между шагами игры).</dd><dt>1.5.33 α</dt><dd>Режим 30 кадров сам по себе больше не снижает качество графики; если устройство действительно не успевает, автокачество по-прежнему его снижает.</dd><dt>1.5.32 α</dt><dd>Настройка «Кадры» теперь есть и на компьютере; выбор на компьютере и на телефоне хранится отдельно.</dd><dt>1.5.31 α</dt><dd>Частота кадров: 30, 60 или без ограничения. Предел теперь точный на любом экране (раньше «30» на экранах 75–240 Гц давало от 25 до 33 кадров), а скорость игры от выбора не зависит. Прежний режим «60» на быстрых экранах ничего не ограничивал — у тех, кто его выбирал, теперь стоит «Без ограничения».</dd><dt>1.5.30 α</dt><dd>Этап 6, шаг 3. Опыт, уровень и очереди улучшений в забеге теперь меняет один модуль игры, а не девятнадцать разных мест. Повышение уровня, брифинг и выбор модулей работают как раньше.</dd><dt>1.5.29 α</dt><dd>Этап 6, шаг 2. Замена текущего прогресса (загрузка, новая игра, облако, сброс) проходит через одну функцию; временные подмены прогресса всегда возвращают прежний. Для игрока ничего не изменилось.</dd><dt>1.5.28 α</dt><dd>Этап 6, шаг 1. Смена экранов игры (меню, пауза, карта, ангар и другие) теперь проходит через одну функцию вместо сорока одного места. Экраны работают как раньше.</dd><dt>1.5.27 α</dt><dd>Этап 7, шаг 3. Убран запасной старый вариант кода прицеливания, оставленный на время проверки версии 1.5.24. Прицеливание работает как раньше.</dd><dt>1.5.26 α</dt><dd>Этап 7, шаг 2. Четыре цепочки мелких надстроек над экраном настроек и обучением собраны каждая в одну надстройку. Надстройки, которые принадлежат разным частям игры, оставлены раздельными, чтобы каждая переехала вместе со своей частью. Порядок действий тот же; в игре ничего не изменилось.</dd><dt>1.5.25 α</dt><dd>Этап 7, шаг 1. Из кода убраны 24 старые копии функций, которые давно заменены новыми и никогда не выполнялись. В игре ничего не изменилось.</dd><dt>1.5.24 α</dt><dd>Этап 5 завершён. Наведение собрано в одну подсистему с проверяемой границей: какие места игры могут менять отмеченную цель и прицел, перечислено и проверяется автоматически. В игре ничего не изменилось.</dd><dt>1.5.23 α</dt><dd>Этап 5, шаг 3. Внешние места, где игра снимала или ставила отмеченную цель и сбрасывала ручной захват (уничтожение врага, отступление, перехват петли, аномалия, бесконечный режим), теперь вызывают три именованные функции подсистемы наведения. Поведение не изменилось; новые прямые записи ловит проверка.</dd><dt>1.5.22 α</dt><dd>Этап 5, шаг 2. Наведение корабля (выбор цели, ручной прицел, поворот, решение стрелять) вынесено из обновления игрока в подсистему наведения. Игра работает как раньше; прежний путь включается флагом A-26.</dd><dt>1.5.21 α</dt><dd>Этап 5, пилот. Функции наведения (кого можно взять в прицел, выбор цели, ручной прицел, отметка касанием, точка прицеливания) собраны в один блок исходника. Игра, прицел и стрельба работают как раньше.</dd><dt>1.5.20 α</dt><dd>«Свобода корпуса» (пробная, по умолчанию выключена). Если корабль улетает от далёкой цели, его нос плавно разворачивается по ходу полёта, а пушки продолжают бить по цели. Цели, дальность и сила стрельбы не меняются.</dd><dt>1.5.19 α</dt><dd>«Ровный такт». На обычных экранах 60 Гц игра больше не путает соседние кадры: раньше из-за округления времени браузером часть кадров получала сразу два игровых шага, а часть — ни одного, и движение слегка подёргивалось. Скорость игры, урон и враги не изменились.</dd><dt>1.5.18 α</dt><dd>«Снегопад». На экранах 90, 120 и 144 Гц снег и дождь в открытом секторе снова идут, а не застывают. Плавность движения защищена от сбоев: если что-то пойдёт не так, игра просто продолжит работу с обычной картинкой.</dd><dt>1.5.17 α</dt><dd>«Диагностика». В меню разработчика появился переключатель «Диагностика кадров»: поверх игры показываются частота экрана, равномерность кадров, плавность движения и текущая цель, а последние 30 секунд можно сохранить в файл. Обычная игра не меняется.</dd><dt>1.5.16 α</dt><dd>«Шаг V». На мониторах 90, 120 и 144 Гц корабль, враги, боссы, снаряды и камера теперь движутся плавно с частотой экрана: между расчётными шагами игры картинка показывает промежуточное положение. Сама игра, попадания, враги и сохранения от этого не меняются. На экранах 60 Гц всё остаётся как было.</dd><dt>1.5.15 α</dt><dd>«Шаг IV». Мелкие визуальные эффекты — вспышки щитов, подсветка ударов, глитчи, снег и дождь в секторах — теперь гаснут и движутся с одинаковой скоростью на любом экране: раньше на 144 Гц они пролетали вдвое быстрее, а на 30 Гц тянулись вдвое дольше. Игровая логика, баланс, награды и сохранения не изменились.</dd><dt>1.5.14 α</dt><dd>«Шаг III». Обновление под капотом. Кинематографичный режиссёр первых миссий (замедления, финальная камера, удары) теперь отсчитывает своё время по шагам игры, а не по частоте кадров экрана: на быстрых и медленных мониторах его замедления срабатывают одинаково. Вид сцен, звук, баланс, награды и сохранения не изменились.</dd><dt>1.5.13 α</dt><dd>«Шаг II». Обновление под капотом. Игра теперь рассчитывает мир ровными шагами по 1/60 секунды независимо от частоты кадров экрана: на 30, 60, 120 или 144 Гц одинаковые бои развиваются одинаково, а при коротких подвисаниях игра догоняет время не более чем на три шага, как и раньше. Замедления, ударные паузы и плавный возврат после паузы работают как прежде. Баланс, враги, награды и сохранения не изменились.</dd><dt>1.5.12 α</dt><dd>«Шаг I». Обновление под капотом. Короткая ударная пауза при попаданиях теперь отсчитывает свою задержку по часам игры, а не по часам компьютера. В обычной игре это ничего не меняет, но одинаковые бои теперь одинаково повторяются в проверочных прогонах. Баланс, враги, награды и сохранения не изменились.</dd><dt>1.5.11 α</dt><dd>«Ровно II». Обновление под капотом. Частицы, искры, следы рывка и дрожание интерфейса теперь берут случайность из собственного визуального источника. Настройки «Эффекты», «Меньше эффектов», качество графики и частота кадров больше не меняют ход боя: одна и та же схватка разворачивается одинаково при любой графике. Баланс, враги, награды и сохранения не изменились.</dd><dt>1.5.10 α</dt><dd>«Ровно». Обновление под капотом. Ржавый контейнер теперь вскрывается за 3 секунды на любом экране: раньше на экранах 120–144 Гц он открывался почти вдвое быстрее, а при 30 кадрах — вдвое медленнее. Ход финального боя больше не зависит от качества графики, плотности пикселей экрана и открытой карты, а ход любого боя — от музыки и звука. Если старое сохранение не прочиталось и отложить его копию некуда, игра не запишет новый прогресс поверх него, пока вы не скачаете старую запись файлом или явно не откажетесь от неё. Сбой в отображении интерфейса больше не ставит игру на паузу. Баланс, враги, боссы и прогресс не менялись.</dd><dt>1.5.9 α</dt><dd>«Опора». Обновление под капотом: игра стала надёжнее, а играется и выглядит так же. Если сохранение не удаётся прочитать, оно больше не стирается новой игрой: старая запись откладывается отдельно, и игра об этом сообщает. Если какая-то система игры даст сбой, бой не зависнет молча — игра встанет на паузу и скажет об этом. Карта больше не перерисовывается по нескольку раз за кадр после повторных нажатий на её вкладку. Механики, баланс, враги, боссы и прогресс не менялись — это проверено повтором боёв со всеми десятью боссами.</dd><dt>1.5.8 α</dt><dd>«Тише». Обновление без новых механик: игра считает меньше лишнего, а выглядит и играется так же, как раньше. Числа в интерфейсе (лом, счёт, цены, итоги миссий) форматируются в 15 раз быстрее — тот же текст до символа. Враги в больших боях быстрее расходятся друг от друга и быстрее находят, кого прикрыть щитом или усилить: те же решения и та же траектория до последнего врага, проверено повтором боя с одним сидом. Каждую из оптимизаций можно выключить, и тогда игра идёт старым путём.</dd><dt>1.5.7 α</dt><dd>«Небо: глубина». Маяк Ядра в открытом мире теперь стоит на месте, как самая дальняя точка неба: вверху слева, вдали от миникарты. Через весь сектор он сдвигается едва заметно, всего на ~50 единиц, — это параллакс, а не погоня за курсом. Сам Маяк стал чуть светлее. Камни на заднем плане стали непрозрачными и ближе всего остального фона: звёзды, пыль, туман и Маяк — позади них. Когда камень проходит перед Маяком, начинается затмение. Сначала светлеет край камня, обращённый к Маяку. Когда Маяк уходит за край, на контуре вспыхивает яркая точка. Потом свет обтекает камень по всему периметру и слабеет, чем глубже Маяк за камнем. Всё это плавно, без переключений. Скорости параллакса прежние. «Затмение при остановке» убрано — его заменило настоящее. Исправлено: камни заднего плана в миссиях 02 и 05 раньше не рисовались совсем.</dd><dt>1.5.6 α</dt><dd>«Небо», правки после первого показа. Длинная Дуга Пояса убрана — и в открытом мире, и в миссиях: на ходу она смещалась неровно и спорила с полётом. Кольцо станций вокруг Маяка в миссии 06 осталось. Сам Маяк Ядра стал тусклее: ядро и лучи спокойнее, а свет, которым он подсвечивает туман, прежний. В открытом мире Маяк больше не прыгает с места на место — например, когда пролетаешь мимо миссии 05 и Ядро оказывается прямо под тобой. Теперь он плавно, примерно за полсекунды, переплывает по краю неба. На вертикальном экране направления «вниз» отражаются наверх, и прыжка слева направо больше нет.</dd><dt>1.5.5 α</dt><dd>«Небо» (прототип) — у первого сектора, «Пояса Стража», появилось своё небо, одно на весь сектор: в открытом мире и в миссиях 01–06. В глубине — холодный туман бирюзы и синевы с редкими фиолетовыми прожилками, тёмные полосы пыли и три слоя звёзд разных оттенков. Через небо идёт Дуга Пояса — тонкая линия станций с огнями. Вдалеке горит Маяк Ядра, единственный источник света, и туман подсвечен с его стороны. С каждой миссией Маяк ближе и крупнее, а в 06 Дуга смыкается вокруг него кольцом. В открытом мире Маяк всегда стоит в той стороне, где Ядро, а у ворот во второй сектор небо плавно переходит в янтарное. Центр экрана, где идёт бой, и полосы интерфейса нарочно спокойнее и темнее — фон не спорит с пулями. Небо собирается заранее и по частям, так что миссия не притормаживает, а слабые телефоны получают облегчённую версию. Настройка «Яркость неба: тусклее / обычная / ярче» — во вкладке «Экран». Заодно исправлено: старое небо при повороте экрана больше не сдвигает случайности боя.</dd><dt>1.5.1 α</dt><dd>«Кадр», вторая версия прототипа. Заголовки больше не печатаются по букве — ни на брифинге, ни в миссии; так печатаются только подсказки: примечание БОРТА и радио. В миссии вместо «ГЛАВА I · ПРОБУЖДЕНИЕ» — только название миссии: оно проявляется из размытия, по буквам проходит блик, под ним растёт линия. Режиссура 01–04 переписана. Камера: 01 открывается вплотную к кораблю, в расфокусе и полутьме, и отъезжает, пока открываются глаза; 02 начинается медленным наездом; удар тарана и финальный удар показаны коротким наездом. Цвет: в 01 мир бесцветен и возвращает цвет с каждым зажжённым буем, 02 выцветшая, как старая плёнка, 03 пыльно-тёплая, 04 глубоко-синяя; на финальном ударе цвет уходит. Звук: свой зал с длинным хвостом и панорама по экрану; в 01 музыка слышна как сквозь воду и открывается вместе с глазами, системы включаются нотами одного аккорда, буи звенят колоколом; трассеры 02 пролетают слева направо и звенят о плиты; перед тараном 03 гул идёт с той стороны, откуда он выйдет; 04 — подъём шума и тяжёлый удар на заголовке, гудящая тень, от которой мигает интерфейс; на замедлении звук уходит под воду и возвращается; финальный удар — суб-удар, секунда тишины и шлейф аккорда. Как и раньше, бой не меняется, управление у вас, а «Кино: тихое / выкл» во вкладке «Экран» убирает движение камеры.</dd><dt>1.5.0 α</dt><dd>«Кадр» (прототип) — первые четыре миссии стали четырьмя главами пролога: «Пробуждение», «Отзвук», «Дрейф» и «Тень гиганта». У каждой — свой цвет, свой титр и один фирменный момент. В 01 корабль просыпается вслед за пилотом: веки-полосы открываются, интерфейс зажигается по частям, когда становится нужен, а сектор светлеет с каждым зажжённым буем. В 02 по арене пролетают чужие трассеры вашего типа, а на плитах остаются их следы. В 03 перед первым тараном стихает музыка, а первый удар тарана о глыбу показан как авария. В 04 над минным полем проходит тень чего-то очень большого, цепь мин звучит нотами, а в конце корабль находит прожектор. Голос Стража в 01–04 звучит по событиям, а не по таймеру. Новых врагов «Кадр» показывает табличкой. Брифинги 01–04 открываются как титры фильма. Управление у вас не забирается: короткий стоп-кадр бывает только без опасности рядом. Полный показ — до первой победы, на повторах всё короче. Настройка «Кино: полное / тихое / выкл» — во вкладке «Экран». «Тихое» — без замедления и вспышек; при выключенных эффектах нет и световых приёмов. Бой при этом не меняется.</dd><dt>1.4.5 α</dt><dd>«Верстак» — режим разработчика (открывается только с ?dev в адресе). В открытом мире разработчика теперь открыто всё: ворота Нулевой точки к боссу 50 без «Мига», арсенал без медали 14, а сторожевик «Изморозь» снова стоит на своём месте на границе II–III. В сетке выбора миссий появилась плитка сторожевика, а плитка 50 больше не запускает пустую миссию — оба идут через песочницу, своей настоящей дорогой и без единой записи в настоящую игру. Две старые панели заменила одна — на семь вкладок: «Прыжок» (все миссии плитками по секторам, «войти сразу», места, ближайший журнал или тайник, назад, закладки, координаты, Alt+клик по карте), «Корабль» (бессмертие в три ступени — выкл, держать 1 HP, полное; энергия, рывок, с одного попадания, сквозь скалы, корпуса), «Бой» (инструменты миссии, босса 50 — стадии, сегмент, сбой, атаки по имени, финал — и сторожевика — акты, задачи, существо, свет и холод, пугалки; призыв врагов, скорость времени, пауза и шаг кадра), «Мир», «Прогресс» («пройдено до N», флаги сюжета, снимки F5/F9, копия своего прогресса), «Обучение» (каждый урок: показать, сбросить и «почему не начинается») и «Отладка» (сид боя, журнал событий, ошибки, сторож сохранения, отчёт одной кнопкой). Состояние видно в дев-полосе чипами. И для всех: взрывы и отрисовка экрана, как и звук в 1.4.1, больше не сдвигают случайности боя — они не зависят от частоты кадров.</dd><dt>1.4.2 α</dt><dd>Исправление «Пульта». В настройках осталась одна кнопка «Готово» — внизу, как раньше: на телефоне она всегда на экране, на компьютере рядом с ней подсказка ESC. Верхняя дублировала её и ушла. На телефоне вкладки больше не нужно листать вбок: все пять видны сразу плиткой со значками (три сверху, две снизу), в альбомной — одной строкой. Шапка на телефоне больше не залипает, под настройки остаётся больше места.</dd><dt>1.4.1 α</dt><dd>«Пульт». Настройки разложены по пяти вкладкам — «Звук», «Управление», «Экран», «Доступность», «Игра» — с закреплённой шапкой и кнопкой «ГОТОВО» наверху, на телефоне больше не нужно листать два экрана. Под каждой строкой — одна фраза о том, что она меняет в игре. На компьютере убраны «Масштаб», «Качество» и «Кадры»: там они ничего не делали (это настройки телефона). «Тряска» и ползунки громкости приглушаются и подписаны, когда от них ничего не зависит. Прицел на компьютере — «МЫШЬ / АВТО» с подсказкой про клавишу T; появилась справка «Клавиши», которая не пропадает после обучения; «Без переворота управления» и «Без стирания интерфейса» переехали в «Доступность» и наконец объяснены. Новая кнопка «Вернуть стандартные» — прогресс, скины и обучение она не трогает. Звуки у новых игроков теперь включены (70 %), выбор тех, кто уже играет, сохранён. Пауза показывает сводку и на компьютере: в секторе — сектор, миссии, лом, уровень пилота и текущую цель с расстоянием; в миссии — время, уровень, убитых и условие мастерства с текущим статусом. В паузе — быстрые «Музыка» и «Звуки»; на телефоне в альбомной сводка слева, кнопки справа — без прокрутки. Исправлено: звуки больше не влияют на ход боя — у шума и нот теперь свой генератор случайностей, со звуком и без бой идёт одинаково.</dd><dt>1.4.0 α</dt><dd>«Живые корпуса». Все 16 корпусов, найденных по сюжету, по-прежнему копии VØID-013 по силуэту, но теперь каждый ведёт себя по-своему: свой покой, двигатель, след в полёте, импульс и — главное — свой рывок из трёх долей: толчок, превращение в полёте и метка на пройденном пути. Архивный оставляет стопку карточек-копий и «ЗАПИСАНО»; Наст — ледяную полосу, которая трескается; Изморозь — ледяные статуи; Нерождённый выпускает ядро вперёд, и оболочка тянется следом; Глиф пишет на пути фразу из пяти букв; Довод таранит щитом-шевроном; Осколок лекала распадается на три части и собирается; Серия 013 чертит размерную линию с длиной рывка; Тишина растворяется до контура; Позывной 013 выписывает путь морзянкой «· · · — — — · · ·»; Несущая становится волной; Ковчег рисует кардиограмму; Рассвет Ковчега — луч рассвета; Опечатка расслаивается на три цветные копии; Линия прилива поднимает волну; Пустой берег рассыпается в песок и оставляет следы. В «Хранилище корпусов» каждая карточка раз в 3 секунды показывает свой рывок. Частицы обычного рывка теперь в цвете следа скина. Это только внешний вид: скорость, урон и рывок не меняются; при «меньше эффектов» следы короче и без частиц.</dd><dt>1.3.5 α</dt><dd>«Один курс». Если проложить на карте курс к той же цели, куда и так ведёт стрелка (например, к следующей миссии), у края экрана рисовались две стрелки и две подписи друг на друге — «КУРС · МИССИЯ 06» и «МИССИЯ 06» сливались в кашу. Теперь одна цель — одна стрелка: курс с карты главнее, повторная стрелка не рисуется (то же для лома, аномалии и подсказок обучения). Подписи разных стрелок, указывающих в одну сторону, встают одна под другой. На телефоне, когда подпись отодвигается от кнопок «ИМП» и «РЫВОК», её тёмная обводка раньше оставалась на старом месте и выглядела чёрной размытой надписью — теперь обводка переезжает вместе с текстом.</dd><dt>1.3.4 α</dt><dd>«Дорога домой». Через секунду после возвращения из миссии 01 загораются счётчик лома и сам склад: «НАГРАДА — НА СКЛАДЕ», дорожка от корабля и кольцо на мастерской, а стрелка у края экрана показывает «СКЛАД» вместо «МИССИЯ 02». Подсказка держится, пока вы не долетите до склада, — радио, баннеры и тосты её больше не гасят, патруль лишь ненадолго её прерывает. Только после визита на склад путь ведёт ко второй миссии. Подсказка про импульс больше не появляется в секторе и у склада: её покажут в бою второй миссии, когда враги рядом. Склад и «Хранилище корпусов» теперь всегда отмечены на карте, даже под туманом войны, и к ним можно прыгнуть, если сектор открыт.</dd><dt>1.3.3 α</dt><dd>«Курс без тупиков». Ворота калибровки теперь стоят, пока вы не пройдёте их рывком: пролёт без рывка — просто «ещё раз», ворота можно проходить с любой стороны, и призрак показывает рывок с вашей стороны. Радио, бой, тосты больше не стирают трассу — на это время прячется только подпись. Улетели далеко — трасса переезжает к вам, а пройденные кольца засчитаны; ушли в миссию — после неё ворота вернутся; перезагрузили игру — кольца не сбрасываются. Подсказки «лом» и дорожка к складу появляются сразу после возвращения из миссии 01 («НАГРАДА — НА СКЛАДЕ»), а не по дороге ко второй миссии; проигнорировали дорожку — она больше не вернётся. У миссии 02 карта больше ничего не предлагает и никуда не зовёт прыгать. После победы во второй миссии подсвечивается кнопка карты, а при первом открытии карты на 5 секунд появляется подпись «НАЖМИ НА ТОЧКУ — ПРЫЖОК»: все точки прыжка пульсируют одинаково, ни одна не выбрана за вас.</dd><dt>1.3.2 α</dt><dd>«Проверка». Сектор I и обучение прошли 5000 автоматических полётов — 2500 на компьютере и 2500 на телефонах и планшетах, на 32 размерах экрана, с поиском ошибок, наложений и съехавшего текста. Исправлено: на телефоне в альбомной ориентации и на планшетах карточка объекта («Мастерская», «Миссия») закрывала кнопки «ИМП» и «ДЕЙСТВИЕ» — теперь она встаёт в свободное место между стиком и кнопками; всплывающий «Допуск пилота» налезал на радио, тосты, карточку объекта, подсказки обучения и даже на корабль — теперь он ищет свободное место, на компьютере уходит на правую сторону (при нужде — под мини-карту), если слева корабль, а если места нет — ждёт; на узких телефонах стик и его подсказка «ДВИЖЕНИЕ» заходили на кнопки «КАРТА» и «ИМП» и могли уехать за край экрана; подсказка обучения могла лечь на кнопку, если все обычные места заняты, — теперь ищет ближайшее свободное; в книжной ориентации карточка объекта уходит под тост или радио, а не под них; подписи стрелок у края экрана получили тёмную обводку и читаются поверх подписей мира; в «Хранилище корпусов» длинные кнопки «НАЙТИ · …» переносятся на новую строку и не вылезают за край экрана, а сам экран больше не прокручивается вбок. Музыка меню: игра сама «кликает» в свободную точку экрана и пробует включить звук раз в полторы секунды; браузеры такой клик из кода не засчитывают, поэтому если звук заблокирован, он включится с первого настоящего касания.</dd><dt>1.3.1 α</dt><dd>Чище и честнее. Внизу главного меню вместо плашек «Миссии» и «Пилот» — версия игры, пометка, что это альфа, и коротко о последнем обновлении; всплывающее «Что нового» в левом верхнем углу убрано. «Допуск пилота» в паузе теперь свёрнут и исчезает, когда освоены все восемь навыков. Прозрачность кнопок на телефоне переделана: настройка действует на всю кнопку — с обводкой и свечением, в том числе на готовый импульс и кнопку действия, а «Сильная» стала по-настоящему сильной. У стика — своя настройка прозрачности со своим значком: «Сильная» делает его почти невидимым (прозрачность 95%). Музыка меню пробует включиться сама при загрузке и потом раз в полторы секунды; если браузер не разрешает звук до первого касания, внизу меню тихо мигает подсказка, и музыка включается с первого касания или нажатия в любом месте.</dd><dt>1.2.9 α</dt><dd>Баланс середины кампании. В миссиях 15–24 (сектора «Ржавые хроники», «Чужие колыбели» и первые узлы «Кладбища флота») прочность всех врагов, включая боссов секторов и их части, умножена на 1,5, урон их выстрелов и таранов — тоже на 1,5. Скорость полёта врагов и темп их атак не менялись. Остальные миссии, бесконечный режим и открытый космос сектора — без изменений.</dd><dt>1.2.8 α</dt><dd>«Допуск пилота». Обучение стало практикой: сразу после пробуждения — голографическая трасса «Калибровка»: три кольца, чтобы почувствовать руль, и луч между пилонами, который проходится только рывком; призрак корабля сам показывает манёвр, промах подсвечивается красным. Освоенные навыки собираются в «Допуск пилота» — восемь значков всплывают при каждом новом навыке, а в паузе карточка показывает управление именно для вашего устройства: клавиши, кнопки телефона или геймпада. Новые живые показы: волна импульса и его радиус, призрак рывка в сторону от выстрела, лом, текущий к складу, путь к точке прыжка на карте; отдельный момент «Импульс готов», когда накопитель впервые полон. Пропуск «✕» навык не засчитывает. Музыка меню включается через полсекунды после загрузки, а если браузер требует касания — с первого же касания в любом месте, без задержки на загрузку трека. В настройках появилась громкость звуков. В меню на телефоне с нижним вырезом панель кнопок больше не наезжает на «Миссии / Пилот».</dd><dt>1.2.7 α</dt><dd>«Первый вылет». Обучение встроено в полёт по секторам I–II: двенадцать коротких уроков появляются, когда нужный навык впервые пригодится, — движение, лом с собой и на складе, путь к мастерской, действие у объекта, огонь, рывок, импульс, ячейки в кольцо маяка, ремонт линии ретранслятора, карта, прыжок и патруль. Никаких окон с текстом: кольцо вокруг настоящей кнопки, клавиша-подсказка у корабля (на ПК — клавиши, на телефоне — кнопки и жесты, на геймпаде — его кнопки), стрелка к цели, прожектор на точке прыжка. Каждый урок показывается один раз и закрывается действием; кто уже умеет — его не увидит. В бою мирные подсказки молчат, одновременно — не больше одной. Каждую можно смахнуть «✕», в настройках — выключить обучение или пройти заново. Пилоты со старым сохранением обучения не увидят. На карте отказ в прыжке теперь крупная полупрозрачная красная надпись по центру — «Во время патруля перемещение недоступно», «Рядом враги», «Идёт аномалия», — а кольца точек прыжка краснеют заранее. Сами правила прыжка, бои и экономика не менялись.</dd><dt>1.2.6 α</dt><dd>«Голоса Пустоты». Записанная музыка в меню («Меню»), во всех миссиях с 1-й по 10-ю («Войд-10») и в схватках с боссами: при появлении Стража в 6-й миссии трек за 2–2,5 с перетекает в «Страж-0», при появлении Глушителя в 10-й — в «Страж-10»; после победы боевая тема звучит ещё 3 с и уходит вместе с миссией. Все переходы — равномощные кривые без провалов громкости, длина 2–4 с; меню и миссии продолжаются с того же места, если вернуться быстро. Вступления звучат один раз, дальше — бесшовные петли 77–112 с. Треки выровнены по громкости и сжаты в 6 МБ. Пауза плавно (≈ 3 с) опускает всю музыку на 90 %, а после паузы она возвращается быстрее (≈ 1 с). Звук убийства и сигналы миссии подстроены под тональность звучащего трека.</dd><dt>1.2.5 α</dt><dd>«Пустота-12». Первая записанная музыка в игре: тёмный эмбиент в фа миноре, 60 ударов в минуту, звучит в открытом мире секторов I и II. Петля 160 с без шва (стык сведён заранее), вступление — один раз за сессию; на границе секторов музыка не прерывается — меняется только окраска: Пояс Стража темнее и тяжелее, Дрейф маяка светлее. Процедурные слои перестроены в фа минор и идут в долю с треком; в бою, у колодца и на паузе музыка тише и глуше, взрывы на миг её прижимают, у Разлома она «плывёт». Вернулись в сектор быстрее чем через 90 с — музыка продолжается с того же места. Музыка: «Пустота-12», сделано в Suno.</dd><dt>1.2.4 α</dt><dd>«Широкий кадр». Интерфейс масштабируется одним числом вместе с полем боя: на 1440p — ×1,35, на 4K — ×2, без ступенек; растут и стрелки у края, и мини-карта, и подписи большой карты. На сверхшироких мониторах (шире 21:9) интерфейс и меню собраны в центральной сцене 21:9, арена миссии — тоже 21:9, по краям приглушённый фон. В «Экране» — «Интерфейс: 90% / авто / 110% / 125%». Переключатели доезжают до края и едут с лёгкой пружиной; стрелки ← → на клавиатуре. Журналы, фрагменты памяти и радиоперехваты закрываются нажатием (на телефоне — и свайпом), наведение курсора держит сообщение; в бою с прицелом мышью — только крестиком. Планшеты до 1200 px — планшетная раскладка с крупными кнопками; на телефоне подпись стрелки не ложится на кнопки, подписи мира не обрезаются краем.</dd><dt>1.2.3 α</dt><dd>Исправлено сохранение: если облако отвечает медленно, новая пустая игра больше не перезаписывает облачный прогресс — он загружается при выходе в меню; лучшая облачная копия хранится в резерве (Настройки → «Вернуть сохранение»). «Без позывного». Курс тарана вместо красного прямоугольника: два прозрачных рельса сужаются к точке остановки, внутри бегут шевроны и заполняется шкала замаха; за долю секунды до рывка курс фиксируется и вспыхивает — длина равна настоящему пути вместе с заносом. Так же выглядят рывки Стража-0 и Дефекта. Закрытая миссия — гравитационный колодец: в кольцо можно войти, но чем ближе к центру, тем сильнее тянет назад; до маяка не добраться, а вблизи видно, какую миссию пройти сначала. Редкое событие в открытом мире: на карте вдали — знак патруля, который идёт за оранжевым «?». Если успеть — увидите, за кем гонится патруль.</dd><dt>1.2.2 α</dt><dd>«Поверка». Сторожевик перестроен палуба за палубой: узкий шлюзовой коридор со скафандрами на стойках; криопалуба — лабиринт рядов капсул; та же криопалуба ещё раз — тёмная, тихая, все капсулы открыты; машинное — кольцо вокруг кожуха реактора с тупиковыми нишами генераторов; реактор — тесный коридор, огромный зал и бег обратно. Убраны надписи «кровью» и вспышка «это не твой голос»: вместо них говорит сам корабль — ровная автоматика с будничными сводками, которые не сходятся, судовая роль с процарапанной тринадцатой строкой, счёт дней на стене, баррикада из ящиков. Неизвестные в скафандрах появляются на долю секунды со сбоем картинки; резкие мерцания света; скафандры поворачиваются, пока вы не смотрите; музыкальная шкатулка среди капсул; ваш рывок иногда звучит ещё раз издалека. На двух последних палубах — слабые помехи края карты.</dd><dt>1.2.1 α</dt><dd>«Сторожевик». Пост «Изморозь» — теперь огромный разбитый сторожевой корабль, вмёрзший поперёк прохода II–III (выше узла 10, вдали от Бездны), и он есть на карте. Вход — через шлюз, выход — сразу в сектор III, без экрана итогов. Внутри: палубы с переборками, которые отбрасывают тень от фонаря; фонарь сбоит; красные аварийные маячки; искры с оборванных кабелей; надписи на стенах, следы когтей, капсулы криосна, замёрзшие корабли VØID-013. Наблюдатель — тень с длинными конечностями: стоит, пока вы на него смотрите. Тишина перед ударом, силуэты на краю луча, шёпот, дыхание и шаги в наушниках. В финале — разгерметизация: ледяной фронт гонится за вами, сходится аварийная переборка, воет сирена. Жанровая плашка на брифинге убрана.</dd><dt>1.2.0 α</dt><dd>«Без права на ремонт». В миссиях корпус не чинится ничем: вход — с полной прочностью, ремкомплекты не падают, модули и находки дают щит, темп или оглушение вместо ремонта. Режим «Эхо» убран отовсюду, медалей у миссии три. Сектор I: буи-прожекторы, отражающие плиты, неразрушимые глыбы, течение с цепными минами, тёмные облака с ракетами. Страж миссии 6 сражается в три новые фазы (связи пилонов, кольцо глыб, спираль мин во тьме), а атакует и держит урон на четверть сильнее. Миссии 8–10 усилены: враги быстрее, бьют и держат урон на четверть сильнее, награда выше. После миссии 10 проход в сектор III скован льдом — сначала нужно пройти пост «Изморозь»: темнота, лёд, обморожение и Наблюдатель.</dd><dt>1.1.1 α</dt><dd>«Стекло». Новый облик меню и окон: экраны плотные — игра не просвечивает сквозь текст; единые кнопки, вкладки, переключатели и карточки; текст не мельче 12 пикселей; брифинг в две колонки; пауза разделена на «продолжить» и «выйти», а выход из миссии спрашивает подтверждение; уведомления сверху по центру с полоской времени; стрелки ходят по кнопкам меню; при «ЭФФЕКТЫ: МЕНЬШЕ» оболочка не анимируется.</dd><dt>1.1.0 α</dt><dd>«Чистый интерфейс». Из игры убран текстовый шум: точные секунды, проценты и множители там, где за ними нет решения; служебные строки; названия механик в подсказках. Полосы и значки вместо цифр, у корпуса число осталось. Подсказки всех 50 миссий и описания угроз переписаны коротко. Меню разработчика скрыто. Справочник — семь разделов. Настройки — одной кнопкой и на ПК.</dd><dt>1.0.0 α</dt><dd>«Туман войны». Миссии открываются по порядку: следующая — только после предыдущей. Сектор закрыт туманом войны, пока не пройдена последняя миссия предыдущего сектора: на карте и в мире он скрыт, стена тумана не пускает за кромку (и облететь её сверху нельзя), прыжок туда недоступен. Сектор II, как и раньше, — после миссии 06 и двух замков ворот, сектор XII — после «Мига» (49). Сохранение больше не теряется после обновлений: прогресс копируется в облако артефакта (личная папка игрока) и возвращается при следующем запуске, а если браузер не даёт писать — держится в памяти вкладки. Коды сохранения: вставка прощает кавычки, переносы, невидимые пробелы и текст вокруг кода; «Копировать» работает и во встроенном окне; экран кода и меню показывают, где хранится прогресс. Карта: всё скрытое — неисследованное, закрытые сектора и Разлом между секторами — выглядит как та же чёрная пустота со звёздами, что и вокруг мира; между открытым и скрытым — широкие плавные градиенты, у закрытого сектора мгла полная уже на его границе. В мире кромка тумана — такая же плавная чёрная мгла, корабль и выстрелы видны поверх неё.</dd><dt>0.9.9 α</dt><dd>Сектор XII «Нулевой миг» и босс 50 — VØID-000 «Нулевой», первая копия. Он не ждёт в комнате: по кнопке «Войти в комнату» две секунды ничего не происходит, потом у сектора вырастают стены, «комната» расширяется от узла до стен, игрока отбрасывает, карта глохнет в помехах, телепорт закрывается, на экране искажённое «ТОЧКА НЕВОЗВРАТА ОТКРЫТА». После выбора стартового комплекта он выходит из разлома. Его сигнатура — зеркало: он повторяет вас. Пространство сжимается сорока фигурами (круг, эллипс, кольцо, капсула, полоса, серп, две линзы, треугольник, шестиугольник, звезда, крест, спираль, осколки — телеграф 1,5 с, морф 1 с, снаружи через 1,2 с стирание и незаряжающийся рывок). Четыре стадии. «Зеркало»: он стоит в точке отражения через центр фигуры, каждая ваша пуля возвращается эхом, спереди он отражает всё; рывок рвёт зеркало на 1,4 с — шов открыт; на половине сегмента появляются два осевых отражения, эхо втрое; раз в 6,5 с — бросок сквозь центр. «Отсчёт»: он у стола под двумя вращающимися лучами, счёт 12→0; таран рывком или импульс в упор — +5 с и 2,2 с открыт, лучи ускоряются; ноль — фигура ×0,65, импульс, −10% корпуса и ещё луч (до четырёх). «Негатив»: внутри фигуры — стирание, фигура охотится за вами (150 px/с, быстрее с каждой вылазкой); он внутри неуязвим и бьёт веерами; подойдите к кромке — он выйдет за вами и 2,8 с будет открыт. «Кнопка»: рывок, веер, луч, импульс циклом, выпад на каждый четвёртый удар сердца, эхо; в такт — двойной урон; помилованные из «Мига» держат линии вокруг кнопки и стреляют; на 20% — гонка к кнопке, его касание — цикл заново с 60%. Корпус-негатив: тёмное тело со светлой кромкой, шов по оси, орбита осколков белеет, когда он открыт, послеобразы за ним. Контрольных точек нет: гибель — цикл заново. У кнопки — выбор: стереть, вспомнить или третий путь (если помилованных не меньше трёх). Три концовки, записи 64–65, мастерство «без единого повтора цикла».</dd><dt>0.9.7 α</dt><dd>Сектор XI «Нулевая точка» наполнен: три миссии, где врагов не придумали заново — их собрали из лучших связок прежних секторов. 47 «Созвездие»: пять погибших пилотов лежат созвездием; прочитать каждого — 3 секунды в кольце, и память отвечает теми, кто их убил: копейщики со стаей, Изморозь с таранами, Смотрители со стрелками, минёры с Охотником, Командир с Тромбами. 48 «Пуск»: стартовый стол с тремя контактами — Связист с расчётом, Гвардия с Лаборантом и Отражением, Певчий с Нерождёнными; когда все подняты — 10 секунд в круге «ПУСК» под последним расчётом, и пуск стирает всё. 49 «Миг»: существует только полоса, которая ползёт, поворачивает и сжимается к точке выхода; снаружи стирание и незаряжающийся рывок, зато враги вязнут; четыре засечки от Охотников до Стёртого пилота с Корректором, а у точки выхода за вас отвечает память — двое и те, кого вы пощадили. Миссия 50 вынесена в отдельный сектор XII за воротами Нулевой точки: ворота открывает победа в «Миге», комната подготовлена, босс будет описан отдельно. У сектора свой свет (созвездие, чертёж, негатив), свой звук (хор, метроном, тиканье) и свои мастерства.</dd><dt>0.9.6 α</dt><dd>Доводка «до идеала». Сердце стало проходимым: кольцевая волна без проходов шла на каждый удар, а рывок перезаряжается дольше такта — теперь у каждой волны есть проход: в первой фазе вдоль сосудов, во второй он плывёт, в третьей безопасно там, где совпадают проходы двух колец; фибрилляция идёт без обычных ударов, проход — по оранжевой стрелке. Часы Сердца идут по реальному времени и на телефоне с 30 кадрами — раньше оно билось там вдвое чаще. Кульминация «Остановки»: три круга ключей — по порядку, наоборот и плывущие, — а последний запуск разрывает ритм за 4 секунды при любом оружии. Тревога больше не раскручивается в спираль: облава — три Фагоцита раз в 30 секунд, каждый сбитый снимает 4, в затишье шкала быстро спадает, а переходы на 30 и 60 срабатывают всегда. Иммунный страж после удара щитом на 1,2 секунды опускает мембрану (✦), миссия 41 стала вдвое короче, а последние враги больше не прячутся: шлюзы на финальной зачистке открываются насовсем, а вошедший в арену враг уже не уйдёт за её край. Корректор в миссии 44 доводит ремонт: обход строк ведёт его к цели, а не к вам. Звук сведён по замеру громкости: удар сердца тише и теперь слышен в динамике телефона, «чирк» Ластика и слёзы Смотрителя тише. Виньетка сектора берётся из кэша, а ядро ганглия снова рисуется векторами — миссия 41 на слабом телефоне на четверть легче. Табличка новой встречи не ложится на баннер, баннер в альбомной — ниже полосы босса.</dd><dt>0.9.5 α</dt><dd>«Сердце и Берег 2.0» — мега-улучшение секторов IX и X. Единый язык угроз: у каждой атаки есть телеграф не короче 0,45 секунды — линии утолщаются, зоны заливаются от центра, рывки показывают стрелкой, уязвимое окно — белым ромбом ✦. Восемь новых враждебных врагов: Лейкоциты-охотники стаей чертят треугольник, Спазм сжимает ленты кровотока, Тельца-бомбы, Иммунный страж с мембраной, Клякса, Переписчик со строками снарядов, Отливник с языком пустоты и Стёртый пилот, который летает по вашим правилам. Все четырнадцать старых врагов получили вторую атаку и окно уязвимости. У каждой миссии 39–46 своя арена: воронка лент, отсеки, кольцо вокруг ганглия, косы стирания, страница со строками-стенами, диагональный берег; укрытия, которые рушатся от огня; событие арены на третьей волне, передышка с сундуком, кульминация с элитой и тайник. Сердце 2.0: бич аорты, кровяной дождь в такт, толчок, лента тактов, комбо, стреляющие клапаны, фибрилляция, затопление камеры и два запуска. Берег 2.0: Смотритель горизонта с глазами-мишенями, слезами стирания, вздохом и словами-снарядами; маяки стали слабыми, но злыми — лучи-прожекторы, самонаводящиеся огни, перезапись соседа; тени прошлых боссов — мини-боссы, а в тишине Смотритель спускается и прочёсывает арену руками. Открытый мир: патрули Кровотока и Правки, Иммунный ответ, Потерянные, события Аритмия, Тромбоз, Отлив, Опечатка в мире и Последний сигнал, безопасные зоны у станций, фон из сосудов и «недорисованный» берег. Последний шанс, очередь надписей, стрелки угроз за краем экрана, табличка первой встречи с замедлением, настройка «Меньше эффектов». Двадцать исправлений. После сборки — три круга самокритики: враги обходят укрытия и строки-стены, сквозь стену не проскочить ни рывком, ни отбросом, на любой сложности одна элита кульминации, удар обычного врага — не больше 16 единиц, буквы «стёртой подписи» читаются, у Смотрителя настоящие руки, тени прошлых боссов обрели тело, фон мира стал бесшовным, а на телефоне подсказки боя больше не лезут под пальцы.</dd><dt>0.9 α</dt><dd>«Сердце Ковчега и Стёртые берега». Сектора IX и X больше не в разработке. Сектор IX: ленты кровотока сносят корабль и удлиняют рывок по течению, шкала Тревоги зовёт облаву Фагоцитов, шлюзы делят арену и держат снаряды, в капсулах спят пассажиры — будите их, пока Смотрители не разбудили силой. Сектор X: стирание наползает с краёв, пропадают шкалы интерфейса, во второй половине приходят воспоминания прошлых секторов, Свидетели несут двенадцать обрывков памяти, по арене проходит Прилив, а тени прошлых боссов возвращаются слабее, чем были. Пятнадцать новых врагов — от Тромба и Смотрителя до Опечатки, Корректора, Эха-призрака и Безымянного. Босс «Сердце» (42): бой в ритме удара — точные попадания в такт, аритмия, двойные удары с проходами и ручной запуск четырьмя ключами. Босс «Берег» (46): горизонт пустоты опускается, держат его маяки памяти, а в конце остаётся только ваше эхо. У обоих по скрытому третьему исходу. Стоп-кадр на точных ударах, мягкая тряска (настраивается), таблички первой встречи, своя музыка секторов и боёв. Мастерство 39–46, пять скинов, четыре модуля, шесть контрактов.</dd><dt>0.8.5 α</dt><dd>«Лекало и Колодец». Комнаты боссов 31 и 38 больше не в доработке — арка «Предел и Исток» закрыта. Цех №0: «Лекало» — бой в четыре смены (приёмка, сборка, ОТК, списание) на трёх конвейерах над печью утилизации; Серийники стреляют шаблоном вашего оружия, пульты смены останавливают линию, хват тащит к печи, а в темноте рама бьёт добычей с арены. Колодец Истока: «Первый сигнал» — два кольца излучателей, глотающих снаряды, сонар с проходами, Паломники, которых надо будить, запись и повтор вашего полёта, петля на трёх якорях и фаза тишины. Два финальных выбора меняют сектора VII–VIII: свет, бюро, Паломников, музыку; у концовки VIII есть третий, скрытый вариант. Новые враги: Заготовка, Серийник, Нота, Отзвук-0, Якорь петли. Музыка боёв растёт из темы сектора по фазам. Мастерство 31 и 38, пять скинов, модуль «Позывной», три контракта. Темнота секторов VII–VIII на ПК рисуется в разы быстрее, а оба боя переживают смену размера окна посреди схватки.</dd><dt>0.8.0 α</dt><dd>«Предел и Исток». Сектор VII «Предел» (миссии 28–30, комната босса 31 — в доработке): брошенные цеха бюро, где собирали копии VØID. Новые враги: Лаборант (чинит раненых лучом), Брак (каждые 3 с меняет поведение), Конвейерный щит (ловит обычные снаряды на рельсе), Печать (штамп с взрывом через 4 с — сбросьте рывком), Инспектор (конус скана: 0,8 с в нём — враги бьют на 20% сильнее), Утилизатор (собирает лом и опыт павших и стреляет ими в вас). Сектор VIII «Исток» (миссии 32–37, комната босса 38 — в доработке): Отзвук (возвращает ваши выстрелы любым оружием через секунду), Петля (возвращается через 5 с — добейте за 2 с), Изнанка (редкая, волна зеркалит управление на 2 с), Паломники (мирные копии — не стреляйте). В открытом мире — отключения света по циклу сектора, утечки охлаждения (снаряды втрое медленнее), пульты тревоги (срабатывают через 10 с, перезарядка 20–30 мин), стенд испытаний с мишенью и цифрами урона (автоприцел бьёт по ней), патрули «Утилизация», «Ревизия», «Паломники» и ещё четыре, 12 новых контрактов, «Голоса Истока». Своя музыка секторов с плавной сменой: механический ритм бюро и хор Истока, тёмные варианты при отключении света. В настройках — «мягкая Изнанка».</dd><dt>0.7.5 α</dt><dd>«Все цели видны». Автоприцел (основной режим на телефоне) теперь бьёт Мембрану — в ближайшую точку стены, 35% урона обычным огнём, заряд ×1,5 — и Устье (600 прочности, обычный огонь ранит); Поглотитель выбирается последним и «устаёт» после двух веёров; страховка: если 3 с нет цели при живых врагах, прицел берёт ближайшего. Ренегат с борта получает 45% и подсказывает зайти с носа. <b>Кормилица 2.0</b>: у утроб полоски прочности (обычный огонь рвёт, заряд ×4, «Разрыв» ×2, импульс 40%), тело ранимо всегда (−20% за каждую целую пуповину); кормление нитью — порвите её и Кормилица откроется; плач и молоко (+10% прочности, темп +20%); пуповина может отрасти; во 2-й фазе тело дрейфует, край вспыхивает перед сжатием, на вдохе урон ×1,5, Зародыш рядом с ней вызывает вдох, со стены падают коконы; в 3-й — лепестки, отражающие снаряды, кольца с узким окном и сплошные (рывок), последняя колыбельная на 15%. <b>«Последний довод» 2.0</b>: 12 500 прочности; автоприцел выбивает секции, каждая снимает с рубки 15% брони; полоски секций, видимый ремонт (стреляйте в искры); рубка без батарей отвечает очередями; два корпуса-укрытия; звено на выходе; прожектор и прицельный залп; таран; абордажный шлюз; перекличка мёртвого флота; заряд оглушает рубку; Тео, эхо Стража и доклад «мы живы» помогают; третий удар залпа — полоса. Общее: метка 10% на полосе босса, подсказки в строке босса, финальные доки выше кнопок, предупреждение за 5 с, при повторе — «ВЫ УЖЕ ВЫБРАЛИ».</dd><dt>0.7.4 α</dt><dd>«Колыбели и флот». Сектор V «Чужие колыбели» (миссии 19–22): инкубация — часть волн приходит коконами; Нерождённые, Пестуны, Мембраны, Пуповины, Певчие, Зародыши стража и Последний из вида; события «Роды» и «Чужая гравитация»; босс «Кормилица» с выбором «прервать или выносить». Сектор VI «Кладбище флота» (23–27): милость Стражей глушит двигатели, дрейфующие корпуса с батареями, залпы мёртвого флота; Автопилоты, Абордажники, Брандеры, Связисты, Крейсер-перебежчик, Курсанты и Скелет линкора; события «Поднять флаг», «Чёрный ящик», «Битва 127 лет назад», «Последний приказ»; босс «Последний довод» с выбором «по рубке или по двигателям». В открытом мире — восемь новых патрулей, журналы, пять глифов, «Выбор сохранения», радиоголоса КОЛЫБЕЛЬ и ФЛОТ, скины «Нерождённый», «Глиф», «Довод». Сила пилота больше не зависит от того, где корабль: урон и прочность — по максимальному открытому сектору (в альфе — уровень сектора IV). Патрули секторов III–IV снова появляются. На телефоне перехваты и журналы вдвое компактнее и стоят слева сверху под корпусом.</dd><dt>0.7.0 α</dt><dd>«Арсенал». После комнаты босса 14 в Холодном архиве открывается Арсенал «Иней»: прокачка силы и темпа орудия по три ступени и второе оружие «Разрыв» — снаряд по области со своими ветками мощности и радиуса. Новый доход во второй половине игры: трофеи боссов, тройные награды с 15-й миссии, повторы в секторах III+ дают 35 % без затухания.</dd><dt>0.6.2 α</dt><dd>«Полный экран». Настройка ПОЛНЫЙ ЭКРАН: выкл / при полёте / всегда — на ПК и на телефоне. Кнопка в меню и на паузе, F11 и Alt+Enter. Выход из полного экрана посреди боя — пауза и возврат одним нажатием. Там, где браузер не пускает игру во весь экран (iPhone, встроенные браузеры), кнопка показывает один понятный шаг вместо молчания.</dd><dt>0.6.1 α</dt><dd>Карта на телефоне открывается вокруг корабля и близко: 2–4 точки на экран, пинч приближает ещё, кнопка «ко мне» возвращает масштаб. Стрелки врагов за кадром остались только на лёгкой сложности.</dd><dt>0.6.0 α</dt><dd>«Мобильная». Та же игра, но на телефоне теперь удобно. Картинка крупнее на треть, арена миссии одинакова в любой ориентации (в портрете она больше не коридор), камера ведёт корабль, стрелки на краю показывают врагов и цели за кадром. Новое управление: плавающий стик с мёртвой зоной, дуга кнопок с кольцами перезарядки, рывок свайпом, вибрация, защита от случайного нажатия на экранах поверх боя, отсчёт после паузы. HUD на телефоне сокращён до главного, экраны получили крупные кнопки и закреплённые действия внизу, появился экран настроек (масштаб, размер и прозрачность кнопок, режим левши, игра одной рукой, качество, 30 кадров, крупный текст). Экран не гаснет в бою, системная кнопка «назад» работает как Esc, прогресс сохраняется при сворачивании, есть иконка для экрана «Домой». На компьютере всё как было.</dd><dt>0.5.10 α</dt><dd>«Чистка». Итоги большого прогона на баги и уязвимости (более 1 500 проверок). Код сохранения и данные в хранилище теперь проверяются по схеме: чужой код не может подсунуть в игру разметку или сломать загрузку испорченным полем. Если браузер не даёт записать сохранение (переполнено или запрещено хранилище), игра предупреждает, а не молчит. Страница получила метку viewport — на телефоне интерфейс больше не уменьшается в два раза; карта на узких экранах больше не уезжает за край. Панель разработчика не предлагает врагов, которые без сценария рождаются «сломанными». Убраны функции и константы без применения. Защищены вызовы экранов вне открытого сектора.</dd><dt>0.5.9 α</dt><dd>«Альфа-фиксы». Игра теперь официально в альфа-версии. Холод сектора III вдвое прозрачнее (иней, шельфы, снежная буря). Патрули секторов III–IV: прочность ниже в 3 раза, зон вдвое меньше, в патруле 2–4 корабля, без подкреплений и возвращаются реже. Бездна «Бесконечность» снова притягивает корабль и пускает внутрь; рядом с ней не появляются патрули, стаи и бури. Игра в альфа-версии: все уровни временно открыты для теста — прыжок с карты к любому узлу.</dd><dt>0.5.8 α</dt><dd>«Холод и ржавчина». Открытый мир секторов III и IV: восемь патрулей сильнее прежних (масштаб сектора, вожак с аффиксами, подкрепление, награда ×1,5/×2); ледяные шельфы со скольжением и обледенением; ржавые поля с мировым износом и дорогим ломом; снежный фронт и ржавый дождь, которые ходят по карте; шесть дрейфующих записей Архива; раскопки у обломка Инвентаризатора и скин «Архивный»; три радиомаяка Архива; Странствующий Архиватор с засадами; редкие гражданские буксиры (сопровождение или грабёж); стаи ржавых копий после миссии 18; аномалия «Холодное ядро» и скин «Наст»; спецзадание «Конвейер» у депо; девять контрактов секторов III–IV.</dd><dt>0.5.7 α</dt><dd>«Без ремонта». Миссии 11–18: прочность корабля в бою не восстанавливается ни ремкомплектами, ни перком «Полевой ремонт», ни доком «Обода» (док теперь снимает износ и даёт 6 с неуязвимости); взамен корабль входит в каждую миссию сектора с полной прочностью. Враги сектора III быстрее ещё на 5%, сектора IV — на 10%; все враги секторов III–IV, включая боссов и копии, атакуют на 15% чаще. У «Инвентаризатора» и «Обода» каждые 14 с приходит звено охраны из 2–3 атакующих врагов (награда за них ×0,5). Средняя сложность усиливает эти прибавки на 15%, хардкор — на 50%; сводка на брифинге считает цифры из формулы. По итогам плейтеста миссий 11–18.</dd><dt>0.5.6 α</dt><dd>«Картотека и Обод». Боссы секторов III и IV: «Инвентаризатор» (миссия 14) — корабль-картотека, который описывает ваши системы и заставляет выбирать, что спасти, выпускает записи прежних циклов и замораживает арену; «Обод» (миссия 18) — ремонтная станция-кольцо вокруг корабля с доками ремонта и утилизации, спицами ржавчины и сжимающимся кольцом. У обоих финальный выбор с последствиями для мира, радио и хроники. По итогам плейтеста: ледяные копии Архиватора теперь летят по вашему маршруту и стреляют вашим орудием; враги сектора III быстрее ещё на 15%, сектора IV — на 20% (в хардкоре вдвое больше), волны приходят чаще; в последних волнах вдвое меньше бронированных врагов и больше динамичных, в конце обычной миссии — стая; затянувшаяся концовка снимает броню с «уставших» врагов; на старте миссий 11–18 больше динамичных врагов.</dd><dt>0.5.5 α</dt><dd>«Холод и ржавчина». Сектора III и IV наполнены: четыре новых врага — Изморозь и Архиватор в Холодном архиве, Коррозийник и Ремонтник «Обода» в Ржавых хрониках. Обледенение корабля, ледяные копии вашего маршрута, износ корпуса, ржавые облака, собранные заново враги. Волны 11–18 — новые враги вперемешку с врагами предыдущего сектора; враги сектора III в 2 раза прочнее, на 5% быстрее, с бронёй 10%, сектора IV — ×4, +10%, 19%. Урон корабля там ×1,5 и ×2, награды ×1,5 и ×2. Ледяная гвардия, радио Архива и «Тихой», новые записи в справочнике.</dd><dt>0.5.4 α</dt><dd>Служебное: открытый мир разработчика (песочница) — все узлы открыты, скорость полёта ×0,5–×8, лом по кнопке, автовозврат после миссий. Песочница хранится отдельно и ничего не записывает в настоящую игру.</dd><dt>0.5.3 α</dt><dd>«Разбитые корабли». Все 63 обломка разные: 32 — разбитые корпуса VØID в точных скинах (в секторах I–V — только Базовый, дальше все скины), 31 — чужие корабли одиннадцати классов, по одному на сектор (транспорт, станция, архивная баржа, тягач, раковина, флагман, чертёж, разобранные Стражи, обслуга Ковчега, стёртые корабли, прототип-кольцо). Пять степеней разрушения: от «подбит» до «стёрт». В журнале — строка корпуса и иконка, на карте — два значка, в Хранилище — счётчик найденных обломков скина.</dd><dt>0.5 α</dt><dd>«Не дайте ему вспомнить». Сюжет: пробуждение перед полётом, 63 разбитых корабля с записями (журналы теперь на обломках), 120 радиоперехватов, 15 фрагментов памяти (каждый приближает Разлом), отступающие враги, которых можно отпустить, сводка цикла, вкладка «Хроника». Сектора III–XI переименованы, Ангар стал Хранилищем корпусов.</dd><dt>0.4.1 α</dt><dd>Новая карта «Туманность»: сектора — цветные облака, мягкий туман войны без клеток, плавные гиперлинии с огоньками, подписи без наложений, уровни детализации, подсказки при наведении, инерция, обзор мира и легенда. Разлом: за пределами секторов можно летать, но пространство искажается всё сильнее, а Неизвестные стреляют из темноты и убивают с одного попадания (рывок спасает).</dd><dt>0.4 α</dt><dd>Масштаб: ещё 40 уровней (всего 50) в 9 новых секторах, которые идут вправо-вверх по карте; мир вырос до 160×80 а.е. Новые уровни пока заготовки — зачистки из существующих врагов с ростом прочности и элиты. Комнаты будущих боссов на уровнях 14, 18, 22, 27, 31, 38, 42, 46, 50 помечены «БОСС · ДОРАБОТКА». Доступ к новым секторам временно открыт, у каждого — маяк сектора для прыжка. За первое прохождение уровня 10 скорость корабля навсегда +15%.</dd><dt>0.3.4 α</dt><dd>Эмбиент вместо мелодий: спокойные приключенческие звуковые пейзажи без ведущей мелодии — меню, Пояс Стража, Дрейф маяка, отдельные умиротворённые пейзажи мастерской и ангара, экран нового цикла. В миссиях — боевой эмбиент (мягкий пульс и томы, у каждой из 10 миссий своя окраска), на боссах — устрашающий: двойной пульс, медь, удары на сменах фаз; во тьме Глушителя остаётся только сердце. При корпусе ниже 30% — сердцебиение и звон поверх. Плавные переходы, короткие звуковые акценты на начале миссии, вспышках маяка, появлении и гибели босса.</dd><dt>0.3.3 α</dt><dd>Новая музыка: 16 процедурных треков с приключенческим настроением — меню, тема каждого из двух секторов, своя боевая тема у каждой из 10 миссий, Бездна и две темы боссов. Треки сменяются плавным переходом, в бою добавляются ударные и бас, при появлении босса — быстрая напряжённая тема, при низком корпусе — тревожные нотки и приглушение. Маленький прицел и захват цели курсором (в том числе боссов).</dd><dt>0.3.2 α</dt><dd>Хардкор: урон по кораблю ×3, враги быстрее в 1,5 раза, маяк хрупче, предупреждения об атаках скрыты, награда ×2. Ручной прицел мышью (T — авто). Значок лома и крупные суммы. Вкладка «Журналы» на карте (J). Перк «Сдвоенный ствол» (1500), «Сканер» дороже (600) и видит журналы. Аномалии сложнее и щедрее. Ионная буря подсвечивает тьму. Исправлено: астероиды перемешивались при смене сложности на брифинге.</dd><dt>0.3.1 α</dt><dd>Лом в секторе появляется один раз: разбитые обломки не возвращаются ни после миссий, ни в новом цикле; осколки роевиков из патрулей лома не дают. Награда за первое прохождение 20 + 12×N (меньше в начале, больше в конце), тайники 80–140. Миссии 7 и 8 плотнее: больше охотников, чаще волны, маяк хрупче. Исправлено: кнопка «Новый цикл» на узле 10 запускала миссию; замки ворот снова появлялись после перезагрузки; потерянный лом пропадал при второй гибели; на телефоне карточка перекрывала кнопку ЗАРЯД, а полоса корпуса — счёт.</dd><dt>0.3 α</dt><dd>Разделение улучшений: 13 постоянных перков мастерской и модули на одну миссию со стартовым комплектом на брифинге. Новая экономика без фарма обломков и патрулей. Три сложности, уровень пилота и покупка скинов, контракты, заряженный выстрел, комбо, Бездна у миссии 10, боссы-эхо в Бесконечности, новый цикл, обнуление прогресса. Миссия 7: зарядка ×2 и новые враги; миссия 8: на 5% больше врагов.</dd><dt>0.2.6 α</dt><dd>«Бесконечность» вдвое проще: предел 35 врагов, ступени с третьей по 15 секунд, мягче рост элиты, прочности и скорости. Миссия 10 проще в 1,5 раза, миссии 7–8 чуть сложнее. Ангар «Зеркало» у миссии 05 с 11 скинами корабля (Базовый + 10 новых силуэтов). Тайники дают 200 лома. Новые звуки выстрела и уничтожения.</dd><dt>0.2.5 α</dt><dd>Режим «Бесконечность»: ступени каждые 10 секунд с удвоением угрозы и разнообразия, предел 70 врагов, элитные отряды, секундомер и таблица рекордов. Классическая экспедиция и старт с акта II убраны: кампания идёт только через открытый сектор. Расстояния в секторе — в астрономических единицах, на карте масштабная линейка. Раздел «Выбор миссий» для разработки.</dd><dt>0.2.0 α</dt><dd>«Открытый сектор»: два сектора между миссиями, узлы с тремя состояниями, ворота с замками, лом, 2 мастерские с 6 постоянными улучшениями, 5 окрасок, 4 тайника, 8 бортжурналов, 3 аномалии, 2 ретранслятора, 11 патрулей, минное поле, тёмная зона, крейсерский режим, карта с быстрыми прыжками, мини-карта, медали миссий, сохранение и код сохранения.</dd><dt>0.1.1 α</dt><dd>Дополнение «Маяк»: акт II, миссии 7–10. Маяк с зарядом и целостностью, кольцо зарядки, доставка ячеек, 8 модулей маяка, группы врагов, ретрансляторы, астероиды, тьма, ионная буря, охлаждение, передача, 4 случайных события, 6 аффиксов элиты, 18 новых угроз, босс Глушитель, 6 новых модулей корабля.</dd>
    <dt>0_2_0</dt><dd>Пересборка в Claude по проектному описанию 0_1_3. Исходный код 0_1_3 не переносился: составы волн, числа баланса, атаки Стража и список модулей заданы заново по принципам описания.</dd>
    <dt>Альфа</dt><dd>Игра в альфа-версии: баланс и содержимое меняются от версии к версии. Пишите, где слишком легко или тяжело.</dd>
    <dt>План</dt><dd>Сектора III–IV спроектированы; V–XI — предварительные.</dd></dl>`;
}
function drawIcons(){
  document.querySelectorAll('canvas[data-icon]').forEach(c=>{
    const k=c.dataset.icon,g=c.getContext('2d');g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,128,128);
    if(!k){g.fillStyle='#2a3a55';g.font='700 40px "JetBrains Mono",monospace';g.textAlign='center';g.fillText('?',64,78);return;}
    const d=EDEF[k];const fake={type:k,seed:1,uid:1,x:0,y:0,vx:1,vy:0,r:d.r,t:1,flash:0,face:0,aim:0,st:'seek',spawnT:0,hp:1,maxHp:1,shieldK:1,rot:.3,phase:1,over:0,arm:0,fuse:0,charging:false,ang:0,att:false,h:0,role:'gun',down:0,ghost:false,buff:1};
    const real=ctx,sp=G.player;ctx=g;G.player=sp||{x:200,y:0};
    try{if(k==='boss'){g.setTransform(.78,0,0,.78,64,64);drawBoss(fake,1);}else{const s=k==='jam'?.8:k==='cruiser'?1.1:Math.min(3,44/(d.r+8));g.setTransform(s,0,0,s,64,64);drawEnemy(fake,1,true);}}
    catch(err){console.error(err);}
    finally{ctx=real;G.player=sp;g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;}
  });
}

// ---------- Ввод ----------
let touchMode=window.matchMedia&&matchMedia('(pointer:coarse)').matches;
// 0.6.0: три оси адаптации — ввод (G.input), форм-фактор (G.ff), качество (G.q). ПК (ff-desk + kbm) не меняется.
const MOBQ=window.matchMedia?matchMedia('(pointer:coarse)'):null;
G.input=touchMode?'touch':'kbm';G.ff='desk';G.q=2;
let inputT=0,mouseAcc=0,synthKey=false;
document.documentElement.lang='ru';document.documentElement.dataset.input=G.input;
function setInput(m){if(G.input===m)return;if(G.input==='touch'&&m!=='touch'&&performance.now()-inputT<500)return;
  G.input=m;touchMode=m==='touch';document.documentElement.dataset.input=m;for(const k in hudCache)delete hudCache[k];
  try{ffUpdate();$('#touch').hidden=!(touchMode&&(G.state==='play'||G.state==='world'));updateCursor();renderSettings();G.cardKey=null;if(typeof layoutTouch==='function')layoutTouch();}catch(e){console.error(e);}}
function ffUpdate(){setTimeout(()=>{try{FS.sync();}catch(e){}},0);const vv=window.visualViewport,w=vv&&vv.width?vv.width:innerWidth,h=vv&&vv.height?vv.height:innerHeight,sm=Math.min(w,h);
  const dev=(MOBQ&&MOBQ.matches)||G.input==='touch';
  const ff=!dev?'desk':sm<600?(h>w?'phone-p':'phone-l'):sm<=1000?'tablet':'desk';
  G.ff=ff;const c=document.documentElement.classList;for(const k of ['desk','phone-p','phone-l','tablet'])c.toggle('ff-'+k,k===ff);
  c.toggle('mob',ff!=='desk');c.toggle('lefty',ff!=='desk'&&SET.hand==='l');}
function isMob(){return G.ff!=='desk';}
function isPortrait(){return G.ff==='phone-p'||(G.ff==='tablet'&&CH>CW);}
// подсказки управления без клавиш на касаниях
function kh(s){if(!touchMode||typeof s!=='string')return s;
  return s.replace(/\s*\[(?:[A-ZЁ]|ESC|ENTER|TAB|F11)\]/g,'').replace(/WASD или стрелки — движение/g,'Стик слева — движение').replace(/ПРОБЕЛ — рывок/g,'Кнопка РЫВОК — рывок').replace(/E или Shift — импульс/g,'Кнопка ИМП — импульс').replace(/Клик по врагу \(или касание\)/g,'Касание врага').replace(/ · J — все журналы/g,' · журналы — на карте').replace(/J — все журналы/g,'журналы — на карте');}
// системная кнопка «назад» = Esc (только на телефоне и планшете)
let histOn=false;
function histArm(){if(histOn||!isMob())return;try{history.pushState({v:1},'');histOn=true;}catch(e){}}
function escAction(){synthKey=true;try{dispatchEvent(new KeyboardEvent('keydown',{code:'Escape',key:'Escape'}));}finally{synthKey=false;KEYS.Escape=false;}}
addEventListener('popstate',()=>{histOn=false;if(G.state==='menu')return;if(performance.now()-(FS.chgAt||0)<300){histArm();return;}escAction();histArm();});
addEventListener('keydown',e=>{
  if(cfmKey(e))return;if(e.target&&e.target.tagName==='INPUT')return;if(!synthKey&&!e.repeat)setInput('kbm');
  if(!$('#fsCard').hidden){if(e.code==='Escape'||e.code==='Enter'){e.preventDefault();FS.card(false);}return;}
  if(e.code==='F11'||(e.code==='Enter'&&e.altKey)||(e.code==='KeyF'&&e.ctrlKey&&e.metaKey)){if(FS.is()||FS.can()){e.preventDefault();FS.toggle('key');return;}}
  if(G.state==='settings'&&e.code==='Escape'){closeSettings();return;}
  if(G.state==='intro'&&e.code==='Escape'&&synthKey){if(!$('#bIntroBack').hidden)$('#bIntroBack').click();return;}
  if(G.prologue){prologueSkip();e.preventDefault();return;}
  /*DEVW*/if(window.DEVW&&DEVW.on()&&DEVW.key(e))return;
  KEYS[e.code]=true;
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)&&G.state==='play')e.preventDefault();
  if((G.state==='world'||G.state==='play')&&e.code==='KeyT'){SET.manual=!SET.manual;saveSet();updateCursor();if(G.player)floater(G.player.x,G.player.y-40,SET.manual?'ПРИЦЕЛ · РУЧНОЙ':'ПРИЦЕЛ · АВТО','#8fe9ff');}
  if(G.state==='world'){
    if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Tab'].includes(e.code))e.preventDefault();
    if(e.code==='KeyJ'){openMap('jr');return;}
    if(e.code==='Space')tryDash();if(e.code==='KeyE'||e.code==='ShiftLeft'||e.code==='ShiftRight')tryPulse();
    if(e.code==='KeyF'||e.code==='Enter')cardAct('main');
    if(e.code==='KeyM'||e.code==='Tab')openMap();if(e.code==='Escape'||e.code==='KeyP')pause();return;}
  if(G.state==='map'){if(['KeyM','Tab','Escape'].includes(e.code)){e.preventDefault();closeMap();}else if(e.code==='KeyJ')mapTab(G.mapTab==='jr'?'map':'jr');return;}
  if(G.state==='shop'){if(e.code==='Escape')closeShop();return;}
  if(G.state==='hangar'){if(e.code==='Escape')closeHangar();return;}
  if(G.state==='arsenal'){if(e.code==='Escape')closeArsenal();return;}
  if(G.state==='cycle'){if(e.code==='Escape')closeCycle();return;}
  if(G.state==='save'||G.state==='dev'){if(e.code==='Escape')toMenu();return;}
  if(e.code==='Backquote'&&devAny()&&G.state==='play'){toggleDevPanel();return;}
  if(G.state==='play'){if(e.code==='Space')tryDash();if(e.code==='KeyE'||e.code==='ShiftLeft'||e.code==='ShiftRight')tryPulse();if(e.code==='Escape'||e.code==='KeyP')pause();}
  else if(G.state==='pause'&&(e.code==='Escape'||e.code==='KeyP'))resume();
  else if(G.state==='levelup'&&/^Digit[123]$/.test(e.code))choose(+e.code.slice(5)-1);
  else if(G.state==='levelup'&&e.code==='KeyA'&&G.briefQ>0)autoPick();
  else if(G.state==='menu'){if(e.code==='Enter'&&document.activeElement.tagName!=='BUTTON')startWorld(false);if(e.code==='KeyC')openCodex('menu');}
  else if(G.state==='codex'&&e.code==='Escape')closeCodex();
  else if(G.state==='intro'&&e.code==='Enter'&&document.activeElement.tagName!=='BUTTON'){e.preventDefault();startMission();}
});
addEventListener('keyup',e=>{KEYS[e.code]=false;});
addEventListener('blur',()=>{for(const k in KEYS)KEYS[k]=false;CHG.m=false;CHG.t=false;MOUSE.down=false;pause();lifeSave();});
document.addEventListener('visibilitychange',()=>{if(document.hidden){pause();lifeSave();}});
function lifeSave(){try{for(const k in KEYS)KEYS[k]=false;CHG.m=false;CHG.t=false;CHG.p=false;if(joy.on){joy.on=false;joy.id=null;joy.x=joy.y=0;$('#joy').style.display='none';}SW.clear();
  if(G.mode==='world'&&G.world&&G.player&&G.save&&!(window.DEVW&&DEVW.on()))saveWorld();if(isMob()&&AU.ctx&&AU.ctx.state==='running'&&document.hidden)AU.ctx.suspend();}catch(e){console.error(e);}}
addEventListener('pagehide',lifeSave);
addEventListener('pointerdown',()=>{if(isMob())audioInit();},true);
cv.addEventListener('mousedown',e=>{if(e.button===2)CHG.m=true;if(e.button===0)MOUSE.down=true;});
addEventListener('pointermove',e=>{if(e.pointerType!=='mouse')return;MOUSE.mvAt=performance.now();if(G.input!=='kbm'){mouseAcc+=Math.abs(e.movementX||0)+Math.abs(e.movementY||0);if(mouseAcc>8){mouseAcc=0;setInput('kbm');}}MOUSE.sx=e.clientX;MOUSE.sy=e.clientY;if(!MOUSE.moved){MOUSE.moved=true;}});
addEventListener('pointerdown',e=>{if(e.pointerType==='touch'){inputT=performance.now();setInput('touch');}else if(e.pointerType==='mouse')setInput('kbm');},true);
addEventListener('mouseup',e=>{if(e.button===2)CHG.m=false;if(e.button===0)MOUSE.down=false;});
addEventListener('contextmenu',e=>{if(G.state==='play'||G.state==='world'||e.target===cv)e.preventDefault();});
// ---------- 0.6.0: сенсорное управление ----------
let SAFE={t:0,r:0,b:0,l:0},TBR={};
const TBL={dash:{d:88,dx:92,dy:92},pulse:{d:64,dx:190,dy:64},charge:{d:64,dx:64,dy:190},act:{d:64,dx:190,dy:190}};
function readSafe(){const el=$('#safeProbe');if(!el)return;const cs=getComputedStyle(el);SAFE={t:parseFloat(cs.paddingTop)||0,r:parseFloat(cs.paddingRight)||0,b:parseFloat(cs.paddingBottom)||0,l:parseFloat(cs.paddingLeft)||0};}
function joyR(){return isMob()?56*(SET.btnSize||1):55;}
function joyFixed(){const k=SET.btnSize||1,R=joyR();const x=SET.hand==='l'?CW-SAFE.r-24-R*2.1:SAFE.l+24+R*2.1;return{x,y:CH-SAFE.b-24-R*2.1,R};}
function layoutTouch(){readSafe();const mob=isMob(),k=(SET.btnSize||1)*(typeof tabK==='function'?tabK():1),left=SET.hand==='l';TBR={};
  const T=$('#touch');if(T)T.style.setProperty('--ba',mob?(SET.btnAlpha||.7):1);
  const topLim=G.world&&G.state!=='menu'?SAFE.t+(G.ff==='phone-l'?(CH<=360?136:150):148):SAFE.t+64,need=Math.max(...Object.values(TBL).map(L=>(L.dy+L.d/2)*k)),f=Math.min(1,(CH-SAFE.b-topLim)/need);
  for(const [id,key] of [['tDash','dash'],['tPulse','pulse'],['tCharge','charge'],['tAct','act']]){const el=$('#'+id);if(!el)continue;
    if(!mob){el.style.cssText='';continue;}
    const L=TBL[key],d=L.d*k*(f<.85?Math.max(.8,f/.85):1),cx=left?SAFE.l+L.dx*k:CW-SAFE.r-L.dx*k,cy=CH-SAFE.b-L.dy*k*f;
    el.style.left=(cx-d/2)+'px';el.style.top=(cy-d/2)+'px';el.style.right='auto';el.style.bottom='auto';el.style.width=el.style.height=d+'px';TBR[key]={x:cx,y:cy,r:d/2};}
  const R=joyR(),J=$('#joy'),I=$('#joyIdle');
  if(mob){J.style.width=J.style.height=(R*2+10)+'px';J.style.margin=(-(R+5))+'px 0 0 '+(-(R+5))+'px';const kn=J.firstElementChild;kn.style.width=kn.style.height=(R*.82)+'px';kn.style.margin=(-(R*.41))+'px 0 0 '+(-(R*.41))+'px';}
  else{J.style.width=J.style.height=J.style.margin='';const kn=J.firstElementChild;kn.style.width=kn.style.height=kn.style.margin='';}
  if(I){const f=SET.stick==='fixed'?joyFixed():{x:joy.lx??(left?CW-SAFE.r-24-R*2.3:SAFE.l+24+R*2.3),y:joy.ly??(CH-SAFE.b-24-R*2.3)};
    I.style.width=I.style.height=(R*2+10)+'px';I.style.left=(f.x-R-5)+'px';I.style.top=(f.y-R-5)+'px';}}
function stickZone(x,y){if(!isMob())return x<CW*.5;
  const left=SET.hand==='l';if(left?x<CW*.5:x>=CW*.5)return false;
  if(x<SAFE.l+14||x>CW-SAFE.r-14||y>CH-SAFE.b-10)return false;
  for(const k in TBR){const b=TBR[k];if(Math.hypot(x-b.x,y-b.y)<b.r*1.15)return false;}
  if(SET.stick==='fixed'){const f=joyFixed();return Math.hypot(x-f.x,y-f.y)<f.R*1.8;}
  return y>(isPortrait()?CH*.4:SAFE.t+84);}
function joyShow(){const j=$('#joy');j.style.display='block';j.style.left=joy.ox+'px';j.style.top=joy.oy+'px';}
function joyUnlock(){if(!joy.locked)return;joy.locked=false;joy.x=joy.y=0;const L=$('#joyLock');if(L)L.classList.remove('on');}
/* ARCH·81 → prioTap перенесена в блок «ПОДСИСТЕМА НАВЕДЕНИЯ» после nearestEnemy */
const SW=new Map();
cv.addEventListener('pointerdown',e=>{if(G.prologue){if(e.pointerType!=='touch'||G.prologue.t>.8)prologueSkip();return;}
  audioInit();if(e.button===2)return;
  if(e.pointerType==='touch'){touchMode=true;$('#touch').hidden=!(G.state==='play'||G.state==='world');}
  if(G.state!=='play'&&G.state!=='world')return;
  if(e.pointerType==='mouse'&&aimManual())return;
  if(e.pointerType==='touch'){
    if(!joy.on&&stickZone(e.clientX,e.clientY)){joyUnlock();joy.on=true;joy.id=e.pointerId;
      if(isMob()&&SET.stick==='fixed'){const f=joyFixed();joy.ox=f.x;joy.oy=f.y;}else{joy.ox=e.clientX;joy.oy=e.clientY;}
      joy.x=joy.y=0;joy.lockHold=0;joy.lockable=false;joy.fl=[{x:e.clientX,y:e.clientY,t:performance.now()}];joyShow();joyMove(e.clientX,e.clientY);
      const j=$('#joy');j.firstElementChild.style.transform='';const I=$('#joyIdle');if(I)I.classList.remove('on');return;}
    SW.set(e.pointerId,{x:e.clientX,y:e.clientY,t:performance.now()});return;}
  prioTap(e.clientX,e.clientY);
});
function joyMove(cx,cy){const m=joyR();let dx=cx-joy.ox,dy=cy-joy.oy,l=Math.hypot(dx,dy);
  if(isMob()){if(SET.stick!=='fixed'&&l>m){joy.ox+=dx/l*(l-m);joy.oy+=dy/l*(l-m);dx=cx-joy.ox;dy=cy-joy.oy;l=m;$('#joy').style.left=joy.ox+'px';$('#joy').style.top=joy.oy+'px';}
    else if(l>m){dx*=m/l;dy*=m/l;l=m;}
    const n=l/m,dz=.08,o=n<=dz?0:Math.pow((n-dz)/(1-dz),1.25);joy.x=l>0?dx/l*o:0;joy.y=l>0?dy/l*o:0;}
  else{if(l>m){dx*=m/l;dy*=m/l;}joy.x=dx/m;joy.y=dy/m;}
  $('#joy').firstElementChild.style.transform=`translate(${dx}px,${dy}px)`;}
addEventListener('pointermove',e=>{if(!joy.on||e.pointerId!==joy.id)return;joyMove(e.clientX,e.clientY);
  if(isMob()&&SET.oneHand){const now=performance.now();joy.fl.push({x:e.clientX,y:e.clientY,t:now});while(joy.fl.length&&now-joy.fl[0].t>120)joy.fl.shift();
    const a=joy.fl[0],dx=e.clientX-a.x,dy=e.clientY-a.y,d=Math.hypot(dx,dy);if(d>joyR()*2&&now-joy.flT>350){joy.flT=now;joy.fl=[];tryDash([dx/d,dy/d]);}}});
const joyEnd=e=>{if(e.pointerId!==joy.id)return;const keep=e.type==='pointerup'&&joy.lockable&&G.state==='world';
  joy.on=false;joy.id=null;joy.lx=joy.ox;joy.ly=joy.oy;$('#joy').style.display='none';$('#joy').classList.remove('lockable');joy.lockable=false;
  if(keep){joy.locked=true;const L=$('#joyLock');if(L){L.classList.add('on');L.style.left=Math.max(8,joy.ox-90)+'px';L.style.top=Math.max(8,joy.oy-joyR()-40)+'px';}buzz('ready');}
  else{joy.x=joy.y=0;}
  if(isMob())layoutTouch();const I=$('#joyIdle');if(I&&isMob()&&touchMode)I.classList.add('on');};
addEventListener('pointerup',joyEnd);addEventListener('pointercancel',joyEnd);
const swEnd=e=>{const q=SW.get(e.pointerId);if(!q)return;SW.delete(e.pointerId);if(e.type!=='pointerup')return;
  const dx=e.clientX-q.x,dy=e.clientY-q.y,d=Math.hypot(dx,dy),dt=performance.now()-q.t;
  if(isMob()&&SET.dashSwipe!==false&&d>=60&&dt<=200){tryDash([dx/d,dy/d]);return;}
  if(d<14)prioTap(q.x,q.y);};
addEventListener('pointerup',swEnd);addEventListener('pointercancel',swEnd);
function tbBump(el){if(!el)return;el.classList.remove('bump');void el.offsetWidth;el.classList.add('bump');}
$('#tDash').addEventListener('pointerdown',e=>{e.preventDefault();const p=G.player,cd0=p&&p.dashCd;tryDash();if(p&&cd0===p.dashCd&&!(p.dashT>0))tbBump(e.currentTarget);});
$('#tPulse').addEventListener('pointerdown',e=>{e.preventDefault();const p=G.player,en0=p&&p.en;tryPulse();if(p&&p.en===en0&&en0<100)tbBump(e.currentTarget);});
{const tc=$('#tCharge');tc.addEventListener('pointerdown',e=>{e.preventDefault();CHG.t=true;try{tc.setPointerCapture(e.pointerId);}catch(err){}});
  ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>tc.addEventListener(ev,()=>{CHG.t=false;}));}
$('#tAct').addEventListener('pointerdown',e=>{e.preventDefault();const a=e.currentTarget.dataset.act;if(G.state!=='world')return;if(!a||a==='map')openMap();else cardAct(a);});
function ctxBtnSync(){const b=$('#tAct');if(!b)return;const on=isMob()&&touchMode&&G.state==='world'&&!G.prologue;if(b.hidden===on)b.hidden=!on;if(!on)return;
  const W_=$('#wcard'),wb=W_.hidden?null:W_.querySelector('[data-act]');const lab=wb?wb.textContent.trim().split(/\s+/)[0]:'КАРТА',act=wb?wb.dataset.act:'map';
  if(b.dataset.act!==act||b.dataset.lab!==lab){b.dataset.act=act;b.dataset.lab=lab;b.querySelector('.lb').textContent=lab;b.classList.toggle('go',!!wb);}}
// вибрация (Android; на iOS API нет — молча ничего)
let buzzT=0;const BUZZ={dash:12,pulse:30,ready:[8,40,8],chg:35,chgFull:20,hit:25,hit2:50,death:[80,60,120],boss:[40,40,40,40,120],win:[40,40,40,40,120],tap:15};
function buzz(k){if(!SET.haptics||!touchMode||!isMob()||!navigator.vibrate||RMQ&&RMQ.matches)return;const now=performance.now();if(now-buzzT<80)return;buzzT=now;try{navigator.vibrate(BUZZ[k]||15);}catch(e){}}
const RMQ=window.matchMedia?matchMedia('(prefers-reduced-motion: reduce)'):null;
// состояние кнопок: кольца перезарядки, готовность, фиксация курса
const tbC={};
function tbSet(id,p,txt,cls){const el=$('#'+id);if(!el)return;const k=Math.round(p*100);if(tbC[id+'p']!==k){tbC[id+'p']=k;const c=el.querySelector('.rf');if(c)c.style.strokeDashoffset=100-k;}
  if(tbC[id+'t']!==txt){tbC[id+'t']=txt;const n=el.querySelector('.cdn');if(n)n.textContent=txt;}
  for(const c of ['rdy','chg'])if(tbC[id+c]!==(cls===c)){tbC[id+c]=cls===c;el.classList.toggle(c,cls===c);}}
let tbPrevEn=0,tbPrevChg=0;
function touchTick(dt){const T=$('#touch');if(!T||T.hidden||!isMob())return;const p=G.player;if(!p)return;
  const dm=p.dashCdMax||G.st.dashCd||1;tbSet('tDash',p.dashCd>0?1-p.dashCd/dm:1,'');
  tbSet('tPulse',Math.min(1,p.en/100),'',p.en>=100?'rdy':'');if(p.en>=100&&tbPrevEn<100)buzz('ready');tbPrevEn=p.en;
  const cf=p.chg>0?Math.min(1,p.chg/CHG_T):p.chgCd>0?1-p.chgCd/CHG_CD:1;tbSet('tCharge',cf,'',p.chg>0?'chg':'');if(p.chg>=CHG_T&&tbPrevChg<CHG_T)buzz('chgFull');tbPrevChg=p.chg||0;
  ctxBtnSync();
  const calm=G.state==='world'&&G.calm>5&&p.hp>=G.st.maxHp*.99;if(tbC.calm!==calm){tbC.calm=calm;T.classList.toggle('calm',calm);}
  // фиксация курса в спокойном полёте: стик у края 2,5 с в одном направлении
  if(joy.on&&G.state==='world'&&G.calm>2){const m=Math.hypot(joy.x,joy.y),a=Math.atan2(joy.y,joy.x);
    if(m>.9&&Math.abs(angDiff(a,joy.lockA))<.35){joy.lockHold+=dt;}else{joy.lockHold=0;joy.lockA=a;}
    const lk=joy.lockHold>2.5;if(lk!==joy.lockable){joy.lockable=lk;$('#joy').classList.toggle('lockable',lk);}}
  else if(joy.lockable){joy.lockable=false;$('#joy').classList.remove('lockable');}
  if(joy.locked&&(G.state!=='world'||G.calm<=0||p.hp<=0))joyUnlock();
  const I=$('#joyIdle');if(I){const on=!joy.on&&!joy.locked;if(I.classList.contains('on')!==on)I.classList.toggle('on',on);const hint=on&&(G.mode==='world'&&!G.world&&G.m<=2);if(I.classList.contains('hint')!==hint)I.classList.toggle('hint',hint);}}
$('#btnPause').addEventListener('click',pause);
$('#bHangarClose').onclick=closeHangar;
$('#bWorld').onclick=()=>cloudGate(()=>startWorld(false));$('#bEndless').onclick=()=>{G.fromAbyss=false;startEndless(false,1);};$('#bDev').onclick=openDev;
$('#bWorldNew').onclick=()=>{if(newConfirm&&performance.now()-newConfirm<4000){cloudGate(()=>{startWorld(true);cloudForce();});return;}newConfirm=performance.now();$('#bWorldNew').textContent='ТОЧНО? ПРОГРЕСС ПОЛЁТА СОТРЁТСЯ';};
$('#bSave').onclick=()=>cloudGate(openSaveScreen);$('#bSettings').onclick=()=>openSettings('menu');$('#bMore').onclick=()=>{$('#sMenu').classList.toggle('more');$('#bMore').textContent=$('#sMenu').classList.contains('more')?'СКРЫТЬ':'ЕЩЁ';};$('#bPauseSet').onclick=()=>openSettings('pause');$('#bSetBack').onclick=closeSettings;$('#btnMap').onclick=openMap;$('#bMapClose').onclick=closeMap;$('#bShopClose').onclick=closeShop;
$('#bIntroBack').onclick=()=>{if(G.mode==='world')returnToWorld();else if(G.mode==='dev')openDev();};
$('#bPauseMap').onclick=()=>{scr6('world');openMap();};
$('#bAbandon').onclick=()=>{if(G.fromAbyss){leaveAbyss();return;}if(G.mode==='dev'){openDev();return;}if(G.mode!=='world')return;restoreRun();returnToWorld();};
$('#bToWorld').onclick=()=>{if(G.fromAbyss){leaveAbyss();return;}if(G.devRun){openDev();return;}restoreRun();returnToWorld();};$('#bCodex').onclick=()=>openCodex('menu');$('#bCodexBack').onclick=closeCodex;
$('#bGo').onclick=startMission;$('#bNext').onclick=()=>{if(G.state!=='done')return;if(G.mode==='world'){returnToWorld();return;}if(G.mode==='dev'){restoreRun();openIntro(G.m-1);}};$('#bDoneMenu').onclick=()=>{if(G.mode==='dev')openDev();else toMenu();};
function confirm2(el,f){return e=>{if(!touchMode||!isMob())return f(e);const now=performance.now();if(el.dataset.arm&&now-+el.dataset.arm<3000){el.dataset.arm='';el.textContent=el.dataset.lab;return f(e);}el.dataset.arm=now;el.dataset.lab=el.dataset.lab||el.textContent;el.textContent='ТОЧНО? НАЖМИТЕ ЕЩЁ РАЗ';setTimeout(()=>{if(el.dataset.arm&&performance.now()-+el.dataset.arm>=2900){el.dataset.arm='';el.textContent=el.dataset.lab;}},3000);};}
$('#bArsClose').onclick=closeArsenal;$('#bResume').onclick=resume;$('#bRestart').onclick=()=>{if(G.mode==='endless'){startEndless(G.devRun,G.devStep);return;}restoreRun();openIntro(G.m-1);};$('#bPauseCodex').onclick=()=>openCodex('pause');$('#bQuit').onclick=toMenu;
['bRestart','bAbandon','bQuit'].forEach(id=>{const el=$('#'+id),f=el.onclick;el.onclick=confirmPause(el,f);});
$('#bRetry').onclick=()=>{if(G.mode==='endless'){startEndless(G.devRun,G.devStep);return;}restoreRun();openIntro(G.m-1);};$('#bOverMenu').onclick=toMenu;

// =====================================================================
// ---------- БЕСКОНЕЧНОСТЬ (0.2.5) ----------
// ступени по 10 с · удвоение бюджета и разнообразия · предел 70 · рекорды
// =====================================================================
const END_ORDER=['scout','gunner','rammer','splitter','moth','miner','phantom','lancer','shielder','mirror','shocker','twin','hunter','guard','commander','vortex'];
const END_W={guard:.4,hunter:.6,commander:.6,vortex:.5,shielder:.7,moth:.8};
const END_CAP=35,END_STEP=10;
const stepDur=n=>n<=2?10:15;
const stepStart=n=>n<=1?0:n===2?10:20+(n-3)*15;
const fmtT=t=>{const m=Math.floor(t/60),s=t-m*60;return m+':'+pad2(Math.floor(s))+'.'+Math.floor((s%1)*10);};
function endRecords(){const L=store('void_endless');return Array.isArray(L)?L.filter(r=>r&&typeof r.t==='number'):[];}
function bestEndless(){const L=endRecords();return L.length?L[0]:null;}
function startEndless(dev,step0){secReset();/*DEVW*/if(window.DEVW&&!dev&&!DEVW.on())DEVW.clearFlag(true);riftReset();
  audioInit();
  G.mode='endless';G.devRun=!!dev;G.devStep=step0||1;G.world=false;lockArena();G.mods={};computeStats();G.player=newPlayer();G.player.hp=G.st.maxHp;
  runStart6(1);Object.assign(G,{score:0,kills:0,taken:0,inRun:true,m:10});
  Object.assign(G,{enemies:[],pb:[],eb:[],pick:[],parts:[],float:[],warns:[],shock:[],prio:null,boss:null,endT:0,deadT:0,bc:null,relays:[],rocks:[],fields:[],meteors:[],meteorT:0,
    storm:null,flare:0,fake:null,lureP:null,dashLog:[],dark:false,lightFull:0,jam:null,loseBeacon:false,affixCh:0,affix2:0,rockN:0,waves:[],spawnQ:[],mc:null,lowFx:false,fpsLow:0,mT:0,missionKills:0,missionTaken:0});
  const p=G.player;p.x=W/2;p.y=H/2;p.px=p.x;p.py=p.y;p.inv=1.5;if(G.arena){G.camSnap=1;missionCam(0);}
  const rec=bestEndless();
  G.noTele=false;aimLockClear();G.end={t:0,step:0,stepT:0,acc:1,dur:10,next60:90,best:dev?null:rec,beat:false,budget:4,types:1,hpMul:1,spdMul:1,pool:{},nextBoss:300,bossN:0,bosses:0,bossOn:false};G.combo=null;G.bossMul=0;
  const s0=Math.max(1,step0||1);G.end.t=stepStart(s0);G.end.next60=Math.floor(G.end.t/90)*90+90;G.end.nextBoss=Math.floor(G.end.t/300)*300+300;enterStep(s0,true);
  scr6('play');show('');banner(G.fromAbyss?'БЕЗДНА':'БЕСКОНЕЧНОСТЬ',dev?'ТЕСТ · СТУПЕНЬ '+s0:G.fromAbyss?'В СЕКТОР НИЧЕГО НЕ ПЕРЕНОСИТСЯ':'ДЕРЖИТЕСЬ КАК МОЖНО ДОЛЬШЕ');
}
function enterStep(n,silent){
  const E=G.end,prevTypes=E.types;E.step=n;
  E.budget=2*Math.pow(2,Math.min(n-1,40));E.dur=stepDur(n);E.types=Math.min(END_ORDER.length,Math.pow(2,Math.min(n-1,10)));
  E.pool={};END_ORDER.slice(0,E.types).forEach(k=>E.pool[k]=END_W[k]||1);
  const over=Math.max(0,n-6);
  G.affixCh=n>=6?Math.min(1,(n-5)*.075):0;G.affix2=n>=12?Math.min(1,(n-11)*.075):0;
  E.hpMul=Math.pow(1.06,over);E.spdMul=Math.min(1.3,1+.02*over);
  if(silent)return;
  const fresh=n>1?END_ORDER.slice(Math.min(prevTypes,E.types),E.types).map(k=>EDEF[k].name.toUpperCase()):[];
  banner('СТУПЕНЬ '+n,fresh.length?'НОВЫЕ УГРОЗЫ: '+fresh.slice(0,5).join(', ')+(fresh.length>5?' И ЕЩЁ '+(fresh.length-5):''):
    'ЭЛИТА '+Math.round(G.affixCh*100)+'% · ПРОЧНОСТЬ ×'+E.hpMul.toFixed(2)+' · СКОРОСТЬ ×'+E.spdMul.toFixed(2));
  sfx('warn');
}
function eliteSquad(){
  const E=G.end,cand=['gunner','rammer','lancer','mirror','shocker','hunter','guard'].filter(k=>E.pool[k]);
  if(!cand.length)cand.push('scout','scout');
  const n=Math.max(1,Math.min(E.step>=10?3:2,Math.floor(END_CAP-enemyLoad()))),side=Math.random()*4|0,u=rnd(.2,.8);
  for(let i=0;i<n;i++)edgeSpawn(cand[Math.random()*cand.length|0],{side,u:u+i*.07,elite:true,delay:i*.15});
  banner('ЭЛИТНЫЙ ОТРЯД','ДВА АФФИКСА У КАЖДОГО');sfx('warn');
}
function updateEndless(dt){
  const E=G.end;E.t+=dt;G.mT=E.t;const bossUp=endlessBossAlive();if(!bossUp)E.stepT+=dt;
  if(E.stepT>=E.dur){E.stepT-=E.dur;enterStep(E.step+1);}
  updateEndlessBoss();
  E.acc=Math.min(4,E.acc+dt*E.budget/E.dur*(bossUp?.5:1));
  if(E.acc>=1){const t=pickPool(E.pool),cost=t==='moth'?2.3:t==='twin'?2:1;if(enemyLoad()+cost<=END_CAP){E.acc-=1;directorSpawn(t);}}
  if(E.t>=E.next60){E.next60+=90;eliteSquad();}
  if(E.best&&!E.beat&&E.t>E.best.t){E.beat=true;banner('НОВЫЙ РЕКОРД',fmtT(E.best.t)+' ПОЗАДИ');sfx('level');}
}
function endlessOver(){
  scr6('over');const E=G.end;const picks=Object.values(G.mods).reduce((a,b)=>a+b,0);
  const rec={t:Math.round(E.t*10)/10,k:G.kills,s:E.step,b:E.bosses||0,d:new Date().toLocaleDateString('ru-RU')};let place=0;
  if(!G.devRun){const L=endRecords();L.push(rec);L.sort((a,b)=>b.t-a.t||b.k-a.k);place=L.indexOf(rec)+1;store('void_endless',L.slice(0,10));}
  $('#ovEyebrow').textContent=G.devRun?'БЕСКОНЕЧНОСТЬ · ТЕСТ · НЕ ЗАПИСАНО':G.fromAbyss?'БЕЗДНА · ЗАБЕГ ОКОНЧЕН':'БЕСКОНЕЧНОСТЬ · ЗАБЕГ ОКОНЧЕН';
  $('#ovName').textContent=fmtT(rec.t)+(place&&place<=10?' · место '+place:'');
  $('#ovStats').innerHTML=statCells([['ВРЕМЯ',fmtT(rec.t)],['УНИЧТОЖЕНО',rec.k],['СТУПЕНЬ',rec.s],['БОССЫ',rec.b],['МОДУЛЕЙ',picks]]);
  const b=E.best;$('#ovNote').textContent=G.devRun?'Тестовый забег не попадает в таблицу рекордов.':
    place===1?'Новый лучший результат.':b?'Рекорд: '+fmtT(b.t)+' · '+b.k+' уничтожено.':'Первый забег записан.';
  $('#bRetry').firstChild.nodeValue='ЕЩЁ РАЗ ';$('#bRetry').hidden=false;$('#bToWorld').hidden=!(G.devRun||G.fromAbyss);$('#bToWorld').textContent=G.fromAbyss?'В СЕКТОР':'К ВЫБОРУ МИССИЙ';
  show('sOver');(touchMode||$('#bRetry').focus());
}
function updateEndlessHUD(){
  const p=G.player,st=G.st,E=G.end;if(!p||!E)return;
  setT('hpT',Math.ceil(p.hp)+'/'+st.maxHp);setS('hpB',(p.hp/st.maxHp).toFixed(3));
  setS('enB',(p.en/100).toFixed(3));setC('enBar','full',p.en>=100);
  setT('eTime',mmss(E.t));setS('eB',(E.stepT/E.dur).toFixed(3));
  {const bo=G.boss&&G.boss.alive?G.boss:G.jam&&G.jam.alive?G.jam:null;
    if(bo){setT('eStep',bo.type==='boss'?'ЭХО СТРАЖА':'ЭХО ГЛУШИТЕЛЯ');}
    else{const tb=E.nextBoss-E.t;setT('eStep','СТУПЕНЬ '+E.step+(tb<=10?' · ЭХО БЛИЗКО':''));}}
  if(E.best){setT('eRec',E.beat?'НОВЫЙ РЕКОРД':'РЕКОРД '+mmss(E.best.t));setC('eRec','beat',E.beat);}
  else setT('eRec','');
  hudEls.score.firstChild.nodeValue=fmt(G.kills);
  const blocked=dashBlocked();const dr=p.dashCd<=0&&!blocked;
  setT('dashC','РЫВОК');setF('dashC',p.dashCd>0?1-p.dashCd/(p.dashCdMax||st.dashCd||1):0);setC('dashC','ok',dr);setC('dashC','bad',blocked);setC('tDash','cd',!dr);
  const pr=p.en>=100;setT('pulseC',pr?'ИМПУЛЬС [E]':'ИМПУЛЬС');setF('pulseC',pr?0:p.en/100);setC('pulseC','ok',pr);setC('tPulse','cd',!pr);
  setH('cargoC',true);setT('lvC','ЩИТ');setH('lvC',!st.shieldCd);setC('lvC','ok',!!(st.shieldCd&&p.shieldUp));setS('xpB',(G.xp/G.need).toFixed(3));
  chargeChip();
}

// =====================================================================
// ---------- ВЫБОР МИССИЙ (режим разработчика) ----------
// включается константой DEV_MENU; ничего не пишет в сохранения
// =====================================================================
const DEV_MENU=true;
/* 1.1.0: меню разработчика скрыто от игроков; вход — пять нажатий по логотипу или ?dev в адресе (запоминается в этой вкладке) */
function devUnlocked(){try{if(/[?&#]dev\b/.test(location.search+location.hash))sessionStorage.setItem('void_dev_ui','1');return DEV_MENU&&(window.__devUI===true||sessionStorage.getItem('void_dev_ui')==='1');}catch(e){return window.__devUI===true;}}
(function(){let n=0,t=0;const L=document.querySelector('#sMenu .logo');if(L)L.addEventListener('click',()=>{const now=performance.now();n=now-t<600?n+1:1;t=now;if(n>=5){window.__devUI=true;try{sessionStorage.setItem('void_dev_ui','1');}catch(e){}renderMenu();toast('РАЗРАБОТКА','Меню разработчика открыто.');}});})();
const DEV_TYP=[0,3,6,9,12,14,15,16,18,20];
const DEV_TOG=[['god','Бессмертие корабля'],['bcGod','Неуязвимый маяк'],['speed','Скорость времени ×2'],['hit','Показать хитбоксы'],['fps','FPS и число объектов'],['diag77','Диагностика кадров']];/* ARCH·77 */
G.dev=Object.assign({build:'typ',god:false,bcGod:false,speed:false,hit:false,fps:false,step:1,diff:'easy',cycle:1},store('void_dev')||{});
function devBuild(m,b){
  const avail=Object.keys(MODS).filter(k=>MODS[k].from<=m),mods={};
  if(b==='max')avail.forEach(k=>mods[k]=MODS[k].max);
  else if(b==='typ'){for(let i=0;i<(DEV_TYP[m-1]??20);i++){const ks=avail.filter(k=>(mods[k]||0)<MODS[k].max);if(!ks.length)break;const k=ks[Math.random()*ks.length|0];mods[k]=(mods[k]||0)+1;}}
  return mods;
}
function openDev(){
  banT=0;$('#banner').classList.remove('show');scr6('dev');G.devRun=false;G.mode=null;G.world=false;G.player=null;G.bc=null;G.boss=null;G.jam=null;G.dark=false;CX=0;CY=0;
  $('#devGrid').innerHTML=MISSIONS.slice(0,NM).map((M,i)=>`<button class="devm" data-m="${i+1}"><b>${pad2(i+1)}</b><span>${M.name}</span><small>${M.gen?(M.bossRoom?'БОСС · ':'')+'СЕКТОР '+roman(M.sec+1):i<6?'АКТ I':'АКТ II'}</small></button>`).join('')+
    `<button class="devm end" data-m="end"><b>∞</b><span>Бесконечность</span><small>СТУПЕНЬ ${G.dev.step}</small></button>`;
  renderDevOpts();show('sDev');/*DEVW*/if(window.DEVW)DEVW.devCard();
}
function renderDevOpts(){
  const D=G.dev;store('void_dev',D);
  document.querySelectorAll('#devBuild button').forEach(b=>b.classList.toggle('on',b.dataset.b===D.build));
  $('#devToggles').innerHTML=DEV_TOG.map(([k,n])=>`<button class="tog dtog ${D[k]?'on':''}" data-d="${k}"><span>${n}</span><span>${D[k]?'ВКЛ':'ВЫКЛ'}</span></button>`).join('');
  document.querySelectorAll('#devDiff [data-df]').forEach(b=>b.classList.toggle('on',b.dataset.df===D.diff));$('#devCyc').textContent=roman(D.cycle||1);
  $('#devStep').textContent=D.step;const end=document.querySelector('.devm.end small');if(end)end.textContent='СТУПЕНЬ '+D.step;
}
function devStart(m){
  riftReset();audioInit();const D=G.dev;G.mode='dev';G.devRun=true;G.world=false;
  G.mods=devBuild(m,D.build);computeStats();G.player=newPlayer();G.player.hp=G.st.maxHp;
  const lv=1+Object.values(G.mods).reduce((a,b)=>a+b,0);
  runStart6(lv);Object.assign(G,{score:0,kills:0,taken:0,inRun:true});
  openIntro(m-1);
}
function devMissionDone(){ambSting('win');
  scr6('done');
  $('#dnEyebrow').textContent='ТЕСТ · МИССИЯ '+pad2(G.m)+' ПРОЙДЕНА · НЕ ЗАПИСАНО';$('#dnName').textContent=MISSIONS[G.m-1].name;
  const cells=[['ВРЕМЯ',mmss(G.mT)],['УНИЧТОЖЕНО',G.kills-G.missionKills],['ПОЛУЧЕНО УРОНА',Math.round(G.taken-G.missionTaken)],['УРОВЕНЬ МОДУЛЕЙ',G.lvl]];
  if(G.bc)cells.splice(3,0,['МАЯК ЦЕЛ НА',Math.round(G.bc.hp/G.bc.maxHp*100)+'%']);
  $('#dnStats').innerHTML=statCells(cells);
  let mast='';try{mast=MASTERY[G.m-1].ok()?'выполнено':'не выполнено';}catch(e){mast='—';}
  $('#dnNote').textContent='Условие мастерства «'+MASTERY[G.m-1].t+'»: '+mast+'. Прогресс и медали не сохраняются.';
  $('#bNext').firstChild.nodeValue='ЕЩЁ РАЗ ';$('#bDoneMenu').textContent='К ВЫБОРУ МИССИЙ';
  show('sDone');(touchMode||$('#bNext').focus());
}
$('#devGrid').addEventListener('click',e=>{const b=e.target.closest('.devm');if(!b)return;if(b.dataset.m==='end')startEndless(true,G.dev.step);else devStart(+b.dataset.m);});
$('#devBuild').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;G.dev.build=b.dataset.b;renderDevOpts();});
$('#devToggles').addEventListener('click',e=>{const b=e.target.closest('.dtog');if(!b)return;const k=b.dataset.d;G.dev[k]=!G.dev[k];renderDevOpts();});
$('#devStepM').onclick=()=>{G.dev.step=Math.max(1,G.dev.step-1);renderDevOpts();};
$('#devStepP').onclick=()=>{G.dev.step=Math.min(15,G.dev.step+1);renderDevOpts();};
$('#bDevBack').onclick=()=>toMenu();
$('#devDiff').addEventListener('click',e=>{const b=e.target.closest('[data-df]');if(!b)return;G.dev.diff=b.dataset.df;renderDevOpts();});
$('#devCycM').onclick=()=>{G.dev.cycle=Math.max(1,(G.dev.cycle||1)-1);renderDevOpts();};
$('#devCycP').onclick=()=>{G.dev.cycle=Math.min(6,(G.dev.cycle||1)+1);renderDevOpts();};
function devAny(){return G.devRun||!!(window.DEVW&&DEVW.on());}/*DEVW*/
const devOn=k=>devAny()&&G.dev[k];
// панель быстрых действий
function toggleDevPanel(force){/*DEVW*/if(window.DEVW&&DEVW.on()&&G.state==='world'){DEVW.panel(force);return;}if(!devAny())return;const P=$('#devPanel');P.hidden=force!==undefined?!force:!P.hidden;if(!P.hidden)renderDevPanel();}
function renderDevPanel(){
  const sel=$('#devSpawn');if(!sel.options.length)sel.innerHTML=CODEX_ORDER.filter(k=>!['boss','jam','pylon','inventor','obheart','shell','icecopy','cpart','invcell','invcore','obseg','hull','lock','rustcopy'].includes(k)&&EDEF[k]).map(k=>`<option value="${k}">${EDEF[k].name}</option>`).join('');
  const M=G.mode==='endless'?null:MISSIONS[G.m-1];
  $('#dvBoss').hidden=!(M&&(M.boss||M.transmit||M.sboss));$('#dvBoss').textContent=G.boss||G.jam||G.sb?'СЛЕДУЮЩАЯ ФАЗА БОССА':'ПЕРЕЙТИ К БОССУ';
  $('#dvCharge').hidden=!G.bc;$('#dvWave').hidden=!(M&&!M.beacon&&!M.boss);$('#dvStep').hidden=G.mode!=='endless';
}
function devAct(a){
  if(!devAny()||G.state!=='play')return;const M=G.mode==='endless'?null:MISSIONS[G.m-1];
  const clearAll=()=>{G.warns=[];G.spawnQ=[];for(let k=0;k<2;k++)G.enemies.slice().forEach(e=>{if(e.alive&&!['boss','jam','lock'].includes(e.type)&&!EDEF[e.type].sbp)kill(e,false);});};
  if(a==='kill')clearAll();
  if(a==='wave'){clearAll();G.gapT=0;}
  if(a==='lvl')runGrant6('lvl');
  if(a==='plvl'||a==='lom'){const sb=!!(window.DEVW&&DEVW.on()),K='void_devworld',S=sb?G.save:(migrateSave(store(K))||migrateSave(newSave()));if(a==='lom')S.lom+=500;else{const keep=G.save;try{addPilotXPTo(S,pilotNeed(S.pilot.lvl)-S.pilot.xp);}finally{if(!sb)saveSet6(keep,'temp');}if(!sb)G.pilotUps=[];}store(K,S);if(sb)G.lomPrev=undefined;
    floater(G.player.x,G.player.y-40,a==='lom'?'+500 ЛОМА В ПЕСОЧНИЦУ':'ПИЛОТ · УР '+S.pilot.lvl,'#00ff88');}
  if(a==='charge'&&G.bc){G.bc.charge=Math.min(100,G.bc.charge+25);}
  if(a==='step'&&G.end)G.end.stepT=G.end.dur;
  if(a==='spawn'){const t=$('#devSpawn').value;if(t==='twin')directorSpawn('twin');else edgeSpawn(t);}
  if(a==='boss'&&M){
    if(M.sboss){const b=G.sb;if(!b){clearAll();G.waveIdx=G.waves.length;G.gapT=.1;}else if(b.st==='enter')b.timer=0;else if(b.st==='fight'){if(b.phase<3){b.hp=b.th[b.phase-1];sbPhase(b);}else{b.hp=b.th[2];sbFinal(b);}}else if(b.st==='final')sbChoose(b,null);}
    else if(M.boss){const b=G.boss;
      if(!b){clearAll();G.waveIdx=G.waves.length;G.gapT=.1;}
      else if(b.st==='enter')b.timer=0;
      else if(b.st==='fight'){const th=b.th[b.phase-1];if(b.phase<3){b.hp=th;phaseShift(b);}else{b.hp=0;b.alive=true;kill(b);}}}
    else if(M.transmit){const j=G.jam,bc=G.bc;
      if(!j&&bc){bc.charge=100;bc.peak=100;bc.thrI=bc.thr.length;bc.coolI=bc.coolAt.length;}
      else if(j&&j.st==='enter')j.timer=0;
      else if(j&&j.st==='fight'){const th=j.th[j.phase-1];if(j.phase<3){j.hp=th;jamPhase(j);}else{j.hp=0;kill(j);}}}
  }
  renderDevPanel();
}
$('#devPanel').addEventListener('click',e=>{const b=e.target.closest('[data-dv]');if(b)devAct(b.dataset.dv);});
$('#devBtn').onclick=()=>toggleDevPanel();
let fpsAvg=60;
function drawDevOverlay(){
  if(!devAny()||!G.player)return;
  if(G.dev.hit){const k=DPR*SC;ctx.setTransform(k,0,0,k,-CX*k,-CY*k);ctx.lineWidth=1;ctx.globalAlpha=.9;
    ctx.strokeStyle='#00ff88';for(const e of G.enemies){if(!e.alive)continue;ctx.beginPath();ctx.arc(e.x,e.y,e.r,0,TAU);ctx.stroke();}
    ctx.strokeStyle='#ffffff';const p=G.player;ctx.beginPath();ctx.arc(p.x,p.y,9,0,TAU);ctx.stroke();ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,TAU);ctx.stroke();
    ctx.strokeStyle='#ff4f6e';for(const b of G.eb){ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,TAU);ctx.stroke();}
    if(G.bc){ctx.strokeStyle='#ffb84d';ctx.beginPath();ctx.arc(G.bc.x,G.bc.y,G.bc.r,0,TAU);ctx.stroke();}
    ctx.globalAlpha=1;}
  if(G.dev.fps){ctx.setTransform(DPR,0,0,DPR,0,0);ctx.font='700 11px "JetBrains Mono",monospace';ctx.textAlign='left';ctx.fillStyle='#00ff88';
    const txt=`FPS ${Math.round(fpsAvg)} · ВРАГИ ${G.enemies.length} · НАГРУЗКА ${enemyLoad().toFixed(1)} · СНАРЯДЫ ${G.pb.length}/${G.eb.length} · ЧАСТИЦЫ ${G.parts.length}`;
    ctx.fillText(txt,16,CH-70);}
}

// =====================================================================
// ---------- ОТКРЫТЫЙ СЕКТОР (0.2.0) ----------
// мир · сохранение · узлы · мастерская · находки · аномалии · патрули · карта · HUD мира
// =====================================================================
const WW0=10000,WH0=6000,OY=14000,WW=40000,WH=20000,FOG=400,FGW=Math.ceil(WW/FOG),FGH=Math.ceil(WH/FOG);
// ---------- Скины корабля (0.2.6) ----------
// у всех одинаковый хитбокс; скин меняет силуэт, детали, пламя, шлейф и цвет снарядов
const SKINS={
  base:{name:'Базовый',col:'#8fe9ff',bul:'#8fe9ff',trail:'#8fe9ff',d:'Стандартный разведкорабль экспедиции.',unlock:0},
  falcon:{name:'Сокол',col:'#ffb84d',bul:'#ffcf7a',trail:'#ff9a3d',d:'Обратная стреловидность и два форсажных двигателя.',unlock:3},
  manta:{name:'Скат',col:'#4dffd2',bul:'#7affe0',trail:'#2fd6b0',d:'Живые крылья волнами режут пустоту.',unlock:6},
  prism:{name:'Призма',col:'#e0d2ff',bul:'#ffffff',trail:'#e0d2ff',d:'Кристалл, который преломляет свет звёзд.',unlock:9},
  reaper:{name:'Жнец',col:'#ff3d5a',bul:'#ff6b81',trail:'#ff2a44',d:'Серп из закалённого сплава. Оставляет тлеющие искры.',unlock:12},
  halo:{name:'Ореол',col:'#ffe6a3',bul:'#fff2c9',trail:'#ffd36b',d:'Ядро, окружённое вечным кольцом.',unlock:15},
  comet:{name:'Комета',col:'#9fb8ff',bul:'#c9d6ff',trail:'#b48cff',d:'Ледяное ядро с хвостом на полнеба.',unlock:18},
  hornet:{name:'Шершень',col:'#ffd23d',bul:'#ffe27a',trail:'#ffb800',d:'Полосатый перехватчик с жалом и гудящими крыльями.',unlock:21},
  obsidian:{name:'Обсидиан',col:'#b48cff',bul:'#c9a6ff',trail:'#5a3a8c',d:'Стелс-корпус. Виден только по контуру.',unlock:24},
  sail:{name:'Солнечный парус',col:'#ffd77a',bul:'#fff0b0',trail:'#ffc94d',d:'Ловит звёздный ветер огромным парусом.',unlock:27},
  pulsar:{name:'Пульсар',col:'#ff6bd0',bul:'#6bf0ff',trail:'#ff6bd0',d:'Нейтронная звезда на поводке. Пульсирует.',unlock:30}
};
function curSkin(){const k=G.save&&G.save.skin;return SKINS[k]&&(!G.save.ownSkins||G.save.ownSkins.includes(k))?k:'base';}
function shipCol(){return SKINS[curSkin()].col;}
function shipBul(){return SKINS[curSkin()].bul;}
function flameTri(x,y,len,w,col){ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(x,y-w);ctx.lineTo(x-len,y);ctx.lineTo(x,y+w);ctx.closePath();ctx.fill();}
// рисует корабль в локальных координатах (нос смотрит вдоль +x)
function drawShip(id,t,sp,o){
  o=o||{};const S=SKINS[id]||SKINS.base,A=ctx.globalAlpha,fl=8+sp/30+Math.sin(t*50)*2,edge=o.noDash?'#6bf0ff':S.col;
  ctx.lineJoin='round';ctx.lineCap='round';
  if(w58DrawSkin(id,t,sp,o,A,fl,edge)||w74DrawSkin(id,t,sp,o,A,fl,edge)||w85DrawSkin(id,t,sp,o,A,fl,edge)||w90DrawSkin(id,t,sp,o,A,fl,edge)){ctx.globalAlpha=A;ctx.lineCap='butt';return;}
  switch(id){
    case 'falcon':{
      for(const s of [-1,1]){glow(-11,s*5,fl,'#ff9a3d',.8);flameTri(-9,s*5,fl*1.1,2.4,'#ffcf7a');}
      ctx.fillStyle='#1a1206';ctx.strokeStyle=edge;ctx.lineWidth=2;
      ctx.beginPath();ctx.moveTo(21,0);ctx.lineTo(6,-4);ctx.lineTo(-2,-16);ctx.lineTo(-8,-15);ctx.lineTo(-5,-6);ctx.lineTo(-12,-5);ctx.lineTo(-10,0);
      ctx.lineTo(-12,5);ctx.lineTo(-5,6);ctx.lineTo(-8,15);ctx.lineTo(-2,16);ctx.lineTo(6,4);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.fillStyle=S.col;for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(13,s*2);ctx.lineTo(8,s*8);ctx.lineTo(6,s*3);ctx.closePath();ctx.fill();}
      ctx.strokeStyle='#fff3d6';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(17,0);ctx.lineTo(-6,0);ctx.stroke();
      ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(8,0,2,0,TAU);ctx.fill();break;}
    case 'manta':{const w=Math.sin(t*6)*3;
      glow(-10,0,fl,'#2fd6b0',.7);
      ctx.strokeStyle='#4dffd2';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(-8,0);for(let i=1;i<=9;i++)ctx.lineTo(-8-i*2.6,Math.sin(t*8-i*.8)*i*.5);ctx.stroke();
      ctx.fillStyle='#04241f';ctx.strokeStyle=edge;ctx.lineWidth=2;
      ctx.beginPath();ctx.moveTo(16,0);ctx.quadraticCurveTo(8,-6,0,-8);ctx.quadraticCurveTo(-6,-18-w,-12,-17-w);ctx.quadraticCurveTo(-8,-8,-9,0);
      ctx.quadraticCurveTo(-8,8,-12,17+w);ctx.quadraticCurveTo(-6,18+w,0,8);ctx.quadraticCurveTo(8,6,16,0);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle='rgba(77,255,210,.45)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(4,-4);ctx.quadraticCurveTo(-4,-10,-9,-13-w*.7);ctx.moveTo(4,4);ctx.quadraticCurveTo(-4,10,-9,13+w*.7);ctx.stroke();
      ctx.fillStyle='#bfffee';ctx.beginPath();ctx.arc(9,-2.5,1.6,0,TAU);ctx.arc(9,2.5,1.6,0,TAU);ctx.fill();break;}
    case 'prism':{const h=(t*80)%360;
      glow(-10,0,fl,'#ffffff',.5);flameTri(-9,0,fl*1.1,3.5,`hsl(${(h+180)%360},100%,72%)`);
      const g=ctx.createLinearGradient(-10,-12,18,12);g.addColorStop(0,`hsla(${h},90%,66%,.92)`);g.addColorStop(.5,`hsla(${(h+120)%360},90%,66%,.92)`);g.addColorStop(1,`hsla(${(h+240)%360},90%,66%,.92)`);
      ctx.fillStyle=g;ctx.strokeStyle=o.noDash?'#6bf0ff':'#ffffff';ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-10,-13);ctx.lineTo(-10,13);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.strokeStyle='rgba(255,255,255,.6)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-1,0);ctx.lineTo(-10,-13);ctx.moveTo(-1,0);ctx.lineTo(-10,13);ctx.stroke();
      const k=(t*1.4)%1;ctx.fillStyle='#ffffff';ctx.globalAlpha=A*(1-k);ctx.beginPath();ctx.arc(17-k*24,-k*9,1.8,0,TAU);ctx.fill();ctx.globalAlpha=A;break;}
    case 'reaper':{
      glow(-6,0,fl*.9,'#ff2a44',.8);flameTri(-5,0,fl,2.6,'#ff6b81');
      ctx.fillStyle='#1a0408';ctx.strokeStyle=edge;ctx.lineWidth=2;
      ctx.beginPath();ctx.arc(0,0,17,-2.3,2.3);ctx.arc(-5,0,14,2.05,-2.05,true);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-6,0);ctx.lineTo(10,0);ctx.stroke();
      ctx.fillStyle='#ff3d5a';ctx.beginPath();ctx.arc(-3,0,3+Math.sin(t*6),0,TAU);ctx.fill();
      ctx.fillStyle='#ffd0d6';ctx.beginPath();ctx.arc(14,-6,1.3,0,TAU);ctx.arc(14,6,1.3,0,TAU);ctx.fill();break;}
    case 'halo':{const rot=t*1.2;
      glow(0,0,20,'#ffd36b',.6);glow(-9,0,fl*.8,'#ffd36b',.5);
      ctx.strokeStyle=edge;ctx.lineWidth=2.5;ctx.beginPath();ctx.ellipse(0,0,15,6,rot,0,TAU);ctx.stroke();
      ctx.fillStyle='#ffffff';for(let i=0;i<3;i++){const a=t*3+i*TAU/3,lx=15*Math.cos(a),ly=6*Math.sin(a);ctx.beginPath();ctx.arc(lx*Math.cos(rot)-ly*Math.sin(rot),lx*Math.sin(rot)+ly*Math.cos(rot),2,0,TAU);ctx.fill();}
      const g=ctx.createRadialGradient(0,0,0,0,0,8);g.addColorStop(0,'#ffffff');g.addColorStop(.6,'#ffe6a3');g.addColorStop(1,'#c99a3a');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,7,0,TAU);ctx.fill();
      ctx.fillStyle='#ffe6a3';ctx.beginPath();ctx.moveTo(16,0);ctx.lineTo(9,-3);ctx.lineTo(9,3);ctx.closePath();ctx.fill();break;}
    case 'comet':{const L=fl*2.2+10;const cols=['#b48cff','#9fb8ff','#ffffff'];
      for(let i=0;i<3;i++){ctx.strokeStyle=cols[i];ctx.globalAlpha=A*(.25+i*.22);ctx.lineWidth=7-i*2.2;ctx.beginPath();ctx.moveTo(2,0);
        for(let s=1;s<=10;s++)ctx.lineTo(-s*L/10,Math.sin(t*7-s*.7)*s*.45*(1-i*.3));ctx.stroke();}
      ctx.globalAlpha=A;
      const g=ctx.createRadialGradient(6,0,0,4,0,10);g.addColorStop(0,'#ffffff');g.addColorStop(.5,'#c9d6ff');g.addColorStop(1,'#6b7dff');
      ctx.fillStyle=g;ctx.strokeStyle=edge;ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(4,0,9,0,TAU);ctx.fill();ctx.stroke();
      ctx.fillStyle='rgba(255,255,255,.9)';ctx.beginPath();ctx.arc(7,-3,2,0,TAU);ctx.fill();break;}
    case 'hornet':{const wa=.3+.25*Math.sin(t*90);
      glow(-14,0,fl*.7,'#ffb800',.6);
      ctx.fillStyle=`rgba(220,240,255,${wa})`;ctx.beginPath();ctx.ellipse(1,-9,9,4,-.45,0,TAU);ctx.ellipse(1,9,9,4,.45,0,TAU);ctx.fill();
      ctx.strokeStyle='#ffd23d';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-14,0);ctx.lineTo(-22,0);ctx.stroke();
      ctx.save();ctx.beginPath();ctx.ellipse(-7,0,9,6,0,0,TAU);ctx.fillStyle='#141008';ctx.fill();ctx.clip();ctx.fillStyle='#ffd23d';for(let i=-2;i<3;i++)ctx.fillRect(-7+i*4.5-1.2,-7,2.4,14);ctx.restore();
      ctx.strokeStyle=edge;ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(-7,0,9,6,0,0,TAU);ctx.stroke();
      ctx.fillStyle='#141008';ctx.beginPath();ctx.ellipse(4,0,5,4.5,0,0,TAU);ctx.fill();ctx.stroke();
      ctx.fillStyle='#ffd23d';ctx.beginPath();ctx.arc(11,0,3.6,0,TAU);ctx.fill();
      ctx.fillStyle='#141008';ctx.beginPath();ctx.arc(12.5,-1.6,1.2,0,TAU);ctx.arc(12.5,1.6,1.2,0,TAU);ctx.fill();break;}
    case 'obsidian':{const fk=.55+.45*Math.abs(Math.sin(t*3));
      glow(-10,0,fl*.6,'#5a3a8c',.6);flameTri(-9,0,fl*.6,2,'#7c5cff');
      ctx.fillStyle='#050308';ctx.beginPath();ctx.moveTo(21,0);ctx.lineTo(3,-6);ctx.lineTo(-5,-17);ctx.lineTo(-13,-7);ctx.lineTo(-9,0);ctx.lineTo(-13,7);ctx.lineTo(-5,17);ctx.lineTo(3,6);ctx.closePath();ctx.fill();
      ctx.strokeStyle=edge;ctx.globalAlpha=A*fk;ctx.lineWidth=1.4;ctx.stroke();ctx.globalAlpha=A;
      ctx.strokeStyle='rgba(180,140,255,.35)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(3,-6);ctx.lineTo(-9,0);ctx.lineTo(3,6);ctx.moveTo(21,0);ctx.lineTo(-9,0);ctx.stroke();
      ctx.fillStyle='#c9a6ff';ctx.globalAlpha=A*fk;ctx.fillRect(6,-1,7,2);ctx.globalAlpha=A;break;}
    case 'sail':{
      glow(-13,0,fl*.8,'#ffc94d',.7);flameTri(-12,0,fl,2.2,'#fff0b0');
      ctx.save();ctx.translate(-2,0);ctx.rotate(Math.PI/4);
      const g=ctx.createLinearGradient(-11,-11,11,11);g.addColorStop(0,'rgba(255,215,122,.18)');g.addColorStop(.5,'rgba(255,240,176,.6)');g.addColorStop(1,'rgba(255,201,77,.22)');
      ctx.fillStyle=g;ctx.fillRect(-11,-11,22,22);ctx.strokeStyle=edge;ctx.lineWidth=1.2;ctx.strokeRect(-11,-11,22,22);
      ctx.save();ctx.beginPath();ctx.rect(-11,-11,22,22);ctx.clip();const k=((t*.8)%1)*44-22;ctx.strokeStyle='rgba(255,255,255,.85)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(k,-11);ctx.lineTo(k-8,11);ctx.stroke();ctx.restore();
      ctx.restore();
      ctx.strokeStyle='rgba(255,240,176,.5)';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(-2,-15.5);ctx.lineTo(8,0);ctx.lineTo(-2,15.5);ctx.stroke();
      ctx.strokeStyle='#fff0b0';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(20,0);ctx.lineTo(-14,0);ctx.stroke();
      ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(20,0,2,0,TAU);ctx.fill();break;}
    case 'pulsar':{
      for(let i=0;i<2;i++){const k=((t*1.2+i*.5)%1);ctx.strokeStyle='#6bf0ff';ctx.globalAlpha=A*(1-k)*.6;ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(0,0,6+k*18,0,TAU);ctx.stroke();}
      ctx.globalAlpha=A;glow(-8,0,fl*.7,'#ff6bd0',.6);glow(0,0,16,'#ff6bd0',.5);
      ctx.save();ctx.rotate(t*2.5);for(let i=0;i<4;i++){ctx.rotate(Math.PI/2);ctx.fillStyle=i%2?'#ff6bd0':'#6bf0ff';ctx.beginPath();ctx.moveTo(4,-2.6);ctx.lineTo(16,0);ctx.lineTo(4,2.6);ctx.closePath();ctx.fill();}ctx.restore();
      const g=ctx.createRadialGradient(0,0,0,0,0,7);g.addColorStop(0,'#ffffff');g.addColorStop(.5,'#ffc2ec');g.addColorStop(1,'#ff6bd0');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,6+Math.sin(t*10)*.8,0,TAU);ctx.fill();
      ctx.strokeStyle=edge;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(10,-3);ctx.lineTo(19,0);ctx.lineTo(10,3);ctx.stroke();break;}
    default:{
      glow(-12,0,fl*1.2,'#5fc8ff',.8);flameTri(-8,0,fl,4,S.col);
      ctx.fillStyle='#0c1828';ctx.strokeStyle=edge;ctx.lineWidth=2;
      ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(5,0,2.5,0,TAU);ctx.fill();}
  }
  ctx.globalAlpha=A;ctx.lineCap='butt';
}
// ---- ангар «Зеркало» ----
function openHangar(){if(G.state!=='world')return;scr6('hangar');renderHangar();show('sHangar');}
// ---- 0.7.0: Арсенал ----
function openArsenal(){if(G.state!=='world'||!arsOpen())return;const S=G.save;if(S&&!S.ars)S.ars=arsDef();scr6('arsenal');G.arsArm=null;renderArsenal();show('sArsenal');saveWorld();}
function closeArsenal(){if(G.state!=='arsenal')return;scr6('world');G.cardKey=null;G.arsArm=null;computeStats();show('');}
const f1=v=>(Math.round(v*10)/10).toFixed(1).replace('.',',');
function arsStat(w,lv){const dmg=10*arsMul(w,'pow',lv.pow),rate=w==='gun'?(1/.27)*arsMul('gun','rate',lv.rate):(1/.27)/1.6,R=110*arsMul('blast','rad',lv.rad||0);return {dmg,rate,R};}
function renderArsenal(){const S=G.save;if(!S)return;const A=S.ars||(S.ars=arsDef());if(G.arsArm&&performance.now()-G.arsArmT>6000)G.arsArm=null;
  $('#arsLom').innerHTML=`ЛОМ ${lomH(S.lom,1)}`;
  const card=w=>{const W=ARS[w],own=!!A.own[w],cur=A.weapon===w&&own,lv=A.lv[w],st=arsStat(w,lv);
    const stats=w==='gun'?`УРОН ${f1(st.dmg)} · ТЕМП ${f1(st.rate)} ВЫСТР./С`:`ВЗРЫВ ${f1(st.dmg*1.4)} В ЦЕНТРЕ · ТЕМП ${f1(st.rate)} ВЫСТР./С · РАДИУС ${Math.round(st.R)}`;
    const tracks=Object.entries(W.tracks).map(([t,T])=>{const n=lv[t]||0;const curV=t==='pow'?st.dmg*(w==='blast'?1.4:1):t==='rate'?st.rate:st.R,nxt=n<3?curV*T.k[n]:null;
      const segs=T.k.map((k,i)=>{const can=own&&i===n,cost=T.cost[i],arm=G.arsArm===w+':'+t,poor=can&&S.lom<cost;
        return `<button class="ars-seg ${i<n?'f':i===n?'next':''} ${poor?'poor':''} ${arm&&can?'arm':''}" data-buy="${w}:${t}" ${can?'':'disabled'} aria-label="${T.name} ступень ${i+1}">${i<n?'✓ '+(i+1):arm&&can?'ПОДТВЕРДИТЬ':lomH(cost)}</button>`;}).join('');
      return `<div class="ars-track" data-t="${t}"><div class="ars-tl"><span>${T.name}</span><span>${n}/3</span></div><div class="ars-segs">${segs}</div><div class="ars-after">${!own?'сначала купите оружие':n<3?'':'максимум'}</div></div>`;}).join('');
    const arm=G.arsArm==='w:'+w,btn=!own?`<button class="wbtn amber ars-buyw ${S.lom<W.price?'poor':''} ${arm?'arm':''}" data-buyw="${w}">${arm?'ПОДТВЕРДИТЬ · ':'КУПИТЬ ОРУЖИЕ · '}${lomH(W.price)}</button>`:cur?`<button class="wbtn" disabled>АКТИВНО</button>`:`<button class="wbtn" data-pickw="${w}">ВЫБРАТЬ</button>`;
    return `<div class="ars-card ${cur?'cur':''}" data-w="${w}"><div class="eyebrow">${W.name}${cur?' · АКТИВНО':own?' · КУПЛЕНО':' · '+lomH(W.price)}</div><canvas class="ars-demo" data-demo="${w}" width="440" height="220" aria-hidden="true"></canvas><p class="note">${W.d}</p>${tracks}<div class="wc-row">${btn}</div></div>`;};
  $('#arsCards').innerHTML=card('gun')+card('blast');const m=$('#arsMsg');if(m)m.textContent=G.arsMsgT||'';G.arsMsgT='';}
function arsBuy(key){const S=G.save,A=S.ars;if(!A)return false;
  if(key.startsWith('w:')){const w=key.slice(2),W=ARS[w];if(A.own[w])return false;if(S.lom<W.price){G.arsMsgT='НЕ ХВАТАЕТ '+(W.price-S.lom)+' ЛОМА';sfx('block');return false;}S.lom-=W.price;A.own[w]=1;A.weapon=w;}
  else{const [w,t]=key.split(':'),T=ARS[w].tracks[t],n=A.lv[w][t]||0;if(!A.own[w]||n>=3)return false;const cost=T.cost[n];if(S.lom<cost){G.arsMsgT='НЕ ХВАТАЕТ '+(cost-S.lom)+' ЛОМА';sfx('block');return false;}S.lom-=cost;A.lv[w][t]=n+1;}
  G.arsArm=null;computeStats();saveWorld();sfx('level');buzz('win');return true;}
document.addEventListener('click',e=>{if(G.state!=='arsenal')return;const S=G.save;if(!S||!S.ars)return;
  const b=e.target.closest('[data-buy],[data-buyw],[data-pickw]');if(!b||b.disabled)return;
  if(b.dataset.pickw){S.ars.weapon=b.dataset.pickw;computeStats();saveWorld();buzz('tap');renderArsenal();return;}
  const key=b.dataset.buyw?'w:'+b.dataset.buyw:b.dataset.buy;
  if(G.arsArm===key){arsBuy(key);}else{G.arsArm=key;G.arsArmT=performance.now();buzz('tap');}renderArsenal();});
// живые демонстрации выстрела
function arsDemoTick(now){const S=G.save;if(!S||!S.ars)return;const t=now/1000;
  document.querySelectorAll('#arsCards .ars-demo').forEach(c=>{const w=c.dataset.demo,g=c.getContext('2d'),W=c.width,H=c.height,lv=S.ars.lv[w],st=arsStat(w,lv);g.clearRect(0,0,W,H);
    g.fillStyle='#030710';g.fillRect(0,0,W,H);g.strokeStyle='#10213a';g.lineWidth=1;for(let x=0;x<W;x+=40){g.beginPath();g.moveTo(x,0);g.lineTo(x,H);g.stroke();}
    const sx=60,sy=H/2;g.fillStyle='#8fe9ff';g.beginPath();g.moveTo(sx+16,sy);g.lineTo(sx-12,sy-11);g.lineTo(sx-6,sy);g.lineTo(sx-12,sy+11);g.closePath();g.fill();
    const tg=[[W-70,sy-52],[W-60,sy],[W-74,sy+50]];const cyc=w==='gun'?1.2:2.4,ph=(t%cyc)/cyc;
    if(w==='gun'){const gap=Math.max(28,90*3.7/st.rate);const th=1.5+(st.dmg/10-1)*2;g.strokeStyle='#8fe9ff';g.lineWidth=th;for(let x=sx+20+(ph*gap)%gap;x<W-80;x+=gap){g.beginPath();g.moveTo(x-16,sy);g.lineTo(x,sy);g.stroke();}
      for(const [x,y] of tg){const hit=Math.abs(y-sy)<8&&((t*st.rate)%1)<.25;g.strokeStyle=hit?'#ffffff':'#ff4f6e';g.lineWidth=2;g.beginPath();g.arc(x,y,12,0,TAU);g.stroke();if(hit){g.fillStyle='rgba(255,255,255,.35)';g.fill();}}}
    else{const fx=sx+20+ph*(W-sx-120)/.6,R=st.R*.55;const expl=ph>.6;const ex=W-90,ey=sy;
      if(!expl){g.fillStyle='#dff6ff';g.beginPath();g.arc(Math.min(fx,ex),sy,5,0,TAU);g.fill();g.strokeStyle='#9fe3ff';g.lineWidth=2;g.beginPath();g.moveTo(Math.min(fx,ex)-18,sy);g.lineTo(Math.min(fx,ex),sy);g.stroke();}
      else{const q=(ph-.6)/.4;g.strokeStyle=`rgba(159,227,255,${1-q})`;g.lineWidth=3;g.beginPath();g.arc(ex,ey,R*Math.min(1,q*1.6),0,TAU);g.stroke();g.fillStyle=`rgba(159,227,255,${.25*(1-q)})`;g.fill();}
      for(const [x,y] of tg){const d=Math.hypot(x-ex,y-ey),hit=expl&&d<R*Math.min(1,(ph-.6)/.4*1.6);g.strokeStyle=hit?'#ffffff':'#ff4f6e';g.lineWidth=2;g.beginPath();g.arc(x,y,12,0,TAU);g.stroke();if(hit){g.fillStyle='rgba(255,255,255,.35)';g.fill();}}
      g.strokeStyle='rgba(159,227,255,.25)';g.setLineDash([4,4]);g.beginPath();g.arc(ex,ey,R,0,TAU);g.stroke();g.setLineDash([]);}
  });}
function closeHangar(){if(G.state!=='hangar')return;scr6('world');G.cardKey=null;show('');}
function renderHangar(){
  const cur=curSkin(),Sv=G.save,lv=Sv.pilot.lvl;
  $('#hangarNote').innerHTML=`Уровень пилота ${lv} · ${lomH(Sv.lom,1)}<br>Скины открываются уровнем пилота и покупаются за лом.`;
  $('#skinGrid').innerHTML=Object.entries(SKINS).map(([k,S])=>{const own=Sv.ownSkins.includes(k),q=skinReq(k),lock=!own&&lv<q.lvl;
    const tag=k==='base'?'СТАНДАРТ':own?'В ХРАНИЛИЩЕ':S.find?'СКРЫТО':lock?'УРОВЕНЬ '+q.lvl:lomH(q.cost);
    const btn=k===cur?`<button class="wbtn" disabled>ВЫБРАН</button>`:own?`<button class="wbtn amber" data-pick="${k}">ВЫБРАТЬ</button>`:S.find?`<button class="wbtn" disabled>НАЙТИ · ${S.find}</button>`:
      lock?`<button class="wbtn" disabled>ЗАКРЫТ · УРОВЕНЬ ${q.lvl}</button>`:`<button class="wbtn amber" data-buy="${k}" ${Sv.lom<q.cost?'disabled':''}>КУПИТЬ · ${lomH(q.cost)}</button>`;
    const [wn,wm]=skinWrecks(k);
    return `<div class="skincard ${k===cur?'on':''} ${lock?'lock':''}"><canvas data-prev="${k}" width="320" height="200"></canvas>
    <div class="sc-h"><b>${S.name}</b><span class="${lock?'need':'free'}">${tag}</span></div><p>${S.d}</p>${wm?`<p class="wcnt">Обломков найдено: ${wn}/${wm}</p>`:''}${btn}</div>`;}).join('');
}
$('#skinGrid').addEventListener('click',e=>{const S=G.save;if(!S)return;const b=e.target.closest('[data-pick],[data-buy]');if(!b||b.disabled)return;
  if(b.dataset.buy){const k=b.dataset.buy,q=skinReq(k);if(S.ownSkins.includes(k)||S.pilot.lvl<q.lvl||S.lom<q.cost||SKINS[k].find)return;S.lom-=q.cost;S.ownSkins.push(k);S.skin=k;banner('СКИН КУПЛЕН',SKINS[k].name.toUpperCase());}
  else{const k=b.dataset.pick;if(!S.ownSkins.includes(k))return;S.skin=k;}
  saveWorld();sfx('level');renderHangar();});
function drawHangarPreviews(now){
  const t=now/1000,real=ctx;
  document.querySelectorAll('canvas[data-prev]').forEach((c,i)=>{
    const g=c.getContext('2d'),id=c.dataset.prev,S=SKINS[id];ctx=g;
    try{g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';g.fillStyle='#070c16';g.fillRect(0,0,320,200);
      for(let s=0;s<26;s++){const x=((s*97+i*31)-t*40*(1+s%3))%340,xx=x<0?x+340:x;g.fillStyle=s%3?'#2a3a55':'#7f9ab5';g.fillRect(xx-10,(s*53+i*17)%200,1.5,1.5);}
      const bob=Math.sin(t*1.6+i)*6,ang=-.35+Math.sin(t*.9+i)*.12;
      g.setTransform(3.2,0,0,3.2,165,100+bob);
      for(let k=1;k<=9;k++)glow(-Math.cos(ang)*k*6,-Math.sin(ang)*k*6,7-k*.5,S.trail,.5*(1-k/10));
      g.rotate(ang);drawShip(id,t+i,260,{});
    }catch(err){console.error(err);}finally{ctx=real;g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;}
  });
}

const PERKS={
  hull:{name:'Усиленный корпус',max:3,cost:[100,180,280],d:'+10 к прочности корпуса за уровень.'},
  aim:{name:'Пристрелка',max:3,cost:[120,200,300],d:'+5% к урону основного орудия и заряженного выстрела за уровень.'},
  reserve:{name:'Резерв модулей',max:3,cost:[150,250,400],d:'+1 стартовый модуль на брифинге за уровень.'},
  pre:{name:'Предзаряд',max:2,cost:[120,220],d:'Миссия начинается с заряженным накопителем: 30%, затем 60%.'},
  dash:{name:'Резерв рывка',max:2,cost:[120,220],d:'Перезарядка рывка короче на 0,15 с за уровень.'},
  mag:{name:'Гравиядро',max:2,cost:[60,120],d:'Радиус подбора +25 за уровень.'},
  pilot:{name:'Опытный пилот',max:2,cost:[140,240],d:'+10% к опыту модулей в миссиях за уровень.'},
  regen:{name:'Ремонт в секторе',max:2,cost:[160,260],d:'Через 3 с без урона корпус чинится: 0,5, затем 1 ед./с. Не действует в секторах III–IV (миссии 11–18).'},
  energy:{name:'Энергоконтур',max:2,cost:[100,180],d:'+15% к набору энергии импульса за уровень.'},
  combo:{name:'Боевой ритм',max:3,cost:[150,250,350],d:'Комбо: уничтожения с интервалом до 2,5 с повышают опыт модулей на 5% за звено. Предел ×1,5 / ×1,75 / ×2. Работает и в Бесконечности.'},
  scan:{name:'Сканер',max:1,cost:[600],d:'Тайники и непрочитанные бортжурналы видны на мини-карте с 1600 единиц (6,4 а.е.), а на большой карте — знаком «?» в радиусе 2400.'},
  twin:{name:'Сдвоенный ствол',max:1,cost:[1500],d:'Каждый снаряд основного орудия вылетает парой из двух стволов, урон каждого ×0,65 — итого ×1,3. Складывается с «Веерным залпом». В Бесконечности не действует.',req:4},
  bcar:{name:'Бронеплиты маяка',max:2,cost:[150,250],d:'+60 к целостности маяка в миссиях 7–10.',req:6},
  cargo:{name:'Грузовой отсек',max:1,cost:[180],d:'+1 место в трюме для энергоячеек.',req:6}
};
const MASTERY_GEN=[{t:'Без единого рывка',ok:()=>G.mc.dashes===0},{t:'Подобрать 3 энергоячейки',ok:()=>G.mc.cells>=3},{t:'Дважды применить импульс',ok:()=>G.mc.pulses>=2},{t:'Урон корпусу меньше 20',ok:()=>G.taken-G.missionTaken<20}];
const MASTERY=[
  {t:'Без единого рывка',ok:()=>G.mc.dashes===0},
  {t:'Подобрать 3 энергоячейки',ok:()=>G.mc.cells>=3},
  {t:'Дважды применить импульс',ok:()=>G.mc.pulses>=2},
  {t:'5 уничтожений по приоритетной цели',ok:()=>G.mc.prioKills>=5},
  {t:'Ни одного попадания луча копейщика',ok:()=>G.mc.lanceHits===0},
  {t:'Победить Стража за 3 перегрузки',ok:()=>G.mc.overloads<=3},
  {t:'Маяк цел минимум на 80%',ok:()=>!!G.bc&&G.bc.hp>=G.bc.maxHp*.8},
  {t:'Все линии ретрансляторов целы к концу',ok:()=>G.relays.every(r=>!r.cut)},
  {t:'Маяк цел минимум на 60%',ok:()=>!!G.bc&&G.bc.hp>=G.bc.maxHp*.6},
  {t:'Передача без единой паузы',ok:()=>!G.mc.transPaused}
];
const WORLD={
  nodes:[{m:1,x:700,y:3000},{m:2,x:1500,y:1800},{m:3,x:2600,y:2700},{m:4,x:3200,y:1300},{m:5,x:4000,y:2300},{m:6,x:4200,y:4300},
         {m:7,x:5900,y:3100},{m:8,x:6900,y:1900},{m:9,x:8100,y:3400},{m:10,x:9200,y:1700}],
  hangar:{x:3450,y:2550,name:'АНГАР «ЗЕРКАЛО»'},
  abyss:{x:9550,y:2550},
  shops:[{id:'s1',x:1250,y:4000,name:'МАСТЕРСКАЯ «ОБОД»'},{id:'s2',x:6300,y:4500,name:'МАСТЕРСКАЯ «ГОРИЗОНТ»'}],
  relays:[{id:'r1',x:2500,y:650},{id:'r2',x:7700,y:5150}],
  caches:[{id:'c1',x:380,y:900,skin:'amber'},{id:'c2',x:3600,y:5300,skin:'violet'},{id:'c3',x:7300,y:560,skin:'crimson'},{id:'c4',x:9450,y:5250,skin:'white'}],
  journals:[
    {id:'j1',x:950,y:2250,title:'«ИНЕЙ-4» · ЗАПИСЬ 112',text:'Мы приняли сигнал за маяк и шли на свет. Поняли слишком поздно: он светил не нам.'},
    {id:'j2',x:2150,y:2350,title:'ПИЛОТ СОРЕЛЬ',text:'Разведчики почти не стреляют. Они считают. Каждый наш манёвр куда-то уходит — к ядру.'},
    {id:'j3',x:3800,y:3600,title:'ИНЖЕНЕР ВАРГА',text:'Заряды Стража — не броня, а предохранители. Сними их, и ядро захлебнётся собственной мощностью.'},
    {id:'j4',x:3000,y:450,title:'НЕИЗВЕСТНЫЙ ПИЛОТ',text:'Гвардия разворачивается медленно. Мы жили, пока летали кругами. Потом кончилось топливо.'},
    {id:'j5',x:4650,y:3700,title:'ПОГРАНИЧНЫЙ БУЙ',text:'Ворота держат два замка. Ставили их не мы. Открываются только тем, кто прошёл ядро.'},
    {id:'j6',x:5650,y:4050,title:'СМОТРИТЕЛЬ «ГОРИЗОНТА»',text:'Маяк не гаснет. Он просто перестал быть нужен — некому было слушать.'},
    {id:'j7',x:7250,y:3050,title:'ГРУЗОВОЙ ДРОН Т-9',text:'Пиявки пришли после третьей вспышки. Металл им не нужен. Они едят свет.'},
    {id:'j8',x:9650,y:3050,title:'ПОСЛЕДНЯЯ ЗАПИСЬ СТАНЦИИ',text:'Глушитель — не корабль. Это тишина, которой придали форму. Если ты это слышишь, значит, у тебя получилось.'}],
  anomalies:[{id:'a1',x:2000,y:4850,kind:'cells',name:'РОССЫПЬ',d:'Соберите 8 из 10 энергоячеек за 22 секунды. Ячейки дрейфуют и убегают от корабля — берите рывком. Вокруг мины.'},
             {id:'a2',x:6100,y:850,kind:'storm',name:'ИОННЫЙ ВИХРЬ',d:'30 секунд в сжимающемся круге: кольца снарядов всё чаще, с 12-й секунды — два вращающихся луча. Рывок перезаряжается вдвое дольше.'},
             {id:'a3',x:8800,y:4400,kind:'chase',name:'ПОГОНЯ',d:'Похититель быстрее вас, бронирован, делает фазовые рывки, роняет мины и летит с двумя стрелками. 25 секунд.'}],
  zones:[
    {x:1150,y:2350,req:1,set:{scout:5}},
    {x:2250,y:1050,req:2,set:{scout:4,gunner:2}},
    {x:3300,y:3500,req:3,set:{rammer:2,splitter:2,scout:2}},
    {x:4000,y:700,req:4,set:{gunner:3,scout:4,rammer:1}},
    {x:2700,y:5000,req:5,set:{lancer:2,gunner:2,scout:4}},
    {x:4450,y:3000,req:6,set:{guard:2,gunner:3,scout:4},gate:true},
    {x:6500,y:2450,req:7,set:{moth:10,scout:3}},
    {x:7700,y:2650,req:8,set:{phantom:2,gunner:3,scout:3}},
    {x:6900,y:5200,req:8,set:{rammer:3,splitter:2,mirror:1}},
    {x:8600,y:4900,req:9,set:{shocker:2,phantom:2,mirror:1,scout:2}},
    {x:9500,y:900,req:10,set:{twin:2,hunter:1,mirror:1,scout:3}}],
  fields:[{x:380,y:900,r:520,n:26},{x:2900,y:4000,r:480,n:16},{x:4350,y:1700,r:420,n:12},{x:7300,y:560,r:520,n:24},{x:5600,y:1300,r:480,n:16},{x:8500,y:2500,r:450,n:14},{x:7000,y:4750,r:450,n:14}],
  minefields:[{x:3600,y:5300,r:520,n:18}],
  dark:[{x:9350,y:5050,r:1000}],
  gate:{x:5000,y:3000},
  locks:[[4820,2640],[4820,3360]]
};
for(let m=11;m<=50;m++)MASTERY.push(MASTERY_GEN[m%4]);
MASTERY[21]={t:'Порвать все четыре пуповины за 30 с',ok:()=>!!G.mc&&G.mc.cord74!==undefined&&G.mc.cord74<=30};MASTERY[26]={t:'Ни одного попадания «по двигателям»',ok:()=>!!G.mc&&!G.mc.eng74};
const SECTOR_NAMES=['ПОЯС СТРАЖА','ДРЕЙФ МАЯКА',...SECTORS_NEW.map(q=>q.name)];
// ---- 0.4: мир 40 000 × 20 000; старые сектора сдвинуты вниз на OY ----
(function shiftWorld(){const sh=o=>{o.y+=OY;};const W_=WORLD;[...W_.nodes,...W_.shops,...W_.relays,...W_.caches,...W_.journals,...W_.anomalies,...W_.zones,...W_.fields,...W_.minefields,...W_.dark].forEach(sh);
  sh(W_.hangar);sh(W_.abyss);sh(W_.gate);W_.locks.forEach(l=>l[1]+=OY);})();
WORLD.sectors=[{name:SECTOR_NAMES[0],box:[0,OY,5000,OY+WH0],col:'#8fe9ff'},{name:SECTOR_NAMES[1],box:[5000,OY,WW0,OY+WH0],col:'#ffb84d'}];
WORLD.fields2=[];
const SEC_Y0=[12000,8500,11000,7000,9500,13000,9500,6000,8000],SEC_W=[3400,3200,3500,3300,3200,3700,3300,3400,3000];
{let xs=10000;SECTORS_NEW.forEach((q,k)=>{if(k>=9)return;const x0=xs,x1=x0+SEC_W[k],y0=SEC_Y0[k],y1=y0+5500,R=mulberry(900+k*13);xs=x1;
  const prev=k===0?[OY,OY+WH0]:[SEC_Y0[k-1],SEC_Y0[k-1]+5500],next=k<8?[SEC_Y0[k+1],SEC_Y0[k+1]+5500]:[y0+1500,y1-1500];
  const ey=(Math.max(y0,prev[0])+Math.min(y1,prev[1]))/2,xy=(Math.max(y0,next[0])+Math.min(y1,next[1]))/2;
  const sc={name:q.name,box:[x0,y0,x1,y1],col:q.col,bx:x0+430,by:clamp(ey,y0+600,y1-600),lv:q.lv};WORLD.sectors.push(sc);
  const n=q.lv[1]-q.lv[0]+1;
  for(let i=0;i<n;i++){const f=(i+1)/n,x=x0+900+(x1-x0-1400)*f,zig=(i%2?1:-1)*(n>5?650:450)*(i===n-1?0:1);
    const y=clamp(ey+(xy-ey)*f+zig+(R()-.5)*250,y0+600,y1-600);
    WORLD.nodes.push({m:q.lv[0]+i,x:Math.round(x+(R()-.5)*(i===n-1?0:200)),y:Math.round(y),boss:BOSS_LV.has(q.lv[0]+i),sec:k+2});}
  for(let i=0;i<2;i++)WORLD.fields2.push({x:x0+800+R()*(x1-x0-1600),y:y0+1200+R()*(y1-y0-2400),r:350+R()*200,n:12+Math.floor(R()*8)});});}
world110Setup();
// 0.7.0: Арсенал «Иней» — рядом с узлом 14, внутри сектора III, не ближе 520 к другим узлам
{const n14=WORLD.nodes.find(n=>n.m===14),b=WORLD.sectors[2].box;let best=null;for(const [dx,dy] of [[-650,-520],[-650,520],[650,-520],[-900,0],[650,520],[0,-800]]){const x=n14.x+dx,y=n14.y+dy;if(x<b[0]+450||x>b[2]-450||y<b[1]+450||y>b[3]-450)continue;if(WORLD.nodes.some(q=>q!==n14&&Math.hypot(q.x-x,q.y-y)<520))continue;best={x,y};break;}
  if(!best)best={x:clamp(n14.x-650,b[0]+450,b[2]-450),y:clamp(n14.y-520,b[1]+450,b[3]-450)};WORLD.arsenal={x:Math.round(best.x),y:Math.round(best.y),name:'АРСЕНАЛ «ИНЕЙ»'};}
function sectorIdx(x,y){const S_=WORLD.sectors;for(let i=0;i<S_.length;i++){const b=S_[i].box;if(x>=b[0]&&x<=b[2]&&y>=b[1]&&y<=b[3])return i;}
  let bi=0,bd=1e12;for(let i=0;i<S_.length;i++){const b=S_[i].box,dx=Math.max(b[0]-x,0,x-b[2]),dy=Math.max(b[1]-y,0,y-b[3]),d=dx*dx+dy*dy;if(d<bd){bd=d;bi=i;}}return bi;}
const sectorName=(x,y)=>WORLD.sectors[sectorIdx(x,y)].name;
function inSectors(x,y){return WORLD.sectors.some(q=>x>=q.box[0]&&x<=q.box[2]&&y>=q.box[1]&&y<=q.box[3]);}
const doneCount=()=>{let n=0;for(const q of WORLD.nodes)if(nodeState(q.m)==='done')n++;return n;};
function perk(k){return G.mode==='world'&&G.save&&G.save.perks?(G.save.perks[k]||0):0;}
// ===== 0.7.0: Арсенал «Иней» — прокачка орудия и второе оружие =====
const ARS={
  gun:{name:'ОРУДИЕ',d:'Основное орудие: быстрый одиночный снаряд, работает с пробитием, рикошетом и сдвоенным стволом.',tracks:{
    pow:{name:'СИЛА',k:[1.2,1.3,1.4],cost:[2000,3000,4000]},rate:{name:'ТЕМП',k:[1.1,1.2,1.3],cost:[1500,2500,3500]}}},
  blast:{name:'РАЗРЫВ',price:5000,d:'Снаряд не бьёт в точку, а детонирует при касании: урон всем в радиусе, сильнее в центре. Темп ниже, пробитие и рикошет не действуют.',tracks:{
    pow:{name:'МОЩНОСТЬ',k:[1.2,1.3,1.4],cost:[2000,3000,4000]},rad:{name:'РАДИУС',k:[1.15,1.2,1.25],cost:[1500,2500,3500]}}}};
const BOSS_TROPHY={14:2000,18:3000,22:4000,27:5000,31:6000,38:7000,42:8000,46:9000,50:10000};
function arsDef(){return {weapon:'gun',own:{gun:1,blast:0},lv:{gun:{pow:0,rate:0},blast:{pow:0,rad:0}}};}
function arsMul(w,t,n){const k=ARS[w].tracks[t].k;let m=1;for(let i=0;i<Math.min(n||0,k.length);i++)m*=k[i];return m;}
function arsK(w,t){const S=G.save;if(G.mode!=='world'||!S||!S.ars||!S.ars.lv[w])return 1;return arsMul(w,t,S.ars.lv[w][t]||0);}
function arsWeapon(){const S=G.save;return G.mode==='world'&&S&&S.ars&&S.ars.weapon==='blast'&&S.ars.own.blast?'blast':'gun';}
function arsOpen(){const S=G.save;return !!(S&&S.medals&&S.medals[14]&&S.medals[14].clear);}
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function newSave(){const n=WORLD.nodes[0];return{v:2,wv:2,pilot:{lvl:1,xp:0},ownSkins:['base'],contracts:{list:[],done:0},cycle:1,rocksGone:[],zonesDone:{},bestDiff:{},diff:'easy',cleared:0,medals:{},lom:0,carry:0,perks:{},skins:['base'],skin:'base',found:{},journals:{},anomalies:{},relays:{},gate:false,reveal:'',
  pos:{x:n.x-260,y:n.y+90},last:{x:n.x-260,y:n.y+90},run:{mods:{},lvl:1,xp:0,need:need(1),hp:100,en:0,score:0,kills:0,taken:0},replays:{},lost:null,best:{},intro:false};}
function validSave(S){return !!S&&typeof S==='object'&&!Array.isArray(S)&&(S.v===1||S.v===2)&&!!S.run&&typeof S.run==='object'&&Number.isFinite(+S.cleared)&&!!S.pos&&typeof S.pos==='object'&&!!S.medals&&typeof S.medals==='object';}
function saveWorld(){
  const S=G.save;if(!S)return;const p=G.player;
  if(G.world&&p&&p.hp>0)S.pos={x:Math.round(p.x),y:Math.round(p.y)};
  if(G.fog)S.reveal=Array.from(G.fog).join('');
  S.run={mods:{...G.mods},lvl:G.lvl,xp:G.xp,need:G.need,hp:p?Math.max(1,Math.round(p.hp)):100,en:p?p.en:0,score:G.score,kills:G.kills,taken:G.taken};
  store(saveKey(),S);
}
// 1.0.0 α: туман войны. Миссия открыта, только если пройдена предыдущая. Сектор закрыт туманом, пока не пройдена последняя миссия
// предыдущего сектора; стена тумана на всю высоту мира не пускает за кромку (облететь сверху нельзя). Сектор II — ещё и ворота с двумя замками.
function openAllNow(){return ALPHA_OPEN||G.mode==='dev'||!!(window.DEVW&&DEVW.on&&DEVW.on());}
function progDone(m){const S=G.save;if(!S||!m)return false;if(m<=CORE&&+S.cleared>=m)return true;if(S.medals&&S.medals[m]&&S.medals[m].clear)return true;return m===49&&!!(S.story&&S.story.zero49);}
function secOfM(m){if(m<=6)return 0;if(m<=CORE)return 1;const n=WORLD.nodes[m-1];return n&&n.sec!==undefined?n.sec:1;}
const SEC_LAST={};function secLastM(i){if(SEC_LAST[i]!==undefined)return SEC_LAST[i];let r=0;for(const n of WORLD.nodes)if(secOfM(n.m)===i)r=Math.max(r,n.m);return SEC_LAST[i]=r;}
function secSeen(i){if(openAllNow()||i<=0)return true;if(i===1)return progDone(6);if(i===11)return zeroOpen110();return progDone(secLastM(i-1));}
function secOpen(i){return secSeen(i)&&(i!==1||openAllNow()||gateOpen());}
const FOGC={k:null};
function fogMemo(){const S=G.save;let nc=0;if(S&&S.medals)for(const k in S.medals)if(S.medals[k]&&S.medals[k].clear)nc++;
  const k=S?[openAllNow()?1:0,S.cleared,S.gate?1:0,nc,S.story&&S.story.zero49?1:0,G.dev&&G.devZero110?1:0].join('|'):'-';if(FOGC.k===k&&FOGC.s===S)return FOGC;
  FOGC.k=k;FOGC.s=S;const by=f=>{if(!S||openAllNow()||!WORLD.sectors)return Infinity;for(let i=1;i<=10;i++)if(!f(i))return i===1?5000:WORLD.sectors[i].box[0];return Infinity;};
  FOGC.x=by(secOpen);FOGC.sx=by(secSeen);FOGC.z=!S||secSeen(11);FOGC.i=-1;for(let i=1;i<=10;i++)if(!secOpen(i)){FOGC.i=i;break;}return FOGC;}
function fogX(){return fogMemo().x;}
function fogSeeX(){return fogMemo().sx;}
function fogSec(){return fogMemo().i;}
function fogClosedAt(x,y){const F=fogMemo();if(x>=F.sx)return true;return !F.z&&inXII110(x,y);}
function fogBlockedAt(x,y){const F=fogMemo();if(x>=F.x)return true;return !F.z&&inXII110(x,y);}
function fogHint(i){return i===1?(progDone(6)?'УНИЧТОЖЬТЕ ДВА ЗАМКА ВОРОТ':'ПРОЙДИТЕ МИССИЮ 06'):'СЕКТОР '+roman(i+1)+' · ПРОЙДИТЕ МИССИЮ '+pad2(secLastM(i-1));}
function nodeState(m){const S=G.save;if(progDone(m))return 'done';if(openAllNow())return 'open';
  if(m>1&&!progDone(m-1))return 'locked';if(m===7&&!S.gate)return 'locked';return secOpen(secOfM(m))?'open':'locked';}
// стена: держит только пересечение кромки (корабль, уже оказавшийся за ней, не перебрасывает через полмира)
function fogWall(p){if(!p||openAllNow()||p.px===undefined)return;const fx=fogX();if(fx===Infinity)return;const L=fx-p.r;
  if(p.x>L&&p.px<=L+1){p.x=L-1;p.vx=-Math.abs(p.vx)*.4-90;p.dashT=0;const i=fogSec();hintOnce(i===1?'gate':'fog'+i,i===1?(G.save.cleared>=6?'ВОРОТА ЗАПЕРТЫ · УНИЧТОЖЬТЕ ДВА ЗАМКА':'ВОРОТА СЕКТОРА · СНАЧАЛА ЯДРО СТРАЖА'):'ТУМАН ВОЙНЫ · '+fogHint(i),i===1?'#b48cff':'#9fb0c4');}}
// старые сохранения альфы: ворота II, если уже пройдены миссии за ними; корабль не стоит в закрытом тумане
function fogFix(S){if(!S||openAllNow())return;if(!S.gate&&WORLD.nodes.some(n=>n.m>=7&&progDone(n.m)))S.gate=true;
  if(S.pos&&fogBlockedAt(S.pos.x,S.pos.y)){let bn=WORLD.nodes[0];for(const n of WORLD.nodes)if(nodeState(n.m)!=='locked'&&!fogBlockedAt(n.x,n.y))bn=n;S.pos={x:bn.x,y:bn.y+160};S.last={...S.pos};}}
function fogDraw(t){if(openAllNow()||!G.save||!G.player)return;const F=fogMemo(),p=G.player,mob=isMob(),vx0=CX-80,vx1=CX+W+80,vy0=CY-80,vy1=CY+H+80;
  const wall=(ax,ay,bx,by,dir,txt)=>{const E=dir==='x'?860:720;
    const L=Math.max(dir==='x'?ax-E:ax,vx0),R_=Math.min(bx,vx1),T_=Math.max(dir==='y'?ay-E:ay,vy0),B_=Math.min(by,vy1);if(L>=R_||T_>=B_)return;
    const gr=dir==='x'?ctx.createLinearGradient(ax-E,0,ax,0):ctx.createLinearGradient(0,ay-E,0,ay);
    // плавная S-кривая (smootherstep по 13 точкам): к границе сектора мгла полная, обрыва нет
    for(let q=0;q<=12;q++){const u=q/12,a=u*u*u*(u*(u*6-15)+10);gr.addColorStop(u,'rgba(3,5,11,'+(a*.985).toFixed(3)+')');}ctx.fillStyle=gr;ctx.fillRect(L,T_,R_-L,B_-T_);
    if(SET.fx){const st=mob?420:260;const puff=(cx,cy,r)=>{const rg=ctx.createRadialGradient(cx,cy,0,cx,cy,r);rg.addColorStop(0,'rgba(3,5,11,.55)');rg.addColorStop(1,'rgba(3,5,11,0)');ctx.fillStyle=rg;ctx.fillRect(cx-r,cy-r,r*2,r*2);};
      if(dir==='x'){for(let y=Math.floor(T_/st)*st;y<B_+st;y+=st){const k=y/st;puff(ax-60+Math.sin(t*.25+k*1.7)*70,y+Math.sin(t*.2+k)*60,170+50*Math.sin(t*.4+k*2.3));}}
      else{for(let x=Math.floor(L/st)*st;x<R_+st;x+=st){const k=x/st;puff(x+Math.sin(t*.2+k)*60,ay-50+Math.sin(t*.25+k*1.7)*60,170+50*Math.sin(t*.4+k*2.3));}}}
    if(dir==='x'?Math.abs(p.x-ax)<1000:Math.abs(p.y-ay)<1000){const hw=(mob?95:125)/SC,lx=clamp(dir==='x'?ax+190:p.x,CX+hw+8/SC,CX+W-hw-8/SC),ly=dir==='x'?clamp(p.y-40,T_+60,B_-60):ay+130;
      worldLabel(lx,ly,'ТУМАН ВОЙНЫ','#9fb0c4');worldLabel(lx,ly+18,mob?txt.replace(/^СЕКТОР [IVXL]+ · /,''):txt,'#6f8096');}};
  const i=F.sx===Infinity?-1:(()=>{for(let k=1;k<=10;k++)if(!secSeen(k))return k;return -1;})();
  if(i>0)wall(F.sx,0,WW,WH,'x',fogHint(i));
  if(!F.z&&F.sx>WORLD.sectors[11].box[0]){const b=WORLD.sectors[11].box;wall(b[0],b[1],b[2],b[3],'y','СЕКТОР XII · ПРОЙДИТЕ МИССИЮ 49');}}
const medalCount=md=>md?(md.clear?1:0)+(md.clean?1:0)+(md.master?1:0):0;
function totalMedals(){let s=0;for(const k in G.save.medals)s+=medalCount(G.save.medals[k]);return s;}
const AUNIT=250;
const fmtAU=d=>{const v=d/AUNIT;return v<1?'рядом':Math.round(v)+' а.е.';};
const inView=(x,y,r)=>x+r>CX&&x-r<CX+W&&y+r>CY&&y-r<CY+H;

function genWorld(){
  const R=mulberry(1337),rr=(a,b)=>a+R()*(b-a);
  const pois=[WORLD.hangar,WORLD.abyss,WORLD.arsenal,...WORLD.nodes,...WORLD.shops,...WORLD.relays,...WORLD.caches,...(WORLD.journals0||WORLD.journals),...WORLD.anomalies,WORLD.gate];
  const ok=(x,y)=>pois.every(q=>Math.hypot(q.x-x,q.y-y)>150)&&Math.abs(x-5000)>170&&WORLD.locks.every(([lx,ly])=>Math.hypot(lx-x,ly-y)>120);
  const rocks=[];
  const add=(x,y,r)=>{if(x<60||y-OY<60||x>WW0-60||y-OY>WH0-60||!ok(x,y))return;const n=9,v=[];for(let i=0;i<n;i++)v.push(r*rr(.75,1.1));rocks.push({id:rocks.length,x,y,vx:0,vy:0,r,hp:r>25?60:25,v,rot:rr(0,TAU),vr:rr(-.3,.3),alive:true,tow:null,flung:false,hitF:0});};
  for(const f of WORLD.fields)for(let i=0;i<f.n;i++){const a=rr(0,TAU),d=Math.sqrt(R())*f.r;add(f.x+Math.cos(a)*d,f.y+Math.sin(a)*d,rr(18,38));}
  for(let i=0;i<90;i++)add(rr(100,WW0-100),OY+rr(100,WH0-100),rr(16,34));
  const decor=[];const cols=['#46288c','#145082','#781e46','#1e6e8c'];for(let i=0;i<46;i++)decor.push({x:rr(0,WW0),y:OY+rr(0,WH0),r:rr(500,1300),col:cols[i%4],a:rr(.1,.22)});
  // новые сектора: свои обломки (id с 100000) и туманности
  {const R2=mulberry(4242),r2=(a,b)=>a+R2()*(b-a);let id=100000;
    for(const f of WORLD.fields2)for(let i=0;i<f.n;i++){const a=r2(0,TAU),d=Math.sqrt(R2())*f.r,x=f.x+Math.cos(a)*d,y=f.y+Math.sin(a)*d,r=r2(18,38);if(WORLD.nodes.some(q=>Math.hypot(q.x-x,q.y-y)<180))continue;const v=[];for(let k=0;k<9;k++)v.push(r*r2(.75,1.1));rocks.push({id:id++,x,y,vx:0,vy:0,r,hp:r>25?60:25,v,rot:r2(0,TAU),vr:r2(-.3,.3),alive:true,tow:null,flung:false,hitF:0});}
    for(const sc of WORLD.sectors.slice(2))for(let i=0;i<6;i++)decor.push({x:r2(sc.box[0],sc.box[2]),y:r2(sc.box[1],sc.box[3]),r:r2(600,1400),col:sc.col,a:r2(.05,.1)});}
  const gone=new Set((G.save&&G.save.rocksGone)||[]);G.wrocks=rocks.filter(r=>!gone.has(r.id));G.rockTotal=rocks;G.decor=decor;w58Gen();G.zones=WORLD.zones.filter(z=>!z.w58).map((z,i)=>({...z,idx:i,active:false,cool:0,n:0}));G.wgen=true;
}
function loadFog(){G.fogVer=(G.fogVer||0)+1;G.fog=new Uint8Array(FGW*FGH);const s=G.save.reveal||'';for(let i=0;i<G.fog.length&&i<s.length;i++)G.fog[i]=s[i]==='1'?1:0;}
function revealAround(x,y,R){const c0=Math.max(0,Math.floor((x-R)/FOG)),c1=Math.min(FGW-1,Math.floor((x+R)/FOG)),r0=Math.max(0,Math.floor((y-R)/FOG)),r1=Math.min(FGH-1,Math.floor((y+R)/FOG));
  for(let j=r0;j<=r1;j++)for(let i=c0;i<=c1;i++){const cx=(i+.5)*FOG,cy=(j+.5)*FOG;if(Math.hypot(cx-x,cy-y)<R+FOG*.5&&!G.fog[j*FGW+i]&&!fogClosedAt(cx,cy)){G.fog[j*FGW+i]=1;G.fogVer=(G.fogVer||0)+1;}}}
const revealedAt=(x,y)=>!!G.fog&&G.fog[clamp(Math.floor(y/FOG),0,FGH-1)*FGW+clamp(Math.floor(x/FOG),0,FGW-1)]===1&&!fogClosedAt(x,y);
function camSnap(){const p=G.player;CX=clamp(p.x-W/2,0,Math.max(0,WW-W));CY=clamp(p.y-H/2,0,Math.max(0,WH-H));}
function camFollow(dt){const p=G.player;let lx=0,ly=0;if(aimManual()){const m=mouseWorld();lx=clamp((m.x-p.x)*.15,-80,80);ly=clamp((m.y-p.y)*.15,-80,80);}const tx=clamp(p.x-W/2+p.vx*.22+lx,0,Math.max(0,WW-W)),ty=clamp(p.y-H/2+p.vy*.22+ly,0,Math.max(0,WH-H));const k=Math.min(1,dt*5*(/*DEVW*/window.DEVW&&DEVW.on()&&G.world?Math.max(1,DEVW.spd()):1));CX+=(tx-CX)*k;CY+=(ty-CY)*k;}



// ===== 0.6.0: геймпад =====
const PADB={};
function padTick(now){const gp=navigator.getGamepads?[...navigator.getGamepads()].find(g=>g&&g.connected):null;if(!gp){if(G.padOn){G.padOn=false;G.padX=G.padY=0;CHG.p=false;}return;}
  const ax=gp.axes[0]||0,ay=gp.axes[1]||0,l=Math.hypot(ax,ay),dz=.18;G.padOn=l>dz;if(G.padOn){const k=Math.min(1,(l-dz)/(1-dz))/l;G.padX=ax*k;G.padY=ay*k;}else G.padX=G.padY=0;
  const pr=i=>!!(gp.buttons[i]&&(gp.buttons[i].pressed||gp.buttons[i].value>.5));const edge=i=>{const v=pr(i),o=PADB[i];PADB[i]=v;return v&&!o;};
  const any=[0,1,2,3,9,12,13].some(i=>pr(i))||G.padOn;if(any)setInput('pad');
  CHG.p=pr(7)||pr(5);
  const st=G.state;
  if(st==='play'||st==='world'){if(edge(0))tryDash();if(edge(2))tryPulse();if(edge(9))pause();if(st==='world'&&edge(3))openMap();if(st==='world'&&edge(1)&&G.card)cardAct('main');return;}
  if(st==='map'&&(edge(3)||edge(1))){closeMap();return;}
  if(st==='pause'&&edge(9)){resume();return;}
  if(edge(1)){escAction();return;}
  const sc=G.scrId&&$('#'+G.scrId);if(!sc)return;const bt=[...sc.querySelectorAll('button:not([disabled]),.card')].filter(b=>b.offsetParent!==null&&getComputedStyle(b).visibility!=='hidden');if(!bt.length)return;
  let i=bt.indexOf(document.activeElement);if(edge(13)){i=(i+1)%bt.length;bt[i].focus();}if(edge(12)){i=(i-1+bt.length)%bt.length;bt[i].focus();}
  if(edge(0)){if(i<0){bt[0].focus();}else bt[i].click();}}
addEventListener('gamepadconnected',()=>setInput('pad'));
// ===== 0.6.0: обучение на касаниях (миссии 1–2) =====
function tutTick(){if(!touchMode||!isMob()||G.state!=='play'||G.mode!=='world'||!G.player||G.m>2)return;const T=G.tut||(G.tut={});const p=G.player;
  if(!T['s'+G.m]){T['s'+G.m]=1;floater(p.x,p.y-46,G.m===1?'ВЕДИТЕ КОРАБЛЬ СТИКОМ СЛЕВА':'РЫВОК — УВОРОТ · КНОПКА ИЛИ СВАЙП ВПРАВО','#8fe9ff');}
  if(!T.en&&p.en>=100){T.en=1;floater(p.x,p.y-46,'ИМП ГОТОВ · КНОПКА СПРАВА','#ffb84d');}}
// ===== 0.6.0: экранный слой для телефона =====
function drawArenaEdge(p,t){const m=120,near=Math.min(p.x,p.y,W-p.x,H-p.y);if(near>m*2.2)return;const a=clamp(1-(near-m*.4)/(m*1.8),0,1)*.55;
  ctx.save();ctx.strokeStyle='#8fe9ff';ctx.globalAlpha=a;ctx.lineWidth=2/SC;ctx.setLineDash([10/SC,8/SC]);ctx.strokeRect(2,2,W-4,H-4);ctx.setLineDash([]);ctx.restore();}
function edgePt(X,Y,x0,y0,x1,y1){const cx=(x0+x1)/2,cy=(y0+y1)/2,dx=X-cx,dy=Y-cy;let k=1e9;
  if(dx)k=Math.min(k,((dx>0?x1:x0)-cx)/dx);if(dy)k=Math.min(k,((dy>0?y1:y0)-cy)/dy);k=Math.min(1,k);return [cx+dx*k,cy+dy*k,Math.atan2(dy,dx)];}
function edgeArrow(x,y,col,size,label){const X=(x-CX)*SC,Y=(y-CY)*SC;if(X>=-4&&X<=CW+4&&Y>=-4&&Y<=CH+4)return false;
  let [ex,ey,a]=edgePt(X,Y,SAFE.l+26,SAFE.t+74,CW-SAFE.r-26,CH-SAFE.b-26);
  if(ex>CW-SAFE.r-130&&ey<SAFE.t+176)ey=SAFE.t+176;
  for(let n=0;n<2;n++)for(const k in TBR){const b=TBR[k];if(Math.hypot(ex-b.x,ey-b.y)<b.r+22){if(Math.abs(ex-b.x)>Math.abs(ey-b.y)&&ey<b.y)ey=b.y-b.r-24;else if(ex>CW/2)ex=b.x-b.r-24;else ex=b.x+b.r+24;}}
  ctx.save();ctx.translate(ex,ey);ctx.rotate(a);ctx.fillStyle=col;ctx.strokeStyle='#04060c';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(size,0);ctx.lineTo(-size*.6,-size*.7);ctx.lineTo(-size*.25,0);ctx.lineTo(-size*.6,size*.7);ctx.closePath();ctx.stroke();ctx.fill();ctx.restore();
  if(label){ctx.font='700 12px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#04060c';const lw=ctx.measureText(label).width/2+10,rx=ex-Math.cos(a)*30,lx=clamp(rx,SAFE.l+lw,CW-SAFE.r-lw),ly0=ey-Math.sin(a)*22+4,ly=clamp(Math.abs(lx-ex)<lw+6&&Math.abs(ly0-4-ey)<16?ey+(ey<CH/2?28:-18):ly0,SAFE.t+70,CH-SAFE.b-10);ctx.lineJoin='round';ctx.lineWidth=4;ctx.strokeStyle='rgba(4,6,12,.92)';ctx.strokeText(label,lx,ly);ctx.fillStyle=col;ctx.fillText(label,lx,ly);}
  return true;}
function mobOverlay(now){if(!isMob())return;const p=G.player;if(!p||!(G.state==='play'||G.state==='world'||G.state==='pause'||G.state==='levelup'))return;
  const t=now/1000;ctx.setTransform(DPR,0,0,DPR,0,0);ctx.globalAlpha=1;
  const PX=(p.x-CX)*SC,PY=(p.y-CY)*SC;
  if(!G.world&&G.arena){// угрозы и цели за кадром
    const list=[];for(const e of G.enemies){if(!e.alive||e.spawnT>0||e.ghost||e.type==='mine'||EDEF[e.type]&&EDEF[e.type].passive)continue;
      const d=Math.hypot(e.x-p.x,e.y-p.y);if(d>VW*.95)continue;const X=(e.x-CX)*SC,Y=(e.y-CY)*SC;if(X>=0&&X<=CW&&Y>=0&&Y<=CH)continue;
      const v=(e.vx||0)*(p.x-e.x)+(e.vy||0)*(p.y-e.y);if(v<0&&d>VW*.5)continue;list.push([d,e]);}
    list.sort((a,b)=>a[0]-b[0]);if((curDiff().rank||0)===0)for(const [d,e] of list.slice(0,6))edgeArrow(e.x,e.y,EDEF[e.type].col||'#ff4f6e',8+6*(1-d/VW),'');
    const B=G.sb&&G.sb.alive?G.sb:G.boss&&G.boss.alive?G.boss:G.jam&&G.jam.alive?G.jam:null;if(B)edgeArrow(B.x,B.y,'#ff6b8a',14,'БОСС');
    if(G.bc)edgeArrow(G.bc.x,G.bc.y,'#ffb84d',13,'МАЯК');}
  if(p.hp>0&&touchMode){// ореол корабля: где я и когда рывок
    const R=22;ctx.globalAlpha=.22;ctx.strokeStyle='#cfeeff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(PX,PY,R,0,TAU);ctx.stroke();
    if(p.dashCd>0){const f=1-p.dashCd/(p.dashCdMax||G.st.dashCd||1);ctx.globalAlpha=.6;ctx.strokeStyle='#8fe9ff';ctx.lineWidth=2.5;ctx.beginPath();ctx.arc(PX,PY,R,-Math.PI/2,-Math.PI/2+TAU*f);ctx.stroke();}
    ctx.globalAlpha=1;
    const C=G.combo;if(typeof comboOn==='function'&&comboOn()&&C&&C.n>1){ctx.font='700 14px "JetBrains Mono",monospace';ctx.textAlign='center';const s_='×'+C.mul.toFixed(2).replace('.',',');ctx.fillStyle='#04060c';ctx.fillText(s_,PX+1,PY-R-9);ctx.fillStyle='#ffb84d';ctx.fillText(s_,PX,PY-R-10);}}
  if(G.resumeK>0){const k=G.resumeK/1.2,b=Math.floor(G.resumeK/.4);ctx.globalAlpha=(b%2?.45:.9);ctx.strokeStyle='#8fe9ff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(PX,PY,30+k*30,0,TAU);ctx.stroke();
    ctx.font='700 16px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#8fe9ff';ctx.fillText(String(Math.ceil(G.resumeK/.4)),PX,PY-48);ctx.globalAlpha=1;}
}
// ---- вход в мир / выход в миссию ----
function startWorld(fresh){
  /*DEVW*/if(window.DEVW&&!DEVW.on())DEVW.clearFlag(true);
  audioInit();
  let S=fresh?null:migrateSave(store(saveKey()));if(!S)S=migrateSave(newSave());
  if(!inSectors(S.pos.x,S.pos.y)){let bn=WORLD.nodes[0],bd=1e12;for(const q of WORLD.nodes){const d=Math.hypot(q.x-S.pos.x,q.y-S.pos.y);if(d<bd){bd=d;bn=q;}}S.pos={x:bn.x,y:bn.y+160};S.last={...S.pos};}
  if(S.lost&&!inSectors(S.lost.x,S.lost.y))S.lost=null;
  /*DEVW*/if(window.DEVW&&DEVW.on())DEVW.prep(S);
  saveSet6(S,'new');fogFix(S);if(!S.contracts.init&&S.cleared>=2){fillContracts();S.contracts.init=1;}else if(S.contracts.init&&S.contracts.list.length<3){try{fillContracts();}catch(e){}}
  saveSet6(S,'new');G.mode='world';G.devRun=false;G.end=null;G.abyssImm=0;G.saveFail=0;G.lowFx=false;G.wgen=false;w58Reset();W58.zones.forEach(z=>{z.active=false;z.cool=0;});
  G.mods={...S.run.mods};computeStats();G.player=newPlayer();
  Object.assign(G.player,{hp:clamp(S.run.hp,1,G.st.maxHp),en:S.run.en||0});
  runRestore6(S.run);Object.assign(G,{score:S.run.score,kills:S.run.kills,taken:S.run.taken,inRun:true});
  enterWorldAt(S.pos.x,S.pos.y);saveWorld();
  if(S.migrated!==undefined){toast('ОБНОВЛЕНИЕ 0.3',`Модули корабля теперь действуют до конца миссии и выбираются на брифинге. За прежние модули начислено ${S.migrated} лома. Уровень пилота: ${S.pilot.lvl}.`);delete S.migrated;S.intro=true;store(saveKey(),S);}
  else if(!S.intro){S.intro=true;toast('ОТКРЫТЫЙ СЕКТОР',touchMode?'Янтарная стрелка ведёт к доступной миссии. Кнопка над рывком — войти или карта.':'Янтарная стрелка ведёт к доступной миссии. M — карта, F — взаимодействие.');}
  else banner(sectorName(S.pos.x,S.pos.y),(S.cycle||1)>1?'ЦИКЛ '+roman(S.cycle):'');
  G.lomPrev=undefined;G.radio=null;/*DEVW*/if(!(window.DEVW&&DEVW.on()))prologueStart(!!fresh||!S.story.prologue);
}
function enterWorldAt(x,y){
  unlockArena();secReset();if(!G.wgen)genWorld();
  const S=G.save;
  Object.assign(G,{world:true,state:'world',enemies:[],pb:[],eb:[],pick:[],parts:[],float:[],warns:[],shock:[],fields:[],meteors:[],meteorT:0,prio:null,boss:null,jam:null,bc:null,relays:[],rocks:[],storm:null,
    dark:false,noTele:false,aimLock:null,riftI:0,riftD:-1e9,unk:[],riftDeath:0,riftB1:0,riftB2:0,lightFull:0,affixCh:0,endT:0,deadT:0,bpQ:0,fake:null,lureP:null,dashLog:[],anom:null,calm:0,saveT:8,flare:0,cardKey:null,card:null,mc:null,zb:null,zbCool:0,zbAmb:null});
  G.m=Math.max(1,S.cleared);
  G.zones.forEach(z=>{z.active=false;});
  loadFog();
  const p=G.player;Object.assign(p,{x:clamp(x,40,WW-40),y:clamp(y,40,WH-40),vx:0,vy:0,inv:1.5,dashT:0,dashCd:0,trail:[],cargo:0,noDash:0});p.px=p.x;p.py=p.y;
  for(const f of WORLD.minefields){const R=mulberry(77);for(let i=0;i<f.n;i++){const a=R()*TAU,d=100+Math.sqrt(R())*(f.r-100);spawnEnemy('mine',f.x+Math.cos(a)*d,f.y+Math.sin(a)*d,{arm:0,fuse:0,life:1e9,noAffix:true});}}
  if(S.cleared>=6&&!S.gate)WORLD.locks.forEach(([lx,ly],li)=>{if(!(S.locksDown||[]).includes(li))spawnEnemy('lock',lx,ly,{noAffix:true,li});});
  BW=WW;BH=WH;camSnap();show('');
}
function riftReset(){G.unk=[];G.riftI=0;G.riftD=-1e9;G.riftDeath=0;G.riftB1=0;G.riftB2=0;if(G.eb)G.eb=G.eb.filter(b=>!b.rift);const hd=document.getElementById('hud');if(hd){hd.style.transform='';hd.style.opacity='';}}
function enterNode(m,echo){
  if(m===50&&G.mode==='world'&&G.world&&!echo&&typeof zbStart==='function'){zbStart();return;}
  const S=G.save,n=WORLD.nodes[m-1];if(!S||!n||!G.player)return;riftReset();if(G.anom)endAnom();G.slick=false;G.chillK=1;G.chillD=1;if(G.w){G.w.chill=0;G.w.chillT=0;G.w.iced=false;}
  if(S.carry>0){S.lom+=S.carry;S.carry=0;}
  S.pos={x:n.x,y:n.y+160};S.last={...S.pos};saveWorld();
  G.world=false;G.card=null;G.cardKey=null;$('#wcard').hidden=true;
  CX=0;CY=0;BW=W;BH=H;openIntro(m-1);
}
function returnToWorld(){
  const S=G.save;if(!S||!G.player)return;$('#toast').hidden=true;
  G.mods={};computeStats();runZero6(true);G.combo=null;G.player.hp=Math.min(G.player.hp,G.st.maxHp);
  if(G.boostMsg){G.boostMsg=0;setTimeout(()=>toast('ДВИГАТЕЛИ ПЕРЕНАСТРОЕНЫ','Корабль навсегда стал быстрее.'),400);}
  enterWorldAt(S.pos.x,S.pos.y);
  if(G.arsMsg){G.arsMsg=0;G.trophyMsg=0;const ar=WORLD.arsenal;setTimeout(()=>{banner('АРСЕНАЛ ОТКРЫТ','«ИНЕЙ» · СЕКТОР III · ТРОФЕЙ +2000 ЛОМА');if(G.state==='world'){G.course={x:ar.x,y:ar.y+150,label:ar.name};}},700);}
  else if(G.trophyMsg){const tr=G.trophyMsg;G.trophyMsg=0;setTimeout(()=>banner('ТРОФЕЙ БОССА','+'+tr+' ЛОМА НА СКЛАД'),700);}
  try{const ios=/iP(hone|ad|od)/.test(navigator.userAgent),sa=navigator.standalone||matchMedia('(display-mode: standalone)').matches;if(ios&&!sa&&!SET.iosHint&&doneCount()>=5){SET.iosHint=true;saveSet();setTimeout(()=>toast('СОХРАНИТЕ ПРОГРЕСС','Safari стирает данные сайтов, которые не открывали 7 дней. Добавьте игру на экран «Домой» («Поделиться» → «На экран Домой») или сохраните код в меню «ЕЩЁ» → «КОД СОХРАНЕНИЯ».'),900);}}catch(e){}
  const U=G.unlockPending;G.unlockPending=null;
  if(U){
    if(U.from===6){banner('ВОРОТА СЕКТОРА','УНИЧТОЖЬТЕ ДВА ЗАМКА ГВАРДИИ');const a=WORLD.nodes[5];G.unlockFx={x0:a.x,y0:a.y,x1:WORLD.gate.x,y1:WORLD.gate.y,t:0};}
    else if(U.from===CORE){if(!postGate()){banner('ПРОХОД ПЕРЕКРЫТ','В ЛЁД ВМЁРЗ СТОРОЖЕВИК «ИЗМОРОЗЬ»');const a=WORLD.nodes[CORE-1];G.unlockFx={x0:a.x,y0:a.y,x1:POST_HATCH.x,y1:POST_HATCH.y,t:0};G.course={x:POST_HATCH.x,y:POST_HATCH.y+150,label:'СТОРОЖЕВИК «ИЗМОРОЗЬ»'};setTimeout(()=>{try{radioSay('Х',0);}catch(e){}},2600);}else banner('АКТ I ЗАВЕРШЁН','ДОСТУПЕН НОВЫЙ ЦИКЛ · МАСТЕРСКАЯ ИЛИ УЗЕЛ 10');}
    else{const a=WORLD.nodes[U.from-1],b=WORLD.nodes[U.from];banner('СИГНАЛ РАСШИФРОВАН','МИССИЯ '+pad2(U.from+1)+' ДОСТУПНА');G.unlockFx={x0:a.x,y0:a.y,x1:b.x,y1:b.y,t:0};}
    sfx('flash');
  }
  saveWorld();
}
function worldMissionDone(){if(!G.save||!G.player||!G.mc||G.mode!=='world')return;ambSting('win');buzz('win');{const M=MISSIONS[G.m-1];if(M&&M.gen&&M.sec===3&&wearPct()<=5)conEvent('clearLowWear');if(M&&M.gen&&M.sec===6&&G.mc&&!G.mc.seen80)conEvent('clean85');done90(M);}
  const S=G.save,m=G.m,first=m<=CORE?(m>S.cleared&&!(ALPHA_OPEN&&S.medals[m]&&S.medals[m].clear))/* ВРЕМЕННО (альфа 0.5.9): без повторной первой награды */:!(S.medals[m]&&S.medals[m].clear),p=G.player,node=WORLD.nodes[m-1],D=curDiff(),mul=D.lom*cycLom()*(MISSION_K[m]&&MISSION_K[m].lom||1);
  const md=S.medals[m]||(S.medals[m]={});const got=[];let lom=0,px=0;
  const taken=G.taken-G.missionTaken,cleanLim=m<=6?30:45;
  if(!md.clear){md.clear=1;got.push('Прохождение');}
  if(!md.clean&&taken<cleanLim){md.clean=1;got.push('Чистота');}
  let mastered=false;try{mastered=MASTERY[m-1].ok();}catch(e){}
  if(!md.master&&mastered){md.master=1;got.push('Мастерство');}
  lom+=got.length*20;
  const k=S.replays[m]||0;
  const sr=secRew(m),firstLom=m<=CORE?20+12*m:Math.round((100+3*(m-CORE))*sr*(m>=15?3:1));/* 0.7.0: сектора IV+ платят втрое */
  if(first){lom+=firstLom;px+=(40+8*m)*mul*sr;}
  else{lom+=m>CORE?Math.round(firstLom*.35)/* 0.7.0: повторы в секторах III+ — плоские 35 % */:Math.max(2,Math.round((6+2*m)*Math.pow(.6,k)));px+=Math.max(10,(40+8*m)*Math.pow(.6,k+1))*mul;S.replays[m]=k+1;}
  lom=Math.round(lom*mul*(G.sbLomK||1))+Math.round(G.lom74||0);px+=25*got.length;
  {const tr=BOSS_TROPHY[m];if(tr&&!(S.trophy&&S.trophy[m])){S.trophy=S.trophy||{};S.trophy[m]=1;lom+=tr;G.trophyMsg=tr;if(m===14)G.arsMsg=1;}}
  S.lom+=lom;addPilotXP(px);const tsec=Math.round(G.mT);if(!S.best[m]||tsec<S.best[m])S.best[m]=tsec;
  S.bestDiff[m]=Math.max(S.bestDiff[m]??-1,D.rank);
  const healed=Math.round(Math.min(G.st.maxHp-p.hp,G.st.maxHp*.3));p.hp+=healed;
  if(first&&m<=CORE){G.unlockPending={from:m};}
  if(first&&m===CORE&&!S.speedBoost){S.speedBoost=1;G.boostMsg=1;}
  if(m<=CORE){if(ALPHA_OPEN){if(m===S.cleared+1){S.cleared=m;while(S.cleared<CORE&&S.medals[S.cleared+1]&&S.medals[S.cleared+1].clear)S.cleared++;}}/* ВРЕМЕННО (альфа 0.5.9): cleared растёт только по порядку */else S.cleared=Math.max(S.cleared,m);}S.pos={x:node.x,y:node.y+160};S.last={...S.pos};
  REC.maxMission=Math.max(REC.maxMission,m+1);REC.best=Math.max(REC.best,G.score);saveRec();
  conEvent('clear',D.rank);if(G.mc.pulses===0&&m>=2)conEvent('clearNoPulse');if(G.mc.dashes===0)conEvent('clearNoDash');
  if(G.bc&&G.bc.hp>=G.bc.maxHp*.9)conEvent('clearBc90');got.forEach(()=>conEvent('medal'));
  if(first)fillContracts();saveWorld();
  scr6('done');
  $('#dnEyebrow').textContent=(m===6&&first?'ЯДРО ПРОЙДЕНО':m===CORE&&first?'АКТ I ЗАВЕРШЁН':'МИССИЯ ВЫПОЛНЕНА');
  $('#dnName').textContent=mName(MISSIONS[m-1]);
  const cells=[['ВРЕМЯ',mmss(G.mT)],['ЛОМ',lomH('+'+lom,1)]];
  $('#dnStats').innerHTML=statCells(cells);
  const mrow=(on,name,cond)=>`<span style="color:${on?'var(--amber)':'var(--muted)'}">${on?'●':'○'} ${name}${cond?' — '+cond:''}</span>`;
  const fx=v=>v.toFixed(2).replace('.',',').replace(/0$/,'').replace(/,$/,'');
  $('#dnNote').innerHTML=`<span style="display:grid;gap:4px;font-family:var(--f-mono);font-size:12px">${mrow(md.clear,'Прохождение')}${mrow(md.clean,'Чистота','почти без урона')}${mrow(md.master,'Мастерство',MASTERY[m-1].t)}</span>`+
    (G.sbChoiceTxt?'<br>'+G.sbChoiceTxt:'');
  $('#bNext').firstChild.nodeValue='В СЕКТОР ';$('#bDoneMenu').textContent='В МЕНЮ';
  show('sDone');(touchMode||$('#bNext').focus());
}
function worldRespawn(){
  if(G.zb&&typeof zbAbort==='function')zbAbort('death');
  const S=G.save,p=G.player;
  let lx=p.x,ly=p.y;if(!inSectors(lx,ly)){const R_=riftInfo(lx,ly);lx=R_.nx-R_.ox*150;ly=R_.ny-R_.oy*150;}
  if(S.carry>0){S.lost={x:Math.round(lx),y:Math.round(ly),v:S.carry+(S.lost?S.lost.v:0)};S.carry=0;}
  const wasRift=G.riftDeath;G.riftDeath=0;G.unk=[];G.eb=[];G.riftI=wasRift?.7:G.riftI;
  G.enemies.forEach(e=>{if(e.zone)e.alive=false;});G.enemies=G.enemies.filter(e=>e.alive);G.zones.forEach(z=>{z.active=false;});G.eb=[];endAnom();clearIce();G.iceImm=0;if(G.w){G.w.chill=0;G.w.chillT=0;G.w.iced=false;G.w.ambush=null;}G.chillK=1;G.chillD=1;
  Object.assign(p,{hp:G.st.maxHp*.7,x:S.last.x,y:S.last.y,vx:0,vy:0,inv:2.5,dashT:0,trail:[]});p.px=p.x;p.py=p.y;camSnap();
  banner('КОРАБЛЬ ВОССТАНОВЛЕН',wasRift?(S.lost?'У ПОСЛЕДНЕЙ ТОЧКИ · ЛОМ ОСТАЛСЯ У КРАЯ СЕКТОРА':'У ПОСЛЕДНЕЙ ТОЧКИ'):S.lost?'ПОТЕРЯННЫЙ ЛОМ ЖДЁТ НА МЕСТЕ ГИБЕЛИ':'У ПОСЛЕДНЕЙ ТОЧКИ');saveWorld();
}

// ---- обновление мира ----
function worldUpdate(dt){
  applyWH();G.t+=dt;BW=WW;BH=WH;const S=G.save,p=G.player,st=G.st;
  if(G.deadT>0){G.deadT-=dt;updateFx(dt);camFollow(dt);if(G.riftDeath)G.riftI=1;if(G.deadT<=0)worldRespawn();return;}
  const hostile=G.enemies.some(e=>e.alive&&e.type!=='mine'&&e.type!=='lock'&&e.type!=='rangedummy'&&!e.peace&&Math.hypot(e.x-p.x,e.y-p.y)<750);
  if(hostile||G.hurtV>0||G.anom)G.calm=0;else G.calm+=dt;
  G.cruise=G.calm>2.2&&(G.riftI||0)<.1;
  const base=st.speed;if(G.cruise)st.speed=base*1.75*(G.w&&G.w.cruiseK||1);
  /*DEVW*/if(window.DEVW&&DEVW.on())DEVW.move(dt);else updatePlayer(dt);st.speed=base;regenTick(dt);updateRift(dt);if(G.pilotUps&&G.pilotUps.length)flushPilotUps();
  if(G.abyssImm>0)G.abyssImm-=dt;G.abyssPull=0;
  if(abyssOpen()&&!(G.abyssImm>0)&&p.hp>0&&!(p.dashT>0)){const a=WORLD.abyss,d=Math.hypot(a.x-p.x,a.y-p.y);if(d<520&&d>70){// 0.5.9: притяжение сильнее, шире и видно
    const k=160*Math.pow(1-d/520,.7)*dt;p.x+=(a.x-p.x)/d*k;p.y+=(a.y-p.y)/d*k;G.calm=0;G.abyssPull=1;hintOnce('abyssPull','БЕЗДНА ТЯНЕТ · ВХОД В ЦЕНТРЕ','#c9a6ff');
    if(SET.fx&&vR2()<dt*12)part(p.x+vrnd2(-10,10),p.y+vrnd2(-10,10),(a.x-p.x)/d*220,(a.y-p.y)/d*220,.6,'#c9a6ff',2);}}
  if(G.cruise&&SET.fx&&Math.hypot(p.vx,p.vy)>320&&vR2()<.6)part(p.x-p.vx*.04+vrnd2(-6,6),p.y-p.vy*.04+vrnd2(-6,6),-p.vx*.3,-p.vy*.3,.35,shipCol(),2);
  // барьеры: помехи вокруг закрытых узлов и ворота
  wellTick(dt);
  if(!gateOpen()&&p.px<=4945&&p.x>4945&&p.y>OY)/* ВРЕМЕННО (альфа 0.5.9): gateOpen() вместо S.gate */{p.x=4945;p.vx=-140;p.dashT=0;hintOnce('gate',S.cleared>=6?'ВОРОТА ЗАПЕРТЫ · УНИЧТОЖЬТЕ ДВА ЗАМКА':'ВОРОТА СЕКТОРА · СНАЧАЛА ЯДРО СТРАЖА','#b48cff');}
  gate110(p,S);fogWall(p);
  // обломки рядом с кораблём
  G.rocks=G.wrocks.filter(r=>r.alive&&Math.abs(r.x-p.x)<W+300&&Math.abs(r.y-p.y)<H+300);
  for(const r of G.rocks){r.rot+=r.vr*dt;r.hitF=Math.max(0,r.hitF-dt);
    const d=Math.hypot(p.x-r.x,p.y-r.y),m=r.r+p.r*.8;if(d<m&&d>0){p.x=r.x+(p.x-r.x)/d*m;p.y=r.y+(p.y-r.y)/d*m;}
    for(const e of G.enemies){if(!e.alive||STATIC.has(e.type)||e.type==='mine')continue;const q=Math.hypot(e.x-r.x,e.y-r.y),mm=r.r+e.r;if(q<mm&&q>0){e.x=r.x+(e.x-r.x)/q*mm;e.y=r.y+(e.y-r.y)/q*mm;}}}
  updateEnemies(dt);
  for(const e of G.enemies){if(!e.zone||!e.alive)continue;if(!inSectors(e.x,e.y)){const R_=riftInfo(e.x,e.y);e.x=R_.nx-R_.ox*20;e.y=R_.ny-R_.oy*20;e.vx*=.3;e.vy*=.3;}if(G.riftD>0&&e.cd!==undefined)e.cd=Math.max(e.cd,.6);}
  updateFields(dt);updateBullets(dt);updatePickups(dt);
  G.wrocks=G.wrocks.filter(r=>r.alive);
  secTick(dt);secWorldTick(dt);w74WorldTick(dt);w80WorldTick(dt);updateZones(dt);updatePOI(dt);storyWorldTick(dt);updateAnom(dt);revealAround(p.x,p.y,900);
  if(G.unlockFx){G.unlockFx.t+=dt;if(G.unlockFx.t>3.2)G.unlockFx=null;}
  updateFx(dt);zbCamPre();camFollow(dt);zbTick(dt);
  runLvlUp6(p);
  if(G.lvlQ>0&&G.state==='world'&&G.deadT<=0)nextPick();
  G.saveT-=dt;if(G.saveT<=0){G.saveT=8;saveWorld();}
}
function updateZones(dt){
  const S=G.save,p=G.player;
  for(const z of G.zones){if(z.w58)continue;
    if(z.cool>0)z.cool-=dt;
    if(S.cleared<z.req||(z.gate&&S.gate))continue;
    const d=Math.hypot(p.x-z.x,p.y-z.y);
    if(!z.active){
      if(z.cool<=0&&d<950&&p.hp>0){z.active=true;z.n=0;
        for(const [t,c] of Object.entries(z.set)){
          if(t==='twin'){for(let i=0;i<c/2;i++){const id=++G.uid;for(let k=0;k<2;k++){spawnEnemy('twin',z.x+rnd(-240,240),z.y+rnd(-240,240),{spawnT:.7,zone:z,pair:id,noAffix:true});z.n++;}}continue;}
          for(let i=0;i<c;i++){spawnEnemy(t,z.x+rnd(-260,260),z.y+rnd(-260,260),{spawnT:.7,zone:z,noAffix:true});z.n++;}}
        floater(p.x,p.y-40,z.gate?'ЗАСЛОН ГВАРДИИ':'ПАТРУЛЬ','#ff4f6e');sfx('warn');}
    }else{
      const left=G.enemies.filter(e=>e.alive&&e.zone===z).length;
      if(left===0){z.active=false;z.cool=240;const first=!S.zonesDone[z.idx];const v=first?10+z.n*3:3;S.zonesDone[z.idx]=1;S.carry+=v;floater(p.x,p.y-40,'ПАТРУЛЬ РАЗБИТ · +'+v+' ЛОМА'+(first?'':' · ПОВТОР'),'#c9d2de');sfx('level');conEvent('patrol');}
      else if(d>1900){G.enemies.forEach(e=>{if(e.zone===z)e.alive=false;});z.active=false;}
    }
  }
}
function updatePOI(dt){
  const S=G.save,p=G.player;if(p.hp<=0)return;
  let card=null;
  for(const n of WORLD.nodes){if(nodeState(n.m)==='locked')continue;if(Math.hypot(p.x-n.x,p.y-n.y)<150){card={kind:'node',n,key:'n'+n.m};S.last={x:n.x,y:n.y+150};}}
  for(const s of WORLD.shops){if(Math.hypot(p.x-s.x,p.y-s.y)<175){card={kind:'shop',s,key:s.id};S.last={x:s.x,y:s.y+150};}}
  for(const a of WORLD.anomalies){if(S.anomalies[a.id]||G.anom||(G.anomCd&&G.anomCd[a.id]>G.t))continue;if(Math.hypot(p.x-a.x,p.y-a.y)<170)card={kind:'anom',a,key:a.id};}
  {const hg=WORLD.hangar;if(Math.hypot(p.x-hg.x,p.y-hg.y)<175){card={kind:'hangar',key:'hangar|'+curSkin()};S.last={x:hg.x,y:hg.y+150};}}
  {const ar=WORLD.arsenal;if(Math.hypot(p.x-ar.x,p.y-ar.y)<175){card={kind:'arsenal',key:'arsenal|'+(arsOpen()?1:0)+'|'+(S.ars?S.ars.weapon:'')};S.last={x:ar.x,y:ar.y+150};}}
  for(const sc of WORLD.sectors)if(sc.bx&&Math.hypot(p.x-sc.bx,p.y-sc.by)<220)S.last={x:sc.bx,y:sc.by+150};
  if(abyssOpen()){const ab=WORLD.abyss;if(Math.hypot(p.x-ab.x,p.y-ab.y)<200){card={kind:'abyss',key:'abyss'};S.last={x:ab.x,y:ab.y+620};}}
  for(const r of WORLD.relays){if(S.relays[r.id])continue;const d=Math.hypot(p.x-r.x,p.y-r.y);
    if(d<120){r.rep=(r.rep||0)+dt;if(r.rep>=2){S.relays[r.id]=1;r.rep=0;revealAround(r.x,r.y,2400);S.lom+=30;banner('РЕТРАНСЛЯТОР ВОССТАНОВЛЕН','КАРТА РАСКРЫТА · +30 ЛОМА · НОВАЯ ТОЧКА ПРЫЖКА');sfx('level');G.shock.push({x:r.x,y:r.y,r:10,R:900,t:0,col:'#8fe9ff',slow:true});saveWorld();}}
    else r.rep=Math.max(0,(r.rep||0)-dt);}
  for(const c of WORLD.caches){if(S.found[c.id])continue;if(Math.hypot(p.x-c.x,p.y-c.y)<75){const cv=80+20*WORLD.caches.indexOf(c);S.found[c.id]=1;S.lom+=cv;addPilotXP(20);banner('ТАЙНИК · ЗАКЛАДКА Э.','+'+cv+' ЛОМА НА СКЛАД · +20 ОПЫТА ПИЛОТА');sfx('level');explode(c.x,c.y,'#ffb84d',30,1);saveWorld();}}
  for(const j of WORLD.journals){if(S.journals[j.id])continue;if(Math.hypot(p.x-j.x,p.y-j.y)<wreckR(j)){S.journals[j.id]=1;(S.jOrder||(S.jOrder=[])).includes(j.id)||S.jOrder.push(j.id);S.lom+=10;toast(j.title,j.text+' (+10 лома · J — все журналы)');sfx('pick');saveWorld();}}
  if(S.lost&&Math.hypot(p.x-S.lost.x,p.y-S.lost.y)<80){S.carry+=S.lost.v;floater(p.x,p.y-30,'ЛОМ ВОЗВРАЩЁН · +'+S.lost.v,'#c9d2de');S.lost=null;sfx('cell');saveWorld();}
  card=arch70POI(card,dt);/* ARCH·70 A-9 */if(card&&card.kind==='node'&&card.n.m===50&&zbOn())card=null;
  G.card=card;renderCard(card);
}
function renderCard(card){
  const el=$('#wcard');const key=card?card.key+'|'+G.save.cleared+'|'+G.save.lom+(card.kind==='node'&&card.n.m===50?'|'+(zbOn()?'z':zbDone()?'d':G.zbCool>G.t?'c':'o'):''):'';
  if(key===G.cardKey)return;G.cardKey=key;
  if(!card||G.state!=='world'){el.hidden=true;return;}
  const S=G.save;let h='';
  if(card.kind==='node'&&card.n.m===50){h=zbCard();}
  else if(card.kind==='node'){const m=card.n.m,M=MISSIONS[m-1],md=S.medals[m]||{},done=nodeState(m)==='done';
    h=`<div class="eyebrow">МИССИЯ ${pad2(m)}${done?' · ПРОЙДЕНА':''}</div><h3>${mName(M)}${M.bossRoom||M.boss||M.sboss?' <span class="badge" style="color:#ff6b8a">БОСС</span>':''}</h3>

      <div class="medals"><i class="${md.clear?'on':''}"></i><i class="${md.clean?'on':''}"></i><i class="${md.master?'on':''}"></i><span>${S.best[m]?'лучшее время '+mmss(S.best[m]):''}</span></div>
      ${done?`<p class="note">Мастерство: ${MASTERY[m-1].t}.</p>`:''}
      <div class="wc-row"><button class="wbtn" data-act="enter">ВОЙТИ [F]</button>${m===CORE&&S.cleared>=CORE?`<button class="wbtn amber" data-act="cycle">НОВЫЙ ЦИКЛ</button>`:''}</div>`;}
  else if(card.kind==='shop'){h=`<div class="eyebrow">${card.s.name}</div><h3>Ремонт и улучшения</h3><p class="note">На складе ${lomH(S.lom,1)}${S.carry?' · с собой '+lomH(S.carry):''}</p><div class="wc-row"><button class="wbtn amber" data-act="shop">ОТКРЫТЬ [F]</button></div>`;}
  else if(card.kind==='hangar'){h=`<div class="eyebrow">${WORLD.hangar.name}</div><h3>Скины корабля</h3><p class="note">${SKINS[curSkin()].name}</p><div class="wc-row"><button class="wbtn amber" data-act="hangar">ОТКРЫТЬ [F]</button></div>`;}
  else if(card.kind==='arsenal'){const open=arsOpen(),A=S.ars||arsDef();h=`<div class="eyebrow">${WORLD.arsenal.name}${open?'':' · ЗАПЕЧАТАН'}</div><h3>${open?'Прокачка орудия и второе оружие':'Склад Изобретателя'}</h3><p class="note">${open?`Оружие: ${ARS[A.weapon].name} · на складе ${lomH(S.lom,1)}`:'Откроется после победы над боссом Холодного архива.'}</p><div class="wc-row">${open?'<button class="wbtn amber" data-act="arsenal">ОТКРЫТЬ [F]</button>':'<button class="wbtn" disabled>ЗАПЕЧАТАНО</button>'}</div>`;}
  else if(card.kind==='abyss'){const eb=bestEndless();h=`<div class="eyebrow">∞ БЕЗДНА · БЕСКОНЕЧНОСТЬ</div><h3>Забег на выживание</h3><p class="note">Бесконечность на базовом корабле. В сектор ничего не переносится.${eb?' Лучшее: '+mmss(eb.t)+'.':''}</p><div class="wc-row"><button class="wbtn violet" data-act="abyss">ВОЙТИ [F]</button></div>`;}
  else if(card.kind==='anom'){h=`<div class="eyebrow">АНОМАЛИЯ · ${card.a.name}</div><p>${card.a.d}</p><div class="wc-row"><button class="wbtn violet" data-act="anom">НАЧАТЬ [F]</button></div>`;}
  else if(card.kind==='conv')h=w58Card(card);
  el.innerHTML=kh(h);el.hidden=false;if(typeof ctxBtnSync==='function')ctxBtnSync();
}
function cardAct(act){
  const c=G.card;if(!c||G.state!=='world')return;
  if(act==='cycle'){if(c.kind==='node'&&c.n.m===CORE&&G.save.cleared>=CORE)openCycle();return;}
  if(c.kind==='node'){if(act==='echo')return;{if(c.n.m===50){if(zbOn())return;if(!zbCanStart()){hintOnce('n50',G.zbCool>G.t?'ТОЧКА НЕВОЗВРАТА ЗАКРЫТА · '+Math.ceil(G.zbCool-G.t)+' С':'КНОПКА НЕ ОТВЕЧАЕТ','#ff9fe0');return;}zbStart();return;}enterNode(c.n.m,false);}}
  else if(c.kind==='shop'&&act!=='echo')openShop(c.s);
  else if(c.kind==='anom'&&act!=='echo')startAnom(c.a);
  else if(c.kind==='conv'&&act!=='echo')w58ConvStart();
  else if(c.kind==='hangar'&&act!=='echo')openHangar();
  else if(c.kind==='arsenal'&&act!=='echo'){if(arsOpen())openArsenal();}
  else if(c.kind==='abyss'&&act!=='echo')enterAbyss();
}
$('#wcard').addEventListener('click',e=>{const b=e.target.closest('[data-act]');if(b)cardAct(b.dataset.act);});
let toastTimer=0;
function toast(title,text){$('#toastT').textContent=kh(title);$('#toastP').textContent=kh(text);$('#toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{$('#toast').hidden=true;},8000);}

// ---- аномалии ----
function startAnom(a){
  G.anom={a,t:0,got:0,objs:[]};G.cardKey=null;const S=G.save,R=(x,y,o)=>{const m=spawnEnemy('mine',x,y,Object.assign({arm:0,fuse:0,life:1e9,noAffix:true,anomObj:true},o||{}));G.anom.objs.push(m);return m;};
  if(a.kind==='cells'){G.anom.dur=22;G.anom.need=8;G.anom.tp=6;
    for(let i=0;i<10;i++){const ang=rnd(0,TAU),d=rnd(140,470),da=rnd(0,TAU),sp=rnd(40,70);G.pick.push({k:'cell',x:a.x+Math.cos(ang)*d,y:a.y+Math.sin(ang)*d,vx:0,vy:0,r:9,t:0,stab:0,life:24,anom:true,noMag:true,dx:Math.cos(da)*sp,dy:Math.sin(da)*sp});}
    for(let i=0;i<4;i++){const ang=i/4*TAU+.4;R(a.x+Math.cos(ang)*260,a.y+Math.sin(ang)*260);}
    banner('АНОМАЛИЯ · РОССЫПЬ','8 ИЗ 10 ЯЧЕЕК ЗА 22 С · ЯЧЕЙКИ УБЕГАЮТ — БЕРИТЕ РЫВКОМ');}
  if(a.kind==='storm'){G.anom.dur=30;G.anom.next=1;G.anom.R=400;G.anom.beamA=rnd(0,TAU);banner('АНОМАЛИЯ · ИОННЫЙ ВИХРЬ','30 С В СЖИМАЮЩЕМСЯ КРУГЕ · С 12 С — ЛУЧИ');}
  if(a.kind==='coldcore'){w58CoreStart(a);}
  if(a.kind==='chase'){G.anom.dur=25;const e=spawnEnemy('thief',a.x+60,a.y,{noAffix:true,anomObj:true});e.hp=e.maxHp=150;e.armor=3;e.spd=310;e.flee=true;e.loot=0;const ang=rnd(0,TAU);
    e.fx=clamp(a.x+Math.cos(ang)*3200,100,WW-100);e.fy=clamp(a.y+Math.sin(ang)*3200,100,WH-100);G.anom.target=e;prioSet(e);G.anom.dashT=4;G.anom.mineT=2.5;G.anom.boost=0;
    for(let i=0;i<2;i++){const g=spawnEnemy('gunner',e.x+rnd(-60,60),e.y+rnd(-60,60),{noAffix:true,anomObj:true});G.anom.objs.push(g);}
    banner('АНОМАЛИЯ · ПОГОНЯ','ПОХИТИТЕЛЬ БЫСТРЕЕ ВАС · ПЕРЕХВАТЫВАЙТЕ И ДЕЛАЙТЕ РЫВОК');}
  sfx('warn');
}
function endAnom(){const A=G.anom;if(!A)return;G.enemies.forEach(e=>{e.tK=1;});if(A.a.kind==='conveyor'){G.enemies.forEach(e=>{if(e.conv)e.alive=false;});G.event=null;}for(const o of A.objs)o.alive=false;if(A.target&&A.target.alive)A.target.alive=false;G.pick=G.pick.filter(k=>!k.anom);G.anom=null;G.cardKey=null;}
function updateAnom(dt){
  const A=G.anom;if(!A)return;const S=G.save,p=G.player,a=A.a;A.t+=dt;G.calm=0;
  const fail=why=>{banner('АНОМАЛИЯ ПРОВАЛЕНА',why+' · ПОВТОР ЧЕРЕЗ 30 С');(G.anomCd||(G.anomCd={}))[a.id]=G.t+30;endAnom();};
  const win=v=>{S.anomalies[a.id]=1;S.lom+=v;addPilotXP(40);banner('АНОМАЛИЯ ПРОЙДЕНА','+'+v+' ЛОМА · +40 ОПЫТА ПИЛОТА');sfx('level');endAnom();conEvent('anom');saveWorld();};
  if(a.kind==='conveyor'){w58ConvTick(dt);return;}
  if(a.kind==='coldcore'){w58CoreTick(dt,fail,win);return;}
  if(p.hp<=0){fail('КОРАБЛЬ ПОТЕРЯН');return;}
  if(a.kind==='cells'){
    if(A.got>=A.need){win(100);return;}if(A.t>A.dur){fail('ВРЕМЯ ВЫШЛО');return;}
    const cells=G.pick.filter(k=>k.anom&&k.life>0);
    A.tp-=dt;if(A.tp<=0&&cells.length){A.tp=6;const c=cells[Math.random()*cells.length|0];const ang=rnd(0,TAU),d=rnd(140,460);explode(c.x,c.y,'#ffb84d',6,.5);c.x=a.x+Math.cos(ang)*d;c.y=a.y+Math.sin(ang)*d;}
    for(const c of cells){c.x+=c.dx*dt;c.y+=c.dy*dt;const ra=Math.hypot(c.x-a.x,c.y-a.y);if(ra>480){c.dx=-c.dx;c.dy=-c.dy;c.x=a.x+(c.x-a.x)*479/ra;c.y=a.y+(c.y-a.y)*479/ra;}
      const d=Math.hypot(c.x-p.x,c.y-p.y);if(d<130&&p.dashT<=0&&d>1){c.x+=(c.x-p.x)/d*265*dt;c.y+=(c.y-p.y)/d*265*dt;}c.life=Math.max(c.life,2);}
  }
  else if(a.kind==='storm'){
    A.R=400-180*clamp(A.t/A.dur,0,1);
    if(Math.hypot(p.x-a.x,p.y-a.y)>A.R){fail('ВЫ ПОКИНУЛИ КРУГ');return;}
    A.next-=dt;if(A.next<=0){A.next=Math.max(.6,1.2-.02*A.t);const gap=Math.atan2(p.y-a.y,p.x-a.x)+rnd(-.8,.8);
      for(let i=0;i<26;i++){const ang=i/26*TAU+A.t;if(Math.abs(angDiff(ang,gap))<.45)continue;shootE(a.x,a.y,ang,150,8,'#9fb4ff',5);}}
    if(A.t>=12){A.beamA+=dt*.55;const cyc=(A.t-12)%4.3;A.beamWarn=cyc<.8;A.beamOn=cyc>=.8&&cyc<3.8;
      if(A.beamOn)for(const k of [0,Math.PI]){const ang=A.beamA+k,ex=a.x+Math.cos(ang)*A.R,ey=a.y+Math.sin(ang)*A.R;if(segDist(a.x,a.y,ex,ey,p.x,p.y)<16)damagePlayer(14);}}
    if(A.t>A.dur){G.eb=[];win(130);}}
  else if(a.kind==='chase'){const e=A.target;
    if(!e.alive){if(e.hp<=0)win(130);else fail('ПОХИТИТЕЛЬ УШЁЛ');return;}
    if(A.t>A.dur||Math.hypot(e.x-a.x,e.y-a.y)>2600){fail('ПОХИТИТЕЛЬ УШЁЛ');return;}
    A.dashT-=dt;e.blink=A.dashT<.4;if(A.dashT<=0){A.dashT=4;const base=Math.atan2(e.fy-e.y,e.fx-e.x)+rnd(-1.05,1.05);explode(e.x,e.y,'#9dff6b',8,.5);e.x=clamp(e.x+Math.cos(base)*260,40,WW-40);e.y=clamp(e.y+Math.sin(base)*260,40,WH-40);sfx('dash');}
    A.mineT-=dt;if(A.mineT<=0){A.mineT=2.5;const m=spawnEnemy('mine',e.x,e.y,{arm:0,fuse:0,life:1e9,noAffix:true,anomObj:true});A.objs.push(m);}
    const d=Math.hypot(e.x-p.x,e.y-p.y);if(A.boost>0)A.boost-=dt;else if(d<200)A.boost=1.5;e.spd=A.boost>0?382:310;
    for(const g of A.objs)if(g.type==='gunner'&&g.alive){const tx=(e.x*2+p.x)/3,ty=(e.y*2+p.y)/3;g.x+=(tx-g.x)*Math.min(1,dt*1.5);g.y+=(ty-g.y)*Math.min(1,dt*1.5);}}
}

// ---- мастерская ----
function openShop(s){
  const S=G.save,p=G.player;if(!S||!p||G.state!=='world')return;if(S.carry>0){S.lom+=S.carry;S.carry=0;}
  p.hp=Math.max(p.hp,G.st.maxHp*(storyFlag('obod18')==='scrap'&&sectorIdx(s.x,s.y)===3?.8:1));scr6('shop');G.shopName=s.name;renderShop();show('sShop');shopType(shopLine());if(S.contracts.list.length&&S.story&&!S.story.seen['Д1'])radioForce('Д',0,1.5);saveWorld();
}
function renderShop(){
  const S=G.save;{const sh=$('#sShop .shop');if(!sh.dataset.st)sh.dataset.st='perks';const cy=S.cleared>=CORE;$('#shopTabCyc').hidden=!cy;if(!cy&&sh.dataset.st==='cyc')sh.dataset.st='perks';$('#shopTabs').querySelectorAll('[data-st]').forEach(b=>b.classList.toggle('on',b.dataset.st===sh.dataset.st));$('#shopTabsLom').innerHTML=lomH(S.lom,1);}$('#shopName').textContent=G.shopName+' · КОРПУС ВОССТАНОВЛЕН';
  $('#shopLom').innerHTML=`<span>ЛОМ ${lomH(S.lom,1)}</span>`;
  $('#shopPerks').innerHTML=Object.entries(PERKS).map(([k,P])=>{const l=S.perks[k]||0,max=l>=P.max,lockd=P.req&&S.cleared<P.req,cost=max?0:P.cost[l];
    const pips=Array.from({length:P.max},(_,j)=>`<i class="${j<l?'f':''}"></i>`).join('');
    return `<div class="perk"><div><h4>${P.name}</h4><div class="pips" style="margin:6px 0">${pips}</div><p>${P.d}${lockd?' Откроется после ядра Стража.':''}</p></div>
      <button class="wbtn amber" data-perk="${k}" ${max||lockd||S.lom<cost?'disabled':''}>${max?'ПРЕДЕЛ':lockd?'ЗАКРЫТО':'КУПИТЬ · '+lomH(cost)}</button></div>`;}).join('');
  const C=S.contracts;
  $('#shopCon').innerHTML=S.cleared<2&&(S.cycle||1)===1?'<p class="note">Контракты откроются после миссии 02.</p>':`<p class="note">Выполнено: ${C.done}.</p>`+(C.list.length?C.list.map((c,i)=>{const T=conT(c);if(!T)return '';
    return `<div class="perk"><div><h4>${T.s}</h4><p>${T.t(c.n)} · ${c.p}/${c.n} · ${lomH(c.lom)}</p><div class="cbar"><i style="width:${Math.round(c.p/c.n*100)}%"></i></div></div>
      <button class="wbtn" data-reroll="${i}" ${S.lom<20?'disabled':''}>ЗАМЕНИТЬ · ${lomH(20)}</button></div>`;}).join(''):'<p class="note">Доступных контрактов нет.</p>');
  $('#shopCycle').innerHTML=S.cleared>=CORE?`<div class="cx-h2">НОВЫЙ ЦИКЛ</div><div class="perk"><div><h4>Цикл ${roman((S.cycle||1)+1)}</h4><p>Сектор начинается заново: враги сильнее, награды больше. Перки, скины, уровень пилота и лом остаются.</p></div><button class="wbtn violet" data-cyc="1">ПОДРОБНЕЕ</button></div>`:'';
}
$('#shopTabs').addEventListener('click',e=>{const b=e.target.closest('[data-st]');if(!b)return;$('#sShop .shop').dataset.st=b.dataset.st;renderShop();$('#sShop').scrollTop=0;});
$('#shopCon').addEventListener('click',e=>{const b=e.target.closest('[data-reroll]');if(!b||b.disabled)return;const S=G.save,C=S.contracts,i=+b.dataset.reroll;if(S.lom<20||!C.list[i])return;
  const old=C.list[i];C.list.splice(i,1);const n=newContract();if(n)C.list.splice(i,0,n);else C.list.splice(i,0,old);if(n)S.lom-=20;saveWorld();sfx('pick');renderShop();});
$('#shopCycle').addEventListener('click',e=>{if(e.target.closest('[data-cyc]'))openCycle();});
function openCycle(){
  const S=G.save;if(!S||S.cleared<CORE)return;G.cycleFrom=G.state==='shop'?'shop':'world';scr6('cycle');const n=(S.cycle||1)+1;
  $('#cycEyebrow').textContent='НОВЫЙ ЦИКЛ · '+roman(S.cycle||1)+' → '+roman(n);$('#cycName').textContent='Цикл '+roman(n);
  $('#cycList').innerHTML=`<div><div class="eyebrow" style="color:var(--hostile)">СБРОСИТСЯ</div><ul><li>Пройденные миссии и узлы</li><li>Ворота и замки</li><li>Медали</li><li>Тайники, бортжурналы, аномалии, ретрансляторы</li><li>Награды первого разгрома патрулей</li><li>Разведанная карта</li></ul></div>
    <div><div class="eyebrow" style="color:var(--ice)">СОХРАНИТСЯ</div><ul><li>Перки мастерской</li><li>Купленные скины</li><li>Уровень пилота</li><li>Лом на складе: ${lomH(S.lom+(S.carry||0))}</li><li>Контракты</li><li>Рекорды Бесконечности</li></ul></div>`;
  $('#cycNote').textContent=`В цикле ${roman(n)} враги сильнее и их больше, а лома и опыта — больше.`;
  show('sCycle');(touchMode||$('#bCycBack').focus());
}
function closeCycle(){if(G.state!=='cycle')return;if(G.cycleFrom==='shop'){scr6('shop');renderShop();show('sShop');}else{scr6('world');G.cardKey=null;show('');}}
$('#bCycBack').onclick=closeCycle;$('#bCycGo').onclick=()=>{if(G.state!=='cycle')return;openReport();};
$('#bRepGo').onclick=()=>{if(G.state!=='report')return;newCycle();};
$('#shopPerks').addEventListener('click',e=>{const b=e.target.closest('[data-perk]');if(!b||b.disabled)return;const S=G.save,k=b.dataset.perk,P=PERKS[k],l=S.perks[k]||0;if(l>=P.max||S.lom<P.cost[l])return;
  S.lom-=P.cost[l];S.perks[k]=l+1;if(S.story)S.story.bought=1;computeStats();G.player.hp=G.st.maxHp;sfx('level');saveWorld();renderShop();});
function closeShop(){if(G.state!=='shop')return;scr6('world');G.cardKey=null;show('');}

// ---- карта сектора ----
function openMap(tab){if(G.state!=='world')return;scr6('map');mapViewInit();buildMapLegend();$('#mapTip').hidden=true;show('sMap');mapTab(tab||'map');alphaJumpUI();}
// ВРЕМЕННО (альфа 0.5.9): список быстрого прыжка к любому уровню
function alphaJumpUI(){const el=$('#alphaJump');if(!el)return;if(!ALPHA_OPEN){el.hidden=true;return;}const S=G.save;
  let o='';for(const n of WORLD.nodes){const M=MISSIONS[n.m-1]||{},st=nodeState(n.m);o+=`<option value="${pad2(n.m)}">${pad2(n.m)} · ${M.name||''}${n.boss?' · БОСС':''}${st==='done'?' · ПРОЙДЕНА':''}</option>`;}
  o+='<option value="∞">∞ БЕЗДНА</option>';
  el.innerHTML=`<span class="aj-l">АЛЬФА · ПРЫЖОК К УРОВНЮ</span><select id="ajSel">${o}</select><button class="wbtn amber" id="ajGo">ПРЫЖОК</button>`;el.hidden=false;
  $('#ajGo').onclick=()=>alphaJump($('#ajSel').value);}
function alphaJump(label){if(G.state!=='map')return false;if(!G.mapPts||!G.mapPts.length)drawMap();const q=(G.mapPts||[]).find(z=>z.label===label);if(!q)return false;G.mapAnimJump=false;const r=mapJumpAt(q.px,q.py);G.mapAnimJump=undefined;return r;}
function mapTab(t){G.mapTab=t;document.querySelectorAll('#mapTabs [data-mt]').forEach(b=>b.classList.toggle('on',b.dataset.mt===t));
  $('#mapJr').hidden=t!=='jr';$('#mapPane').style.display=t==='jr'?'none':'grid';
  const S=G.save;$('#mtJr').firstChild.nodeValue='ЖУРНАЛЫ · '+journalIds().length+'/'+WORLD.journals.length+' ';
  if(t==='jr')renderJournals($('#mapJr'),true);else{ARCH.mapGen++;mapLoop();}/* ARCH·69 A-1 */}
function journalIds(){const S=G.save;if(!S)return [];const ids=(S.jOrder||[]).filter((id,i,a)=>a.indexOf(id)===i&&S.journals[id]&&WORLD.journals.some(j=>j.id===id));
  for(const j of WORLD.journals)if(S.journals[j.id]&&!ids.includes(j.id))ids.push(j.id);return ids;}
function renderJournals(el,mapBtn){
  const S=G.save,ids=journalIds(),p=G.player;
  const card=j=>`<div class="jr"><h4>${j.title}</h4><p>${j.text}</p><div class="jhull"><canvas data-wr="${j.id}" width="96" height="96"></canvas><span>${hullLine(j)}</span></div><div class="meta"><span>${sectorName(j.x,j.y)}${p&&G.mode==='world'?' · '+fmtAU(Math.hypot(j.x-p.x,j.y-p.y)):''}</span>${mapBtn?`<button class="wbtn" data-jmap="${j.id}">НА КАРТЕ</button>`:''}</div></div>`;
  let h=`<p class="note">Найдено записей: ${ids.length} из ${WORLD.journals.length}. Записи остались на обломках кораблей — подлетите к мигающему корпусу.</p>`;
  WORLD.sectors.forEach((sc,si)=>{const all=WORLD.journals.filter(j=>j.sec===si),got=all.filter(j=>S.journals[j.id]);if(!all.length)return;
    h+=`<div class="jsec${got.length?'':' empty'}">${roman(si+1)} · ${sc.name} <small>${got.length}/${all.length}</small></div>`;
    h+=got.map(card).join('');});
  {const ws=S&&typeof w58S==='function'?w58S():null;if(ws){const got=W58.recs.filter(r=>ws.arcRec.includes(r.id));h+=`<div class="jsec">ЗАПИСИ АРХИВА <small>${got.length}/6</small></div>`+(got.length?got.map(r=>`<div class="jr"><h4>${r.title}</h4><p>${w58RecText(r)}</p></div>`).join(''):'<div class="jr lockd"><h4>— НЕ НАЙДЕНО —</h4><p>Ледяные капсулы дрейфуют по Холодному архиву. Их шесть.</p></div>');}}
  const fr=S&&S.story?Object.entries(S.story.frags).sort((a,b)=>a[1]-b[1]):[];
  h+=`<div class="jsec">ФРАГМЕНТЫ ПАМЯТИ <small>${fr.length}/15</small></div>`+(fr.length?fr.map(([,n])=>`<div class="jr frag"><h4>ФРАГМЕНТ ${n}</h4><p>${STORY_FRAG[n-1]}</p></div>`).join(''):'<div class="jr lockd"><h4>НЕ НАЙДЕНО</h4><p>Белые осколки света. Некоторые лежат там, где пространство уже не держит форму.</p></div>');
  if(typeof zbJournalsHTML==='function')h+=zbJournalsHTML(S);el.innerHTML=h;try{wreckIconsFill(el);}catch(e){console.error(e);}
}
$('#mapTabs').addEventListener('click',e=>{const b=e.target.closest('[data-mt]');if(b&&G.state==='map')mapTab(b.dataset.mt);});
$('#mapJr').addEventListener('click',e=>{const b=e.target.closest('[data-jmap]');if(!b)return;const j=WORLD.journals.find(q=>q.id===b.dataset.jmap);if(!j)return;G.mapHi={x:j.x,y:j.y,until:performance.now()+3000};mapTab('map');});
function closeMap(){if(G.state!=='map')return;scr6('world');G.cardKey=null;show('');}
function jumpPoints(){const S=G.save,pts=[];
  WORLD.nodes.forEach(n=>{if(nodeState(n.m)==='done'||ALPHA_OPEN/* ВРЕМЕННО (альфа 0.5.9): прыжок к любому узлу */)pts.push({x:n.x,y:n.y+150,label:pad2(n.m)});});
  WORLD.sectors.slice(2).forEach((sc,i)=>pts.push({x:sc.bx,y:sc.by+150,label:roman(i+3)}));
  WORLD.shops.forEach(s=>{pts.push({x:s.x,y:s.y+150,label:'М'});});
  WORLD.relays.forEach(r=>{if(S.relays[r.id])pts.push({x:r.x,y:r.y+120,label:'Р'});});
  pts.push({x:WORLD.hangar.x,y:WORLD.hangar.y+150,label:'А'});
  if(arsOpen())pts.push({x:WORLD.arsenal.x,y:WORLD.arsenal.y+150,label:'И'});
  if(abyssOpen()&&(revealedAt(WORLD.abyss.x,WORLD.abyss.y)||ALPHA_OPEN/* ВРЕМЕННО (альфа 0.5.9) */))pts.push({x:WORLD.abyss.x,y:WORLD.abyss.y+150,label:'∞'});return pts.filter(q=>!fogBlockedAt(q.x,q.y-150));}


// ---- HUD мира ----
let miniT=0;
function updateWorldHUD(){
  const p=G.player,st=G.st,S=G.save;if(!p||!S)return;
  setT('hpT',Math.ceil(p.hp)+'/'+st.maxHp);setS('hpB',(p.hp/st.maxHp).toFixed(3));
  setS('enB',(p.en/100).toFixed(3));setC('enBar','full',p.en>=100);
  setT('wSec',sectorName(p.x,p.y));{const v=lomH(S.lom,1)+(S.carry?` <span style="font-size:13px;color:var(--amber)">+${fmtN(S.carry)}</span>`:'');if(hudCache.wLom!==v){hudCache.wLom=v;$('#wLom').innerHTML=v;}}
  let sub='';
  if(G.anom){const A=G.anom;sub=A.a.hud?A.a.hud():'АНОМАЛИЯ · '+A.a.name+' · '+Math.max(0,Math.ceil(A.dur-A.t))+' С'+(A.a.kind==='cells'||A.a.kind==='coldcore'?' · '+A.got+'/'+A.need:'');}
  setT('wSub',hudClean(sub));setC('hud0','subimp',!!G.anom);if(typeof zbHud==='function')zbHud();
  hudEls.score.firstChild.nodeValue=fmt(G.score);
  const blocked=dashBlocked();const dr=p.dashCd<=0&&!blocked;
  setT('dashC','РЫВОК');setF('dashC',p.dashCd>0?1-p.dashCd/(p.dashCdMax||st.dashCd||1):0);setC('dashC','ok',dr);setC('dashC','bad',false);setC('tDash','cd',!dr);
  const pr=p.en>=100;setT('pulseC',pr?'ИМПУЛЬС [E]':'ИМПУЛЬС');setF('pulseC',pr?0:p.en/100);setC('pulseC','ok',pr);setC('tPulse','cd',!pr);
  setH('cargoC',true);
  setT('lvC','ЩИТ');setH('lvC',!st.shieldCd);setC('lvC','ok',!!(st.shieldCd&&p.shieldUp));setS('xpB',(G.xp/G.need).toFixed(3));
  chargeChip();
  {const I=G.riftI||0,hd=$('#hud');if(I>=.7&&SET.fx){hd.style.transform=vR5()<.25?`translate(${vrnd5(-4,4).toFixed(1)}px,${vrnd5(-2,2).toFixed(1)}px)`:'';hd.style.opacity=vR5()<.12?'.55':'1';if(vR5()<.08){hudEls.wLom&&(hudCache.wLom=null);$('#wLom').textContent='▒░▒ ░▒▒';hudCache.wLom='glitch';}}
    else if(hd.style.transform||hd.style.opacity){hd.style.transform='';hd.style.opacity='';}}
  if(++miniT%(isMob()?[4,2,1][G.q]||2:2)===0)drawMini();
}
$('#mini').addEventListener('click',()=>{if(G.state==='world'&&isMob())openMap();});
function drawMini(){
  const c=$('#mini');if(!c)return;if(typeof zbMini==='function'&&zbMini())return;const g=c.getContext('2d'),s=c.width,R=2600,k=s/2/R,p=G.player,S=G.save;
  g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,s,s);g.save();g.beginPath();g.arc(s/2,s/2,s/2-1,0,TAU);g.clip();
  g.fillStyle='rgba(4,6,12,.85)';g.fillRect(0,0,s,s);
  const P=(x,y)=>[s/2+(x-p.x)*k,s/2+(y-p.y)*k];
  if(!gateOpen()/* ВРЕМЕННО (альфа 0.5.9) */&&p.y>OY-2600){const [gx]=P(5000,0);g.strokeStyle='rgba(180,140,255,.5)';g.setLineDash([3,3]);g.beginPath();g.moveTo(gx,0);g.lineTo(gx,s);g.stroke();g.setLineDash([]);}
  for(const r of G.rocks){const [x,y]=P(r.x,r.y);g.fillStyle='#26324a';g.fillRect(x-1,y-1,2,2);}
  WORLD.nodes.forEach(n=>{const [x,y]=P(n.x,n.y);const st=nodeState(n.m);g.fillStyle=n.boss&&st!=='done'?'#ff6b8a':st==='done'?'#8fe9ff':st==='open'?'#ffb84d':'#3a4558';g.beginPath();g.arc(x,y,st==='open'?6:4,0,TAU);g.fill();});
  WORLD.shops.forEach(sh=>{const [x,y]=P(sh.x,sh.y);g.fillStyle='#ffb84d';g.fillRect(x-4,y-4,8,8);});
  {const [x,y]=P(WORLD.hangar.x,WORLD.hangar.y);g.save();g.translate(x,y);g.rotate(Math.PI/4);g.fillStyle='#ff6bd0';g.fillRect(-4,-4,8,8);g.restore();}
  {const [x,y]=P(WORLD.arsenal.x,WORLD.arsenal.y);g.fillStyle=arsOpen()?'#9fe3ff':'#3a5a74';g.beginPath();g.arc(x,y,4,0,TAU);g.fill();}
  WORLD.anomalies.forEach(a=>{if(S.anomalies[a.id])return;const [x,y]=P(a.x,a.y);g.strokeStyle='#c9a6ff';g.beginPath();g.arc(x,y,5,0,TAU);g.stroke();});
  WORLD.relays.forEach(r=>{const [x,y]=P(r.x,r.y);g.fillStyle=S.relays[r.id]?'#8fe9ff':'#ff4f6e';g.fillRect(x-3,y-3,6,6);});
  if(abyssOpen()){const [x,y]=P(WORLD.abyss.x,WORLD.abyss.y);g.fillStyle='#c9a6ff';g.font='700 13px "JetBrains Mono",monospace';g.textAlign='center';g.fillText('∞',x,y+4);}
  if(perk('scan')){WORLD.caches.forEach(c=>{if(S.found[c.id]||Math.hypot(c.x-p.x,c.y-p.y)>1600)return;const [x,y]=P(c.x,c.y);g.strokeStyle='#ffb84d';g.lineWidth=1.5;g.strokeRect(x-3,y-3,6,6);});
    WORLD.journals.forEach(j=>{if(S.journals[j.id]||Math.hypot(j.x-p.x,j.y-p.y)>1600)return;const [x,y]=P(j.x,j.y);g.strokeStyle='#8fe9ff';g.lineWidth=1.5;g.beginPath();g.arc(x,y,3,0,TAU);g.stroke();});}
  if(G.unk&&G.unk.length){g.font='700 10px "JetBrains Mono",monospace';g.textAlign='center';g.fillStyle='#ff4f6e';for(const u of G.unk){if(u.x===undefined)continue;let [x,y]=P(u.x,u.y);const dx=x-s/2,dy=y-s/2,dl=Math.hypot(dx,dy),mr=s/2-8;if(dl>mr){x=s/2+dx/dl*mr;y=s/2+dy/dl*mr;}g.globalAlpha=.6+.4*Math.sin(G.t*10);g.fillText('?',x,y+3);g.globalAlpha=1;}}
  if((G.riftI||0)>.05){g.globalAlpha=Math.min(.6,G.riftI*.7);for(let i=0;i<40;i++){g.fillStyle=vR5()<.5?'#ff4f6e':'#9fb0c4';g.fillRect(vR5()*s,vR5()*s,2,1);}g.globalAlpha=1;}
  if(S.lost){const [x,y]=P(S.lost.x,S.lost.y);g.fillStyle='#ff4f6e';g.beginPath();g.arc(x,y,4,0,TAU);g.fill();}
  if(G.course){let [x,y]=P(G.course.x,G.course.y);const dx=x-s/2,dy=y-s/2,dl=Math.hypot(dx,dy),mr=s/2-6;if(dl>mr){x=s/2+dx/dl*mr;y=s/2+dy/dl*mr;}g.strokeStyle='rgba(143,233,255,.7)';g.lineWidth=2;g.setLineDash([4,4]);g.beginPath();g.moveTo(s/2,s/2);g.lineTo(x,y);g.stroke();g.setLineDash([]);}
  STORY_FRAGS.forEach(f=>{if(!fragAvail(f))return;const q=fragPos(f);if(Math.hypot(q.x-p.x,q.y-p.y)>1600)return;const [x,y]=P(q.x,q.y);g.fillStyle='#ffffff';g.fillRect(x-2,y-2,4,4);});
  WORLD.journals.forEach(j=>{if(S.journals[j.id]||Math.hypot(j.x-p.x,j.y-p.y)>1600||perk('scan'))return;const [x,y]=P(j.x,j.y);g.strokeStyle='rgba(143,233,255,.6)';g.lineWidth=1;g.beginPath();g.arc(x,y,3,0,TAU);g.stroke();});
  mini95(g,P,s);
  for(const e of G.enemies){if(!e.alive||e.type==='mine')continue;const [x,y]=P(e.x,e.y);g.fillStyle=e.type==='lock'?'#b48cff':'#ff4f6e';g.fillRect(x-2,y-2,4,4);}
  if(!openAllNow()){const fx=fogSeeX();if(fx<Infinity){const [gx]=P(fx,0);if(gx<s+30){const gr=g.createLinearGradient(gx-26,0,gx+4,0);gr.addColorStop(0,'rgba(3,5,11,0)');gr.addColorStop(1,'rgba(3,5,11,.95)');g.fillStyle=gr;g.fillRect(Math.max(0,gx-26),0,s,s);}}}
  g.translate(s/2,s/2);g.rotate(p.ang);g.fillStyle=shipCol();g.beginPath();g.moveTo(8,0);g.lineTo(-5,-5);g.lineTo(-3,0);g.lineTo(-5,5);g.closePath();g.fill();
  g.restore();g.strokeStyle='#1c2a42';g.lineWidth=2;g.beginPath();g.arc(s/2,s/2,s/2-1,0,TAU);g.stroke();
}
function nextTarget(){const S=G.save;if(S.cleared>=CORE){const n=WORLD.nodes.find(q=>q.m>CORE&&nodeState(q.m)!=='done');return n?{x:n.x,y:n.y,label:(n.boss?'БОСС ':'МИССИЯ ')+pad2(n.m),col:n.boss?'#ff6b8a':'#ffb84d'}:null;}if(S.cleared>=6&&!S.gate)return{x:WORLD.gate.x,y:WORLD.gate.y,label:'ВОРОТА',col:'#b48cff'};const n=WORLD.nodes[S.cleared];return{x:n.x,y:n.y,label:'МИССИЯ '+pad2(n.m),col:'#ffb84d'};}

// ---- отрисовка мира ----
function renderWorld(now){
  const t=now/1000,p=G.player,S=G.save;
  ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  if(nebula)ctx.drawImage(nebula,0,0,cv.width,cv.height);
  const rI=G.riftI||0,sx=(G.shake?rnd(-G.shake,G.shake):0)+(SET.fx?Math.sin(t*1.3)*6*rI:0),sy=(G.shake?rnd(-G.shake,G.shake):0)+(SET.fx?Math.cos(t*1.1)*6*rI:0),k=DPR*SC;
  ctx.setTransform(k,0,0,k,0,0);
  for(const s of stars){const x=((s.x-CX*s.k*2.5)%(W*1.2)+W*1.2)%(W*1.2)-W*.1,y=((s.y-CY*s.k*2.5)%(H*1.2)+H*1.2)%(H*1.2)-H*.1;
    ctx.globalAlpha=.45+.4*Math.sin(t*1.3+s.tw);ctx.fillStyle=s.k>.06?'#cfeeff':'#7f9ab5';ctx.fillRect(x,y,s.s,s.s);}
  ctx.globalAlpha=1;
  wbg95(t,k,sx,sy);{const Z=G.wz95||1;ctx.setTransform(k*Z,0,0,k*Z,((sx-CX)*Z+W/2*(1-Z))*k,((sy-CY)*Z+H/2*(1-Z))*k);}
  if(SET.fx)for(const n of G.decor)if(inView(n.x,n.y,n.r))glow(n.x,n.y,n.r,n.col,n.a);
  for(const sc of WORLD.sectors){const b=sc.box;if(b[2]<CX-50||b[0]>CX+W+50||b[3]<CY-50||b[1]>CY+H+50)continue;ctx.strokeStyle=sc.col;ctx.globalAlpha=.16;ctx.lineWidth=4;ctx.setLineDash([24,18]);ctx.strokeRect(b[0],b[1],b[2]-b[0],b[3]-b[1]);ctx.setLineDash([]);ctx.globalAlpha=1;
    if(inView(b[0]+260,b[3]-60,300)){ctx.font='700 13px "JetBrains Mono",monospace';ctx.textAlign='left';ctx.fillStyle=sc.col;ctx.globalAlpha=.55;ctx.fillText('СЕКТОР '+roman(WORLD.sectors.indexOf(sc)+1)+' · '+sc.name,b[0]+40,b[3]-40);ctx.globalAlpha=1;}
    if(sc.bx&&inView(sc.bx,sc.by,120)){ctx.save();ctx.translate(sc.bx,sc.by);glow(0,0,90,sc.col,.35);ctx.rotate(t*.4);ctx.strokeStyle=sc.col;ctx.lineWidth=2;poly(4,22,0);ctx.stroke();ctx.rotate(-t*.8);poly(4,12,0);ctx.stroke();ctx.restore();worldLabel(sc.bx,sc.by-46,'МАЯК СЕКТОРА '+roman(WORLD.sectors.indexOf(sc)+1),sc.col);}}
  // ворота
  const gt=WORLD.gate;
  if(!gateOpen()/* ВРЕМЕННО (альфа 0.5.9) */){ctx.strokeStyle='#7c5cff';ctx.lineWidth=1.5;const y0=Math.max(OY,CY-40),y1=Math.min(OY+WH0,CY+H+40);
    for(let y=y0-(y0%30);y<y1;y+=30){ctx.globalAlpha=.15+.35*Math.abs(Math.sin(t*3+y*.05));ctx.beginPath();ctx.moveTo(5000+rnd(-6,6),y);ctx.lineTo(5000+rnd(-6,6),y+22);ctx.stroke();}
    ctx.globalAlpha=1;}
  if(inView(gt.x,gt.y,260)){ctx.save();ctx.translate(gt.x,gt.y);glow(0,0,240,S.gate?'#8fe9ff':'#7c5cff',.35);ctx.rotate(t*.15);ctx.strokeStyle=S.gate?'#8fe9ff':'#b48cff';ctx.lineWidth=4;
    for(let i=0;i<6;i++){ctx.beginPath();ctx.arc(0,0,150,i/6*TAU,i/6*TAU+.7);ctx.stroke();}ctx.restore();
    if(!S.gate)for(const e of G.enemies)if(e.type==='lock'&&e.alive){ctx.strokeStyle='#b48cff';ctx.globalAlpha=.4+.3*Math.sin(t*6);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(gt.x,gt.y);ctx.stroke();ctx.globalAlpha=1;}
    worldLabel(gt.x,gt.y-185,S.gate?'ВОРОТА ОТКРЫТЫ':ALPHA_OPEN/* ВРЕМЕННО (альфа 0.5.9) */?'ВОРОТА СЕКТОРА · АЛЬФА: ПРОХОД ОТКРЫТ':'ВОРОТА СЕКТОРА',S.gate?'#8fe9ff':'#b48cff');}
  // аномалии
  for(const a of WORLD.anomalies){if(!inView(a.x,a.y,420))continue;const done=S.anomalies[a.id],act=G.anom&&G.anom.a===a;
    if(act&&a.kind==='storm'){const A=G.anom;ctx.strokeStyle='#9fb4ff';ctx.lineWidth=2;ctx.globalAlpha=.6;ctx.setLineDash([10,8]);ctx.beginPath();ctx.arc(a.x,a.y,A.R,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
      if(A.beamWarn||A.beamOn)for(const k of [0,Math.PI]){const ang=A.beamA+k,ex=a.x+Math.cos(ang)*A.R,ey=a.y+Math.sin(ang)*A.R;
        if(A.beamOn){ctx.globalCompositeOperation='lighter';ctx.strokeStyle='#9fb4ff';ctx.globalAlpha=.5;ctx.lineWidth=22;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(ex,ey);ctx.stroke();ctx.strokeStyle='#ffffff';ctx.globalAlpha=.9;ctx.lineWidth=4;ctx.stroke();ctx.globalCompositeOperation='source-over';}
        else{ctx.strokeStyle='#9fb4ff';ctx.globalAlpha=.4+.4*Math.sin(t*30);ctx.lineWidth=2;ctx.setLineDash([12,8]);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(ex,ey);ctx.stroke();ctx.setLineDash([]);}ctx.globalAlpha=1;}}
    if(done){ctx.strokeStyle='#3a4558';ctx.lineWidth=1;ctx.beginPath();ctx.arc(a.x,a.y,30,0,TAU);ctx.stroke();continue;}
    for(let i=0;i<3;i++){ctx.strokeStyle='#c9a6ff';ctx.globalAlpha=.25+.15*i;ctx.lineWidth=2;ctx.beginPath();ctx.arc(a.x,a.y,26+i*14,t*(1+i*.4),t*(1+i*.4)+4);ctx.stroke();}ctx.globalAlpha=1;
    glow(a.x,a.y,60,'#c9a6ff',.5);worldLabel(a.x,a.y-80,'АНОМАЛИЯ · '+a.name,'#c9a6ff');}
  // ретрансляторы
  for(const r of WORLD.relays){if(!inView(r.x,r.y,200))continue;const ok=S.relays[r.id];const col=ok?'#8fe9ff':'#ff4f6e';glow(r.x,r.y,50,col,ok?.6:.3+.3*(Math.sin(t*8)>0?1:0));
    ctx.save();ctx.translate(r.x,r.y);ctx.fillStyle='#0b1220';ctx.strokeStyle=col;ctx.lineWidth=2.5;poly(3,22,-Math.PI/2);ctx.fill();ctx.stroke();ctx.restore();
    if(!ok&&r.rep>0){ctx.strokeStyle='#8fe9ff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(r.x,r.y,34,-Math.PI/2,-Math.PI/2+TAU*r.rep/2);ctx.stroke();}
    worldLabel(r.x,r.y-50,ok?'РЕТРАНСЛЯТОР':'РЕТРАНСЛЯТОР · ПОВРЕЖДЁН',col);}
  // мастерские
  for(const s of WORLD.shops){if(!inView(s.x,s.y,200))continue;ctx.save();ctx.translate(s.x,s.y);glow(0,0,110,'#ffb84d',.35);ctx.rotate(t*.3);ctx.strokeStyle='#ffb84d';ctx.fillStyle='#0b1220';ctx.lineWidth=2.5;
    ctx.fillRect(-36,-36,72,72);ctx.strokeRect(-36,-36,72,72);for(let i=0;i<4;i++){ctx.rotate(Math.PI/2);ctx.beginPath();ctx.moveTo(36,0);ctx.lineTo(62,0);ctx.stroke();ctx.fillStyle='#ffb84d';ctx.fillRect(60,-5,10,10);ctx.fillStyle='#0b1220';}
    ctx.restore();worldLabel(s.x,s.y-90,s.name,'#ffb84d');}
  storyDrawWorld(t);w58Draw(t);w74Draw(t);d74Under(t);w80Draw(t);d80Under(t);zbUnder(t);zbWallsDraw(t);
  // тайники: видны только вблизи
  for(const c of WORLD.caches){if(S.found[c.id]||Math.hypot(p.x-c.x,p.y-c.y)>650)continue;const a=1-Math.hypot(p.x-c.x,p.y-c.y)/650;glow(c.x,c.y,30,'#ffb84d',a*(.5+.5*Math.sin(t*6)));
    ctx.save();ctx.translate(c.x,c.y);ctx.rotate(t);ctx.globalAlpha=a;ctx.strokeStyle='#ffb84d';ctx.lineWidth=2;ctx.strokeRect(-9,-9,18,18);ctx.restore();ctx.globalAlpha=1;}
  // ангар «Зеркало»
  {const hg=WORLD.hangar;if(inView(hg.x,hg.y,220)){const ks=Object.keys(SKINS);ctx.save();ctx.translate(hg.x,hg.y);glow(0,0,130,'#ff6bd0',.3);ctx.rotate(t*.25);
    for(let i=0;i<6;i++){ctx.save();ctx.rotate(i/6*TAU);ctx.translate(58,0);ctx.rotate(Math.PI/2);const col=SKINS[ks[(i+Math.floor(t*.5))%ks.length]].col;
      ctx.fillStyle='#0b1220';ctx.strokeStyle=col;ctx.lineWidth=2;ctx.fillRect(-14,-5,28,10);ctx.strokeRect(-14,-5,28,10);ctx.fillStyle=col;ctx.globalAlpha=.35+.25*Math.sin(t*3+i);ctx.fillRect(-12,-3,24,6);ctx.globalAlpha=1;ctx.restore();}
    ctx.restore();ctx.save();ctx.translate(hg.x,hg.y);ctx.rotate(-t*.6);drawShip(curSkin(),t,200,{});ctx.restore();
    worldLabel(hg.x,hg.y-92,hg.name,'#ff6bd0');}}
  {const ar=WORLD.arsenal;if(inView(ar.x,ar.y,220)){const open=arsOpen();ctx.save();ctx.translate(ar.x,ar.y);glow(0,0,120,'#8fd8ff',open?.3:.12);ctx.save();ctx.rotate(t*.15);ctx.strokeStyle=open?'#9fe3ff':'#3a5a74';ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;ctx[i?'lineTo':'moveTo'](Math.cos(a)*56,Math.sin(a)*56);}ctx.closePath();ctx.stroke();ctx.globalAlpha=.3;ctx.fillStyle=open?'#8fd8ff':'#1c2e44';ctx.fill();ctx.globalAlpha=1;ctx.restore();
    ctx.rotate(-t*.5);for(let i=0;i<3;i++){ctx.save();ctx.rotate(i/3*TAU);ctx.translate(34,0);ctx.fillStyle=open?'#dff6ff':'#3a5a74';ctx.globalAlpha=open?.6+.3*Math.sin(t*3+i):.5;ctx.fillRect(-10,-3,20,6);ctx.restore();}ctx.restore();
    if(!open){ctx.strokeStyle='#9fd8ff';ctx.lineWidth=2;ctx.strokeRect(ar.x-9,ar.y-6,18,14);ctx.beginPath();ctx.arc(ar.x,ar.y-6,6,Math.PI,0);ctx.stroke();}
    worldLabel(ar.x,ar.y-84,ar.name+(open?'':' · ЗАПЕЧАТАН'),open?'#9fe3ff':'#5a7a94');}}
  drawAbyss(t);
  // узлы миссий
  for(const n of WORLD.nodes){if(!inView(n.x,n.y,460))continue;drawNode(n,t);}
  if(S.lost&&inView(S.lost.x,S.lost.y,60)){glow(S.lost.x,S.lost.y,40,'#ff4f6e',.6+.3*Math.sin(t*5));worldLabel(S.lost.x,S.lost.y-30,'ПОТЕРЯННЫЙ ЛОМ · '+S.lost.v,'#ff4f6e');}
  if(G.unlockFx){const U=G.unlockFx,q=Math.min(1,U.t/1.5);ctx.globalCompositeOperation='lighter';ctx.strokeStyle='#ffb84d';ctx.lineWidth=6;ctx.globalAlpha=.6*(1-Math.max(0,U.t-2)/1.2);
    ctx.beginPath();ctx.moveTo(U.x0,U.y0);ctx.lineTo(U.x0+(U.x1-U.x0)*q,U.y0+(U.y1-U.y0)*q);ctx.stroke();ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
  drawRocks(G.rocks);try{postWorldDraw(t);}catch(e){}try{chaseDraw(t);}catch(e){}
  drawPickups();
  for(const e of G.enemies)if(inView(e.x,e.y,e.r+80))drawEnemy(e,t);
  w58DrawTop(t);w74DrawTop(t);zbDraw(t);d80Draw(t);w80Mask(sx-CX,sy-CY);
  fogDraw(t);
  ctx.globalCompositeOperation='lighter';
  const BC=shipBul();for(const b of G.pb){if(b.blast){glow(b.x,b.y,b.charged?34:22,'#9fe3ff',.8);ctx.strokeStyle='#9fe3ff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(b.x-b.vx*.03,b.y-b.vy*.03);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.fillStyle='#dff6ff';ctx.beginPath();ctx.arc(b.x,b.y,b.charged?7:4.5,0,TAU);ctx.fill();continue;}if(b.charged){glow(b.x,b.y,34,BC,.9);ctx.strokeStyle='#ffffff';ctx.lineWidth=7;ctx.beginPath();ctx.moveTo(b.x-b.vx*.05,b.y-b.vy*.05);ctx.lineTo(b.x,b.y);ctx.stroke();continue;}ctx.strokeStyle=b.pk90?'#ffd36b':b.drone?'#c9b6ff':BC;ctx.lineWidth=b.pk90?4.5:3;ctx.beginPath();ctx.moveTo(b.x-b.vx*.018,b.y-b.vy*.018);ctx.lineTo(b.x,b.y);ctx.stroke();}
  for(const b of G.eb){if(b.rift)continue;glow(b.x,b.y,Math.max(b.r*3.2,BMIN*4.5),b.col,.8);}
  ctx.globalCompositeOperation='source-over';
  for(const b of G.eb){if(b.k95){eb95Draw(b,t);continue;}if(b.copy){ctx.strokeStyle=b.col;ctx.lineWidth=3;ctx.globalAlpha=.9;ctx.beginPath();ctx.moveTo(b.x-b.vx*.02,b.y-b.vy*.02);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.globalAlpha=1;continue;}if(b.rift){ctx.strokeStyle='#ff4f6e';ctx.lineWidth=4;ctx.globalAlpha=.5;ctx.beginPath();ctx.moveTo(b.x-b.vx*.03,b.y-b.vy*.03);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.globalAlpha=1;ctx.stroke();continue;}ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(b.x,b.y,Math.max(b.r*.55,BMIN),0,TAU);ctx.fill();if(BMIN||G.ol95){ctx.strokeStyle='#04060c';ctx.lineWidth=(G.ol95?1.5:1)/SC;ctx.stroke();}}
  drawPlayer(p,t);
  ctx.globalCompositeOperation='lighter';
  for(const q of G.parts){ctx.globalAlpha=q.life/q.max;ctx.fillStyle=q.col;ctx.fillRect(q.x-q.size/2,q.y-q.size/2,q.size,q.size);}
  for(const s of G.shock){ctx.globalAlpha=(1-s.t)*(s.thin?.5:.8);ctx.strokeStyle=s.col;ctx.lineWidth=s.thin?2:5*(1-s.t)+1;ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,TAU);ctx.stroke();}
  ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  if(G.prio&&G.prio.alive){const e=G.prio,r=e.r+10,a=t*2;ctx.strokeStyle='#ffffff';ctx.lineWidth=2;for(let i=0;i<4;i++){const q=a+i*Math.PI/2;ctx.beginPath();ctx.arc(e.x,e.y,r,q,q+.5);ctx.stroke();}}
  ctx.textAlign='center';ctx.font='700 '+fpx(12)+'px "JetBrains Mono",monospace';
  for(const f of G.float){ctx.globalAlpha=Math.min(1,f.life*2);ctx.fillStyle='#04060c';ctx.fillText(f.text,f.x+1,f.y+1);ctx.fillStyle=f.col;ctx.fillText(f.text,f.x,f.y);}
  ctx.globalAlpha=1;
  if(aimManual()&&p&&p.hp>0&&(G.state==='play'||G.state==='world')){const m=mouseWorld(),c=shipCol();ctx.strokeStyle=c;ctx.lineWidth=1;ctx.globalAlpha=.85;
    for(let i=0;i<4;i++){const a=i*Math.PI/2;ctx.beginPath();ctx.moveTo(m.x+Math.cos(a)*3,m.y+Math.sin(a)*3);ctx.lineTo(m.x+Math.cos(a)*6,m.y+Math.sin(a)*6);ctx.stroke();}
    ctx.fillStyle=c;ctx.fillRect(m.x-.75,m.y-.75,1.5,1.5);
    const L=G.aimLock;if(L&&L.alive){const r=L.r+7,q=5;ctx.lineWidth=1.5;ctx.globalAlpha=.95;for(const [sx2,sy2] of [[-1,-1],[1,-1],[1,1],[-1,1]]){ctx.beginPath();ctx.moveTo(L.x+sx2*r,L.y+sy2*(r-q));ctx.lineTo(L.x+sx2*r,L.y+sy2*r);ctx.lineTo(L.x+sx2*(r-q),L.y+sy2*r);ctx.stroke();}}
    ctx.globalAlpha=1;}
  // тёмная зона
  let dk=0;for(const d of WORLD.dark){const q=Math.hypot(p.x-d.x,p.y-d.y);dk=Math.max(dk,clamp((d.r-q)/(d.r*.45),0,1));}
  if(dk>.02)drawWorldDark(sx,sy,dk*.9);
  drawRiftFx(Math.max(G.riftI||0,G.wakeI||0),t);w58Screen(t);zbTop(t);
  // стрелки у края экрана
  ctx.setTransform(DPR,0,0,DPR,0,0);
  const arrow=(x,y,col,label)=>{if(arw61Dup(x,y))return;if(isMob()){edgeArrow(x,y,col,10,label+' · '+fmtAU(Math.hypot(x-p.x,y-p.y)));ctx.setTransform(DPR,0,0,DPR,0,0);return;}const X=(x-CX)*SC,Y=(y-CY)*SC;if(X>20&&X<CW-20&&Y>20&&Y<CH-20)return;
    const cx=CW/2,cy=CH/2,a=Math.atan2(Y-cy,X-cx),m=46*UI,sl=stageL(),ex=clamp(cx+Math.cos(a)*CW,sl+m,CW-sl-m),ey=clamp(cy+Math.sin(a)*CH,m+170*UI,CH-m-80*UI);
    ctx.save();ctx.translate(ex,ey);ctx.rotate(a);ctx.scale(UI,UI);ctx.fillStyle=col;ctx.globalAlpha=.85+.15*Math.sin(t*5);ctx.beginPath();ctx.moveTo(12,0);ctx.lineTo(-6,-8);ctx.lineTo(-2,0);ctx.lineTo(-6,8);ctx.closePath();ctx.fill();ctx.restore();
    ctx.globalAlpha=1;ctx.font='700 '+(10*UI)+'px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle=col;const dd=fmtAU(Math.hypot(x-p.x,y-p.y));
    {const tl=label+' · '+dd,tx=clamp(ex-Math.cos(a)*34*UI,stageL()+70*UI,CW-stageL()-70*UI),ty=lab61Place(tx,ey-(Math.sin(a)*22-4)*UI,ctx.measureText(tl).width/2+4,10*UI);ctx.lineJoin='round';ctx.lineWidth=4*UI;ctx.strokeStyle='rgba(4,6,12,.92)';ctx.strokeText(tl,tx,ty);ctx.fillText(tl,tx,ty);}};
  if(G.course){if(Math.hypot(G.course.x-p.x,G.course.y-p.y)<240){G.course=null;floater(p.x,p.y-44,'ВЫ НА МЕСТЕ','#8fe9ff');}else arrow(G.course.x,G.course.y,'#8fe9ff','КУРС · '+G.course.label);}
  const nt=zbOn()?null:tut133HoldNext()?tut134Home():nextTarget();if(nt)arrow(nt.x,nt.y,nt.col,nt.label);
  if(S.lost)arrow(S.lost.x,S.lost.y,'#ff4f6e','ЛОМ');
  if(G.anom&&G.anom.a.kind!=='conveyor')arrow(G.anom.a.x,G.anom.a.y,'#c9a6ff','АНОМАЛИЯ');
  if(G.w&&G.w.tug&&G.w.tug.alive&&Math.hypot(G.w.tug.x-p.x,G.w.tug.y-p.y)<2500)arrow(G.w.tug.x,G.w.tug.y,'#7affc9',G.w.tug.st==='escort'?'БУКСИР':'ГРАЖДАНСКИЕ');
  if((G.riftI||0)>=.35&&G.riftBack&&p.hp>0){const X=(G.riftBack.x-CX)*SC,Y=(G.riftBack.y-CY)*SC;if(X>20&&X<CW-20&&Y>20&&Y<CH-20){ctx.font='700 11px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#8fe9ff';ctx.fillText('↓ СЕКТОР',X,Y);}else arrow(G.riftBack.x,G.riftBack.y,'#8fe9ff','К СЕКТОРУ');}
  if(G.unk&&G.unk.length&&p.hp>0)for(const u of G.unk){if(u.x===undefined)continue;const X=(u.x-CX)*SC,Y=(u.y-CY)*SC,cx=CW/2,cy=CH/2,a=Math.atan2(Y-cy,X-cx);
    const ex=clamp(cx+Math.cos(a)*CW,30,CW-30),ey=clamp(cy+Math.sin(a)*CH,40,CH-40);ctx.font='700 13px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#ff4f6e';ctx.globalAlpha=.55+.45*Math.sin(t*10+u.a);ctx.fillText('?',ex,ey);ctx.globalAlpha=1;}
  // помехи на экране у закрытого узла
  let nz=0;for(const n of WORLD.nodes){if(nodeState(n.m)!=='locked')continue;nz=Math.max(nz,clamp((640-Math.hypot(p.x-n.x,p.y-n.y))/220,0,1));}
  if(nz>0&&SET.fx){ctx.globalAlpha=.08*nz;ctx.fillStyle='#9fb0c4';for(let i=0;i<40;i++)ctx.fillRect(Math.random()*CW,Math.random()*CH,rnd(20,120),1);ctx.globalAlpha=1;}
  if(G.hurtV>0||(p.hp>0&&p.hp<G.st.maxHp*.25)){ctx.setTransform(1,0,0,1,0,0);const v=Math.max(G.hurtV*.55,p.hp<G.st.maxHp*.25?.16+.08*Math.sin(t*5):0);
    const g=ctx.createRadialGradient(cv.width/2,cv.height/2,Math.min(cv.width,cv.height)*.35,cv.width/2,cv.height/2,Math.max(cv.width,cv.height)*.7);g.addColorStop(0,'rgba(255,40,70,0)');g.addColorStop(1,`rgba(255,40,70,${v})`);ctx.fillStyle=g;ctx.fillRect(0,0,cv.width,cv.height);}
}
function fpx(n){return isMob()?Math.max(n,11.5/SC):n;}
function worldLabel(x,y,text,col){ctx.font='700 '+fpx(11)+'px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillStyle='#04060c';ctx.fillText(text,x+1,y+1);ctx.fillStyle=col;ctx.fillText(text,x,y);}
function drawNode(n,t){
  if(n.m===50&&typeof zbDrawNode==='function'){zbDrawNode(n,t);return;}
  const st=nodeState(n.m),M=MISSIONS[n.m-1],S=G.save;
  if(st==='locked'){drawWell(n,t);return;}
  const col=st==='done'?'#8fe9ff':'#ffb84d';
  if(st==='open'){for(let i=0;i<3;i++){const q=((t*.5+i/3)%1);ctx.strokeStyle=col;ctx.globalAlpha=(1-q)*.6;ctx.lineWidth=2;ctx.beginPath();ctx.arc(n.x,n.y,30+q*160,0,TAU);ctx.stroke();}ctx.globalAlpha=1;}
  if(n.boss){ctx.save();ctx.translate(n.x,n.y);glow(0,0,170,'#ff4f6e',.35);ctx.rotate(t*.15);ctx.strokeStyle='#ff6b8a';ctx.lineWidth=3;poly(8,92,0);ctx.stroke();ctx.rotate(-t*.3);ctx.globalAlpha=.6;ctx.setLineDash([16,12]);ctx.lineDashOffset=t*30;poly(8,120,0);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;ctx.restore();
    worldLabel(n.x,n.y+140,bossLab90(n.m),'#ff6b8a');}
  if(n.m>=7&&n.m<=CORE)drawMiniBeacon(n.x,n.y,col,t);
  else if(n.m===6){ctx.save();ctx.translate(n.x,n.y);glow(0,0,140,'#b48cff',st==='done'?.3:.55);ctx.rotate(t*.2);ctx.strokeStyle=st==='done'?'#5a4a8c':'#b48cff';ctx.lineWidth=4;
    for(let i=0;i<10;i++){const a=i/10*TAU;if(st==='done'&&i%3===0)continue;ctx.beginPath();ctx.arc(0,0,70,a,a+TAU/10-.15);ctx.stroke();}ctx.fillStyle=st==='done'?'#2a2440':'#e0d2ff';ctx.beginPath();ctx.arc(0,0,22,0,TAU);ctx.fill();ctx.restore();}
  else{ctx.save();ctx.translate(n.x,n.y);glow(0,0,70,col,.5);ctx.rotate(Math.PI/4+t*.4);ctx.fillStyle='#0b1220';ctx.strokeStyle=col;ctx.lineWidth=2.5;ctx.fillRect(-16,-16,32,32);ctx.strokeRect(-16,-16,32,32);ctx.restore();
    ctx.fillStyle=col;ctx.beginPath();ctx.arc(n.x,n.y,5,0,TAU);ctx.fill();}
  worldLabel(n.x,n.y-(n.m===6?110:62),pad2(n.m)+' · '+M.name.toUpperCase(),col);
  if(st==='done'){const md=S.medals[n.m]||{};const arr=[md.clear,md.clean,md.master];arr.forEach((on,i)=>{ctx.fillStyle=on?'#ffb84d':'#26324a';ctx.beginPath();ctx.arc(n.x-10+i*10,n.y+(n.m===6?100:50),3.5,0,TAU);ctx.fill();});}
}
function drawWorldDark(sx,sy,alpha){
  if(!darkC||darkC.width!==cv.width||darkC.height!==cv.height){darkC=document.createElement('canvas');darkC.width=cv.width;darkC.height=cv.height;dctx=darkC.getContext('2d');}
  const k=DPR*SC,p=G.player;dctx.globalCompositeOperation='source-over';dctx.clearRect(0,0,darkC.width,darkC.height);
  dctx.fillStyle=`rgba(1,2,7,${alpha.toFixed(3)})`;dctx.fillRect(0,0,darkC.width,darkC.height);dctx.globalCompositeOperation='destination-out';
  const X=(p.x-CX+sx)*k,Y=(p.y-CY+sy)*k,R=G.st.light*1.3*k;const g=dctx.createRadialGradient(X,Y,R*.3,X,Y,R);g.addColorStop(0,'rgba(0,0,0,1)');g.addColorStop(1,'rgba(0,0,0,0)');dctx.fillStyle=g;dctx.beginPath();dctx.arc(X,Y,R,0,TAU);dctx.fill();
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(darkC,0,0);ctx.restore();
}

// ---- код сохранения ----
function openSaveScreen(){try{$('#bSaveShare').hidden=!navigator.share;$('#savePasteRow').hidden=!(navigator.clipboard&&navigator.clipboard.readText);}catch(e){}/*DEVW*/if(window.DEVW&&!DEVW.on())DEVW.clearFlag(true);
  scr6('save');const S=store('void_world');
  $('#saveOut').value=validSave(S)?btoa(unescape(encodeURIComponent(JSON.stringify(S)))):'';
  $('#saveOut').placeholder='Сохранения пока нет. Начните полёт в открытом секторе.';$('#saveIn').value='';$('#saveMsg').textContent=saveStatus();show('sSave');
}
$('#bSaveCopy').onclick=()=>{const t=$('#saveOut');if(!t.value){$('#saveMsg').textContent='Копировать нечего: сохранения пока нет.';return;}
  const done=()=>{$('#saveMsg').textContent='Код скопирован.';};
  // 1.0.0 α: во встроенном окне буфер часто запрещён — запасной путь через выделение и execCommand
  const manual=()=>{try{t.focus();t.select();t.setSelectionRange(0,t.value.length);if(document.execCommand&&document.execCommand('copy')){done();return;}}catch(e){}
    $('#saveMsg').textContent='Код выделен — скопируйте его вручную (долгое нажатие → «Копировать»).';};
  try{if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t.value).then(done,manual);else manual();}catch(e){manual();}};
// 1.0.0 α: код чистится от того, что добавляют чаты и мессенджеры: кавычки, переносы, неразрывные и невидимые пробелы, текст вокруг
function codeDecode(raw){const one=c=>{c=c.replace(/=+$/,'').replace(/-/g,'+').replace(/_/g,'/');while(c.length%4)c+='=';const S=JSON.parse(decodeURIComponent(escape(atob(c))));return validSave(S)?S:null;};
  const s0=String(raw||'').replace(/[​-‏⁠﻿­]/g,'').replace(/[  -   　]/g,' ');
  const flat=s0.replace(/[\s"'`«»“”„‘’<>]/g,''),cands=[];
  const i=flat.indexOf('eyJ');if(i>=0){const m=flat.slice(i).match(/^[A-Za-z0-9+/=_-]+/);if(m)cands.push(m[0]);}
  const runs=flat.match(/[A-Za-z0-9+/_-]{40,}={0,2}/g);if(runs)cands.push(...runs.sort((a,b)=>b.length-a.length));cands.push(flat);
  for(const c of cands){try{const S=one(c);if(S)return S;}catch(e){}}return null;}
$('#bSaveLoad').onclick=()=>{const raw=$('#saveIn').value,S0=codeDecode(raw);
  if(!S0){$('#saveMsg').textContent=raw.trim()?'Код не распознан. Проверьте, что он скопирован целиком.':'Вставьте код сохранения в поле.';return;}
  store('void_world',S0);const S=migrateSave(JSON.parse(JSON.stringify(S0)));saveSet6(S,'import');cloudForce();
  $('#saveMsg').textContent='Полёт загружен: пройдено миссий — '+worldDone(S0)+'.';renderMenu();};
$('#bSaveBack').onclick=()=>toMenu();
