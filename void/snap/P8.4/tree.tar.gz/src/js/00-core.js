
"use strict";
/* ▼▼▼ ARCH·69 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.9 α «Опора»)
   Надёжность без изменения игры. Каждая правка выключается флагом: ARCH.off['A-n']=1 в консоли
   или window.__archOff=['A-n'] до загрузки — тогда идёт старый путь. Точечные места помечены «ARCH·69 A-n».
   A-1 · один цикл отрисовки карты · A-2 · резерв нечитаемого сохранения · A-3 · сохранение на загрузке проходит всю цепочку миграций
   A-4 · предохранитель симуляции: N кадров подряд с ошибкой → пауза, сообщение, запись в void_diag */
var ARCH={off:{},mapGen:0,err:0,errN:30,first:null,trips:0};try{if(window.__archOff)for(const k of window.__archOff)ARCH.off[k]=1;}catch(e){}
/* A-1 — продолжение цикла карты только у последнего запущенного цикла; старые гаснут на своём следующем кадре */
function arch69MapNext(){if(ARCH.off['A-1']){requestAnimationFrame(mapLoop);return;}const g=ARCH.mapGen;requestAnimationFrame(()=>{if(g===ARCH.mapGen)mapLoop();});}
/* A-4 — счётчик подряд идущих кадров с ошибкой в стадии симуляции/мира */
function arch69Ok(){if(ARCH.err&&!ARCH.off['A-13']){ARCH.first=null;ARCH.last=null;}ARCH.err=0;ARCH.hudErr=null;}/* ARCH·70 A-13 */
function arch69Fault(err){if(!(ARCH.off['A-10']&&ARCH.off['A-12']&&ARCH.off['A-13']))return arch70Fault(err);/* ARCH·70 A-10 A-12 A-13 */if(ARCH.off['A-4'])return;if(G.state!=='play'&&G.state!=='world'){ARCH.err=0;return;}
  if(!ARCH.err)ARCH.first={msg:String(err&&err.message||err).slice(0,200),stack:String(err&&err.stack||'').split('\n').slice(0,6).join(' | ').slice(0,600)};
  if(++ARCH.err<ARCH.errN)return;ARCH.err=0;ARCH.trips++;
  try{LS.setItem('void_diag',JSON.stringify({ver:typeof VER_TAG!=='undefined'?VER_TAG:'',at:Date.now(),stage:'sim',state:G.state,m:G.m&&G.m.id!=null?G.m.id:null,frames:ARCH.errN,trips:ARCH.trips,msg:ARCH.first&&ARCH.first.msg,stack:ARCH.first&&ARCH.first.stack}),true);}catch(e){}
  try{pause();}catch(e){}
  try{toast('СБОЙ В ИГРЕ','Часть систем перестала отвечать, поэтому игра встала на паузу, чтобы бой не завис незаметно. Можно продолжить или выйти в меню — подробности записаны для разработчика.');}catch(e){}}
/* A-2 — нечитаемое сохранение откладывается до того, как новая игра его перезапишет */
function arch69Backup(){if(ARCH.off['A-2'])return;if(!ARCH.off['A-11'])return arch70Backup();/* ARCH·70 A-11 */try{if(G.save)return;const raw=LS.getItem('void_world');if(!raw)return;
  const prev=LS.getItem('void_world_bad');if(prev===raw)return;const key=prev?'void_world_bad_'+(Date.now()%1e9):'void_world_bad';LS.setItem(key,raw,true);
  try{toast('СОХРАНЕНИЕ НЕ ПРОЧИТАНО','Старая запись не открылась и отложена отдельно — новая игра её не сотрёт.');}catch(e){}}catch(e){}}
/* выполняется последней строкой главного скрипта, когда все обёртки уже установлены */
function arch69Boot(){if(!ARCH.off['A-3']){try{saveSet6(migrateSave(store('void_world')),'load');}catch(e){console.error(e);}}arch69Backup();}
/* ▲▲▲ ARCH·69 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·70 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.10 α «Ровно» · этап 2: изоляция случайности и времени)
   Каждая правка выключается флагом: window.__archOff=['A-n'] до загрузки (A-5, A-6, A-8, A-12 ставятся при загрузке и
   из консоли по ходу игры не снимаются; A-7, A-9, A-10, A-11, A-13 проверяют флаг на каждом вызове). Места в коде помечены «ARCH·70 A-n».
   A-5 музыкальный таймер и перенастройка подложки V12 (асинхронно, после декодирования) берут числа из SFXR63 · A-6 эхо реверберации строится на SFXR63 · A-7 отложенное эхо рывка идёт через iso63
   A-8 шум миникарты VØID-000 — на VFXR65 · A-9 ржавый контейнер считает игровое время, а не кадры
   A-10 номер миссии и режим в void_diag · A-11 нечитаемое сохранение нельзя молча перезаписать · A-12 сбой HUD не ставит игру на паузу
   A-13 ARCH.first не переживает восстановление. Новых генераторов случайности нет — только существующие iso63/iso65. */
ARCH.poiDt=null;ARCH.hudErr=null;ARCH.hudN=0;ARCH.toastN=0;ARCH.last=null;ARCH.lock=null;
/* A-9 — шаг времени для w58POI: живёт ровно один вызов, восстанавливается в finally, проверяется на корректность */
function arch70Dt(){const d=ARCH.poiDt;return (!ARCH.off['A-9']&&typeof d==='number'&&d>=0&&d<1000)?d:1/60;}
function arch70POI(card,dt){if(ARCH.off['A-9'])return w58POI(card);const pd=ARCH.poiDt;ARCH.poiDt=dt;try{return w58POI(card);}finally{ARCH.poiDt=pd;}}
/* A-12 — внешняя обёртка функций HUD: помечает исключение, которое из неё вышло. Классификация по самому объекту ошибки,
   поэтому вложенные вызовы HUD и вызовы вне кадра не могут выдать сбой симуляции за сбой интерфейса. */
function arch70Hud(f){const w=function(){try{return f.apply(this,arguments);}catch(e){if(e&&typeof e==='object')ARCH.hudErr=e;throw e;}};w.toString=()=>f.toString();return w;}
function arch70Info(err){return {msg:String(err&&err.message||err).slice(0,200),stack:String(err&&err.stack||'').split('\n').slice(0,6).join(' | ').slice(0,600)};}
/* A-10 · A-13 — запись void_diag */
function arch70Diag(stage,first,last,frames){try{const o={ver:typeof VER_TAG!=='undefined'?VER_TAG:'',at:Date.now(),stage,state:G.state,m:G.m&&G.m.id!=null?G.m.id:null,frames,trips:ARCH.trips,msg:first&&first.msg,stack:first&&first.stack};
  if(!ARCH.off['A-10']){o.m=(G.state==='play'&&typeof G.m==='number')?G.m:null;o.mode=G.mode||null;o.world=G.state==='world';o.zb=G.zb&&G.zb.k||null;o.v=2;}
  if(!ARCH.off['A-13']&&last&&last!==first)o.last=last.msg;
  LS.setItem('void_diag',JSON.stringify(o),true);}catch(e){}}
function arch70Fault(err){if(ARCH.off['A-4'])return;
  if(G.state!=='play'&&G.state!=='world'){ARCH.err=0;ARCH.hudErr=null;if(!ARCH.off['A-13']){ARCH.first=null;ARCH.last=null;}return;}
  const hud=!ARCH.off['A-12']&&err!==null&&typeof err==='object'&&err===ARCH.hudErr;ARCH.hudErr=null;
  if(hud){/* шаг симуляции этого кадра завершился — серия сбоев симуляции прервана */ARCH.err=0;if(!ARCH.off['A-13']){ARCH.first=null;ARCH.last=null;}
    if(!ARCH.hudN++){const i=arch70Info(err);arch70Diag('hud',i,i,1);}return;}
  const info=arch70Info(err);if(!ARCH.err)ARCH.first=info;ARCH.last=info;
  if(++ARCH.err<ARCH.errN)return;ARCH.err=0;ARCH.trips++;
  arch70Diag('sim',ARCH.first,ARCH.last,ARCH.errN);if(!ARCH.off['A-13']){ARCH.first=null;ARCH.last=null;}
  try{pause();}catch(e){}
  if(ARCH.off['A-12']||!ARCH.toastN++){try{toast('СБОЙ В ИГРЕ','Часть систем перестала отвечать, поэтому игра встала на паузу, чтобы бой не завис незаметно. Можно продолжить или выйти в меню — подробности записаны для разработчика.');}catch(e){}}}
/* A-11 — резерв нечитаемого сохранения. Если отложить копию не удалось, запись void_world блокируется: новый прогресс живёт
   только в памяти вкладки, а старая запись остаётся на месте, пока игрок не скачает её или явно не откажется от неё. */
function arch70BadKeys(){const out=[];try{const ls=window.localStorage;for(let i=0;i<ls.length;i++){const k=ls.key(i);if(k&&k.indexOf('void_world_bad')===0)out.push(k);}}catch(e){}return out;}
function arch70Backup(){try{if(G.save)return;const raw=LS.getItem('void_world');if(!raw)return;
  const keys=arch70BadKeys();for(const k of keys){if(LS.getItem(k)===raw)return;}
  let ok=false;if(keys.length<3){const key=keys.indexOf('void_world_bad')<0?'void_world_bad':'void_world_bad_'+(Date.now()%1e9);
    try{LS.setItem(key,raw,true);ok=LS.persisted(key)&&LS.getItem(key)===raw;}catch(e){ok=false;}}
  if(ok){try{toast('СОХРАНЕНИЕ НЕ ПРОЧИТАНО','Старая запись не открылась и отложена отдельно — новая игра её не сотрёт.');}catch(e){}return;}
  arch70Lock(raw);}catch(e){console.error(e);}}
function arch70Lock(raw){if(ARCH.lock)return;const L=ARCH.lock={raw,has:false,mem:null};
  const g=LS.getItem,s=LS.setItem,r=LS.removeItem,p=LS.persisted;L.orig={g,s,r,p};
  LS.getItem=function(k){if(k==='void_world'&&ARCH.lock)return ARCH.lock.has?ARCH.lock.mem:ARCH.lock.raw;return g.apply(this,arguments);};
  LS.setItem=function(k,v){if(k==='void_world'&&ARCH.lock){ARCH.lock.has=true;ARCH.lock.mem=String(v);return;}return s.apply(this,arguments);};
  LS.removeItem=function(k){if(k==='void_world'&&ARCH.lock){ARCH.lock.has=true;ARCH.lock.mem=null;return;}return r.apply(this,arguments);};
  LS.persisted=function(k){if(k==='void_world'&&ARCH.lock)return false;return p.apply(this,arguments);};
  arch70Panel();}
/* экспорт: в просмотрщике claude.ai — через разрешённый механизм downloads (зритель подтверждает сохранение);
   в обычном браузере и из file:// — обычной ссылкой на файл. Результат сообщается честно: ok / declined / sent / fail */
function arch70ExportName(){const d=new Date(),pad=n=>String(n).padStart(2,'0');return 'void_world_'+d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate())+'_'+pad(d.getHours())+pad(d.getMinutes())+'.txt';}
async function arch70Export(){const L=ARCH.lock;if(!L)return 'fail';const name=arch70ExportName();
  try{const C=window.claude;if(C&&typeof C.use==='function'){const dl=await C.use('downloads');
      if(dl){try{const r=await dl.save({filename:name,data:L.raw});L.exported=1;return r&&r.status==='saved'?'ok':'sent';}catch(e){return e&&e.code==='declined'?'declined':'fail';}}}}catch(e){}
  try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([L.raw],{type:'text/plain'}));a.download=name;
    document.body.appendChild(a);a.click();setTimeout(()=>{try{URL.revokeObjectURL(a.href);a.remove();}catch(e){}},1500);L.exported=1;return 'sent';}catch(e){console.error(e);return 'fail';}}
function arch70Release(){const L=ARCH.lock;if(!L)return;ARCH.lock=null;const o=L.orig;LS.getItem=o.g;LS.setItem=o.s;LS.removeItem=o.r;LS.persisted=o.p;
  try{if(L.has){if(L.mem===null)LS.removeItem('void_world');else LS.setItem('void_world',L.mem);}}catch(e){try{toast('СОХРАНЕНИЕ НЕ ЗАПИСАНО','Браузер не даёт записать прогресс: хранилище переполнено или запрещено. Скопируйте код сохранения в меню, иначе прогресс пропадёт.');}catch(_){}}
  const el=document.getElementById('bak70');if(el)el.remove();clearInterval(L.tick);}
function arch70Panel(){try{const L=ARCH.lock;if(!L||document.getElementById('bak70'))return;
  if(!document.getElementById('bak70css')){const st=document.createElement('style');st.id='bak70css';
    st.textContent='#bak70{position:fixed;left:50%;bottom:max(16px,env(safe-area-inset-bottom,0px));transform:translateX(-50%);width:min(440px,calc(100% - 32px));z-index:60;border-left:2px solid var(--amber);background:var(--panel);padding:14px 16px;display:grid;gap:10px;font-family:var(--f-body);color:var(--text)}'+
      '#bak70 .t{font-family:var(--f-display);font-size:12px;font-weight:600;letter-spacing:.14em;color:var(--amber)}#bak70 p{margin:0;font-size:13px;line-height:1.45;color:var(--text)}'+
      '#bak70 .r{display:grid;grid-template-columns:1fr 1fr;gap:8px}#bak70 .btn{min-height:44px;font-size:11px;padding:10px 12px;justify-content:center;text-align:center}';
    document.head.appendChild(st);}
  const el=document.createElement('div');el.id='bak70';el.setAttribute('role','alertdialog');el.setAttribute('aria-labelledby','bak70t');
  el.innerHTML='<div class="t" id="bak70t">СОХРАНЕНИЕ НЕ ПРОЧИТАНО</div><p>Старую запись не удалось отложить: хранилище браузера переполнено. Чтобы она не пропала, игра пока не записывает новый прогресс поверх неё — он живёт только до закрытия вкладки.</p>'+
    '<div class="r"><button class="btn" data-b70="exp">СКАЧАТЬ ЗАПИСЬ</button><button class="btn act2" data-b70="drop">ОТКАЗАТЬСЯ ОТ НЕЁ</button></div>';
  document.body.appendChild(el);let arm=0;
  el.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-b70]');if(!b)return;
    if(b.dataset.b70==='exp'){arch70Export().then(r=>{const T={ok:['ЗАПИСЬ СКАЧАНА','Файл со старой записью сохранён. Когда убедитесь, что он на месте, можно отказаться от записи в игре.'],
        sent:['ФАЙЛ ОТПРАВЛЕН В ЗАГРУЗКИ','Проверьте папку загрузок. Если файла там нет, браузер его не пропустил — старая запись по-прежнему защищена.'],
        declined:['СКАЧИВАНИЕ ОТМЕНЕНО','Старая запись по-прежнему защищена. Скачать её можно в любой момент.'],
        fail:['НЕ УДАЛОСЬ СКАЧАТЬ','Здесь браузер не даёт сохранить файл. Старая запись по-прежнему защищена.']}[r]||['НЕ УДАЛОСЬ СКАЧАТЬ',''];try{toast(T[0],T[1]);}catch(_){}});return;}
    if(!arm){arm=1;b.textContent='ТОЧНО? ЗАПИСЬ ПРОПАДЁТ';return;}arch70Release();try{toast('ЗАЩИТА СНЯТА','Новый прогресс снова сохраняется. Старая запись будет заменена.');}catch(_){}});
  const sync=()=>{try{el.hidden=!(G.state==='menu'||G.state==='save');}catch(_){}};sync();L.tick=setInterval(sync,400);}catch(e){console.error(e);}}
/* выполняется после arch69Boot(): все обёртки уже установлены */
function arch70Boot(){try{
  if(typeof iso63==='function'){if(!ARCH.off['A-5']){if(typeof musSched==='function')musSched=iso63(musSched);if(typeof v12Retune==='function')v12Retune=iso63(v12Retune);}if(!ARCH.off['A-6']&&typeof makeImpulse==='function')makeImpulse=iso63(makeImpulse);}
  else if(!ARCH.off['A-5']||!ARCH.off['A-6'])console.warn('ARCH·70: iso63 не найден — A-5/A-6 не применены');
  if(typeof iso65==='function'){if(!ARCH.off['A-8']&&typeof zbMapStatic==='function')zbMapStatic=iso65(zbMapStatic);}
  else if(!ARCH.off['A-8'])console.warn('ARCH·70: iso65 не найден — A-8 не применён');
  if(!ARCH.off['A-12']){if(typeof updateHUD==='function')updateHUD=arch70Hud(updateHUD);if(typeof updateEndlessHUD==='function')updateEndlessHUD=arch70Hud(updateEndlessHUD);if(typeof updateWorldHUD==='function')updateWorldHUD=arch70Hud(updateWorldHUD);}
}catch(e){console.error(e);}}
/* ▲▲▲ ARCH·70 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·71 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.11 α · этап 3: визуальная случайность в симуляции — на VFXR65)
   В отмеченных местах симуляции и HUD визуальные числа (частицы, искры, дрожание) берутся не из игрового Math.random,
   а из уже существующего VFXR65 — так эффекты, «Меньше», lowFx, качество и частота кадров больше не сдвигают ход боя.
   Группы и флаги отката (window.__archOff=['A-n'] до загрузки; читаются один раз при загрузке):
   A-14 ядро боя · A-15 мир и сюжет · A-16 боссы и сектора · A-17 «Ноль» · A-18 HUD и мини-карта (частота кадров).
   С выключенным флагом группа берёт числа из текущего Math.random — ровно как в 1.5.10. Новых генераторов и обёрток нет.
   Места в коде: vR<n>() / vrnd<n>(a,b). */
var VR71_1=()=>Math.random(),VR71_2=()=>Math.random(),VR71_3=()=>Math.random(),VR71_4=()=>Math.random(),VR71_5=()=>Math.random();
function vR1(){return VR71_1();}function vrnd1(a,b){return a+VR71_1()*(b-a);}
function vR2(){return VR71_2();}function vrnd2(a,b){return a+VR71_2()*(b-a);}
function vR3(){return VR71_3();}function vrnd3(a,b){return a+VR71_3()*(b-a);}
function vR4(){return VR71_4();}function vrnd4(a,b){return a+VR71_4()*(b-a);}
function vR5(){return VR71_5();}function vrnd5(a,b){return a+VR71_5()*(b-a);}
function arch71Boot(){if(typeof VFXR65!=='function'){console.warn('ARCH·71: VFXR65 не найден — A-14…A-18 не применены');return;}
  if(!ARCH.off['A-14'])VR71_1=VFXR65;if(!ARCH.off['A-15'])VR71_2=VFXR65;if(!ARCH.off['A-16'])VR71_3=VFXR65;if(!ARCH.off['A-17'])VR71_4=VFXR65;if(!ARCH.off['A-18'])VR71_5=VFXR65;}
/* ▲▲▲ ARCH·71 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·72 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.12 α · этап 4.1: часы ударной паузы)
   A-19 · hs90 отсчитывает паузу 500 мс между слабыми ударными паузами по часам игры ARCH.clk, а не по performance.now().
   ARCH.clk — секунды: в старом цикле растёт на dt0 кадра (те же часы, что у rAF), в цикле A-20 — на шаг 1/60.
   Выключение: window.__archOff=['A-19'] до загрузки. */
ARCH.clk=0;
/* ▲▲▲ ARCH·72 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·73 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.13 α · этап 4.2: игровой шаг 1/60)
   A-20 · главный цикл frame74: накопитель реального времени кадра, шаги ровно по 1/60 с, не больше 3 за кадр
   (тот же предел 0,05 с, что у старого цикла). Замедление slow95, ударная пауза hs90 и resumeK масштабируют dt шага (C1),
   а их таймеры, часы ARCH.clk и зум камеры camZ (видимая область VW/VH) отсчитываются по шагам. HUD, звук и отрисовка — раз в кадр,
   ветка HUD выбирается по состоянию на начало кадра, как прежде; мир не удваивается режимом speed, как прежде.
   Старый frame() остаётся целиком: window.__archOff=['A-20'] (или выключенный A-19) до загрузки — и игра идёт по нему. */
const STEP74=1/60,MAXN74=3;let ACC74=0;ARCH.sc74=1;ARCH.n74=0;ARCH.steps74=0;
function live74(){return G.state==='play'||G.state==='world';}
function camZ74(dt){const zt=camZTarget(),z=G.camZ||1;if(Math.abs(zt-z)>.001){G.camZ=z+clamp(zt-z,-.15*dt,.15*dt);setScale();}}
function mobTick74(dt,now){
  touchTick(dt);qTick(dt,now);wakeSync(now);padTick(now);tutTick();
  cv.classList.toggle('fs-cursor',!isMob()&&FS.state==='native'&&(G.state==='play'||G.state==='world')&&now-(MOUSE.mvAt||0)>2500);}
function step74(){
  ARCH.clk+=STEP74;camZ74(STEP74);let k=1;const L=live74();
  if(G.resumeK>0&&L){G.resumeK=Math.max(0,G.resumeK-STEP74);if(G.resumeK>0)k*=.3;}
  const S_=G.slow95;if(S_&&S_.t>0&&L){S_.t-=STEP74;k*=S_.k;if(S_.t<=0)G.slow95=null;}
  G.rdt90=STEP74*k;let kh=1;const H_=G.hs90;
  if(H_&&G.state==='play'){if(H_.t>0){H_.t-=STEP74;kh=.04;}else if(H_.ramp>0){const r0=H_.ramp;H_.ramp-=STEP74;kh=.3+.7*(1-r0/.4);}else G.hs90=null;}
  const dt=STEP74*k*kh,reps=devOn('speed')?2:1;G.rdtU96=reps;ARCH.sc74=k*kh;ARCH.steps74++;
  if(G.state==='play'){for(let r=0;r<reps&&G.state==='play';r++)update(dt);}
  else if(G.state==='world'){if(G.prologue)prologueTick(dt);else worldUpdate(dt);}
  if(ARCH.c66s){try{c66Tick(STEP74);}catch(e){c66Fail(e);}}/* ARCH·74 A-21 */}
function frame74(now){
  if(ARCH.fc27){if(!gate27(now)){requestAnimationFrame(frame);return;}}else if(isMob()&&SET.fps===30&&now-last<29&&now>=last){requestAnimationFrame(frame);return;}/* ARCH·90a A-27 */
  const dt0=Math.min(.05,Math.max(0,(now-last)/1000));last=now;if(ARCH.vdt)VDT74=dt0;/* ARCH·75 A-22 */
  try{mobTick74(dt0,now);}catch(err){console.error(err);}
  let n=0;const st0=G.state,pro0=G.prologue;
  try{if(!live74()){ACC74=ARCH.a25?STEP74/2:0;/* ARCH·79 A-25 */ARCH.sc74=1;camZ74(dt0);if(G.state!=='pause')G.resumeK=0;}
    else{ACC74=Math.min(ACC74+dt0,STEP74*MAXN74+1e-9);while(ACC74>=STEP74-1e-9&&n<MAXN74&&live74()){ACC74-=STEP74;n++;step74();if(ARCH.vi&&IP76.act)ip78Post();/* ARCH·76 A-23: перепись только при активной интерполяции */}}
    if(st0==='play'){if(G.mode==='endless')updateEndlessHUD();else updateHUD();}
    else if(st0==='world'){if(!pro0)updateWorldHUD();}
    else if(st0==='hangar')drawHangarPreviews(now);else if(st0==='arsenal')arsDemoTick(now);arch69Ok();}catch(err){console.error(err);arch69Fault(err);/* ARCH·69 A-4 */}
  ARCH.n74=n;const dt=live74()?dt0*ARCH.sc74:dt0;
  if(dt>0)fpsAvg+=(1/dt-fpsAvg)*.05;
  if(G.mode==='endless'&&G.state==='play'&&!G.lowFx){G.fpsLow=dt>fpsLowT27()?(G.fpsLow||0)+dt:Math.max(0,(G.fpsLow||0)-dt*.5);if(G.fpsLow>3)G.lowFx=true;}
  try{if(G.prologue&&G.state!=='world')prologueEnd();if(G.state!=='world'&&G.state!=='play'&&G.radio&&G.radio.cur)radioClear();if(G.state==='menu')menuGlitch(dt);else menuGlitchOff();}catch(err){console.error(err);}
  try{musicTick(dt);if(G.state!=='play'&&G.x90&&(G.x90.hudAll||G.x90.hud&&G.x90.hud.cur))clearHud100();}catch(err){console.error(err);}
  const ip76=ARCH.vi&&ip78Apply(dt0);/* ARCH·76 A-23 · ARCH·78 защита */
  try{if(G.world&&G.player)renderWorld(now);else{render(now);secVignette();}mobOverlay(now);drawDevOverlay();if(G.dev.diag77||D77.on)diag77(now,dt0,n);/* ARCH·77 */}catch(err){console.error(err);}
  if(ip76)ip78Restore();/* ARCH·76 A-23 · ARCH·78 защита */
  requestAnimationFrame(frame);}
/* ▲▲▲ ARCH·73 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·74 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.14 α · этап 4.3: часы режиссёра C66)
   A-21 · такт режиссёра C66 (миссии 1–5) в бою и в мире идёт из шага step74 по 1/60, а не из отрисовки по часам стены.
   Отложенное замедление после оглушения тарана (было setTimeout 140 мс) и метки «последнее убийство / взрыв мины / зона чиста»
   считаются по ARCH.clk. Звуковые setTimeout, заставка брифинга и карточка итога остаются на настоящем времени: игру они не меняют.
   Работает только вместе с циклом A-20 (и A-19). Выключение: window.__archOff=['A-21'] до загрузки. */
ARCH.c66s=!ARCH.off['A-21']&&!ARCH.off['A-20']&&!ARCH.off['A-19'];
function c66Clk(){return ARCH.c66s?ARCH.clk*1000:performance.now();}
/* ▲▲▲ ARCH·74 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·75 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.15 α · этап 4.4: визуальные таймеры)
   A-22 · 13 мест в рисовании, где вспышка, снег, дождь, подсветка удара или глитч убывали на 1/60 за каждую отрисовку
   (w58DrawTop, w58Screen ×4, sb74Draw, drawE90, lvTop95, heartUnder, zbDraw ×2, postDrawCrates, bg67Events), теперь убывают на
   настоящее время кадра VDT74. Симуляция эти поля не читает (перепись чтений в отчёте 4.4). Без A-22 VDT74 всегда ровно 1/60 —
   прежнее поведение побайтно. Работает только вместе с циклом A-20 (и A-19). Выключение: window.__archOff=['A-22'] до загрузки. */
ARCH.vdt=!ARCH.off['A-22']&&!ARCH.off['A-20']&&!ARCH.off['A-19'];let VDT74=1/60;
/* ▲▲▲ ARCH·75 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·76 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.16 α · этап 4.5: плавность 90/120/144 Гц)
   A-23 · после каждого шага step74 запоминаются x, y и ang всех объектов, достижимых из G (корабль, враги и их части, боссы,
   снаряды, подборы, частицы, «Ноль», сектора), и камера CX/CY. Перед отрисовкой кадра им на время рисования ставится положение
   между предыдущим и текущим шагом (доля = остаток накопителя / шаг), после рисования точные значения возвращаются на место.
   Игра, столкновения, ИИ, RNG и сохранения видят только настоящие значения. Скачок больше IP76CUT пикселей за шаг (телепорт,
   смена сцены, переиспользованный объект) не сглаживается. Новые объекты с vx/vy отодвигаются назад по своей скорости, чтобы
   снаряд не «опережал» корабль. Включается сама, только если экран заметно чаще 60 Гц (средний кадр < 0,8 шага): на 60 Гц и
   ниже картинка, задержка и нагрузка те же, что без патча (перепись объектов тоже не идёт). В плоских списках
   G.parts, G.pb, G.eb, G.pick, G.float, G.rocks берутся только x/y самих элементов, без захода в их поля. Работает только вместе с циклом A-20 (и A-19).
   Выключение: window.__archOff=['A-23'] до загрузки. Сравнение для владельца: window.__ip76mode='x' — экстраполяция вперёд. */
ARCH.vi=!ARCH.off['A-23']&&!ARCH.off['A-20']&&!ARCH.off['A-19'];
const IP76LEAF=new Set(['parts','pb','eb','pick','float','rocks','wrocks']),IP76CUT=80,IP76SKIP=new Set(['save','fog','fogT','wrocks','decor','zones','posLog','dashLog','trail','world','nodes','dev','mc','stat','ach','runStart','radio','x90','relays','hit']);
const IP76={A:{o:[],x:new Float64Array(4096),y:new Float64Array(4096),a:new Float64Array(4096),m:new Map(),n:0,cx:0,cy:0},
  B:{o:[],x:new Float64Array(4096),y:new Float64Array(4096),a:new Float64Array(4096),m:new Map(),n:0,cx:0,cy:0},
  ok:0,ema:STEP74,act:false,mode:(window.__ip76mode==='x'?'x':'i'),al:0,rx:new Float64Array(4096),ry:new Float64Array(4096),ra:new Float64Array(4096),rn:0,rcx:0,rcy:0,
  st:{fr:0,ip:0,obj:0,cut:0,born:0,postMs:0,applyMs:0},seen:new Set()};
function ip76Grow(L,n){if(n<L.x.length)return;const k=L.x.length*2,f=a=>{const b=new Float64Array(k);b.set(a);return b;};L.x=f(L.x);L.y=f(L.y);L.a=f(L.a);
  if(IP76.rx.length<k){IP76.rx=f(IP76.rx);IP76.ry=f(IP76.ry);IP76.ra=f(IP76.ra);}}
function ip76Walk(o,d,L,leaf){if(!o||typeof o!=='object'||IP76.seen.has(o))return;IP76.seen.add(o);
  if(Array.isArray(o)){if(!o.length||typeof o[0]!=='object')return;for(let i=0;i<o.length;i++)ip76Walk(o[i],d,L,leaf);return;}
  if(ArrayBuffer.isView(o)||o instanceof Node||o instanceof Map||o instanceof Set)return;
  if(typeof o.x==='number'&&typeof o.y==='number'){const n=L.n;ip76Grow(L,n);L.o[n]=o;L.x[n]=o.x;L.y[n]=o.y;L.a[n]=typeof o.ang==='number'?o.ang:NaN;L.m.set(o,n);L.n=n+1;}
  if(d>=2||leaf)return;for(const k in o){if(IP76SKIP.has(k))continue;const v=o[k];if(v&&typeof v==='object')ip76Walk(v,d+1,L);}}
function ip76Post(){const t0=performance.now();const P=IP76.A;IP76.A=IP76.B;IP76.B=P;const L=IP76.B;L.n=0;L.m.clear();IP76.seen.clear();
  for(const k in G){if(IP76SKIP.has(k))continue;const v=G[k];if(v&&typeof v==='object')ip76Walk(v,0,L,IP76LEAF.has(k));}
  for(let i=L.n;i<L.o.length;i++)L.o[i]=null;L.cx=CX;L.cy=CY;IP76.ok++;IP76.st.postMs+=performance.now()-t0;}
function ip76Apply(dt0){if(dt0>0&&dt0<.05)IP76.ema+=(dt0-IP76.ema)*.1;
  const was=IP76.act;IP76.act=IP76.act?IP76.ema<STEP74*.9||ip27fast():IP76.ema<STEP74*.8||ip27fast();/* ARCH·92 */if(IP76.act&&!was)IP76.ok=0;IP76.st.fr++;
  if(!IP76.act||IP76.ok<2||!live74())return false;
  const t0=performance.now(),al=Math.max(0,Math.min(1,ACC74/STEP74)),C=IP76.B,P=IP76.A,x=IP76.mode==='x',dts=STEP74*ARCH.sc74;IP76.al=al;
  let cut=0,born=0;for(let i=0;i<C.n;i++){const o=C.o[i];const ox=o.x,oy=o.y,oa=o.ang;IP76.rx[i]=ox;IP76.ry[i]=oy;IP76.ra[i]=typeof oa==='number'?oa:NaN;IP76.rp=i+1;/* ARCH·78 */
    if(ox!==C.x[i]||oy!==C.y[i])continue;/* сдвинут вне шага (событие ввода) — рисуем как есть */
    const j=P.m.get(o);
    if(j===undefined){if(!x&&typeof o.vx==='number'&&typeof o.vy==='number'){const k=(1-al)*dts;o.x=ox-o.vx*k;o.y=oy-o.vy*k;born++;}continue;}
    const dx=ox-P.x[j],dy=oy-P.y[j];if(dx*dx+dy*dy>IP76CUT*IP76CUT){cut++;continue;}
    if(x){o.x=ox+dx*al;o.y=oy+dy*al;}else{o.x=P.x[j]+dx*al;o.y=P.y[j]+dy*al;}
    const pa=P.a[j];if(typeof oa==='number'&&pa===pa&&oa===C.a[i]){let da=oa-pa;da-=Math.round(da/(2*Math.PI))*2*Math.PI;o.ang=x?oa+da*al:pa+da*al;}}
  IP76.rn=C.n;IP76.rcx=CX;IP76.rcy=CY;
  if(CX===C.cx&&CY===C.cy){const dx=CX-P.cx,dy=CY-P.cy;if(dx*dx+dy*dy<=IP76CUT*IP76CUT){if(x){CX=CX+dx*al;CY=CY+dy*al;}else{CX=P.cx+dx*al;CY=P.cy+dy*al;}}}
  IP76.st.ip++;IP76.st.obj=C.n;IP76.st.cut+=cut;IP76.st.born+=born;IP76.st.applyMs+=performance.now()-t0;return true;}
function ip76Restore(){const C=IP76.B;for(let i=IP76.rn-1;i>=0;i--){const o=C.o[i];o.x=IP76.rx[i];o.y=IP76.ry[i];const a=IP76.ra[i];if(a===a)o.ang=a;}CX=IP76.rcx;CY=IP76.rcy;}
/* ▲▲▲ ARCH·76 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·77 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.17 α · диагностика кадров, только режим разработчика)
   Включается переключателем «Диагностика кадров» в меню разработчика (меню открывается через ?dev или 5 нажатий на логотип).
   Без переключателя diag77 не вызывается и ничего не меняет. Только читает состояние и рисует поверх кадра: частоту rAF и разброс
   интервалов, шаги за кадр (0/1/2/3), 0- и 2-шаговые кадры и пропуски vsync за минуту, состояние A-23 и её переключения,
   источник текущей цели и расстояние, неровность видимой скорости корабля и камеры. Кольцевой буфер последних 60 с живых кадров
   (метка rAF, dt, шаги, накопитель, A-23, видимые x/y корабля, камера). Экспорт последних 30 с в JSON: F8 на компьютере
   или выключение переключателя (скачивание файла и window.__diag77last). */
const D77C=['now','dt0','n','acc','ip','px','py','cx','cy'];
const D77={on:false,buf:null,cap:14400,i:0,n:0,tog:0,act:null,chk:0,okDev:false,last:0,t0:0,px:NaN,py:NaN,cx:0,cy:0,
  sec:[],cur:null,dts:new Float64Array(240),di:0,dn:0,med:0,vs:new Float64Array(240),vc:new Float64Array(240),vi:0,vn:0,txt:[],txtAt:0,lines:null,wrapAt:-1,wrapW:0};
function diag77Dev(now){if(now-D77.chk>1000||now<D77.chk){D77.chk=now;try{D77.okDev=devUnlocked();}catch(e){D77.okDev=false;}}return D77.okDev;}
function diag77(now,dt0,n){
  const want=!!(G.dev&&G.dev.diag77)&&diag77Dev(now);
  if(!want){if(D77.on){D77.on=false;diag77Export('выкл');}return;}
  if(!D77.on){D77.on=true;D77.buf=new Float64Array(D77.cap*D77C.length);D77.i=0;D77.n=0;D77.tog=0;D77.act=null;D77.sec=[];D77.cur=null;D77.dn=0;D77.vn=0;D77.px=NaN;D77.t0=now;D77.last=now;D77.txtAt=0;}
  const L=live74(),p=G.player,I=typeof IP76!=='undefined'?IP76:null,old=!!(ARCH.off['A-20']||ARCH.off['A-19']);
  if(I){if(D77.act!==null&&D77.act!==I.act)D77.tog++;D77.act=I.act;}
  const fd=now-D77.last;D77.last=now;
  if(L){const C=D77C.length,k=D77.i*C,B=D77.buf;B[k]=now;B[k+1]=dt0;B[k+2]=n;B[k+3]=old?NaN:ACC74;B[k+4]=(ARCH.vi?1:0)+(I&&I.act?2:0)+(old?4:0);
    B[k+5]=p?p.x:NaN;B[k+6]=p?p.y:NaN;B[k+7]=CX;B[k+8]=CY;D77.i=(D77.i+1)%D77.cap;D77.n=Math.min(D77.n+1,D77.cap);
    if(fd>0&&fd<100){D77.dts[D77.di]=fd;D77.di=(D77.di+1)%240;D77.dn=Math.min(D77.dn+1,240);}
    let S=D77.cur;if(!S||now-S.t>=1000){S=D77.cur={t:now,f:0,z:0,a:0,b:0,c:0,m:0};D77.sec.push(S);while(D77.sec.length&&now-D77.sec[0].t>60000)D77.sec.shift();}
    S.f++;if(n===0)S.z++;else if(n===1)S.a++;else if(n===2)S.b++;else if(n===3)S.c++;if(D77.med>0&&fd>D77.med*1.5&&fd<100)S.m++;
    if(p&&fd>0&&fd<100&&D77.px===D77.px){D77.vs[D77.vi]=Math.hypot(p.x-D77.px,p.y-D77.py)*1000/fd;D77.vc[D77.vi]=Math.hypot(CX-D77.cx,CY-D77.cy)*1000/fd;D77.vi=(D77.vi+1)%240;D77.vn=Math.min(D77.vn+1,240);}
    else D77.vn=0;
    D77.px=p?p.x:NaN;D77.py=p?p.y:NaN;D77.cx=CX;D77.cy=CY;}
  else{D77.px=NaN;D77.vn=0;}
  if(now-D77.txtAt>250||now<D77.txtAt){D77.txtAt=now;diag77Text(now,old,I);}
  diag77Draw();}
function diag77Cv(a,N,i0){/* неровность: среднее |v(i)−v(i−1)| / средняя v по последним кадрам при движении быстрее 60 px/с; плавный разгон её почти не меняет */
  let s=0,d=0,k=0;for(let j=1;j<N;j++){const v=a[(i0-N+j+480)%240],u=a[(i0-N+j-1+480)%240];if(v>60||u>60){s+=v;d+=Math.abs(v-u);k++;}}return k<20?null:d/Math.max(1e-9,s);}
function diag77Text(now,old,I){
  const d=Array.from(D77.dts.subarray(0,D77.dn)).sort((a,b)=>a-b),med=d.length?d[d.length>>1]:0;D77.med=med;
  let f=0,z=0,a=0,b=0,c=0,m=0;for(const S of D77.sec){f+=S.f;z+=S.z;a+=S.a;b+=S.b;c+=S.c;m+=S.m;}
  const span=D77.sec.length?Math.max(1,(now-D77.sec[0].t)/60000):0,pm=v=>span?(v/span).toFixed(0):'—',pc=v=>f?Math.round(100*v/f)+'%':'—';
  const p=G.player,tg=G.tg90,man=typeof aimManual==='function'&&aimManual();
  let src='нет цели',dist='';if(man)src='ручной прицел';else if(tg){src=tg===G.prio?'отмеченная (касание/клик)':(G.sb&&G.sb.alive&&G.sb.st==='fight'?'авто · босс':'авто · ближайшая');if(p)dist=' · '+Math.round(Math.hypot(tg.x-p.x,tg.y-p.y))+' px';}
  const pr=G.prio&&p?' · отмечена цель на '+Math.round(Math.hypot(G.prio.x-p.x,G.prio.y-p.y))+' px':'';
  const cs=diag77Cv(D77.vs,D77.vn,D77.vi),cc=diag77Cv(D77.vc,D77.vn,D77.vi),q=v=>v===null?'—':Math.round(v*100)+'%';
  const F=ARCH.d78&&ARCH.d78.fail?' · АВАРИЯ A-23: '+ARCH.d78.where:'';
  D77.txt=['ДИАГНОСТИКА · ARCH·77 · '+(old?'старый цикл':'цикл A-20')+' · '+(med>0?(1000/med).toFixed(1)+' Гц':'—')+' · кадр мин/мед/макс '+(d.length?d[0].toFixed(1)+'/'+med.toFixed(1)+'/'+d[d.length-1].toFixed(1):'—')+' мс',
    (old?'шаги за кадр: — (старый цикл)':'шаги за кадр  0:'+pc(z)+'  1:'+pc(a)+'  2:'+pc(b)+'  3:'+pc(c)+' · в минуту: 0-шаговых '+pm(z)+', 2-шаговых '+pm(b))+', пропусков vsync '+pm(m),
    'A-23 '+(ARCH.vi?'включена':'выключена')+(I?' · '+(I.act?'интерполирует':'спит')+' · переключений '+D77.tog+' · доля шага '+(I.al||0).toFixed(2):'')+F,
    'цель: '+src+dist+pr,
    'рывки видимой скорости от кадра к кадру: корабль '+q(cs)+' · камера '+q(cc)+' · запись '+Math.min(30,(now-D77.t0)/1000).toFixed(0)+'/30 с · экспорт: F8 или выключить'];}
function diag77Draw(){
  const w=Math.min(CW-20,660),y0=isMob()?172:86;ctx.save();ctx.setTransform(DPR,0,0,DPR,0,0);ctx.font='700 10px "JetBrains Mono",monospace';ctx.textAlign='left';ctx.textBaseline='top';
  if(D77.wrapAt!==D77.txtAt||D77.wrapW!==w){D77.wrapAt=D77.txtAt;D77.wrapW=w;const out=[];
    for(const s of D77.txt){let cur='';for(const part of s.split(' · ')){const t=cur?cur+' · '+part:part;if(cur&&ctx.measureText(t).width>w-14){out.push(cur);cur='   '+part;}else cur=t;}out.push(cur);}D77.lines=out;}
  const L=D77.lines||[];ctx.globalAlpha=.78;ctx.fillStyle='#000';ctx.fillRect(10,y0-4,w,L.length*13+36);ctx.globalAlpha=1;ctx.fillStyle='#00ff88';
  for(let i=0;i<L.length;i++)ctx.fillText(L[i],16,y0+i*13);
  const gy=y0+L.length*13+28,N=Math.min(D77.dn,(w-12)/2|0);ctx.lineWidth=1;ctx.strokeStyle='#00ff88';ctx.beginPath();
  for(let j=0;j<N;j++){const v=D77.dts[(D77.di-N+j+480)%240],h=Math.min(24,v/50*24);ctx.moveTo(16+j*2+.5,gy);ctx.lineTo(16+j*2+.5,gy-h);}ctx.stroke();
  ctx.strokeStyle='#ffb84d';ctx.beginPath();ctx.moveTo(16,gy-8);ctx.lineTo(16+w-12,gy-8);ctx.stroke();ctx.restore();}
function diag77Rows(sec,now){const R=[],C=D77C.length,B=D77.buf;for(let j=D77.n-1;j>=0;j--){const k=((D77.i-1-j+D77.cap*2)%D77.cap)*C;if(now-B[k]>sec*1000)continue;const r=[];for(let c=0;c<C;c++){const v=B[k+c];r.push(v===v?+v.toFixed(c===0?3:4):null);}R.push(r);}return R;}
function diag77Export(why){if(!D77.buf)return null;const R=diag77Rows(30,D77.n?D77.buf[((D77.i-1+D77.cap)%D77.cap)*D77C.length]:D77.last);/* окно — 30 с до последнего игрового кадра */
  const out={what:'VØID ARCH·77 диагностика кадров',ver:typeof VER_TAG!=='undefined'?VER_TAG:'',why,at:new Date().toISOString(),ua:navigator.userAgent,dpr:devicePixelRatio,
    screen:[screen.width,screen.height],off:Object.keys(ARCH.off).filter(k=>ARCH.off[k]),ipMode:typeof IP76!=='undefined'?IP76.mode:null,cols:D77C,
    note:'now — метка rAF, мс; dt0 — с; n — шагов в кадре (-1 старый цикл); acc — накопитель после шагов, с; ip: 1 — A-23 включена, 2 — интерполирует, 4 — старый цикл; px/py — видимое положение корабля, cx/cy — камера',rows:R};
  window.__diag77last=out;
  const name='void-diag77-'+out.at.replace(/[:.]/g,'-')+'.json',txt=JSON.stringify(out);
  const link=()=>{try{const b=new Blob([txt],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},4000);}catch(e){console.warn('ARCH·77 экспорт',e);}};
  /* в просмотрщике claude.ai обычная ссылка скачивания не работает — там файл отдаётся через возможность downloads */
  try{if(window.claude&&typeof window.claude.use==='function')window.claude.use('downloads').then(d=>{if(d)d.save({filename:name,data:txt}).catch(e=>console.warn('ARCH·77 экспорт',e));else link();},link);else link();}catch(e){link();}
  return out;}
addEventListener('keydown',e=>{if(e.code==='F8'&&D77.on){e.preventDefault();diag77Export('F8');}});
/* ▲▲▲ ARCH·77 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·78 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.18 α · исправление A-23)
   1) Снег и дождь мира (G.w.snow, G.w.rain) двигает сама отрисовка (w58Screen), а не шаг игры. A-23 возвращала им после
      рисования значения шага, и на 90–144 Гц осадки стояли. Перепись отрисовки (стенд rcensus78: 13 сценариев, компьютер и телефон)
      нашла только эти два списка, поэтому они исключены из A-23 точечно. Других изменений в работе интерполяции нет.
   2) Ошибка внутри интерполяции больше не может остановить цикл или оставить объекты в промежуточном положении: всё уже
      сдвинутое возвращается на точные значения, A-23 выключается до перезагрузки, причина пишется в ARCH.d78 и в консоль. */
IP76SKIP.add('snow');IP76SKIP.add('rain');IP76.rp=0;
ARCH.d78={fail:0,where:'',msg:''};
function ip78Off(where,e){ARCH.vi=false;IP76.act=false;IP76.ok=0;ARCH.d78.fail++;ARCH.d78.where=where;ARCH.d78.msg=String(e&&e.message||e).slice(0,200);
  try{console.warn('ARCH·78: интерполяция A-23 выключена до перезагрузки ('+where+')',e);}catch(_){}}
function ip78Back(n){const C=IP76.B;for(let i=Math.min(n,C.n)-1;i>=0;i--){try{const o=C.o[i];if(!o)continue;o.x=IP76.rx[i];o.y=IP76.ry[i];const a=IP76.ra[i];if(a===a)o.ang=a;}catch(e){}}CX=IP76.rcx;CY=IP76.rcy;}
function ip78Apply(dt0){IP76.rp=0;IP76.rcx=CX;IP76.rcy=CY;try{return ip76Apply(dt0);}catch(e){ip78Back(IP76.rp);ip78Off('перед отрисовкой',e);return false;}}
function ip78Restore(){try{ip76Restore();}catch(e){ip78Back(IP76.rn);ip78Off('после отрисовки',e);}}
function ip78Post(){try{ip76Post();}catch(e){ip78Off('запись после шага',e);}}
/* ▲▲▲ ARCH·78 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·79 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.19 α · A-25: фаза накопителя)
   A-25 · при загрузке и пока игра стоит (меню, пауза, выбор улучшения), накопитель A-20 держится на половине шага, а не на нуле.
   При нуле на экране ровно 60 Гц остаток после каждого шага оказывается точно на границе шага, и округление меток rAF
   (0,1 мс и грубее) раскидывает кадры на 0 и 2 шага — видимое подёргивание. С половиной шага граница далеко от меток.
   Скорость игры не меняется: шаги по-прежнему ровно 1/60 с, предел 3 шага на кадр тот же; средняя доля времени, теряемая
   при каждом входе в игру, становится 0 вместо половины шага. Выключение: window.__archOff=['A-25'] до загрузки. */
ARCH.a25=!ARCH.off['A-25']&&!ARCH.off['A-20']&&!ARCH.off['A-19'];if(ARCH.a25)ACC74=STEP74/2;
/* ▲▲▲ ARCH·79 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·80 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.20 α · A-24: свобода корпуса, эксперимент)
   A-24 · цель, автострельба и направление выстрела работают как прежде (pickTarget, shoot=!!tg, aimPt, радиусы 560/700/760/800,
   G.prio, G.tg90 не меняются). Меняется только желаемый угол корпуса в автонаведении: если корабль летит ОТ цели
   (скорость больше v0, угол между скоростью и направлением на цель больше 90°) и цель дальше r0, корпус плавно доворачивается
   к направлению полёта. Вес w = гладкая ступень(скорость) · гладкая ступень(угол) · гладкая ступень(дальность), 0…1;
   поворот идёт тем же сглаживанием, что и раньше (dt·14), так что скачков угла нет. Пока w = 0, всё побитно как без A-24.
   Зависит от поворота (согласованно): точка вылета пуль (смещается к цели пропорционально w — пули не пролетают сквозь корпус),
   рывок с места без ввода (летит по корпусу). Механики, которые читают курс корабля для баланса (Отзвук echo80, пара hollow100),
   читают «прежний» курс — тот, который был бы без A-24 (считается параллельно теми же формулами). В бою с боссом, «Нолём» и в ручном прицеле не работает.
   Включение только явно: window.__a24on=true до загрузки (пробная сборка). Параметры: window.__a24={r0,r1,v0,v1,c0,c1,dash}; dash:'aim' — рывок без ввода по прежнему курсу на цель. */
const A24P=Object.assign({r0:200,r1:320,v0:60,v1:180,c0:0,c1:-.5,dash:'hull'},window.__a24||{});
ARCH.a24=window.__a24on===true&&!ARCH.off['A-24'];
ARCH.a24s={p:null,ang:0,last:0,ep:false,w:0,n:0};
function a24ss(x){x=x<0?0:x>1?1:x;return x*x*(3-2*x);}
function a24Boss(){return !!((G.boss&&G.boss.st==='fight')||(G.jam&&G.jam.st==='fight')||(G.sb&&G.sb.alive&&G.sb.st==='fight')||G.zb);}
function a24Want(p,tg,want,sp,dt,man){const A=ARCH.a24s;
  if(A.p!==p){A.p=p;A.ang=p.ang;A.last=p.ang;A.ep=false;A.w=0;}
  if(p.ang!==A.last){if(A.ep)A.ang+=angDiff(p.ang,A.last);else A.ang=p.ang;}/* курс изменён вне поворота (зеркало, сброс): прежний курс следует за ним */
  /* «прежний» курс: тот же поворот, что у корпуса без A-24 — те же формулы и то же want, поэтому побитно равен p.ang сборки без A-24 */
  A.ang+=man?clamp(angDiff(want,A.ang)*Math.min(1,dt*18),-.45,.45):angDiff(want,A.ang)*Math.min(1,dt*14);
  let w=0;if(!man&&tg&&sp>A24P.v0&&!a24Boss()){const q=aimPt(tg),dx=q.x-p.x,dy=q.y-p.y,d=Math.hypot(dx,dy);
    if(d>A24P.r0){const c=(p.vx*dx+p.vy*dy)/(sp*d);w=a24ss((A24P.c0-c)/(A24P.c0-A24P.c1))*a24ss((sp-A24P.v0)/(A24P.v1-A24P.v0))*a24ss((d-A24P.r0)/(A24P.r1-A24P.r0));}}
  A.w=w;let wn=want;
  if(w>0){A.n++;const mA=Math.atan2(p.vy,p.vx);let df=angDiff(mA,want);
    if(Math.abs(df)>2.8){const s=angDiff(p.ang,want);if(s!==0&&(s>0)!==(df>0))df+=df>0?-TAU:TAU;}/* почти встречно: доворот с той стороны, где корпус уже стоит */
    wn=want+df*w;}
  A.last=p.ang+(man?clamp(angDiff(wn,p.ang)*Math.min(1,dt*18),-.45,.45):angDiff(wn,p.ang)*Math.min(1,dt*14));/* то же выражение, что в updatePlayer */
  A.ep=A.last!==A.ang;
  return wn;}
function a24Hull(p){const A=ARCH.a24s;return ARCH.a24&&A.p===p?A.ang:p.ang;}
function a24Muz(p,base){const A=ARCH.a24s;return A.p===p&&A.w>0?p.ang+angDiff(base,p.ang)*A.w:p.ang;}
/* ▲▲▲ ARCH·80 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·81 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.21 α · этап 5, пилот: перенос функций наведения)
   Исполняемого кода в этом блоке нет. Функции наведения собраны в один блок сразу после итогового объявления nearestEnemy
   (ищите «ARCH·81 · ПОДСИСТЕМА НАВЕДЕНИЯ»); на их прежних местах оставлены метки «ARCH·81 →». */
/* ▲▲▲ ARCH·81 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·82 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.22 α · этап 5: шаг наведения вынесен из updatePlayer)
   A-26: флаг и ветка отката сняты в ARCH·87 (1.5.27); window.__archOff=['A-26'] больше ничего не меняет. */
/* ARCH·87: флаг A-26 снят вместе с веткой отката (1.5.27); window.__archOff=['A-26'] больше ничего не меняет */
/* ▲▲▲ ARCH·82 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·83 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.23 α · этап 5: контролируемые точки записи G.prio / G.aimLock)
   Исполняемого кода в этом блоке нет и флага нет: шесть внешних присваиваний заменены вызовами prioSet / prioClear / aimLockClear
   (объявлены в конце блока «ARCH·81 · ПОДСИСТЕМА НАВЕДЕНИЯ»). Откат — снятие патча 83. Это не инкапсуляция: G по-прежнему глобален. */
/* ▲▲▲ ARCH·83 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·84 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.24 α · этап 5: правила границы подсистемы наведения и приёмка)
   Исполняемого кода нет: изменены только номер версии, запись журнала и текст комментария границы в начале блока
   «ARCH·81 · ПОДСИСТЕМА НАВЕДЕНИЯ». Правила — в tools5/ownership5.json (манифест v2). Откат — снятие патча 84. */
/* ▲▲▲ ARCH·84 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·85 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.25 α · этап 7: недостижимые объявления)
   Исполняемого кода нет. Сняты 24 объявления функций верхнего уровня (23 имени), которые перекрыты более поздним объявлением
   того же имени: при подъёме объявлений имя связывается с последним, к прежним не ведёт ни одна ссылка. Вместо каждого — метка
   «ARCH·85 · снято …». Имена: nearestEnemy (2), aimPt и 21 функция прежней версии сверхбосса 0.7.5 (s74Hurt, b74Hit, sb74*, nu*, fl*).
   Итоговые объявления не лежат в вырезаемых тестами блоках CINE·PROTO / BG·PROTO. Откат — снятие патча 85. */
/* ▲▲▲ ARCH·85 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·86 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.26 α · этап 7: слияние серий слоёв-переустановок)
   Исполняемого кода в этом блоке нет и флага нет. 4 серии соседних однотипных слоёв «{const _p=f; f=function(){pre; r=_p(); post; return r}}»
   одной подсистемы (10 слоёв) заменены 4 объединёнными слоями на месте последнего слоя серии: pre — от внешнего слоя к внутреннему, post — от внутреннего
   к внешнему, как исполнялась цепочка. Локальные имена слоёв переименованы (<имя>_86<номер слоя>), параметры внутренних слоёв читаются из
   arguments. Серии: renderSettings (3), renderSetScreen (3), tutEmit (2), tutMapDraw (2).
   Почему безопасно: между слоями серии нет других записей f, вызовов, достигающих f, и чтений f при загрузке (m6, dump86);
   слои не меняют параметры и arguments, не возвращают раньше и не подменяют результат. Проверка — trace7 (последовательность вызовов).
   Сливаются только серии, все слои которых принадлежат одной подсистеме. Остальные 11 серий (27 слоёв) оставлены раздельными: их слои —
   крючки разных подсистем, на этапе 8 каждый переезжает вместе со своей подсистемой, а слияние собрало бы чужие записи G в одном месте:
   tryPulse (tut | skin), toMenu (post | chase | vn | dev), enterNode (chase | dev), mobOverlay (tut | tut | world61), openMap (tut+mapdeny | tut), closeMap (tut+mapdeny | tut), tryDash (tut | skin), banner (tut | dev), pause (tut | tut | pausecard), tutStart (tut | dev+tut), tutTick2 (tut | tut | dev+tut).
   Откат — снятие патча 86. */
/* ▲▲▲ ARCH·86 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·87 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.27 α · этап 7: снята ветка отката A-26)
   Исполняемого кода нет. В updatePlayer удалён прежний встроенный текст шагов наведения (ветка отката A-26, ARCH·82) и выбор
   стрельбы по флагу; шаги наведения выполняет только aimStep / autoFireWanted. Владелец подтвердил работу 1.5.24 (решение Р1).
   Откат — снятие патча 87 (вернёт ветку и флаг A-26). */
/* ▲▲▲ ARCH·87 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·88 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.28 α · этап 6: переходы экранов через одну точку записи)
   Все 41 прямая запись G.state в 38 функциях заменены вызовом scr6(X). Логики сверх присваивания нет: scr6 возвращает присвоенное
   значение, как выражение присваивания; во всех местах оно стояло отдельным оператором, X вычисляется до записи, как и раньше.
   Зарегистрированные исключения (пишут G.state не через scr6): литерал G (начальное «menu») и групповой сброс Object.assign в enterWorldAt
   (state:'world' вместе с полями раунда). Допустимые переходы и правило «писать только через scr6» — tools6/ownership6.json (own6, st6 trans).
   Откат — снятие патча 88. */
function scr6(to){return G.state=to;}
/* ▲▲▲ ARCH·88 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·89 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.29 α · этап 6: идентичность объекта прогресса G.save)
   Все 17 мест, где G.save получает другой объект, идут через saveSet6(S, класс) или saveWith6(S, fn). Класс (второй аргумент) —
   метка для проверок: load (загрузка из хранилища/облака/выход из песочницы), new (новый или выбранный мир), import (код сохранения),
   reset (полный сброс), temp (временная подмена), dev (песочница разработчика). Логики сверх присваивания нет.
   Две временные подмены не восстанавливали прежний объект при исключении. doneCountS: единственный вызов (подпись главной кнопки
   меню) передаёт текущее сохранение, поэтому видимой ошибки сейчас нет — правка защитная. devAct (режим разработчика, начисление
   опыта пилоту вне песочницы): при исключении активным оставалось сохранение песочницы. Обе подмены теперь восстанавливаются в finally.
   На обычном пути порядок действий прежний. Реестр мест и классов — tools6/ownership6.json (own6); ловушка устаревшего объекта — st6 saveid.
   Откат — снятие патча 89. */
function saveSet6(S,why){return G.save=S;}
function saveWith6(S,fn){const k=G.save;G.save=S;try{return fn();}finally{G.save=k;}}
/* ▲▲▲ ARCH·89 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·89b · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.30 α · этап 6: граница подсистемы «прокачка забега»)
   Поля G.xp, G.lvl, G.need, G.lvlQ, G.bpQ, G.briefQ, G.briefN (опыт, уровень, порог, очереди модулей корабля / маяка / брифинга)
   пишут только функции этого блока. Было: 34 места в 19 функциях, две копии цикла повышения уровня (update, worldUpdate) и две копии
   старта брифинга (startMission, zbTick). Стало: 19 вызовов API. Зарегистрированные исключения — большие групповые сбросы раунда
   Object.assign в setupMission0 и enterWorldAt (bpQ:0 вместе с остальными полями раунда). Чтения полей не ограничены.
   Порядок вычислений сохранён: аргументы вычисляются до записи, как значения литерала в Object.assign; need() и xpMul() не пишут G.
   Порядок создания ключей G тот же (новым может быть только briefQ/briefN — они создаются там же и в том же порядке).
   Правило проверяется own6 (tools6/ownership6.json). Откат — снятие патча 89b. */
function runXp6(v){G.xp+=v;}
function runLvlUp6(p){while(G.xp>=G.need&&p.hp>0){G.xp-=G.need;G.lvl++;G.need=need(G.lvl);G.lvlQ++;}}
function runLvlSeg6(){G.lvlQ++;G.xp=0;G.lvl++;G.need=need(G.lvl);}
function runBrief6(K){Object.assign(G,{lvl:1+K,xp:0,lvlQ:K,briefQ:K,briefN:K});G.need=need(G.lvl);}
function runStart6(lv){Object.assign(G,{xp:0,lvl:lv,lvlQ:0,bpQ:0});G.need=need(lv);}
function runZero6(bp){const n=need(1);G.lvl=1;G.xp=0;G.need=n;G.lvlQ=0;if(bp)G.bpQ=0;G.briefQ=0;}
function runRestore6(r){G.xp=r.xp;G.lvl=r.lvl;G.need=r.need;G.lvlQ=0;G.bpQ=0;}
function runGrant6(k){if(k==='bp')G.bpQ++;else G.lvlQ++;}
function runTake6(k){if(k==='bp')G.bpQ=Math.max(0,G.bpQ-1);else{G.lvlQ=Math.max(0,G.lvlQ-1);if(G.briefQ>0)G.briefQ--;}}
function runQClear6(){G.lvlQ=0;G.briefQ=0;}
/* ▲▲▲ ARCH·89b · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·90a · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.31 α · FPS: 30 / 60 / без ограничения)
   A-27 · предел частоты обработанных кадров. Решает только, обрабатывать ли очередной вызов rAF; игровой шаг остаётся 1/60 (STEP74),
   накопитель ACC74 и MAXN74 не меняются, глобальный requestAnimationFrame не подменяется. Срок следующего кадра накапливается
   (FC27.next += T), поэтому средняя частота точная на любом экране (30.00 / 60.00 на 60–240 Гц), а не «каждый N-й кадр».
   Допуск — половина периода экрана (оценка по интервалам rAF), но не больше половины периода предела. Провал больше 2T (фон, зависание)
   или скачок времени назад сбрасывает срок — без всплеска кадров после возврата. Настройки: SET.fpsCap (телефон/планшет, isMob()) и
   SET.fpsCapD (ПК) — независимы, значения 30 / 60 / 0 (без ограничения). Старый ключ fps синхронизируется при выборе на телефоне
   (30 → 30, иначе 60): при откате на прежнюю версию телефон ведёт себя как выбрано. Сохранённые до 1.5.31 настройки: fps 30 → fpsCap 30,
   fps 60 → 0 (прежний «60» не ограничивал частоту). Выключение: window.__archOff=['A-27'] до загрузки — прежнее условие пропуска и
   прежние две кнопки. Старый frame() (A-20 выкл.) не тронут. Откат — снятие патча 90a.
   Фаза: первый кадр под пределом отсчитывается от последнего обработанного (last + T), как у прежнего условия, — при 60 Гц обработанные
   кадры «30» те же, что в 1.5.24. Если на телефоне старый ключ fps расходится с fpsCap по «30» (его записала прежняя версия при откате
   или облако с неё), действует старый ключ: fps 30 → предел 30, иначе без ограничения — это последний выбор игрока. */
ARCH.fc27=!ARCH.off['A-27'];const FC27={last:0,next:0,disp:0};
function fpsCur27(){if(!isMob())return SET.fpsCapD;const c=SET.fpsCap,o=SET.fps===30;return o!==(c===30)?(o?30:0):c;}
function fpsCap27(){if(!ARCH.fc27)return 0;const c=fpsCur27();return c===30||c===60?c:0;}
function gate27(now){const cap=fpsCap27();
  if(FC27.last){const d=now-FC27.last;if(d>0&&d<100)FC27.disp=FC27.disp?FC27.disp+(d-FC27.disp)*.1:d;}FC27.last=now;
  if(cap<=0){FC27.next=0;return true;}
  const T=1000/cap,tol=Math.min(T*.5,Math.max(1,FC27.disp*.5));
  if(!FC27.next&&now>=last&&now-last<2*T)FC27.next=last+T;
  if(!FC27.next||now<FC27.next-4*T||now-FC27.next>2*T){FC27.next=now+T;return true;}
  if(now<FC27.next-tol)return false;
  FC27.next+=T;return true;}
function fpsPick27(raw){const v=[30,60,0].find(o=>String(o)===raw);if(v===undefined)return;const mob=isMob();SET[mob?'fpsCap':'fpsCapD']=v;if(mob)SET.fps=v===30?30:60;
  saveSet();applySettings();renderSetScreen();buzz('tap');}
/* ▲▲▲ ARCH·90a · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·90b · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.32 α · FPS: строка «КАДРЫ» на ПК)
   Исполняемого кода нет. layout63 больше не убирает строку «КАДРЫ» на ПК (при A-27 вкл.); «МАСШТАБ» и «КАЧЕСТВО» на ПК скрыты, как раньше.
   Решение владельца Р2; ожидание теста L03 (kit/q310.py) обновлено по его тексту. Откат — снятие патча 90b. */
/* ▲▲▲ ARCH·90b · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·91 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.33 α · FPS: предел кадров не снижает качество сам по себе)
   Автокачество (qTick) и облегчённые эффекты бесконечного режима (fpsLow в frame74) судят о нехватке производительности по
   интервалу между обработанными кадрами. При пределе 30 этот интервал ≈ 1/30 с — больше прежних порогов 1/50 и 1/40, и качество
   падало без всякой нагрузки. Теперь пороги учитывают ожидаемый интервал предела E = 1/cap: снижение — при среднем > max(1/50, 1.2·E),
   fpsLow — при кадре > max(1/40, 1.2·E), повышение — при среднем < max(1/83, 1.05·E). Без предела (cap 0) и при A-27 выкл. пороги прежние.
   Настоящая перегрузка (кадр заметно дольше предела) по-прежнему снижает качество. Старый frame() не тронут. Откат — снятие патча 91. */
function qDn27(){const c=fpsCap27();return c>0?Math.max(1/50,1.2/c):1/50;}
function qUp27(){const c=fpsCap27();return c>0?Math.max(1/83,1.05/c):1/83;}
function fpsLowT27(){const c=fpsCap27();return c>0?Math.max(1/40,1.2/c):1/40;}
/* ▲▲▲ ARCH·91 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·92 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.34 α · FPS: интерполяция A-23 при пределе на быстром экране)
   A-23 включалась по средней длине обработанного кадра (< 0.8 шага). При пределе 60 на экране 75–240 Гц средний кадр ≈ шагу, и
   интерполяция выключалась, хотя кадры показываются на неравномерной сетке экрана. Теперь она включается и тогда, когда действует
   предел, а период самого экрана (оценка gate27) меньше 0.8 шага. Симуляция не меняется: A-23 сдвигает только отрисовку и возвращает
   позиции после кадра. Принято по измерению fps6 (неравномерность отрисованного движения). Откат — снятие патча 92 или A-23 / A-27. */
function ip27fast(){return fpsCap27()>0&&FC27.disp>0&&FC27.disp<STEP74*800;}
/* ▲▲▲ ARCH·92 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */
/* ▼▼▼ ARCH·93 · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.35 α · этапы 6+7: итог)
   Исполняемого кода нет. Границы владения полями G после этапа 6 (проверка — node tools6/own6.js по tools6/ownership6.json):
     экраны      G.state                                   — только scr6 (ARCH·88); исключение — групповой сброс enterWorldAt;
     прогресс    смена объекта G.save                      — только saveSet6 / saveWith6 (ARCH·89); содержимое G.save.* не ограничено;
     прокачка    G.xp, lvl, need, lvlQ, bpQ, briefQ, briefN — только run*6 (ARCH·89b); исключения — сбросы раунда setupMission0, enterWorldAt (bpQ);
     наведение   G.prio, aimLock, tg90, noTg75, aimWarn75  — подсистема ARCH·81 и prioSet / prioClear / aimLockClear; исключения — сбросы раунда.
   Этап 7: сняты 24 недостижимых объявления (ARCH·85), 4 серии из 10 слоёв одной подсистемы слиты в 4 слоя (ARCH·86; 11 серий из слоёв разных подсистем оставлены раздельными), снята ветка A-26 (ARCH·87).
   Оставшиеся цепочки переустановок перечислены с назначением и классом в tools6/chains6.json. Чтения полей G не ограничены:
   G остаётся одним глобальным объектом — это границы записи, а не инкапсуляция. Откат — снятие патча 93. */
/* ▲▲▲ ARCH·93 · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */


/* ▼▼▼ PERF·OPT · НАЧАЛО ВЫРЕЗАЕМОГО БЛОКА ▼▼▼ (1.5.8 α)
   Оптимизации без изменения поведения. Каждая выключается флагом: PERF.off['O-n']=1 в консоли
   или window.__perfOff=['O-n'] до загрузки — тогда идёт старый путь. Точечные места помечены «PERF·OPT O-n». */
var PERF={off:{}};try{if(window.__perfOff)for(const k of window.__perfOff)PERF.off[k]=1;}catch(e){}
/* O-6 · один форматтер чисел на всю игру — НАЧАЛО.
   toLocaleString('ru-RU') по стандарту = new Intl.NumberFormat('ru-RU').format(x): тот же текст, но без создания форматтера на каждый вызов */
var NF68=null;try{NF68=new Intl.NumberFormat('ru-RU');}catch(e){NF68=null;}
function ru68(n){return (NF68&&!PERF.off['O-6'])?NF68.format(n):n.toLocaleString('ru-RU');}
/* O-6 — КОНЕЦ */
/* O-3 · враги: те же вычисления, меньше лишних — НАЧАЛО.
   Math.hypot(dx,dy) ≥ max(|dx|,|dy|), поэтому пара, у которой |dx| или |dy| уже ≥ порога, заведомо не проходит проверку «< порога».
   Набор, порядок обхода и все числа — прежние. */
/* три ближайших к щитоносцу: расстояние один раз на кандидата; сортировка стабильная по тем же числам — тот же порядок при равенстве */
function o3Near(s){const sx=s.x,sy=s.y,a=[];
  for(const o of G.enemies){const dx=o.x-sx,dy=o.y-sy;if(dx>=240||dx<=-240||dy>=240||dy<=-240)continue;if(!(o.alive&&o!==s&&o.type!=='shielder'&&!HEAVY.has(o.type)&&o.type!=='moth'))continue;const d=Math.hypot(dx,dy);if(d<240)a.push({o,d});}
  a.sort((p,q)=>p.d-q.d);const r=[];for(let i=0;i<a.length&&i<3;i++)r.push(a[i].o);return r;}
/* разведение: фильтр sep() не зависит от координат — считается один раз; пары идут в прежнем порядке i<j */
var O3L=[];
function o3Sep(es,sep){const L=O3L;let n=0;for(let i=0;i<es.length;i++)if(sep(es[i]))L[n++]=es[i];
  for(let i=0;i<n;i++){const a=L[i];for(let j=i+1;j<n;j++){const b=L[j],dx=b.x-a.x,dy=b.y-a.y,m=a.r+b.r+2;
    if(dx>=m||dx<=-m||dy>=m||dy<=-m)continue;
    const d=Math.hypot(dx,dy);if(d>0&&d<m){const k=(m-d)/d*.5;a.x-=dx*k;a.y-=dy*k;b.x+=dx*k;b.y+=dy*k;}}}
  L.length=0;}
/* O-3 — КОНЕЦ */
/* ▲▲▲ PERF·OPT · КОНЕЦ ВЫРЕЗАЕМОГО БЛОКА ▲▲▲ */

/* 1.0.0 α: слой хранения. Браузерное хранилище может отказать (встроенное окно, приватный режим, переполнение) или прийти пустым
   после новой версии. LS держит копию каждой записи в памяти — в этой вкладке прогресс не теряется, а облако (ниже) переносит его между версиями. */
const LS=(function(){const mem={},bad={},hooks=[];let real=null;try{real=window.localStorage;real.getItem('void_world');}catch(e){real=null;}
  const has=k=>Object.prototype.hasOwnProperty.call(mem,k);const fire=k=>{for(const f of hooks){try{f(k);}catch(e){}}};
  return {ok(){return !!real;},persisted(k){return !!real&&!bad[k];},
    getItem(k){if(real&&!bad[k]){try{return real.getItem(k);}catch(e){}}return has(k)?mem[k]:null;},
    setItem(k,v,quiet){v=String(v);mem[k]=v;let ok=false;if(real){try{real.setItem(k,v);ok=true;delete bad[k];}catch(e){bad[k]=1;}}else bad[k]=1;
      if(!quiet)fire(k);if(!ok){const er=new Error('storage write failed');er.name='QuotaExceededError';throw er;}},
    removeItem(k,quiet){delete mem[k];delete bad[k];if(real){try{real.removeItem(k);}catch(e){}}if(!quiet)fire(k);},
    onWrite(f){hooks.push(f);}};})();
/* =====================================================================
   VØID 0_2_0 «Последний сигнал» + дополнение 0.1.1 «Маяк» (альфа)
   Подсистемы: утилиты · настройки · аудио · рендер-ресурсы · данные · игрок · стрельба
   · враги · Страж · маяк · режиссёр · уровень (астероиды, линии, тьма, буря) · события
   · Глушитель · подбор · прогрессия · отрисовка · HUD · экраны · ввод · цикл
   ===================================================================== */
/* ВРЕМЕННО (альфа 0.5.9): все уровни и Бездна открыты для теста, прыжок с карты к любому узлу.
   Убрать перед бетой: ALPHA_OPEN = false, затем удалить все блоки с пометкой "ВРЕМЕННО (альфа 0.5.9)". */
const ALPHA_OPEN = (typeof window!=='undefined'&&window.__alpha===true); // 1.0.0 α: мир закрыт туманом войны; true выставляют только старые тесты // ВРЕМЕННО (альфа 0.5.9): false выставляют только тесты
function gateOpen(){return !!G.save&&(!!G.save.gate||ALPHA_OPEN);} // ВРЕМЕННО (альфа 0.5.9): ворота проходимы в альфе
function abyssOpen(){return gateOpen();} // 0.5.9: Бездна открыта вместе с воротами (в альфе — всегда)
const COLD_A=0.5; // 0.5.9: холод сектора III прозрачнее вдвое (множитель всех декоративных слоёв)
const PATROL_HP_K=1/3; // 0.5.9: прочность патрулей III–IV ÷3

// ---------- Утилиты ----------
const $=s=>document.querySelector(s);
const TAU=Math.PI*2;
const rnd=(a,b)=>a+Math.random()*(b-a);
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const angDiff=(a,b)=>{let d=(a-b)%TAU;if(d>Math.PI)d-=TAU;if(d<-Math.PI)d+=TAU;return d;};
function segDist(ax,ay,bx,by,px,py){const dx=bx-ax,dy=by-ay,l=dx*dx+dy*dy;let t=l?((px-ax)*dx+(py-ay)*dy)/l:0;t=clamp(t,0,1);return Math.hypot(ax+dx*t-px,ay+dy*t-py);}
function segPoint(ax,ay,bx,by,px,py){const dx=bx-ax,dy=by-ay,l=dx*dx+dy*dy;let t=l?((px-ax)*dx+(py-ay)*dy)/l:0;t=clamp(t,0,1);return{x:ax+dx*t,y:ay+dy*t};}
function segInter(ax,ay,bx,by,cx,cy,dx,dy){const r1=bx-ax,r2=by-ay,s1=dx-cx,s2=dy-cy,den=r1*s2-r2*s1;if(Math.abs(den)<1e-9)return false;const t=((cx-ax)*s2-(cy-ay)*s1)/den,u=((cx-ax)*r2-(cy-ay)*r1)/den;return t>=0&&t<=1&&u>=0&&u<=1;}
const fmt=n=>ru68(Math.round(n));/* PERF·OPT O-6 */
const pad2=n=>String(n).padStart(2,'0');
const LOMSVG='<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.4 13.7 4.7v6.6L8 14.6 2.3 11.3V4.7Z" fill="#141c28" stroke="#c9d2de" stroke-width="1.4" stroke-linejoin="round"/><path d="M8 1.4 13.7 4.7 8 8Z" fill="#ffb84d" opacity=".9"/><circle cx="8" cy="8" r="2.3" fill="#04060c" stroke="#c9d2de" stroke-width="1.2"/></svg>';
const fmtN=n=>typeof n==='number'?ru68(Math.round(n)):n;/* PERF·OPT O-6 */
function lomH(n,big){return `<span class="lom${big?' big':''}">${LOMSVG}<b>${fmtN(n)}</b></span>`;}
function store(k,v){/*DEVW*/if(v!==undefined&&window.DEVW&&DEVW.block(k))return null;try{if(v===undefined){const s=LS.getItem(k);return s?JSON.parse(s):null;}LS.setItem(k,JSON.stringify(v));G.saveFail=0;}catch(e){if(v!==undefined&&k==='void_world'&&!G.saveFail&&!(window.CLOUD&&CLOUD.state==='ready')){G.saveFail=1;try{toast('СОХРАНЕНИЕ НЕ ЗАПИСАНО','Браузер не даёт записать прогресс: хранилище переполнено или запрещено. Скопируйте код сохранения в меню, иначе прогресс пропадёт.');}catch(_){}}return null;}}
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]];}return a;}

// ---------- Настройки и рекорд ----------
const SET_DEF={amb:true,ambVol:.6,sfx:true,fx:true,manual:true,radio:true,zoom:1,btnSize:1,btnAlpha:.7,hand:'r',stick:'float',dashSwipe:true,haptics:true,softInv:false,oneHand:false,quality:'auto',fps:60,textScale:1,fsMode:(window.matchMedia&&matchMedia('(pointer:coarse)').matches)?'auto':'off',orient:'auto',fsHintShown:false,shake:1,noErase:false,lessFx:false,fpsCap:0,fpsCapD:0};/* ARCH·90a: fpsCap — телефон/планшет, fpsCapD — ПК; 0 — без ограничения */
const SET_OPT={fsMode:['off','auto','always'],orient:['auto','land','port'],zoom:[.85,1,1.15],btnSize:[.85,1,1.2],btnAlpha:[.45,.7,1],hand:['r','l'],stick:['float','fixed'],quality:['auto',0,1,2],fps:[60,30],fpsCap:[30,60,0],fpsCapD:[30,60,0],textScale:[1,1.15,1.3],shake:[0,.5,1]};
const SET=Object.assign({},SET_DEF,(()=>{const v=store('void_settings');return v&&typeof v==='object'&&!Array.isArray(v)?v:{};})());
{const v=store('void_settings');if(!(v&&typeof v==='object'&&!Array.isArray(v)&&'fpsCap' in v))SET.fpsCap=SET.fps===30?30:0;}/* ARCH·90a: прежний «30» — предел на телефоне, прежний «60» — предела не было */
for(const k in SET_DEF){const d=SET_DEF[k];if(SET_OPT[k]){if(!SET_OPT[k].includes(SET[k]))SET[k]=d;}else if(typeof SET[k]!==typeof d||(typeof d==='number'&&!Number.isFinite(SET[k])))SET[k]=d;}
if(SET.ambVol<0||SET.ambVol>1)SET.ambVol=SET_DEF.ambVol;
// 0.6.2: миграция autoFs (0.6.1) → fsMode
{const raw=store('void_settings');if(raw&&typeof raw==='object'&&typeof raw.autoFs==='boolean'&&raw.fsMode===undefined)SET.fsMode=raw.autoFs?'auto':'off';delete SET.autoFs;}
const REC=Object.assign({best:0,maxMission:0,seen:['scout']},store('void_record')||{});
if(!Array.isArray(REC.seen))REC.seen=['scout'];
function saveSet(){store('void_settings',SET);}
function saveRec(){if(devAny())return;store('void_record',REC);}
function recReload(){const s=store('void_record')||{};for(const k in REC)delete REC[k];Object.assign(REC,{best:0,maxMission:0,seen:['scout']},s);}
function saveKey(){/*DEVW*/return window.DEVW&&DEVW.on()?'void_devworld':'void_world';}

// ---------- Аудио (WebAudio, синтез без файлов) ----------
const AU={ctx:null};
function audioInit(){
  if(AU.ctx){if(AU.ctx.state!=='running'&&AU.ctx.state!=='closed'){try{AU.ctx.resume();}catch(e){}}return;}
  try{
    const A=window.AudioContext||window.webkitAudioContext;const c=new A();AU.ctx=c;
    AU.amb=c.createGain();AU.amb.gain.value=0;AU.amb.connect(c.destination);
    AU.sfx=c.createGain();AU.sfx.gain.value=.32;const slp=c.createBiquadFilter();slp.type='lowpass';slp.frequency.value=4200;AU.sfx.connect(slp);slp.connect(c.destination);
    musInit();
    AU.pingT=6;applyAudio();
  }catch(e){AU.ctx=null;}
}
function applyAudio(){if(!AU.ctx)return;const t=AU.ctx.currentTime;AU.amb.gain.setTargetAtTime(SET.amb?SET.ambVol*.55:0,t,.6);}
const sfxLast={};
const PENTA=[523.25,587.33,659.25,783.99,880];
function sfx(n){
  if(!AU.ctx||!SET.sfx)return;const c=AU.ctx,t=c.currentTime;
  const lim={shot:.07,hit:.04,pick:.03,block:.05,boom:.05,bhit:.15,kill:.05,killBig:.08};if(lim[n]){if(sfxLast[n]&&t-sfxLast[n]<lim[n])return;sfxLast[n]=t;}
  const tone=(f0,f1,dur,type,vol,delay=0)=>{const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(f0,t+delay);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+delay+dur);g.gain.setValueAtTime(vol,t+delay);g.gain.exponentialRampToValueAtTime(.0001,t+delay+dur);o.connect(g);g.connect(AU.sfx);o.start(t+delay);o.stop(t+delay+dur+.02);};
  const noise=(dur,vol,f)=>{const len=c.sampleRate*dur|0,b=c.createBuffer(1,len,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<len;i++)d[i]=(Math.random()*2-1)*(1-i/len);const s=c.createBufferSource();s.buffer=b;const fl=c.createBiquadFilter();fl.type='lowpass';fl.frequency.value=f;const g=c.createGain();g.gain.value=vol;s.connect(fl);fl.connect(g);g.connect(AU.sfx);s.start(t);};
  switch(n){
    case 'shot':{const f=rnd(760,860);tone(f,f*.6,.07,'triangle',.034);tone(f*2.01,f*1.3,.045,'sine',.01);break;}
    case 'hit':tone(420,300,.04,'sine',.03);break;
    case 'kill':{const n=PENTA[Math.random()*5|0];tone(n,n,.16,'triangle',.06);tone(n*1.5,n*1.5,.2,'sine',.035,.04);noise(.12,.12,700);break;}
    case 'killBig':{const n=PENTA[Math.random()*5|0]/2;tone(n,n,.32,'triangle',.08);tone(n*1.5,n*1.5,.36,'sine',.05,.05);tone(n*2,n*2,.3,'sine',.03,.1);noise(.3,.22,500);break;}
    case 'boom':noise(.35,.35,700);tone(110,45,.35,'sine',.22);break;
    case 'bigboom':noise(1.4,.8,600);tone(80,25,1.3,'sine',.5);break;
    case 'pick':tone(900,1500,.08,'sine',.09);break;
    case 'cell':tone(500,1000,.12,'triangle',.12);tone(1000,1600,.12,'sine',.08,.08);break;
    case 'dash':noise(.18,.25,2400);tone(200,600,.15,'sawtooth',.05);break;
    case 'hurt':tone(220,60,.25,'sawtooth',.16);noise(.2,.3,1200);break;
    case 'shield':tone(1200,400,.2,'triangle',.12);break;
    case 'pulse':tone(90,30,.7,'sine',.5);noise(.6,.4,1600);break;
    case 'level':[523,659,784,1046].forEach((f,i)=>tone(f,f,.18,'triangle',.09,i*.07));break;
    case 'warn':tone(660,660,.12,'square',.05);tone(660,660,.12,'square',.05,.18);break;
    case 'block':tone(1800,900,.05,'square',.03);break;
    case 'bhit':tone(180,90,.2,'square',.07);break;
    case 'flash':[392,523,659].forEach((f,i)=>tone(f,f*2,.5,'sine',.08,i*.05));break;
    case 'charged':tone(1400,300,.35,'sawtooth',.06);tone(700,180,.4,'triangle',.12);noise(.25,.25,3000);break;
  }
}

// ---------- Холст и масштаб ----------
const cv=$('#cv');let ctx=cv.getContext('2d');
let DPR=1,SC=1,W=900,H=600,CW=900,CH=600;
let BW=900,BH=600,CX=0,CY=0,VW=900,VH=600,BMIN=0;
let nebula=null,stars=[],darkC=null,dctx=null;
// 0.6.0: видимый мир и разрешение рендера разделены. ПК — 760 единиц на короткую сторону (как раньше), телефон — 560, планшет — 680.
function viewS(){return G.ff==='desk'?760:G.ff==='tablet'?680:560;}
function zoomK(){return (isMob()?(SET.zoom||1):1)*(G.camZ||1);}
function applyWH(){if(G.arena&&!G.world){W=G.arena.w;H=G.arena.h;}else{W=VW;H=VH;}}
function setScale(){SC=Math.max(.42,Math.min(CW,CH)/(viewS()*zoomK()));VW=CW/SC;VH=CH/SC;applyWH();BMIN=isMob()?2.2/SC:0;}
function dprCap(){const q=G.q,cap=q>=2?2:q===1?1.5:1;return Math.min(cap,Math.sqrt(2.2e6/Math.max(1,CW*CH)));}
let rsW=0,rsH=0;
function resize(){
  ffUpdate();CW=window.innerWidth;CH=window.innerHeight;DPR=Math.min(isMob()?dprCap():2,window.devicePixelRatio||1);
  cv.width=Math.round(CW*DPR);cv.height=Math.round(CH*DPR);
  setScale();
  // туманность и звёзды — только при заметной смене размера (адресная строка дёргает resize десятки раз), на ПК — как раньше
  if(!isMob()||Math.abs(CW-rsW)>64||Math.abs(CH-rsH)>64||!nebula||(CW>CH)!==(rsW>rsH)){rsW=CW;rsH=CH;buildNebula();buildStars();}
  if(G.player&&!G.world&&!G.arena){G.player.x=clamp(G.player.x,20,W-20);G.player.y=clamp(G.player.y,20,H-20);}
  if(G.bc&&!G.arena)layoutBeacon();
  if(G.world&&G.player)camSnap();
  if(G.arena&&!G.world&&G.player){G.camSnap=1;missionCam(0);}
  if(typeof layoutTouch==='function')layoutTouch();
}
// арена миссии на телефоне и планшете: 1280×760, длинной стороной вдоль длинной стороны экрана; на ПК арена = экран
function lockArena(){if(!isMob()){G.arena=null;applyWH();return;}G.arena=CW>=CH?{w:1280,h:760}:{w:760,h:1280};applyWH();}
function unlockArena(){G.arena=null;applyWH();}
function missionCam(dt){
  if(!G.arena){CX=0;CY=0;return;}
  const p=G.player;if(!p){CX=(W-VW)/2;CY=(H-VH)/2;return;}
  const off=isPortrait()?.12:.06;let tx=p.x+(p.vx||0)*.35-VW/2,ty=p.y+(p.vy||0)*.35-VH/2+VH*off;
  if(G.bc){tx=tx*.7+(G.bc.x-VW/2)*.3;ty=ty*.7+(G.bc.y-VH/2)*.3;}
  const fx=W>VW?clamp(tx,0,W-VW):(W-VW)/2,fy=H>VH?clamp(ty,0,H-VH):(H-VH)/2;
  const k=G.camSnap||!(dt>0)?1:Math.min(1,dt*6);G.camSnap=0;CX+=(fx-CX)*k;CY+=(fy-CY)*k;}
function buildNebula(){
  const c=document.createElement('canvas');c.width=Math.max(2,CW*DPR/2|0);c.height=Math.max(2,CH*DPR/2|0);const g=c.getContext('2d');
  g.fillStyle='#04060c';g.fillRect(0,0,c.width,c.height);
  const blobs=[['rgba(70,40,140,',.22],['rgba(20,80,130,',.2],['rgba(120,30,70,',.1],['rgba(30,110,140,',.12]];
  for(let i=0;i<7;i++){const [col,a]=blobs[i%blobs.length];const x=Math.random()*c.width,y=Math.random()*c.height,r=rnd(.3,.75)*Math.max(c.width,c.height);
    const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,col+a+')');gr.addColorStop(1,col+'0)');g.fillStyle=gr;g.fillRect(0,0,c.width,c.height);}
  nebula=c;
}
function buildStars(){
  stars=[];const n=Math.round(W*H/2600);
  for(let i=0;i<n;i++){const l=Math.random();stars.push({x:Math.random()*W*1.2-W*.1,y:Math.random()*H*1.2-H*.1,k:l<.6?.02:l<.9?.05:.1,s:l<.6?.8:l<.9?1.3:2,tw:Math.random()*TAU});}
}
const glowCache={};
function glowSprite(col){
  if(glowCache[col])return glowCache[col];const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');
  const gr=g.createRadialGradient(32,32,0,32,32,32);gr.addColorStop(0,col);gr.addColorStop(.35,col+'66');gr.addColorStop(1,col+'00');g.fillStyle=gr;g.fillRect(0,0,64,64);
  return glowCache[col]=c;
}
function glow(x,y,r,col,a=1){if((!SET.fx||G.lowFx)&&r>30||GLOWMAX&&r>GLOWMAX)return;const ga=ctx.globalAlpha;ctx.globalAlpha=ga*a;ctx.drawImage(glowSprite(col),x-r,y-r,r*2,r*2);ctx.globalAlpha=ga;}

// ---------- Данные: угрозы ----------
// grp: siege — летит к маяку, hunt — охотится на игрока, sab — диверсант
const EDEF={
  scout:{name:'Разведчик',hp:18,spd:155,r:11,xp:1,contact:10,col:'#ff5f8a',pts:10,act:1,desc:'Быстро сближается и таранит корпус. Опасен стаей, а не поодиночке.'},
  gunner:{name:'Стрелок',hp:30,spd:95,r:13,xp:2,contact:10,col:'#ff9a4d',pts:20,act:1,desc:'Держит дистанцию и стреляет прицельно. Перед выстрелом ствол раскаляется.'},
  rammer:{name:'Таран',hp:42,spd:80,r:15,xp:3,contact:16,col:'#ff4545',pts:30,act:1,desc:'Подсвечивает траекторию и разгоняется по прямой. Уходите вбок, а не назад.'},
  splitter:{name:'Роевик',hp:36,spd:75,r:16,xp:2,contact:10,col:'#e86bff',pts:25,act:1,desc:'При гибели распадается на три быстрых осколка.'},
  mite:{name:'Осколок',hp:8,spd:190,r:7,xp:1,contact:6,col:'#f2a2ff',pts:5,act:1,desc:'Остаток роевика. Хрупкий, но шустрый.'},
  miner:{name:'Минёр',hp:34,spd:85,r:14,xp:3,contact:10,col:'#ffd24d',pts:30,act:1,desc:'Расставляет мины. Мина взводится за секунду и взрывается, если подлететь близко. Мины можно сбивать.'},
  mine:{name:'Мина',hp:6,spd:0,r:9,xp:0,contact:0,col:'#ffd24d',pts:2,passive:true},
  shielder:{name:'Щитоносец',hp:55,spd:70,r:15,xp:4,contact:10,col:'#9c8cff',pts:45,act:1,desc:'Держится позади и связывает до трёх союзников полем: по ним проходит лишь 35% урона. Снимайте первым.'},
  lancer:{name:'Копейщик',hp:40,spd:75,r:13,xp:4,contact:10,col:'#ff3dbb',pts:45,act:1,desc:'Секунду ведёт вас прицелом, затем бьёт лучом через весь экран. Линия прицела — сигнал к рывку.'},
  guard:{name:'Гвардия',hp:150,spd:72,r:20,xp:8,contact:18,col:'#ffb84d',pts:120,act:1,desc:'Элита Стража. Фронтальный щит отражает выстрелы, но разворачивается медленно — заходите с фланга. Рывок и импульс игнорируют щит.'},
  pylon:{name:'Заряд',hp:85,spd:0,r:13,xp:2,contact:12,col:'#b48cff',pts:60,act:1,desc:'Питает щит ядра Стража. Уничтожьте все заряды, чтобы вызвать перегрузку ядра.'},
  seeker:{name:'Искатель',hp:10,spd:175,r:8,xp:0,contact:12,col:'#ff4f6e',pts:10,act:1,desc:'Самонаводящийся снаряд Стража и Глушителя. Сбивается одним-двумя попаданиями.'},
  boss:{name:'Страж',hp:1800,spd:0,r:54,xp:0,contact:22,col:'#b48cff',pts:5000,act:1,desc:'Три фазы. Ядро неуязвимо, пока живы заряды. Без зарядов ядро уходит в перегрузку: атаки замирают, урон по ядру ×1,5.'},
  // ---- Акт II ----
  moth:{name:'Мотылёк',hp:6,spd:135,r:7,xp:1,contact:3,col:'#ffe08a',pts:4,grp:'siege',noRet:true,act:2,m:7,desc:'Летит стаей на свет маяка и бьётся о него. Одно-два попадания. Стаю у маяка удобно снимать импульсом.'},
  leech:{name:'Пиявка',hp:14,spd:120,r:9,xp:1,contact:0,col:'#c46bff',pts:12,grp:'siege',noRet:true,act:2,m:7,desc:'Прилипает к маяку и тянет из него заряд. Урона не наносит, но каждая пиявка отнимает 0,7% заряда в секунду.'},
  carrier:{name:'Носитель',hp:60,spd:50,r:18,xp:3,contact:15,col:'#ffc46b',pts:35,grp:'siege',act:2,m:7,desc:'Медленный транспорт. У маяка сбрасывает четыре мотылька каждые 6 секунд. Сбивайте на подлёте.'},
  jammerS:{name:'Малый глушитель',hp:45,spd:90,r:13,xp:3,contact:8,col:'#4dd0ff',pts:40,grp:'sab',act:2,m:7,desc:'Встаёт у края экрана. Пока жив, зарядка маяка идёт на 30% медленнее.'},
  cutter:{name:'Резчик',hp:22,spd:150,r:10,xp:2,contact:8,col:'#5ee0ff',pts:25,grp:'sab',act:2,m:8,desc:'Летит к линии ретранслятора и режет её. Порванную линию чините, пролетая вдоль неё.'},
  tug:{name:'Буксир',hp:40,spd:75,r:14,xp:3,contact:10,col:'#c9a36b',pts:30,grp:'siege',act:2,m:8,desc:'Цепляет астероид тросом и швыряет его в маяк. Трос можно перебить выстрелом.'},
  mortar:{name:'Осадник',hp:35,spd:60,r:14,xp:3,contact:10,col:'#ff8f5a',pts:35,grp:'siege',act:2,m:8,desc:'Бьёт по маяку навесом. Место падения отмечено кругом. Снаряд можно сбить или закрыть собой.'},
  shell:{name:'Навесной снаряд',hp:4,spd:0,r:7,xp:0,contact:0,col:'#ff8f5a',pts:3,passive:true},
  phantom:{name:'Призрак',hp:30,spd:120,r:12,xp:3,contact:12,col:'#a0b4ff',pts:30,grp:'hunt',act:2,m:8,desc:'Периодически становится прозрачным и неуязвимым. Бейте, когда он плотный.'},
  shade:{name:'Тень',hp:28,spd:140,r:11,xp:3,contact:14,col:'#8a7dff',pts:35,grp:'hunt',act:2,m:9,desc:'Невидима вне света. Перед броском выдаёт себя короткой вспышкой.'},
  mirror:{name:'Зеркальщик',hp:70,spd:85,r:16,xp:5,contact:14,col:'#dfe8ff',pts:60,grp:'hunt',act:2,m:9,desc:'Щит спереди отражает ваши снаряды обратно в вас. Уязвим с флангов и сзади, таран его пробивает.'},
  hive:{name:'Матка',hp:120,spd:60,r:22,xp:6,contact:10,col:'#ffcf4d',pts:80,grp:'siege',act:2,m:9,desc:'Неподвижный узел у края. Каждые 4 секунды выпускает двух мотыльков.'},
  shocker:{name:'Шокер',hp:32,spd:95,r:12,xp:3,contact:10,col:'#6bf0ff',pts:35,grp:'hunt',act:2,m:9,desc:'Разряд на 3 секунды отключает ваш рывок. После гибели оставляет такое же поле.'},
  vortex:{name:'Вихрь',hp:60,spd:40,r:16,xp:5,contact:10,col:'#7d6bff',pts:55,grp:'sab',act:2,m:9,desc:'Гравитационная воронка тянет корабль, снаряды, ячейки и врагов. Хорошее место для импульса.'},
  twin:{name:'Близнецы',hp:35,spd:110,r:12,xp:3,contact:12,col:'#ff6bd0',pts:40,grp:'hunt',act:2,m:10,desc:'Пара, связанная лучом. Если убить одного, второй воскресит его через 3 секунды. Добивайте обоих.'},
  thief:{name:'Похититель',hp:30,spd:175,r:10,xp:3,contact:6,col:'#9dff6b',pts:40,grp:'sab',act:2,m:10,desc:'Крадёт ячейку из вашего трюма или с поля и улетает. Догоните — груз выпадет.'},
  hunter:{name:'Охотник',hp:90,spd:160,r:14,xp:6,contact:18,col:'#ff2e4a',pts:90,grp:'hunt',act:2,m:10,desc:'Повторяет ваши рывки с задержкой 0,5 с — туда, куда вы прыгнули. Рывок в сторону и обратно заставит его промахнуться.'},
  commander:{name:'Командир',hp:80,spd:60,r:17,xp:6,contact:12,col:'#ffa63d',pts:80,grp:'siege',act:2,m:10,desc:'Ускоряет врагов рядом с собой на 25%. Без него наступление вязнет.'},
  cruiser:{name:'Осадный крейсер',hp:180,spd:45,r:22,xp:12,contact:25,col:'#ff7a5a',pts:250,grp:'siege',act:2,m:10,desc:'Корабль из частей: два двигателя, орудие и ядро. Двигатели замедляют, орудие бьёт по маяку. Выбирайте, что ломать.'},
  cpart:{name:'Узел крейсера',hp:60,spd:0,r:11,xp:2,contact:0,col:'#ff9a7a',pts:40,grp:'siege'},
  antenna:{name:'Антенна',hp:40,spd:0,r:10,xp:1,contact:0,col:'#4dd0ff',pts:30},
  decoy:{name:'Ложный маяк',hp:150,spd:0,r:26,xp:0,contact:0,col:'#8fe9ff',pts:50},
  crate:{name:'Контейнер',hp:60,spd:0,r:16,xp:0,contact:0,col:'#8fe9ff',pts:50,passive:true},
  lock:{name:'Замок ворот',hp:300,spd:0,r:24,xp:0,contact:0,col:'#b48cff',pts:200},
  jam:{name:'Глушитель',hp:2000,spd:0,r:46,xp:0,contact:22,col:'#4dd0ff',pts:8000,act:2,m:10,desc:'Источник помех. Фаза 1: антенны глушат маяк и закрывают ядро. Фаза 2: ложный маяк уводит автоприцел, цели отмечайте вручную. Фаза 3: тьма, ядро открывается только во вспышки маяка (каждые 16 с на 4,5 с).'}
};
const CODEX_ORDER=['scout','gunner','rammer','splitter','mite','miner','shielder','lancer','guard','pylon','seeker','boss',
  'moth','leech','carrier','jammerS','cutter','tug','mortar','phantom','shade','mirror','hive','shocker','vortex','twin','thief','hunter','commander','cruiser','jam'];
const STATIC=new Set(['pylon','boss','jam','cpart','antenna','decoy','shell','lock','inventor','invcell','invcore','obheart','obseg']);
const HEAVY=new Set(['lock','boss','pylon','jam','antenna','decoy','cruiser','cpart','hive','jammerS','crate','shell','mine','guard','inventor','invcell','invcore','obheart','obseg']);
