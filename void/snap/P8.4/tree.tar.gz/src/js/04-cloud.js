// ===== 1.0.0 α: облачное сохранение — личная папка игрока в базе артефакта (data/users/<id>/save) =====
// Переживает публикацию новых версий и смену устройства. Решение «облако или браузер»: явное действие (новый полёт, сброс, загрузка
// кода) побеждает; иначе побеждает больший прогресс (пройденные миссии); при равенстве — более свежая запись.
var CLOUD_KEYS=['void_world','void_record','void_endless','void_settings','void_echo100','void_serial85'];
var CLOUD={state:'init',ref:null,dirty:false,busy:false,again:false,tm:0,lastAt:0,sig:'',applying:false,pending:null,waiters:[],gateOff:false,err:''};
function metaGet(){try{const v=JSON.parse(LS.getItem('void_meta')||'null');return v&&typeof v==='object'?{t:+v.t||0,force:+v.force||0}:{t:0,force:0};}catch(e){return {t:0,force:0};}}
function metaSet(m){try{LS.setItem('void_meta',JSON.stringify(m),true);}catch(e){}}
function worldDone(raw){try{const S=typeof raw==='string'?JSON.parse(raw):raw;if(!validSave(S))return 0;let n=0;
  for(let m=1;m<=NM;m++)if((m<=CORE&&+S.cleared>=m)||(S.medals&&S.medals[m]&&S.medals[m].clear)||(m===49&&S.story&&S.story.zero49))n++;return n;}catch(e){return 0;}}
LS.onWrite(k=>{if(CLOUD.applying||!CLOUD_KEYS.includes(k))return;const m=metaGet();m.t=Date.now();metaSet(m);cloudDirty();});
function cloudForce(){const m=metaGet();m.force=m.t=Date.now();metaSet(m);cloudDirty(true);}
function cloudBody(){const keys={};for(const k of CLOUD_KEYS)keys[k]=LS.getItem(k);const m=metaGet();return {v:1,t:m.t||Date.now(),force:m.force||0,done:worldDone(keys.void_world),ver:'1.0.0a',keys};}
function cloudSig(b){return JSON.stringify(b.keys)+'|'+b.force;}
function cloudDirty(now){CLOUD.dirty=true;if(CLOUD.state!=='ready')return;clearTimeout(CLOUD.tm);
  CLOUD.tm=setTimeout(cloudPush,now?60:Math.min(12000,Math.max(3000,12000-(Date.now()-CLOUD.lastAt))));}
async function cloudPush(){if(CLOUD.state!=='ready'||!CLOUD.ref)return;if(CLOUD.busy){CLOUD.again=true;return;}if(!CLOUD.dirty)return;
  const b=cloudBody(),sg=cloudSig(b);if(sg===CLOUD.sig){CLOUD.dirty=false;return;}CLOUD.busy=true;CLOUD.dirty=false;
  try{await CLOUD.ref.set(b);CLOUD.sig=sg;CLOUD.lastAt=Date.now();CLOUD.err='';}
  catch(e){const c=e&&e.code;CLOUD.dirty=true;CLOUD.err=c||'unavailable';
    if(['invalid_argument','not_granted','capability_disabled','capability_removed','revoked','transform_error'].includes(c))CLOUD.state='ro';
    else if(c==='quota_exceeded')toast('ОБЛАКО ЗАПОЛНЕНО','Облачная копия не записана: место в хранилище закончилось. Код сохранения в меню по-прежнему работает.');
    else setTimeout(()=>{if(CLOUD.dirty)cloudPush();},2500+Math.random()*2000);}
  finally{CLOUD.busy=false;if(CLOUD.again){CLOUD.again=false;if(CLOUD.dirty)cloudDirty();}}}
function cloudWinner(body){if(!body||!body.keys)return 'local';const lw=LS.getItem('void_world'),ld=worldDone(lw),m=metaGet(),ct=+body.t||0,cf=+body.force||0,cd=+body.done||0;
  if(m.force&&m.force>ct)return 'local';if(cf&&cf>m.t)return 'cloud';if(!lw&&body.keys.void_world)return 'cloud';
  if(cd>ld)return 'cloud';if(ld>cd)return 'local';return ct>m.t?'cloud':'local';}
function cloudApply(body){CLOUD.applying=true;
  try{for(const k of CLOUD_KEYS){if(!(k in body.keys))continue;const v=body.keys[k];try{if(v===null||v===undefined)LS.removeItem(k,true);else LS.setItem(k,String(v),true);}catch(e){}}
    metaSet({t:+body.t||Date.now(),force:0});}finally{CLOUD.applying=false;}
  CLOUD.sig=cloudSig(cloudBody());cloudReloadState();}
function cloudReloadState(){saveSet6(migrateSave(store('void_world')),'load');recReload();
  const v=store('void_settings');if(v&&typeof v==='object'&&!Array.isArray(v)){for(const k in SET_DEF){if(!(k in v))continue;const x=v[k];
    if(SET_OPT[k]?SET_OPT[k].includes(x):(typeof x===typeof SET_DEF[k]&&(typeof x!=='number'||Number.isFinite(x))))SET[k]=x;}try{applySettings();renderSettings();}catch(e){}}
  if(G.state==='menu')renderMenu();}
async function cloudInit(){const done=()=>{if(CLOUD.gateOff)return;CLOUD.gateOff=true;const W_=CLOUD.waiters.splice(0);try{if(G.state==='menu')renderMenu();}catch(e){}
    for(const f of W_){try{f();}catch(e){console.error(e);}}};
  setTimeout(done,LS.getItem('void_world')?6000:15000);
  try{const C=typeof window!=='undefined'?window.claude:null;if(!C||typeof C.use!=='function'){CLOUD.state='off';return done();}
    const [db,user]=await Promise.all([C.use('db'),C.use('user')]);if(!db||!user){CLOUD.state='off';return done();}
    const uid=await user.id();if(!uid){CLOUD.state='off';return done();}
    CLOUD.ref=db.doc('data/users/'+uid+'/save');let snap=null;
    for(let a=0;a<2&&!snap;a++){try{snap=await CLOUD.ref.get();}catch(e){if(a)throw e;await new Promise(r=>setTimeout(r,1500));}}
    const body=snap&&snap.exists?snap.data():null;CLOUD.state='ready';
    if(body&&cloudWinner(body)==='cloud'){if(G.state==='menu'){cloudApply(body);const n=worldDone(LS.getItem('void_world'));toast('ПРОГРЕСС ВОССТАНОВЛЕН',n?'Облачная копия: пройдено миссий '+n+' из '+NM+'.':'Облачная копия загружена.');}else CLOUD.pending=body;}
    else cloudDirty(true);
  }catch(e){CLOUD.state='off';CLOUD.err=(e&&e.code)||'error';}
  done();}
function cloudMenuCheck(){const b=CLOUD.pending;if(!b)return;CLOUD.pending=null;if(cloudWinner(b)==='cloud'){cloudApply(b);toast('ПРОГРЕСС ВОССТАНОВЛЕН','Облачная копия загружена.');}else cloudDirty(true);}
function cloudGate(f){if(CLOUD.gateOff||CLOUD.state!=='init'){f();return;}CLOUD.waiters.length=0;CLOUD.waiters.push(f);toast('СИНХРОНИЗАЦИЯ','Проверяю облачное сохранение…');}
function cloudFlush(){if(CLOUD.state==='ready'&&CLOUD.dirty){clearTimeout(CLOUD.tm);cloudPush();}}
addEventListener('visibilitychange',()=>{if(document.hidden)cloudFlush();});addEventListener('pagehide',cloudFlush);
function saveWhere(){const C=window.CLOUD;if(C&&C.state==='init'&&!C.gateOff)return 'ПРОВЕРКА…';if(C&&C.state==='ready')return 'ОБЛАКО';return LS.ok()&&LS.persisted('void_world')?'БРАУЗЕР':'ВКЛАДКА';}
function saveStatus(){const C=window.CLOUD;if(C&&C.state==='ready')return 'Прогресс сохраняется автоматически.';
  if(LS.ok()&&LS.persisted('void_world'))return 'Прогресс хранится только на этом устройстве — сохраните код.';
  return 'Здесь прогресс не сохраняется. Скопируйте код перед выходом.';}

$('#bSaveShare').onclick=()=>{const t=$('#saveOut').value;if(!t||!navigator.share)return;navigator.share({title:'VØID · код сохранения',text:t}).catch(()=>{});};
$('#bSavePaste').onclick=()=>{try{navigator.clipboard.readText().then(v=>{$('#saveIn').value=v||'';$('#saveMsg').textContent=v?'Код вставлен — нажмите «ЗАГРУЗИТЬ КОД».':'Буфер обмена пуст.';},()=>{$('#saveMsg').textContent='Браузер не дал прочитать буфер — вставьте код вручную.';});}catch(e){$('#saveMsg').textContent='Вставьте код вручную.';}};

// =====================================================================
// ---------- ПРОГРЕССИЯ 0.3 ----------
// сложность · брифинг · пилот · контракты · циклы · обнуление · Бездна · боссы-эхо · заряд · комбо
// =====================================================================
const DIFF={
  easy:{name:'ЛЁГКАЯ',short:'Л',k:1,enemy:1,live:1,xp:1,thr:[25,50,75],rep:1,lom:1,rank:0,k57:1,esc:{every:14,cap:5}},
  mid:{name:'СРЕДНЯЯ',short:'С',k:.75,enemy:1.1,live:1.1,xp:.9,thr:[25,50,75],rep:.8,lom:1.1,rank:1,k57:1.15,esc:{every:12,cap:6}},
  hard:{name:'ХАРДКОР',short:'Х',k:.5,enemy:2.5,live:1.5,xp:.75,thr:[50,75],rep:.5,lom:2,rank:2,dmg:3,spd:1.5,bcDmg:1,bcHp:2,hideTele:true,k57:1.5,esc:{every:9,cap:8}}
};
const DIFF_KEYS=['easy','mid','hard'];
const BRIEF_K=[0,2,4,6,8,10,11,12,13,14];
const roman=n=>['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII','XIII','XIV','XV','XVI','XVII','XVIII','XIX','XX'][n-1]||String(n);
function curDiff(){return(G.mode==='world'||G.mode==='dev')&&DIFF[G.diff]?DIFF[G.diff]:DIFF.easy;}
function cycleN(){if(G.mode==='dev')return G.dev.cycle||1;return G.mode==='world'&&G.save?(G.save.cycle||1):1;}
function cycLom(){return Math.min(2,1+.25*(cycleN()-1));}
function cycHp(){return Math.min(1.5,1+.1*(cycleN()-1));}
function cycCnt(){return Math.min(1.25,1+.05*(cycleN()-1));}
function inMission(){return(G.mode==='world'||G.mode==='dev')&&!G.world;}
// ===== 1.2.0: прибавки по миссиям (умножаются на множители выбранной сложности, не заменяют их) =====
const MISSION_K={
  6: {rate:1.25,hp:1.25,lom:1.25},
  8: {spd:1.25,dmg:1.25,hp:1.25,lom:1.25},
  9: {spd:1.25,dmg:1.25,hp:1.25,lom:1.25},
  10:{spd:1.25,dmg:1.25,hp:1.25,lom:1.25}
};
function missionK(k){if(!inMission())return 1;const t=MISSION_K[G.m];return t&&t[k]||1;}

function enemyMul(){return inMission()?curDiff().enemy*cycCnt():1;}
function liveMul(){return inMission()?curDiff().live*cycCnt():1;}
function briefK(m){if(G.mode!=='world')return 0;const b=m<=CORE?BRIEF_K[m-1]:Math.min(20,14+Math.floor((m-CORE)/5));return Math.floor(b*curDiff().k)+perk('reserve');}
function perkRaw(k){return G.save&&G.save.perks?(G.save.perks[k]||0):0;}
function xpMul(){let m=inMission()?curDiff().xp:1;m*=1+.1*perk('pilot');return m*(G.combo?G.combo.mul:1);}
function scaleWave(arr){const mul=enemyMul();if(mul===1)return arr;const c={};arr.forEach(t=>c[t]=(c[t]||0)+1);const out=[];for(const t in c){const n=String(t).startsWith('e95:')?1:Math.max(1,Math.round(c[t]*mul));for(let i=0;i<n;i++)out.push(t);}return shuffle(out);}

// ---- уровень пилота ----
const pilotNeed=L=>150+60*(L-1);
const SKIN_ORDER=['falcon','manta','prism','reaper','halo','comet','hornet','obsidian','sail','pulsar'];
const skinReq=k=>{const i=SKIN_ORDER.indexOf(k);return i<0?{lvl:0,cost:0}:{lvl:2*(i+1),cost:100+50*i};};
function addPilotXP(v){
  const S=G.save;if(!S||!S.pilot||!(v>0))return;const P=S.pilot;P.xp+=v;
  while(P.xp>=pilotNeed(P.lvl)){P.xp-=pilotNeed(P.lvl);P.lvl++;(G.pilotUps||(G.pilotUps=[])).push({lvl:P.lvl,sk:SKIN_ORDER.find(k=>skinReq(k).lvl===P.lvl)});}
}
function flushPilotUps(){
  const u=G.pilotUps;if(!u||!u.length)return;const last=u[u.length-1],sk=u.map(x=>x.sk).filter(Boolean);
  banner('ПИЛОТ · УРОВЕНЬ '+last.lvl,sk.length?'СКИН «'+SKINS[sk[sk.length-1]].name.toUpperCase()+'» МОЖНО КУПИТЬ В ХРАНИЛИЩЕ':'УРОВЕНЬ ПОВЫШЕН');sfx('level');G.pilotUps=[];
}

// ---- контракты ----
const CTPL=[
  {id:'k_scout',s:'Разведчики',t:n=>`Уничтожить ${n} разведчиков`,ev:'kill',type:'scout',n:[30,50]},
  {id:'k_gunner',s:'Стрелки',t:n=>`Уничтожить ${n} стрелков`,ev:'kill',type:'gunner',n:[15,25],req:2},
  {id:'k_rammer',s:'Тараны',t:n=>`Уничтожить ${n} таранов`,ev:'kill',type:'rammer',n:[10,16],req:3},
  {id:'k_splitter',s:'Роевики',t:n=>`Уничтожить ${n} роевиков`,ev:'kill',type:'splitter',n:[10,16],req:3},
  {id:'k_shielder',s:'Щитоносцы',t:n=>`Уничтожить ${n} щитоносцев`,ev:'kill',type:'shielder',n:[6,10],req:4},
  {id:'k_miner',s:'Минёры',t:n=>`Уничтожить ${n} минёров`,ev:'kill',type:'miner',n:[8,12],req:4},
  {id:'k_lancer',s:'Копейщики',t:n=>`Уничтожить ${n} копейщиков`,ev:'kill',type:'lancer',n:[8,12],req:5},
  {id:'k_guard',s:'Гвардия',t:n=>`Уничтожить ${n} гвардейцев`,ev:'kill',type:'guard',n:[3,5],req:6},
  {id:'k_moth',s:'Мотыльки',t:n=>`Уничтожить ${n} мотыльков`,ev:'kill',type:'moth',n:[60,100],req:7},
  {id:'k_leech',s:'Пиявки',t:n=>`Уничтожить ${n} пиявок`,ev:'kill',type:'leech',n:[12,20],req:7},
  {id:'k_mirror',s:'Зеркальщики',t:n=>`Уничтожить ${n} зеркальщиков`,ev:'kill',type:'mirror',n:[4,8],req:9},
  {id:'k_hunter',s:'Охотники',t:n=>`Уничтожить ${n} охотников`,ev:'kill',type:'hunter',n:[3,5],req:10},
  {id:'c_mid',s:'Средняя+',t:()=>'Пройти миссию на средней сложности или выше',ev:'clear',min:1,n:[1,1],req:1},
  {id:'c_hard',s:'Хардкор',t:()=>'Пройти миссию на хардкоре',ev:'clear',min:2,n:[1,1],req:2},
  {id:'c_nopulse',s:'Без импульса',t:()=>'Пройти миссию, ни разу не применив импульс',ev:'clearNoPulse',n:[1,1],req:3},
  {id:'c_nodash',s:'Без рывка',t:()=>'Пройти миссию без единого рывка',ev:'clearNoDash',n:[1,1],req:1},
  {id:'c_bc',s:'Маяк 90%',t:()=>'Пройти миссию с маяком, сохранив 90% целостности',ev:'clearBc90',n:[1,1],req:7},
  {id:'medal',s:'Медали',t:n=>`Получить ${n} медали`,ev:'medal',n:[2,3],req:1},
  {id:'charged',s:'Заряд',t:n=>`Уничтожить ${n} врагов заряженным выстрелом`,ev:'chargedKill',n:[8,15],req:2},
  {id:'combo',s:'Комбо ×1,75',t:()=>'Достичь комбо ×1,75',ev:'combo',n:[1,1],perk:['combo',2]},
  {id:'cells',s:'Ячейки',t:n=>`Подобрать ${n} энергоячеек в миссиях`,ev:'cell',n:[10,18],req:2},
  {id:'patrol',s:'Патрули',t:n=>`Разбить ${n} патруля`,ev:'patrol',n:[2,3],req:1},
  {id:'anom',s:'Аномалия',t:()=>'Пройти аномалию',ev:'anom',n:[1,1],anomLeft:true},
  {id:'c_frost',s:'III · Оттепель',t:n=>`Уничтожить ${n} Изморозей`,ev:'kill',type:'frost',n:[12,20],after:11,sec:2},
  {id:'c_rec',s:'III · Каталогизатор',t:n=>`Найти ${n} дрейфующих записи Архива`,ev:'arcRec',n:[2,3],after:11,sec:2,alive:()=>w58S().arcRec.length<4},
  {id:'c_slide',s:'III · Коньки',t:n=>`Прокатиться ${n*100} единиц по ледяным шельфам`,ev:'shelf',n:[40,60],after:11,sec:2},
  {id:'c_wander',s:'III · Стёртый наблюдатель',t:()=>'Уничтожить Странствующего Архиватора',ev:'wander',n:[1,1],after:12,sec:2},
  {id:'c_beacon',s:'III · Радиотишина',t:n=>`Снести ${n} ${n===1?'маяк':'маяка'} Архива`,ev:'arcBeacon',n:[1,2],after:11,sec:2,alive:()=>w58S().arcBeacons.length<2},
  {id:'c_rustbox',s:'IV · Утильсырьё',t:n=>`Вскрыть ${n} ${n===1?'контейнер':'контейнера'} в ржавых полях`,ev:'rustBox',n:[1,2],after:15,sec:3,alive:()=>w58S().rustBox.length<2},
  {id:'c_clean4',s:'IV · Заводская краска',t:()=>'Пройти миссию сектора IV с износом не более 5%',ev:'clearLowWear',n:[1,1],after:15,sec:3},
  {id:'c_storm',s:'III–IV · Охотник за бурями',t:()=>'Забрать груз из центра бури',ev:'stormBox',n:[1,1],after:11,sec:2},
  {id:'c_patrol34',s:'III–IV · Выездная бригада',t:n=>`Разбить ${n} патруля секторов III–IV, убив вожака первым`,ev:'patrolLeader',n:[2,2],after:11,sec:3},
  {id:'c_convoy80',s:'VII · Списание отменено',t:()=>'Разбить контейнер конвоя «Утилизация»',ev:'convoyBreak',n:[1,1],after:28,sec:6},
  {id:'c_rescue80',s:'VII · Без номера',t:n=>`Спасти ${n} ${n===1?'копию':'копии'} с переплавки`,ev:'rescue80',n:[1,2],after:28,sec:6},
  {id:'c_audit80',s:'VII · Вне ревизии',t:()=>'Пройти мимо Ревизии незамеченным и разбить её',ev:'auditStealth',n:[1,1],after:28,sec:6},
  {id:'c_recycler80',s:'VII · Вторсырьё',t:n=>`Уничтожить ${n} Утилизатора с полным бункером (от 8)`,ev:'recyclerFull',n:[2,3],after:30,sec:6},
  {id:'c_stamp80',s:'VII · Без подписи',t:n=>`Сбросить ${n} штампов Печати`,ev:'stampOff',n:[3,5],after:29,sec:6},
  {id:'c_alarm80',s:'VII · Всем постам',t:n=>`Уничтожить ${n} врагов у пульта во время тревоги`,ev:'alarmKill',n:[8,12],after:28,sec:6,alive:()=>{const w=w80S();return w.alarmAt.some(a=>a-(w.clk||0)<600);}},
  {id:'c_range80',s:'VII · Выше нормы',t:()=>`Набрать на стенде ${rangeGoal80()} урона в секунду`,ev:'rangeDps',n:[1,1],after:28,sec:6},
  {id:'c_dark80',s:'VII–VIII · Без света',t:n=>`Уничтожить ${n} врагов в темноте`,ev:'darkKill',n:[10,15],after:28,sec:6},
  {id:'c_pilgrims80',s:'VIII · Попутчики',t:()=>'Проводить Паломников, не задев ни одного',ev:'pilgrimsSafe',n:[1,1],after:32,sec:7},
  {id:'c_loop80',s:'VIII · Конец петли',t:n=>`Разорвать ${n} Петель с первого возвращения`,ev:'loopBreak',n:[3,5],after:33,sec:7},
  {id:'c_echo80',s:'VIII · Тишина в ответ',t:n=>`Уничтожить ${n} ${n===1?'Отзвука':'Отзвуков'}, не получив своих же снарядов`,ev:'echoClean',n:[1,2],after:32,sec:7},
  {id:'c_inverse80',s:'VIII · Лицевая сторона',t:()=>'Уничтожить Изнанку до её первой волны',ev:'inverseFast',n:[1,1],after:34,sec:7}
];
const conT=c=>CTPL.find(t=>t.id===c.tid);
function conEligible(T){const S=G.save;if(T.after&&!(S.cleared>=CORE&&S.gate&&S.medals[T.after]&&S.medals[T.after].clear))return false;if(T.alive&&!T.alive())return false;if(T.req&&S.cleared<T.req&&(S.cycle||1)===1)return false;if(T.perk&&perkRaw(T.perk[0])<T.perk[1])return false;
  if(T.anomLeft&&WORLD.anomalies.every(a=>S.anomalies[a.id]))return false;return !S.contracts.list.some(c=>c.tid===T.id);}
function newContract(){const S=G.save,C=S.contracts;const el=CTPL.filter(conEligible);const hot=S.medals[11]&&S.medals[11].clear&&!(S.medals[18]&&S.medals[18].clear);const pool=[];for(const T of el){const w=T.sec&&hot?4:1;for(let i=0;i<w;i++)pool.push(T);}if(!pool.length)return null;const T=pool[Math.random()*pool.length|0];
  const n=T.n[0]+Math.floor(Math.random()*(T.n[1]-T.n[0]+1)),mul=(1+Math.min(1,.1*C.done))*(T.sec>=6?3:T.sec===3?2:T.sec===2?1.5:1);return{tid:T.id,n,p:0,lom:Math.round(40*mul),px:Math.round(60*mul)};}
function fillContracts(){const S=G.save;if(!S||(S.cleared<2&&(S.cycle||1)===1))return;const C=S.contracts;C.list=C.list.filter(c=>conT(c)&&!(conT(c).alive&&!conT(c).alive()));while(C.list.length<3){const c=newContract();if(!c)break;C.list.push(c);}}
function conEvent(ev,data){
  const S=G.save;if(!S||G.mode!=='world'||!S.contracts)return;const C=S.contracts;let changed=false;
  for(const c of C.list){const T=conT(c);if(!T||T.ev!==ev||c.p>=c.n)continue;
    if(ev==='kill'&&data!==T.type)continue;if(ev==='clear'&&(data||0)<T.min)continue;c.p++;changed=true;}
  if(!changed)return;
  const done=C.list.filter(c=>c.p>=c.n);
  for(const c of done){S.lom+=c.lom;addPilotXP(c.px);C.done++;banner('КОНТРАКТ ВЫПОЛНЕН','+'+c.lom+' ЛОМА · +'+c.px+' ОПЫТА ПИЛОТА');sfx('level');}
  if(done.length){C.list=C.list.filter(c=>c.p<c.n);store(saveKey(),S);}
}

// ---- новый цикл и обнуление ----
function newCycle(){
  const S=G.save;if(!S||S.cleared<CORE)return;S.lom+=S.carry||0;S.carry=0;
  if(S.w58){S.w58.iceRocks=[];S.w58.arcRec=[];S.w58.rustBox=[];S.w58.arcBeacons=[];S.w58.wander={};S.w58.conveyor={};S.w58.packs={};}if(S.story){delete S.story.invDig;}WORLD.caches=WORLD.caches.filter(c=>!c.civ);
  storyNewCycle(S);Object.assign(S,{jOrder:[],cycle:(S.cycle||1)+1,cleared:0,gate:false,locksDown:[],medals:{},found:{},journals:{},anomalies:{},relays:{},replays:{},best:{},bestDiff:{},reveal:'',lost:null,zonesDone:{}});
  const n=WORLD.nodes[0];S.pos={x:n.x-260,y:n.y+90};S.last={...S.pos};store(saveKey(),S);
  fillContracts.call(null);startWorld(false);banner('ЦИКЛ '+roman(S.cycle),'ВРАГИ СИЛЬНЕЕ · НАГРАДЫ ×'+cycLom().toFixed(2).replace('.',','));
}
let resetT=0,resetTm=0;
function fullReset(alsoEndless){
  try{LS.removeItem('void_world');LS.removeItem('void_record');if(alsoEndless)LS.removeItem('void_endless');}catch(e){}
  cloudForce();saveSet6(null,'reset');REC.best=0;REC.maxMission=0;REC.seen=['scout'];resetT=0;renderMenu();renderSettings();banner('ПРОГРЕСС ОБНУЛЁН','ВСЁ НАЧИНАЕТСЯ ЗАНОВО');sfx('warn');
}
function resetBlock(){const arm=resetT&&performance.now()-resetT<5000;
  return cloudBestHTML()+`<div class="reset"><button class="rbtn" id="bReset">${arm?'ОТМЕНА':'СБРОСИТЬ ПРОГРЕСС'}</button>
    ${arm?`<p class="rwarn">Сотрётся весь полёт: миссии, пилот, перки, скины и лом.</p><button class="rbtn go" id="bResetGo">СТЕРЕТЬ</button>
    <label class="rchk"><input type="checkbox" id="rsEnd"> Также стереть рекорды Бесконечности</label>`:''}
    <p class="rnote">Звук, эффекты и настройки разработки не сбрасываются. Перед обнулением можно сохранить «Код сохранения».</p></div>`;}
document.addEventListener('click',e=>{
  if(e.target.closest('#bResetGo')){if(resetT&&performance.now()-resetT<5000){const ch=$('#rsEnd');fullReset(!!(ch&&ch.checked));}return;}
  if(!e.target.closest('#bReset'))return;
  if(resetT&&performance.now()-resetT<5000){resetT=0;renderSettings();return;}
  resetT=performance.now();renderSettings();clearTimeout(resetTm);resetTm=setTimeout(()=>{resetT=0;if(G.state==='menu')renderSettings();},5000);
});

// ---- миграция сохранений ----
// 0.5.10: схема сохранения — приведение типов и очистка строк (код сохранения приходит от чужих людей)
function sanitizeSave(S){
  const num=(v,d,lo,hi,int)=>{v=+v;if(!Number.isFinite(v))v=d;if(lo!==undefined&&v<lo)v=lo;if(hi!==undefined&&v>hi)v=hi;return int?Math.round(v):v;};
  const obj=v=>v&&typeof v==='object'&&!Array.isArray(v)?v:{};
  const arr=v=>Array.isArray(v)?v:[];
  const strip=v=>{if(typeof v==='string')return v.replace(/[<>]/g,'').slice(0,FGW*FGH+64);if(Array.isArray(v))return v.map(strip);if(v&&typeof v==='object'){const o={};for(const k of Object.keys(v)){if(k==='__proto__'||k==='constructor'||k==='prototype')continue;o[k]=strip(v[k]);}return o;}return v;};
  S=strip(S);
  S.lom=num(S.lom,0,0,1e12);S.carry=num(S.carry,0,0,1e12);S.cleared=num(S.cleared,0,0,CORE,true);S.cycle=num(S.cycle,1,1,999,true);
  S.pilot=obj(S.pilot);S.pilot.lvl=num(S.pilot.lvl,1,1,999,true);S.pilot.xp=num(S.pilot.xp,0,0,1e9);
  S.run=obj(S.run);S.run.mods=obj(S.run.mods);S.run.hp=num(S.run.hp,100,1,1e6);S.run.en=num(S.run.en,0,0,100);S.run.lvl=num(S.run.lvl,1,1,999,true);S.run.xp=num(S.run.xp,0,0,1e9);S.run.need=num(S.run.need,10,1,1e9);S.run.score=num(S.run.score,0,0,1e12);S.run.kills=num(S.run.kills,0,0,1e9,true);S.run.taken=num(S.run.taken,0,0,1e9);
  for(const k of ['pos','last']){S[k]=obj(S[k]);S[k].x=num(S[k].x,0,0,WW);S[k].y=num(S[k].y,0,0,WH);}
  if(S.lost){S.lost=obj(S.lost);S.lost.x=num(S.lost.x,0,0,WW);S.lost.y=num(S.lost.y,0,0,WH);S.lost.v=num(S.lost.v,0,0,1e12);if(!S.lost.v)S.lost=null;}
  S.contracts=obj(S.contracts);S.contracts.done=num(S.contracts.done,0,0,1e6,true);S.contracts.list=arr(S.contracts.list).filter(c=>c&&typeof c==='object'&&typeof c.tid==='string'&&CTPL.some(t=>t.id===c.tid)).slice(0,20).map(c=>({tid:c.tid,p:num(c.p,0,0,1e6,true),n:num(c.n,1,1,1e6,true),lom:num(c.lom,0,0,1e6,true),px:num(c.px,0,0,1e6,true)}));
  const m={};for(const k of Object.keys(obj(S.medals))){const i=+k;if(!(i>=1&&i<=NM))continue;const v=obj(S.medals[k]),o={};for(const f of ['clear','clean','master'])if(v[f])o[f]=1;m[i]=o;}S.medals=m;
  const pk={};for(const k of Object.keys(obj(S.perks)))if(PERKS[k])pk[k]=num(S.perks[k],0,0,PERKS[k].max,true);S.perks=pk;
  {const A=obj(S.ars),lv=obj(A.lv),g=obj(lv.gun),bl=obj(lv.blast);S.ars={weapon:A.weapon==='blast'?'blast':'gun',own:{gun:1,blast:obj(A.own).blast?1:0},lv:{gun:{pow:num(g.pow,0,0,3,true),rate:num(g.rate,0,0,3,true)},blast:{pow:num(bl.pow,0,0,3,true),rad:num(bl.rad,0,0,3,true)}}};if(!S.ars.own.blast)S.ars.weapon='gun';
   const tr={};for(const k of Object.keys(obj(S.trophy))){const i=+k;if(BOSS_TROPHY[i]&&S.trophy[k])tr[i]=1;}S.trophy=tr;}
  S.ownSkins=arr(S.ownSkins).filter(k=>SKINS[k]);S.skins=arr(S.skins).filter(k=>SKINS[k]);if(!SKINS[S.skin])S.skin='base';if(!DIFF[S.diff])S.diff='easy';
  for(const k of ['journals','found','anomalies','relays','zonesDone','replays','best','bestDiff'])S[k]=obj(S[k]);
  S.jOrder=arr(S.jOrder).filter(x=>typeof x==='string');S.rocksGone=arr(S.rocksGone).filter(x=>typeof x==='number'||typeof x==='string').slice(0,5000);S.locksDown=arr(S.locksDown).filter(x=>typeof x==='number');
  if(typeof S.reveal!=='string'||S.reveal.length>FGW*FGH)S.reveal='';S.gate=!!S.gate;S.speedBoost=S.speedBoost?1:0;S.intro=!!S.intro;
  if(S.story!==undefined){S.story=obj(S.story);const st=S.story;if(st.inv14!==undefined&&!['memory','cold'].includes(st.inv14))delete st.inv14;if(st.obod18!==undefined&&!['scrap','service'].includes(st.obod18))delete st.obod18;if(st.cradle22!==undefined&&!['cut','keep'].includes(st.cradle22))delete st.cradle22;if(st.fleet27!==undefined&&!['bridge','engine'].includes(st.fleet27))delete st.fleet27;if(st.save33!==undefined&&!['dead','unborn'].includes(st.save33))delete st.save33;if(st.teo!==undefined&&![1,-1].includes(st.teo))delete st.teo;if(st.echo127!==undefined&&st.echo127!=='guard')delete st.echo127;if(st.lastKind!==undefined)st.lastKind=num(st.lastKind,0,0,1e4,true);if(st.pilgrimsKilled!==undefined)st.pilgrimsKilled=num(st.pilgrimsKilled,0,0,1e6,true);st.history=arr(st.history).filter(r=>r&&typeof r==='object').slice(0,50);if(st.invDig!==undefined)st.invDig=num(st.invDig,0,0,4,true);}
  if(S.w80!==undefined){const w=S.w80=obj(S.w80);w.clk=num(w.clk,0,0,1e9);w.alarmAt=arr(w.alarmAt).slice(0,3).map(v=>num(v,0,0,1e9));while(w.alarmAt.length<3)w.alarmAt.push(0);w.rangeBest=num(w.rangeBest,0,0,1e6,true);if(w.rangeGoal!==undefined)w.rangeGoal=num(w.rangeGoal,60,0,1e6,true);w.seen=obj(w.seen);w.zd=obj(w.zd);w.voices=num(w.voices,0,0,12,true);if(w.karr!==undefined)w.karr=1;}
  if(S.story){const st=S.story;if(st.line31!==undefined&&!['break','write'].includes(st.line31))delete st.line31;if(st.well38!==undefined&&!['silence','answer','third'].includes(st.well38))delete st.well38;if(st.woke!==undefined)st.woke=num(st.woke,0,0,1e6,true);if(st.third85!==undefined&&st.third85!==1)delete st.third85;}
  sanitize90(S,num,obj);
  if(S.w85!==undefined){const w=S.w85=obj(S.w85);w.apprAt=num(w.apprAt,0,0,1e9);}
  if(S.w74!==undefined){const w=S.w74=obj(S.w74);w.pois=obj(w.pois);w.zd=obj(w.zd);w.glyph=num(w.glyph,0,0,5,true);if(w.save33!==undefined&&!['dead','unborn'].includes(w.save33))delete w.save33;}
  if(S.w58!==undefined){const w=S.w58=obj(S.w58);for(const k of ['iceRocks','arcRec','rustBox','arcBeacons'])w[k]=arr(w[k]).filter(x=>typeof x==='number'||typeof x==='string').slice(0,500);w.tugs=obj(w.tugs);w.tugs.esc=num(w.tugs.esc,0,0,1e6,true);w.tugs.rob=num(w.tugs.rob,0,0,1e6,true);w.wander=obj(w.wander);w.conveyor=obj(w.conveyor);w.packs=obj(w.packs);}
  return S;}
function migrateSave(S){
  if(!validSave(S))return null;S=sanitizeSave(S);
  if(S.v===1){
    const lv=Object.values(S.run.mods||{}).reduce((a,b)=>a+b,0),comp=Math.min(300,15*lv);S.lom=(S.lom||0)+comp;
    let px=0;for(let m=1;m<=S.cleared;m++)px+=40+8*m;for(const k in S.medals)px+=25*medalCount(S.medals[k]);
    S.pilot={lvl:1,xp:0};while(px>=pilotNeed(S.pilot.lvl)){px-=pilotNeed(S.pilot.lvl);S.pilot.lvl++;}S.pilot.xp=px;
    S.ownSkins=['base'];if(S.skin&&S.skin!=='base'&&SKINS[S.skin])S.ownSkins.push(S.skin);
    S.v=2;S.migrated=comp;
  }
  S.run.mods={};S.run.lvl=1;S.run.xp=0;
  S.pilot=S.pilot||{lvl:1,xp:0};S.ownSkins=S.ownSkins||['base'];if(!S.ownSkins.includes('base'))S.ownSkins.unshift('base');
  if(!S.wv){for(const k of ['pos','last','lost'])if(S[k]&&typeof S[k].y==='number')S[k].y=Math.min(WH,S[k].y+OY);
    if(S.reveal){const o=S.reveal,FW0=Math.ceil(WW0/FOG),FH0=Math.ceil(WH0/FOG),a=new Array(FGW*FGH).fill('0');for(let j=0;j<FH0;j++)for(let i=0;i<FW0;i++)if(o[j*FW0+i]==='1')a[(j+OY/FOG)*FGW+i]='1';S.reveal=a.join('');}
    S.wv=2;}
  if(!S.speedBoost&&(S.cleared>=CORE||(S.cycle||1)>1))S.speedBoost=1;
  S.contracts=S.contracts||{list:[],done:0};if(!Array.isArray(S.jOrder))S.jOrder=WORLD.journals.filter(j=>S.journals&&S.journals[j.id]).map(j=>j.id);S.cycle=S.cycle||1;S.rocksGone=S.rocksGone||[];S.zonesDone=S.zonesDone||{};S.bestDiff=S.bestDiff||{};
  S.diff=DIFF[S.diff]?S.diff:'easy';if(!SKINS[S.skin]||!S.ownSkins.includes(S.skin))S.skin='base';
  {const D=newSave();for(const k in D)if(S[k]===undefined)S[k]=D[k];for(const k of ['lom','carry']){const v=+S[k];S[k]=Number.isFinite(v)&&v>0?v:0;}}
  storyInit(S);
  return S;
}

// ---- Бездна ----
function enterAbyss(){
  const S=G.save,a=WORLD.abyss;if(S.carry>0){S.lom+=S.carry;S.carry=0;}
  S.pos={x:a.x,y:a.y+620};S.last={...S.pos};G.world=false;saveWorld();/* 0.5.9: saveWorld больше не перезаписывает точку возврата позицией корабля у дыры */
  G.fromAbyss=true;G.world=false;$('#wcard').hidden=true;G.card=null;startEndless(false,1);banner('БЕЗДНА','В СЕКТОР НИЧЕГО НЕ ПЕРЕНОСИТСЯ');
}
function leaveAbyss(){G.fromAbyss=false;startWorld(false);G.abyssImm=3;banner('ВЫХОД ИЗ БЕЗДНЫ','СЕКТОР В ТОМ ЖЕ СОСТОЯНИИ');}
function drawAbyss(t){
  const a=WORLD.abyss,S=G.save;if(!inView(a.x,a.y,320))return;
  ctx.save();ctx.translate(a.x,a.y);
  glow(0,0,260,'#7c5cff',.35);glow(0,0,160,'#ff6b3d',.18);
  ctx.save();ctx.rotate(-.32);
  for(let i=6;i>=0;i--){const rx=78+i*24,ry=(78+i*24)*.32;ctx.strokeStyle=i%2?'#ffb84d':'#b48cff';ctx.globalAlpha=.16+.07*(6-i);ctx.lineWidth=5-i*.5;
    ctx.setLineDash([18+i*6,10+i*4]);ctx.lineDashOffset=-t*(120-i*12);ctx.beginPath();ctx.ellipse(0,0,rx,ry,0,0,TAU);ctx.stroke();}
  ctx.setLineDash([]);ctx.restore();
  ctx.globalAlpha=1;
  for(let i=0;i<40;i++){const k=((t*.35+i/40)%1),ang=i*2.39+t*1.6*(1-k),r=260*(1-k)+20;ctx.fillStyle=i%3?'#c9a6ff':'#ffd0a0';ctx.globalAlpha=k;ctx.fillRect(Math.cos(ang)*r,Math.sin(ang)*r*.55,2,2);}
  ctx.globalAlpha=1;const g=ctx.createRadialGradient(0,0,10,0,0,70);g.addColorStop(0,'#000000');g.addColorStop(.8,'#000000');g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,70,0,TAU);ctx.fill();
  ctx.strokeStyle='#b48cff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(0,0,58,0,TAU);ctx.stroke();
  ctx.restore();
  const eb=bestEndless();if(abyssOpen()&&G.player&&Math.hypot(G.player.x-a.x,G.player.y-a.y)<900){ctx.strokeStyle='#b48cff';ctx.globalAlpha=G.abyssPull?.4:.25;ctx.lineWidth=1.5;ctx.setLineDash([8,10]);ctx.beginPath();ctx.arc(a.x,a.y,520,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
  worldLabel(a.x,a.y-120,'∞ БЕЗДНА · БЕСКОНЕЧНОСТЬ',abyssOpen()?'#c9a6ff':'#5a4a7c');
  if(eb)worldLabel(a.x,a.y-104,'ЛУЧШЕЕ ВРЕМЯ '+fmtT(eb.t),'#7a8ea5');
}

// ---- боссы-эхо в Бесконечности ----
function spawnEchoBoss(){
  const E=G.end,n=E.bossN++,mul=1+.25*n;
  if(n%2===0){spawnBoss();const b=G.boss;b.hp=b.maxHp=EDEF.boss.hp*mul;b.th=[b.maxHp*2/3,b.maxHp/3,0];banner('ЭХО СТРАЖА',(G.fromAbyss&&storyEchoLine())||'ТРИ ФАЗЫ · СНИМИТЕ ЗАРЯДЫ');}
  else{spawnJam();const j=G.jam;j.hp=j.maxHp=EDEF.jam.hp*mul;j.th=[j.maxHp*2/3,j.maxHp/3,0];banner('ЭХО ГЛУШИТЕЛЯ','АНТЕННЫ · ЛОЖНАЯ ЦЕЛЬ · ТЬМА');}
  E.bossOn=true;sfx('warn');
}
function endlessBossAlive(){return !!((G.boss&&G.boss.alive)||(G.jam&&G.jam.alive));}
function updateEndlessBoss(){
  const E=G.end,alive=endlessBossAlive();
  if(!alive&&E.bossOn){E.bossOn=false;E.bosses++;G.dark=false;banner('ЭХО ПОВЕРЖЕНО','+3 РЕМКОМПЛЕКТА');
    for(let i=0;i<3;i++)G.pick.push({k:'rep',x:W/2+rnd(-140,140),y:H/2+rnd(-90,90),vx:0,vy:0,r:10,t:0,life:30});}
  if(!alive&&!E.bossOn&&E.t>=E.nextBoss){E.nextBoss+=300;spawnEchoBoss();}
}

// ---- комбо (перк «Боевой ритм») ----
function comboOn(){return(G.mode==='endless'||(G.mode==='world'&&!G.world))&&perkRaw('combo')>0;}
function comboCap(){return[1,1.5,1.75,2][perkRaw('combo')]||1;}
function comboKill(){
  if(!comboOn())return;const C=G.combo||(G.combo={n:0,mul:1,last:-9,hit:false});
  if(G.t-C.last>2.5){C.n=0;C.hit=false;}C.n++;C.last=G.t;C.mul=Math.min(comboCap(),1+.05*(C.n-1));
  if(C.mul>=1.75&&!C.hit){C.hit=true;conEvent('combo',C.mul);}
}
function comboTick(){const C=G.combo;if(C&&C.n>0&&G.t-C.last>2.5){C.n=0;C.mul=1;}}
function comboBreak(){const C=G.combo;if(C&&C.n>0){C.n=0;C.mul=1;}}

// ---- заряженный выстрел ----
const CHG_T=1.2,CHG_CD=3;
function chargeAllowed(){if(G.state==='world')return !!G.save&&G.save.cleared>=1;if(G.state!=='play')return false;return G.mode==='endless'||G.m>=2;}
function fireCharged(p){
  const tg=aimManual()?null:pickTarget();const a=tg?Math.atan2(tg.y-p.y,tg.x-p.x):p.ang;const sx=p.x+Math.cos(a)*18,sy=p.y+Math.sin(a)*18;
  if(G.st.weapon==='blast')G.pb.push({x:sx,y:sy,px:sx,py:sy,vx:Math.cos(a)*900,vy:Math.sin(a)*900,dmg:G.st.dmg*6,pierce:0,rico:0,life:.9,hit:[],charged:true,blast:true,R:G.st.blastR,age:0});
  else G.pb.push({x:sx,y:sy,px:sx,py:sy,vx:Math.cos(a)*1300,vy:Math.sin(a)*1300,dmg:G.st.dmg*6,pierce:99,rico:0,life:.9,hit:[],charged:true});
  p.chgCd=CHG_CD;sfx('charged');shake(5);buzz('chg');
  if(SET.fx)for(let i=0;i<14;i++)part(sx,sy,Math.cos(a)*rnd(100,400)+rnd(-80,80),Math.sin(a)*rnd(100,400)+rnd(-80,80),.35,'#ffffff',2.5);
}
function regenTick(dt){const l=perk('regen'),p=G.player;if(!l||!p||p.hp<=0||p.hp>=G.st.maxHp||noHeal())return;if(G.t-(p.hitT??-99)>3)p.hp=Math.min(G.st.maxHp,p.hp+.5*l*dt);}
function chargeChip(){
  const p=G.player;const show=!!p&&(G.world?!!G.save&&G.save.cleared>=1:(G.mode==='endless'||G.m>=2));setH('chgC',!show);setH('tCharge',!show);if(!show)return;
  const rd=p.chgCd<=0&&!(p.chg>0);setT('chgC',rd?'ЗАРЯД [Q]':'ЗАРЯД');setF('chgC',p.chgCd>0?1-p.chgCd/CHG_CD:p.chg>0?Math.min(1,p.chg/CHG_T):0);
  setC('chgC','ok',rd||p.chg>=CHG_T);setC('tCharge','cd',p.chgCd>0);
  setH('aimC',true);
  const C=G.combo;const on=comboOn()&&C&&C.n>1;setH('comboC',!on);if(on)setT('comboC','КОМБО '+C.n);
}

function rewMul(){return curDiff().lom*cycLom();}
function addPilotXPTo(S,v){saveSet6(S,'temp');addPilotXP(v);}

// =====================================================================
// ---------- ЭМБИЕНТ (0.3.4) ----------
// адаптивные звуковые пейзажи: протяжные пэды без терций, саб-дрон, шум, редкие отзвуки;
// в бою — мягкий пульс и томы, на боссе — медь и двойной пульс; тревога поверх; равномощный кроссфейд
// =====================================================================
const AMB_CFG={fadeCalm:4,fadeFight:2,fadeOut:6,alarmOn:.3,alarmOff:.35,alarmHold:1.5,maxVoices:40};
// аккорды-«поля» (полутоны от тоники), без терций либо с терцией глубоко внутри
const V={
  dor:[[0,7,14,17],[-2,5,12,14],[5,12,17,19],[-5,2,7,14]],
  mix:[[0,7,14,17],[-2,5,14,17],[5,12,19,21],[0,7,10,14]],
  lyd:[[0,7,14,18],[2,9,14,21],[-5,2,7,14],[0,7,11,18]],
  phr:[[0,7,12,19],[1,8,13,20],[0,7,12,17],[-2,5,12,17]],
  calm:[[0,7,14,19],[5,12,19,21],[-2,5,14,17],[0,7,12,21]]
};
const SC_={
  menu:  {name:'Последний сигнал',root:38,v:V.calm,chordT:[12,18],pad:['triangle',380,850,.05],sub:.09,noise:['lowpass',480,.016,.05],bell:['shine',9,16,.026],ping:1,rev:.45,vol:.62},
  belt:  {name:'Пояс Стража',root:40,v:V.dor,chordT:[10,16],pad:['sawtooth',420,1050,.03],sub:.085,noise:['bandpass',800,.012,.08],bell:['shine',10,18,.022],rev:.35,alert:1,vol:.7},
  drift: {name:'Дрейф маяка',root:45,v:V.lyd,chordT:[10,16],pad:['triangle',650,1500,.045],sub:.07,noise:['bandpass',1200,.01,.06],bell:['glass',7,12,.024],rev:.55,alert:1,vol:.68},
  shop:  {name:'Мастерская',root:41,v:[[0,7,12,14],[5,12,14,19],[-2,5,10,14]],chordT:[12,20],pad:['triangle',330,680,.045],sub:.06,noise:['lowpass',400,.007,.04],bell:['metal',6,11,.02],rev:.42,vol:.72},
  hangar:{name:'Хранилище корпусов',root:46,v:[[0,7,14,19],[2,9,14,21],[5,12,19,21]],chordT:[12,18],pad:['triangle',560,1150,.04],sub:.05,noise:['lowpass',600,.006,.05],bell:['glass',5,9,.022],chorus:1,rev:.5,vol:.75},
  cycle: {name:'Новый цикл',root:38,v:[[0,7,12,19]],chordT:[30,30],pad:['triangle',400,700,.05],sub:.09,noise:['lowpass',400,.01,.03],bell:['shine',8,12,.03],rev:.6,vol:.6},
  abyss: {name:'Бездна',root:33,v:[[0,7,12,19],[1,8,13,20],[0,7,12,17]],chordT:[10,14],pad:['sawtooth',230,620,.035],sub:.13,noise:['lowpass',300,.025,.03],bell:['shine',12,20,.015],rev:.5,fight:1,bpm:94,pulse:'q',toms:'fight',vol:1},
  warden:{name:'Страж',root:38,v:V.phr,chordT:[8,10],pad:['sawtooth',300,900,.03],sub:.13,tri:1,noise:['lowpass',420,.02,.2],rev:.35,fight:1,boss:1,bpm:112,pulse:'double',toms:'boss',brass:.07,vol:.85},
  jam:   {name:'Глушитель',root:40,v:V.phr,chordT:[8,10],pad:['sawtooth',320,950,.028],sub:.12,tri:1,noise:['bandpass',1500,.025,1.3],rev:.4,fight:1,boss:1,bpm:118,pulse:'double',toms:'boss',brass:.05,crackle:1,vol:.85}
};
[['m1','Первый контакт',38,'dor',84,{}],['m2','Охота на стрелков',40,'mix',88,{metal:1}],['m3','Рой',36,'dor',92,{swarm:1}],
 ['m4','Стальной строй',41,'mix',94,{heavy:1}],['m5','Копья в пустоте',43,'dor',96,{brass:.035}],['m6','Ядро Стража',38,'phr',98,{brass:.03,heavy:1}],
 ['m7','Тихий маяк',45,'lyd',90,{beat:1}],['m8','Ретрансляторы',46,'lyd',96,{pan:1}],['m9','Ионная буря',36,'dor',100,{crackle:1}],['m10','Последняя передача',38,'mix',106,{hi:1,brass:.03}]]
 .forEach(([id,name,root,mode,bpm,x])=>{SC_[id]=Object.assign({name,root,v:V[mode],chordT:[8,12],pad:['sawtooth',380,1100,.03],sub:.1,noise:['bandpass',700,x.swarm?.03:.012,x.swarm?.9:.1],bell:['shine',14,22,.016],rev:.32,fight:1,bpm,pulse:'q',toms:'fight',vol:1},x);});
SECTORS_NEW.forEach((q,i)=>{if(i>=9)return;const modes=['dor','mix','phr','dor','lyd','phr','mix','lyd','dor'],roots=[43,41,38,36,47,35,42,44,39],md=modes[i];
  SC_['s'+(i+2)]={name:q.name.charAt(0)+q.name.slice(1).toLowerCase(),root:roots[i],v:V[md],chordT:[10,16],pad:[i%2?'sawtooth':'triangle',420+i*20,1000+i*40,i%2?.03:.042],sub:.08,noise:['bandpass',600+i*90,.012,.05+i*.02],bell:[['shine','glass','metal'][i%3],9,15,.02],rev:.4+(i%3)*.06,alert:1,vol:.68};
  SC_['mx'+(i+2)]={name:'Бой · '+q.name.charAt(0)+q.name.slice(1).toLowerCase(),root:roots[i],v:V[md],chordT:[8,12],pad:['sawtooth',380,1100,.03],sub:.1,noise:['bandpass',700+i*60,.012,.1],bell:['shine',14,22,.016],rev:.32,fight:1,bpm:96+i*2,pulse:'q',toms:'fight',heavy:i%2?1:0,brass:i>=4?.03:0,vol:1};});
const MUS={players:[],cur:null,lastName:'',voices:0,alarm:false,alarmT:0,lowSince:0,tonal:[],duckT:1,pausedLP:false};
const mtof=m=>440*Math.pow(2,(m-69)/12);
function vStart(n,t){MUS.voices++;n.onended=()=>{MUS.voices--;};n.start(t);}
function noiseBuf(){const c=AU.ctx;if(MUS.nb)return MUS.nb;const len=c.sampleRate*2,b=c.createBuffer(1,len,c.sampleRate),d=b.getChannelData(0);let l=0;for(let i=0;i<len;i++){const w=Math.random()*2-1;l=l*.97+w*.03;d[i]=w*.6+l*2.2;}return MUS.nb=b;}
// одиночные события
function ev(t,f,dur,type,vol,out,att,f2,pan){const c=AU.ctx;if(MUS.voices>AMB_CFG.maxVoices)return;const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+dur);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol,t+(att||.01));g.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(g);
  if(pan){const p=c.createStereoPanner();p.pan.value=pan;g.connect(p);p.connect(out);}else g.connect(out);vStart(o,t);o.stop(t+dur+.05);}
function evNoise(t,dur,vol,out,type,f,q,f2){const c=AU.ctx;if(MUS.voices>AMB_CFG.maxVoices)return;const s=c.createBufferSource();s.buffer=noiseBuf();const fl=c.createBiquadFilter();fl.type=type;fl.frequency.setValueAtTime(f,t);if(f2)fl.frequency.exponentialRampToValueAtTime(f2,t+dur);fl.Q.value=q||1;
  const g=c.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol,t+Math.min(.02,dur/3));g.gain.exponentialRampToValueAtTime(.0001,t+dur);s.connect(fl);fl.connect(g);g.connect(out);vStart(s,t);s.stop(t+dur+.05);}
function tonal(t,id){MUS.tonal.push([t,id]);if(MUS.tonal.length>400)MUS.tonal.splice(0,200);}
function bell(P,t){const S=P.sc,b=S.bell;if(!b)return;const ch=P.chord,n=ch[Math.random()*ch.length|0]+S.root+24+(Math.random()<.4?12:0),f=mtof(n),pan=rnd(-.7,.7);
  if(b[0]==='metal'){ev(t,f,3.2,'sine',b[3],P.L.bell,.005,null,pan);ev(t,f*2.76,1.6,'sine',b[3]*.35,P.L.bell,.005,null,pan);}
  else if(b[0]==='glass'){ev(t,f,4.5,'sine',b[3],P.L.bell,.02,null,pan);ev(t,f*3,2.2,'sine',b[3]*.25,P.L.bell,.02,null,-pan);}
  else{ev(t,f,5,'sine',b[3],P.L.bell,.03,null,pan);ev(t,f*2,2.5,'sine',b[3]*.3,P.L.bell,.03,null,pan);}
  tonal(t,P.id);}
// звуковой пейзаж: постоянные голоса + планировщик событий
function newScape(id){
  const c=AU.ctx,S=SC_[id],t=c.currentTime;const P={id,sc:S,t0:t,stopAt:0,L:{},chord:S.v[0],ci:0,nextChord:t+rnd(S.chordT[0],S.chordT[1]),step:0,next:t+.1,nextBell:t+rnd(2,6),nextPing:t+3,nodes:[],I:0,calm:false,ext:{},semi:0};
  P.out=c.createGain();P.out.gain.value=0;P.out.connect(AU.mus);P.send=c.createGain();P.send.gain.value=S.rev;P.out.connect(P.send);P.send.connect(AU.rev);
  for(const k of ['pad','sub','noise','pulse','toms','tick','brass','bell','fx','hi'])(P.L[k]=c.createGain()).connect(P.out);
  // пэд: 4 ноты × 2 расстроенных осциллятора, общий фильтр
  P.padF=c.createBiquadFilter();P.padF.type='lowpass';P.padF.Q.value=.7;P.padF.frequency.value=S.pad[1];P.padF.connect(P.L.pad);
  if(S.chorus){const d=c.createDelay(.05);d.delayTime.value=.022;const dg=c.createGain();dg.gain.value=.5;const pn=c.createStereoPanner();pn.pan.value=.6;P.padF.connect(d);d.connect(dg);dg.connect(pn);pn.connect(P.L.pad);}
  P.pad=[];S.v[0].forEach((iv,i)=>{for(const det of [-6,6]){const o=c.createOscillator();o.type=S.pad[0];o.frequency.value=mtof(S.root+12+iv)*Math.pow(2,det/1200);const g=c.createGain();g.gain.value=S.pad[3];const pn=c.createStereoPanner();pn.pan.value=(i-1.5)*.35+det/30;o.connect(g);g.connect(pn);pn.connect(P.padF);vStart(o,t);P.pad.push({o,iv,det});P.nodes.push(o);}});
  P.subO=c.createOscillator();P.subO.type='sine';P.subO.frequency.value=mtof(S.root);const sg=c.createGain();sg.gain.value=S.sub;P.subO.connect(sg);sg.connect(P.L.sub);vStart(P.subO,t);P.nodes.push(P.subO);
  if(S.tri){const o=c.createOscillator();o.type='sine';o.frequency.value=mtof(S.root+6);const g=c.createGain();g.gain.value=S.sub*.22;o.connect(g);g.connect(P.L.sub);vStart(o,t);P.nodes.push(o);}
  const ns=c.createBufferSource();ns.buffer=noiseBuf();ns.loop=true;P.noiseF=c.createBiquadFilter();P.noiseF.type=S.noise[0];P.noiseF.frequency.value=S.noise[1];P.noiseF.Q.value=.8;const ng=c.createGain();ng.gain.value=S.noise[2];ns.connect(P.noiseF);P.noiseF.connect(ng);ng.connect(P.L.noise);vStart(ns,t);P.nodes.push(ns);
  if(S.hi){for(const iv of [24,31]){const o=c.createOscillator();o.type='sine';o.frequency.value=mtof(S.root+iv);const g=c.createGain();g.gain.value=.012;o.connect(g);g.connect(P.L.hi);vStart(o,t);P.nodes.push(o);}P.L.hi.gain.value=0;}
  scape80(P,c,t);P.L.pulse.gain.value=0;P.L.toms.gain.value=0;P.L.tick.gain.value=0;P.L.brass.gain.value=0;
  return P;
}
function scapeStop(P,t){for(const n of P.nodes){try{n.stop(t);}catch(e){}}setTimeout(()=>{try{P.out.disconnect();P.send.disconnect();}catch(e){}},(t-AU.ctx.currentTime+.5)*1000);}
function setChord(P,t){const S=P.sc;P.ci=(P.ci+1+(Math.random()<.3?1:0))%S.v.length;P.chord=S.v[P.ci];
  P.pad.forEach((v,k)=>{const iv=P.chord[Math.floor(k/2)];v.o.frequency.setTargetAtTime(mtof(S.root+P.semi+12+iv)*Math.pow(2,v.det/1200),t,1.4);});
  P.subO.frequency.setTargetAtTime(mtof(S.root+P.semi+(P.chord[0]<0?P.chord[0]+12:P.chord[0])%12),t,2);
  P.nextChord=t+rnd(S.chordT[0],S.chordT[1]);}
// один шестнадцатый шаг
function scapeStep(P,t){
  const S=P.sc,X=P.ext,st=P.step%16,bar=Math.floor(P.step/16),I=P.I,root=S.root+P.semi,tn=m=>mtof(m);
  const dark=X.darkOff;
  // пульс (тональный, одна нота/квинта)
  if(S.fight&&!P.calm&&!dark&&!X.drop){
    const pat=S.pulse==='double'?[0,2,8,10]:I>.55?[0,4,8,12]:[0,4,8];
    if(pat.includes(st)){const n=root+12+(st===8&&S.pulse==='q'&&bar%2?7:0);const pan=S.pan?(st%8===0?-.5:.5):0;
      ev(t,tn(n),.42,'sawtooth',.05,P.L.pulse,.006,tn(n)*.995,pan);tonal(t,P.id);}
    // томы
    const tp=S.toms==='boss'?[0,3,6,8,11]:S.heavy?[0,6,10]:I>.65?[0,6,10]:[0,10];
    if(tp.includes(st)){const f=S.toms==='boss'?72:86;ev(t,f,.5,'sine',S.toms==='boss'?.2:.26,P.L.toms,.003,f*.5);evNoise(t,.05,.05,P.L.toms,'lowpass',1800);}
    if(st===4&&bar%2===1)evNoise(t,.25,.06,P.L.toms,'bandpass',S.metal?3200:900,S.metal?8:1.2);
    // тиканье
    if(st%2===1&&(I>.4||S.boss))evNoise(t,.03,S.metal?.03:.018,P.L.tick,'bandpass',S.metal?4200:2600,4);
    // маяк — тёплый удар на тонике
    if(S.beat&&st===0){ev(t,tn(root+24),1.2,'sine',.05,P.L.fx,.01);tonal(t,P.id);}
    // разгон перед сменой гармонии
    if(P.nextChord-t<2.2&&P.nextChord-t>2.2-60/(S.bpm)/4&&I>.3)evNoise(t,2.1,.05*I+.02,P.L.fx,'bandpass',300,2,3000);
  }
  // тревога в секторе: сердцебиение и тиканье
  if(S.alert&&P.I>0){if(st===0||st===3)ev(t,58,.3,'sine',.22,P.L.toms,.004,40);if(st%4===2)evNoise(t,.03,.016,P.L.tick,'bandpass',2400,4);}
  // глушитель во тьме — только сердце
  if(dark&&(st===0||st===3))ev(t,55,.35,'sine',.26,P.L.toms,.004,38);
  // медь
  if(S.brass&&!P.calm&&!dark&&!X.drop&&st===0&&bar%8===(S.boss?0:4)){const c=AU.ctx,dur=3.2;for(const iv of [0,7]){const o=c.createOscillator(),f=c.createBiquadFilter(),g=c.createGain();o.type='sawtooth';o.frequency.value=tn(root+iv);f.type='bandpass';f.Q.value=2.5;f.frequency.setValueAtTime(180,t);f.frequency.exponentialRampToValueAtTime(900,t+1.4);f.frequency.exponentialRampToValueAtTime(260,t+dur);
      g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(S.brass,t+.8);g.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(f);f.connect(g);g.connect(P.L.brass);vStart(o,t);o.stop(t+dur+.05);}tonal(t,P.id);}
  // треск бури / глушителя
  if(S.crackle&&(X.storm||S.boss)&&Math.random()<.18)evNoise(t,.02,.035,P.L.fx,'highpass',3500);
  if(S.swarm&&st%2===0&&Math.random()<.5)evNoise(t,.12,.012,P.L.fx,'bandpass',rnd(900,2400),6);
  step80(P,t,st,bar);
}
function scapeRun(P,now,ahead){
  const S=P.sc;const sd=60/((S.bpm||90)+(P.ext.bpmAdd||0))/4;
  if(P.next<now-.25)P.next=now+.05;
  while(P.next<ahead){
    if(P.next>=P.nextChord)setChord(P,P.next);
    scapeStep(P,P.next);P.step++;P.next+=sd;}
  if(S.bell&&P.nextBell<ahead){bell(P,Math.max(now,P.nextBell));P.nextBell+=rnd(S.bell[1],S.bell[2])*(P.I>.5?1.6:1);}
  if(S.ping&&P.nextPing<ahead){const t=Math.max(now,P.nextPing),f=rnd(880,1240);[0,.32,.64].forEach((d,i)=>ev(t+d,f*(i===2?.75:1),1.4,'sine',.03*(1-i*.3),P.L.bell,.02));tonal(t,P.id);P.nextPing+=rnd(10,15);}
}
function scapeLayers(P){
  const t=AU.ctx.currentTime,S=P.sc,X=P.ext,I=P.I,set=(k,v,tc)=>P.L[k].gain.setTargetAtTime(v,t,tc||.7);
  const dark=X.darkOff;
  set('pad',dark?.15:1);set('sub',1);set('noise',dark?.6:1);set('bell',1);
  set('pulse',S.fight&&!P.calm?(S.boss?1:.45+.55*I):0);set('toms',S.fight&&!P.calm?(S.boss?1:.25+.75*I):S.alert?I:0);
  set('tick',S.fight&&!P.calm?(S.boss?1:I):S.alert?I:0);set('brass',S.boss?1:I);set('fx',1);set('hi',X.transmit?1:0,1.5);
  const lo=S.pad[1],hi=S.pad[2],br=S.fight&&!P.calm?.35+.65*I:S.alert?.2+.6*I:.4;
  const cut=(lo+(hi-lo)*br)*(X.storm?1.5:1)*(.85+.15*Math.sin(t*.4+P.t0));P.padF.frequency.setTargetAtTime(cut,t,1.2);
  if(S.alert)P.noiseF.frequency.setTargetAtTime(S.noise[1]*(1+.8*I),t,1.5);
  if(S.swarm||S.noise[3]>.5)P.noiseF.frequency.setTargetAtTime(S.noise[1]*(1+.6*Math.sin(t*S.noise[3]*2)),t,.3);
  if(X.anom)P.L.fx.gain.setTargetAtTime(1,t,.5);
}
// стингеры
function ambSting(kind){
  if(!AU.ctx||!AU.sting||!SET.amb)return;const c=AU.ctx,t=c.currentTime+.02,o=AU.sting,P=MUS.cur,root=P?P.sc.root+P.semi:38;
  AU.duckG.gain.cancelScheduledValues(t);AU.duckG.gain.setTargetAtTime(MUS.duckT*.63,t,.08);AU.duckG.gain.setTargetAtTime(MUS.duckT,t+1.5,.6);
  if(kind==='start'){for(const iv of [12,19,24])ev(t,mtof(root+iv),3,'triangle',.05,o,.4);evNoise(t,1.6,.06,o,'bandpass',400,1.5,2500);}
  if(kind==='flash'){for(const iv of [24,31,36])ev(t,mtof(root+iv),2.4,'sine',.05,o,.01);ev(t,70,.6,'sine',.3,o,.003,40);}
  if(kind==='boss'){evNoise(t,2.5,.12,o,'lowpass',200,1,1400);ev(t,mtof(root),3,'sawtooth',.06,o,1.5);ev(t,mtof(root+1),3,'sawtooth',.03,o,1.5);ev(t+2.4,60,.9,'sine',.45,o,.003,32);}
  if(kind==='phase'){ev(t,mtof(root+13),1.2,'sawtooth',.04,o,.01);ev(t,mtof(root+12),1.2,'sawtooth',.04,o,.01);ev(t,64,.7,'sine',.4,o,.003,34);}
  if(kind==='bossDown'||kind==='win'){for(const iv of [12,19,24,31])ev(t+iv*.004,mtof(root+iv),4.5,'triangle',.045,o,.05);ev(t,66,.8,'sine',.35,o,.003,36);}
  if(kind==='fail'){evNoise(t,3,.08,o,'lowpass',1500,1,120);ev(t,mtof(root+12),3.5,'sine',.06,o,.02,mtof(root));}
}
function makeImpulse(c,sec){const n=c.sampleRate*sec,b=c.createBuffer(2,n,c.sampleRate);for(let ch=0;ch<2;ch++){const d=b.getChannelData(ch);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,3.2);}return b;}
function musInit(){
  const c=AU.ctx;AU.mus=c.createGain();AU.mus.gain.value=1;
  AU.musLP=c.createBiquadFilter();AU.musLP.type='lowpass';AU.musLP.frequency.value=18000;
  AU.duckG=c.createGain();AU.duckG.gain.value=1;const comp=c.createDynamicsCompressor();comp.threshold.value=-18;comp.ratio.value=3;
  AU.mus.connect(AU.musLP);AU.musLP.connect(AU.duckG);AU.duckG.connect(comp);comp.connect(AU.amb);
  AU.rev=c.createConvolver();AU.rev.buffer=makeImpulse(c,4);const rg=c.createGain();rg.gain.value=.8;AU.rev.connect(rg);rg.connect(AU.musLP);
  AU.sting=c.createGain();AU.sting.gain.value=1;AU.sting.connect(comp);const ss=c.createGain();ss.gain.value=.35;AU.sting.connect(ss);ss.connect(AU.rev);
  // тревога: звон в ушах (постоянный, тихий) + удары сердца и пульс тритона
  AU.alarm=c.createGain();AU.alarm.gain.value=0;AU.alarm.connect(comp);
  const ring=c.createOscillator();ring.type='sine';ring.frequency.value=2600;const rgn=c.createGain();rgn.gain.value=.006;ring.connect(rgn);rgn.connect(AU.alarm);ring.start();AU.ring=ring;
  {const ns=c.createBufferSource();ns.buffer=noiseBuf();ns.loop=true;AU.riftF=c.createBiquadFilter();AU.riftF.type='bandpass';AU.riftF.Q.value=1.4;AU.riftF.frequency.value=1200;AU.riftG=c.createGain();AU.riftG.gain.value=0;ns.connect(AU.riftF);AU.riftF.connect(AU.riftG);AU.riftG.connect(AU.amb);ns.start();}
  if(!MUS.timer)MUS.timer=setInterval(()=>{try{musSched();}catch(e){console.error(e);}},50);
}
function musSched(){
  if(!AU.ctx||!AU.mus)return;const c=AU.ctx,now=c.currentTime,ahead=now+.3;
  if(c.state!=='running')return;
  for(const P of MUS.players)if(!P.stopAt||now<P.stopAt)scapeRun(P,now,ahead);
  MUS.players=MUS.players.filter(P=>!(P.stopAt&&now>P.stopAt+.2));
  if(MUS.alarm){if(MUS.alarmT<now)MUS.alarmT=now+.05;while(MUS.alarmT<ahead){const t=MUS.alarmT,P=MUS.cur,r=P?P.sc.root+P.semi:40;
    ev(t,60,.25,'sine',.28,AU.alarm,.003,40);ev(t+.22,57,.22,'sine',.2,AU.alarm,.003,38);ev(t+.8,mtof(r+30),.5,'triangle',.03,AU.alarm,.01);MUS.alarmT+=1.6;}
    AU.ring.frequency.setTargetAtTime(2500+300*Math.sin(now*.7),now,.5);}
}
function musSwitch(id,fade,semi){
  if(!AU.ctx)return;const cur=MUS.cur;if(cur&&cur.id===id&&cur.semi===(semi||0))return;
  const c=AU.ctx,t=c.currentTime+.03,N=64;
  const up=new Float32Array(N),dn=new Float32Array(N);for(let i=0;i<N;i++){const x=i/(N-1);up[i]=Math.sin(x*Math.PI/2)*SC_[id].vol;dn[i]=Math.cos(x*Math.PI/2);}
  if(cur){const g=cur.out.gain,v=g.value;g.cancelScheduledValues(t);g.setValueAtTime(v,t);const d2=dn.map(x=>x*v);g.setValueCurveAtTime(d2,t+.001,fade);cur.stopAt=t+fade+.1;scapeStop(cur,t+fade+.1);}
  const P=newScape(id);P.semi=semi||0;if(P.semi){P.pad.forEach((v,k)=>v.o.frequency.value=mtof(P.sc.root+P.semi+12+P.chord[Math.floor(k/2)])*Math.pow(2,v.det/1200));P.subO.frequency.value=mtof(P.sc.root+P.semi);}
  P.out.gain.setValueCurveAtTime(up,t+.001,fade);MUS.players.push(P);MUS.cur=P;MUS.lastName=P.sc.name;
}
// какой пейзаж и с какой интенсивностью нужен сейчас
function musTarget(){
  const st=G.state,p=G.player;let id='menu',I=0,calm=false,semi=0,ext={},low=false,duck=1,lp=18000;
  const bossOf=()=>G.boss&&G.boss.alive&&G.boss.st!=='enter'?'warden':G.jam&&G.jam.alive&&G.jam.st!=='enter'?'jam':null;
  if(G.mode==='endless'&&G.end&&['play','levelup','pause','over','codex'].includes(st)){
    const b=bossOf();id=b||'abyss';I=st==='play'?Math.min(1,.3+G.end.step*.04):.4;if(b){semi=1;}}
  else if(st==='shop')id='shop';else if(st==='hangar')id='hangar';else if(st==='cycle')id='cycle';
  else if(G.mode==='world'&&G.world&&['world','map','pause','codex'].includes(st)&&p){
    {const si=sectorIdx(p.x,p.y);id=si===0?'belt':si===1?'drift':'s'+si;}const hostile=G.enemies.some(e=>e.alive&&e.type!=='mine'&&e.type!=='lock'&&e.type!=='rangedummy'&&!e.peace&&Math.hypot(e.x-p.x,e.y-p.y)<900);
    if(hostile)MUS.hostT=G.t;I=hostile||(G.t-(MUS.hostT||-9)<4)||G.anom?1:0;ext.anom=!!G.anom;if(typeof zbMus==='function'){const q=zbMus();if(q){id=q.id;I=q.I;if(q.ext)Object.assign(ext,q.ext);}}}
  else if((G.mode==='world'||G.mode==='dev')&&['intro','play','levelup','pause','done','over','codex'].includes(st)&&G.m){
    id=SC_['m'+G.m]?'m'+G.m:'mx'+MISSIONS[G.m-1].sec;calm=st==='intro'||st==='done'||st==='over';
    const b=bossOf();if(b&&!calm)id=b;
    if(!calm){const ld=enemyLoad(),near=p&&G.enemies.some(e=>e.alive&&!EDEF[e.type].passive&&Math.hypot(e.x-p.x,e.y-p.y)<300);I=clamp(ld/12+(near?.2:0),0,1);}
    if(G.bc&&G.bc.transStarted)ext.transmit=1;if(G.storm&&G.storm.warn<=0)ext.storm=1;
    if(G.boss&&G.boss.alive){ext.bpmAdd=(G.boss.phase-1)*6;if(G.boss.over>0)ext.drop=1;}
    if(G.jam&&G.jam.alive){ext.bpmAdd=(G.jam.phase-1)*6;if(G.jam.phase===3&&G.jam.window<=0)ext.darkOff=1;}}
  if(G.mode==='endless'&&G.jam&&G.jam.alive&&G.jam.phase===3&&G.jam.window<=0)ext.darkOff=1;
  if(G.mode==='endless'&&G.boss&&G.boss.alive){ext.bpmAdd=(G.boss.phase-1)*6;if(G.boss.over>0)ext.drop=1;}
  if(p&&p.hp>0&&(st==='play'||st==='world'||st==='levelup')){const r=p.hp/G.st.maxHp;if(r<AMB_CFG.alarmOn){low=true;MUS.lowSince=performance.now();}else if(MUS.alarm&&(r<AMB_CFG.alarmOff||performance.now()-MUS.lowSince<AMB_CFG.alarmHold*1000))low=true;}
  if(st==='pause'){duck=.5;lp=800;}
  return mus80({id,I,calm,semi,ext,low,duck,lp});
}
let musLayerT=0;
function musicTick(dt){
  if(!AU.ctx||!AU.mus)return;const T=musTarget(),t=AU.ctx.currentTime,cur=MUS.cur;
  if(!cur||cur.id!==T.id||cur.semi!==T.semi){const from=cur?cur.sc:null,to=SC_[T.id];
    const fade=to.fight&&!(from&&from.fight)?AMB_CFG.fadeFight:from&&from.fight&&!to.fight?AMB_CFG.fadeOut:to.boss?AMB_CFG.fadeFight:AMB_CFG.fadeCalm;
    musSwitch(T.id,fade80(cur,T.id,fade),T.semi);}
  const P=MUS.cur;P.I+=(T.I-P.I)*Math.min(1,dt/2);P.calm=T.calm;P.ext=T.ext;
  if((musLayerT-=dt)<=0){musLayerT=.25;scapeLayers(P);}
  if(T.low!==MUS.alarm){MUS.alarm=T.low;AU.alarm.gain.setTargetAtTime(T.low?1:0,t,.5);}
  const rI=G.world&&G.state==='world'||G.riftDeath?(G.riftI||0):0;
  let lp=T.low?1200:T.lp;if(rI>.02)lp=Math.min(lp,600+17400*Math.pow(1-rI,2));if(Math.abs(lp-(MUS.lp||0))>40){MUS.lp=lp;AU.musLP.frequency.setTargetAtTime(lp,t,.4);}
  if(AU.riftG){AU.riftG.gain.setTargetAtTime(SET.amb||SET.sfx?rI*.5:0,t,.3);AU.riftF.frequency.setTargetAtTime(600+2400*(.5+.5*Math.sin(t*.7)),t,.5);
    if(rI>.5&&Math.random()<.03){AU.duckG.gain.setTargetAtTime(MUS.duckT*.3,t,.01);AU.duckG.gain.setTargetAtTime(MUS.duckT,t+.08,.05);}}
  if(T.duck!==MUS.duckT){MUS.duckT=T.duck;AU.duckG.gain.setTargetAtTime(T.duck,t,.3);}
}

// ---- карта «Туманность» (0.4.1): кэши в мировых координатах, гиперлинии, подписи без столкновений ----
const MAPC={sc:1/50,neb:null,rift:null,fog:null,fogVer:-1,stars:null,segs:null,spr:null,edge:null,noise:null,cycle:-1};
const hexA=(h,a)=>{const n=parseInt(h.slice(1),16);return `rgba(${n>>16&255},${n>>8&255},${n&255},${a})`;};
function secOfNode(n){return n.sec!==undefined?n.sec:sectorIdx(n.x,n.y);}
function mapStars(){if(MAPC.stars)return MAPC.stars;const R=mulberry(77),a=[];for(let i=0;i<600;i++)a.push({x:R(),y:R(),l:i%3,s:R()*1.3+.4,tw:R()*TAU,b:R()<.025});return MAPC.stars=a;}
function mapNeb(){if(MAPC.neb)return MAPC.neb;const sc=MAPC.sc,c=document.createElement('canvas');c.width=Math.ceil(WW*sc);c.height=Math.ceil(WH*sc);const g=c.getContext('2d');g.globalCompositeOperation='lighter';
  WORLD.sectors.forEach((S_,i)=>{const R=mulberry(500+i*31),b=S_.box,n=6+(i%5);for(let k=0;k<n;k++){const x=b[0]+(b[2]-b[0])*(.12+.76*R()),y=b[1]+(b[3]-b[1])*(.12+.76*R()),r=Math.min(b[2]-b[0],b[3]-b[1])*(.38+.42*R());
    const gr=g.createRadialGradient(x*sc,y*sc,0,x*sc,y*sc,r*sc),a=.1+.12*R();gr.addColorStop(0,hexA(S_.col,a));gr.addColorStop(.6,hexA(S_.col,a*.45));gr.addColorStop(1,hexA(S_.col,0));g.fillStyle=gr;g.beginPath();g.arc(x*sc,y*sc,r*sc,0,TAU);g.fill();}});
  return MAPC.neb=c;}
function mapRift(){const sh=riftShift(),er=Math.floor(erosion()*20)/20,key=sh+'|'+er;if(MAPC.rift&&MAPC.riftKey===key)return MAPC.rift;MAPC.riftKey=key;
  const st=100,W_=Math.ceil(WW/st),H_=Math.ceil(WH/st),c=document.createElement('canvas');c.width=W_;c.height=H_;const g=c.getContext('2d'),im=g.createImageData(W_,H_),Rn=mulberry(913),Rb=mulberry(4711);
  const bd=(x,y)=>{let best=1e9;for(const S_ of WORLD.sectors){const b=S_.box,dx=Math.max(b[0]-x,0,x-b[2]),dy=Math.max(b[1]-y,0,y-b[3]),d=Math.hypot(dx,dy);if(d<best)best=d;}return best;};
  const reach=sh+er*250+50;
  for(let j=0;j<H_;j++)for(let i=0;i<W_;i++){const x=(i+.5)*st,y=(j+.5)*st;let d=bd(x,y);const bite=Rb();
    if(d===0&&reach>50){const si=sectorIdx(x,y),b=WORLD.sectors[si].box,own=Math.min(x-b[0],b[2]-x,y-b[1],b[3]-y);if(own<reach+200)d=riftInfo(x,y).d;else d=-own;}
    d+=sh+(d<=0?er*250*bite:0);const q=smooth(0,900,d),n=Rn(),o=(j*W_+i)*4;
    const sp=n<.07*q;im.data[o]=sp?(Rn()<.5?255:180):7+18*q*n;im.data[o+1]=sp?(Rn()<.5?79:140):4;im.data[o+2]=sp?(Rn()<.5?110:255):13+22*q*n;im.data[o+3]=Math.round(255*q*(sp?.55:.82));}
  g.putImageData(im,0,0);const c2=document.createElement('canvas'),sc=MAPC.sc;c2.width=Math.ceil(WW*sc);c2.height=Math.ceil(WH*sc);const g2=c2.getContext('2d');g2.imageSmoothingEnabled=true;g2.filter='blur(1.5px)';g2.drawImage(c,0,0,c2.width,c2.height);g2.filter='none';
  return MAPC.rift=c2;}
function fogSprite(){if(MAPC.spr)return MAPC.spr;const s=64,c=document.createElement('canvas');c.width=c.height=s;const g=c.getContext('2d'),gr=g.createRadialGradient(s/2,s/2,0,s/2,s/2,s/2);gr.addColorStop(0,'rgba(0,0,0,1)');gr.addColorStop(.55,'rgba(0,0,0,.92)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,s,s);return MAPC.spr=c;}
function mapFog(){const fk=fogMemo().k;if(MAPC.fog&&MAPC.fogVer===G.fogVer&&MAPC.fogK===fk)return MAPC.fog;const sc=MAPC.sc,W_=Math.ceil(WW*sc),H_=Math.ceil(WH*sc),c=document.createElement('canvas');c.width=W_;c.height=H_;const g=c.getContext('2d');
  g.fillStyle='rgba(2,3,8,.94)';g.fillRect(0,0,W_,H_);g.globalCompositeOperation='destination-out';const sp=fogSprite(),rr=FOG*1.6*sc;
  for(let j=0;j<FGH;j++)for(let i=0;i<FGW;i++)if(G.fog[j*FGW+i]&&!fogClosedAt((i+.5)*FOG,(j+.5)*FOG)){const x=(i+.5)*FOG*sc,y=(j+.5)*FOG*sc;g.drawImage(sp,x-rr,y-rr,rr*2,rr*2);}
  const c2=document.createElement('canvas');c2.width=W_;c2.height=H_;const g2=c2.getContext('2d');g2.filter='blur(2px)';g2.drawImage(c,0,0);g2.filter='none';
  MAPC.fog=c2;MAPC.fogVer=G.fogVer;MAPC.fogK=fk;return c2;}
// 1.0.0 α: карта — всё скрытое (неисследованное, закрытые туманом войны сектора, Разлом вне секторов) выглядит как один и тот же
// космос за краем мира: фон и звёзды. Видимость считается полем на сетке 200 ед., размывается в коде (три прохода коробки по осям,
// σ ≈ 700 ед.) и сглаживается S-кривой — переходы очень плавные на любом устройстве, без ctx.filter.
const MAPH={R:200,P:8};
function mapHide(){const F=fogMemo(),key=(G.fogVer||0)+'|'+F.k;if(MAPC.hide&&MAPC.hideK===key)return MAPC.hide;
  const R=MAPH.R,P=MAPH.P,gw=Math.ceil(WW/R)+2*P,gh=Math.ceil(WH/R)+2*P,n=gw*gh,v=new Float32Array(n),u=new Float32Array(n);
  // cv — закрытые туманом войны сектора: их край гаснет целиком на открытой стороне (за границей ничего не просвечивает)
  const cv=new Float32Array(n),oa=openAllNow();
  for(let j=0;j<gh;j++)for(let i=0;i<gw;i++){const x=(i-P+.5)*R,y=(j-P+.5)*R,q=j*gw+i;
    if(!oa&&fogClosedAt(clamp(x,0,WW),clamp(y,0,WH)))cv[q]=1;if(j>=P&&j<gh-P&&i>=P&&i<gw-P)v[q]=inSectors(x,y)&&revealedAt(x,y)?1:0;}
  const r=3,blur=(a,b,hz)=>{const Ln=hz?gw:gh,M=hz?gh:gw,at=(m,q)=>{q=q<0?0:q>=Ln?Ln-1:q;return hz?a[m*gw+q]:a[q*gw+m];};
    for(let m=0;m<M;m++){let s=0;for(let q=-r;q<=r;q++)s+=at(m,q);for(let q=0;q<Ln;q++){b[hz?m*gw+q:q*gw+m]=s/(2*r+1);s+=at(m,q+r+1)-at(m,q-r);}}};
  for(let k=0;k<3;k++){blur(v,u,true);blur(u,v,false);}
  if(!oa)for(let k=0;k<3;k++){blur(cv,u,true);blur(u,cv,false);}
  const c=document.createElement('canvas');c.width=gw;c.height=gh;const g=c.getContext('2d'),im=g.createImageData(gw,gh),d=im.data;
  for(let q=0;q<n;q++){let a=(v[q]-.06)/(.82-.06);a=a<0?0:a>1?1:a;a=a*a*(3-2*a);
    // к краю мира видимость гаснет плавно: туманности за краем нет, обрыва быть не должно
    const x=((q%gw)-P+.5)*R,y=(Math.floor(q/gw)-P+.5)*R;let f=Math.min(x,WW-x,y,WH-y)/1100;f=f<0?0:f>1?1:f;f=f*f*(3-2*f);a*=f;
    let e=1-(cv[q]-.015)/(.5-.015);e=e<0?0:e>1?1:e;a*=e*e*(3-2*e);
    d[q*4+3]=Math.round((1-a)*255);}
  g.putImageData(im,0,0);MAPC.hide=c;MAPC.hideK=key;MAPC.hideDark=null;return c;}
function mapHideTint(){return mapHideDark();}
function mapHideDark(){const hm=mapHide();if(MAPC.hideDark)return MAPC.hideDark;const c=document.createElement('canvas');c.width=hm.width;c.height=hm.height;const g=c.getContext('2d');
  g.fillStyle=MAP_BG;g.fillRect(0,0,c.width,c.height);g.globalCompositeOperation='destination-in';g.imageSmoothingEnabled=true;g.drawImage(hm,0,0);MAPC.hideDark=c;return c;}
// поверх содержимого карты — скрытое закрывается цветом фона (одна растянутая маска), затем звёзды и мягкая виньетка поверх всего
function mapSpace(g,X,Y,k,w,h,t,fx,V_){const pd=MAPH.P*MAPH.R;g.save();g.globalAlpha=1;g.globalCompositeOperation='source-over';g.imageSmoothingEnabled=true;
  g.drawImage(mapHideTint(),X(-pd),Y(-pd),(WW+2*pd)*k,(WH+2*pd)*k);g.restore();
  mapStarsDraw(g,w,h,k,V_,fx,t);g.globalAlpha=1;
  const vg=g.createRadialGradient(w/2,h/2,Math.min(w,h)*.25,w/2,h/2,Math.max(w,h)*.78);vg.addColorStop(0,'rgba(1,2,6,0)');vg.addColorStop(1,'rgba(1,2,6,.5)');g.fillStyle=vg;g.fillRect(0,0,w,h);}
function mapSegs(){if(MAPC.segs)return MAPC.segs;const N=WORLD.nodes,segs=[];
  for(let i=0;i<N.length-1;i++){const p0=N[i-1]||N[i],p1=N[i],p2=N[i+1],p3=N[i+2]||p2,pts=[];
    for(let k=0;k<=14;k++){const t=k/14,t2=t*t,t3=t2*t,f=(a,b,c,d)=>.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t2+(-a+3*b-3*c+d)*t3);pts.push([f(p0.x,p1.x,p2.x,p3.x),f(p0.y,p1.y,p2.y,p3.y)]);}
    const s1=secOfNode(p1),s2=secOfNode(p2);let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const [x,y] of pts){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}
    segs.push({a:p1,b:p2,pts,cross:s1!==s2,c1:WORLD.sectors[s1].col,c2:WORLD.sectors[s2].col,bb:[x0,y0,x1,y1]});}
  return MAPC.segs=segs;}
// значки (общие для карты и легенды)
function mapIcon(g,kind,x,y,o){o=o||{};const t=o.t||0;g.save();g.translate(x,y);g.lineWidth=1.5;const glowC=(c,r)=>{const gr=g.createRadialGradient(0,0,0,0,0,r);gr.addColorStop(0,hexA(c,.35));gr.addColorStop(1,hexA(c,0));g.fillStyle=gr;g.beginPath();g.arc(0,0,r,0,TAU);g.fill();};
  if(w58MapIcon(g,kind,o,t)||w74MapIcon(g,kind,o,t)||w80MapIcon(g,kind,o,t)){g.restore();return;}
  switch(kind){
    case 'open':glowC('#ffb84d',14);g.fillStyle='#ffb84d';g.beginPath();g.arc(0,0,4,0,TAU);g.fill();g.strokeStyle='#ffb84d';g.beginPath();g.arc(0,0,7,t*2,t*2+4.4);g.stroke();break;
    case 'done':glowC('#8fe9ff',12);g.fillStyle='#8fe9ff';g.beginPath();g.arc(0,0,4.5,0,TAU);g.fill();g.strokeStyle='rgba(143,233,255,.5)';g.beginPath();g.arc(0,0,7,0,TAU);g.stroke();
      if(o.md!==undefined)for(let i=0;i<4;i++){const a=Math.PI/2+(i-1.5)*.42;g.fillStyle=i<o.md?(i===3?'#b48cff':'#ffb84d'):'#26324a';g.beginPath();g.arc(Math.cos(a)*11,Math.sin(a)*11,1.6,0,TAU);g.fill();}break;
    case 'locked':g.fillStyle='#3a4558';g.beginPath();g.arc(0,0,4,0,TAU);g.fill();g.strokeStyle='#3a4558';g.setLineDash([2,3]);g.beginPath();g.arc(0,0,7,0,TAU);g.stroke();g.setLineDash([]);break;
    case 'boss':{glowC('#ff4f6e',22);const r=o.small?7:11;g.strokeStyle='#ff6b8a';g.rotate(t*.3);g.beginPath();for(let i=0;i<8;i++){const a=i/8*TAU+Math.PI/8;g.lineTo(Math.cos(a)*r,Math.sin(a)*r);}g.closePath();g.stroke();
      g.fillStyle=o.done?'#8fe9ff':'#ff6b8a';g.beginPath();g.arc(0,0,3.5,0,TAU);g.fill();if(!o.small){g.rotate(-t*.6);g.setLineDash([3,4]);g.globalAlpha=.6;g.beginPath();g.arc(0,0,r+5,0,TAU);g.stroke();g.setLineDash([]);g.globalAlpha=1;}break;}
    case 'beacon':glowC(o.col||'#8fe9ff',14);g.strokeStyle=o.col||'#8fe9ff';g.beginPath();g.moveTo(0,-7);g.lineTo(6,0);g.lineTo(0,7);g.lineTo(-6,0);g.closePath();g.stroke();g.globalAlpha=.5;g.beginPath();g.moveTo(0,-7);g.lineTo(0,-18);g.stroke();g.globalAlpha=1;break;
    case 'shop':glowC('#ffb84d',12);g.strokeStyle='#ffb84d';g.strokeRect(-5,-5,10,10);for(let i=0;i<4;i++){g.rotate(Math.PI/2);g.beginPath();g.moveTo(5,0);g.lineTo(8,0);g.stroke();}break;
    case 'arsenal':{const c=o.open||o.small?'#9fe3ff':'#3a5a74';glowC('#8fd8ff',12);g.strokeStyle=c;g.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;g[i?'lineTo':'moveTo'](Math.cos(a)*6.5,Math.sin(a)*6.5);}g.closePath();g.stroke();if(o.open||o.small){g.globalAlpha=.45;g.fillStyle='#8fd8ff';g.fill();g.globalAlpha=1;}break;}
    case 'hangar':glowC('#ff6bd0',12);g.strokeStyle='#ff6bd0';g.rotate(Math.PI/4);g.strokeRect(-5,-5,10,10);g.globalAlpha=.4;g.fillStyle='#ff6bd0';g.fillRect(-5,-5,5,10);g.globalAlpha=1;break;
    case 'relay':g.strokeStyle=o.ok?'#8fe9ff':'#ff4f6e';g.beginPath();g.moveTo(0,-6);g.lineTo(5.5,4);g.lineTo(-5.5,4);g.closePath();g.stroke();if(o.ok){g.fillStyle='#8fe9ff';g.fill();}break;
    case 'anom':{const j=o.done?0:Math.sin(t*9)*.8;g.strokeStyle=o.done?'#3a4558':'#c9a6ff';g.beginPath();g.arc(j,0,6,0,TAU);g.stroke();if(!o.done){g.globalAlpha=.4;g.beginPath();g.arc(-j,0,9,0,TAU);g.stroke();g.globalAlpha=1;}break;}
    case 'cache':g.fillStyle='#ffb84d';g.rotate(Math.PI/4);g.fillRect(-3,-3,6,6);break;
    case 'wreck':g.strokeStyle=o.col||'#8fe9ff';g.beginPath();g.moveTo(1,-5);g.lineTo(8,0);g.lineTo(1,5);g.lineTo(3,0);g.closePath();g.moveTo(-2,-4);g.lineTo(-8,-7);g.lineTo(-5,-1);g.closePath();g.moveTo(-2,3);g.lineTo(-7,7);g.lineTo(-4,2);g.stroke();break;
    case 'wreckx':g.fillStyle='#7a8ea5';g.beginPath();g.moveTo(-6,-3);g.lineTo(1,-6);g.lineTo(6,-1);g.lineTo(2,5);g.lineTo(-4,3);g.closePath();g.globalAlpha=.55;g.fill();g.globalAlpha=1;g.strokeStyle='#9fb0c4';g.lineWidth=1;g.stroke();break;
    case 'frag':glowC('#ffffff',10);g.fillStyle='#ffffff';g.beginPath();g.moveTo(0,-7);g.lineTo(4,0);g.lineTo(0,7);g.lineTo(-3,1);g.closePath();g.fill();break;
    case 'journal':g.strokeStyle='#8fe9ff';g.beginPath();g.moveTo(-4,-5);g.lineTo(3,-5);g.lineTo(5,-3);g.lineTo(5,5);g.lineTo(-4,5);g.closePath();g.stroke();break;
    case 'abyss':glowC('#b48cff',14);g.fillStyle='#000';g.beginPath();g.arc(0,0,6,0,TAU);g.fill();g.strokeStyle=o.dim?'#5a4a7c':'#c9a6ff';g.beginPath();g.ellipse(0,0,10,3.5,-.3,0,TAU);g.stroke();break;
    case 'gate':g.strokeStyle=o.ok?'#8fe9ff':'#b48cff';g.beginPath();g.arc(0,0,8,0,TAU);g.stroke();g.beginPath();g.moveTo(-8,0);g.lineTo(8,0);g.stroke();break;
    case 'lost':g.strokeStyle='#ff4f6e';g.beginPath();g.arc(0,0,7,0,TAU);g.stroke();g.fillStyle='#c9d2de';g.beginPath();for(let i=0;i<6;i++){const a=-Math.PI/2+i*Math.PI/3;g.lineTo(Math.cos(a)*4,Math.sin(a)*4);}g.closePath();g.fill();break;
    case 'unk':g.fillStyle='#ff4f6e';g.globalAlpha=.6+.4*Math.sin(t*12);g.font='700 10px "JetBrains Mono",monospace';g.textAlign='center';g.textBaseline='middle';g.fillText('?',0,0);g.globalAlpha=1;break;
    case 'ship':g.rotate(o.ang||0);g.fillStyle=o.col||'#8fe9ff';g.beginPath();g.moveTo(9,0);g.lineTo(-6,-6);g.lineTo(-3,0);g.lineTo(-6,6);g.closePath();g.fill();break;
  }
  g.restore();}
function mapSpanMax(w,h){return Math.max(WW,WH*w/h)*1.02;}
function mapSpanDef(){return isMob()?(G.ff==='tablet'?7000:innerWidth>innerHeight?6000:4000):(($('#mapC')&&$('#mapC').clientWidth)||1000)<520?6500:11000;}
function mapSpanMin(){return isMob()?2200:3500;}
function mapViewInit(){const p=G.player,sp=mapSpanDef();G.mapView={cx:p.x,cy:p.y,span:sp*1.25,tspan:sp,vx:0,vy:0};G.mapOpenT=performance.now();G.mapTipPin=null;}
function mapClamp(w,h){const V_=G.mapView,mx=mapSpanMax(w,h),mn=mapSpanMin();V_.span=clamp(V_.span,mn,mx);V_.tspan=clamp(V_.tspan,mn,mx);const vh=V_.span*h/w;
  if(isMob()){V_.cx=clamp(V_.cx,0,WW);V_.cy=clamp(V_.cy,0,WH);return;}
  V_.cx=V_.span>=WW?WW/2:clamp(V_.cx,V_.span/2,WW-V_.span/2);V_.cy=vh>=WH?WH/2:clamp(V_.cy,vh/2,WH-vh/2);}
const MAP_BG='#050a15';
function mapStarsDraw(g,w,h,k,V_,fx,t){
  const st=mapStars(),fac=[.2,.4,.7];for(const s of st){const W2=w+160,H2=h+160;const x=((s.x*W2-(fx?V_.cx*k*fac[s.l]*.08:0))%W2+W2)%W2-80,y=((s.y*H2-(fx?V_.cy*k*fac[s.l]*.08:0))%H2+H2)%H2-80;
    g.globalAlpha=(.3+.25*s.l)*(fx?.75+.25*Math.sin(t*1.5+s.tw):1);g.fillStyle=s.l===2?'#cfeeff':'#7f9ab5';g.fillRect(x,y,s.s,s.s);
    if(s.b){g.globalAlpha=.5;g.strokeStyle='#cfeeff';g.lineWidth=.6;g.beginPath();g.moveTo(x-4,y+.5);g.lineTo(x+5,y+.5);g.moveTo(x+.5,y-4);g.lineTo(x+.5,y+5);g.stroke();}}
  g.globalAlpha=1;
}
function drawMap(){
  const c=$('#mapC'),S=G.save;if(!c||!S)return;if(typeof zbMap==='function'&&zbMap())return;const t0=performance.now(),t=t0/1000;
  const w=Math.max(200,c.clientWidth),h=isMob()?Math.max(180,Math.round(innerHeight-c.getBoundingClientRect().top-(innerWidth>innerHeight?14:96)-SAFE.b)):Math.round(w<520?Math.min(w*1.15,innerHeight*.62):Math.min(w*.56,innerHeight*.62));
  if(c.width!==Math.round(w*DPR)||c.height!==Math.round(h*DPR)){c.width=Math.round(w*DPR);c.height=Math.round(h*DPR);c.style.height=h+'px';}
  if(!G.mapView)mapViewInit();if(MAPC.cycle!==S.cycle){MAPC.cycle=S.cycle;}mapClamp(w,h);
  const V_=G.mapView,k=w/V_.span,ox=V_.cx-V_.span/2,oy=V_.cy-V_.span*h/w/2,X=x=>(x-ox)*k,Y=y=>(y-oy)*k,vis=(x,y,m)=>X(x)>-m&&X(x)<w+m&&Y(y)>-m&&Y(y)<h+m;
  G.mapXY={X,Y,k,ox,oy,w,h};const g=c.getContext('2d');g.setTransform(DPR,0,0,DPR,0,0);g.textBaseline='alphabetic';
  const fx=SET.fx,lod=k<.03?0:k<.085?1:2;
  // 1. фон
  g.fillStyle=MAP_BG;g.fillRect(0,0,w,h);
  // 2. туманности, 3. разлом, 4. туман войны
  const cs=1/MAPC.sc;g.imageSmoothingEnabled=true;
  g.globalCompositeOperation='lighter';g.drawImage(mapNeb(),X(0),Y(0),WW*k,WH*k);g.globalCompositeOperation='source-over';
  {const rf=mapRift();const jx=fx?Math.sin(t*7)*2:0;g.globalAlpha=.85;g.drawImage(rf,X(0)+jx,Y(0),WW*k,WH*k);g.globalAlpha=fx?.25+.15*Math.sin(t*3):.2;g.drawImage(rf,X(0)-jx*2,Y(0)+jx,WW*k,WH*k);g.globalAlpha=1;}
  w58MapBlobs(g,X,Y,k,vis);
  // натяжение пространства по краю секторов
  {g.strokeStyle='rgba(255,140,180,.22)';g.lineWidth=1;g.beginPath();for(const sgm of riftEdges()){if(!vis((sgm[0]+sgm[2])/2,(sgm[1]+sgm[3])/2,120))continue;const wob=fx?Math.sin(t*2+sgm[0]*.002+sgm[1]*.003)*2:0;g.moveTo(X(sgm[0])+sgm[4]*wob,Y(sgm[1])+sgm[5]*wob);g.lineTo(X(sgm[2])+sgm[4]*wob,Y(sgm[3])+sgm[5]*wob);}g.globalAlpha=.6+.4*Math.sin(t*2);g.stroke();g.globalAlpha=1;}
  // старые ворота
  if(!gateOpen()/* ВРЕМЕННО (альфа 0.5.9) */){g.strokeStyle='#7c5cff';g.setLineDash([4,4]);g.beginPath();g.moveTo(X(5000),Y(OY));g.lineTo(X(5000),Y(OY+WH0));g.stroke();g.setLineDash([]);}
  mapSpace(g,X,Y,k,w,h,t,fx,V_);
  // 5. гиперлинии
  const NS=m=>nodeState(m);
  for(const sg of mapSegs()){const b=sg.bb;if(X(b[2])<-20||X(b[0])>w+20||Y(b[3])<-20||Y(b[1])>h+20)continue;if(!openAllNow()&&fogClosedAt(sg.b.x,sg.b.y))continue;
    const sa=NS(sg.a.m),sb=NS(sg.b.m),done=sa==='done'&&sb==='done',open=!done&&sb!=='locked';
    g.beginPath();sg.pts.forEach(([x,y],i)=>i?g.lineTo(X(x),Y(y)):g.moveTo(X(x),Y(y)));
    if(sg.cross){const gr=g.createLinearGradient(X(sg.a.x),Y(sg.a.y),X(sg.b.x),Y(sg.b.y));gr.addColorStop(0,hexA(sg.c1,done?.9:.45));gr.addColorStop(1,hexA(sg.c2,done?.9:.45));g.strokeStyle=gr;g.lineWidth=done?3.5:2.5;if(!done)g.setLineDash([8,6]);g.stroke();g.setLineDash([]);}
    else if(done){g.strokeStyle=hexA(sg.c2,.18);g.lineWidth=7;g.stroke();g.strokeStyle=hexA(sg.c2,.9);g.lineWidth=2;g.stroke();}
    else if(open){g.strokeStyle='rgba(255,184,77,.55)';g.lineWidth=1.6;g.setLineDash([6,6]);g.lineDashOffset=fx?-t*12:0;g.stroke();g.setLineDash([]);g.lineDashOffset=0;}
    else{g.strokeStyle='rgba(122,142,165,.3)';g.lineWidth=1;g.setLineDash([2,6]);g.stroke();g.setLineDash([]);}
    if(open&&fx)for(let j=0;j<3;j++){const u=((t*.22+j/3)%1)*(sg.pts.length-1),i=Math.floor(u),f=u-i,p1=sg.pts[i],p2=sg.pts[Math.min(i+1,sg.pts.length-1)];const x=X(p1[0]+(p2[0]-p1[0])*f),y=Y(p1[1]+(p2[1]-p1[1])*f);
      const gr=g.createRadialGradient(x,y,0,x,y,5);gr.addColorStop(0,'rgba(255,220,150,.95)');gr.addColorStop(1,'rgba(255,184,77,0)');g.fillStyle=gr;g.beginPath();g.arc(x,y,5,0,TAU);g.fill();}}
  // 6–7. значки и подписи
  const items=[],labels=[],obst=[];
  const add=(kind,x,y,o,lab)=>{if(!vis(x,y,30))return;if(kind!=='lost'&&kind!=='unk'&&kind!=='shop'&&kind!=='hangar'&&!openAllNow()&&fogClosedAt(x,y))return;const sx=X(x),sy=Y(y);items.push({kind,x,y,sx,sy,o:o||{},lab});obst.push({x:sx-8,y:sy-8,w:16,h:16,id:items.length-1});};
  WORLD.journals.forEach(j=>{if(S.journals[j.id]){const sp=wreckSpec(j);add(sp.own==='player'?'wreck':'wreckx',j.x,j.y,{col:sp.own==='player'?SKINS[sp.skin].col:null},lod===2?{t:j.title,p:6,c:'#7a8ea5'}:null);}});
  STORY_FRAGS.forEach(f=>{if(!fragAvail(f))return;const q=fragPos(f);if(revealedAt(q.x,q.y))add('frag',q.x,q.y,{},lod>=1?{t:'ФРАГМЕНТ',p:4,c:'#ffffff'}:null);});
  (S.story?S.story.riftWrecks:[]).forEach(w=>add('lost',w.x,w.y,{},null));
  WORLD.caches.forEach(q=>{if(S.found[q.id])add('cache',q.x,q.y);});
  w58MapAdd(add,lod,S);w74MapAdd(add,lod,S);w80MapAdd(add,lod,S);
  WORLD.anomalies.forEach(a=>{if(revealedAt(a.x,a.y))add('anom',a.x,a.y,{done:!!S.anomalies[a.id],a},lod>=1?{t:'АНОМАЛИЯ · '+a.name,p:5,c:'#c9a6ff'}:null);});
  WORLD.relays.forEach(r=>{if(revealedAt(r.x,r.y)||S.relays[r.id])add('relay',r.x,r.y,{ok:!!S.relays[r.id]},lod===2?{t:'РЕТРАНСЛЯТОР',p:6,c:S.relays[r.id]?'#8fe9ff':'#ff4f6e'}:null);});
  WORLD.shops.forEach(q=>{add('shop',q.x,q.y,{q},lod>=1?{t:q.name,p:3,c:'#ffb84d'}:null);});
  {const hg=WORLD.hangar;add('hangar',hg.x,hg.y,{},lod>=1?{t:hg.name,p:4,c:'#ff6bd0'}:null);}
  {const ar=WORLD.arsenal;if(revealedAt(ar.x,ar.y)||arsOpen())add('arsenal',ar.x,ar.y,{open:arsOpen()},lod>=1?{t:ar.name+(arsOpen()?'':' · ЗАПЕЧАТАН'),p:3,c:arsOpen()?'#9fe3ff':'#5a7a94'}:null);}
  {const ab=WORLD.abyss;if(revealedAt(ab.x,ab.y)||ALPHA_OPEN/* ВРЕМЕННО (альфа 0.5.9) */)add('abyss',ab.x,ab.y,{dim:!abyssOpen()},lod>=1?{t:'∞ БЕЗДНА',p:3,c:'#c9a6ff'}:null);}
  add('gate',WORLD.gate.x,WORLD.gate.y,{ok:S.gate},lod===2?{t:S.gate?'ВОРОТА ОТКРЫТЫ':'ВОРОТА',p:5,c:'#b48cff'}:null);
  if(S.lost)add('lost',S.lost.x,S.lost.y,{},{t:'ЛОМ · '+S.lost.v,p:2,c:'#ff4f6e'});
  WORLD.sectors.forEach((sc,i)=>{if(sc.bx)add('beacon',sc.bx,sc.by,{col:sc.col,sec:i},lod>=1?{t:'МАЯК '+roman(i+1),p:2,c:sc.col}:null);});
  const nt=nextTarget();
  WORLD.nodes.forEach(n=>{const st=NS(n.m),md=medalCount(S.medals[n.m]);const kind=n.boss?'boss':st;const tgt=nt&&Math.abs(nt.x-n.x)<1&&Math.abs(nt.y-n.y)<1;
    add(kind,n.x,n.y,{md:lod===2?md:undefined,done:st==='done',small:lod===0,n,tgt},{t:lod===0?'':(lod===2?pad2(n.m)+' · '+MISSIONS[n.m-1].name:pad2(n.m))+(n.boss&&lod===2?' · '+bossLab90(n.m):''),p:tgt?0:n.boss?1:st==='open'?2:3,c:n.boss&&st!=='done'?'#ff6b8a':st==='done'?'#8fe9ff':st==='open'?'#ffb84d':'#7a8ea5'});});
  // названия секторов по центру облаков
  WORLD.sectors.forEach((sc,i)=>{const b=sc.box,cx=(b[0]+b[2])/2,cy=b[0]===0||b[0]===5000?b[3]-700:(b[1]+b[3])/2;if(!vis(cx,cy,300))return;if(!openAllNow()&&!secSeen(i))return;const fs=lod===0?11:lod===1?15:18;
    g.font=`700 ${fs}px "JetBrains Mono",monospace`;g.textAlign='center';const txt=roman(i+1)+' · '+sc.name,sp=txt.split('').join(String.fromCharCode(8202));
    g.globalAlpha=.32;g.fillStyle=sc.col;g.fillText(sp,X(cx),Y(cy));g.globalAlpha=1;});
  // ссылки на неизвестных
  if(G.unk&&G.unk.length)for(const u of G.unk)if(u.x!==undefined)add('unk',u.x,u.y);
  // отрисовка значков
  for(const it of items){const o=it.o;o.t=t;
    if(o.tgt&&fx){const q=(t*.8)%1;for(const qq of [q,(q+.5)%1]){g.strokeStyle=`rgba(255,184,77,${(1-qq)*.7})`;g.lineWidth=1.5;g.beginPath();g.arc(it.sx,it.sy,8+qq*20,0,TAU);g.stroke();}}
    const sel=G.mapHover&&G.mapHover===it.kind+it.x+','+it.y;if(sel){g.save();g.translate(it.sx,it.sy);g.scale(1.2,1.2);g.translate(-it.sx,-it.sy);}
    mapIcon(g,it.kind,it.sx,it.sy,o);if(sel)g.restore();}
  // подписи без пересечений
  for(const [i,it] of items.entries())if(it.lab&&it.lab.t)labels.push({...it.lab,sx:it.sx,sy:it.sy,id:i});
  labels.sort((a,b)=>a.p-b.p);const placed=[];
  {const au=k>.08?5:k>.03?20:50,sl=au*AUNIT*k,mob=w<520,mw=Math.min(mob?110:150,w*.3),mh=mw*WH/WW,bs=mob?44:36,bb=mob?80:96;
    placed.push({x:0,y:h-36,w:sl+86,h:36},{x:w-mw-14,y:h-mh-14,w:mw+14,h:mh+14},{x:w-bs-16,y:h-bb-4*bs-24,w:bs+16,h:4*bs+28});}
  const ovl=r=>placed.some(q=>r.x<q.x+q.w&&r.x+r.w>q.x&&r.y<q.y+q.h&&r.y+r.h>q.y)||obst.some(q=>q.id!==r.id&&r.x<q.x+q.w&&r.x+r.w>q.x&&r.y<q.y+q.h&&r.y+r.h>q.y);
  G.mapLabels=[];
  for(const L of labels){const fs=L.p<=1?11:10;g.font=`700 ${fs}px "JetBrains Mono",monospace`;const tw=g.measureText(L.t).width,th=fs+2,pad=10;
    const cand=[[L.sx-tw/2,L.sy-pad-th],[L.sx+pad,L.sy-th/2],[L.sx-tw/2,L.sy+pad],[L.sx-pad-tw,L.sy-th/2]];
    let ok=null;for(const [x,y] of cand){const r={x,y,w:tw,h:th,id:L.id};if(x<0||y<0||x+tw>w||y+th>h)continue;if(!ovl(r)){ok=r;break;}}
    if(!ok)continue;placed.push(ok);G.mapLabels.push(ok);g.textAlign='left';g.lineWidth=3;g.strokeStyle='rgba(2,4,10,.9)';g.strokeText(L.t,ok.x,ok.y+fs);g.fillStyle=L.c;g.fillText(L.t,ok.x,ok.y+fs);}
  // 1.0.0 α: подпись над первым закрытым сектором (сам сектор — космос, как пустота вокруг)
  if(!openAllNow()){const F=fogMemo();
    const label=(bb,txt)=>{const L=Math.max(0,X(bb[0])),T_=Math.max(0,Y(bb[1])),R_=Math.min(w,X(bb[2])),B_=Math.min(h,Y(bb[3]));if(R_-L<40||B_-T_<40)return;
      const t2=isMob()?txt.replace(/^СЕКТОР [IVXL]+ · /,''):txt;g.font='700 '+(isMob()?10:11)+'px "JetBrains Mono",monospace';g.textAlign='center';
      const tw=Math.max(g.measureText('ТУМАН ВОЙНЫ').width,g.measureText(t2).width)+6,x0=clamp(L+14,6,w-tw-6),cy=B_-T_>140?clamp(T_+48,T_+22,B_-22):(T_+B_)/2;g.textAlign='left';
      g.globalAlpha=.9;g.fillStyle='#8a9bb3';g.fillText('ТУМАН ВОЙНЫ',x0,cy-8);g.fillStyle='#5f7088';g.fillText(t2,x0,cy+9);g.globalAlpha=1;};
    let i=-1;for(let q=1;q<=10;q++)if(!secSeen(q)){i=q;break;}
    if(i>0)label(WORLD.sectors[i].box,fogHint(i));if(!F.z&&F.sx>WORLD.sectors[11].box[0])label(WORLD.sectors[11].box,'СЕКТОР XII · ПРОЙДИТЕ МИССИЮ 49');}
  // 8. корабль и точки прыжка
  const p=G.player;{const q=(t*1.2)%1;g.strokeStyle=hexA(shipCol().length===7?shipCol():'#8fe9ff',(1-q)*.6);g.lineWidth=1.5;g.beginPath();g.arc(X(p.x),Y(p.y),6+q*16,0,TAU);g.stroke();}
  mapIcon(g,'ship',X(p.x)+(G.riftI>.05&&fx?rnd(-2,2)*G.riftI:0),Y(p.y),{ang:p.ang,col:shipCol()});
  G.mapPts=jumpPoints().map(q=>({...q,px:X(q.x),py:Y(q.y-150)}));
  for(const q of G.mapPts){if(q.px<-20||q.px>w+20||q.py<-20||q.py>h+20)continue;const hv=G.mapHover==='jp'+q.label;g.strokeStyle=mapJpCol(hv);g.lineWidth=hv?2:1;g.beginPath();g.arc(q.px,q.py,13,0,TAU);g.stroke();}
  if(G.mapDeny&&t0<G.mapDeny.until){const d=G.mapDeny;g.strokeStyle='#ff4f6e';g.lineWidth=2;g.beginPath();g.arc(X(d.x)+Math.sin(t0/25)*3,Y(d.y),14,0,TAU);g.stroke();}
  if(G.mapJumpFx){const J=G.mapJumpFx,q=clamp((t0-J.t0)/250,0,1);g.strokeStyle='#ffffff';g.lineWidth=2;g.globalAlpha=1-q*.5;g.beginPath();g.moveTo(X(p.x),Y(p.y));g.lineTo(X(p.x)+(X(J.x)-X(p.x))*q,Y(p.y)+(Y(J.y)-Y(p.y))*q);g.stroke();g.globalAlpha=1;}
  if(G.mapHi&&t0<G.mapHi.until){const q=(t0/400)%1;g.strokeStyle='#8fe9ff';g.lineWidth=2;g.globalAlpha=1-q;g.beginPath();g.arc(X(G.mapHi.x),Y(G.mapHi.y),6+q*22,0,TAU);g.stroke();g.globalAlpha=1;}
  // развёртка радара при открытии
  {const q=clamp((t0-(G.mapOpenT||0))/600,0,1);if(q<1){const R=q*Math.hypot(w,h),cx=X(p.x),cy=Y(p.y);g.fillStyle='rgba(2,4,10,.92)';g.beginPath();g.rect(0,0,w,h);g.arc(cx,cy,R,0,TAU,true);g.fill('evenodd');g.strokeStyle='rgba(143,233,255,.6)';g.lineWidth=2;g.beginPath();g.arc(cx,cy,R,0,TAU);g.stroke();}}
  // 9. линейка масштаба
  {const au=k>.08?5:k>.03?20:50,sl=au*AUNIT*k,bx=12,by=h-16;g.fillStyle='rgba(2,4,10,.65)';g.fillRect(bx-6,by-16,sl+70,26);g.strokeStyle='#7a8ea5';g.lineWidth=1.5;g.beginPath();g.moveTo(bx,by);g.lineTo(bx+sl,by);
    for(let i=0;i<=5;i++){const x=bx+sl*i/5,hh=i%5===0?6:3;g.moveTo(x,by-hh);g.lineTo(x,by+hh*.0);}g.stroke();g.fillStyle='#9fb0c4';g.font='600 10px "JetBrains Mono",monospace';g.textAlign='left';g.fillText(au+' а.е.',bx+sl+8,by+4);}
  // обзор мира
  {const mw=Math.min(w<520?110:150,w*.3),mh=mw*WH/WW,mx=w-mw-10,my=h-mh-10,mk=mw/WW;G.mapOv={mx,my,mw,mh,mk};g.fillStyle='rgba(2,4,10,.85)';g.fillRect(mx,my,mw,mh);
    g.globalCompositeOperation='lighter';g.drawImage(mapNeb(),mx,my,mw,mh);g.globalCompositeOperation='source-over';g.imageSmoothingEnabled=true;{const hd=mapHideDark(),P_=MAPH.P;g.drawImage(hd,P_,P_,hd.width-2*P_,hd.height-2*P_,mx,my,mw,mh);}
    g.strokeStyle='rgba(143,233,255,.35)';g.lineWidth=1;g.beginPath();WORLD.nodes.forEach((n,i)=>{const x=mx+n.x*mk,y=my+n.y*mk;i?g.lineTo(x,y):g.moveTo(x,y);});g.stroke();
    g.strokeStyle='#ffffff';g.lineWidth=1;g.strokeRect(mx+ox*mk,my+oy*mk,V_.span*mk,V_.span*h/w*mk);g.fillStyle=shipCol();g.fillRect(mx+p.x*mk-1.5,my+p.y*mk-1.5,3,3);g.strokeStyle='#26324a';g.strokeRect(mx,my,mw,mh);}
  G.mapItems=items;
  const jc=Object.keys(S.journals).length,cc=Object.keys(S.found).length,ac=Object.keys(S.anomalies).length;
  $('#mapStat').textContent=G.mapStatMsg&&t0<G.mapStatMsg.until?G.mapStatMsg.t:/*DEVW*/(window.DEVW&&DEVW.on()?'ПЕСОЧНИЦА · ':'')+`МИССИИ ${doneCount()}/${NM}${(S.cycle||1)>1?' · ЦИКЛ '+roman(S.cycle):''}`;
  MAPC.ms=performance.now()-t0;
}
function mapTick(dt){const V_=G.mapView;if(!V_)return;if(!G.mapDrag){V_.cx+=V_.vx*dt;V_.cy+=V_.vy*dt;const d=Math.exp(-dt/.14);V_.vx*=d;V_.vy*=d;if(Math.abs(V_.vx)<1)V_.vx=0;if(Math.abs(V_.vy)<1)V_.vy=0;}
  if(Math.abs(V_.tspan-V_.span)>1){const M=G.mapXY,f=1-Math.exp(-dt/.06);const ns=V_.span+(V_.tspan-V_.span)*f;
    if(M&&V_.zx!==undefined){const wx=M.ox+V_.zx/M.k,wy=M.oy+V_.zy/M.k,k2=M.w/ns;V_.cx=wx-(V_.zx-M.w/2)/k2;V_.cy=wy-(V_.zy-M.h/2)/k2;}V_.span=ns;}}
let mapLast=0;
function mapLoop(){if(G.state!=='map'||G.mapTab!=='map')return;const now=performance.now(),dt=Math.min(.05,(now-(mapLast||now))/1000);mapLast=now;mapTick(dt);drawMap();arch69MapNext();/* ARCH·69 A-1 */}
function mapZoom(f,sx,sy){const M=G.mapXY;if(!M||!G.mapView)return;const V_=G.mapView;V_.zx=sx??M.w/2;V_.zy=sy??M.h/2;V_.tspan=clamp(V_.tspan*f,mapSpanMin(),mapSpanMax(M.w,M.h));}
function mapMsg(t){G.mapStatMsg={t,until:performance.now()+2200};}
function mapJumpAt(x,y){
  let best=null,bd=18;for(const q of G.mapPts||[]){const d=Math.hypot(q.px-x,q.py-y);if(d<bd){bd=d;best=q;}}
  if(!best)return false;const p=G.player;const deny=(m,r)=>{mapMsg(m);G.mapDeny={x:best.x,y:best.y-150,until:performance.now()+700};sfx('block');try{mapDenyShow(r);}catch(e){}};
  {const r=jumpDenyReason(best);if(r){deny(JUMP_DENY[r].msg,r);return true;}}
  const go=()=>{G.mapJumpFx=null;G.enemies.forEach(o=>{if(o.zone||o.tugAtk)o.alive=false;});G.zones.forEach(z=>{z.active=false;});if(typeof W58!=='undefined')W58.zones.forEach(z=>{z.active=false;});if(G.event==='zone'||G.event==='tug'){if(G.w&&G.w.tug&&G.event==='tug')G.w.tug.alive=false;G.event=null;}G.riftI=0;G.riftB1=0;
    Object.assign(p,{x:best.x,y:best.y,vx:0,vy:0,dashT:0,trail:[]});p.px=p.x;p.py=p.y;camSnap();closeMap();
    G.shock.push({x:p.x,y:p.y,r:10,R:260,t:0,col:shipCol()});sfx('dash');banner('ПРЫЖОК','ТОЧКА '+best.label);};
  if(G.mapAnimJump===false){go();return true;}
  G.mapJumpFx={x:best.x,y:best.y-150,t0:performance.now()};$('#mapTip').hidden=true;setTimeout(()=>{if(G.state==='map'&&G.mapJumpFx)go();},250);return true;}
// подсказка-карточка
function mapFind(x,y){let best=null,bd=16;for(const it of G.mapItems||[]){if(it.kind==='unk')continue;const d=Math.hypot(it.sx-x,it.sy-y);if(d<bd){bd=d;best=it;}}return best;}
function mapTipHTML(it){const S=G.save,p=G.player,dist=fmtAU(Math.hypot(it.x-p.x,it.y-p.y));let h='';
  const jp=(G.mapPts||[]).find(q=>Math.abs(q.x-it.x)<260&&Math.abs(q.y-150-it.y)<260);
  if(it.o.n){const n=it.o.n,M=MISSIONS[n.m-1],st=nodeState(n.m),md=medalCount(S.medals[n.m]),bd=S.bestDiff[n.m];
    h=`<b>${pad2(n.m)} · ${M.name}</b><span>${n.boss?'КОМНАТА БОССА · ДОРАБОТКА · ':''}${st==='done'?'ПРОЙДЕНА':st==='open'?'ДОСТУПНА':'ПОМЕХИ'} · ${dist}</span>${st==='done'?`<span>медали ${md}/4${bd!==undefined?' · лучшая сложность '+DIFF[DIFF_KEYS[bd]].name:''}</span>`:''}`;}
  else{const names={shop:it.o.q?it.o.q.name:'МАСТЕРСКАЯ',hangar:WORLD.hangar.name,arsenal:WORLD.arsenal.name+(arsOpen()?'':' · запечатан'),beacon:'МАЯК СЕКТОРА '+roman((it.o.sec||0)+1),anom:'АНОМАЛИЯ · '+(it.o.a?it.o.a.name:''),relay:'РЕТРАНСЛЯТОР',cache:'ТАЙНИК',journal:'БОРТЖУРНАЛ',abyss:'∞ БЕЗДНА',gate:'ВОРОТА СЕКТОРА',lost:'ПОТЕРЯННЫЙ ЛОМ'};
    h=`<b>${names[it.kind]||''}</b><span>${sectorName(it.x,it.y)} · ${dist}</span>`;}
  {const lab=it.o.n?'МИССИЯ '+pad2(it.o.n.m):({shop:'МАСТЕРСКАЯ',hangar:'ХРАНИЛИЩЕ',beacon:'МАЯК',anom:'АНОМАЛИЯ',relay:'РЕТРАНСЛЯТОР',cache:'ТАЙНИК',journal:'ЖУРНАЛ',abyss:'БЕЗДНА',gate:'ВОРОТА',lost:'ЛОМ'})[it.kind]||'ЦЕЛЬ';h+=`<div class="wc-row"><button class="wbtn" data-mcourse="${Math.round(it.x)},${Math.round(it.y)},${lab}">${G.course&&Math.abs(G.course.x-it.x)<2&&Math.abs(G.course.y-it.y)<2?'КУРС ПРОЛОЖЕН':'ПРОЛОЖИТЬ КУРС'}</button>`+(jp?`<button class="wbtn amber" data-mjump="${jp.label}">ПРЫЖОК</button>`:'')+'</div>';}return h;}
function mapShowTip(it,pin){const tip=$('#mapTip');if(!it){if(!G.mapTipPin){tip.hidden=true;}G.mapHover=null;return;}
  G.mapHover=it.kind+it.x+','+it.y;tip.innerHTML=mapTipHTML(it);tip.hidden=false;tip.classList.toggle('bottom',touchMode);
  if(!touchMode){const M=G.mapXY;tip.style.left=clamp(it.sx+16,4,M.w-230)+'px';tip.style.top=clamp(it.sy-10,4,M.h-90)+'px';}else{tip.style.left='';tip.style.top='';}
  if(pin)G.mapTipPin=it;}
$('#mapTip').addEventListener('click',e=>{const c=e.target.closest('[data-mcourse]');if(c){const [x,y,...l]=c.dataset.mcourse.split(',');G.course={x:+x,y:+y,label:l.join(',')};$('#mapTip').hidden=true;G.mapTipPin=null;closeMap();if(G.player)floater(G.player.x,G.player.y-44,'КУРС · '+G.course.label,'#8fe9ff');return;}const b=e.target.closest('[data-mjump]');if(!b)return;const q=(G.mapPts||[]).find(z=>z.label===b.dataset.mjump);if(q)mapJumpAt(q.px,q.py);});
{const MP={ptr:new Map(),moved:0,pinch:0,lx:0,ly:0,lt:0};const cvM=$('#mapC');
  cvM.addEventListener('pointerdown',e=>{if(G.state!=='map')return;cvM.setPointerCapture(e.pointerId);MP.ptr.set(e.pointerId,{x:e.clientX,y:e.clientY});MP.moved=0;G.mapDrag=true;MP.lt=performance.now();
    if(G.mapView){G.mapView.vx=0;G.mapView.vy=0;}if(MP.ptr.size===2){const [a,b]=[...MP.ptr.values()];MP.pinch=Math.hypot(a.x-b.x,a.y-b.y);}});
  cvM.addEventListener('pointermove',e=>{const r=cvM.getBoundingClientRect();const q=MP.ptr.get(e.pointerId);
    if(!q){if(e.pointerType==='mouse'&&!G.mapTipPin)mapShowTip(mapFind(e.clientX-r.left,e.clientY-r.top),false);
      const jp=(G.mapPts||[]).find(z=>Math.hypot(z.px-(e.clientX-r.left),z.py-(e.clientY-r.top))<16);if(jp)G.mapHover='jp'+jp.label;cvM.style.cursor=jp?'pointer':'grab';return;}
    if(!G.mapXY)return;const dx=e.clientX-q.x,dy=e.clientY-q.y;
    if(MP.ptr.size===2){q.x=e.clientX;q.y=e.clientY;const [a,b]=[...MP.ptr.values()],d=Math.hypot(a.x-b.x,a.y-b.y);if(MP.pinch>0&&d>0){const V_=G.mapView;V_.zx=(a.x+b.x)/2-r.left;V_.zy=(a.y+b.y)/2-r.top;V_.tspan=V_.span=clamp(V_.span*MP.pinch/d,mapSpanMin(),mapSpanMax(G.mapXY.w,G.mapXY.h));}MP.pinch=d;MP.moved=99;return;}
    MP.moved+=Math.abs(dx)+Math.abs(dy);if(MP.moved>6){const V_=G.mapView,now=performance.now(),dtm=Math.max(1,now-MP.lt)/1000;V_.cx-=dx/G.mapXY.k;V_.cy-=dy/G.mapXY.k;V_.vx=-dx/G.mapXY.k/dtm*.6;V_.vy=-dy/G.mapXY.k/dtm*.6;MP.lt=now;q.x=e.clientX;q.y=e.clientY;cvM.style.cursor='grabbing';}});
  const up=e=>{const had=MP.ptr.has(e.pointerId);MP.ptr.delete(e.pointerId);if(MP.ptr.size<2)MP.pinch=0;if(MP.ptr.size===0)G.mapDrag=false;if(!had||G.state!=='map')return;
    if(MP.moved>6&&G.mapView&&performance.now()-MP.lt>80){G.mapView.vx=0;G.mapView.vy=0;}
    if(MP.moved<=6&&e.type==='pointerup'){const r=cvM.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top,O=G.mapOv;
      if(O&&x>=O.mx&&x<=O.mx+O.mw&&y>=O.my&&y<=O.my+O.mh){G.mapView.cx=(x-O.mx)/O.mk;G.mapView.cy=(y-O.my)/O.mk;return;}
      if(e.pointerType==='mouse'&&mapJumpAt(x,y))return;
      const it=mapFind(x,y);if(it){G.mapTipPin=null;mapShowTip(it,true);}
      else if(e.pointerType!=='mouse'){const jp=(G.mapPts||[]).find(z=>Math.hypot(z.px-x,z.py-y)<18);if(jp){G.mapTipPin=null;const tip=$('#mapTip');tip.innerHTML=`<b>ТОЧКА ПРЫЖКА ${jp.label}</b><span>${sectorName(jp.x,jp.y)}</span><button class="wbtn amber" data-mjump="${jp.label}">ПРЫЖОК</button>`;tip.hidden=false;tip.classList.add('bottom');G.mapTipPin=jp;}else{G.mapTipPin=null;$('#mapTip').hidden=true;}}
      else{G.mapTipPin=null;$('#mapTip').hidden=true;}}};
  cvM.addEventListener('pointerup',up);cvM.addEventListener('pointercancel',up);cvM.addEventListener('pointerleave',()=>{if(!G.mapTipPin){$('#mapTip').hidden=true;G.mapHover=null;}});
  cvM.addEventListener('wheel',e=>{if(G.state!=='map')return;e.preventDefault();const r=cvM.getBoundingClientRect();mapZoom(e.deltaY>0?1.25:1/1.25,e.clientX-r.left,e.clientY-r.top);},{passive:false});
  $('#mapZin').onclick=()=>mapZoom(1/1.4);$('#mapZout').onclick=()=>mapZoom(1.4);$('#mapZme').onclick=()=>{const p=G.player;G.mapView.cx=p.x;G.mapView.cy=p.y;if(isMob()){G.mapView.zx=undefined;G.mapView.tspan=mapSpanDef();}};$('#mapZall').onclick=()=>{G.mapView.zx=undefined;G.mapView.tspan=1e9;G.mapView.cx=WW/2;G.mapView.cy=WH/2;};}
function buildMapLegend(){const L=$('#mapLeg');if(!L||L.dataset.ok)return;L.dataset.ok=1;
  const it=[['open','доступно'],['done','пройдено'],['locked','закрыто · туман'],['boss','комната босса'],['beacon','маяк сектора'],['shop','мастерская'],['hangar','хранилище'],['arsenal','арсенал'],['relay','ретранслятор'],['anom','аномалия'],['abyss','Бездна'],['wreck','корпус VØID'],['wreckx','чужой обломок'],['frag','фрагмент памяти'],['lost','потерянный лом']];
  const box=L.querySelector('.legi');box.innerHTML='';for(const [k,n] of it){const s=document.createElement('span'),c=document.createElement('canvas');c.width=c.height=28*DPR;c.style.width=c.style.height='18px';const g=c.getContext('2d');g.scale(DPR*18/28*1.55,DPR*18/28*1.55);
    mapIcon(g,k,9,9,{small:true,md:2,ok:true});s.appendChild(c);s.appendChild(document.createTextNode(n));box.appendChild(s);}
  const sp=document.createElement('span');sp.innerHTML='<b style="color:#ff4f6e">?</b> неизвестные в Разломе';box.appendChild(sp);
  L.open=innerWidth>640&&!isMob();}

// ---- Разлом (0.4.1): помехи за пределами секторов и Неизвестные ----
function riftEdges(){if(MAPC.edge)return MAPC.edge;const segs=[],STEP=200;
  for(const sc of WORLD.sectors){const [x0,y0,x1,y1]=sc.box;
    for(const [ax,ay,bx,by,nx,ny] of [[x0,y0,x1,y0,0,-1],[x1,y0,x1,y1,1,0],[x0,y1,x1,y1,0,1],[x0,y0,x0,y1,-1,0]]){const L=Math.hypot(bx-ax,by-ay),n=Math.max(1,Math.round(L/STEP));
      for(let i=0;i<n;i++){const u0=i/n,u1=(i+1)/n,mx=ax+(bx-ax)*(u0+u1)/2,my=ay+(by-ay)*(u0+u1)/2;
        if(!inSectors(mx+nx*12,my+ny*12)&&inSectors(mx-nx*12,my-ny*12))segs.push([ax+(bx-ax)*u0,ay+(by-ay)*u0,ax+(bx-ax)*u1,ay+(by-ay)*u1,nx,ny]);}}}
  return MAPC.edge=segs;}
function riftInfo(x,y){let bd=1e18,bx=x,by=y,bn=null;for(const s of riftEdges()){const dx=s[2]-s[0],dy=s[3]-s[1],L2=dx*dx+dy*dy;let u=((x-s[0])*dx+(y-s[1])*dy)/L2;u=u<0?0:u>1?1:u;
    const px=s[0]+dx*u,py=s[1]+dy*u,d=(x-px)*(x-px)+(y-py)*(y-py);if(d<bd){bd=d;bx=px;by=py;bn=s;}}
  const d=Math.sqrt(bd);return {d:inSectors(x,y)?-d:d,nx:bx,ny:by,ox:bn?bn[4]:0,oy:bn?bn[5]:0};}
const smooth=(a,b,v)=>{const q=clamp((v-a)/(b-a),0,1);return q*q*(3-2*q);};
function riftTarget(d){if(d<=-300)return 0;if(d<=0)return .2*smooth(-300,0,d);if(d<=800)return .2+.5*smooth(0,800,d);return .7+.3*smooth(800,1600,d);}
function updateRift(dt){
  const p=G.player,R_=riftInfo(p.x,p.y);G.riftD=R_.d+riftShift();const tgt=G.riftDeath?1:riftTarget(G.riftD),I0=G.riftI||0;
  G.riftI=I0+(tgt-I0)*(1-Math.exp(-dt/(tgt>I0?.6:.9)));if(G.riftI<.002)G.riftI=0;const I=G.riftI;
  let ox=p.x-R_.nx,oy=p.y-R_.ny;const ol=Math.hypot(ox,oy);if(R_.d>0&&ol>1){ox/=ol;oy/=ol;}else{ox=R_.ox;oy=R_.oy;}
  G.riftBack={x:R_.nx-ox*150,y:R_.ny-oy*150};
  if(I>=.15&&!G.riftB1){G.riftB1=1;banner('ГРАНИЦА СЕКТОРОВ','ПРОСТРАНСТВО НЕСТАБИЛЬНО');sfx('warn');}
  if(I>=.35&&!G.riftB2){G.riftB2=1;banner('РАЗЛОМ','НЕИЗВЕСТНЫЕ КОНТАКТЫ · ВЕРНИТЕСЬ В СЕКТОР');sfx('warn');}
  if(I<.05){G.riftB1=0;G.riftB2=0;}
  const U=G.unk||(G.unk=[]);
  if(I<.25||G.riftDeath){if(U.length)U.length=0;G.unkT0=0;}
  else if(I>=.35||U.length){const want=I<.35?U.length:Math.min(4,1+Math.floor((I-.35)/.65*3.999));
    while(U.length<want){U.push({a:Math.atan2(oy,ox)+rnd(-Math.PI/4,Math.PI/4),r:rnd(700,1000),dir:Math.random()<.5?1:-1,cd:rnd(.6,1.4)});if(!G.unkT0)G.unkT0=G.t;}
    while(U.length>want)U.pop();}
  const base=Math.atan2(oy,ox);
  for(const u of U){u.a+=u.dir*.15*dt;const da=angDiff(u.a,base);if(Math.abs(da)>Math.PI/4){u.a=base+Math.sign(da)*Math.PI/4;u.dir*=-1;}
    u.x=p.x+Math.cos(u.a)*u.r;u.y=p.y+Math.sin(u.a)*u.r;
    if(I<.35||p.hp<=0||G.deadT>0)continue;u.cd-=dt;
    if(u.cd<=0){u.cd=(2.2-1.5*clamp((I-.35)/.65,0,1))*rnd(.85,1.15);
      const dist=Math.hypot(p.x-u.x,p.y-u.y),tt=dist/980;let tx=p.x+p.vx*tt,ty=p.y+p.vy*tt;
      if(G.t-G.unkT0<2.5){const side=Math.atan2(ty-u.y,tx-u.x)+Math.PI/2,off=rnd(120,180)*(Math.random()<.5?1:-1);tx+=Math.cos(side)*off;ty+=Math.sin(side)*off;}
      const a=Math.atan2(ty-u.y,tx-u.x)+rnd(-.08,.08);G.eb.push({x:u.x,y:u.y,vx:Math.cos(a)*980,vy:Math.sin(a)*980,dmg:0,col:'#ff4f6e',r:4,life:1.6,rift:true});
      if(AU.ctx&&SET.sfx){const c=AU.ctx,t=c.currentTime,o=c.createOscillator(),g=c.createGain(),pn=c.createStereoPanner();o.type='square';o.frequency.value=2200;g.gain.setValueAtTime(.02,t);g.gain.exponentialRampToValueAtTime(.0001,t+.04);pn.pan.value=clamp((u.x-p.x)/800,-1,1);o.connect(g);g.connect(pn);pn.connect(AU.sfx);o.start(t);o.stop(t+.05);}}}
  if(I<.35)for(const b of G.eb)if(b.rift&&b.life>.3)b.life=.3;
  // аномалия и крейсер
  if(G.anom&&G.riftD>0){banner('АНОМАЛИЯ ПРОВАЛЕНА','ВЫ ПОКИНУЛИ СЕКТОР · ПОВТОР ЧЕРЕЗ 30 С');(G.anomCd||(G.anomCd={}))[G.anom.a.id]=G.t+30;endAnom();}
}
function riftKill(){/*DEVW*/if(window.DEVW&&DEVW.on()&&G.dev.god)return;const p=G.player;if(!p||p.hp<=0||G.deadT>0)return;p.hp=0;G.riftDeath=1;G.riftI=1;
  for(let i=0;i<70;i++){const a=rnd(0,TAU),v=rnd(40,380);part(p.x,p.y,Math.cos(a)*v,Math.sin(a)*v,rnd(.4,1.3),Math.random()<.5?'#ffffff':shipCol(),rnd(1.5,3.5));}
  sfx('bigboom');shake(14);G.deadT=1.8;G.save.riftDeaths=(G.save.riftDeaths||0)+1;banner('ПРОСТРАНСТВО ОТТОРГЛО КОРАБЛЬ','ВОСПОМИНАНИЕ ИЗЪЯТО');storyDeath(true);}
function riftNoise(){if(MAPC.noise)return MAPC.noise;const c=document.createElement('canvas');c.width=c.height=160;const g=c.getContext('2d'),im=g.createImageData(160,160);
  for(let i=0;i<im.data.length;i+=4){const v=Math.random()*255|0;im.data[i]=v;im.data[i+1]=v;im.data[i+2]=Math.min(255,v+20);im.data[i+3]=Math.random()<.45?255:0;}g.putImageData(im,0,0);return MAPC.noise=c;}
// экранные помехи (после отрисовки мира, экранные координаты)
function drawRiftFx(I,t){
  if(I<.02&&!G.riftDeath)return;const w=cv.width,h=cv.height,fx=SET.fx;ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  let src=cv;if(I>=.15){let sn=MAPC.snap;if(!sn){sn=MAPC.snap=document.createElement('canvas');}if(sn.width!==w||sn.height!==h){sn.width=w;sn.height=h;}const sg=sn.getContext('2d');sg.globalCompositeOperation='copy';sg.drawImage(cv,0,0);src=sn;}
  if(fx&&I>=.35){const n=8+Math.round(6*I),sh=Math.ceil(h/n),amp=(I-.35)/.65*18*DPR;for(let i=0;i<n;i++){const off=Math.sin(t*6+i*.9)*amp;if(Math.abs(off)<.5)continue;ctx.drawImage(src,0,i*sh,w,sh,off,i*sh,w,sh);}}
  if(I>=.15){const n=2+Math.round(4*I);for(let i=0;i<n;i++){const y=Math.random()*h,bh=(4+Math.random()*24)*DPR,off=(Math.random()-.5)*2*(4+26*I)*DPR;ctx.drawImage(src,0,y,w,bh,off,y,w,bh);}}
  if(fx&&I>=.25){const o=(1+5*(I-.25)/.75)*DPR;ctx.globalCompositeOperation='screen';ctx.globalAlpha=.2;ctx.drawImage(src,(t*60|0)%2?o:-o,o*.3);
    ctx.globalCompositeOperation='multiply';ctx.globalAlpha=.06*I;ctx.fillStyle='#ff3060';ctx.fillRect(0,0,w,h);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;}
  const pat=ctx.createPattern(riftNoise(),'repeat'),ga=Math.min(.82,.04+.5*Math.pow(I,1.4)+(I>.85?(I-.85)*2.2:0));ctx.translate(Math.random()*160,Math.random()*160);ctx.globalAlpha=ga;ctx.fillStyle=pat;ctx.fillRect(-160,-160,w+320,h+320);ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;
  if(I>=.5){const v=ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*.25,w/2,h/2,Math.max(w,h)*.7);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,`rgba(4,2,8,${Math.min(.85,(I-.5)*1.5)})`);ctx.fillStyle=v;ctx.fillRect(0,0,w,h);
    if(fx&&Math.random()<.04*I){ctx.fillStyle='rgba(0,0,0,.85)';ctx.fillRect(0,Math.random()*h,w,(10+Math.random()*60)*DPR);}}
  if(G.riftDeath&&G.deadT>0){const q=clamp((1.8-G.deadT)/1.8,0,1);ctx.fillStyle=`rgba(2,2,6,${smooth(.4,1,q)})`;ctx.fillRect(0,0,w,h);}
  ctx.restore();}


