/* ===== 1.1.0 α · «Чистый интерфейс»: тексты без технического шума ===== */
const VER_TAG='1.5.35 α';
function mTitle(M){let n=mName(M);const i=n.indexOf(' · ');if(i>0&&String(M.sector||'').toLowerCase().includes(n.slice(0,i).toLowerCase()))n=n.slice(i+3);return n.charAt(0).toUpperCase()+n.slice(1);}
function dangerTag(M){const SS=M&&M.gen&&SEC_SCALE[M.sec];if(!SS)return '';const n=clamp(Math.ceil((M.sec-1)/2),1,5);
  return `<span class="tag threat">ОПАСНОСТЬ ${'●'.repeat(n)}${'○'.repeat(5-n)}</span>`;}
const MECH_FIX={'ПЕРЕДАЧА 45 С':'ПЕРЕДАЧА','ЧТЕНИЕ · 5 ПИЛОТОВ':'ЧТЕНИЕ ПИЛОТОВ','ПУСК · 3 КОНТАКТА · 10 С':'ПУСК','4 СТАДИИ · БЕЗ КОНТРОЛЬНЫХ ТОЧЕК':'БЕЗ КОНТРОЛЬНЫХ ТОЧЕК',
  'ПРОСТРАНСТВО ДЫШИТ · ВЫДОХ, ВЫДОХ, ВДОХ':'ПРОСТРАНСТВО ДЫШИТ','АФФИКСЫ':'ЭЛИТА','КОМНАТА БОССА · ДОРАБОТКА':'КОМНАТА БОССА','СЕКТОР В РАЗРАБОТКЕ':''};
function mechTags(M){return (M.mech||[]).filter(k=>!/^ВРАГИ СЕКТОРА/.test(k)).map(k=>k in MECH_FIX?MECH_FIX[k]:k.split(' · ').filter(x=>!/\d/.test(x)).join(' · ')).filter(Boolean);}
const DIFF_NOTE={easy:'Спокойный бой для первого прохождения.',mid:'Враги крепче и их больше. Лома больше.',hard:'Враги быстрее и бьют намного больнее, предупреждений об атаках нет. Лома гораздо больше.'};

/* подсказки брифинга: что делать, без чисел */
const HINTS_110={
 1:['WASD или стрелки — движение. Огонь — сам, по ближайшей цели.','Собирайте осколки данных с врагов — из них растут модули.'],
 2:['ПРОБЕЛ — рывок сквозь снаряды.','Энергоячейки можно подобрать, когда они перестанут мерцать.'],
 3:['Таран сначала чертит линию — уходите вбок. Роевик распадается на осколки.','E или Shift — импульс, когда шкала полна: сносит снаряды и отбрасывает врагов.'],
 4:['Клик по врагу (или касание) — огонь только по нему.','Щитоносец прикрывает соседей — снимайте его первым.'],
 5:['Копейщик целится, затем бьёт лучом. Линия вспыхнула — рывок.','Берегите импульс для тяжёлых моментов.'],
 6:['Гвардию закрывает щит спереди — заходите сбоку, тараньте рывком или бейте импульсом.','Ядро неуязвимо, пока живы заряды. Разбейте их все.','Каждая фаза — новые атаки.'],
 7:['Маяк — цель миссии. Стойте в кольце вокруг него, чтобы заряжать.','Везите энергоячейки в кольцо — они ускоряют заряд.','Ромб над врагом — летит к маяку, треугольник — к вам, кольцо — диверсант. Пиявок снимайте первыми.','Маяк вспыхивает на рисках шкалы и даёт модуль. Разрушен маяк — провал.'],
 8:['Целые линии ретрансляторов ускоряют заряд. Порванную линию чините, пролетев вдоль неё.','Астероиды — укрытие для всех. Из некоторых выпадают ячейки.','Буксир тащит астероид к маяку — перебейте трос.','Круг на земле — сюда упадёт снаряд Осадника. Встаньте в него, чтобы прикрыть маяк.'],
 9:['Видно только у маяка и вокруг корабля. Автоприцел в темноте слеп — вспышки маяка освещают всё.','В ионной буре рывок не работает, зато враги в ней подсвечены — бейте ручным прицелом.','Иногда маяку нужна продувка: заряд стоит, маяк уязвимее.','Цветной пунктир вокруг врага — элита с особым свойством.'],
 10:['Полная шкала — начинается передача. Держите заряд высоким, пока она идёт.','С передачей прилетает Глушитель. Нужно и закончить передачу, и сбить его.','Глушитель ставит ложный маяк — отметьте его самого кликом.'],
 11:['Изморозь замораживает корабль — рывок и импульс стряхивают лёд.'],
 12:['Архиваторы повторяют ваш маршрут ледяными копиями — не летайте по прямой.','Запись прерывают урон или рывок сквозь луч.'],
 13:['Сначала снимайте Изморозь: замёрзший корабль записывается быстрее.','Щит Ледяной гвардии раскалывается после серии попаданий.'],
 14:['Инвентаризатор описывает ваши системы — разбейте ячейку с той, что нужнее. Разбитая ячейка открывает его корпус.','Позже он выпускает ваши прошлые записи и замораживает арену с краёв — печати ломаются рывком. В финале придётся выбрать.'],
 15:['В облаках ржавчины корпус изнашивается до конца миссии.','Сектор понемногу изнашивает корпус и сам.'],
 16:['Ремонтники чинят врагов и поднимают павших — доломайте каркас рывком.','Ржавые враги ничего не дают.'],
 17:['Коррозийник, погибший среди стаи, снимает с неё броню. Ремонтник рядом — первая цель.','Снаряды ржавчины сбивают щит.'],
 18:['Обод берёт корабль в кольцо. Его узел уязвим в пробоине и после красного дока.','Зелёный док снимает износ, но забирает модуль. Красный открывает узел, но зовёт ремонтников.'],
 19:['Часть волны приходит коконами — они вылупляются врагами сильнее. Решайте, что важнее: враг или кладка.'],
 20:['Пестуны рассаживают коконы — ловите их до посадки.','Мембрану пробивайте зарядом, «Разрывом», импульсом или рывком.','Воронки тянут корабль в ритме сердца — летайте между ударами.'],
 21:['Певчий ускоряет стаю — снимайте его первым.','Пуповины лечат друг друга — рывок сквозь трос рвёт связь. Поглотителя бейте зарядом или импульсом.','Если увидите Последнего из вида — решайте сами: он не атакует.'],
 22:['Кормилица неуязвима, пока целы пуповины — рвите их зарядом, «Разрывом» или импульсом.','В кольцах песни есть окно — пролетайте в него. Молоко из утробы ненадолго ускоряет темп.'],
 23:['Снаряды Стражей глушат двигатели, а потом и рывок. Повреждение спадает само.','Дрейфующие корпуса — укрытие, но у края раздавят.'],
 24:['Абордажника стряхивайте рывком или импульсом. Брандер подрывайте среди врагов.','Курсанты уходят, если их не добивать. Один из них — Тео.'],
 25:['Связист ведёт отсчёт — потом стреляют все разом. Снимите его или уйдите рывком.','Крейсер-перебежчик бронирован с бортов — бейте в нос или корму.'],
 26:['Без двигателей скелет линкора встаёт, залпы реже. Держитесь у носа или кормы.','Эхо старой битвы: можно помочь любой стороне.'],
 27:['«Последний довод» бьёт бортами — держитесь у носа или кормы. Выбитый двигатель — и залпы начнут мести арену.','Быстро разбейте последнюю волну — флагман выйдет без охраны. В финале — выбор.'],
 28:['Лаборант чинит раненых — снимайте его первым.','Цвет брака — его поведение: красный таранит, жёлтый стреляет, серый держит урон.'],
 29:['Конвейерный щит ловит обычные снаряды — заряд и «Разрыв» проходят насквозь.','Штамп Печати сбрасывается рывком или импульсом.','В голубом облаке все снаряды летят медленнее.'],
 30:['Не стойте в жёлтом конусе Инспектора.','Утилизатор крадёт лом и опыт — убейте его, и он вернёт всё.','Иногда гаснет свет — видно только рядом.'],
 31:['Разбивайте заготовки, пока сборка не закончена, — иначе выйдет Серийник с вашим оружием.','Пульт в углу останавливает конвейеры. После удара пресса бейте в матрицу.'],
 32:['Отзвук повторяет ваши выстрелы — снимайте его первым. Импульс стирает его память.'],
 33:['Петля возвращается — добейте её сразу или разбейте след импульсом. Пока след горит, волна не кончится.','Иногда гаснет свет.'],
 34:['Волна Изнанки переворачивает управление — уходите от неё или проскочите рывком.','Изнанка хрупкая — убейте её до первой волны.'],
 35:['Петли и Отзвуки вместе — каждый промах может вернуться.','Здесь гаснет свет.'],
 36:['Паломники мирные. Не задевайте их: звено ответит вашим же оружием.','Изнанка встречается редко — держите рывок наготове.'],
 37:['Все силы Истока разом. Паломники летят мимо — не стреляйте по ним.','Здесь гаснет свет.'],
 38:['Кольца излучателей глотают обычные снаряды — стреляйте в проходы. Паломников будите импульсом.','Когда колодец пишет вас (● REC), не стойте на месте — там пролетит ваш Отзвук.','Якоря петли разбейте до нуля счётчика.'],
 39:['Ленты кровотока сносят корабль — рывок по течению дальше.','Бейте клапан сразу после открытия. Лейкоциты охотятся тройкой — выйдите из треугольника.','Где-то за столбом — тайник.'],
 40:['Тревога растёт в бою и спадает в затишье. Сбейте Фагоцитов облавы — станет тише.','Смотрителей бейте в спину. Шлюзы иногда закрываются.'],
 41:['Тревога та же: растёт в бою, спадает в затишье. Облаву гасите, сбивая её Фагоцитов.','Рывок сквозь луч между нейронами рвёт связь. Иммунного стража обходите сбоку, эмбрионы разбейте до того, как вылупятся.'],
 42:['Сердце открыто между ударами. Бейте за миг до удара. Рывок сквозь волну — без урона.','Стрелки у сердца показывают будущие проходы, лента внизу — следующие удары.','В финале пролетайте ключи ритма по часовой стрелке. Нужно два запуска.'],
 43:['Обломки памяти — укрытия. Держитесь рядом со Свидетелями — они полетят за вами.','Ластик чиркает через арену — уходите с линии. Круг — место приземления Кляксы.'],
 44:['Арена — страница: строки-стены переписываются, шкалы интерфейса пропадают.','Импульс стирает строку снарядов. Рывок сквозь луч Корректора переворачивает ремонт.'],
 45:['Прилив идёт вдоль берега — ищите проход или проскочите рывком.','Не держите прицел на Безымянном — он ответит лучом.'],
 46:['Уязвимы только открытые глаза Смотрителя. Разбитый маяк оглушает его.','Щит маяка тает вблизи. Маяк, который давно не трогали, чинит соседа.'],
 47:['Читайте пилотов по порядку: держитесь в кольце у каждого. Память ответит теми, кто их убил.'],
 48:['Поднимите три контакта — подлетите или выстрелите. Потом держитесь в круге «ПУСК».','Связиста бейте первым.'],
 49:['Держитесь в полосе — снаружи стирание. Полоса ползёт и сжимается к выходу.','Победа открывает сектор XII.'],
 50:['Войдите в комнату — VØID-000 выйдет сам. Карта и телепорт глохнут.','Его слабые места — корма, остывание после атаки и полная шкала сбоя.','Полоса «ДЫХАНИЕ» показывает следующие вдохи и выдохи. Снаружи — стирание.','Гибель — цикл заново у кнопки, с разбором.']
};
for(const m in HINTS_110){const M=MISSIONS[m-1];if(M)M.hint=HINTS_110[m].slice();}

/* описания угроз в справочнике: что делает и как с этим быть */
const EDESC_110={
 scout:'Быстро сближается и таранит. Опасен стаей.',splitter:'При гибели распадается на быстрые осколки.',
 miner:'Расставляет мины: взведённая мина взрывается, если подлететь. Мины можно сбивать.',
 shielder:'Держится позади и закрывает союзников полем — по ним почти не проходит урон. Снимайте первым.',
 lancer:'Ведёт вас прицелом, затем бьёт лучом через весь экран. Линия прицела — сигнал к рывку.',
 seeker:'Самонаводящийся снаряд Стража и Глушителя. Сбивается парой попаданий.',
 boss:'Ядро неуязвимо, пока живы заряды. Без зарядов ядро уходит в перегрузку: атаки замирают, ядро уязвимее.',
 moth:'Летит стаей на свет маяка и бьётся о него. Хрупкий — стаю у маяка удобно снимать импульсом.',
 leech:'Прилипает к маяку и тянет из него заряд. Снимайте пиявок первыми.',
 carrier:'Медленный транспорт: у маяка выпускает мотыльков. Сбивайте на подлёте.',
 jammerS:'Встаёт у края экрана. Пока жив, маяк заряжается медленнее.',
 hive:'Неподвижный узел у края. Раз за разом выпускает мотыльков.',
 shocker:'Разряд ненадолго отключает ваш рывок. После гибели оставляет такое же поле.',
 twin:'Пара, связанная лучом: убитый воскресает, пока жив второй. Добивайте обоих.',
 hunter:'Повторяет ваши рывки с задержкой — туда, куда вы прыгнули. Рывок в сторону и обратно — и он промахнётся.',
 commander:'Ускоряет врагов рядом. Без него наступление вязнет.',
 jam:'Источник помех. Сначала антенны глушат маяк и закрывают ядро, потом ложный маяк уводит автоприцел, в финале — тьма: ядро открыто только во вспышки маяка.',
 frost:'Стреляет медленными кристаллами: каждое попадание — слой льда, от нескольких слоёв корабль замерзает. Рывок или импульс сбрасывают лёд.',
 archivist:'Ведёт корабль лучом-сеткой, затем выпускает ледяную копию по вашему маршруту. Прервите запись уроном или рывком сквозь луч, летайте ломано.',
 inventor:'Описывает ваши системы: успейте разбить ячейку с нужной подписью, иначе система уйдёт на хранение. Разбитая ячейка открывает его корпус.',
 corroder:'Ставит облака ржавчины: внутри корабль теряет максимум прочности. Его снаряды сбивают щит. Гибель снимает броню с врагов рядом.',
 repairer:'Не стреляет: чинит раненых и собирает павших заново. Каркас павшего доломайте рывком. Снимайте первым.',
 obheart:'Станция-кольцо окружает корабль; наружу — только через пробоину. Узел уязвим в пробоине, при переезде и после красного дока. Зелёный док чинит, но забирает модуль.',
 cocoon:'Не стреляет и не двигается. Скоро вылупится врагом сильнее обычного. Песня Певчего ускоряет кладку.',
 unborn:'Мелкий роевой: сначала неуязвим, потом бросается на корабль. Импульс снимает всю стаю.',
 pestun:'Несёт коконы и рассаживает их по углам. Ловите до посадки.',
 membrane:'Живая стена между вами и стаей. Обычный огонь пробивает её медленно — бейте зарядом, «Разрывом», импульсом или рывком.',
 sporer:'Раскидывает облака спор: внутри ваши снаряды вязнут и сворачивают. Импульс разгоняет споры.',
 absorber:'Глотает обычные снаряды и растёт, потом лопается веером. Бейте зарядом, импульсом или тараном.',
 cord:'Пара на живом тросе: лечат друг друга. Убейте одного — второй ослабнет. Рывок сквозь трос рвёт связь.',
 singer:'Не атакует: поёт, ускоряя стаю и коконы рядом. Цель номер один.',
 embryo:'Рождается слабым и дорастает до Гвардии со щитом. Убить рано — дёшево, поздно — дорого.',
 lastkind:'Не атакует и уходит за край арены. Убить — щедрая награда. Отпустить — его запомнят.',
 nurse:'Неуязвима, пока целы пуповины: рвите их зарядом, «Разрывом» или импульсом и рвите нить, которой она кормит утробу. В кольцах песни ищите окно; позже тело открыто только на вдохе.',
 battery:'Турель на дрейфующем корпусе: бьёт залпом в свою сторону и поворачивается вместе с корпусом. Заходите со спины.',
 boarder:'Присасывается к кораблю: замедляет и изнашивает броню. Стряхните рывком или импульсом.',
 fireship:'Разгоняется к вам и взрывается. Подорванный раньше жжёт соседей — встречайте его посреди стаи.',
 signaller:'Ведёт отсчёт — и враги на экране стреляют разом. Снимайте первым или пережидайте залп рывком.',
 turncoat:'Элита. Борта почти неуязвимы — бейте в нос и корму. Его попадания глушат ваши двигатели.',
 cadet:'Слабый и неточный. Подранок уходит из боя — не добивайте, и он вас запомнит.',
 linkor:'Огромный корпус с батареями и двумя двигателями, бьёт бортовыми залпами. Выбейте двигатели — он встанет. Держитесь у носа или кормы.',
 flagship:'Флагман флота. Выбитые секции снимают броню с рубки. В луче прожектора залп становится прицельным — прячьтесь за корпусами.',
 labrat:'Лечит самого раненого врага зелёным лучом. Луч рвётся от попадания в Лаборанта и от рывка сквозь него.',
 defect:'Копия с ошибкой: то и дело меняет поведение. Цвет подсказывает режим — стрелок, таран, минёр или сторож.',
 railshield:'Платформа на рельсе встаёт между вами и стаей и ловит обычные снаряды. Заряд и «Разрыв» проходят насквозь.',
 stamp:'Ставит на корабль штамп, который скоро взорвётся — достанется и врагам рядом. Рывок или импульс сбрасывают штамп.',
 inspector:'Вращает жёлтый конус скана. Задержались в конусе — враги рядом бьют сильнее. Укрытия и темнота рвут конус.',
 recycler:'Засасывает добычу павших и стреляет ею в вас. Убитый высыпает всё назад — с прибавкой.',
 echo80:'Возвращает ваши выстрелы — тем же веером, но слабее. Не стреляете вы — молчит и он. Импульс стирает его память.',
 loop:'Возвращается после гибели — добейте сразу или разбейте след импульсом либо зарядом. Пока след горит, волна не закончится.',
 inverse:'Хрупкая. Выпускает волну, после которой управление на миг зеркалится. Рывок сквозь волну спасает. В настройках переворот можно заменить замедлением.',
 pilgrim:'Мирная копия VØID, летит к Истоку. Автоприцел её не трогает, рикошет и «Разрыв» — трогают. Заденете — звено ответит вашим же оружием.',
 blank85:'Серая заготовка на ленте: доедет до Лекала — станет Серийником. Разбивайте раньше; пресс давит и заготовки.',
 serial85:'Копия с вашим оружием в жёлтой краске бюро. Перед очередью стволы вспыхивают — уходите с линии.',
 lekalo:'Рама-трафарет бюро «Предел». Разбивайте заготовки до конца сборки, рвите хват манипулятора рывком. После удара пресса рама раскрыта — бейте в матрицу.',
 note85:'Голос долетевшего Паломника. Выпускает медленные самонаводящиеся звуки.',
 ghost85:'Белый контур вашего корабля: повторяет ваш недавний маршрут и выстрелы. Убейте его или сотрите импульсом рядом.',
 anchor85:'Пока жив хоть один якорь, счётчик петли идёт — на нуле колодец откатывается назад. Разбейте все.',
 wellcore:'Ядро в двух кольцах излучателей. Кольца глотают обычные снаряды — стреляйте в проходы. Паломников будите импульсом, не стреляйте по ним.',
 clot90:'Ползёт к вам и прыгает дугой туда, где растёт тень. Оставляет лужу, в которой корабль вязнет. Импульс и заряд растворяют лужи.',
 hunt95:'Охотятся тройкой: окружают треугольником и бросаются в центр. Выйдите из треугольника. Без вожака стая рассыпается.',
 valve90:'Бьётся тактами: открыт — плюёт тельцами, закрывается — бьёт волной с проходами. Сразу после открытия уязвимее (✦).',
 keeper90:'Ходит по маршруту с конусом обзора. Заметит — подсветит вас, и враги рядом стреляют чаще. Бейте в спину.',
 phago90:'Кружит вокруг вас и бьёт выпадом. Глотает обычные снаряды и потом выплёвывает их обратно. Бейте сразу после выпада.',
 spasm95:'Сжимает ленту кровотока — поток в ней ускоряется. Сзади беззащитен.',
 cell95:'Несётся по лентам и взрывается рядом с вами — ранит и врагов. Сбивайте издалека.',
 neuron90:'Узлы, связанные лучами: враги у сети злее, по лучам бегут импульсы. Рывок сквозь луч рвёт связь.',
 embryo90:'Скоро вылупится копией ближайшего врага — сильнее, но в первые мгновения без брони (✦). Разбейте раньше.',
 guard95:'Спереди — щит-мембрана, бьёт им вперёд. Обходите сбоку; заряд пробивает щит и оглушает.',
 pass90:'Разбуженный пассажир: стреляет по врагам. Импульс притягивает его к вам. Ваши снаряды его ранят — тогда он ответит.',
 heart90:'Бьётся тактами: на сжатии закрыто и гонит волну с проходами, между ударами открыто. Бейте за миг до удара. В финале пролетайте ключи ритма.',
 eraser100:'Чиркает через арену и стирает полосы пространства — в стёртом опасно. После чирка сам уязвим. Рывок сквозь него оглушает.',
 hollow100:'Дрожание пустоты. Перед броском загораются глаза. После броска замирает — бейте. Импульс проявляет его.',
 blot95:'Скачет; круг — место приземления, пятно после него стирает. В прыжке уязвима.',
 witness100:'Мирный корабль с обрывком памяти. Держитесь рядом — полетит быстрее. Долетит — обрывок ваш, погибнет — потерян навсегда.',
 typo100:'Собрана из кусков разных врагов — силуэт подсказывает, чего ждать. Время от времени переписывает часть себя и в этот миг уязвима.',
 fixer100:'Возвращает раненым недавний урон. Рывок сквозь луч переворачивает ремонт.',
 scribe95:'Пишет в воздухе строку снарядов, и она летит в вас. Пока строка висит, импульс стирает её целиком.',
 echo100:'Ваш собственный след: летит старым маршрутом и стреляет вашим оружием. Импульс стирает его.',
 tide100:'Неуязвимая полоса пустоты с одним проходом. Ищите проход или проскочите рывком.',
 noname100:'Крепнет, пока вы в него целитесь, а потом бьёт лучом по линии прицела. Отводите прицел.',
 ebb95:'Тянет за собой язык стирания. Убейте — край отступит.',
 lost95:'Корабль, который летает по вашим правилам — рывок, импульс, заряд. Сбитый роняет жетон с именем.',
 shore100:'Уязвимы только открытые глаза Смотрителя горизонта. Маяки памяти жгут прожектором — разбитый маяк оглушает Смотрителя.',
 zero000:'Первая копия. Выходит в сектор сам, и пространство дышит. Слабые места — корма, остывание после атаки и полная шкала сбоя.'
};
for(const k in EDESC_110)if(EDEF[k])EDEF[k].desc=EDESC_110[k];

/* элита, модули маяка, перки: без процентов и радиусов */
if(AFX.armor)AFX.armor.d='первые попадания гасит броня';if(AFX.fast)AFX.fast.d='заметно быстрее';
Object.entries({turret:'Маяк сам стреляет по врагам рядом.',barrier:'Купол принимает удары на себя и восстанавливается при каждой вспышке.',ring:'Кольцо зарядки шире.',
  flashdmg:'Вспышки маяка ранят и оглушают врагов рядом.',battery:'Заряд не падает ниже последней пройденной риски.',reflect:'Вражеские снаряды, попавшие в маяк, летят обратно.'}).forEach(([k,d])=>{if(BMODS[k])BMODS[k].d=d;});
if(MODS.phase)MODS.phase.d='Рывок оставляет приманку — охотники ненадолго отвлекаются на неё.';
if(MODS.linekit)MODS.linekit.d='Линии ретрансляторов чинятся быстрее.';
Object.entries({hull:'Прочнее корпус.',aim:'Сильнее основное орудие и заряженный выстрел.',pre:'Миссия начинается с частично заряженным импульсом.',dash:'Рывок перезаряжается быстрее.',
  mag:'Шире радиус подбора.',pilot:'Больше опыта модулей в миссиях.',regen:'В секторе корпус понемногу чинится, если вас давно не били. В миссиях не действует.',
  energy:'Импульс копится быстрее.',combo:'Быстрые серии уничтожений дают больше опыта модулей. Работает и в Бесконечности.',
  scan:'Тайники и непрочитанные бортжурналы видны на мини-карте и карте издалека.',twin:'Основное орудие стреляет парой снарядов — суммарно сильнее. В Бесконечности не действует.',
  bcar:'Прочнее маяк в миссиях 7–10.'}).forEach(([k,d])=>{if(PERKS[k])PERKS[k].d=d;});

/* «Что нового» — один раз для вернувшегося игрока */
setTimeout(()=>{try{if(G.state!=='menu'||!G.save||!$('#toast').hidden)return;if(LS.getItem('void_ver_seen')===VER_TAG)return;LS.setItem('void_ver_seen',VER_TAG);
  vnFresh();}catch(e){}},1600);


/* ===== 1.1.1 α «Стекло»: оболочка — подтверждения, клавиатура, движение ===== */
function fx25(){document.documentElement.classList.toggle('lessfx',!SET.fx||!!SET.lessFx);}
// подтверждение перед необратимым (вместо «нажмите ещё раз» на телефоне): одно окно для всех устройств
function askConfirm(title,text,ok,onOk){let el=document.getElementById('cfm');
  if(!el){el=document.createElement('div');el.id='cfm';el.hidden=true;el.setAttribute('role','alertdialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-labelledby','cfmT');el.setAttribute('aria-describedby','cfmP');
    el.innerHTML='<div class="box"><h3 id="cfmT"></h3><p id="cfmP"></p><div class="row"><button class="btn" id="cfmNo">ОТМЕНА</button><button class="btn danger-f" id="cfmOk"></button></div></div>';document.body.appendChild(el);
    el.addEventListener('click',e=>{if(e.target===el)closeConfirm();});
    el.querySelector('#cfmNo').onclick=()=>closeConfirm();
    el.querySelector('#cfmOk').onclick=()=>{const f=el._ok;closeConfirm(true);if(f)f();};}
  el.querySelector('#cfmT').textContent=title;const P=el.querySelector('#cfmP');P.textContent=text||'';P.hidden=!text;el.querySelector('#cfmOk').textContent=ok;
  el._ok=onOk;el._ret=document.activeElement;el.hidden=false;try{el.querySelector('#cfmNo').focus();}catch(e){}buzz&&buzz('tap');}
function closeConfirm(done){const el=document.getElementById('cfm');if(!el||el.hidden)return;el.hidden=true;el._ok=null;const r=el._ret;el._ret=null;
  if(!done&&r&&r.focus&&document.contains(r)&&r.offsetParent)try{r.focus({preventScroll:true});}catch(e){}}
function confirmPause(el,f){return e=>{
  if(G.devRun||G.mode==='dev')return f(e);
  const id=el.id,end=G.mode==='endless';let o=null;
  if(id==='bQuit'){if(G.pausedWorld)return f(e);o=end?['Выйти в меню?','Забег прервётся.','В МЕНЮ']:['Выйти в меню?','Миссия прервётся, прогресс этой попытки пропадёт.','В МЕНЮ'];}
  else if(id==='bRestart')o=end?['Начать заново?','Текущий забег прервётся.','ЗАНОВО']:['Перезапустить миссию?','Прогресс этой попытки пропадёт.','ПЕРЕЗАПУСК'];
  else if(id==='bAbandon')o=G.fromAbyss?['Покинуть Бездну?','Этот спуск не попадёт в рекорды.','ПОКИНУТЬ']:['Покинуть миссию?','Вы вернётесь в сектор. Прогресс миссии пропадёт.','ПОКИНУТЬ'];
  if(!o)return f(e);
  askConfirm(o[0],o[1],o[2],()=>{if(G.state==='pause')f(e);});};}
// окно подтверждения перехватывает клавиши: Esc — отмена, Tab и стрелки — между двумя кнопками
function cfmKey(e){const c=document.getElementById('cfm');if(!c||c.hidden)return false;
  if(e.code==='Escape'){e.preventDefault();closeConfirm();}
  else if(e.code==='Tab'||/^Arrow/.test(e.code)){e.preventDefault();const a=c.querySelector('#cfmNo'),b=c.querySelector('#cfmOk');(document.activeElement===a?b:a).focus();}
  return true;}
addEventListener('keydown',e=>{if(cfmKey(e))e.stopImmediatePropagation();},true);
// стрелки в меню и окнах: фокус ходит по кнопкам в порядке на экране
addEventListener('keydown',e=>{
  if(!/^Arrow(Up|Down|Left|Right)$/.test(e.code)||e.altKey||e.ctrlKey||e.metaKey)return;
  if(G.state==='play'||G.state==='world'||G.state==='map'||G.prologue)return;
  const t=e.target;if(t&&t.tagName&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))return;if(t&&t.matches&&t.matches('.tog[data-k]')&&(e.code==='ArrowLeft'||e.code==='ArrowRight'))return;
  const root=[...document.querySelectorAll('section.screen')].find(s=>!s.hidden&&s.id!=='fsCard');if(!root||root.id==='sMap')return;
  const L=[...root.querySelectorAll('button')].filter(b=>!b.disabled&&b.offsetParent!==null&&b.getClientRects().length);if(!L.length)return;
  const R=new Map(L.map(b=>[b,b.getBoundingClientRect()]));L.sort((a,b)=>{const A=R.get(a),B=R.get(b);return Math.abs(A.top-B.top)>6?A.top-B.top:A.left-B.left;});
  let i=L.indexOf(document.activeElement);
  if(i<0){const p=[...root.querySelectorAll('.btn.primary')].find(x=>L.includes(x));i=p?L.indexOf(p):0;}
  else{const d=(e.code==='ArrowDown'||e.code==='ArrowRight')?1:-1;i=(i+d+L.length)%L.length;}
  e.preventDefault();try{L[i].focus();L[i].scrollIntoView({block:'nearest'});}catch(er){}
},true);

// роли для экранного диктора: вкладки, группы выбора; вкладки с прокруткой держат активную в центре
function ariaSync(){try{
  document.querySelectorAll('.tabs,.maptabs').forEach(t=>t.setAttribute('role','tablist'));
  document.querySelectorAll('.tabs .tab,.maptabs button').forEach(b=>{b.setAttribute('role','tab');b.setAttribute('aria-selected',b.classList.contains('on')?'true':'false');});
  document.querySelectorAll('.seg').forEach(g=>g.setAttribute('role','group'));
  document.querySelectorAll('.seg button').forEach(b=>b.setAttribute('aria-pressed',b.classList.contains('on')?'true':'false'));
  if(isMob())document.querySelectorAll('.tabs').forEach(t=>{const on=t.querySelector('.on');if(!on||t.scrollWidth<=t.clientWidth+2||!t.offsetParent)return;const r=on.getBoundingClientRect(),q=t.getBoundingClientRect();t.scrollLeft+=(r.left+r.width/2)-(q.left+q.width/2);});
}catch(e){}}
document.addEventListener('click',()=>setTimeout(ariaSync,0));
// меню: в главной кнопке — что дальше (номер и название ближайшей непройденной миссии)
function menuCont25(){const b=document.getElementById('bWorld');if(!b)return;let c=b.querySelector('.cont');if(!c){c=document.createElement('span');c.className='cont';b.insertBefore(c,b.querySelector('kbd'));}
  let t='';try{const S=G.save&&validSave(G.save)?G.save:null;if(S){let m=0;for(let i=1;i<=NM;i++){if(nodeState(i)==='open'){m=i;break;}}
    t=m?'Миссия '+m+' · '+mName(MISSIONS[m-1]):(doneCountS(S)>=NM?'Все миссии пройдены':'');}}catch(e){t='';}c.textContent=t;}
{const _rm25=renderMenu;renderMenu=function(){_rm25.apply(this,arguments);menuCont25();};}
// тень потери: красный след за полосой корпуса догоняет её с задержкой
{let gh25=1;const _setS25=setS;setS=function(id,v){_setS25(id,v);if(id!=='hpB')return;const n=+v;if(n===gh25)return;const g=document.getElementById('hpG');if(!g)return;g.style.transition=n>gh25?'none':'';gh25=n;g.style.transform=`scaleX(${n})`;};}
// штамп поражения живёт внутри экрана поражения, а не поверх любых окон (V-02)
function stamp25(txt){const w=document.querySelector('#sOver .wrap');if(!w)return false;let st=document.getElementById('ovStamp');
  if(!st){st=document.createElement('div');st.id='ovStamp';st.setAttribute('aria-hidden','true');w.insertBefore(st,w.firstChild);}
  st.textContent=txt||'';st.classList.remove('on');if(txt){void st.offsetWidth;st.classList.add('on');}return true;}
{const _mf25=memoFlash;memoFlash=function(txt){if(!$('#sOver').hidden&&stamp25(txt))return;_mf25(txt);};}
{const _show25=show;show=function(id){closeConfirm();const m=document.getElementById('memo'),live=m&&m.classList.contains('on');
  _show25(id);setTimeout(ariaSync,0);if(id==='sOver')stamp25(live?m.textContent:'');if(m&&id)m.classList.remove('on');};}
{const _toast25=toast;toast=function(a,b){_toast25(a,b);const el=document.getElementById('toast');if(!el)return;el.classList.remove('in');void el.offsetWidth;el.classList.add('in');};}
{const _apply25=applySettings;applySettings=function(){_apply25.apply(this,arguments);fx25();};}
togHTML=function(k,lab,on,off){const v=!!SET[k];return `<button class="tog ${v?'on':''}" data-k="${k}" role="switch" aria-checked="${v}"><span>${lab}</span><span class="sw"><span class="sr">${v?(on||'ВКЛ'):(off||'ВЫКЛ')}</span></span></button>`;};

// книжная ориентация: карточка объекта не залезает под монологи и уведомления — встаёт под их стопку
function cardStack25(){const c=document.getElementById('wcard');if(!c)return;
  if(c.hidden||!document.documentElement.classList.contains('ff-phone-p')){if(c.style.top)c.style.top='';return;}
  let y=0;for(const id of ['radio','toast','fragTxt']){const e=document.getElementById(id);if(!e||e.hidden||e.offsetHeight===0)continue;const cs=getComputedStyle(e);if(+cs.opacity<.05||cs.display==='none')continue;const r=e.getBoundingClientRect();if(r.left<innerWidth*.5)y=Math.max(y,r.bottom);}
  const sp=document.getElementById('safeProbe'),base=sp?parseFloat(getComputedStyle(sp).paddingTop)||0:0;const want=y?Math.max(base+96,Math.round(y+8)):0;
  c.style.top=want?want+'px':'';}
// стопка монологов догоняет печатающийся текст каждый кадр, а не раз в 120 мс
(function loop25(){try{if(isMob()){mobStack74();cardStack25();}else cardStack25();}catch(e){}requestAnimationFrame(loop25);})();
fx25();


/* ===== 1.2.0 α · сектор I: по одной механике среды на миссию и новый Страж (без новых врагов) ===== */
// 1 буи · 2 рикошетные плиты · 3 дрейфующие глыбы · 4 цепные мины и течение · 5 тёмные карманы и ракеты · 6 Страж: связи, пояс, минная спираль и тьма
const S1C={ice:'#8fe9ff',amber:'#ffb84d',red:'#ff4f6e',violet:'#b48cff',plate:'#9fb6cc'};
function s1Setup(m){
  G.s1=null;if(!inMission()||m<1||m>6)return;
  const S={m,t:0,cid:0,chains:{},links:[],ph:0,ring:false,clouds:[],flares:[],lights:[],stock:0,flareT:9,spiralT:5,flow:null,buoys:[],plates:[]};G.s1=S;
  if(m===1)S.buoys=[[.12,.45],[.88,.45],[.5,.14]].map(([u,v],i)=>({i,x:W*u,y:H*v,lit:0,ping:2,ever:false,ring:0}));
  if(m===2)S.plates=[[.28,.38],[.72,.34],[.5,.6]].map(([u,v])=>({x:W*u,y:H*v,a:rnd(0,TAU),vr:rnd(.18,.3)*(Math.random()<.5?-1:1),vx:rnd(-10,10),vy:rnd(-8,8),L:50,cd:0,flash:0}));
  if(m===3){for(let i=0;i<4;i++){const r=makeRock(W*(.16+i*.23)+rnd(-30,30),H*rnd(.3,.58),rnd(44,52));r.hp=1e9;r.s1big=true;r.vx=rnd(10,18)*(i%2?-1:1);r.vy=rnd(-6,6);r.vr=rnd(-.15,.15);G.rocks.push(r);}}
  if(m===4)S.flow={a:rnd(0,TAU),v:30,streaks:Array.from({length:26},()=>({x:rnd(0,W),y:rnd(0,H),l:rnd(20,60)}))};
  if(m===5){S.clouds=s1Clouds(3);S.flares=[{x:W*.22,y:H*.3},{x:W*.78,y:H*.68}].map(o=>({...o,t:0}));}
  s1Chip();
}
function s1Clouds(n){const out=[];for(let i=0;i<n;i++)out.push({x:W*(.2+.3*i)+rnd(-40,40),y:H*rnd(.25,.7),r:rnd(150,190),vx:rnd(8,14)*(Math.random()<.5?-1:1),vy:rnd(-7,7),ph:rnd(0,TAU)});return out;}
function s1Chip(){let c=document.getElementById('flareC');if(!c){const box=document.querySelector('#hud .chips');if(!box)return;c=document.createElement('div');c.className='chip ok';c.id='flareC';c.hidden=true;c.textContent='РАКЕТА';box.appendChild(c);}
  c.hidden=!(G.s1&&G.s1.stock>0);}
function s1InCloud(x,y){const S=G.s1;if(!S||!S.clouds.length)return false;let inC=false;for(const c of S.clouds)if(Math.hypot(x-c.x,y-c.y)<c.r*.82){inC=true;break;}if(!inC)return false;
  for(const L of S.lights)if(Math.hypot(x-L.x,y-L.y)<L.r*.9)return false;return true;}
function s1Linked(e){const S=G.s1;if(!S||!S.links.length)return false;return S.links.some(L=>!L.cut&&(L.a===e||L.b===e)&&L.a.alive&&L.b.alive);}
function s1Tick(dt){const S=G.s1,p=G.player;if(!S||!p)return;S.t+=dt;
  // --- 1: сигнальные буи — зажжённый буй раз в несколько секунд метит врагов рядом, по меченым урон выше
  for(const b of S.buoys){b.ring=Math.max(0,b.ring-dt);const near=p.hp>0&&Math.hypot(p.x-b.x,p.y-b.y)<70;
    if(near&&b.lit<=0){b.lit=18;b.ping=.3;sfx('cell');floater(b.x,b.y-30,'БУЙ ЗАЖЖЁН','#8fe9ff');if(G.waveIdx<G.waves.length&&!b.ever){b.ever=true;G.mc.s1buoys=S.buoys.filter(q=>q.ever).length;}}
    else if(near)b.lit=Math.max(b.lit,18);
    if(b.lit>0){b.lit-=dt;b.ping-=dt;if(b.ping<=0){b.ping=3.5;b.ring=.6;for(const e of G.enemies)if(e.alive&&!e.ghost&&Math.hypot(e.x-b.x,e.y-b.y)<300)e.s1mark=G.t+3;}}}
  // --- 2: рикошетные плиты — укрытие от снарядов; рывок сквозь плиту разворачивает снаряды вокруг неё
  for(const pl of S.plates){pl.a+=pl.vr*dt;pl.x+=pl.vx*dt;pl.y+=pl.vy*dt;if(pl.x<80&&pl.vx<0||pl.x>W-80&&pl.vx>0)pl.vx*=-1;if(pl.y<80&&pl.vy<0||pl.y>H-80&&pl.vy>0)pl.vy*=-1;
    pl.cd=Math.max(0,pl.cd-dt);pl.flash=Math.max(0,pl.flash-dt);const ax=pl.x-Math.cos(pl.a)*pl.L,ay=pl.y-Math.sin(pl.a)*pl.L,bx=pl.x+Math.cos(pl.a)*pl.L,by=pl.y+Math.sin(pl.a)*pl.L;
    for(const b of G.eb){if(b.life<=0||b.k95||b.rift)continue;if(segDist(ax,ay,bx,by,b.x,b.y)<(b.r||5)+4){b.life=0;if(SET.fx)part(b.x,b.y,rnd(-60,60),rnd(-60,60),.2,'#dfe8ff',2);}}
    if(p.dashT>0&&pl.cd<=0&&segDist(ax,ay,bx,by,p.x,p.y)<p.r+8){pl.cd=1.2;pl.flash=.35;let n=0;
      G.eb=G.eb.filter(b=>{if(b.k95||b.rift||b.boss||Math.hypot(b.x-pl.x,b.y-pl.y)>190)return true;const sp=Math.max(420,Math.hypot(b.vx,b.vy)*1.6);let tg=null,td=1e9;for(const e of G.enemies){if(!e.alive||e.ghost||e.spawnT>0)continue;const q=Math.hypot(e.x-b.x,e.y-b.y);if(q<td){td=q;tg=e;}}
        const a=tg?Math.atan2(tg.y-b.y,tg.x-b.x):Math.atan2(-b.vy,-b.vx);G.pb.push({x:b.x,y:b.y,px:b.x,py:b.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,dmg:14,pierce:0,rico:0,life:1,hit:[],refl:true});n++;return false;});
      sfx('shield');shake(3);if(n)floater(pl.x,pl.y-26,'ОТРАЖЕНО','#dfe8ff');}}
  // --- 3: глыбы — таран, влетевший в глыбу, оглушён, урон по нему вдвое
  if(S.m===3||S.ring){for(const e of G.enemies){if(!e.alive)continue;
      if(e.type==='rammer'&&e.st==='charge'){for(const r of G.rocks){if(!r.alive||!(r.s1big||r.s1orb))continue;if(Math.hypot(e.x-r.x,e.y-r.y)<r.r+e.r+2){e.st='rest';e.timer=2;e.vx=e.vy=0;e.s1dz=G.t+2;G.mc.s1stun=(G.mc.s1stun||0)+1;floater(e.x,e.y-e.r-10,'ОГЛУШЁН','#ffd24d');sfx('block');shake(4);break;}}}
      if(e.type==='guard'&&S.ring&&!(e.s1g>G.t)){for(const r of G.rocks){if(!r.alive||!r.s1orb)continue;if(Math.hypot(e.x-r.x,e.y-r.y)<r.r+e.r+2){e.s1g=G.t+4;e.shieldDown=3;e.cd=Math.max(e.cd,2);e.s1dz=G.t+1.2;floater(e.x,e.y-e.r-12,'ЩИТ СБИТ','#ffd24d');sfx('block');break;}}}}}
  // --- 4: течение — сносит корабль и мины
  if(S.flow){const F=S.flow;F.a+=dt*.05;const fx=Math.cos(F.a),fy=Math.sin(F.a);
    if(p.hp>0&&!(p.dashT>0)){p.x=clamp(p.x+fx*F.v*dt,p.r,W-p.r);p.y=clamp(p.y+fy*F.v*dt,p.r,H-p.r);}
    for(const e of G.enemies)if(e.alive&&e.type==='mine'){e.x=clamp(e.x+fx*F.v*.8*dt,10,W-10);e.y=clamp(e.y+fy*F.v*.8*dt,10,H-10);}
    for(const s of F.streaks){s.x+=fx*F.v*2.2*dt;s.y+=fy*F.v*2.2*dt;if(s.x<-60)s.x+=W+120;if(s.x>W+60)s.x-=W+120;if(s.y<-60)s.y+=H+120;if(s.y>H+60)s.y-=H+120;}}
  // --- 5 и 6: тёмные карманы, ракеты
  for(const c of S.clouds){c.x+=c.vx*dt;c.y+=c.vy*dt;c.ph+=dt*.6;if(c.x<c.r*.4&&c.vx<0||c.x>W-c.r*.4&&c.vx>0)c.vx*=-1;if(c.y<c.r*.3&&c.vy<0||c.y>H-c.r*.3&&c.vy>0)c.vy*=-1;}
  for(const L of S.lights)L.t-=dt;S.lights=S.lights.filter(L=>L.t>0);
  if(S.m===5){S.flareT-=dt;if(S.flareT<=0&&S.flares.length<2){S.flareT=14;let x,y,k=0;do{x=rnd(W*.12,W*.88);y=rnd(H*.15,H*.85);}while(Math.hypot(x-p.x,y-p.y)<220&&++k<8);S.flares.push({x,y,t:0});}
    for(const f of S.flares){f.t+=dt;if(S.stock<1&&p.hp>0&&Math.hypot(p.x-f.x,p.y-f.y)<34){f.got=true;S.stock=1;sfx('cell');floater(f.x,f.y-24,'РАКЕТА · НА ИМПУЛЬС','#ffd24d');}}
    S.flares=S.flares.filter(f=>!f.got);}
  // --- 6: Страж
  const b=G.boss;if(S.m===6&&b&&b.alive&&b.st==='fight'){
    if(S.ph!==b.phase){S.ph=b.phase;S.links=[];S.linkKey='';
      for(const r of G.rocks)if(r.s1orb)r.alive=false;S.ring=false;
      if(b.phase===2){S.ring=true;for(let i=0;i<8;i++){const r=makeRock(b.x,b.y,rnd(15,19));r.hp=1e9;r.s1orb=true;r.oa=i/8*TAU;r.vx=r.vy=0;G.rocks.push(r);}}
      if(b.phase===3){S.clouds=s1Clouds(2);S.spiralT=3;}}
    if(b.phase===1){const py=G.enemies.filter(e=>e.alive&&e.type==='pylon'&&e.spawnT<=0);const key=py.map(e=>e.uid).join(',');
      if(py.length>=2&&key!==S.linkKey&&!S.links.length){S.linkKey=key;for(let i=0;i<py.length;i++){const a=py[i],c=py[(i+1)%py.length];if(py.length===2&&i===1)break;S.links.push({a,b:c,cut:false});}}
      for(const L of S.links){if(L.cut||!L.a.alive||!L.b.alive)continue;if(p.dashT>0&&segDist(L.a.x,L.a.y,L.b.x,L.b.y,p.x,p.y)<p.r+8){L.cut=true;floater(p.x,p.y-30,'СВЯЗЬ РАЗОРВАНА','#ffffff');sfx('shield');shake(4);if(SET.fx)for(let k=0;k<10;k++)part((L.a.x+L.b.x)/2,(L.a.y+L.b.y)/2,vrnd3(-120,120),vrnd3(-120,120),.4,S1C.violet,2.5);}}}
    if(S.ring){S.ringA=(S.ringA||0)+dt*.45;for(const r of G.rocks)if(r.alive&&r.s1orb){const a=r.oa+S.ringA;r.x=b.x+Math.cos(a)*205;r.y=b.y+Math.sin(a)*205*.85;r.vx=r.vy=0;}}
    if(b.phase===3&&b.over<=0){S.spiralT-=dt*missionK('rate');if(S.spiralT<=0){S.spiralT=6.5;const a0=rnd(0,TAU);sfx('warn');for(let k=0;k<6;k++){const a=a0+k*1.05,R=110+k*30;spawnEnemy('mine',clamp(b.x+Math.cos(a)*R,20,W-20),clamp(b.y+Math.sin(a)*R*.85,20,H-20),{arm:1.1,fuse:0,life:15,noAffix:true});}}}}
  if(!G.bc&&G.rocks.length)updateRocks(dt);
  s1Chip();
}
function s1OnPulse(){const S=G.s1,p=G.player;if(!S||!p)return;
  if(S.stock>0&&(S.m===5||S.clouds.length)){S.stock=0;S.lights.push({x:p.x,y:p.y,r:240,t:6,t0:6});G.shock.push({x:p.x,y:p.y,r:10,R:240,t:0,col:'#ffd24d',thin:true});floater(p.x,p.y-36,'РАКЕТА','#ffd24d');}
}
function s1ChainBlast(e,R){const S=G.s1;if(!S)return;const id=e.chain||(e.chain=++S.cid);const C=S.chains[id]||(S.chains[id]={n:0,hit:false});C.n++;
  for(const o of G.enemies)if(o.alive&&o!==e&&!STATIC.has(o.type)&&o.type!=='mine'&&Math.hypot(o.x-e.x,o.y-e.y)<R)C.hit=true;
  for(const o of G.enemies){if(!o.alive||o===e||o.type!=='mine'||o.fuse>0)continue;if(Math.hypot(o.x-e.x,o.y-e.y)<R+18){o.fuse=.14;o.chain=id;}}
  if(S.m===6&&G.boss&&G.boss.phase===3)for(const o of G.enemies)if(o.alive&&o.type==='pylon'&&Math.hypot(o.x-e.x,o.y-e.y)<R+o.r){hurt(o,999,{force:true});floater(o.x,o.y-20,'ЗАРЯД СНЯТ','#ffd24d');}
  if(C.hit&&C.n>=2)G.mc.s1chain=Math.max(G.mc.s1chain||0,C.n);
  if(C.n===3)floater(e.x,e.y-30,'ЦЕПЬ','#ffd24d');}
// ---------- отрисовка: под врагами (буи, плиты, течение, связи) и поверх (тьма, метки, прицелы из тьмы)
function s1DrawUnder(t){const S=G.s1;if(!S)return;
  if(S.flow){const F=S.flow,fx=Math.cos(F.a),fy=Math.sin(F.a);ctx.strokeStyle='#8fd8ff';ctx.lineWidth=1.2;for(const s of F.streaks){ctx.globalAlpha=.12;ctx.beginPath();ctx.moveTo(s.x,s.y);ctx.lineTo(s.x-fx*s.l,s.y-fy*s.l);ctx.stroke();}ctx.globalAlpha=1;}
  for(const b of S.buoys){const on=b.lit>0;glow(b.x,b.y,on?46:22,on?S1C.ice:'#3f5a72',on?.7:.35);ctx.save();ctx.translate(b.x,b.y);ctx.strokeStyle=on?S1C.ice:'#4a6680';ctx.fillStyle='#0b1220';ctx.lineWidth=2;
    ctx.beginPath();for(let k=0;k<6;k++){const a=k/6*TAU;ctx.lineTo(Math.cos(a)*11,Math.sin(a)*11);}ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle=on?'#ffffff':'#4a6680';ctx.beginPath();ctx.arc(0,0,3.5,0,TAU);ctx.fill();
    if(!on){ctx.globalAlpha=.35+.25*Math.sin(t*3+b.i);ctx.setLineDash([3,5]);ctx.beginPath();ctx.arc(0,0,70,0,TAU);ctx.stroke();ctx.setLineDash([]);}
    if(b.ring>0){const k=1-b.ring/.6;ctx.globalAlpha=(1-k)*.6;ctx.strokeStyle=S1C.ice;ctx.beginPath();ctx.arc(0,0,20+280*k,0,TAU);ctx.stroke();}ctx.restore();ctx.globalAlpha=1;}
  for(const pl of S.plates){ctx.save();ctx.translate(pl.x,pl.y);ctx.rotate(pl.a);ctx.fillStyle='#16233a';ctx.strokeStyle=pl.flash>0?'#ffffff':S1C.plate;ctx.lineWidth=2;ctx.beginPath();ctx.rect(-pl.L,-6,pl.L*2,12);ctx.fill();ctx.stroke();
    ctx.strokeStyle='#4a6680';ctx.lineWidth=1;for(let k=-pl.L+10;k<pl.L;k+=14){ctx.beginPath();ctx.moveTo(k,-6);ctx.lineTo(k+6,6);ctx.stroke();}ctx.restore();if(pl.flash>0)glow(pl.x,pl.y,70,'#dfe8ff',pl.flash*2);}
  for(const f of S.flares){glow(f.x,f.y,30,'#ffd24d',.55+.3*Math.sin(f.t*5));ctx.fillStyle='#ffd24d';ctx.beginPath();ctx.moveTo(f.x,f.y-9);ctx.lineTo(f.x+5,f.y+6);ctx.lineTo(f.x-5,f.y+6);ctx.closePath();ctx.fill();}
  for(const L of S.links){if(L.cut||!L.a.alive||!L.b.alive)continue;ctx.strokeStyle=S1C.violet;ctx.lineWidth=3;ctx.globalAlpha=.55+.3*Math.sin(t*12);ctx.beginPath();ctx.moveTo(L.a.x,L.a.y);ctx.lineTo(L.b.x,L.b.y);ctx.stroke();ctx.lineWidth=1;ctx.strokeStyle='#ffffff';ctx.globalAlpha=.6;ctx.stroke();ctx.globalAlpha=1;}
}
let s1C=null,s1X=null;
function s1DrawOver(t){const S=G.s1;if(!S)return;
  for(const e of G.enemies){if(!e.alive)continue;
    if(e.s1mark>G.t){ctx.strokeStyle=S1C.ice;ctx.lineWidth=1.5;ctx.globalAlpha=.8;ctx.setLineDash([4,4]);ctx.lineDashOffset=-t*30;ctx.beginPath();ctx.arc(e.x,e.y,e.r+8,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;}
    if(e.s1dz>G.t){for(let k=0;k<3;k++){const a=t*4+k*2.1;ctx.fillStyle='#ffd24d';ctx.beginPath();ctx.arc(e.x+Math.cos(a)*(e.r+6),e.y-e.r-4+Math.sin(a)*4,2.5,0,TAU);ctx.fill();}}
    if(e.type==='pylon'&&s1Linked(e)){ctx.strokeStyle='#ffffff';ctx.globalAlpha=.5;ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(e.x,e.y,e.r+6,0,TAU);ctx.stroke();ctx.globalAlpha=1;}}
  if(S.clouds.length){
    if(!s1C||s1C.width!==cv.width||s1C.height!==cv.height){s1C=document.createElement('canvas');s1C.width=cv.width;s1C.height=cv.height;s1X=s1C.getContext('2d');}
    const X=s1X;X.setTransform(1,0,0,1,0,0);X.globalCompositeOperation='source-over';X.clearRect(0,0,s1C.width,s1C.height);X.setTransform(ctx.getTransform());
    // облако — не диск, а клубы: ядро и 6 медленно дышащих выступов, холодно-фиолетовый оттенок к краю
    for(const c of S.clouds){if(!c.pf){c.pf=[];for(let k=0;k<6;k++){const a=k/6*TAU+rnd(-.3,.3);c.pf.push({a,d:rnd(.38,.55),r:rnd(.42,.58),w:rnd(.5,1.2)});}}
      const R0=c.r*(1+.04*Math.sin(c.ph));
      const blob=(x,y,r)=>{const g=X.createRadialGradient(x,y,r*.15,x,y,r);g.addColorStop(0,'rgba(4,5,14,.9)');g.addColorStop(.4,'rgba(6,7,18,.78)');g.addColorStop(.7,'rgba(14,12,34,.42)');g.addColorStop(1,'rgba(22,18,48,0)');X.fillStyle=g;X.beginPath();X.arc(x,y,r,0,TAU);X.fill();};
      blob(c.x,c.y,R0*.8);for(const q of c.pf){const a=q.a+Math.sin(c.ph*q.w)*.18,dd=R0*q.d*(1+.06*Math.sin(c.ph*1.7+q.a));blob(c.x+Math.cos(a)*dd,c.y+Math.sin(a)*dd,R0*q.r);}}
    X.globalCompositeOperation='destination-out';const p=G.player;
    const hole=(x,y,r,a)=>{const g=X.createRadialGradient(x,y,r*.35,x,y,r);g.addColorStop(0,`rgba(0,0,0,${a})`);g.addColorStop(1,'rgba(0,0,0,0)');X.fillStyle=g;X.beginPath();X.arc(x,y,r,0,TAU);X.fill();};
    if(p)hole(p.x,p.y,85,1);for(const L of S.lights)hole(L.x,L.y,L.r,Math.min(1,L.t/1.2));
    const b=G.boss;if(b&&b.alive&&b.over>0)hole(b.x,b.y,110,1);
    ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(s1C,0,0);ctx.restore();
    // копейщик из тьмы виден по лучу прицела
    for(const e of G.enemies){if(!e.alive||e.type!=='lancer'||(e.st!=='aim'&&e.st!=='lock'))continue;ctx.strokeStyle=S1C.red;ctx.globalAlpha=e.st==='lock'?.9:.4;ctx.lineWidth=e.st==='lock'?2.5:1.2;ctx.setLineDash(e.st==='lock'?[]:[8,8]);
      ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.x+Math.cos(e.aim)*1800,e.y+Math.sin(e.aim)*1800);ctx.stroke();ctx.setLineDash([]);glow(e.x,e.y,16,S1C.red,.6);ctx.globalAlpha=1;}
    for(const L of S.lights){const k=L.t/L.t0;ctx.strokeStyle='#ffd24d';ctx.globalAlpha=.25*k;ctx.lineWidth=1;ctx.beginPath();ctx.arc(L.x,L.y,L.r,0,TAU);ctx.stroke();ctx.globalAlpha=1;}}
}
// ---------- связки с игрой
{const _sm29=setupMission0;setupMission0=function(i){_sm29(i);try{s1Setup(i+1);}catch(e){console.error(e);G.s1=null;}};}
{const _up29=update;update=function(dt){_up29(dt);if(G.s1&&inMission()&&G.state==='play'&&G.deadT<=0)s1Tick(dt);};}
{const _tp29=tryPulse;tryPulse=function(){const p=G.player,was=!!p&&p.en>=100;_tp29();if(was&&p.en<100&&G.s1)s1OnPulse();};}
{const _h29=hurt;hurt=function(e,dmg,src){
  if(G.s1&&e&&e.alive){if(e.type==='pylon'&&s1Linked(e)&&!(src&&src.force)){e.shieldFlash=.12;if(SET.fx)part(e.x,e.y,vrnd3(-50,50),vrnd3(-50,50),.2,S1C.violet,2);return;}
    if(e.s1mark>G.t)dmg*=1.25;if(e.s1dz>G.t)dmg*=2;}
  const was=!!(e&&e.alive);_h29(e,dmg,src);
  if(G.s1&&was&&src&&src.refl&&!e.alive&&e.type==='gunner'&&G.mc)G.mc.s1refl=(G.mc.s1refl||0)+1;};}
{const _k29=kill;kill=function(e,silent){if(G.s1&&e&&e.alive&&e.type==='mine'&&!silent&&(G.s1.m===4||G.s1.m===6)&&!e.s1boom){e.s1boom=1;e.hp=1;e.fuse=.06;e.arm=0;return;}return _k29(e,silent);};}
{const _mb29=mineBlast;mineBlast=function(e,R,pd){_mb29(e,R,pd);if(G.s1&&(G.s1.m===4||G.s1.m===6))s1ChainBlast(e,R);};}
{const _dp29=damagePlayer;damagePlayer=function(d){const p=G.player,h0=p?p.hp:0;_dp29(d);if(G.s1&&p&&p.hp<h0&&G.mc&&s1InCloud(p.x,p.y))G.mc.s1dark=(G.mc.s1dark||0)+1;};}
// мастерство, подсказки и теги миссий 1–6
MASTERY[0]={t:'Зажечь все три буя до последней волны',ok:()=>(G.mc.s1buoys||0)>=3};
MASTERY[1]={t:'Уничтожить 3 стрелков их же снарядами',ok:()=>(G.mc.s1refl||0)>=3};
MASTERY[2]={t:'Оглушить о глыбы 3 тарана',ok:()=>(G.mc.s1stun||0)>=3};
MASTERY[3]={t:'Цепь из 5 мин, задевшая врага',ok:()=>(G.mc.s1chain||0)>=5};
MASTERY[4]={t:'Ни одного попадания в темноте',ok:()=>!(G.mc.s1dark>0)};
{const H=MISSIONS;
  H[0].hint=['WASD или стрелки — движение. Огонь — сам, по ближайшей цели.','Подлетите к бую, чтобы зажечь его: он метит врагов рядом, по меченым урон выше.','Собирайте осколки данных с врагов — из них растут модули.'];
  H[1].hint=['Плиты обшивки закрывают от выстрелов. Рывок сквозь плиту разворачивает снаряды вокруг неё во врагов.','ПРОБЕЛ — рывок сквозь снаряды.'];
  H[2].hint=['Таран, влетевший в глыбу, оглушён — урон по нему вдвое. Ставьте глыбу между собой и тараном.','E или Shift — импульс, когда шкала полна: сносит снаряды и отбрасывает врагов.'];
  H[3].hint=['Импульс рвёт мины цепью — взрыв задевает врагов рядом. Не стойте в цепи сами.','Течение медленно сносит корабль и мины.','Клик по врагу (или касание) — огонь только по нему.'];
  H[4].hint=['В тёмных пятнах врагов не видно. Копейщика выдаёт луч прицела.','Подберите ракету: импульс зажжёт её и осветит круг.','Линия копейщика вспыхнула — рывок.'];
  H[5].hint=['Заряды связаны лучами: пока связь цела, заряд не пробить. Рывок сквозь луч рвёт связь.','Во второй фазе гвардия, задевшая пояс обломков, теряет щит. В третьей импульс рвёт мины цепью — взрыв снимает заряд.','Ядро неуязвимо, пока живы заряды. Каждая фаза — новые атаки.'];
  H[0].mech=['СИГНАЛЬНЫЕ БУИ'];H[1].mech=['РИКОШЕТНЫЕ ПЛИТЫ'];H[2].mech=['ДРЕЙФУЮЩИЕ ГЛЫБЫ'];H[3].mech=['ЦЕПНЫЕ МИНЫ','ТЕЧЕНИЕ'];H[4].mech=['ТЁМНЫЕ ПЯТНА','СИГНАЛЬНЫЕ РАКЕТЫ'];H[5].mech=['СВЯЗАННЫЕ ЗАРЯДЫ','ПОЯС ОБЛОМКОВ','МИННАЯ СПИРАЛЬ'];}


/* ===== 1.2.1 α · Сторожевик «Изморозь»: мёртвый корабль вмёрз поперёк прохода II–III. Путь в сектор III — только насквозь ===== */
// Четыре палубы: Шлюзовая (темнота) → Криопалуба (лёд, холод, капсулы) → Машинное (Наблюдатель охотится) → Реактор и побег от ледяного фронта.
// Каноны: свет — единственная защита и он подводит; стены отбрасывают тень; тишина перед ударом; то, что видно краем глаза;
// ложная безопасность; нарастание; погоня в финале. Особая миссия вне счёта «из 50»: запись MISSIONS[50] после расчёта NM.
const POST_W={x:9540,y:14330},POST_ANG=-.06;           // корпус вмёрз у самой границы секторов, выше узла 10 и вдали от Бездны
const POST_HL=[-300,-104];                              // входной шлюз — на верхнем борту корпуса (координаты корпуса)
const POST_HATCH=(()=>{const c=Math.cos(POST_ANG),s=Math.sin(POST_ANG);return {x:Math.round(POST_W.x+POST_HL[0]*c-POST_HL[1]*s),y:Math.round(POST_W.y+POST_HL[0]*s+POST_HL[1]*c)};})();
const POST_EXIT={x:10520,y:14300};                      // выходной шлюз — уже в секторе III
const POST_I=MISSIONS.length; // 50
MISSIONS.push({name:'Сторожевик «Изморозь»',sector:'ГРАНИЦА СЕКТОРОВ II–III',intro:['shade'],post:true,waves:[],
  mech:['ТЕМНОТА','ЛЁД','ХОЛОД'],
  hint:['Фонарь светит по курсу, стены отбрасывают тень. Чего не видите вы — не видно и вам.','Вне тепла корпус обрастает льдом и замерзает. Лампы и генераторы греют.','Оно двигается, только пока вы на него не смотрите. Свет и импульс отгоняют его.']});
MASTERY[POST_I]={t:'Ни разу не замёрзнуть',ok:()=>!!G.post&&G.post.freezes===0};
// раскладка палуб в относительных координатах (в книжной ориентации поворачивается); декор — там же
// Пять палуб. Левел-дизайн: 1 — узкий коридор со скафандрами (учит свету и тени), 2 — лабиринт рядов криокапсул,
// 3 — та же криопалуба ещё раз: тихо, темно, все капсулы открыты (лиминальный повтор), 4 — кольцо вокруг кожуха реактора
// с тупиковыми нишами генераторов (охота), 5 — длинный тесный коридор → огромный зал реактора → бег назад по коридору.
const POST_ACTS=[
 {key:'lock',name:'ШЛЮЗОВАЯ ПАЛУБА',start:[.05,.5],aim:0,walls:[[.12,0,.45,.4],[.12,.6,.45,1],[.56,.42,.61,.58],[.72,0,.76,.3],[.72,.45,.76,1]],crates:[4],
  ice:[],lamps:[[.06,.86,.1,'dead'],[.52,.2,.13,'p0'],[.66,.8,.13,'p1'],[.88,.42,.14,'p2']],panels:[[.58,.1],[.58,.9],[.9,.15]],cells:[],gens:[],core:null,door:[.96,.88],
  wrecks:[[.06,.16,0]],cold:false,watcher:false,beacons:[[.45,.4],[.72,.3],[.12,.6]],
  suits:[[.16,.43],[.21,.43],[.26,.43],[.31,.43],[.36,.43],[.41,.43],[.16,.57],[.21,.57],[.26,.57],[.31,.57],[.36,.57],[.41,.57]],roster:[.66,.05],
  claws:[[.86,.62,.4],[.5,.62,-.5]],pods:[],breach:[]},
 {key:'cryo',name:'КРИОПАЛУБА',start:[.05,.1],aim:0,walls:[[.15,.25,.85,.3],[0,.5,.4,.55],[.5,.5,1,.55],[.15,.75,.85,.8]],
  ice:[[.2,.32,.8,.48],[.15,.57,.85,.73]],lamps:[[.25,.1,.11,'on'],[.75,.65,.1,'on'],[.3,.92,.1,'on']],panels:[],cells:[[.5,.12],[.06,.65],[.94,.92]],gens:[],core:null,door:[.5,.93],
  wrecks:[[.08,.38,1]],cold:true,watcher:'mid',beacons:[[.15,.25],[.85,.3],[.4,.5],[.5,.55]],tally:[[.93,.64,.1]],
  claws:[[.6,.38,1.2],[.72,.86,-.3]],pods:'rows',scarePod:[.33,.45],breach:[[.96,.42,.04]]},
 {key:'loop',name:'КРИОПАЛУБА',start:[.05,.1],aim:0,walls:[[.15,.25,.85,.3],[0,.5,.4,.55],[.5,.5,1,.55],[.15,.75,.85,.8]],
  ice:[],lamps:[[.94,.92,.1,'on']],panels:[],cells:[],gens:[],core:null,door:[.5,.93],trig:[.45,.65],
  wrecks:[],cold:false,watcher:false,beacons:[],claws:[[.6,.38,1.2],[.72,.86,-.3]],pods:'rows',podsOpen:true,breach:[[.96,.42,.04]]},
 {key:'eng',name:'МАШИННОЕ ОТДЕЛЕНИЕ',start:[.5,.9],aim:-Math.PI/2,walls:[[.42,.36,.58,.64],[.16,0,.19,.38],[.16,.62,.19,1],[.72,0,.75,.3],[.75,.27,.9,.3],[.72,.7,.75,1],[.75,.7,.9,.73]],
  ice:[[.24,.2,.38,.8],[.6,.32,.7,.68]],lamps:[[.5,.82,.1,'on']],panels:[],cells:[],gens:[[.07,.5],[.87,.12],[.87,.88]],core:null,door:[.97,.5],
  wrecks:[[.3,.08,2]],cold:true,watcher:'all',beacons:[[.42,.36],[.58,.64],[.19,.38],[.75,.3],[.75,.7]],
  claws:[[.62,.9,.3],[.08,.2,-1.1],[.82,.55,.9]],pods:[],breach:[],rift:true},
 {key:'core',name:'РЕАКТОР',start:[.05,.5],aim:0,walls:[[.08,0,.5,.42],[.08,.58,.5,1],[.62,.12,.66,.28],[.62,.72,.66,.88],[.9,.12,.94,.28],[.9,.72,.94,.88]],
  ice:[[.52,.3,.74,.7]],lamps:[[.2,.5,.08,'on'],[.4,.5,.08,'on'],[.56,.2,.1,'on'],[.56,.8,.1,'on'],[.76,.06,.1,'on'],[.76,.94,.1,'on']],panels:[],cells:[],gens:[],core:[.82,.5],door:[.03,.5],
  wrecks:[[.68,.5,3,1]],cold:true,watcher:'all',beacons:[[.5,.42],[.5,.58],[.66,.28],[.66,.72]],
  claws:[[.3,.3,.4],[.72,.2,-.5]],pods:[],breach:[[.97,.08,.04],[.97,.92,.04]],edoor:[.27,.42,.3,.58],rift:true}];
const POST_LOGS=[
 {title:'СТОРОЖЕВИК «ИЗМОРОЗЬ» · ВАХТА 1',text:'Сменили фильтры. Второй генератор шумит. В капсуле семь опять иней изнутри. Проверил — пустая.'},
 {title:'СТОРОЖЕВИК «ИЗМОРОЗЬ» · ВАХТА 2',text:'На поверке насчитал тринадцать. Пересчитал — двенадцать. Капитан говорит, я устал.'},
 {title:'СТОРОЖЕВИК «ИЗМОРОЗЬ» · ВАХТА 3',text:'В шлюзе висит лишний скафандр. Номер не наш. Утром его не было.'},
 {title:'СТОРОЖЕВИК «ИЗМОРОЗЬ» · ПОСЛЕДНЯЯ',text:'Последняя поверка: двенадцать. Тринадцатый стоял в конце строя и не отвечал. Мы так и не поняли, кого из нас не хватает.'}];
// автоматика корабля: ровный голос, будничные сводки, которые не сходятся
RADIO['Х']={tag:'СТОРОЖЕВИК «ИЗМОРОЗЬ» · АВТОМАТИКА',col:'#bfe8ff',l:[{t:'…СК-07 «Изморозь», плановая сводка. Вахта четыре. Без происшествий.'},{t:'…вахта четыре. Без происшествий. Вахта четыре. Без происшествий.'},{t:'…поверка. Экипаж: двенадцать. Экипаж: тринадцать. Экипаж: двенадцать.'},{t:'…VØID-013 внесён в судовую роль. Займите свою капсулу.'},{t:'…реактор: пуск. Шлюз: открыт. Экипаж: на местах.'},{t:'…стыковка подтверждена. VØID-013, добро пожаловать на борт.'},{t:'…температура в криоотсеке в норме. Все капсулы заняты.'}]};
const POST_DK={easy:{cone:340,dark:.95,cold:.18,wcd:[9,12],wsp:95,tele:1.15,hit:14,esc:52},mid:{cone:300,dark:.97,cold:.24,wcd:[7,9],wsp:110,tele:.95,hit:16,esc:44},hard:{cone:255,dark:.985,cold:.32,wcd:[5,7],wsp:130,tele:.8,hit:18,esc:37}};
function postDK(){return POST_DK[G.diff]||POST_DK.easy;}
function postSave(){const S=G.save;if(!S)return null;if(!S.post||typeof S.post!=='object')S.post={done:0,open3:0,best:0,freezes:-1,logs:[]};return S.post;}
function postDone(){const S=G.save;return !!(S&&S.post&&S.post.done);}
function postGate(){const S=G.save;return !!(S&&S.post&&(S.post.done||S.post.open3));}
function postAvail(){return !!G.save&&progDone(CORE)&&!openAllNowSafe();}
function openAllNowSafe(){try{return openAllNow()&&!G.post;}catch(e){return false;}}
function pRng(seed){let a=seed>>>0;return ()=>{a=a+0x6D2B79F5>>>0;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
// --- раскладка: на сенсорном экране палуба ужимается в зону без кнопок (цели не оказываются под пальцем)
function postBox(){let t=false;try{t=!!touchMode;}catch(e){}if(!t)return [0,0,1,1];if(W<H)return [0,.14,1,.72];return SET.hand==='l'?[.27,.1,1,1]:[0,.1,.73,1];}
function postXY(u,v){const B=postBox(),a=W>=H?u:1-v,b=W>=H?v:u;return [(B[0]+a*(B[2]-B[0]))*W,(B[1]+b*(B[3]-B[1]))*H];}
function postUV(x,y){const B=postBox(),a=(x/W-B[0])/(B[2]-B[0]),b=(y/H-B[1])/(B[3]-B[1]);return W>=H?[a,b]:[b,1-a];}
function postRect(r){const a=postXY(r[0],r[1]),b=postXY(r[2],r[3]);return {x0:Math.min(a[0],b[0]),y0:Math.min(a[1],b[1]),x1:Math.max(a[0],b[0]),y1:Math.max(a[1],b[1])};}
function postR(k){return k*Math.min(W,H);}
function postFree(x,y,pad){if(x<pad||y<pad||x>W-pad||y>H-pad)return false;for(const w of G.post.walls)if(x>w.x0-pad&&x<w.x1+pad&&y>w.y0-pad&&y<w.y1+pad)return false;return true;}
function postLoadAct(n,keepHp){const P=G.post,A=POST_ACTS[n],p=G.player;P.act=n;P.at=0;P.cold=0;P.fade=1;P.lights=[];P.flash=0;
  P.walls=A.walls.map(postRect);for(const ci of (A.crates||[]))if(P.walls[ci])P.walls[ci].crates=true;{const B=postBox(),M=60;if(B[0]>0)P.walls.push({x0:-M,y0:-M,x1:B[0]*W,y1:H+M,edge:1});if(B[2]<1)P.walls.push({x0:B[2]*W,y0:-M,x1:W+M,y1:H+M,edge:1});if(B[3]<1)P.walls.push({x0:-M,y0:B[3]*H,x1:W+M,y1:H+M,edge:1});if(B[1]>0)P.walls.push({x0:-M,y0:-M,x1:W+M,y1:B[1]*H,edge:1});}
  P.ice=A.ice.map(r=>{const q=postRect(r);q.cr=Array.from({length:9},()=>[rnd(q.x0,q.x1),rnd(q.y0,q.y1),rnd(0,TAU),rnd(20,60)]);return q;});
  P.lamps=A.lamps.map(([u,v,k,s])=>{const [x,y]=postXY(u,v);return {x,y,r:postR(k)*1.6,on:s==='on',key:s,fail:s==='dead'?1:0,fl:1,flT:rnd(1,6)};});
  P.panels=A.panels.map(([u,v],i)=>{const [x,y]=postXY(u,v);return {x,y,i,on:false,h:0};});
  P.cells=A.cells.map(([u,v])=>{const [x,y]=postXY(u,v);return {x,y,got:false};});
  P.gens=A.gens.map(([u,v],i)=>{const [x,y]=postXY(u,v);return {x,y,i,h:0,on:false};});
  P.core=A.core?(()=>{const [x,y]=postXY(A.core[0],A.core[1]);return {x,y,h:0,on:false};})():null;
  {const [x,y]=postXY(A.door[0],A.door[1]);P.door={x,y,open:false,k:0};}
  P.wrecks=A.wrecks.map(([u,v,li,mir])=>{const [x,y]=postXY(u,v);return {x,y,li,read:false,a:rnd(0,TAU),mirror:!!mir,turn:0};});
  P.beacons=A.beacons.map(([u,v],i)=>{const [x,y]=postXY(u,v);return {x,y,a:rnd(0,TAU),w:(i%2?-1:1)*rnd(1.1,1.6)};});
  P.suits=(A.suits||[]).map(([u,v],i)=>{const [x,y]=postXY(u,v);const f=Math.atan2(postXY(u,.5)[1]-y,postXY(u,.5)[0]-x);return {x,y,i,f,f0:f,gone:false};});
  P.roster=A.roster?postXY(...A.roster):null;P.tally=(A.tally||[]).map(([u,v,a])=>{const [x,y]=postXY(u,v);return {x,y,a};});
  P.trig=A.trig?(()=>{const [x,y]=postXY(...A.trig);return {x,y,hit:false};})():null;P.figs=[];P.strobe=null;P.figT=rnd(7,12);P.strT=rnd(14,22);P.mbT=0;P.mbI=0;P.rift=0;
  P.claws=A.claws.map(([u,v,a])=>{const [x,y]=postXY(u,v);return {x,y,a};});
  {let L=A.pods==='rows'?[]:A.pods.slice();if(A.pods==='rows'){for(let u=.2;u<.81;u+=.075){L.push([u,.205,0]);L.push([u,.845,0]);}for(const u of [.05,.12,.19,.26,.58,.65,.72,.79,.86,.93])L.push([u,.455,0]);}if(A.scarePod)L.push([A.scarePod[0],A.scarePod[1],1]);
    P.pods=L.map(([u,v,sc],i)=>{const [x,y]=postXY(u,v);return {x,y,i,scare:!!sc,broken:!!A.podsOpen,a:W>=H?0:Math.PI/2};});}
  P.breach=A.breach.map(([u,v,r])=>{const [x,y]=postXY(u,v);return {x,y,r:postR(r)};});
  P.edoor=null;if(A.edoor){const r=postRect(A.edoor),wa={x0:r.x0,y0:r.y0,x1:r.x0,y1:r.y0},wb={x0:r.x1,y0:r.y1,x1:r.x1,y1:r.y1};P.edoor={r,k:0,shut:false,wa,wb};P.walls.push(wa,wb);}
  // кабели свисают с концов переборок
  {const R=pRng(31+n*7);P.cables=[];for(const w of P.walls){if(w.edge)continue;const vert=w.y1-w.y0>w.x1-w.x0;for(const end of [0,1]){if(R()<.35)continue;
      const x=vert?(R()<.5?w.x0:w.x1):(end?w.x1:w.x0),y=vert?(end?w.y1:w.y0):(R()<.5?w.y0:w.y1);if(x<4||x>W-4||y<4||y>H-4)continue;
      P.cables.push({x,y,len:30+R()*45,ph:R()*TAU,dir:Math.atan2(H/2-y,W/2-x)+(R()-.5)*1.2});}}}
  P.escape=0;P.allIce=false;P.events={};P.fakeT=rnd(7,11);P.knockT=rnd(4,7);P.spawnT=8;
  P.front=null;P.inFront=false;P.sparks=[];P.glim=null;P.pend=null;P.fl=1;P.flTarget=1;P.flT=rnd(2,4);P.flk=0;P.groanT=rnd(3,6);P.whisT=4;P.brT=0;P.clT=0;P.sparkT=rnd(2,5);P.glimT=rnd(12,20);P.klT=0;P.glitch=0;P.trail=[];P.deck=null;P.hbPulse=0;
  P.hatch=null;if(A.key==='lock'){const [x,y]=postXY(.012,.5);P.hatch={x,y,k:0,t:0};}
  const [sx,sy]=postXY(A.start[0],A.start[1]);p.x=sx;p.y=sy;p.px=sx;p.py=sy;p.vx=p.vy=0;p.inv=Math.max(p.inv,1.2);
  P.aim=(A.aim||0)+(W>=H?0:Math.PI/2);
  G.enemies=[];G.eb=[];G.pb=[];G.warns=[];G.pick=[];G.ice=0;G.frozen=0;
  P.cp={act:n,hp:keepHp!==undefined?keepHp:p.hp,en:p.en};
  const O=P.O;O.st='off';O.x=-999;O.y=-999;O.cd=rnd(...postDK().wcd)+(A.key==='cryo'?6:3);O.seen=0;
  P.bn=false;
}
function postSetup(){const p=G.player;G.post={act:0,t:0,freezes:0,O:{st:'off',x:-999,y:-999,cd:9,t:0,seen:0},hb:0,scares:0,scDone:{},deaths:0,logsGot:[],cp:null,duck:0};
  postLoadAct(0,p.hp);G.post.cp.hp=p.hp;postAudio(true);}
// --- столкновения
function postPush(o,r){for(const w of G.post.walls){const cx=clamp(o.x,w.x0,w.x1),cy=clamp(o.y,w.y0,w.y1),dx=o.x-cx,dy=o.y-cy,d=Math.hypot(dx,dy);
  if(d<r){if(d>0.01){o.x=cx+dx/d*r;o.y=cy+dy/d*r;}else{const l=o.x-w.x0,R_=w.x1-o.x,t_=o.y-w.y0,b_=w.y1-o.y,m=Math.min(l,R_,t_,b_);if(m===l)o.x=w.x0-r;else if(m===R_)o.x=w.x1+r;else if(m===t_)o.y=w.y0-r;else o.y=w.y1+r;}}}}
function postInWall(x,y){for(const w of G.post.walls)if(x>w.x0&&x<w.x1&&y>w.y0&&y<w.y1)return true;return false;}
function postInIce(x,y){if(G.post.allIce)return true;for(const r of G.post.ice)if(x>r.x0&&x<r.x1&&y>r.y0&&y<r.y1)return true;return false;}
function postLit(x,y,pad){const P=G.post;pad=pad||0;for(const L of P.lamps)if(L.on&&L.fl>.5&&Math.hypot(x-L.x,y-L.y)<L.r*.7+pad)return true;for(const g of P.gens)if(g.on&&Math.hypot(x-g.x,y-g.y)<postR(.3)+pad)return true;
  if(P.core&&P.core.on&&P.escape<=0&&Math.hypot(x-P.core.x,y-P.core.y)<postR(.25)+pad)return true;return false;}
function postWarm(x,y){const P=G.post;for(const L of P.lamps)if(L.on&&Math.hypot(x-L.x,y-L.y)<L.r*.55)return true;for(const g of P.gens)if(g.on&&Math.hypot(x-g.x,y-g.y)<postR(.22))return true;return false;}
// отрезок пересекает переборку — для тени фонаря и «видит ли игрок Наблюдателя»
function postSegBlocked(x0,y0,x1,y1){for(const w of G.post.walls){if(w.x1-w.x0<1||w.y1-w.y0<1)continue;let t0=0,t1=1;const dx=x1-x0,dy=y1-y0;let ok=true;
  for(const [p,q] of [[-dx,x0-w.x0],[dx,w.x1-x0],[-dy,y0-w.y0],[dy,w.y1-y0]]){if(p===0){if(q<0){ok=false;break;}}else{const r=q/p;if(p<0){if(r>t1){ok=false;break;}if(r>t0)t0=r;}else{if(r<t0){ok=false;break;}if(r<t1)t1=r;}}}
  if(ok&&t0<=t1)return true;}return false;}
function postConeR(){const D=postDK(),P=G.post;return D.cone*(G.frozen>0?.5:1)*(1-.25*(G.ice||0)/3)*(.35+.65*P.fl);}
function postSees(x,y){const P=G.post,p=G.player;if(P.fl<.5||P.blackout>0)return false;const d=Math.hypot(x-p.x,y-p.y);if(d<60)return true;if(d>postConeR()*.95)return false;
  let da=Math.atan2(y-p.y,x-p.x)-(P.aim??0);da=Math.atan2(Math.sin(da),Math.cos(da));if(Math.abs(da)>.5)return false;return !postSegBlocked(p.x,p.y,x,y);}
// --- ход миссии
function postTick(dt){const P=G.post,p=G.player,A=POST_ACTS[P.act],D=postDK(),O=P.O;if(!P||!p)return;P.t+=dt;P.at+=dt;
  if(!P.bn){P.bn=true;if(!P.cpSet){P.cpSet=1;P.cp.hp=p.hp;}} // без больших плашек: название палубы — только в строке сверху
  {const r={lock:[2.6,5],cryo:[4,6],loop:[3.5,6],eng:[6,1]}[A.key];if(r&&P.at>r[0]&&!P.events.r){P.events.r=1;radioSay('Х',r[1]);}}
  P.fade=Math.max(0,P.fade-dt*.9);P.flash=Math.max(0,P.flash-dt*2);P.glitch=Math.max(0,P.glitch-dt);P.hbPulse=Math.max(0,P.hbPulse-dt*2.2);
  const sp=Math.hypot(p.vx,p.vy);if(sp>20)P.aim=Math.atan2(p.vy,p.vx);
  P.trail.push([p.x,p.y]);if(P.trail.length>150)P.trail.shift();
  // внешний люк за спиной закрывается — назад дороги нет
  if(P.hatch&&P.hatch.k<1){P.hatch.t+=dt;if(P.hatch.t>1.1){const k0=P.hatch.k;P.hatch.k=Math.min(1,P.hatch.k+dt*1.6);if(k0<1&&P.hatch.k>=1){postSnd('slam',0,1.3);shake(10);}}}
  // фонарь: долгие ровные периоды и короткие серии сбоев; рядом с Наблюдателем, в побеге и при заморозке — чаще
  const dO=O.st!=='off'&&O.st!=='flee'?Math.hypot(O.x-p.x,O.y-p.y):999,nerv=(dO<380?1-dO/380:0)+(P.escape>0?.35:0)+(G.frozen>0?.3:0);
  P.flT-=dt;if(P.flT<=0){if(P.flk>0){P.flk--;P.flTarget=P.flTarget<.6?1:rnd(.04,.35);P.flT=rnd(.04,.13);}else{P.flTarget=1;P.flT=rnd(2.5,6)*(1-Math.min(.8,nerv*.7));P.flk=Math.random()<.35+nerv*.6?2+(Math.random()*5|0):0;}}
  if(lessFx25())P.flTarget=Math.max(P.flTarget,.55);P.fl+=(P.flTarget-P.fl)*Math.min(1,dt*30);
  for(const L of P.lamps){if(!L.on){L.fl=0;continue;}L.flT-=dt;if(L.flT<=0){L.flT=Math.random()<.15?rnd(.05,.12):rnd(1.5,7);L.ft=L.flT<.2?rnd(.1,.5):1;}L.fl+=((L.ft??1)-L.fl)*Math.min(1,dt*25);}
  for(const b of P.beacons)b.a+=b.w*dt*(P.escape>0?2.2:1);
  // переборки
  if(p.hp>0)postPush(p,p.r);for(const e of G.enemies)if(e.alive&&!STATIC.has(e.type))postPush(e,e.r);
  for(const b of G.pb)if(b.life>0&&postInWall(b.x,b.y)){b.life=0;if(SET.fx)part(b.x,b.y,rnd(-40,40),rnd(-40,40),.15,'#9fd8ff',1.5);}
  for(const b of G.eb)if(b.life>0&&postInWall(b.x,b.y))b.life=0;
  // лёд под днищем
  {const on=p.hp>0&&(postInIce(p.x,p.y)||P.inFront);G.slick=on;G.slickK=on?(P.inFront?1.2:1.6):undefined;}
  // холод
  const warm=postWarm(p.x,p.y);
  if(A.cold&&p.hp>0){if(warm&&!P.inFront){P.cold=Math.max(0,P.cold-dt*.8);if(G.ice>0&&!(G.frozen>0)){P.thaw=(P.thaw||0)+dt;if(P.thaw>.8){P.thaw=0;G.ice=Math.max(0,G.ice-1);}}}
    else{P.cold+=dt*D.cold*(P.inFront?5:P.escape>0&&P.escT<=0?3:1);if(P.cold>=1){P.cold=0;const f0=G.frozen>0;addIce(1);if(!f0&&G.frozen>0){P.freezes++;postSnd('crack');}}}}
  // объекты палубы
  for(const pn of P.panels){if(pn.on)continue;if(p.hp>0&&Math.hypot(p.x-pn.x,p.y-pn.y)<48){pn.h+=dt;if(pn.h>=1.2){pn.on=true;sfx('cell');floater(pn.x,pn.y-30,'ЩИТОК ВКЛЮЧЁН','#8fe9ff');const L=P.lamps.find(l=>l.key==='p'+pn.i);if(L){L.on=true;L.fl=0;L.ft=1;L.flT=.6;}postOnPanel(pn.i);}}else pn.h=Math.max(0,pn.h-dt);}
  for(const c of P.cells){if(c.got)continue;if(p.hp>0&&Math.hypot(p.x-c.x,p.y-c.y)<32){c.got=true;sfx('cell');floater(c.x,c.y-26,'ТЕРМОЭЛЕМЕНТ','#ffd9a0');if(P.cells.every(q=>q.got)){floater(P.door.x,P.door.y-44,'ШЛЮЗ ОТКРЫТ','#7affc9');sfx('level');}else if(P.cells.filter(q=>q.got).length===1)radioSay('Х',1);}}
  for(const g of P.gens){if(g.on)continue;const inR=p.hp>0&&Math.hypot(p.x-g.x,p.y-g.y)<70;g.h=inR?g.h+dt:Math.max(0,g.h-dt*.5);
    if(inR&&!g.sp){g.sp=1;for(let k=0;k<2;k++)postSpawn('shade');}
    if(inR&&O.st==='lurk')O.cd-=dt*.6; // шум генератора приманивает его
    if(g.h>=6){g.on=true;sfx('level');shake(6);floater(g.x,g.y-40,'ГЕНЕРАТОР ЗАПУЩЕН','#ffd9a0');G.shock.push({x:g.x,y:g.y,r:10,R:postR(.3),t:0,col:'#ffd9a0',slow:true});
      const n=P.gens.filter(q=>q.on).length;if(n===3){floater(P.door.x,P.door.y-44,'ШЛЮЗ ОТКРЫТ','#7affc9');postQueue(2,1.3);}else if(n===2){radioSay('Х',2);const a=rnd(0,TAU);postFig('crew',g.x+Math.cos(a)*110,g.y+Math.sin(a)*110,.9);}}}
  if(P.core&&!P.core.on){const inR=p.hp>0&&Math.hypot(p.x-P.core.x,p.y-P.core.y)<75;P.core.h=inR?P.core.h+dt:Math.max(0,P.core.h-dt*.5);
    if(P.core.h>=4){P.core.on=true;P.escape=D.esc;P.escT=D.esc;P.allIce=false;P.failT=2.5;P.front=1.04;banner('РАЗГЕРМЕТИЗАЦИЯ','РЕАКТОР ЗАПУЩЕН · К ШЛЮЗУ');sfx('bigboom');shake(16);radioSay('Х',4);O.cd=Math.min(O.cd,3);
      postSnd('stinger',0,.8);}}
  if(P.escape>0){P.escT-=dt;P.failT-=dt;if(P.failT<=0){P.failT=P.escape/(P.lamps.length+1);const on=P.lamps.filter(L=>L.on).sort((a,b)=>W>=H?b.x-a.x:b.y-a.y);if(on.length){on[0].on=false;on[0].fail=1;postSnd('crack');shake(3);}}
    if(P.escT<=0&&!P.events.late){P.events.late=1;banner('КОРАБЛЬ ЗАМЕРЗАЕТ','ХОЛОД СИЛЬНЕЕ');}
    // ледяной фронт идёт от реактора к шлюзу; внутри него — лёд и мороз в пять раз сильнее
    P.front=Math.max(-.2,P.front-dt/(D.esc*1.25));const [u]=postUV(p.x,p.y);const was=P.inFront;P.inFront=p.hp>0&&u>P.front;if(P.inFront&&!was){postSnd('crack',0,1.4);shake(5);}
    P.klT-=dt;if(P.klT<=0){P.klT=1.15;postSnd('klaxon');}
    // аварийная переборка сходится; пока корабль не прошёл — оставляет узкую щель
    const E=P.edoor;if(E&&!E.shut){const vert=E.r.y1-E.r.y0>=E.r.x1-E.r.x0,len=vert?E.r.y1-E.r.y0:E.r.x1-E.r.x0,[pu]=postUV(p.x,p.y),passed=pu<A.edoor[0]-.03;
      const kMax=passed?1:Math.max(0,1-(p.r*2+44)/len);E.k=Math.min(kMax,E.k+(passed?dt*2.5:dt/(D.esc*.55)));/* прошли — переборка захлопывается за спиной */const h=len*E.k/2;
      if(vert){Object.assign(E.wa,{x0:E.r.x0,x1:E.r.x1,y0:E.r.y0,y1:E.r.y0+h});Object.assign(E.wb,{x0:E.r.x0,x1:E.r.x1,y0:E.r.y1-h,y1:E.r.y1});}
      else{Object.assign(E.wa,{y0:E.r.y0,y1:E.r.y1,x0:E.r.x0,x1:E.r.x0+h});Object.assign(E.wb,{y0:E.r.y0,y1:E.r.y1,x0:E.r.x1-h,x1:E.r.x1});}
      if(E.k>=1){E.shut=true;postSnd('slam',0,1.2);shake(9);}}}
  // выход
  if(P.trig&&!P.trig.hit&&p.hp>0&&Math.hypot(p.x-P.trig.x,p.y-P.trig.y)<120){P.trig.hit=true;postRollCall();}
  const ready=(!P.trig||P.trig.hit)&&(P.panels.length?P.panels.every(q=>q.on):true)&&(P.cells.length?P.cells.every(q=>q.got):true)&&(P.gens.length?P.gens.every(q=>q.on):true)&&(P.core?P.core.on:true);
  P.door.open=ready;P.door.k=Math.min(1,Math.max(0,P.door.k+(ready?dt*1.5:-dt*3)));if(ready&&p.hp>0&&Math.hypot(p.x-P.door.x,p.y-P.door.y)<60){if(P.act<POST_ACTS.length-1){P.fadeTo=1;postLoadAct(P.act+1,p.hp);sfx('flash');postSnd('slam',0,.8);}else postWin();return;}
  // записи на замёрзших кораблях
  for(const w of P.wrecks){if(w.read||p.hp<=0)continue;if(Math.hypot(p.x-w.x,p.y-w.y)<56){w.read=true;const L=POST_LOGS[w.li];if(!P.logsGot.includes(w.li))P.logsGot.push(w.li);toast(L.title,L.text);sfx('pick');}}
  // то, что двигается, только пока вы не смотрите: замёрзшие VØID и скафандры поворачиваются к вам
  for(const w of P.wrecks)if((w.mirror&&P.scDone.sc3)||(!w.mirror&&!postSees(w.x,w.y))){const ta=Math.atan2(p.y-w.y,p.x-w.x);let da=ta-w.a;da=Math.atan2(Math.sin(da),Math.cos(da));w.a+=da*Math.min(1,dt*(w.mirror?2.5:6));}
  for(const q of P.suits){if(q.gone)continue;const seen=postSees(q.x,q.y);if(!seen){q.f=Math.atan2(p.y-q.y,p.x-q.x);if(q.i===9&&postUV(p.x,p.y)[0]>.55&&!P.events.suitGone){P.events.suitGone=1;q.gone=true;}}}
  // тени из тьмы
  if(A.key!=='loop'&&(A.key!=='lock'||P.panels.some(q=>q.on))){P.spawnT-=dt;const cap=A.key==='lock'?2:A.key==='core'?4:3;if(P.spawnT<=0){P.spawnT=rnd(9,13);if(G.enemies.filter(e=>e.alive).length<cap)postSpawn(Math.random()<.25&&(A.key==='eng'||A.key==='core')?'phantom':'shade');}}
  // ложные сигналы и стук
  P.fakeT-=dt;if(P.fakeT<=0){P.fakeT=rnd(14,22);P.fake={a:rnd(0,TAU),t:.9};sfx('warn');}if(P.fake){P.fake.t-=dt;if(P.fake.t<=0)P.fake=null;}
  P.knockT-=dt;if(P.knockT<=0){P.knockT=rnd(9,16);postSnd('knock',rnd(-1,1));}
  postDirector(dt,dO);postWatcher(dt);postAudioTick(dt);
}
// --- режиссёр страха: сценарии с тишиной перед ударом, искры, то, что видно краем глаза, звуки корпуса
function postQueue(n,t){const P=G.post;if(P.scDone['sc'+n]||P.pend)return;P.pend={n,t};}
function postDirector(dt,dO){const P=G.post,p=G.player,O=P.O,A=POST_ACTS[P.act],K=A.key,lf=lessFx25();
  if(P.pend){P.duck=Math.min(1,P.duck+dt*3);P.pend.t-=dt;if(P.pend.t<=0){const n=P.pend.n;P.pend=null;postScare(n);}}else P.duck=Math.max(0,P.duck-dt*.7);
  if(K==='loop'&&!(P.trig&&P.trig.hit&&P.at-P.trig.at>1.5))P.duck=1; // повтор палубы — полная тишина, слышно только свой двигатель
  if(K==='lock'&&P.panels.filter(q=>q.on).length>=2&&!P.events.k0){P.events.k0=1;postQueue(0,1.5);}
  if(K==='cryo'){const pd=P.pods.find(q=>q.scare&&!q.broken);if(pd&&Math.hypot(p.x-pd.x,p.y-pd.y)<150&&!P.events.pod){P.events.pod=1;postQueue(1,1.1);}}
  if(K==='core'){const w=P.wrecks.find(q=>q.mirror);if(w&&Math.hypot(p.x-w.x,p.y-w.y)<190&&!P.events.mir){P.events.mir=1;postQueue(3,.9);}
    if(!P.events.hall&&postUV(p.x,p.y)[0]>.52&&P.core&&!P.core.on){P.events.hall=1;postFig('pilot',P.core.x,P.core.y,.7);}}
  // музыкальная шкатулка: где-то среди капсул; на криопалубе — у капсулы-ловушки, на повторе — в темноте посередине
  {let src=null;if(K==='cryo'){const pd=P.pods.find(q=>q.scare&&!q.broken);if(pd)src=pd;}else if(K==='loop'&&P.trig&&!P.trig.hit)src=P.trig;
    if(src){const d=Math.hypot(p.x-src.x,p.y-src.y);if(d<700&&d>110){P.mbT-=dt;if(P.mbT<=0){const MB=[659,784,740,659,587,659,494,523,494,440];const f=MB[P.mbI%MB.length]*(K==='loop'?.94:1);P.mbI++;P.mbT=K==='loop'?.75:.52;postSnd('note',clamp((src.x-p.x)/350,-1,1),.55*(1-d/700),f);}}}}
  // искры с оборванных кабелей; во вспышке иногда стоит он
  P.sparkT-=dt;if(P.sparkT<=0&&P.cables.length&&K!=='loop'){P.sparkT=rnd(3,8);const c=P.cables[(Math.random()*P.cables.length)|0],ex=c.x+Math.cos(c.dir)*c.len,ey=c.y+Math.sin(c.dir)*c.len;
    P.sparks.push({x:ex,y:ey,t:.2});postSnd('spark',clamp((ex-p.x)/400,-1,1),.8);if(SET.fx)for(let k=0;k<8;k++)part(ex,ey,vrnd2(-140,140),vrnd2(-60,160),.4,'#dff6ff',1.6);
    if(K!=='lock'&&O.st==='off'&&!lf&&Math.random()<.4){const a=rnd(0,TAU),gx=ex+Math.cos(a)*70,gy=ey+Math.sin(a)*70;if(postFree(gx,gy,10))P.glim={x:gx,y:gy,t:.3,t0:.3};}}
  for(const s of P.sparks)s.t-=dt;P.sparks=P.sparks.filter(s=>s.t>0);
  // силуэт Наблюдателя на краю луча
  if(K!=='lock'&&K!=='loop'&&O.st==='off'&&!P.glim){P.glimT-=dt;if(P.glimT<=0){P.glimT=rnd(14,26);const a=(P.aim??0)+(Math.random()<.5?-1:1)*.62,R=postConeR()*.78,gx=p.x+Math.cos(a)*R,gy=p.y+Math.sin(a)*R;
    if(postFree(gx,gy,10)&&!postSegBlocked(p.x,p.y,gx,gy)){P.glim={x:gx,y:gy,t:.28,t0:.28};postSnd('whisper',clamp((gx-p.x)/300,-1,1),.5);}}}
  if(P.glim){P.glim.t-=dt;if(P.glim.t<=0)P.glim=null;}
  // неизвестные: на долю секунды, со сбоем картинки — экипаж в скафандрах, бледная копия вашего корабля, кто-то прямо за спиной
  if(K!=='loop'&&(K!=='lock'||P.panels.some(q=>q.on))){P.figT-=dt;if(P.figT<=0){P.figT=K==='lock'?rnd(16,24):rnd(9,16);const r=Math.random();
    if(r<.15){const a=(P.aim??0)+Math.PI+rnd(-.5,.5),x=p.x+Math.cos(a)*70,y=p.y+Math.sin(a)*70;if(postFree(x,y,8))postFig('crew',x,y,.45);}
    else{for(let k=0;k<10;k++){const a=(P.aim??0)+rnd(-.5,.5),d=rnd(150,320),x=p.x+Math.cos(a)*d,y=p.y+Math.sin(a)*d;if(postFree(x,y,14)&&!postSegBlocked(p.x,p.y,x,y)){postFig(r<.32&&K!=='lock'?'pilot':'crew',x,y,rnd(.5,1.1));break;}}}}}
  for(const f of P.figs)f.t-=dt;P.figs=P.figs.filter(f=>f.t>0);
  // резкие мерцания: свет гаснет и вспыхивает сериями; в одной из вспышек кто-то стоит в луче
  if(!lf&&(K==='cryo'||K==='eng'||K==='core')){P.strT-=dt;if(P.strT<=0&&!P.strobe){P.strT=rnd(16,30);postStrobe(Math.random()<.6);}}
  if(P.strobe){const S=P.strobe;S.t-=dt;if(S.t<=0){S.i++;if(S.i>=S.seq.length)P.strobe=null;else{S.t=S.seq[S.i];S.dark=!S.dark;if(!S.dark&&S.i===S.show&&S.fig)P.figs.push({...S.fig,t:S.seq[S.i]+.02,t0:S.seq[S.i]+.02,strobe:true});}}}
  // помехи края карты на двух последних палубах — слабые, усиливаются на сбоях и в побеге
  P.rift=A.rift?(.17+.3*P.glitch+(P.escape>0?.06:0))*(lf?.5:1):(P.glitch>.2?.14*(lf?.5:1):0);
  // корпус стонет
  P.groanT-=dt;if(P.groanT<=0&&K!=='loop'){P.groanT=rnd(7,14);postSnd('groan',rnd(-1,1),.9);}
  if(O.st==='lurk'||O.st==='tele'){P.whisT-=dt;if(P.whisT<=0&&dO<520){P.whisT=rnd(3,6);postSnd('whisper',clamp((O.x-p.x)/300,-1,1),.5+.5*(1-dO/520));}
    if(dO<280&&!postSees(O.x,O.y)){P.brT-=dt;if(P.brT<=0){P.brT=2.6;postSnd('breath',clamp((O.x-p.x)/250,-1,1),1-dO/280);}}
    if(O.st==='lurk'&&!O.frz){P.clT-=dt;if(P.clT<=0){P.clT=rnd(.8,1.3);postSnd('clank',clamp((O.x-p.x)/350,-1,1),.25+.55*Math.max(0,1-dO/520));}}}}
function postFig(kind,x,y,dur){const P=G.post,p=G.player;P.figs.push({kind,x,y,t:dur,t0:dur,seed:Math.random()*1000|0});P.glitch=Math.max(P.glitch,.28);postSnd('static',clamp((x-p.x)/350,-1,1),.9);}
function postStrobe(withFig){const P=G.post,p=G.player;if(lessFx25())return;const seq=[.07,.05,.08,.04,.11,.05,.06,.09];let fig=null;
  if(withFig){for(let k=0;k<8;k++){const a=(P.aim??0)+rnd(-.35,.35),d=rnd(110,200),x=p.x+Math.cos(a)*d,y=p.y+Math.sin(a)*d;if(postFree(x,y,14)&&!postSegBlocked(p.x,p.y,x,y)){fig={kind:'crew',x,y,seed:Math.random()*1000|0};break;}}}
  P.strobe={seq,i:0,t:seq[0],dark:true,show:5,fig};postSnd('spark',0,1.2);P.glitch=Math.max(P.glitch,.2);}
// поверка: на повторе палубы в темноте стоят тринадцать — строем, лицом к вам. Одна вспышка, и их нет
function postRollCall(){const P=G.post,p=G.player,T_=P.trig;T_.at=P.at;P.figs.push({kind:'row',x:T_.x,y:T_.y,t:1.15,t0:1.15,seed:7});P.glitch=.5;postSnd('static',0,1.4);
  if(!lessFx25())P.strobe={seq:[.05,.12,.05,.3,.06,.2],i:0,t:.05,dark:true,show:-1,fig:null};
  setTimeout(()=>{try{if(G.post){postSnd('clank',0,1.2);radioSay('Х',2);const L=G.post.lamps[0];if(L){L.on=true;L.fl=0;L.ft=1;}}}catch(e){}},1300);}
function postOnPanel(i){const P=G.post;if(i===0){radioSay('Х',0);postSpawn('shade');}if(i===1){postSpawn('shade');}if(P.panels.every(q=>q.on)){floater(P.door.x,P.door.y-44,'ШЛЮЗ ОТКРЫТ','#7affc9');sfx('level');}}
function postSpawn(type){const P=G.post,p=G.player;let x,y,k=0;do{x=rnd(40,W-40);y=rnd(40,H-40);}while((Math.hypot(x-p.x,y-p.y)<300||postInWall(x,y)||postLit(x,y,40))&&++k<24);if(k>=24)return;
  const e=spawnEnemy(type,x,y,{noAffix:true});e.spawnT=.4;}
// скримеры: 0 — стук изнутри стены, 1 — капсула, 2 — свет гаснет и он прямо перед вами, 3 — замёрзший VØID-013 поворачивается. Не больше четырёх.
function postScare(n){const P=G.post,p=G.player;if(P.scares>=4||P.events['sc'+n]||P.scDone['sc'+n])return;P.events['sc'+n]=1;P.scDone['sc'+n]=1;P.scares++;
  if(n===0){let bw=null,bd=1e9,bx=0,by=0;for(const w of P.walls){if(w.edge)continue;const cx=clamp(p.x,w.x0,w.x1),cy=clamp(p.y,w.y0,w.y1),d=Math.hypot(p.x-cx,p.y-cy);if(d<bd){bd=d;bw=w;bx=cx;by=cy;}}
    postSnd('knock',bw?clamp((bx-p.x)/200,-1,1):0,2.2);setTimeout(()=>{try{if(G.post)postSnd('knock',0,2.6);}catch(e){}},700);shake(7);P.glitch=.25;
    if(bw&&SET.fx)for(let k=0;k<14;k++)part(bx,by,rnd(-90,90),rnd(-90,90),.6,'#9fb6cc',1.6);P.jolt=.5;}
  if(n===1){const pd=P.pods.find(q=>q.scare&&!q.broken)||P.pods[0];if(pd){pd.broken=true;postSnd('stinger',clamp((pd.x-p.x)/300,-1,1),1.1);postSnd('crack',0,1.5);shake(9);P.glitch=.35;
      if(SET.fx)for(let k=0;k<26;k++)part(pd.x,pd.y,rnd(-260,260),rnd(-260,260),.7,'#dff6ff',2.2);
      const e=spawnEnemy('shade',clamp(pd.x,30,W-30),clamp(pd.y,30,H-30),{noAffix:true});e.st='rev';e.timer=.7;e.reveal=1;}
    else{const a=Math.atan2(p.vy||1,p.vx||0)+Math.PI;const e=spawnEnemy('shade',clamp(p.x+Math.cos(a)*140,30,W-30),clamp(p.y+Math.sin(a)*140,30,H-30),{noAffix:true});e.st='rev';e.timer=.7;e.reveal=1;postSnd('stinger',0,1);shake(5);}}
  if(n===2){P.blackout=lessFx25()?0:1.3;const O=P.O;const a=(P.aim??0);O.x=clamp(p.x+Math.cos(a)*110,30,W-30);O.y=clamp(p.y+Math.sin(a)*110,30,H-30);O.st='show';O.t=1.3;postSnd('breath',0,1.4);setTimeout(()=>{try{if(G.post){postSnd('stinger',0,1.2);G.post.glitch=.4;shake(8);}}catch(e){}},1150);}
  if(n===3){const w=P.wrecks.find(q=>q.mirror);if(w){radioSay('Х',3);postSnd('whisper',clamp((w.x-p.x)/300,-1,1),1.3);P.glitch=.3;}}}
function lessFx25(){return document.documentElement.classList.contains('lessfx');}
// --- Наблюдатель: держится на краю света; пока на него смотрят — замирает, потом отступает; бросается, когда корабль замёрз или во тьме
function postWatcher(dt){const P=G.post,O=P.O,p=G.player,D=postDK(),A=POST_ACTS[P.act];
  const allowed=A.watcher==='all'||(A.watcher==='mid'&&G.diff!=='easy');
  if(P.blackout>0)P.blackout-=dt;
  if(O.st==='show'){O.t-=dt;if(O.t<=0){O.st='off';O.cd=rnd(...D.wcd);}return;}
  if(!allowed||p.hp<=0){O.st='off';return;}
  const chase=P.escape>0,spd=D.wsp*(chase?1.35:1),orbit=chase?170:230;
  if(O.st==='off'){O.cd-=dt;if(O.cd<=0){let k=0;do{const a=rnd(0,TAU);O.x=p.x+Math.cos(a)*420;O.y=p.y+Math.sin(a)*420;}while((postInWall(O.x,O.y)||postLit(O.x,O.y)||postSees(O.x,O.y))&&++k<12);O.st='lurk';O.seen=0;O.cd=rnd(...D.wcd)*(chase?.6:1);O.oa=Math.atan2(O.y-p.y,O.x-p.x);}return;}
  const d=Math.hypot(O.x-p.x,O.y-p.y);
  if(O.st==='lurk'){const seen=postSees(O.x,O.y);O.frz=seen;
    if(seen){O.seen+=dt;if(O.seen>.6&&!chase){O.st='flee';O.t=1.4;postSnd('whisper',clamp((O.x-p.x)/300,-1,1),1.2);return;}}
    else{O.seen=Math.max(0,O.seen-dt*.5);O.oa+=dt*.35;const tx=p.x+Math.cos(O.oa)*orbit,ty=p.y+Math.sin(O.oa)*orbit;const a=Math.atan2(ty-O.y,tx-O.x);O.x+=Math.cos(a)*spd*dt;O.y+=Math.sin(a)*spd*dt;}
    if(postLit(O.x,O.y,20)){O.st='flee';O.t=1.5;}
    O.cd-=dt*(G.frozen>0?3:1)*(seen?.3:1);const exposed=!postLit(p.x,p.y,10);if(O.cd<=0&&exposed&&d<520){O.st='tele';O.t=D.tele;O.tx=p.x;O.ty=p.y;postSnd('heart',Math.sign(O.x-p.x),1.2);P.hbPulse=1;}}
  else if(O.st==='tele'){O.t-=dt;O.tx=p.x;O.ty=p.y;if(O.t<=0){O.st='strike';O.t=.7;const a=Math.atan2(O.ty-O.y,O.tx-O.x);O.vx=Math.cos(a)*560;O.vy=Math.sin(a)*560;postSnd('stinger',clamp((O.x-p.x)/300,-1,1),.7);P.glitch=.3;}}
  else if(O.st==='strike'){O.t-=dt;O.x+=O.vx*dt;O.y+=O.vy*dt;if(p.hp>0&&d<30){damagePlayer(D.hit);const f0=G.frozen>0;addIce(2);if(!f0&&G.frozen>0)P.freezes++;postSnd('hit');P.glitch=.45;O.st='flee';O.t=2.5;}
    else if(O.t<=0||postLit(O.x,O.y)){O.st='flee';O.t=1.8;}}
  else if(O.st==='flee'){O.t-=dt;const a=Math.atan2(O.y-p.y,O.x-p.x);O.x+=Math.cos(a)*spd*2.2*dt;O.y+=Math.sin(a)*spd*2.2*dt;if(O.t<=0){O.st='off';O.cd=rnd(...D.wcd)*(chase?.6:1);}}
}
function postOnPulse(){const P=G.post,O=P&&P.O,p=G.player;if(!P)return;P.flash=1;if(O&&O.st!=='off'&&O.st!=='show'&&Math.hypot(O.x-p.x,O.y-p.y)<300){O.st='flee';O.t=3;O.cd=8;floater(p.x,p.y-40,'ОТОГНАН','#bfe8ff');}}
function postRespawn(){const P=G.post,p=G.player,cp=P.cp;P.deaths++;
  const hard=G.diff==='hard';if(hard&&cp.act<POST_ACTS.length-1)return false;
  p.hp=Math.max(cp.hp,G.st.maxHp*.4);p.en=cp.en;G.deadT=0;scr6('play');
  postLoadAct(cp.act,p.hp);P.cp.hp=Math.max(cp.hp,G.st.maxHp*.4);banner('ТОЧКА ВОЗВРАТА','ПАЛУБА '+(cp.act+1));show('');return true;}
// прохождение: без экрана итогов — корабль выходит из кормового шлюза прямо в сектор III
function postWin(){const P=G.post,S=G.save,p=G.player;if(!S)return;const ps=postSave(),first=!ps.done,D=curDiff();
  ps.done=1;const tsec=Math.round(P.t);if(!ps.best||tsec<ps.best)ps.best=tsec;ps.freezes=ps.freezes<0?P.freezes:Math.min(ps.freezes,P.freezes);
  for(const li of P.logsGot)if(!ps.logs.includes(li))ps.logs.push(li);
  let lom=Math.round((first?180:40)*D.lom);let skin=false;
  if(P.freezes===0&&!S.ownSkins.includes('izmo')){S.ownSkins.push('izmo');skin=true;}
  S.lom+=lom;addPilotXP(first?120:30);if(S.story)S.story.post=1;
  try{FOGC.k=null;if(typeof MAPC!=='undefined'){MAPC.fog=null;MAPC.fogVer=null;}}catch(e){}
  G.postMsg=first?1:2;G.postRes={t:tsec,lom,skin,fr:P.freezes,logs:ps.logs.length};postAudio(false);
  S.pos={x:POST_EXIT.x,y:POST_EXIT.y};S.last={...S.pos};saveWorld();
  scr6('done');returnToWorld();}
// --- отрисовка: палуба рисуется один раз на отсек в отдельный холст, сверху — живое
function postBuildDeck(P,k){const c=document.createElement('canvas');c.width=Math.max(1,Math.round(W*k));c.height=Math.max(1,Math.round(H*k));const X=c.getContext('2d');X.scale(k,k);const R=pRng(101+P.act*53);
  // пол: плиты со швами и заклёпками
  X.fillStyle='#05080d';X.fillRect(0,0,W,H);const S=56;
  for(let y=0,row=0;y<H;y+=S,row++)for(let x=(row%2)*S/2-S;x<W;x+=S){X.fillStyle=`rgba(140,170,210,${(.012+R()*.03).toFixed(3)})`;X.fillRect(x+1,y+1,S-2,S-2);
    X.fillStyle='rgba(160,190,230,.14)';for(const [dx,dy] of [[5,5],[S-5,5],[5,S-5],[S-5,S-5]]){X.fillRect(x+dx-1,y+dy-1,2,2);}}
  X.strokeStyle='rgba(0,0,0,.55)';X.lineWidth=1.5;for(let y=0;y<H;y+=S){X.beginPath();X.moveTo(0,y);X.lineTo(W,y);X.stroke();}
  // решётки вдоль длинных переборок
  // лёд: иней на полу
  for(const r of P.ice){X.fillStyle='rgba(170,220,255,.07)';X.fillRect(r.x0,r.y0,r.x1-r.x0,r.y1-r.y0);X.strokeStyle='rgba(210,240,255,.22)';X.lineWidth=1;
    for(const [x,y,a,l] of r.cr){X.beginPath();X.moveTo(x,y);X.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l);X.lineTo(x+Math.cos(a+.6)*l*1.4,y+Math.sin(a+.6)*l*1.4);X.moveTo(x+Math.cos(a)*l*.5,y+Math.sin(a)*l*.5);X.lineTo(x+Math.cos(a-.9)*l*.9,y+Math.sin(a-.9)*l*.9);X.stroke();}
    for(let i=0;i<4;i++){const x=r.x0+R()*(r.x1-r.x0),y=r.y0+R()*(r.y1-r.y0),g=X.createRadialGradient(x,y,0,x,y,60);g.addColorStop(0,'rgba(220,245,255,.07)');g.addColorStop(1,'rgba(220,245,255,0)');X.fillStyle=g;X.fillRect(x-60,y-60,120,120);}}
  // пятна — тёмные, замёрзшие; следы волочения
  for(let i=0;i<6;i++){let x,y,t=0;do{x=R()*W;y=R()*H;}while(!postFree(x,y,30)&&++t<20);if(t>=20)continue;
    for(let j=0;j<4;j++){const bx=x+(R()-.5)*40,by=y+(R()-.5)*30,br=10+R()*26,g=X.createRadialGradient(bx,by,0,bx,by,br);g.addColorStop(0,'rgba(64,6,12,.55)');g.addColorStop(1,'rgba(64,6,12,0)');X.fillStyle=g;X.beginPath();X.arc(bx,by,br,0,TAU);X.fill();}
    if(R()<.6){const a=R()*TAU,l=60+R()*110;X.strokeStyle='rgba(64,6,12,.32)';X.lineWidth=9;X.lineCap='round';X.beginPath();X.moveTo(x,y);X.quadraticCurveTo(x+Math.cos(a+.4)*l*.5,y+Math.sin(a+.4)*l*.5,x+Math.cos(a)*l,y+Math.sin(a)*l);X.stroke();X.lineCap='butt';}}
  // следы когтей: три борозды в металле
  for(const c of P.claws){X.save();X.translate(c.x,c.y);X.rotate(c.a);for(let k=-1;k<=1;k++){X.strokeStyle='#120306';X.lineWidth=3.5;X.beginPath();X.moveTo(-70,k*10);X.quadraticCurveTo(0,k*10+8,70,k*13);X.stroke();
      X.strokeStyle='rgba(200,220,245,.16)';X.lineWidth=1;X.beginPath();X.moveTo(-68,k*10-2.5);X.quadraticCurveTo(0,k*10+5.5,68,k*13-2.5);X.stroke();}X.restore();}
  // судовая роль у шлюза: двенадцать строк и тринадцатая, процарапанная от руки
  if(P.roster){const [x,y]=P.roster;X.save();X.translate(x,y);X.fillStyle='#0d141e';X.strokeStyle='rgba(150,185,230,.45)';X.lineWidth=1.2;X.fillRect(-34,-26,68,52);X.strokeRect(-34,-26,68,52);
    X.font='700 7px "Exo 2",sans-serif';X.textAlign='left';X.fillStyle='rgba(190,215,240,.6)';X.fillText('ЭКИПАЖ · СК-07',-29,-17);X.fillStyle='rgba(170,195,225,.4)';for(let i=0;i<12;i++)X.fillRect(-29+(i>5?30:0),-11+(i%6)*5.5,22+(i*7%6),1.6);
    X.strokeStyle='rgba(205,225,245,.75)';X.lineWidth=1;X.beginPath();X.moveTo(-29,24);for(let q=0;q<9;q++)X.lineTo(-29+q*3,24+((q*5)%3)-1.5);X.stroke();X.restore();}
  // счёт дней, процарапанный в металле
  for(const q of P.tally){X.save();X.translate(q.x,q.y);X.rotate(q.a);X.strokeStyle='rgba(200,220,245,.42)';X.lineWidth=1.3;for(let g=0;g<5;g++){for(let i=0;i<(g<4?4:2);i++){X.beginPath();X.moveTo(g*16+i*3,-7);X.lineTo(g*16+i*3+1,7);X.stroke();}if(g<4){X.beginPath();X.moveTo(g*16-2,5);X.lineTo(g*16+12,-5);X.stroke();}}X.restore();}
  // капсулы криосна
  for(const q of P.pods)if(!q.scare)postPod(X,q,0,R);
  // проломы в корпусе: сквозь них — звёзды
  for(const b of P.breach){X.save();X.globalCompositeOperation='destination-out';X.beginPath();for(let i=0;i<14;i++){const a=i/14*TAU,rr=b.r*(.7+R()*.45);X.lineTo(b.x+Math.cos(a)*rr,b.y+Math.sin(a)*rr);}X.closePath();X.fill();X.restore();
    X.strokeStyle='rgba(190,215,240,.5)';X.lineWidth=2;X.beginPath();for(let i=0;i<=14;i++){const a=i/14*TAU,rr=b.r*(1+R()*.25);X.lineTo(b.x+Math.cos(a)*rr,b.y+Math.sin(a)*rr);}X.stroke();
    for(let i=0;i<8;i++){const a=R()*TAU;X.strokeStyle='rgba(150,175,205,.5)';X.lineWidth=2;X.beginPath();X.moveTo(b.x+Math.cos(a)*b.r,b.y+Math.sin(a)*b.r);X.lineTo(b.x+Math.cos(a)*b.r*(1.25+R()*.4),b.y+Math.sin(a+(R()-.5)*.3)*b.r*(1.25+R()*.4));X.stroke();}}
  // переборки: металл, заклёпки, фаска; жёлто-чёрная разметка у проёмов; трубы вдоль длинных стен
  for(const w of P.walls){if(w.x1-w.x0<1||w.y1-w.y0<1||w.crates)continue;const ww=w.x1-w.x0,wh=w.y1-w.y0;
    const g=X.createLinearGradient(w.x0,w.y0,w.x1,w.y1);g.addColorStop(0,'#111a27');g.addColorStop(1,'#080d15');X.fillStyle=g;X.fillRect(w.x0,w.y0,ww,wh);
    X.strokeStyle='rgba(150,185,230,.32)';X.lineWidth=1.5;X.strokeRect(w.x0+.75,w.y0+.75,ww-1.5,wh-1.5);
    if(w.edge){X.strokeStyle='rgba(150,185,230,.08)';X.lineWidth=1;for(let k=0;k<Math.max(ww,wh);k+=9){X.beginPath();if(ww>wh){X.moveTo(w.x0+k,w.y0);X.lineTo(w.x0+k-14,w.y1);}else{X.moveTo(w.x0,w.y0+k);X.lineTo(w.x1,w.y0+k-14);}X.stroke();}continue;}
    X.fillStyle='rgba(170,200,235,.28)';const vert=wh>ww;for(let k=8;k<(vert?wh:ww)-6;k+=14){if(vert){X.fillRect(w.x0+3,w.y0+k,2,2);X.fillRect(w.x1-5,w.y0+k,2,2);}else{X.fillRect(w.x0+k,w.y0+3,2,2);X.fillRect(w.x0+k,w.y1-5,2,2);}}
    const ends=Math.min(ww,wh)>60?[]:vert?[[w.y0,0],[w.y1,1]]:[[w.x0,0],[w.x1,1]];
    for(const [e,s] of ends){const inside=vert?(e>3&&e<H-3):(e>3&&e<W-3);if(!inside)continue;X.save();if(vert)X.beginPath(),X.rect(w.x0,s?e-12:e,ww,12);else X.beginPath(),X.rect(s?e-12:e,w.y0,12,wh);X.clip();
      X.fillStyle='#c9a227';if(vert)X.fillRect(w.x0,s?e-12:e,ww,12);else X.fillRect(s?e-12:e,w.y0,12,wh);X.strokeStyle='#14100a';X.lineWidth=4;for(let k=-30;k<40;k+=9){X.beginPath();if(vert){X.moveTo(w.x0+k,s?e-12:e);X.lineTo(w.x0+k+12,s?e:e+12);}else{X.moveTo(s?e-12:e,w.y0+k);X.lineTo(s?e:e+12,w.y0+k+12);}X.stroke();}X.restore();}
    if(Math.max(ww,wh)>110){const side=R()<.5?-1:1;X.strokeStyle='rgba(120,150,190,.35)';X.lineWidth=4;X.beginPath();if(vert){const x=side<0?w.x0-7:w.x1+7;X.moveTo(x,w.y0+6);X.lineTo(x,w.y1-6);}else{const y=side<0?w.y0-7:w.y1+7;X.moveTo(w.x0+6,y);X.lineTo(w.x1-6,y);}X.stroke();
      X.strokeStyle='rgba(10,14,20,.9)';X.lineWidth=2;for(let k=20;k<(vert?wh:ww)-10;k+=42){X.beginPath();if(vert){const x=side<0?w.x0-7:w.x1+7;X.moveTo(x-4,w.y0+k);X.lineTo(x+4,w.y0+k);}else{const y=side<0?w.y0-7:w.y1+7;X.moveTo(w.x0+k,y-4);X.lineTo(w.x0+k,y+4);}X.stroke();}}
    if(R()<.5){const vx=vert?w.x0+ww*(R()<.5?0:1):w.x0+R()*ww,vy=vert?w.y0+R()*wh:w.y0+wh*(R()<.5?0:1);X.fillStyle='#05080d';X.beginPath();for(let i=0;i<6;i++){const a=i/6*TAU;X.lineTo(vx+Math.cos(a)*(6+R()*8),vy+Math.sin(a)*(6+R()*8));}X.closePath();X.fill();}}
  return c;}
function postPod(X,q,t,R){X.save();X.translate(q.x,q.y);X.rotate(q.a);const w=14,h=28;
  X.fillStyle='#0b121c';X.strokeStyle='rgba(150,185,230,.45)';X.lineWidth=2;X.beginPath();X.ellipse(0,0,w,h,0,0,TAU);X.fill();X.stroke();
  if(!q.broken){X.fillStyle='rgba(140,200,240,.10)';X.beginPath();X.ellipse(0,0,w-5,h-5,0,0,TAU);X.fill();
    X.fillStyle='rgba(2,4,8,.85)';X.beginPath();X.ellipse(0,3,4.5,15,0,0,TAU);X.fill();X.beginPath();X.arc(0,-15,4.5,0,TAU);X.fill();
    X.strokeStyle='rgba(220,240,255,.35)';X.lineWidth=1;for(let i=0;i<4;i++){const y=-h+8+i*12;X.beginPath();X.moveTo(-w+4,y);X.lineTo(-w+9,y+4);X.stroke();}}
  else{X.fillStyle='#020306';X.beginPath();X.ellipse(0,0,w-5,h-5,0,0,TAU);X.fill();X.strokeStyle='rgba(220,240,255,.6)';X.lineWidth=1.2;for(let i=0;i<9;i++){const a=i/9*TAU;X.beginPath();X.moveTo(Math.cos(a)*(w-5),Math.sin(a)*(h-5));X.lineTo(Math.cos(a+.2)*(w-11),Math.sin(a+.2)*(h-13));X.stroke();}}
  X.fillStyle=q.broken?'#ff3b4e':'#3a9fd8';X.fillRect(-3,h-8,6,3);X.restore();}

// --- неизвестные: экипаж в скафандрах (вид сверху), бледная копия VØID-013; рисуются со сбоем картинки
function postCrewShape(X,col,visor){X.fillStyle=col;X.beginPath();X.moveTo(-8,-12);X.lineTo(4,-13);X.quadraticCurveTo(8,0,4,13);X.lineTo(-8,12);X.quadraticCurveTo(-11,0,-8,-12);X.fill();
  X.fillRect(-3,-18,11,5);X.fillRect(-3,13,11,5);X.fillRect(-13,-7,5,14);X.beginPath();X.arc(3,0,7.6,0,TAU);X.fill();if(visor){X.fillStyle=visor;X.beginPath();X.ellipse(6.2,0,3.4,5.4,0,0,TAU);X.fill();}}
// фигура «лицом к вам», в полный рост, вне перспективы: скафандр, чёрное стекло шлема, руки чуть длиннее, чем должны быть
function postCrewFront(X,col,visor,sc){X.save();X.scale(sc,sc);X.fillStyle=col;
  X.beginPath();X.ellipse(0,-30,8.5,9.5,0,0,TAU);X.fill();                       // шлем
  X.beginPath();X.moveTo(-11,-20);X.quadraticCurveTo(0,-23,11,-20);X.lineTo(10,6);X.lineTo(-10,6);X.closePath();X.fill(); // корпус скафандра
  X.lineCap='round';X.strokeStyle=col;X.lineWidth=4.2;X.beginPath();X.moveTo(-11,-18);X.quadraticCurveTo(-15,2,-13,19);X.moveTo(11,-18);X.quadraticCurveTo(15,2,13,19);X.stroke(); // руки
  X.lineWidth=5;X.beginPath();X.moveTo(-5,5);X.lineTo(-6,30);X.moveTo(5,5);X.lineTo(6,30);X.stroke();X.lineCap='butt';           // ноги
  if(visor){X.fillStyle=visor;X.beginPath();X.ellipse(0,-30,6,6.3,0,0,TAU);X.fill();}X.restore();}
function postShipShape(X,col){X.fillStyle=col;X.beginPath();X.moveTo(19,0);X.lineTo(-11,-12);X.lineTo(-5,0);X.lineTo(-11,12);X.closePath();X.fill();}
function postDrawSuits(t){const P=G.post;if(!P||!P.suits.length)return;for(const q of P.suits){ctx.save();ctx.translate(q.x,q.y);
  ctx.strokeStyle='rgba(120,150,190,.35)';ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,15,0,TAU);ctx.stroke();
  if(!q.gone){ctx.rotate(q.f);ctx.scale(1.15,1.15);postCrewShape(ctx,'#1a2432','#04070b');ctx.strokeStyle='rgba(160,195,235,.35)';ctx.lineWidth=.8;ctx.beginPath();ctx.arc(3,0,7.6,0,TAU);ctx.stroke();}
  else{ctx.strokeStyle='rgba(150,185,230,.5)';ctx.beginPath();ctx.moveTo(-6,0);ctx.lineTo(6,0);ctx.moveTo(0,-6);ctx.lineTo(0,0);ctx.stroke();}ctx.restore();}}
function postDrawCrates(t){const P=G.post;if(!P)return;const j=P.jolt||0;for(const w of P.walls){if(!w.crates)continue;const R=pRng(Math.round(w.x0*7+w.y0*13));
  for(let y=w.y0;y<w.y1-4;y+=22)for(let x=w.x0;x<w.x1-4;x+=22){const sx=x+(R()-.5)*4+(j>0?(Math.random()-.5)*6*j:0),sy=y+(R()-.5)*4,sz=Math.min(20,w.x1-x-1,w.y1-y-1);ctx.save();ctx.translate(sx+sz/2,sy+sz/2);ctx.rotate((R()-.5)*.25);
    ctx.fillStyle='#16110b';ctx.strokeStyle='rgba(201,162,39,.45)';ctx.lineWidth=1.2;ctx.fillRect(-sz/2,-sz/2,sz,sz);ctx.strokeRect(-sz/2,-sz/2,sz,sz);ctx.beginPath();ctx.moveTo(-sz/2,-sz/2);ctx.lineTo(sz/2,sz/2);ctx.stroke();ctx.restore();}}
  if(j>0)P.jolt=Math.max(0,j-VDT74);/* ARCH·75 A-22 */}
function postDrawFig(f,t){const P=G.post,p=G.player;if(!f.strobe&&Math.random()<.22)return;const face=Math.atan2(p.y-f.y,p.x-f.x),al=f.strobe?.95:.62+.3*Math.random(),jit=(Math.random()-.5)*5;
  const draw=(dx,col,visor)=>{if(f.kind==='row'){const n=13,sp=Math.min(40,(W*.85)/n);for(let i=0;i<n;i++){const o=(i-(n-1)/2)*sp;ctx.save();ctx.translate(clamp(f.x+o+dx,10,W-10),f.y+(i===12?6:0));postCrewFront(ctx,col,visor,i===12?.95:.8);ctx.restore();}}
    else{ctx.save();ctx.translate(f.x+dx+jit,f.y);if(f.kind==='pilot'){ctx.rotate(face);ctx.scale(1.2,1.2);postShipShape(ctx,col);}else postCrewFront(ctx,col,visor,1.15);ctx.restore();}};
  ctx.save();ctx.globalAlpha=al*.5;ctx.globalCompositeOperation='lighter';draw(-4,'#ff2d55',null);draw(4,'#2de0ff',null);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=al;draw(0,f.kind==='pilot'?'#dfe9f2':'#c9d4df',f.kind==='pilot'?null:'#020306');ctx.restore();
  // разрыв картинки по горизонтали в районе фигуры
  if(!lessFx25()&&SET.fx){const T_=ctx.getTransform(),sx=T_.a*f.x+T_.e,sy=T_.d*f.y+T_.f,hh=(f.kind==='row'?60:34)*T_.d;ctx.save();ctx.setTransform(1,0,0,1,0,0);for(let i=0;i<3;i++){const y=sy-hh+Math.random()*hh*2,h=2+Math.random()*8*T_.d,dx=(Math.random()-.5)*24*T_.a;try{ctx.drawImage(cv,0,y,cv.width,h,dx,y,cv.width,h);}catch(e){}}ctx.restore();}}
let pC=null,pX=null,lC=null,lX=null,pN=null;
function postDrawUnder(t){const P=G.post;if(!P)return;const p=G.player;
  const k=Math.min(1.25,Math.max(.5,ctx.getTransform().a));if(!P.deck||P.deckAct!==P.act||Math.abs(P.deckK-k)>.05){P.deck=postBuildDeck(P,k);P.deckAct=P.act;P.deckK=k;}
  ctx.drawImage(P.deck,0,0,W,H);
  if(P.allIce||P.inFront){}
  // капсула-ловушка и внешний люк
  for(const q of P.pods)if(q.scare)postPod(ctx,q,t);
  if(P.hatch){const h=P.hatch,o=1-h.k;if(o>0){const a=W>=H?0:Math.PI/2,gr=ctx.createRadialGradient(h.x,h.y,6,h.x,h.y,340);gr.addColorStop(0,`rgba(220,240,255,${(.35*o).toFixed(3)})`);gr.addColorStop(1,'rgba(220,240,255,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.moveTo(h.x,h.y);ctx.arc(h.x,h.y,340,a-.5*o,a+.5*o);ctx.closePath();ctx.fill();}
    ctx.fillStyle='#0a0f17';ctx.strokeStyle='#c9a227';ctx.lineWidth=3;const L=120;
    if(W>=H){ctx.fillRect(h.x-6,h.y-L/2,12,L*(1-o)/2);ctx.fillRect(h.x-6,h.y+L/2-L*(1-o)/2,12,L*(1-o)/2);ctx.strokeRect(h.x-6,h.y-L/2,12,L);}
    else{ctx.fillRect(h.x-L/2,h.y-6,L*(1-o)/2,12);ctx.fillRect(h.x+L/2-L*(1-o)/2,h.y-6,L*(1-o)/2,12);ctx.strokeRect(h.x-L/2,h.y-6,L,12);}}
  // кабели качаются
  ctx.strokeStyle='#1a2230';ctx.lineWidth=2.2;for(const c of P.cables){const sw=Math.sin(t*1.3+c.ph)*.18,ex=c.x+Math.cos(c.dir+sw)*c.len,ey=c.y+Math.sin(c.dir+sw)*c.len;ctx.beginPath();ctx.moveTo(c.x,c.y);ctx.quadraticCurveTo((c.x+ex)/2+Math.cos(c.dir+1.57)*8*Math.sin(t+c.ph),(c.y+ey)/2+8,ex,ey);ctx.stroke();ctx.fillStyle='#6a7c94';ctx.fillRect(ex-1.5,ey-1.5,3,3);}
  // аварийные маячки
  for(const b of P.beacons){ctx.fillStyle='#2a0a0e';ctx.beginPath();ctx.arc(b.x,b.y,6,0,TAU);ctx.fill();ctx.fillStyle=Math.sin(b.a*2)>0?'#ff3b4e':'#8a1a24';ctx.beginPath();ctx.arc(b.x,b.y,3.5,0,TAU);ctx.fill();}
  // лампы-плафоны
  for(const L of P.lamps){ctx.fillStyle='#141c28';ctx.fillRect(L.x-9,L.y-4,18,8);ctx.fillStyle=L.on?`rgba(255,217,160,${(.25+.75*L.fl).toFixed(2)})`:L.fail?'#3a1a1a':'#202836';ctx.fillRect(L.x-7,L.y-2,14,4);}
  for(const pn of P.panels){ctx.fillStyle='#0b1220';ctx.strokeStyle=pn.on?'#7affc9':'#ff6b84';ctx.lineWidth=2;ctx.fillRect(pn.x-12,pn.y-16,24,32);ctx.strokeRect(pn.x-12,pn.y-16,24,32);
    if(!pn.on){glow(pn.x,pn.y,18,'#ff6b84',.25+.25*Math.sin(t*4));if(pn.h>0){ctx.strokeStyle='#8fe9ff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(pn.x,pn.y,26,-Math.PI/2,-Math.PI/2+TAU*pn.h/1.2);ctx.stroke();}}else glow(pn.x,pn.y,20,'#7affc9',.4);}
  for(const c of P.cells){if(c.got)continue;glow(c.x,c.y,26,'#ffd9a0',.55+.25*Math.sin(t*5));ctx.save();ctx.translate(c.x,c.y);ctx.rotate(t);ctx.strokeStyle='#ffd9a0';ctx.lineWidth=2;ctx.beginPath();for(let q=0;q<6;q++){const a=q/6*TAU;ctx.lineTo(Math.cos(a)*9,Math.sin(a)*9);}ctx.closePath();ctx.stroke();ctx.restore();}
  for(const g of P.gens){ctx.strokeStyle=g.on?'#ffd9a0':'#4a5a70';ctx.lineWidth=3;ctx.fillStyle='#0b1220';ctx.beginPath();ctx.arc(g.x,g.y,22,0,TAU);ctx.fill();ctx.stroke();
    ctx.setLineDash([5,7]);ctx.lineWidth=1.5;ctx.globalAlpha=.6;ctx.beginPath();ctx.arc(g.x,g.y,70,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;
    if(!g.on&&g.h>0){ctx.strokeStyle='#ffd9a0';ctx.lineWidth=4;ctx.beginPath();ctx.arc(g.x,g.y,32,-Math.PI/2,-Math.PI/2+TAU*g.h/6);ctx.stroke();}
    if(g.on){ctx.save();ctx.translate(g.x,g.y);ctx.rotate(t*3);ctx.strokeStyle='#ffd9a0';for(let q=0;q<3;q++){ctx.rotate(TAU/3);ctx.beginPath();ctx.moveTo(6,0);ctx.lineTo(18,0);ctx.stroke();}ctx.restore();}}
  if(P.core){const c=P.core,kk=c.on?1:.5+.3*Math.sin(t*2);ctx.save();ctx.translate(c.x,c.y);ctx.rotate(t*.4);ctx.strokeStyle=c.on?'#ffd9a0':'#8fe9ff';ctx.lineWidth=3;ctx.globalAlpha=kk;ctx.beginPath();for(let q=0;q<6;q++){const a=q/6*TAU;ctx.lineTo(Math.cos(a)*30,Math.sin(a)*30);}ctx.closePath();ctx.stroke();ctx.restore();ctx.globalAlpha=1;
    if(!c.on){ctx.setLineDash([6,8]);ctx.strokeStyle='#8fe9ff';ctx.globalAlpha=.6;ctx.beginPath();ctx.arc(c.x,c.y,75,0,TAU);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1;if(c.h>0){ctx.strokeStyle='#ffd9a0';ctx.lineWidth=4;ctx.beginPath();ctx.arc(c.x,c.y,42,-Math.PI/2,-Math.PI/2+TAU*c.h/4);ctx.stroke();}}}
  // шлюз-выход: створки расходятся, когда палуба выполнена
  {const d=P.door,o=d.k,L=56,col=d.open?'#7affc9':'#ff3b4e';ctx.fillStyle='#0a0f17';ctx.strokeStyle='#c9a227';ctx.lineWidth=2;ctx.fillRect(d.x-22,d.y-30,44,60);ctx.strokeRect(d.x-22,d.y-30,44,60);
    ctx.fillStyle='#1a2433';ctx.fillRect(d.x-20,d.y-28,20*(1-o),56);ctx.fillRect(d.x+20-20*(1-o),d.y-28,20*(1-o),56);if(o>.05){ctx.fillStyle='rgba(122,255,201,.18)';ctx.fillRect(d.x-20*o,d.y-28,40*o,56);}
    glow(d.x,d.y-36,10,col,d.open?.7+.3*Math.sin(t*5):.35+.35*(Math.sin(t*3)>0?1:0));}
  // замёрзшие VØID — такие же, как вы
  for(const w of P.wrecks){ctx.save();ctx.translate(w.x,w.y);ctx.rotate(w.a);ctx.globalAlpha=.85;drawShip('base',t,0,{});ctx.globalAlpha=1;ctx.fillStyle='rgba(225,245,255,.5)';for(let i=0;i<7;i++){ctx.fillRect(-14+i*4,-10+((i*7)%13),2,2);}
    if(w.mirror&&P.scDone.sc3){glow(8,0,10,'#ff3b4e',.8);ctx.fillStyle='#ff3b4e';ctx.beginPath();ctx.arc(6,0,2,0,TAU);ctx.fill();}ctx.restore();
    ctx.font='700 '+fpx(10)+'px "Exo 2",sans-serif';ctx.textAlign='center';ctx.fillStyle='rgba(200,225,250,.55)';ctx.fillText('VØID-013',w.x,w.y+30);
    if(!w.read){ctx.strokeStyle='rgba(220,240,255,.5)';ctx.lineWidth=1;ctx.beginPath();ctx.arc(w.x,w.y,24,0,TAU);ctx.stroke();glow(w.x,w.y,24,'#dff6ff',.3+.2*Math.sin(t*3));}}
  postDrawSuits(t);postDrawCrates(t);
  // аварийная переборка
  if(P.edoor){const E=P.edoor;for(const w of [E.wa,E.wb]){if(w.x1-w.x0<1||w.y1-w.y0<1)continue;ctx.fillStyle='#141c28';ctx.fillRect(w.x0,w.y0,w.x1-w.x0,w.y1-w.y0);ctx.save();ctx.beginPath();ctx.rect(w.x0,w.y0,w.x1-w.x0,w.y1-w.y0);ctx.clip();ctx.strokeStyle='#c9a227';ctx.lineWidth=5;for(let q=-40;q<200;q+=14){ctx.beginPath();ctx.moveTo(w.x0+q,w.y0);ctx.lineTo(w.x0+q-30,w.y1);ctx.stroke();}ctx.restore();}}
}
// Наблюдатель: тень с длинными суставчатыми конечностями; виден только в свете, глаза — всегда
const POST_OS=2.2; // Наблюдатель выше корабля в два с лишним раза
function postDrawO(x,y,t,face,ext,al){ctx.save();ctx.translate(x,y);ctx.rotate(face);ctx.scale(POST_OS,POST_OS);ctx.globalAlpha=al;
  for(let i=0;i<7;i++){ctx.fillStyle='rgba(1,2,6,.92)';ctx.beginPath();ctx.ellipse(-i*7+Math.sin(t*3+i)*2,Math.sin(t*2+i*1.7)*4,18-i*1.4,27-i*2.2,0,0,TAU);ctx.fill();}
  ctx.strokeStyle='rgba(1,2,6,.95)';ctx.lineCap='round';
  for(const [base,len,ph] of [[.75,82,0],[-.75,82,1.3],[1.7,64,2.1],[-1.7,64,3.4]]){let px=Math.cos(base)*12,py=Math.sin(base)*16,a=base*.55;const n=3;
    for(let s=0;s<n;s++){const seg=len*ext/n,bend=Math.sin(t*2.2+ph+s)*.35+(s===1?-.5*Math.sign(base):0);a+=bend*.5;const nx=px+Math.cos(a)*seg,ny=py+Math.sin(a)*seg;ctx.lineWidth=3.4-s;ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(nx,ny);ctx.stroke();px=nx;py=ny;}
    ctx.lineWidth=1;for(const c of [-.4,0,.4]){ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(px+Math.cos(a+c)*9,py+Math.sin(a+c)*9);ctx.stroke();}}
  ctx.lineCap='butt';ctx.fillStyle='rgba(1,2,6,.97)';ctx.beginPath();ctx.ellipse(12,0,13,15,0,0,TAU);ctx.fill();
  ctx.strokeStyle='rgba(190,230,255,.22)';ctx.lineWidth=.8;ctx.beginPath();ctx.ellipse(0,0,22,30,0,0,TAU);ctx.stroke();ctx.strokeStyle='rgba(190,230,255,.1)';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(0,0,24,33,0,0,TAU);ctx.stroke();ctx.restore();ctx.globalAlpha=1;}
function postEyes(x,y,t,face,n,bright,al){ctx.save();ctx.translate(x,y);ctx.rotate(face);ctx.scale(POST_OS,POST_OS);ctx.globalAlpha=al;const E=[[16,-6],[16,6],[10,-11],[10,11],[20,-1],[6,0]];
  for(let i=0;i<n;i++){const [ex,ey]=E[i],bl=Math.sin(t*1.7+i*2.3)>.97?.2:1;ctx.fillStyle=bright?'#ffffff':'#bfe8ff';ctx.beginPath();ctx.ellipse(ex,ey,2.6*bl,2.6,0,0,TAU);ctx.fill();}
  if(bright&&!lessFx25()){ctx.globalAlpha=al*.35;glow(16,0,26,'#bfe8ff',1);}ctx.restore();ctx.globalAlpha=1;}
function postDrawOver(t){const P=G.post,p=G.player;if(!P||!p)return;const D=postDK(),O=P.O;
  const T0=ctx.getTransform(),cw=cv.width,ch=cv.height;
  // 1. тело Наблюдателя и мелькнувший силуэт — под тьмой: видно только то, что освещено
  const ext=O.st==='strike'?1.35:O.st==='tele'?1.15:1;
  if(O.st!=='off')postDrawO(O.x,O.y,t,Math.atan2(p.y-O.y,p.x-O.x),ext,1);
  if(P.glim)postDrawO(P.glim.x,P.glim.y,t,Math.atan2(p.y-P.glim.y,p.x-P.glim.x),1.1,Math.min(1,P.glim.t/P.glim.t0*1.6));
  // 2. тьма в половинном разрешении: фонарь с тенями от переборок, лампы, маячки, искры
  const SC=.5,w2=Math.max(1,Math.round(cw*SC)),h2=Math.max(1,Math.round(ch*SC));
  if(!pC||pC.width!==w2||pC.height!==h2){pC=document.createElement('canvas');pC.width=w2;pC.height=h2;pX=pC.getContext('2d');lC=document.createElement('canvas');lC.width=w2;lC.height=h2;lX=lC.getContext('2d');}
  const M=[T0.a*SC,T0.b*SC,T0.c*SC,T0.d*SC,T0.e*SC,T0.f*SC];
  const L=lX;L.setTransform(1,0,0,1,0,0);L.globalCompositeOperation='source-over';L.clearRect(0,0,w2,h2);L.setTransform(...M);
  const bo=P.blackout>0;
  if(!bo){const a=P.aim??0,R=postConeR(),fl=P.fl;const g=L.createRadialGradient(p.x,p.y,10,p.x,p.y,R);g.addColorStop(0,`rgba(0,0,0,${(.97*fl).toFixed(3)})`);g.addColorStop(.65,`rgba(0,0,0,${(.7*fl).toFixed(3)})`);g.addColorStop(1,'rgba(0,0,0,0)');L.fillStyle=g;
    L.beginPath();L.moveTo(p.x,p.y);L.arc(p.x,p.y,R,a-.5,a+.5);L.closePath();L.fill();
    const g2=L.createRadialGradient(p.x,p.y,20,p.x,p.y,74);g2.addColorStop(0,'rgba(0,0,0,.95)');g2.addColorStop(1,'rgba(0,0,0,0)');L.fillStyle=g2;L.beginPath();L.arc(p.x,p.y,74,0,TAU);L.fill();
    L.globalCompositeOperation='destination-out';L.fillStyle='#000';
    for(const w of P.walls){if(w.x1-w.x0<1||w.y1-w.y0<1)continue;const c=[[w.x0,w.y0],[w.x1,w.y0],[w.x1,w.y1],[w.x0,w.y1]];
      for(let i=0;i<4;i++){const A_=c[i],B_=c[(i+1)%4];const fa=Math.hypot(A_[0]-p.x,A_[1]-p.y)||1,fb=Math.hypot(B_[0]-p.x,B_[1]-p.y)||1,K=3000;
        L.beginPath();L.moveTo(A_[0],A_[1]);L.lineTo(B_[0],B_[1]);L.lineTo(B_[0]+(B_[0]-p.x)/fb*K,B_[1]+(B_[1]-p.y)/fb*K);L.lineTo(A_[0]+(A_[0]-p.x)/fa*K,A_[1]+(A_[1]-p.y)/fa*K);L.closePath();L.fill();}}}
  const X=pX;X.setTransform(1,0,0,1,0,0);X.globalCompositeOperation='source-over';X.clearRect(0,0,w2,h2);
  const dk=isMob()?Math.min(D.dark,.93):D.dark;X.fillStyle=`rgba(1,2,6,${(bo?1:dk).toFixed(3)})`;X.fillRect(0,0,w2,h2);
  X.globalCompositeOperation='destination-out';X.drawImage(lC,0,0);X.setTransform(...M);
  const hole=(x,y,r,a)=>{const g=X.createRadialGradient(x,y,r*.25,x,y,r);g.addColorStop(0,`rgba(0,0,0,${a})`);g.addColorStop(1,'rgba(0,0,0,0)');X.fillStyle=g;X.beginPath();X.arc(x,y,r,0,TAU);X.fill();};
  if(!bo){for(const Lm of P.lamps)if(Lm.on)hole(Lm.x,Lm.y,Lm.r,.95*Lm.fl);for(const g2 of P.gens)if(g2.on)hole(g2.x,g2.y,postR(.32),.95);if(P.core&&P.core.on&&P.escape<=0)hole(P.core.x,P.core.y,postR(.28),.9);
    if(P.core&&!P.core.on)hole(P.core.x,P.core.y,90,.35+.15*Math.sin(t*2));
    for(const b of P.beacons){const R=postR(.34);for(const [hw,al] of [[.09,.22],[.17,.14],[.26,.08]]){const g=X.createRadialGradient(b.x,b.y,4,b.x,b.y,R);g.addColorStop(0,`rgba(0,0,0,${al})`);g.addColorStop(1,'rgba(0,0,0,0)');X.fillStyle=g;X.beginPath();X.moveTo(b.x,b.y);X.arc(b.x,b.y,R,b.a-hw,b.a+hw);X.closePath();X.fill();}}
    for(const s of P.sparks)hole(s.x,s.y,160,Math.min(1,s.t/.2)*.9);
    for(const b of P.breach)hole(b.x,b.y,b.r*1.3,.35);
    if(P.hatch&&P.hatch.k<1){const o=1-P.hatch.k,a=W>=H?0:Math.PI/2,g=X.createRadialGradient(P.hatch.x,P.hatch.y,6,P.hatch.x,P.hatch.y,360);g.addColorStop(0,'rgba(0,0,0,.95)');g.addColorStop(1,'rgba(0,0,0,0)');X.fillStyle=g;X.beginPath();X.moveTo(P.hatch.x,P.hatch.y);X.arc(P.hatch.x,P.hatch.y,360,a-.5*o,a+.5*o);X.closePath();X.fill();}
    if(P.door.open)hole(P.door.x,P.door.y,70,.5);
    if(P.flash>0)hole(p.x,p.y,280,P.flash*.9);
    for(const e of G.enemies)if(e.alive&&e.reveal>0)hole(e.x,e.y,50,.8);}
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=true;ctx.drawImage(pC,0,0,cw,ch);ctx.restore();
  // 3. цвет света: тёплые лампы, холодный фонарь, красные маячки, вспышки искр
  if(!bo){ctx.save();ctx.globalCompositeOperation='lighter';for(const Lm of P.lamps)if(Lm.on)glow(Lm.x,Lm.y,Lm.r*.75,'#ffcf8a',.16*Lm.fl);for(const g2 of P.gens)if(g2.on)glow(g2.x,g2.y,postR(.26),'#ffcf8a',.14);
    {const a=P.aim??0,R=postConeR()*.9;const g=ctx.createRadialGradient(p.x,p.y,8,p.x,p.y,R);g.addColorStop(0,`rgba(210,235,255,${(.2*P.fl).toFixed(3)})`);g.addColorStop(.6,`rgba(210,235,255,${(.08*P.fl).toFixed(3)})`);g.addColorStop(1,'rgba(210,235,255,0)');ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.arc(p.x,p.y,R,a-.48,a+.48);ctx.closePath();ctx.fill();}
    for(const b of P.beacons){const R=postR(.34),k=P.escape>0?1.5:1;for(const [hw,al] of [[.08,.09],[.16,.05],[.25,.03]]){const g=ctx.createRadialGradient(b.x,b.y,4,b.x,b.y,R);g.addColorStop(0,`rgba(255,30,45,${(al*k).toFixed(3)})`);g.addColorStop(.6,`rgba(255,30,45,${(al*k*.4).toFixed(3)})`);g.addColorStop(1,'rgba(255,30,45,0)');ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.arc(b.x,b.y,R,b.a-hw,b.a+hw);ctx.closePath();ctx.fill();}glow(b.x,b.y,26,'#ff3b4e',.25*k);}
    for(const s of P.sparks)glow(s.x,s.y,120,'#cfe8ff',Math.min(1,s.t/.2)*.35);
    for(const b of P.breach)glow(b.x,b.y,b.r*1.4,'#6f9fd8',.12);
    if(P.hatch&&P.hatch.k<1)glow(P.hatch.x,P.hatch.y,200*(1-P.hatch.k),'#cfe8ff',.25);
    ctx.restore();}
  // 4. глаза — их видно и во тьме
  if(O.st!=='off'){const d=Math.hypot(O.x-p.x,O.y-p.y),hot=O.st==='tele'||O.st==='strike'||O.st==='show',vis=hot||postLit(O.x,O.y,30)||d<170||postSees(O.x,O.y);
    if(vis||d<380){const k=O.st==='tele'?.6+.4*Math.abs(Math.sin(t*14)):hot?1:Math.max(.1,1-d/380);postEyes(O.x,O.y,t,Math.atan2(p.y-O.y,p.x-O.x),hot?6:O.frz?4:2,hot,k);}}
  if(P.glim)postEyes(P.glim.x,P.glim.y,t,Math.atan2(p.y-P.glim.y,p.x-P.glim.x),2,true,Math.min(1,P.glim.t/P.glim.t0*1.6));
  for(const f of P.figs)postDrawFig(f,t);
  // 5. указатель цели — тусклый, у самого корабля
  const tg=postTarget();if(tg){const a=Math.atan2(tg.y-p.y,tg.x-p.x),dd=Math.hypot(tg.x-p.x,tg.y-p.y);if(dd>120){const x=p.x+Math.cos(a)*50,y=p.y+Math.sin(a)*50;ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.fillStyle='rgba(191,232,255,.55)';ctx.beginPath();ctx.moveTo(7,0);ctx.lineTo(-4,-4);ctx.lineTo(-4,4);ctx.closePath();ctx.fill();ctx.restore();
    ctx.font='700 '+fpx(11)+'px "Exo 2",sans-serif';ctx.textAlign='center';ctx.fillStyle='rgba(191,232,255,.5)';ctx.fillText(tg.label,p.x+Math.cos(a)*74,p.y+Math.sin(a)*74+4);}}
  if(P.fake){const a=P.fake.a,x=clamp(p.x+Math.cos(a)*600,30,W-30),y=clamp(p.y+Math.sin(a)*600,30,H-30);ctx.save();ctx.translate(x,y);ctx.rotate(a+Math.PI);ctx.strokeStyle='#8a7dff';ctx.globalAlpha=.4+.6*Math.abs(Math.sin(P.fake.t*18));ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-6,-8);ctx.lineTo(4,0);ctx.lineTo(-6,8);ctx.stroke();ctx.restore();ctx.globalAlpha=1;}
  // 6. ледяной фронт побега
  if(P.front!=null&&P.front<1.05){const vert=W>=H,r=postRect([Math.max(P.front,-.3),0,1.3,1]),e=vert?r.x0:r.y0,depth=vert?W:H,span=vert?H:W;ctx.save();
    const gr=vert?ctx.createLinearGradient(e,0,e+depth*.5,0):ctx.createLinearGradient(0,e,0,e+depth*.5);gr.addColorStop(0,'rgba(235,250,255,.62)');gr.addColorStop(.08,'rgba(200,232,255,.38)');gr.addColorStop(1,'rgba(160,205,240,.22)');ctx.fillStyle=gr;
    ctx.beginPath();for(let q=0;q<=48;q++){const z=q/48*span,j=Math.sin(z*.05+t*6)*8+Math.sin(z*.13-t*4)*5;if(vert)ctx.lineTo(e+j,z);else ctx.lineTo(z,e+j);}if(vert){ctx.lineTo(W+60,H);ctx.lineTo(W+60,0);}else{ctx.lineTo(W,H+60);ctx.lineTo(0,H+60);}ctx.closePath();ctx.fill();
    // кристаллы растут вперёд фронта
    ctx.strokeStyle='rgba(240,252,255,.75)';ctx.lineWidth=1.5;for(let q=0;q<26;q++){const z=((q*97.3)%1)*span+((q*37)%11),len=12+((q*53)%28)*(1+.3*Math.sin(t*3+q)),a=(vert?Math.PI:-Math.PI/2)+(((q*13)%9)-4)*.12;const bx=vert?e:z,by=vert?z:e;ctx.beginPath();ctx.moveTo(bx,by);ctx.lineTo(bx+Math.cos(a)*len,by+Math.sin(a)*len);ctx.stroke();}
    ctx.globalCompositeOperation='lighter';ctx.strokeStyle='rgba(200,235,255,.25)';ctx.lineWidth=18;ctx.beginPath();for(let q=0;q<=40;q++){const z=q/40*span,j=Math.sin(z*.05+t*6)*8;if(vert)ctx.lineTo(e+j,z);else ctx.lineTo(z,e+j);}ctx.stroke();ctx.globalCompositeOperation='source-over';
    ctx.strokeStyle='rgba(245,252,255,.95)';ctx.lineWidth=2.5;ctx.beginPath();for(let q=0;q<=48;q++){const z=q/48*span,j=Math.sin(z*.05+t*6)*8+Math.sin(z*.13-t*4)*5;if(vert)ctx.lineTo(e+j,z);else ctx.lineTo(z,e+j);}ctx.stroke();
    if(SET.fx&&Math.random()<.8){const q=Math.random()*span;if(vert)part(e,q,rnd(-160,-40),rnd(-40,40),.6,'#eaf8ff',2);else part(q,e,rnd(-40,40),rnd(-160,-40),.6,'#eaf8ff',2);}ctx.restore();}
  // 7. экранные слои: иней, сторона броска, тяжёлая виньетка, пульс сердца, зерно, сбой картинки, затемнение
  ctx.save();ctx.setTransform(1,0,0,1,0,0);const f=Math.min(1,(G.ice||0)/3+P.cold*.25+(G.frozen>0?.4:0)+(P.inFront?.5:0));
  {const g=ctx.createRadialGradient(cw/2,ch/2,Math.min(cw,ch)*.3,cw/2,ch/2,Math.max(cw,ch)*.72);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.62)');ctx.fillStyle=g;ctx.fillRect(0,0,cw,ch);}
  if(f>.02){const g=ctx.createRadialGradient(cw/2,ch/2,Math.min(cw,ch)*.5,cw/2,ch/2,Math.max(cw,ch)*.72);g.addColorStop(0,'rgba(200,235,255,0)');g.addColorStop(.6,`rgba(200,235,255,${(.08*f).toFixed(3)})`);g.addColorStop(1,`rgba(215,240,255,${(.36*f).toFixed(3)})`);ctx.fillStyle=g;ctx.fillRect(0,0,cw,ch);}
  if(O.st==='tele'){const a=Math.atan2(O.y-p.y,O.x-p.x);const gx=cw/2+Math.cos(a)*cw*.5,gy=ch/2+Math.sin(a)*ch*.5;const g=ctx.createRadialGradient(gx,gy,0,gx,gy,Math.min(cw,ch)*.45);g.addColorStop(0,'rgba(220,240,255,.45)');g.addColorStop(1,'rgba(220,240,255,0)');ctx.fillStyle=g;ctx.fillRect(0,0,cw,ch);}
  {const dO=O.st!=='off'&&O.st!=='flee'?Math.hypot(O.x-p.x,O.y-p.y):999,near=dO<380?1-dO/380:0,k=near*(.35+.65*P.hbPulse);if(k>.02){const g=ctx.createRadialGradient(cw/2,ch/2,Math.min(cw,ch)*.25,cw/2,ch/2,Math.max(cw,ch)*.7);g.addColorStop(0,'rgba(30,0,4,0)');g.addColorStop(1,`rgba(30,0,4,${(.55*k).toFixed(3)})`);ctx.fillStyle=g;ctx.fillRect(0,0,cw,ch);}}
  if(P.strobe){if(P.strobe.dark){ctx.fillStyle='rgba(0,0,0,.94)';ctx.fillRect(0,0,cw,ch);}else{ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(200,225,255,.14)';ctx.fillRect(0,0,cw,ch);ctx.globalCompositeOperation='source-over';}}
  if(!lessFx25()&&SET.fx){if(!pN){pN=document.createElement('canvas');pN.width=pN.height=160;const nx=pN.getContext('2d'),id=nx.createImageData(160,160);for(let i=0;i<id.data.length;i+=4){const v=Math.random()*255|0;id.data[i]=id.data[i+1]=id.data[i+2]=v;id.data[i+3]=Math.random()*70|0;}nx.putImageData(id,0,0);}
    ctx.globalAlpha=.09;const pat=ctx.createPattern(pN,'repeat');ctx.translate(-(Math.random()*160|0),-(Math.random()*160|0));ctx.fillStyle=pat;ctx.fillRect(0,0,cw+160,ch+160);ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;
    if(P.glitch>0){for(let i=0;i<5;i++){const y=Math.random()*ch|0,h=4+Math.random()*28|0,dx=(Math.random()-.5)*30*P.glitch*2;try{ctx.drawImage(cv,0,y,cw,h,dx,y,cw,h);}catch(e){}}}}
  ctx.restore();
  if(P.rift>.01&&typeof drawRiftFx==='function'){try{drawRiftFx(P.rift,t);}catch(e){}}
  if(P.fade>0){ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle=`rgba(0,0,0,${Math.min(1,P.fade).toFixed(3)})`;ctx.fillRect(0,0,cw,ch);ctx.restore();}
}
function postTarget(){const P=G.post;if(!P)return null;const p=G.player,near=a=>a.sort((u,v)=>Math.hypot(u.x-p.x,u.y-p.y)-Math.hypot(v.x-p.x,v.y-p.y))[0];
  const pn=P.panels.filter(q=>!q.on);if(pn.length)return {...near(pn),label:'ЩИТОК'};const c=P.cells.filter(q=>!q.got);if(c.length)return {...near(c),label:'ТЕПЛО'};
  const g=P.gens.filter(q=>!q.on);if(g.length)return {...near(g),label:'ГЕНЕРАТОР'};if(P.core&&!P.core.on)return {x:P.core.x,y:P.core.y,label:'РЕАКТОР'};return {x:P.door.x,y:P.door.y,label:'ШЛЮЗ'};}
// --- звук: гул корпуса вместо музыки, металлический призвук, стоны, шёпот, дыхание, шаги, сирена (Web Audio, без файлов)
function postAudio(on){if(!AU.ctx)return;const c=AU.ctx,t=c.currentTime;
  if(on){AU.amb.gain.setTargetAtTime(0,t,.8);if(AU.postN)return;try{const g=c.createGain();g.gain.value=0;g.connect(AU.sfx);g.gain.setTargetAtTime(SET.sfx?.55:0,t,2);
      const o1=c.createOscillator(),o2=c.createOscillator(),o3=c.createOscillator();o1.type='sine';o1.frequency.value=36;o2.type='sine';o2.frequency.value=36.7;o3.type='triangle';o3.frequency.value=72.4;const og=c.createGain();og.gain.value=.28;const o3g=c.createGain();o3g.gain.value=.05;o1.connect(og);o2.connect(og);o3.connect(o3g);o3g.connect(g);og.connect(g);o1.start();o2.start();o3.start();
      const len=c.sampleRate*2,b=c.createBuffer(1,len,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<len;i++)d[i]=Math.random()*2-1;
      const n=c.createBufferSource();n.buffer=b;n.loop=true;const f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=380;f.Q.value=.7;const ng=c.createGain();ng.gain.value=.12;n.connect(f);f.connect(ng);ng.connect(g);n.start();
      const n2=c.createBufferSource();n2.buffer=b;n2.loop=true;const f2=c.createBiquadFilter();f2.type='bandpass';f2.frequency.value=1150;f2.Q.value=28;const n2g=c.createGain();n2g.gain.value=.22;n2.connect(f2);f2.connect(n2g);n2g.connect(g);n2.start();
      AU.postN={g,o1,o2,o3,n,n2,f,f2};}catch(e){}}
  else{const N=AU.postN;AU.postN=null;if(N){try{N.g.gain.setTargetAtTime(0,t,.4);setTimeout(()=>{try{N.o1.stop();N.o2.stop();N.o3.stop();N.n.stop();N.n2.stop();N.g.disconnect();}catch(e){}},1600);}catch(e){}}applyAudio();}}
function postAudioTick(dt){const P=G.post,O=P.O,p=G.player;if(!AU.ctx||!SET.sfx)return;const c=AU.ctx;
  if(AU.postN)try{const N=AU.postN;N.f.frequency.setTargetAtTime(300+120*Math.sin(P.t*.3),c.currentTime,.5);N.f2.frequency.setTargetAtTime(1100+260*Math.sin(P.t*.17)+(P.escape>0?300:0),c.currentTime,.8);
    N.g.gain.setTargetAtTime(.55*(1-.94*P.duck)*(P.escape>0?1.25:1),c.currentTime,P.duck>0?.12:.6);}catch(e){}
  if(O.st!=='off'&&O.st!=='flee'){const d=Math.hypot(O.x-p.x,O.y-p.y);if(d<480){P.hb-=dt;if(P.hb<=0){P.hb=O.st==='tele'?.32:.55+d/480*.6;postSnd('heart',0,O.st==='tele'?1.3:.7+.5*(1-d/480));P.hbPulse=1;}}}}
function postSnd(k,pan,vol,f0){if(!AU.ctx||!SET.sfx)return;const c=AU.ctx,t=c.currentTime;vol=vol||1;try{
  const out=c.createGain();out.gain.value=vol;if(c.createStereoPanner){const sp=c.createStereoPanner();sp.pan.value=clamp(pan||0,-1,1);out.connect(sp);sp.connect(AU.sfx);}else out.connect(AU.sfx);
  const thump=(dl,f,v,f1)=>{const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.setValueAtTime(f,t+dl);o.frequency.exponentialRampToValueAtTime(f1||30,t+dl+.18);g.gain.setValueAtTime(v,t+dl);g.gain.exponentialRampToValueAtTime(.001,t+dl+.22);o.connect(g);g.connect(out);o.start(t+dl);o.stop(t+dl+.25);};
  const nz=(dl,dur,f,typ,v,q,env)=>{const len=c.sampleRate*dur|0,b=c.createBuffer(1,len,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<len;i++){const x=i/len;d[i]=(Math.random()*2-1)*(env==='swell'?Math.sin(Math.PI*x):Math.pow(1-x,2));}const s=c.createBufferSource();s.buffer=b;const fl=c.createBiquadFilter();fl.type=typ;fl.frequency.value=f;if(q)fl.Q.value=q;const g=c.createGain();g.gain.value=v;s.connect(fl);fl.connect(g);g.connect(out);s.start(t+dl);return fl;};
  const tone=(dl,dur,f,typ,v,f1)=>{const o=c.createOscillator(),g=c.createGain();o.type=typ;o.frequency.setValueAtTime(f,t+dl);if(f1)o.frequency.exponentialRampToValueAtTime(f1,t+dl+dur);g.gain.setValueAtTime(.0001,t+dl);g.gain.exponentialRampToValueAtTime(v,t+dl+.03);g.gain.exponentialRampToValueAtTime(.0001,t+dl+dur);o.connect(g);g.connect(out);o.start(t+dl);o.stop(t+dl+dur+.05);return o;};
  if(k==='heart'){thump(0,70,.5);thump(.16,60,.35);}
  else if(k==='knock'){for(let i=0;i<3;i++)nz(i*.19+rnd(0,.04),.09,260,'lowpass',.9);}
  else if(k==='crack'){nz(0,.25,2600,'highpass',.5);nz(.05,.15,900,'bandpass',.4);}
  else if(k==='hit'){thump(0,90,.7);nz(0,.3,600,'lowpass',.8);}
  else if(k==='slam'){thump(0,70,1,24);nz(0,.9,240,'lowpass',.9);nz(.02,.25,1800,'bandpass',.35,6);}
  else if(k==='groan'){const o=tone(0,2.6,58,'sawtooth',.14,26);const fl=c.createBiquadFilter();fl.type='lowpass';fl.frequency.value=220;try{o.disconnect();const g=c.createGain();g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.16,t+.6);g.gain.exponentialRampToValueAtTime(.0001,t+2.6);o.connect(fl);fl.connect(g);g.connect(out);}catch(e){}nz(.2,2.2,140,'bandpass',.35,3,'swell');}
  else if(k==='whisper'){for(let i=0;i<3;i++){const fl=nz(i*.22,.5+rnd(0,.3),900+rnd(0,700),'bandpass',.5,9,'swell');try{fl.frequency.exponentialRampToValueAtTime(600+rnd(0,1400),t+i*.22+.5);}catch(e){}}}
  else if(k==='breath'){nz(0,1.1,520,'lowpass',.55,0,'swell');nz(1.25,1.3,380,'lowpass',.45,0,'swell');}
  else if(k==='clank'){nz(0,.07,1400,'bandpass',.8,8);thump(0,110,.25,50);}
  else if(k==='stinger'){for(const f of [220,233,311,466,493])tone(0,1.5,f,'sawtooth',.06,f*.94);nz(0,.6,3000,'highpass',.4);thump(0,55,.8,25);}
  else if(k==='klaxon'){const o=tone(0,.5,440,'square',.07);const o2=tone(.55,.5,330,'square',.07);}
  else if(k==='static'){nz(0,.35,2400,'bandpass',.7,2);for(let i=0;i<4;i++)nz(i*.05+rnd(0,.03),.04,5000,'highpass',.5);thump(0,180,.15,60);}
  else if(k==='note'){const f=arguments[3]||660;const o=tone(0,1.1,f,'sine',.09,f*.995);const o2=tone(0,.6,f*2.01,'sine',.025);}
  else if(k==='spark'){for(let i=0;i<5;i++)nz(i*.03+rnd(0,.02),.03,4200,'highpass',.6);}}catch(e){}}
// ---------- мир: огромный разбитый сторожевик поперёк прохода
let PWG=null;
function postWreckGeo(){if(PWG)return PWG;const R=pRng(77);
  const hull=[[420,0],[350,-60],[210,-98],[-240,-112],[-345,-92],[-418,-60],[-418,60],[-345,92],[-240,112],[210,98],[350,60]];
  const frost=[];for(let i=0;i<14;i++){const x=-400+R()*760,top=R()<.6,n=5+(R()*4|0),r=10+R()*22,pts=[];for(let j=0;j<n;j++){const a=j/n*TAU;pts.push([Math.cos(a)*r*(.6+R()*.6),Math.sin(a)*r*.5*(.6+R()*.6)]);}frost.push({x,y:top?-96+R()*10:94-R()*10,pts});}
  const holes=[[-150,-40,26],[230,40,22],[-30,70,18]].map(([x,y,r])=>{const pts=[];for(let j=0;j<11;j++){const a=j/11*TAU;pts.push([x+Math.cos(a)*r*(.6+R()*.6),y+Math.sin(a)*r*(.6+R()*.6)]);}return {x,y,r,pts};});
  const ice=[];for(let i=0;i<24;i++)ice.push([-380+R()*700,100+R()*8,6+R()*26]);
  const debris=Array.from({length:22},()=>({a:R()*TAU,d:420+R()*230,s:4+R()*12,sp:(R()-.5)*.04,rot:R()*TAU,n:3+(R()*3|0)}));
  const lh=POST_HL;
  return PWG={hull,frost,ice,debris,lh,holes};}
function postWorldDraw(t){if(!G.save||!postAvail())return;const p=G.player;if(p&&Math.hypot(p.x-POST_W.x,p.y-POST_W.y)>2600)return;const g=postWreckGeo(),done=postDone();
  ctx.save();ctx.translate(POST_W.x,POST_W.y);
  {const gr=ctx.createRadialGradient(0,0,100,0,0,760);gr.addColorStop(0,'rgba(0,0,0,.55)');gr.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.arc(0,0,760,0,TAU);ctx.fill();}
  for(const d of g.debris){const a=d.a+t*d.sp,x=Math.cos(a)*d.d,y=Math.sin(a)*d.d*.55;ctx.save();ctx.translate(x,y);ctx.rotate(d.rot+t*d.sp*4);ctx.fillStyle='#0c121b';ctx.strokeStyle='rgba(150,180,215,.4)';ctx.lineWidth=1;ctx.beginPath();for(let i=0;i<d.n;i++){const q=i/d.n*TAU;ctx.lineTo(Math.cos(q)*d.s,Math.sin(q)*d.s*.6);}ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}
  ctx.rotate(POST_ANG);
  // корпус
  const gr=ctx.createLinearGradient(0,-112,0,112);gr.addColorStop(0,'#1a2433');gr.addColorStop(.5,'#0c121b');gr.addColorStop(1,'#06090e');ctx.fillStyle=gr;ctx.strokeStyle=done?'rgba(122,255,201,.45)':'rgba(170,205,240,.55)';ctx.lineWidth=2.5;
  ctx.beginPath();for(const [x,y] of g.hull)ctx.lineTo(x,y);ctx.closePath();ctx.fill();
  ctx.save();ctx.strokeStyle=done?'rgba(122,255,201,.12)':'rgba(170,215,255,.13)';ctx.lineWidth=16;ctx.stroke();ctx.lineWidth=7;ctx.stroke();ctx.restore();ctx.stroke();
  // мёртвый прожектор: луч с мостика ходит по льду и сбоит
  {const a=-1.9+Math.sin(t*.35)*.55,on=Math.sin(t*5.3)>-.75&&Math.sin(t*.9)>-.85,L=620;if(on){const gr=ctx.createRadialGradient(-220,-74,4,-220,-74,L);gr.addColorStop(0,'rgba(220,240,255,.22)');gr.addColorStop(1,'rgba(220,240,255,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.moveTo(-220,-74);ctx.arc(-220,-74,L,a-.13,a+.13);ctx.closePath();ctx.fill();}glow(-220,-76,14,'#dff6ff',on?.8:.15);}
  // обшивка: пояса плит
  ctx.save();ctx.beginPath();for(const [x,y] of g.hull)ctx.lineTo(x,y);ctx.closePath();ctx.clip();ctx.strokeStyle='rgba(120,150,190,.14)';ctx.lineWidth=1;for(let x=-420;x<420;x+=34){ctx.beginPath();ctx.moveTo(x,-120);ctx.lineTo(x+6,120);ctx.stroke();}
  for(const y of [-60,-20,24,64]){ctx.beginPath();ctx.moveTo(-420,y);ctx.lineTo(420,y+3);ctx.stroke();}
  // пролом посередине: рёбра шпангоутов и тьма
  ctx.save();ctx.translate(-70,0);ctx.fillStyle='#020306';ctx.beginPath();ctx.moveTo(10,-118);ctx.lineTo(40,-70);ctx.lineTo(18,-40);ctx.lineTo(56,-6);ctx.lineTo(28,30);ctx.lineTo(62,70);ctx.lineTo(36,118);ctx.lineTo(118,118);ctx.lineTo(96,70);ctx.lineTo(128,26);ctx.lineTo(100,-10);ctx.lineTo(132,-52);ctx.lineTo(104,-118);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(140,170,205,.6)';ctx.lineWidth=3;for(let x=34;x<120;x+=17){ctx.beginPath();ctx.moveTo(x,-100);ctx.quadraticCurveTo(x+14,0,x,100);ctx.stroke();}
  ctx.strokeStyle='rgba(200,225,250,.7)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(10,-118);ctx.lineTo(40,-70);ctx.lineTo(18,-40);ctx.lineTo(56,-6);ctx.lineTo(28,30);ctx.lineTo(62,70);ctx.lineTo(36,118);ctx.moveTo(104,-118);ctx.lineTo(132,-52);ctx.lineTo(100,-10);ctx.lineTo(128,26);ctx.lineTo(96,70);ctx.lineTo(118,118);ctx.stroke();
  {const k=(Math.sin(t*1.1)+1)/2;glow(70,10,40,'#ff3b4e',.06+.08*k);}ctx.restore();
  for(const h of g.holes){ctx.fillStyle='#020306';ctx.beginPath();for(const [x,y] of h.pts)ctx.lineTo(x,y);ctx.closePath();ctx.fill();ctx.strokeStyle='rgba(200,225,250,.55)';ctx.lineWidth=1.2;ctx.stroke();ctx.strokeStyle='rgba(140,170,205,.5)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(h.x-h.r*.6,h.y-h.r*.9);ctx.lineTo(h.x-h.r*.5,h.y+h.r*.9);ctx.moveTo(h.x+h.r*.3,h.y-h.r*.9);ctx.lineTo(h.x+h.r*.4,h.y+h.r*.9);ctx.stroke();}
  // надстройка, мостик с окнами; в одном окне — свет, иногда в нём кто-то стоит
  ctx.fillStyle='#0f1724';ctx.fillRect(-300,-74,170,58);ctx.strokeStyle='rgba(150,185,230,.35)';ctx.lineWidth=1.5;ctx.strokeRect(-300,-74,170,58);
  for(let i=0;i<9;i++){const x=-292+i*18,lit=i===5,fl=lit?(Math.sin(t*9)>-.2?.9:.15)*(.6+.4*Math.sin(t*1.3)):0;ctx.fillStyle=lit?`rgba(255,207,138,${fl.toFixed(2)})`:'#05080c';ctx.fillRect(x,-62,10,14);
    if(lit&&((t%11)>8.6)){ctx.fillStyle='#020306';ctx.fillRect(x+3,-60,4,12);}}
  // сопла
  for(const y of [-50,0,50]){ctx.fillStyle='#070a10';ctx.beginPath();ctx.ellipse(-420,y,10,18,0,0,TAU);ctx.fill();ctx.strokeStyle='rgba(150,185,230,.35)';ctx.stroke();}
  // имя на борту — выскоблено
  ctx.font='800 34px "Exo 2",sans-serif';ctx.textAlign='left';ctx.fillStyle='rgba(200,220,245,.34)';ctx.fillText('ИЗМОРОЗЬ',70,30);ctx.font='700 14px "Exo 2",sans-serif';ctx.fillText('СК-07 · СТОРОЖЕВОЙ',72,52);
  ctx.strokeStyle='rgba(6,9,14,.9)';ctx.lineWidth=3;for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(80+i*38,4);ctx.lineTo(116+i*38,38);ctx.stroke();}
  ctx.restore();
  // иней и сосульки
  for(const f of g.frost){ctx.fillStyle='rgba(225,245,255,.5)';ctx.beginPath();for(const [x,y] of f.pts)ctx.lineTo(f.x+x,f.y+y);ctx.closePath();ctx.fill();ctx.strokeStyle='rgba(240,250,255,.7)';ctx.lineWidth=1;ctx.stroke();}
  ctx.strokeStyle='rgba(230,248,255,.55)';ctx.lineWidth=5;ctx.beginPath();for(let i=1;i<=6;i++){const [x,y]=g.hull[i];ctx.lineTo(x,y+4);}ctx.stroke();
  ctx.fillStyle='rgba(215,240,255,.45)';for(const [x,y,l] of g.ice){ctx.beginPath();ctx.moveTo(x-3,y);ctx.lineTo(x+3,y);ctx.lineTo(x,y+l);ctx.closePath();ctx.fill();}
  // огни: красный на носу мигает, янтарный над шлюзом умирает
  {const bl=Math.sin(t*2.2)>.6;glow(410,0,22,'#ff3b4e',bl?.9:.12);ctx.fillStyle=bl?'#ff3b4e':'#5a1a20';ctx.beginPath();ctx.arc(410,0,4,0,TAU);ctx.fill();}
  // шлюз
  {const [hx,hy]=g.lh;ctx.save();ctx.translate(hx,hy);const fl=(Math.sin(t*7)>.3?1:.25)*(Math.sin(t*.7)>-.6?1:.1);
    {const gr=ctx.createLinearGradient(0,0,0,-170);gr.addColorStop(0,`rgba(255,207,138,${(.28*fl).toFixed(3)})`);gr.addColorStop(1,'rgba(255,207,138,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.moveTo(-20,0);ctx.lineTo(20,0);ctx.lineTo(70,-170);ctx.lineTo(-70,-170);ctx.closePath();ctx.fill();}
    ctx.fillStyle='#05080c';ctx.fillRect(-24,-4,48,30);ctx.strokeStyle='#c9a227';ctx.lineWidth=3;ctx.strokeRect(-24,-4,48,30);ctx.fillStyle=`rgba(255,207,138,${(.5*fl).toFixed(2)})`;ctx.fillRect(-19,0,38,22);
    glow(0,-12,22,done?'#7affc9':'#ffcf8a',(done?.8:.9)*fl);ctx.restore();}
  // холодный пар из пролома
  for(let i=0;i<6;i++){const k=((t*.25+i/6)%1),x=70+Math.sin(i*2.1+t)*20,y=-120-k*120;ctx.fillStyle=`rgba(210,235,255,${(.18*(1-k)).toFixed(3)})`;ctx.beginPath();ctx.arc(x,y,8+k*26,0,TAU);ctx.fill();}
  ctx.restore();
  worldLabel(POST_HATCH.x,POST_HATCH.y-62,done?'СТОРОЖЕВИК «ИЗМОРОЗЬ» · ПРОЙДЕН':'СТОРОЖЕВИК «ИЗМОРОЗЬ» · ШЛЮЗ',done?'#7affc9':'#bfe8ff');}
function postEnter(){const S=G.save;if(!S||!G.player)return;riftReset();if(G.anom)endAnom();G.slick=false;
  if(S.carry>0){S.lom+=S.carry;S.carry=0;}S.pos={x:POST_HATCH.x,y:POST_HATCH.y-150};S.last={...S.pos};saveWorld();
  G.world=false;G.card=null;G.cardKey=null;$('#wcard').hidden=true;CX=0;CY=0;BW=W;BH=H;openIntro(POST_I);}
{const _poi30=w58POI;w58POI=function(card){card=_poi30(card);const p=G.player;if(postAvail()&&p){const d=Math.hypot(p.x-POST_HATCH.x,p.y-POST_HATCH.y);
    if(d<900&&!postDone()&&!G.postNear){G.postNear=1;try{radioSay('Х',0);postSnd('crack',0,.6);}catch(e){}}
    if(d<200){card={kind:'post',key:'post|'+(postDone()?1:0)};G.save.last={x:POST_HATCH.x,y:POST_HATCH.y-150};}}return card;};}
{const _rc30=renderCard;renderCard=function(card){if(!card||card.kind!=='post')return _rc30(card);const el=$('#wcard');if(G.cardKey===card.key&&!el.hidden)return;G.cardKey=card.key;const ps=postSave(),done=postDone();
  el.innerHTML=kh(`<div class="eyebrow">ГРАНИЦА II–III · ${done?'ПРОЙДЕН НАСКВОЗЬ':'ВМЁРЗ В ЛЁД'}</div><h3>Сторожевик «Изморозь»</h3><p>${done?'Проход в сектор III открыт. Внутри по-прежнему темно, и в эфире по-прежнему ваш позывной.':'Проход в сектор III перекрыт: поперёк него вмёрз мёртвый сторожевой корабль. Путь один — насквозь. Шлюз открыт. Изнутри вас зовут по имени.'}</p>${done&&ps.best?`<p class="note">Лучшее время ${mmss(ps.best)}</p>`:''}<div class="wc-row"><button class="wbtn" data-act="post">ВОЙТИ В ШЛЮЗ [F]</button></div>`);
  el.hidden=false;if(typeof ctxBtnSync==='function')ctxBtnSync();};}
{const _ca30=cardAct;cardAct=function(act){const c=G.card;if(c&&c.kind==='post'&&G.state==='world'&&act!=='cycle'){postEnter();return;}return _ca30(act);};}
{const _ss30=secSeen;secSeen=function(i){if(i===2&&!openAllNow()&&G.save)return progDone(CORE)&&postGate();return _ss30(i);};}
{const _fh30=fogHint;fogHint=function(i){if(i===2&&G.save&&progDone(CORE)&&!postGate())return 'СЕКТОР III · ПРОЙДИТЕ СТОРОЖЕВИК «ИЗМОРОЗЬ»';return _fh30(i);};}
{const _ma30=w58MapAdd;w58MapAdd=function(add,lod,S){_ma30(add,lod,S);try{if(postAvail())add('post',POST_W.x,POST_W.y,{done:postDone()},lod>=1?{t:postDone()?'СТОРОЖЕВИК · ПРОЙДЕН':'СТОРОЖЕВИК «ИЗМОРОЗЬ»',p:2,c:postDone()?'#7affc9':'#bfe8ff'}:null);}catch(e){}};}
{const _mi30=w58MapIcon;w58MapIcon=function(g,kind,o,t){if(kind!=='post')return _mi30(g,kind,o,t);g.save();g.rotate(POST_ANG);g.fillStyle='#0c121b';g.strokeStyle=o.done?'#7affc9':'#bfe8ff';g.lineWidth=1.5;g.beginPath();g.moveTo(12,0);g.lineTo(8,-4);g.lineTo(-11,-4);g.lineTo(-12,0);g.lineTo(-11,4);g.lineTo(8,4);g.closePath();g.fill();g.stroke();
  g.fillStyle='#020306';g.fillRect(0,-4,3,8);if(!o.done){g.fillStyle=Math.sin(t*2.2)>.4?'#ff3b4e':'#5a1a20';g.beginPath();g.arc(12,0,1.6,0,TAU);g.fill();}g.restore();return true;};}
{const _mg30=migrateSave;migrateSave=function(S){S=_mg30(S);if(!S||typeof S!=='object')return S;
  const P0=S.post&&typeof S.post==='object'?S.post:null;const P={done:P0&&P0.done?1:0,open3:P0&&P0.open3?1:0,best:P0&&+P0.best>0?Math.min(36000,Math.round(+P0.best)):0,freezes:P0&&Number.isFinite(+P0.freezes)?Math.max(-1,Math.min(999,Math.round(+P0.freezes))):-1,logs:Array.isArray(P0&&P0.logs)?P0.logs.filter(v=>Number.isInteger(v)&&v>=0&&v<4).slice(0,4):[]};
  // сохранения до 1.2.0 с пройденной миссией 10: сектор III у них уже был открыт — доступ не отнимаем, сторожевик становится необязательным
  if(!S.v120){S.v120=1;if((+S.cleared||0)>=CORE||(S.medals&&S.medals[CORE]&&S.medals[CORE].clear))P.open3=1;}
  S.post=P;return S;};}
{const _bk30=briefK;briefK=function(m){if(m===POST_I+1){if(G.mode!=='world')return 0;return Math.floor(BRIEF_K[CORE-1]*curDiff().k)+perk('reserve');}return _bk30(m);};}
// брифинг без жанровой плашки: только место
{const _oi30=openIntro;openIntro=function(i){_oi30(i);if(i===POST_I){$('#inSector').textContent=MISSIONS[i].sector;}};}
{const _sm30=setupMission0;setupMission0=function(i){_sm30(i);G.post=null;if(MISSIONS[i]&&MISSIONS[i].post){try{postSetup();}catch(e){console.error(e);}}else postAudio(false);};}
{const _uw30=updateWaves;updateWaves=function(dt){if(G.post)return;return _uw30(dt);};}
{const _up30=update;update=function(dt){_up30(dt);if(G.post&&inMission()&&G.state==='play'&&G.deadT<=0){try{postTick(dt);}catch(e){console.error(e);}}};}
{const _go30=gameOver;gameOver=function(){if(G.post&&G.player&&G.mode==='world'){try{if(postRespawn())return;}catch(e){console.error(e);}postAudio(false);}return _go30();};}
{const _tp30=tryPulse;tryPulse=function(){const p=G.player,was=!!p&&p.en>=100;_tp30();if(was&&p.en<100&&G.post)postOnPulse();};}
{const _hud30=updateHUD;updateHUD=function(){_hud30();const P=G.post;if(!P)return;setT('misT','СТОРОЖЕВИК «ИЗМОРОЗЬ»');
  const tot=P.panels.length+P.cells.length+P.gens.length+(P.core?1:0)||1,dn=P.panels.filter(q=>q.on).length+P.cells.filter(q=>q.got).length+P.gens.filter(q=>q.on).length+(P.core&&P.core.on?1:0);
  setT('sigT',P.escape>0?'К ШЛЮЗУ':POST_ACTS[P.act].name);if(G.frozen>0)setT('dashC','РЫВОК · ЛЁД');setS('sigB',(P.escape>0?Math.max(0,P.escT)/P.escape:dn/tot).toFixed(3));setH('sigBar',false);};}
// выход из корабля — сразу в сектор III: проход открыт, курс на миссию 11, итоги — коротким сообщением
{const _rw30=returnToWorld;returnToWorld=function(){const was=!!G.post;G.post=null;postAudio(false);_rw30();
  if(was&&G.postMsg){const first=G.postMsg===1,R_=G.postRes;G.postMsg=0;G.postRes=null;
    setTimeout(()=>{if(first)banner('ПРОХОД ОТКРЫТ','СЕКТОР III · ХОЛОДНЫЙ АРХИВ');const n=WORLD.nodes[CORE];if(n&&G.state==='world')G.course={x:n.x,y:n.y+150,label:'МИССИЯ 11'};},500);
    if(R_)setTimeout(()=>{try{toast('СТОРОЖЕВИК ПРОЙДЕН','Время '+mmss(R_.t)+' · лом +'+R_.lom+(R_.fr===0?' · ни разу не замёрзли':'')+(R_.skin?' · скин «Изморозь»':'')+' · записи вахты '+R_.logs+'/4');}catch(e){}},3200);}};}
{const _tm30=toMenu;toMenu=function(){G.post=null;postAudio(false);return _tm30.apply(this,arguments);};}
{const _rj30=renderJournals;renderJournals=function(el,mapBtn){_rj30(el,mapBtn);try{const ps=G.save&&G.save.post;if(!ps||!ps.logs||!ps.logs.length&&!ps.done)return;
  const h=`<div class="jsec">СТОРОЖЕВИК «ИЗМОРОЗЬ» <small>${ps.logs.length}/4</small></div>`+ps.logs.slice().sort().map(i=>`<div class="jr"><h4>${POST_LOGS[i].title}</h4><p>${POST_LOGS[i].text}</p></div>`).join('');el.insertAdjacentHTML('beforeend',h);}catch(e){}};}
// скин за прохождение без единой заморозки
Object.assign(SKINS,{izmo:{name:'Изморозь',col:'#cfefff',bul:'#ffffff',trail:'#bfe8ff',d:'Корпус в инее, который не тает. Снят со сторожевика на границе.',unlock:0,find:'ГРАНИЦА II–III · СТОРОЖЕВИК'}});HULL_NUM.izmo='015';
{const _ds30=w58DrawSkin;w58DrawSkin=function(id,t,sp,o,A,fl,edge){if(id!=='izmo')return _ds30(id,t,sp,o,A,fl,edge);
  glow(-12,0,fl*.8,'#dff6ff',.45);ctx.fillStyle='#0d1a2a';ctx.strokeStyle=edge;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.strokeStyle='rgba(223,246,255,.8)';ctx.lineWidth=1;for(const s of [-1,1]){ctx.beginPath();ctx.moveTo(4,s*2);ctx.lineTo(-4,s*7);ctx.lineTo(-2,s*9);ctx.moveTo(-2,s*4);ctx.lineTo(-9,s*9);ctx.stroke();}
  ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(6,0,2,0,TAU);ctx.fill();return true;};}
// музыка: внутри трек сектора II на минимуме (гул корабля звучит поверх, музыкальный канал приглушён)
{const _mt30=musTarget;musTarget=function(){if(!G.post)return _mt30();const m=G.m;G.m=CORE;let r;try{r=_mt30();}finally{G.m=m;}r.I=Math.min(r.I||0,.06);r.calm=true;return r;};}
{const _aa30=applyAudio;applyAudio=function(){_aa30();if(G.post&&AU.ctx)try{AU.amb.gain.setTargetAtTime(0,AU.ctx.currentTime,.3);}catch(e){}};}

// ваш рывок иногда звучит ещё раз — издалека, через секунду
{const _sx30=sfx;sfx=function(k){const r=_sx30.apply(this,arguments);try{if(G.post&&k==='dash'&&Math.random()<.3)setTimeout(()=>{try{if(G.post)(ARCH.off['A-7']||typeof iso63!=='function'?_sx30:iso63(_sx30))('dash');/* ARCH·70 A-7 */}catch(e){}},1100+Math.random()*500);}catch(e){}return r;};}


/* ===== 1.2.3 α «Погоня»: полоса разгона, гравитационный колодец закрытых миссий, редкое событие «Погоня» ===== */
function lessFx34(){return document.documentElement.classList.contains('lessfx')||!SET.fx;}
function rgba34(hex,a){const n=parseInt(hex.slice(1),16);return `rgba(${n>>16&255},${n>>8&255},${n&255},${Math.max(0,Math.min(1,a)).toFixed(3)})`;}

// ---------- 1. Полоса разгона: куда (шевроны), до куда (скоба), когда (заливка и фиксация) ----------
const RAM_V=660,RAM_T=.55,RAM_AIM=.85,RAM_LOCK=.22;
// путь до полной остановки: рывок 0,55 с плюс скольжение в отдыхе (скорость × 0,92 за кадр)
function ramStop(){/* рывок (кадры замаха→рывка включительно) + занос 0,7 с при v*=.92 за кадр */return RAM_V*(RAM_T+2/60+.92*(1-Math.pow(.92,42))/.08/60)*(G.eSpd||1);}
// x,y — центр врага; ang — курс; len — путь рывка (скорость × время); hw — полуширина коридора удара; k — прогресс 0..1;
// locked — курс зафиксирован; o.r — отступ от корпуса, o.flash — вспышка фиксации 0..1, o.alpha — общий множитель (шлейф)
function teleLane(x,y,ang,len,hw,k,locked,col,o){o=o||{};const lf=lessFx34(),r0=o.r||0,hw2=hw*.6,A=o.alpha===undefined?1:o.alpha;
  const pulse=!lf&&!locked&&k<.4?1+.15*Math.sin(G.t*TAU*2.5):1,jit=!lf&&!locked&&o.alpha===undefined?(Math.random()-.5):0;
  ctx.save();ctx.translate(x,y);ctx.rotate(ang);
  if(o.alpha===undefined){const a=(.06+.06*k)*A,g=ctx.createLinearGradient(r0,0,len,0),kk=clamp(k,.02,.98);
    g.addColorStop(0,rgba34(col,a));g.addColorStop(kk,rgba34(col,a*.85));g.addColorStop(Math.min(1,kk+.02),rgba34(col,.015*A));g.addColorStop(1,rgba34(col,.015*A));
    ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(r0,-hw);ctx.lineTo(len,-hw2);ctx.lineTo(len,hw2);ctx.lineTo(r0,hw);ctx.closePath();ctx.fill();}
  const rg=ctx.createLinearGradient(r0,0,len,0);rg.addColorStop(0,rgba34(col,(locked?.85:.7)*A*pulse));rg.addColorStop(1,rgba34(col,(locked?.4:.25)*A));
  ctx.strokeStyle=rg;ctx.lineWidth=locked?1.5:1.2;ctx.beginPath();ctx.moveTo(r0,-hw+jit);ctx.lineTo(len,-hw2+jit);ctx.moveTo(r0,hw-jit);ctx.lineTo(len,hw2-jit);ctx.stroke();
  if(o.flash>0){ctx.globalCompositeOperation='lighter';ctx.strokeStyle=rgba34(col,.4*o.flash);ctx.lineWidth=2.6;ctx.beginPath();ctx.moveTo(r0,-hw);ctx.lineTo(len,-hw2);ctx.moveTo(r0,hw);ctx.lineTo(len,hw2);ctx.stroke();ctx.globalCompositeOperation='source-over';}
  if(o.alpha===undefined){const sp=lf?0:(.6+1.8*k),fr=(G.t*sp)%1,cs=Math.min(8,hw2*.8);ctx.strokeStyle=rgba34(col,.55*A);ctx.lineWidth=1.3;
    for(let i=0;i<3;i++){const q=(fr+i/3)%1,cx=r0+(len-r0)*(.12+.76*q);ctx.globalAlpha=lf?1:Math.min(1,Math.sin(q*Math.PI)*1.6);ctx.beginPath();ctx.moveTo(cx-cs,-cs);ctx.lineTo(cx,0);ctx.lineTo(cx-cs,cs);ctx.stroke();}ctx.globalAlpha=1;
    ctx.strokeStyle=rgba34(col,(locked?.95:.75)*A);ctx.lineWidth=1.8;ctx.beginPath();ctx.moveTo(len-7,-hw2-4);ctx.lineTo(len,-hw2-4);ctx.lineTo(len,hw2+4);ctx.lineTo(len-7,hw2+4);ctx.stroke();}
  ctx.restore();}
function laneRammer(e){if(G.noTele)return;const pr=(G.player&&G.player.r)||14;
  if(e.st==='aim'){const k=1-clamp(e.timer/RAM_AIM,0,1),lk=e.timer<=RAM_LOCK,fl=lk?Math.max(0,1-(RAM_LOCK-e.timer)/.12):0;
    e.lane={x:e.x,y:e.y,a:e.aim};teleLane(e.x,e.y,e.aim,ramStop(),e.r+pr,k,lk,EDEF.rammer.col,{r:e.r+2,flash:fl});}
  else if(e.st==='charge'&&e.lane&&e.timer>RAM_T-.15){const L=e.lane;teleLane(L.x,L.y,L.a,ramStop(),e.r+pr,1,true,EDEF.rammer.col,{r:e.r+2,alpha:(e.timer-(RAM_T-.15))/.15});}}

// ---------- 2. Гравитационный колодец закрытой миссии ----------
const WELL_R0=560,WELL_R1=420,WELL_MIN=170,WELL_DRIFT=80;
function wellK(d){return Math.pow(clamp((d-WELL_MIN)/(WELL_R0-WELL_MIN),0,1),1.6);}
function wellReq(m){for(let q=1;q<m;q++)if(!progDone(q))return q;return Math.max(1,m-1);}
function wellTick(dt){const p=G.player,w=G.w;if(!p||p.hp<=0)return;let depth=0,near=null;
  for(const n of WORLD.nodes){if(nodeState(n.m)!=='locked')continue;const d=Math.hypot(p.x-n.x,p.y-n.y);if(d>=WELL_R0)continue;
    const ux=(p.x-n.x)/(d||1),uy=(p.y-n.y)/(d||1),d0=Math.hypot(p.px-n.x,p.py-n.y);
    // смещение кадра: внутрь — гасится k(d), наружу — свободно; плюс снос наружу
    const mx=p.x-p.px,my=p.y-p.py,dr=mx*ux+my*uy;if(dr<0){const k=wellK(Math.min(d,d0));p.x-=ux*dr*(1-k);p.y-=uy*dr*(1-k);}
    /* вбок — свободно: колодец можно обогнуть по краю, не застревая */
    const drift=WELL_DRIFT*clamp(1-(d-WELL_MIN)/(WELL_R0-WELL_MIN),0,1);p.x+=ux*drift*dt;p.y+=uy*drift*dt;
    const d2=Math.hypot(p.x-n.x,p.y-n.y);if(d2<WELL_MIN){p.x=n.x+ux*WELL_MIN;p.y=n.y+uy*WELL_MIN;}
    const dp=1-clamp((d-WELL_MIN)/(WELL_R0-WELL_MIN),0,1);if(dp>depth){depth=dp;near=n;}
    if(d<WELL_R1&&d0>=WELL_R1){buzz('hit');hintOnce('noise','СИГНАЛ НЕ РАСШИФРОВАН','#9fb0c4');}}
  G.well={depth,n:near};if(depth>0)G.calm=0;wellAudio(depth);}
let wellAU=null;
function wellAudio(depth){try{if(!AU.ctx||!SET.sfx){if(wellAU){wellAU.g.gain.value=0;}return;}const c=AU.ctx;
  if(!wellAU&&depth>0){const g=c.createGain();g.gain.value=0;g.connect(AU.sfx);const o=c.createOscillator();o.type='sine';o.frequency.value=48;const o2=c.createOscillator();o2.type='triangle';o2.frequency.value=96.5;const g2=c.createGain();g2.gain.value=.25;o.connect(g);o2.connect(g2);g2.connect(g);o.start();o2.start();wellAU={g,o,o2};}
  if(wellAU){wellAU.g.gain.setTargetAtTime(depth>0&&G.state==='world'?.18*depth:0,c.currentTime,.2);wellAU.o.frequency.setTargetAtTime(48+62*depth,c.currentTime,.3);wellAU.o2.frequency.setTargetAtTime(96.5+124*depth,c.currentTime,.3);}}catch(e){}}
function drawWell(n,t){const p=G.player,d=p?Math.hypot(p.x-n.x,p.y-n.y):1e9,lf=lessFx34(),near=clamp(1-(d-WELL_MIN)/(1100-WELL_MIN),0,1);
  // кольца-изолинии воронки: густеют к центру
  ctx.save();ctx.translate(n.x,n.y);for(let i=0;i<6;i++){const q=(i+.5)/6,r=WELL_MIN+(WELL_R0-WELL_MIN)*Math.pow(q,1.7);ctx.strokeStyle=rgba34('#9fb0c4',(.05+.16*near)*(1-q*.5));ctx.lineWidth=1;
    ctx.setLineDash([10+i*4,8+i*3]);ctx.lineDashOffset=lf?0:-G.t*(18-i*2)*(i%2?1:-1);ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.stroke();}ctx.setLineDash([]);
  ctx.strokeStyle=rgba34('#9fb0c4',.3);ctx.setLineDash([6,10]);ctx.beginPath();ctx.arc(0,0,WELL_R1,0,TAU);ctx.stroke();ctx.setLineDash([]);
  // течение наружу: штрихи бегут от центра
  if(SET.fx){const N=lf?14:42;for(let i=0;i<N;i++){const a=i*2.399+(i%7)*.1,ph=((G.t*(.18+(i%5)*.03)+i*.137)%1),r=WELL_MIN*.6+(WELL_R0-WELL_MIN*.6)*ph,l=8+18*(1-ph);
    ctx.strokeStyle=rgba34('#bfd2e6',(.08+.22*near)*(1-ph));ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(Math.cos(a)*r,Math.sin(a)*r);ctx.lineTo(Math.cos(a)*(r+l),Math.sin(a)*(r+l));ctx.stroke();}}
  // тизер: сквозь помехи едва виден маяк миссии
  ctx.globalAlpha=.12+.2*near*(lf?1:.7+.3*Math.sin(G.t*7));ctx.strokeStyle='#9fb0c4';ctx.lineWidth=2;poly(8,22,G.t*.2);ctx.stroke();ctx.globalAlpha=1;ctx.restore();
  const depth=clamp(1-(d-WELL_MIN)/(WELL_R0-WELL_MIN),0,1);
  if(depth>.55)worldLabel(n.x,n.y-44,'МИССИЯ '+pad2(n.m)+' · СНАЧАЛА '+pad2(wellReq(n.m)),'#9fb0c4');else worldLabel(n.x,n.y,'?','#7a8ea5');}

// ---------- 3. «Погоня»: патруль сектора гонится за двойником VØID к Разлому ----------
RADIO['Д']={tag:'БЕЗ ПОЗЫВНОГО',col:'#ffb84d',l:[{t:'…вижу край… ещё немного…'},{t:'…не догонят… не должны догнать…'},{t:'…там тихо. Там должно быть тихо…'}]};
const CHASE={vFar:.6,tMin:30,tMax:60,check:60,p:.04,pLate:.12,gap:1200,late:2700,dMin:1600,dMax:2400,near:1200,doom:900,lose:1900};
let CHS=null;
function chaseSave(){const S=G.save;if(!S)return null;if(!S.chase||typeof S.chase!=='object')S.chase={seen:0,lost:0,wt:0,last:-1e9,ck:0};return S.chase;}
function chaseCan(){const S=G.save,p=G.player;if(!S||!p||G.state!=='world'||!G.world||G.mode!=='world')return false;if(!progDone(6))return false;
  if((G.calm||0)<20||G.event||G.anom||(typeof zbOn==='function'&&zbOn())||(G.riftI||0)>.05||p.hp<=0)return false;
  if(G.zones&&G.zones.some(z=>z.active))return false;const sec=inSectors(p.x,p.y)?sectorIdx(p.x,p.y):-1;if(sec<0||sec>=11)return false;return true;}
function chaseSpd(){return ((G.st&&G.st.speed)||260);}
function chasePick(){const p=G.player;const base=Math.atan2(p.vy||0,p.vx||1);
  for(let tr=0;tr<60;tr++){const a=tr<30?base+(Math.random()<.5?1:-1)*(Math.PI/2+rnd(-.6,.6)):rnd(0,TAU),d=rnd(CHASE.dMin,CHASE.dMax),x=p.x+Math.cos(a)*d,y=p.y+Math.sin(a)*d;
    if(!inSectors(x,y)||!revealedAt(x,y))continue;try{if(fogBlockedAt(x,y))continue;}catch(e){}
    const sec=sectorIdx(x,y);if(sec<0||sec>=11)continue;
    if(WORLD.nodes.some(n=>nodeState(n.m)==='locked'&&Math.hypot(n.x-x,n.y-y)<WELL_R0+200))continue;
    if(WORLD.shops.some(s=>Math.hypot(s.x-x,s.y-y)<700))continue;if(G.zones&&G.zones.some(z=>z.active&&Math.hypot(z.x-x,z.y-y)<1200))continue;
    // курс: прямая до края Разлома длиной 30–60 с хода; не через игрока
    const v=chaseSpd()*CHASE.vFar,ax=x-p.x,ay=y-p.y,al=Math.hypot(ax,ay)||1,o0=rnd(0,TAU);let best=null;
    for(let k=0;k<16;k++){const h=o0+k*TAU/16,hx=Math.cos(h),hy=Math.sin(h);if((hx*ax+hy*ay)/al<-.2)continue;let L=0;while(L<v*CHASE.tMax+400&&inSectors(x+hx*L,y+hy*L)&&riftInfo(x+hx*L,y+hy*L).d<-220)L+=60;
      const tt=L/v;if(tt<CHASE.tMin||tt>CHASE.tMax)continue;if(!best||Math.abs(tt-45)<Math.abs(best.tt-45))best={tt,tx:x+hx*(L+240),ty:y+hy*(L+240)};}
    if(!best)continue;return {x,y,sec,tx:best.tx,ty:best.ty,tt:best.tt};}
  return null;}
function chaseSet(sec,x,y){let best=null,bd=1e18;for(const z of WORLD.zones){if(!z.set||sectorIdx(z.x,z.y)!==sec)continue;const d=Math.hypot(z.x-x,z.y-y);if(d<bd){bd=d;best=z;}}
  const set=best?best.set:{scout:3,gunner:2};const L=[];for(const [t,c] of Object.entries(set))for(let i=0;i<c;i++)if(EDEF[t]&&!['mine','lock','boss','jam'].includes(t))L.push(t);
  if(!L.length)L.push('scout','scout','gunner','gunner');const n=clamp(4+(Math.random()*3|0),4,6),out=[];for(let i=0;i<n;i++)out.push(L[(i*7+3)%L.length]);
  if(sec>=2&&best&&best.lead)out[0]=best.lead;return out;}
function chaseStart(force){const S=G.save,cs=chaseSave();if(!S||CHS)return false;const pk=chasePick();if(!pk)return false;
  const serial=(()=>{let n;do{n=14+(Math.random()*85|0);}while(n===13);return n;})();
  const dir=Math.atan2(pk.ty-pk.y,pk.tx-pk.x);
  CHS={ph:'far',t:0,sec:pk.sec,tx:pk.tx,ty:pk.ty,set:chaseSet(pk.sec,pk.x,pk.y),serial,
    d:{x:pk.x,y:pk.y,vx:Math.cos(dir),vy:Math.sin(dir),r:14,hp:140,maxHp:140,ang:dir,dodgeT:1.5,fireT:1,seenT:0,doomT:null,dead:false,gone:0},
    pat:{x:pk.x-Math.cos(dir)*320,y:pk.y-Math.sin(dir)*320},hunters:[],tr:[],fade:0,turnT:0,force:!!force};
  cs.last=cs.wt;try{radioSay('Д',(Math.random()*3)|0);}catch(e){}return true;}
function chaseEnd(lost){const cs=chaseSave();if(CHS){for(const e of CHS.hunters)if(e.alive&&e.hunt){e.alive=false;}if(lost&&cs)cs.lost++;}CHS=null;}
function chaseSpawnHunters(){const c=CHS,p=G.player;c.hunters=[];for(let i=0;i<c.set.length;i++){const a=i/c.set.length*TAU,x=c.pat.x+Math.cos(a)*60,y=c.pat.y+Math.sin(a)*60;
  const e=spawnEnemy(c.set[i],x,y,{noAffix:true,spawnT:.3});e.hunt=true;e.chase=true;e.hi=i;e.hcd=rnd(.4,1);c.hunters.push(e);}c.ph='live';}
function chaseTick(dt){const cs=chaseSave();if(!cs)return;if(G.state==='world'&&G.world)cs.wt+=dt;
  if(!CHS){if(!G.world||G.state!=='world')return;cs.ck=(cs.ck||0)+dt;if(cs.ck>=CHASE.check){cs.ck=0;if(cs.wt-cs.last>=CHASE.gap&&chaseCan()){const pr=cs.wt-cs.last>=CHASE.late?CHASE.pLate:CHASE.p;if(Math.random()<pr)chaseStart();}}return;}
  const c=CHS,p=G.player,D=c.d;if(!G.world||G.mode!=='world'){chaseEnd(false);return;}c.t+=dt;
  if(c.fade>0){c.fade-=dt;if(c.fade<=0)chaseEnd(c.lostFlag);return;}
  const dP=Math.hypot(D.x-p.x,D.y-p.y),toT=Math.atan2(c.ty-D.y,c.tx-D.x),base=chaseSpd();
  if(!D.dead){
    // двойник: к краю Разлома; вдали — быстро и ровно, в живом бою — медленнее, уворачивается и отстреливается
    const live=c.ph==='live',v=live?base*.7:base*CHASE.vFar;D.dodgeT-=dt;let side=0;if(live&&D.dodgeT<=0){D.dodgeT=rnd(1.4,2.4);D.dash=.25*(Math.random()<.5?1:-1);}
    if(D.dash){side=Math.sign(D.dash);D.dash=Math.abs(D.dash)>dt?D.dash-Math.sign(D.dash)*dt:0;}
    const a=toT+Math.sin(c.t*.7)*.18;D.vx=Math.cos(a)*v+(side?-Math.sin(a)*side*520:0);D.vy=Math.sin(a)*v+(side?Math.cos(a)*side*520:0);D.x+=D.vx*dt;D.y+=D.vy*dt;D.ang=Math.atan2(D.vy,D.vx);
    if(SET.fx&&live&&Math.random()<.5)part(D.x-Math.cos(D.ang)*14,D.y-Math.sin(D.ang)*14,-D.vx*.2,-D.vy*.2,.35,'#6f8fb0',2);
    if(Math.hypot(c.tx-D.x,c.ty-D.y)<60||(!inSectors(D.x,D.y)&&Math.hypot(c.tx-D.x,c.ty-D.y)<700)){D.dead=true;D.gone=1;c.fade=2;c.lostFlag=true;if(live){chaseTurn();}else return;}
    if(!live){const pd=Math.hypot(c.pat.x-D.x,c.pat.y-D.y),pa=Math.atan2(D.y-c.pat.y,D.x-c.pat.x),pv=pd>340?v*1.05:pd<260?v*.9:v;c.pat.x+=Math.cos(pa)*pv*dt;c.pat.y+=Math.sin(pa)*pv*dt;
      if(dP<CHASE.near)chaseSpawnHunters();}
    else{if(dP>CHASE.lose+100){for(const e of c.hunters)e.alive=false;c.hunters=[];c.ph='far';c.pat={x:D.x-Math.cos(D.ang)*320,y:D.y-Math.sin(D.ang)*320};return;}
      // развязка: игрок ближе 700 или видит двойника на экране дольше 2 с
      const onS=inView(D.x,D.y,20);D.seenT=onS?D.seenT+dt:Math.max(0,D.seenT-dt);if(D.doomT===null&&(dP<CHASE.doom||D.seenT>1.2))D.doomT=rnd(2.2,3.4);
      if(D.doomT!==null){D.doomT-=dt;if(D.doomT<=0)D.hp=0;}
      D.fireT-=dt;if(D.fireT<=0){D.fireT=rnd(.35,.6);const tg=c.hunters.filter(e=>e.alive).sort((a,b)=>Math.hypot(a.x-D.x,a.y-D.y)-Math.hypot(b.x-D.x,b.y-D.y))[0];
        if(tg){const a2=Math.atan2(tg.y-D.y,tg.x-D.x);c.tr.push({x:D.x,y:D.y,vx:Math.cos(a2)*900,vy:Math.sin(a2)*900,life:.5,col:'#9fd8ff',own:true});}}
      if(!c.paid&&c.hunters.length&&c.hunters.every(e=>!e.alive)){c.paid=1;chaseReward();}
      if(D.hp<=0)chaseDie();}}
  else if(c.ph==='turn'){c.turnT-=dt;for(const e of c.hunters)if(e.alive){e.vx*=.85;e.vy*=.85;}if(c.turnT<=0){c.ph='fight';for(const e of c.hunters)if(e.alive){e.hunt=false;}
      const q=c.hunters.find(e=>e.alive);if(q)floater(q.x,q.y-40,'ПАТРУЛЬ','#ff4f6e');sfx('warn');}}
  else if(c.ph==='fight'){const alive=c.hunters.filter(e=>e.alive);if(!alive.length){if(!c.paid){c.paid=1;chaseReward();}chaseEnd(false);return;}
    if(Math.min(...alive.map(e=>Math.hypot(e.x-p.x,e.y-p.y)))>CHASE.lose){for(const e of alive)e.alive=false;chaseEnd(false);return;}}
  // трассы: попадания по двойнику
  for(const b of c.tr){b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;if(!b.own&&!D.dead&&Math.hypot(b.x-D.x,b.y-D.y)<D.r+4){b.life=0;D.hp-=7;if(SET.fx)part(D.x,D.y,rnd(-80,80),rnd(-80,80),.3,'#ffd9a0',2);}
    if(b.own)for(const e of c.hunters)if(e.alive&&Math.hypot(b.x-e.x,b.y-e.y)<e.r+3){b.life=0;if(SET.fx)part(b.x,b.y,rnd(-60,60),rnd(-60,60),.2,'#9fd8ff',1.5);break;}}
  c.tr=c.tr.filter(b=>b.life>0);if(c.gl>0)c.gl-=dt;}
function chaseDie(){const c=CHS,D=c.d;D.dead=true;c.gl=.6;try{postSnd('static',0,1);}catch(e){}if(SET.fx)for(let i=0;i<14;i++)part(D.x,D.y,rnd(-160,160),rnd(-160,160),.5,Math.random()<.5?'#ff2d55':'#2de0ff',2);
  const cs=chaseSave();if(cs&&!c.counted){c.counted=1;cs.seen++;c.firstSeen=cs.seen===1;}chaseTurn();}
function chaseTurn(){const c=CHS;if(!c.hunters.some(e=>e.alive)){c.fade=Math.max(c.fade,2);return;}c.ph='turn';c.turnT=.6;c.fade=0;}
function chaseReward(){const c=CHS,S=G.save,p=G.player;if(!c.d.dead){const cs=chaseSave();if(cs&&!c.counted){c.counted=1;cs.seen++;c.firstSeen=cs.seen===1;}}const v=Math.round((10+c.hunters.length*3)*1.5);S.carry=(S.carry||0)+v;floater(p.x,p.y-40,'ПАТРУЛЬ РАЗБИТ · +'+v+' ЛОМА','#c9d2de');sfx('level');try{conEvent('patrol');}catch(e){}
  if(c.firstSeen)setTimeout(()=>{try{toast('ДВОЙНИК · КУРС НА РАЗЛОМ','Запись открыта в журналах.');}catch(e){}},900);saveWorld();}
// ИИ охотников: пока двойник жив, патруль его не отпускает и игрока не замечает
function chaseHunterAI(dt){const c=CHS;if(!c)return;const D=c.d;for(const e of c.hunters){if(!e.alive||!e.hunt)continue;if(e.spawnT>0){e.spawnT-=dt;continue;}
  if(D.dead){e.vx*=.9;e.vy*=.9;e.x+=e.vx*dt;e.y+=e.vy*dt;continue;}
  const back=Math.atan2(-D.vy,-D.vx),off=(e.hi-(c.hunters.length-1)/2)*.45,R=150+(e.hi%3)*40,tx=D.x+Math.cos(back+off)*R,ty=D.y+Math.sin(back+off)*R,dx=tx-e.x,dy=ty-e.y,dl=Math.hypot(dx,dy)||1,sp=(EDEF[e.type].spd||90)*2.4;
  e.vx+=(dx/dl*sp-e.vx)*Math.min(1,dt*3);e.vy+=(dy/dl*sp-e.vy)*Math.min(1,dt*3);e.x+=e.vx*dt;e.y+=e.vy*dt;e.ang=Math.atan2(D.y-e.y,D.x-e.x);
  e.hcd-=dt;if(e.hcd<=0){e.hcd=rnd(.55,1.1);const a=Math.atan2(D.y-e.y,D.x-e.x)+rnd(-.06,.06);c.tr.push({x:e.x,y:e.y,vx:Math.cos(a)*620,vy:Math.sin(a)*620,life:.9,col:EDEF[e.type].col||'#ff4f6e'});}}}
function chaseDraw(t){if(!CHS)return;const c=CHS,D=c.d;
  for(const b of c.tr){ctx.strokeStyle=b.col;ctx.globalAlpha=.85;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(b.x-b.vx*.025,b.y-b.vy*.025);ctx.stroke();}ctx.globalAlpha=1;
  if(!D.dead||c.gl>0){if(!inView(D.x,D.y,60))return;const gl=c.gl>0?c.gl/.6:0;
    const one=(dx,col,al)=>{ctx.save();ctx.translate(D.x+dx,D.y);ctx.rotate(D.ang);ctx.globalAlpha=al;if(col){ctx.globalCompositeOperation='lighter';ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-11,-12);ctx.lineTo(-5,0);ctx.lineTo(-11,12);ctx.closePath();ctx.fill();}else drawShip('base',t,Math.hypot(D.vx,D.vy),{});ctx.restore();ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';};
    if(gl>0){if(Math.random()<.7){one(-5,'#ff2d55',.5*gl);one(5,'#2de0ff',.5*gl);one(0,null,.6*gl);}}else{one(0,null,.88);
      worldLabel(D.x,D.y-34,'VØID-0'+String(c.serial).padStart(2,'0'),'#9fb0c4');}}}
// карта и мини-карта: знак патруля (три шеврона) и оранжевый «?», оба движутся
function chaseMapPts(){if(!CHS)return null;const c=CHS,D=c.d;let px=c.pat.x,py=c.pat.y,pa=Math.atan2(D.y-c.pat.y,D.x-c.pat.x);
  if(c.ph!=='far'){const al=c.hunters.filter(e=>e.alive);if(al.length){px=al.reduce((s,e)=>s+e.x,0)/al.length;py=al.reduce((s,e)=>s+e.y,0)/al.length;pa=D.dead?Math.atan2(G.player.y-py,G.player.x-px):Math.atan2(D.y-py,D.x-px);}else px=null;}
  return {q:D.dead&&!c.fade?null:{x:D.x,y:D.y,a:c.fade>0?Math.min(1,c.fade/2):1},pt:px===null?null:{x:px,y:py,a:pa}};}
function chaseIcon(g,kind,o,t){if(kind==='chaseQ'){g.globalAlpha=o.a===undefined?1:o.a;g.font='800 13px "JetBrains Mono",monospace';g.textAlign='center';g.fillStyle='#ffb84d';g.fillText('?',0,4.5);g.globalAlpha=1;return true;}
  if(kind==='chaseP'){g.save();g.rotate(o.ang||0);g.strokeStyle='#ff4f6e';g.lineWidth=1.6;for(const dx of [-5,0,5]){g.beginPath();g.moveTo(dx-3,-4);g.lineTo(dx+1,0);g.lineTo(dx-3,4);g.stroke();}g.restore();return true;}return false;}
{const _ma34=w58MapAdd;w58MapAdd=function(add,lod,S){_ma34(add,lod,S);try{const m=chaseMapPts();if(m){if(m.pt)add('chaseP',m.pt.x,m.pt.y,{ang:m.pt.a},lod>=1?{t:'ПАТРУЛЬ',p:3,c:'#ff4f6e'}:null);if(m.q)add('chaseQ',m.q.x,m.q.y,{a:m.q.a},null);}}catch(e){}};}
{const _mi34=w58MapIcon;w58MapIcon=function(g,kind,o,t){if(chaseIcon(g,kind,o,t))return true;return _mi34(g,kind,o,t);};}
{const _mn34=mini95;mini95=function(g,P,s){_mn34(g,P,s);try{const m=chaseMapPts();if(!m)return;const clampP=(x,y)=>{const dx=x-s/2,dy=y-s/2,dl=Math.hypot(dx,dy),mr=s/2-9;return dl>mr?[s/2+dx/dl*mr,s/2+dy/dl*mr]:[x,y];};
  if(m.pt){const [x,y]=clampP(...P(m.pt.x,m.pt.y));g.save();g.translate(x,y);g.scale(1.6,1.6);chaseIcon(g,'chaseP',{ang:m.pt.a});g.restore();}
  if(m.q){const [x,y]=clampP(...P(m.q.x,m.q.y));g.save();g.translate(x,y);g.scale(1.5,1.5);chaseIcon(g,'chaseQ',{a:m.q.a*(.75+.25*Math.sin(G.t*5))});g.restore();}}catch(e){}};}
{const _bl34=buildMapLegend;buildMapLegend=function(){const L=$('#mapLeg');const had=L&&L.dataset.ok;_bl34();try{if(!L||had)return;const box=L.querySelector('.legi');if(!box)return;
  const s=document.createElement('span'),c=document.createElement('canvas');c.width=c.height=28*DPR;c.style.width=c.style.height='18px';const g=c.getContext('2d');g.scale(DPR,DPR);g.translate(14,14);chaseIcon(g,'chaseP',{ang:0});s.appendChild(c);s.appendChild(document.createTextNode('патруль'));box.appendChild(s);}catch(e){}};}
// стрелка у края экрана к событию — оранжевая, со знаком «?» и расстоянием; курс игрока не меняется
{const _ws34=w58Screen;w58Screen=function(t){_ws34(t);try{if(!CHS||G.state!=='world')return;const D=CHS.d;if(D.dead)return;ctx.save();ctx.setTransform(DPR,0,0,DPR,0,0);edgeArrow(D.x,D.y,'#ffb84d',10,'? · '+fmtAU(Math.hypot(D.x-G.player.x,D.y-G.player.y)));ctx.restore();}catch(e){}};}
// подключение к миру
{const _wu34=worldUpdate;worldUpdate=function(dt){_wu34(dt);try{chaseTick(dt);}catch(e){console.error(e);}};}
{const _ue34=updateEnemies;updateEnemies=function(dt){if(!CHS||!CHS.hunters.length||!G.world)return _ue34(dt);const H_=G.enemies.filter(e=>e.hunt&&e.alive);if(!H_.length)return _ue34(dt);
  G.enemies=G.enemies.filter(e=>!(e.hunt&&e.alive));try{_ue34(dt);}finally{const rest=G.enemies;G.enemies=rest.concat(H_.filter(e=>!rest.includes(e)));}chaseHunterAI(dt);};}
// пока патруль занят двойником, автонаведение его не выбирает: игрок решает сам, вмешиваться ли
{const _ne34=nearestEnemy;nearestEnemy=function(x,y,R,ig){if(!CHS)return _ne34(x,y,R,ig);const H_=CHS.hunters.filter(e=>e.alive&&e.hunt&&!e.n74);for(const e of H_)e.n74=1;try{return _ne34(x,y,R,ig);}finally{for(const e of H_)delete e.n74;}};}
// раненый охотник переключается на игрока
{const _h34=hurt;hurt=function(e,dmg,src){if(e&&e.hunt&&CHS){e.hunt=false;}return _h34(e,dmg,src);};}
{const _en34=enterNode;enterNode=function(){if(CHS)chaseEnd(false);return _en34.apply(this,arguments);};}
{const _tm34=toMenu;toMenu=function(){if(CHS)chaseEnd(false);return _tm34.apply(this,arguments);};}
{const _mg34=migrateSave;migrateSave=function(S){S=_mg34(S);if(!S||typeof S!=='object')return S;const C=S.chase&&typeof S.chase==='object'?S.chase:{};
  const num=(v,lo,hi,df)=>Number.isFinite(+v)?Math.max(lo,Math.min(hi,+v)):df;S.chase={seen:Math.round(num(C.seen,0,9999,0)),lost:Math.round(num(C.lost,0,9999,0)),wt:num(C.wt,0,1e9,0),last:num(C.last,-1e9,1e9,-1e9),ck:num(C.ck,0,600,0)};return S;};}
{const _rj34=renderJournals;renderJournals=function(el,mapBtn){_rj34(el,mapBtn);try{const cs=G.save&&G.save.chase;if(!cs||!cs.seen)return;
  el.insertAdjacentHTML('beforeend',`<div class="jsec">БЕЗ ПОЗЫВНОГО <small>${cs.seen}</small></div><div class="jr"><h4>ДВОЙНИК · КУРС НА РАЗЛОМ</h4><p>Тот же корпус, другой номер. Он не летел на задание — он летел к краю.</p></div>`);}catch(e){}};}
// разработка: запуск события сразу
window.chaseDev=()=>{if(CHS)chaseEnd(false);return chaseStart(true);};

/* ===== 1.2.3 · исправление облака: пустой прогресс больше не затирает облачную копию ===== */
/* ранг прогресса: цикл важнее числа пройденных миссий (новый цикл обнуляет пройденные) */
function cloudRank(raw){try{const S=typeof raw==='string'?JSON.parse(raw):raw;if(!validSave(S))return 0;return (Math.max(1,+S.cycle||1)-1)*1000+worldDone(S);}catch(e){return 0;}}
function bodyRank(b){return b&&b.keys?cloudRank(b.keys.void_world):0;}
cloudWinner=function(body){if(!body||!body.keys)return 'local';const lw=LS.getItem('void_world'),lr=cloudRank(lw),m=metaGet(),ct=+body.t||0,cf=+body.force||0,cr=bodyRank(body);
  if(m.force&&m.force>ct)return 'local';if(cf&&cf>m.t)return 'cloud';if(!lw&&body.keys.void_world)return 'cloud';
  if(cr>lr)return 'cloud';if(lr>cr)return 'local';return ct>m.t?'cloud':'local';};
/* резервная копия: лучшая облачная копия хранится отдельно и не перезаписывается меньшим прогрессом */
async function cloudBak(body){try{if(!body||!body.keys||!CLOUD.ref)return;const ref=CLOUD.bakRef||(CLOUD.bakRef=CLOUD.db.doc(CLOUD.path+'_best'));
  let cur=null;try{const s=await ref.get();cur=s&&s.exists?s.data():null;}catch(e){}
  if(cur&&bodyRank(cur)>=bodyRank(body))return;await ref.set(body);CLOUD.best=body;}catch(e){}}
cloudPush=async function(){if(CLOUD.state!=='ready'||!CLOUD.ref)return;
  if(CLOUD.pending){CLOUD.dirty=true;if(G.state!=='menu'&&!CLOUD.heldToast){CLOUD.heldToast=1;toast('ОБЛАЧНЫЙ ПРОГРЕСС НАЙДЕН','В облаке пройдено миссий: '+worldDone(CLOUD.pending.keys&&CLOUD.pending.keys.void_world)+'. Выйдите в меню — он загрузится.');}return;}  /* облачная копия ждёт возврата в меню — ничего не пишем поверх */
  if(CLOUD.busy){CLOUD.again=true;return;}if(!CLOUD.dirty)return;
  const b=cloudBody(),sg=cloudSig(b);if(sg===CLOUD.sig){CLOUD.dirty=false;return;}CLOUD.busy=true;CLOUD.dirty=false;let held=false;
  try{if(!CLOUD.peek){const s=await CLOUD.ref.get();CLOUD.peek=s&&s.exists?s.data():{keys:null};}
    const cur=CLOUD.peek&&CLOUD.peek.keys?CLOUD.peek:null,cr=bodyRank(cur),br=bodyRank(b),m=metaGet();
    if(cur&&cr>br){
      if(!(m.force&&m.force>(+cur.t||0))){              /* меньше прогресса без сброса по кнопке → не затираем, вернём облачную */
        held=true;CLOUD.pending=cur;CLOUD.dirty=true;
        if(G.state==='menu'){setTimeout(()=>{try{cloudMenuCheck();}catch(e){}},0);}
        else if(!CLOUD.heldToast){CLOUD.heldToast=1;toast('ОБЛАЧНЫЙ ПРОГРЕСС','В облаке сохранено больше (миссий: '+worldDone(cur.keys.void_world)+'). Выйдите в меню — он загрузится.');}
        return;}
      await cloudBak(cur);}                               /* осознанный сброс: лучшая копия остаётся в резерве */
    await CLOUD.ref.set(b);CLOUD.peek=b;CLOUD.sig=sg;CLOUD.lastAt=Date.now();CLOUD.err='';
    if(br>0&&(!CLOUD.best||br>bodyRank(CLOUD.best))&&br%1000>0&&(!CLOUD.bakAt||Date.now()-CLOUD.bakAt>120000)){CLOUD.bakAt=Date.now();cloudBak(b);}}
  catch(e){const c=e&&e.code;CLOUD.dirty=true;CLOUD.err=c||'unavailable';
    if(['invalid_argument','not_granted','capability_disabled','capability_removed','revoked','transform_error'].includes(c))CLOUD.state='ro';
    else setTimeout(()=>{if(CLOUD.dirty)cloudPush();},2500+Math.random()*2000);}
  finally{CLOUD.busy=false;if(!held&&CLOUD.again){CLOUD.again=false;if(CLOUD.dirty)cloudDirty();}}};
{const _cmc=cloudMenuCheck;cloudMenuCheck=function(){const b=CLOUD.pending;_cmc();if(b&&CLOUD.peek!==b&&cloudWinner(b)!=='cloud')CLOUD.peek=b;CLOUD.heldToast=0;};}
/* путь и база для резервной копии; облачная копия в момент входа тоже уходит в резерв */
{const _ci=cloudInit;cloudInit=async function(){try{const C=window.claude;if(C&&typeof C.use==='function'){const [db,user]=await Promise.all([C.use('db'),C.use('user')]);const uid=user&&await user.id();
    if(db&&uid){CLOUD.db=db;CLOUD.path='data/users/'+uid+'/save';}}}catch(e){}
  await _ci();
  try{if(CLOUD.state==='ready'&&CLOUD.db){const s=await CLOUD.db.doc(CLOUD.path+'_best').get();CLOUD.best=s&&s.exists?s.data():null;
    const s2=await CLOUD.ref.get();const cur=s2&&s2.exists?s2.data():null;if(cur&&cur.keys){CLOUD.peek=cur;if(bodyRank(cur)>bodyRank(CLOUD.best))cloudBak(cur);}}}catch(e){}
  try{if(G.state==='menu')renderMenu();}catch(e){}};}
/* кнопка «вернуть лучшую копию» в настройках */
function cloudBestHTML(){const B=CLOUD.best;if(!B||!B.keys)return '';const br=bodyRank(B),lr=cloudRank(LS.getItem('void_world'));if(br<=lr)return '';
  const n=worldDone(B.keys.void_world),c=Math.max(1,(()=>{try{return +JSON.parse(B.keys.void_world).cycle||1}catch(e){return 1}})());
  return `<div class="reset"><button class="rbtn" id="bCloudBest" style="border-color:rgba(127,224,255,.5);color:#7fe0ff">ВЕРНУТЬ СОХРАНЕНИЕ · МИССИЙ ${n}${c>1?' · ЦИКЛ '+c:''}</button></div>`;}
function cloudBestRestore(){const B=CLOUD.best;if(!B)return;cloudApply(B);cloudForce();toast('ПРОГРЕСС ВОЗВРАЩЁН','Загружена резервная облачная копия: пройдено миссий '+worldDone(B.keys.void_world)+'.');try{renderSettings();}catch(e){}}
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('#bCloudBest');if(!b)return;e.preventDefault();
  if(b.dataset.arm&&performance.now()-(+b.dataset.arm)<4000){cloudBestRestore();return;}b.dataset.arm=performance.now();b.textContent='НАЖМИТЕ ЕЩЁ РАЗ — ТЕКУЩИЙ ПРОГРЕСС ЗАМЕНИТСЯ';});

/* ===== 1.2.4 α: единый масштаб интерфейса UI (1080p = 1, 1440p = 1,35, 4K = 2) + сцена 21:9 ===== */
var UI=1;
SET_DEF.uiSize=1;SET_OPT.uiSize=[.9,1,1.1,1.25];SEGS.uiSize=[['ИНТЕРФЕЙС',[[.9,'90%'],[1,'АВТО'],[1.1,'110%'],[1.25,'125%']]]];
try{const v=store('void_settings');if(v&&SET_OPT.uiSize.includes(v.uiSize))SET.uiSize=v.uiSize;}catch(e){}
function uiCalc(){if(G.ff!=='desk')return 1;const a=Math.min(CW/1920,CH/1080);return Math.max(.85,Math.round(clamp(a,1,2.5)*(SET.uiSize||1)*20)/20);}
function stageW(){return G.ff==='desk'&&CW/CH>2.45?Math.round(CH*21/9):CW;}
function uiApply(){const u=uiCalc(),R=document.documentElement;UI=u;R.style.setProperty('--ui',u);R.classList.toggle('uiz',G.ff==='desk');
  const m=Math.max(0,(CW-stageW())/2);R.style.setProperty('--stage-m',(m/u).toFixed(2)+'px');R.style.setProperty('--stage-px',m.toFixed(1)+'px');R.classList.toggle('ultra',m>0);}
{const _rz=resize;resize=function(){_rz();try{uiApply();}catch(e){}};addEventListener('resize',()=>{try{uiApply();}catch(e){}});try{uiApply();}catch(e){}}
try{let mq=null;const watch=()=>{try{if(mq)mq.removeEventListener('change',on);mq=matchMedia('(resolution: '+(window.devicePixelRatio||1)+'dppx)');mq.addEventListener('change',on);}catch(e){}};const on=()=>{resize();watch();};watch();}catch(e){}
/* арена миссии на ПК шире 21:9 — 21:9 по центру, остальное — фон */
{const _la=lockArena;lockArena=function(){if(!isMob()&&VW/VH>21/9+.02){G.arena={w:Math.round(VH*21/9),h:Math.round(VH)};applyWH();return;}_la();};}
/* настройки: строка «Интерфейс» на ПК; применяется сразу */
{const _as=applySettings;applySettings=function(){_as();try{uiApply();}catch(e){}};}
if(SET.uiSize===undefined)SET.uiSize=1;
function stageL(){return (CW-stageW())/2;}
/* стрелка у края экрана (вызывается из погони и телефона): на ПК — в масштабе UI и в пределах сцены */
{const _ea=edgeArrow;edgeArrow=function(x,y,col,size,label){if(isMob()||UI===1&&!stageL())return _ea(x,y,col,size,label);
  const sl=stageL(),cw=CW,ch=CH,sc=SC,cx=CX,cy=CY;ctx.save();ctx.translate(sl,0);ctx.scale(UI,UI);
  try{CW=stageW()/UI;CH=ch/UI;SC=sc/UI;CX=cx+sl/sc;return _ea(x,y,col,size,label);}finally{CW=cw;CH=ch;SC=sc;CX=cx;CY=cy;ctx.restore();}};}
/* подписи на большой карте растут вместе с UI */
try{const c=document.getElementById('mapC'),g=c&&c.getContext('2d');if(g){const D=Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype,'font');
  Object.defineProperty(g,'font',{configurable:true,get(){return D.get.call(this);},set(v){D.set.call(this,UI===1?v:String(v).replace(/(\d+(?:\.\d+)?)px/,(m,n)=>(+n*UI).toFixed(1)+'px'));}});}}catch(e){}
/* арена 21:9 на сверхшироком: за краями — приглушённый фон и тонкая рамка поля */
{const _mo=mobOverlay;mobOverlay=function(now){try{if(!isMob()&&G.arena&&!G.world&&(G.state==='play'||G.state==='pause'||G.state==='levelup'||G.state==='intro')){
  ctx.setTransform(DPR,0,0,DPR,0,0);const x0=(0-CX)*SC,x1=(W-CX)*SC;ctx.fillStyle='rgba(2,3,8,.42)';if(x0>0)ctx.fillRect(0,0,x0,CH);if(x1<CW)ctx.fillRect(x1,0,CW-x1,CH);
  ctx.strokeStyle='rgba(143,233,255,.14)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x0+.5,0);ctx.lineTo(x0+.5,CH);ctx.moveTo(x1-.5,0);ctx.lineTo(x1-.5,CH);ctx.stroke();}}catch(e){}
  return _mo(now);};}

/* ===== 1.2.4 α: переключатели доезжают до края и едут плавно ===== */
/* ARCH·86 · слой renderSettings 1 из 3 (строка 13689 в 1.5.25) перенесён в объединённый слой ниже */
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('.tog[data-k]');if(!b)return;
  try{if(isMob()&&SET.haptics&&!SET.lessFx&&navigator.vibrate)navigator.vibrate(8);}catch(er){}},true);
document.addEventListener('keydown',e=>{const b=document.activeElement;if(!b||!b.matches||!b.matches('.tog[data-k]'))return;if(e.key!=='ArrowRight'&&e.key!=='ArrowLeft')return;
  e.preventDefault();e.stopImmediatePropagation();if(e.key==='ArrowRight'&&!b.classList.contains('on')||e.key==='ArrowLeft'&&b.classList.contains('on'))b.click();},true);

/* ===== 1.2.4 α: всплывающие сообщения закрываются нажатием или свайпом ===== */
const DX={born:{},hold:{}};
function dxBtn(el){if(!el||el.querySelector(':scope>.dx'))return;const b=document.createElement('button');b.className='dx';b.type='button';b.setAttribute('aria-label','Скрыть сообщение');b.tabIndex=-1;b.textContent='✕';el.appendChild(b);}
function dxFade(el,dir,done){if(!el)return;el.classList.remove('dxdrag');el.style.transition='';el.classList.add('dxout');el.dataset.dxd=dir||'';
  const fin=()=>{el.classList.remove('dxout');el.style.transform='';el.style.opacity='';done();};setTimeout(fin,(SET.lessFx||SET.fx===false)?100:180);}
function toastHide(dir){const el=document.getElementById('toast');if(!el||el.hidden)return;clearTimeout(toastTimer);dxFade(el,dir,()=>{el.hidden=true;});}
function fragHide(dir){const el=document.getElementById('fragTxt');if(!el||!el.classList.contains('on'))return;dxFade(el,dir,()=>{el.classList.remove('on');});}
function radioHide(all){const st=radioState();if(all&&st)st.q.length=0;const el=radioEl();if(!el||el.hidden)return;dxFade(el,'l',()=>{radioClear();});}
/* тост: свой таймер, пауза при наведении */
const TST={left:8000,t0:0};
{const _t=toast;toast=function(a,b){_t(a,b);const el=document.getElementById('toast');if(!el)return;dxBtn(el);el.classList.remove('dxout','hold');el.style.transform='';el.style.opacity='';
  DX.born.toast=performance.now();TST.left=8000;TST.t0=performance.now();clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastHide(),8000);};}
{const _fs=fragShow;fragShow=function(txt,n){_fs(txt,n);const el=document.getElementById('fragTxt');if(!el)return;el.innerHTML='<span class="fbox">'+el.innerHTML+'</span>';dxBtn(el.querySelector('.fbox'));DX.born.frag=performance.now();};}
document.addEventListener('animationend',e=>{if(e.target&&e.target.id==='fragTxt'&&e.animationName==='frag')e.target.classList.remove('on');});
{const _rt=radioTick;radioTick=function(dt,mode){if(DX.hold.radio){const st=radioState();if(st&&st.cur)return _rt(0,mode);}return _rt(dt,mode);};}
{const _rc=radioClear;radioClear=function(){_rc();DX.born.radio=performance.now();const el=radioEl();if(el)el.classList.remove('dxout');};}
function dxKind(el){return el.id==='toast'?'toast':el.id==='radio'?'radio':'frag';}
function dxRoot(t){return t.closest&&(t.closest('#toast')||t.closest('#radio')||t.closest('#fragTxt .fbox'));}
function dxClose(card,dir,all){const k=dxKind(card.id?card:card.closest('#fragTxt')||card);if(k==='toast')toastHide(dir);else if(k==='radio')radioHide(all);else fragHide(dir);}
/* в бою с прицелом мышью сообщения прозрачны для клика — закрываются только крестиком */
setInterval(()=>{try{const on=!isMob()&&SET.manual&&G.state==='play'&&G.enemies&&G.enemies.some(e=>e.alive&&!e.ghost&&e.spawnT<=0&&Math.abs(e.x-G.player.x)<VW*.6&&Math.abs(e.y-G.player.y)<VH*.6);
  document.documentElement.classList.toggle('dxaim',!!on);}catch(e){}},200);
{let drag=null;
  const down=e=>{const card=dxRoot(e.target);if(!card)return;e.stopPropagation();e.preventDefault();
    const el=card.id?card:card.closest('#fragTxt'),k=dxKind(el);if(performance.now()-(DX.born[k]||0)<250&&!e.target.closest('.dx'))return;
    if(e.target.closest('.dx')){dxClose(el,'',false);return;}
    drag={el,k,x:e.clientX,y:e.clientY,t:performance.now(),dx:0,dy:0,id:e.pointerId,touch:e.pointerType!=='mouse'};
    if(drag.touch){el.classList.add('dxdrag');try{el.setPointerCapture(e.pointerId);}catch(er){}}};
  const move=e=>{if(!drag||e.pointerId!==drag.id)return;drag.dx=e.clientX-drag.x;drag.dy=e.clientY-drag.y;if(!drag.touch)return;e.preventDefault();
    const base=drag.el.id==='toast'&&getComputedStyle(drag.el).transform!=='none'&&!isMob()?'translateX(-50%) ':'';
    const d=Math.hypot(drag.dx,drag.dy);drag.el.style.transform=base+'translate('+drag.dx+'px,'+drag.dy+'px)';drag.el.style.opacity=String(Math.max(.15,1-d/180));};
  const up=e=>{if(!drag||e.pointerId!==drag.id)return;const D=drag;drag=null;e.stopPropagation();const d=Math.hypot(D.dx,D.dy),v=d/Math.max(1,performance.now()-D.t);
    if(d<8){dxClose(D.el,'',false);return;}
    if(D.touch&&(d>40||v>.5)){const dir=Math.abs(D.dx)>Math.abs(D.dy)?(D.dx<0?'l':'r'):(D.dy<0?'u':'d');dxClose(D.el,dir,D.k==='radio'&&dir==='l');return;}
    D.el.classList.remove('dxdrag');D.el.style.transition='transform .22s cubic-bezier(.3,1.4,.5,1),opacity .2s';D.el.style.transform='';D.el.style.opacity='';setTimeout(()=>{D.el.style.transition='';},260);};
  for(const t of ['pointerdown'])document.addEventListener(t,down,true);
  document.addEventListener('pointermove',move,{capture:true,passive:false});document.addEventListener('pointerup',up,true);document.addEventListener('pointercancel',up,true);
  for(const t of ['mousedown','touchstart','click','contextmenu'])document.addEventListener(t,e=>{if(dxRoot(e.target)){e.stopPropagation();if(t!=='touchstart')e.preventDefault();}},{capture:true,passive:false});
  const hov=(k,on)=>{DX.hold[k]=on;if(k==='toast'){const el=document.getElementById('toast');if(!el||el.hidden)return;el.classList.toggle('hold',on);
      if(on){clearTimeout(toastTimer);TST.left=Math.max(0,TST.left-(performance.now()-TST.t0));}else{TST.left=Math.max(2000,TST.left);TST.t0=performance.now();clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastHide(),TST.left);}}
    if(k==='frag'){const el=document.getElementById('fragTxt');if(el)el.classList.toggle('hold',on);}};
  document.addEventListener('pointerover',e=>{if(e.pointerType!=='mouse')return;const c=dxRoot(e.target);if(!c)return;const el=c.id?c:c.closest('#fragTxt');const k=dxKind(el);if(!DX.hold[k])hov(k,true);});
  document.addEventListener('pointerout',e=>{if(e.pointerType!=='mouse')return;const c=dxRoot(e.target);if(!c)return;const to=e.relatedTarget&&dxRoot(e.relatedTarget);if(to===c)return;const el=c.id?c:c.closest('#fragTxt');hov(dxKind(el),false);});}
try{dxBtn(document.getElementById('toast'));dxBtn(radioEl());}catch(e){}

/* ===== 1.2.4 α: телефон и планшет ===== */
/* подписи мира не обрезаются краем экрана */
{const _wl=worldLabel;worldLabel=function(x,y,text,col){try{if(SC>0&&text){ctx.font='700 '+fpx(11)+'px "JetBrains Mono",monospace';const w=ctx.measureText(text).width/2,X=(x-CX)*SC;
  if(X+w*SC>0&&X-w*SC<CW){const pad=8/SC,L=CX+pad+w+stageL()/SC,R=CX+(CW-stageL())/SC-pad-w;if(L<R)x=clamp(x,L,R);}}}catch(e){}return _wl(x,y,text,col);};}
/* подпись стрелки у края на телефоне не ложится на кнопки, мини-карту, радио и тосты */
function hudRects(){const out=[];for(const k in TBR){const b=TBR[k];if(b&&b.r)out.push([b.x-b.r-4,b.y-b.r-4,b.x+b.r+4,b.y+b.r+4]);}
  for(const id of ['mini','radio','toast','btnPause','btnMap']){const el=document.getElementById(id);if(!el||el.hidden||!el.offsetParent&&id!=='radio')continue;const r=el.getBoundingClientRect();if(r.width>0)out.push([r.left-4,r.top-4,r.right+4,r.bottom+4]);}
  return out;}
{const _ea2=edgeArrow;edgeArrow=function(x,y,col,size,label){if(!isMob()||!label)return _ea2(x,y,col,size,label);
  const calls=[],ft=ctx.fillText,st=ctx.strokeText;ctx.fillText=function(t,a,b){calls.push(['f',t,a,b,this.fillStyle]);};ctx.strokeText=function(t,a,b){calls.push(['s',t,a,b,this.strokeStyle,this.lineWidth,this.lineJoin]);};
  const ownF=Object.prototype.hasOwnProperty.call(ctx,'fillText'),ownS=Object.prototype.hasOwnProperty.call(ctx,'strokeText'),ownT=Object.prototype.hasOwnProperty.call(ctx,'translate'),tr=ctx.translate;let A=null;ctx.translate=function(a,b){if(!A)A=[a,b];return tr.apply(this,arguments);};
  let r;try{r=_ea2(x,y,col,size,label);}finally{if(ownF)ctx.fillText=ft;else delete ctx.fillText;if(ownS)ctx.strokeText=st;else delete ctx.strokeText;if(ownT)ctx.translate=tr;else delete ctx.translate;}
  const F=calls.filter(c=>c[0]==='f').pop();if(!F)return r;const t0=F[1],a0=F[2],b0=F[3];ctx.font='700 12px "JetBrains Mono",monospace';const w=ctx.measureText(t0).width/2+4,h=9,rs=hudRects();const AR=A?[A[0]-size-3,A[1]-size-3,A[0]+size+3,A[1]+size+3]:null;/* сама стрелка — препятствие для отодвинутой подписи */
  const hit=(cx,cy)=>cx-w<SAFE.l+4||cx+w>CW-SAFE.r-4||cy+4>CH-SAFE.b||cy-h<SAFE.t+2||rs.some(q=>cx+w>q[0]&&cx-w<q[2]&&cy+3>q[1]&&cy-h<q[3])||!lab61Free(cx,cy,w,h);
  const hitA=(cx,cy)=>hit(cx,cy)||!!AR&&cx+w>AR[0]&&cx-w<AR[2]&&cy+3>AR[1]&&cy-h<AR[3];
  let best=null;if(!hit(a0,b0))best=[a0,b0];else for(const d of [16,-16,30,-30,44,-44,60,-60,80,-80,100,-100]){if(!hitA(a0,b0+d)){best=[a0,b0+d];break;}if(!hitA(a0+d*1.5,b0)){best=[a0+d*1.5,b0];break;}}
  if(!best)outer:for(const dy of [-16,-32,-48,16,-64,-80]){for(const dx of [40,-40,80,-80,120,-120,160,-160,200,-200]){if(!hitA(a0+dx,b0+dy)){best=[a0+dx,b0+dy];break outer;}}}
  if(!best)return r;/* места нет — подпись не рисуем, как и раньше: лучше без неё, чем поверх кнопки */
  const dx=best[0]-a0,dy=best[1]-b0,fs=ctx.fillStyle,ss=ctx.strokeStyle,lw=ctx.lineWidth,lj=ctx.lineJoin;
  for(const c of calls){if(c[0]==='s'){ctx.strokeStyle=c[4];ctx.lineWidth=c[5];ctx.lineJoin=c[6];st.call(ctx,c[1],c[2]+dx,c[3]+dy);}else{ctx.fillStyle=c[4];ft.call(ctx,c[1],c[2]+dx,c[3]+dy);}}
  ctx.fillStyle=fs;ctx.strokeStyle=ss;ctx.lineWidth=lw;ctx.lineJoin=lj;lab61Add(best[0],best[1],w,h);
  return r;};}
/* планшеты до 1200 px по короткой стороне — планшетная раскладка (iPad Pro 12,9″ больше не получает смесь ПК и тач-кнопок) */
{const _ff=ffUpdate;ffUpdate=function(){_ff();try{if(G.ff==='desk'){const vv=window.visualViewport,w=vv&&vv.width?vv.width:innerWidth,h=vv&&vv.height?vv.height:innerHeight,sm=Math.min(w,h);
  const dev=(MOBQ&&MOBQ.matches)||G.input==='touch';if(dev&&sm<=1200){G.ff='tablet';const c=document.documentElement.classList;for(const k of ['desk','phone-p','phone-l','tablet'])c.toggle('ff-'+k,k==='tablet');c.toggle('mob',true);c.toggle('lefty',SET.hand==='l');}}}catch(e){}};}
try{ffUpdate();resize();}catch(e){}
/* планшет: HUD и тач-кнопки крупнее пропорционально экрану (768 → 1, 1024 → 1,3) */
function tabK(){return G.ff==='tablet'?clamp(Math.min(CW,CH)/768,1,1.3):1;}
{const _uc=uiCalc;uiCalc=function(){return G.ff==='tablet'?Math.round(tabK()*20)/20:_uc();};}
{const _ua=uiApply;uiApply=function(){_ua();document.documentElement.classList.toggle('tabz',G.ff==='tablet'&&UI>1);};}
{const _jr=joyR;joyR=function(){return _jr()*tabK();};}
try{uiApply();layoutTouch();}catch(e){}

/* ===== 1.2.5 α: «Пустота-12» — живая подложка открытого мира в секторах I–II ===== */
const V12={name:'Пустота-12',seg:16,pre:.1,tail:.25,xf:.02,bpm:60,
  order:['intro0','intro1','loop0','loop1','loop2','loop3','loop4','loop5','loop6','loop7','loop8','loop9'],
  buf:{},dec:{},fail:0,ok:false,live:0,on:false,cur:null,nxt:null,pos:null,introDone:false,gain:.38,nodes:null,sec:-1,lastOff:0};
V12.next=n=>{const i=V12.order.indexOf(n);return n==='loop9'?'loop0':V12.order[i+1];};
V12.loopIdx=n=>n.startsWith('loop')?+n.slice(4):-1;
function v12Raw(n){const el=document.getElementById('v12-'+n);return el?el.textContent.trim():'';}
function v12Decode(n){if(V12.buf[n])return Promise.resolve(V12.buf[n]);if(V12.dec[n])return V12.dec[n];
  const b64=v12Raw(n);if(!b64||!AU.ctx)return Promise.reject(new Error('no '+n));
  const bin=atob(b64),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
  const p=new Promise((res,rej)=>{try{const r=AU.ctx.decodeAudioData(u.buffer,res,rej);if(r&&r.then)r.then(res,rej);}catch(e){rej(e);}})
    .then(b=>{V12.buf[n]=b;delete V12.dec[n];if(!V12.ok){V12.ok=true;v12Retune(true);}return b;})
    .catch(e=>{delete V12.dec[n];V12.fail++;throw e;});
  V12.dec[n]=p;return p;}
function v12Keep(){const keep=new Set([V12.cur&&V12.cur.n,V12.nxt&&V12.nxt.n,V12.cur&&V12.next(V12.cur.n)]);for(const k in V12.buf)if(!keep.has(k))delete V12.buf[k];}
function v12Nodes(){if(V12.nodes||!AU.ctx||!AU.musLP)return V12.nodes;const c=AU.ctx;
  const g=c.createGain();g.gain.value=0;const duck=c.createGain();duck.gain.value=1;const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=18000;f.Q.value=.5;
  const lo=c.createBiquadFilter();lo.type='lowshelf';lo.frequency.value=120;const hi=c.createBiquadFilter();hi.type='highshelf';hi.frequency.value=1800;
  const pk=c.createBiquadFilter();pk.type='peaking';pk.frequency.value=180;pk.Q.value=.8;const lc=c.createBiquadFilter();lc.type='lowshelf';lc.frequency.value=60;
  const bus=c.createGain();bus.gain.value=1;
  bus.connect(lo);lo.connect(hi);hi.connect(pk);pk.connect(lc);lc.connect(f);f.connect(duck);duck.connect(g);g.connect(AU.musLP);
  V12.nodes={g,duck,f,lo,hi,pk,lc,bus};return V12.nodes;}
/* хочет ли игра подложку прямо сейчас */
function v12Want(){const p=G.player;if(!SET.amb||!AU.ctx||V12.fail>3)return 0;
  if(!(G.mode==='world'&&G.world&&p&&!G.post&&['world','map','pause','codex'].includes(G.state)))return 0;
  const si=sectorIdx(p.x,p.y);if(si!==0&&si!==1)return 0;V12.sec=si;return 1;}
function v12Start(name,off){const c=AU.ctx,N=v12Nodes(),b=V12.buf[name];if(!N||!b)return false;const when=c.currentTime+.06;
  const s=c.createBufferSource();s.buffer=b;const sg=c.createGain();sg.gain.value=1;s.connect(sg);sg.connect(N.bus);
  s.start(when,V12.pre+off);V12.cur={n:name,src:s,g:sg,t0:when-off};return true;}
function v12Chain(){const c=AU.ctx,C=V12.cur,N=V12.nodes;if(!C)return;const now=c.currentTime,end=C.t0+V12.seg,nn=V12.next(C.n);
  if(!V12.nxt&&end-now<8&&!V12.buf[nn])v12Decode(nn).catch(()=>{});
  if(!V12.nxt&&end-now<2){const b=V12.buf[nn];
    if(b){const s=c.createBufferSource();s.buffer=b;const sg=c.createGain();sg.gain.setValueAtTime(0,end-V12.xf/2);sg.gain.linearRampToValueAtTime(1,end+V12.xf/2);
      s.connect(sg);sg.connect(N.bus);s.start(end-V12.xf/2,V12.pre-V12.xf/2);C.g.gain.setValueAtTime(1,end-V12.xf/2);C.g.gain.linearRampToValueAtTime(0,end+V12.xf/2);
      try{C.src.stop(end+V12.tail);}catch(e){}V12.nxt={n:nn,src:s,g:sg,t0:end};}
    else if(now>end-.05){/* кусок не успел — доиграть хвост и войти позже с сильной доли */try{C.g.gain.setTargetAtTime(0,end,.08);C.src.stop(end+V12.tail);}catch(e){}
      V12.pos={n:nn,off:0,t:performance.now()};V12.cur=null;v12Decode(nn).then(()=>{if(V12.on&&!V12.cur){v12Start(nn,0);}}).catch(()=>{});return;}}
  if(V12.nxt&&now>=V12.nxt.t0){if(V12.cur.n==='intro1')V12.introDone=true;V12.cur=V12.nxt;V12.nxt=null;v12Keep();}}
function v12Pos(){const C=V12.cur;if(!C||!AU.ctx)return null;const off=clamp(AU.ctx.currentTime-C.t0,0,V12.seg-.01);return {n:C.n,off,t:performance.now()};}
function v12Stop(fade){V12.gen=(V12.gen||0)+1;const c=AU.ctx,N=V12.nodes;if(!N)return;V12.pos=v12Pos()||V12.pos;const t=c.currentTime;
  {const v=N.g.gain.value,K=48,a=new Float32Array(K);for(let j=0;j<K;j++)a[j]=v*Math.cos(j/(K-1)*Math.PI/2);N.g.gain.cancelScheduledValues(t);N.g.gain.setValueAtTime(v,t);try{N.g.gain.setValueCurveAtTime(a,t+.005,Math.max(.05,fade));}catch(e){N.g.gain.linearRampToValueAtTime(0,t+fade);}}
  for(const X of [V12.cur,V12.nxt])if(X)try{X.src.stop(t+fade+.05);}catch(e){}V12.cur=V12.nxt=null;V12.lvl=0;}
/* куда входить: вступление один раз, потом петля; вернулся быстрее 90 с — с того же места */
function v12Entry(){const P=V12.pos;if(P&&performance.now()-P.t<90000){let n=P.n,off=Math.floor(P.off/4)*4;if(n.startsWith('intro')&&V12.introDone){n='loop0';off=0;}return {n,off};}
  if(!V12.introDone&&!V12.everIntro){V12.everIntro=1;return {n:'intro0',off:0};}return {n:V12.sec===1?'loop4':'loop0',off:0};}
/* уровни и окраска */
function v12Mix(dt){const N=V12.nodes,c=AU.ctx;if(!N)return;const t=c.currentTime,p=G.player,T=MUS.cur;
  const phone=G.ff==='phone';let db=0,lp=18000;
  const I=T&&T.I||0,zone=typeof zbOn==='function'&&zbOn(),anom=!!G.anom;
  if(zone||anom){db-=12;lp=700;}else if(I>.5){db-=5;lp=1800;}
  if(['map','codex'].includes(G.state)){db-=8;lp=Math.min(lp,900);}
  if(G.well&&G.well.depth>0){db-=6*G.well.depth;lp=Math.min(lp,500+17500*Math.pow(1-G.well.depth,2));}
  try{const r=radioEl();if(r&&!r.hidden)db-=2;}catch(e){}
  if(typeof CHS!=='undefined'&&CHS&&CHS.ph==='live'){db=Math.min(db,-5);lp=Math.min(lp,1800);}
  const lvl=V12.on?V12.gain*(phone?1.19:1)*Math.pow(10,db/20):0;
  if(Math.abs(lvl-(V12.lvl||0))>.002||V12.fadeIn){const tc=V12.fadeIn?1.3:(lvl<(V12.lvl||0)?.5:1.2);const G_=N.g.gain;G_.cancelScheduledValues(t);G_.setValueAtTime(G_.value,t);G_.setTargetAtTime(lvl,t,tc);V12.lvl=lvl;V12.fadeIn=0;}
  if(Math.abs(lp-(V12.lp||0))>30){N.f.frequency.setTargetAtTime(lp,t,lp<(V12.lp||18000)?.4:1.2);V12.lp=lp;}
  const s=V12.sec;const eq=s===1?[-1.5,2]:[1.5,-2];if(V12.eqSec!==s+(phone?10:0)){V12.eqSec=s+(phone?10:0);N.lo.gain.setTargetAtTime(eq[0],t,2);N.hi.gain.setTargetAtTime(eq[1],t,2);N.hi.frequency.setTargetAtTime(s===1?1500:2000,t,2);
    N.pk.gain.setTargetAtTime(phone?2:0,t,.5);N.lc.gain.setTargetAtTime(phone?-3:0,t,.5);}
  /* Разлом: лёгкая «плывучесть» */
  const rI=G.riftI||0,rate=rI>.5?1-.015*Math.min(1,(rI-.5)*2):1;if(Math.abs(rate-(V12.rate||1))>.001){V12.rate=rate;for(const X of [V12.cur,V12.nxt])if(X)X.src.playbackRate.setTargetAtTime(rate,t,.8);}
}
function v12Tick(dt){if(!AU.ctx||AU.ctx.state!=='running')return;const want=v12Want();
  if(want&&!V12.on){V12.on=true;V12.fadeIn=1;const gen=V12.gen=(V12.gen||0)+1;const E=v12Entry();v12Decode(E.n).then(()=>{if(V12.on&&!V12.cur&&gen===V12.gen){v12Nodes();v12Start(E.n,E.off);v12Retune(true);}}).catch(()=>{});}
  else if(!want&&V12.on){V12.on=false;V12.gen=(V12.gen||0)+1;v12Stop(SET.amb?3.5:.4);v12Retune(false);}
  if(V12.on&&V12.cur)v12Chain();
  V12.live=V12.on&&V12.cur?1:0;
  if(V12.nodes)v12Mix(dt);
  if(V12.live)MUS.lastName=V12.name;
}
/* такт и доля подложки для синхронных слоёв */
V12.beatAt=function(t){const C=V12.cur;if(!C)return null;const k=C.n.startsWith('loop')?V12.loopIdx(C.n)*16:(C.n==='intro1'?16:0);const pos=k+(t-C.t0)*(V12.rate||1);return {beat:Math.floor(pos),ph:pos-Math.floor(pos),bar0:C.t0-((k%4))};};
/* перенастройка процедурных пейзажей I–II в фа минор, пока звучит подложка */
V.v12=[[0,7,12,15],[-4,3,8,12],[3,10,15,19],[-2,5,10,14]];
const V12_KEEP={belt:{root:SC_.belt.root,v:SC_.belt.v,bpm:SC_.belt.bpm},drift:{root:SC_.drift.root,v:SC_.drift.v,bpm:SC_.drift.bpm}};
const PENTA0=PENTA.slice(),PENTA_F=[523.25,622.25,698.46,830.61,932.33];
function v12Retune(on){const B=SC_.belt,D=SC_.drift;
  if(on&&V12.ok){B.root=41;B.v=V.v12;B.bpm=120;D.root=44;D.v=V.v12.map(ch=>ch.map(x=>x-3));D.bpm=120;PENTA.splice(0,5,...PENTA_F);}
  else{Object.assign(B,V12_KEEP.belt);Object.assign(D,V12_KEEP.drift);if(V12_KEEP.belt.bpm===undefined)delete B.bpm;if(V12_KEEP.drift.bpm===undefined)delete D.bpm;PENTA.splice(0,5,...PENTA0);}
  try{const P=MUS.cur;if(P&&(P.id==='belt'||P.id==='drift')&&AU.ctx){setChord(P,AU.ctx.currentTime);}}catch(e){}}
{const _sl=scapeLayers;scapeLayers=function(P){_sl(P);if(V12.live&&(P.id==='belt'||P.id==='drift')){const t=AU.ctx.currentTime;P.L.pad.gain.setTargetAtTime(0,t,.8);P.L.sub.gain.setTargetAtTime(0,t,.8);P.L.noise.gain.setTargetAtTime(.6,t,.8);}};}
/* сетка секвенсора и колокольчики — по долям подложки */
{const _sr=scapeRun;scapeRun=function(P,now,ahead){if(V12.live&&(P.id==='belt'||P.id==='drift')){const B=V12.beatAt(now);if(B){const sd=60/(120+(P.ext.bpmAdd||0))/4,g0=now-B.ph*(1/(V12.rate||1));
    if(P.next>=now-.25){const k=Math.ceil((P.next-g0)/sd-1e-6),snap=g0+k*sd;if(Math.abs(snap-P.next)>.002){P.next=snap;P.step=((B.beat%4)*8+k)%32;}}
    if(P.nextBell<ahead){const q=g0+Math.ceil((Math.max(now,P.nextBell)-g0))*1;P.nextBell=q;}}}
  return _sr(P,now,ahead);};}
/* взрывы на мгновение прижимают подложку */
{const _sfx=sfx;sfx=function(n){const r=_sfx.apply(this,arguments);try{if(V12.live&&V12.nodes&&(n==='boom'||n==='bigboom')){const t=AU.ctx.currentTime,g=V12.nodes.duck.gain,d=n==='bigboom'?.5:.71;
  g.cancelScheduledValues(t);g.setTargetAtTime(d,t,.01);g.setTargetAtTime(1,t+.05,.15);}}catch(e){}return r;};}
{const _mt=musicTick;musicTick=function(dt){_mt(dt);try{v12Tick(dt);}catch(e){console.error(e);}};}

const MZ_DEF={"menu": {"segs": [["menu_i0", 12.801208], ["menu_i1", 12.801187], ["menu_i2", 12.801208], ["menu_i3", 12.801187], ["menu_i4", 12.801208], ["menu_l0", 15.299604], ["menu_l1", 15.299604], ["menu_l2", 15.299583], ["menu_l3", 15.299604], ["menu_l4", 15.299604]], "intro": 5, "loop": 5}, "m10": {"segs": [["m10_i0", 14.525], ["m10_i1", 14.525], ["m10_i2", 14.525], ["m10_i3", 14.525], ["m10_i4", 14.525], ["m10_l0", 14.062667], ["m10_l1", 14.062687], ["m10_l2", 14.062667], ["m10_l3", 14.062687], ["m10_l4", 14.062667], ["m10_l5", 14.062667], ["m10_l6", 14.062687], ["m10_l7", 14.062667]], "intro": 5, "loop": 8}, "s0": {"segs": [["s0_i0", 13.604604], ["s0_i1", 13.604604], ["s0_i2", 13.604583], ["s0_i3", 13.604604], ["s0_i4", 13.604604], ["s0_l0", 15.4045], ["s0_l1", 15.4045], ["s0_l2", 15.4045], ["s0_l3", 15.4045], ["s0_l4", 15.4045], ["s0_l5", 15.4045]], "intro": 5, "loop": 6}, "s10": {"segs": [["s10_i0", 13.65625], ["s10_i1", 13.65625], ["s10_i2", 13.65625], ["s10_i3", 13.65625], ["s10_l0", 14.256021], ["s10_l1", 14.256042], ["s10_l2", 14.256021], ["s10_l3", 14.256042], ["s10_l4", 14.256021], ["s10_l5", 14.256042], ["s10_l6", 14.256021]], "intro": 4, "loop": 7}};
/* ===== 1.2.6 α: записанная музыка меню, миссий 1–10 и боссов; общая пауза −90 % ===== */
/* MZ_DEF вставляется сборкой из au/seg2/manifest.json: {key:{segs:[[name,dur],…],intro:n,loop:n}} */
const MZ_TR={
  menu:{name:'Последний сигнал',gain:.47,root:39,penta:[554.37,622.25,739.99,830.61,932.33]},
  m10: {name:'Вахта',gain:.52,root:41,penta:[523.25,622.25,698.46,830.61,932.33]},
  s0:  {name:'Страж-0',gain:.55,root:41,penta:[523.25,622.25,698.46,830.61,932.33]},
  s10: {name:'Глушитель',gain:.58,root:36,penta:[523.25,622.25,698.46,783.99,932.33]}};
const MZ={pl:{},bus:null,lp:null,duck:null,want:null,prev:null,pre:.1,tail:.25,xf:.02,fail:0,bossDeadT:-99,lastBoss:false,menuIntro:false,anyLive:false};
for(const k in MZ_DEF)Object.assign(MZ_TR[k],MZ_DEF[k]);
function mzRaw(n){const el=document.getElementById('mz-'+n);return el?el.textContent.trim():'';}
function mzP(k){return MZ.pl[k]||(MZ.pl[k]={k,buf:{},dec:{},cur:null,nxt:null,pos:null,gen:0,on:false,fade:null,lvlG:null,fail:0,lvl:1});}
function mzNodes(){if(MZ.bus||!AU.ctx)return MZ.bus;const c=AU.ctx;
  MZ.bus=c.createGain();MZ.lp=c.createBiquadFilter();MZ.lp.type='lowpass';MZ.lp.frequency.value=18000;MZ.lp.Q.value=.5;MZ.duck=c.createGain();
  MZ.bus.connect(MZ.lp);MZ.lp.connect(MZ.duck);MZ.duck.connect(AU.amb);return MZ.bus;}
function mzPlayerNodes(P){if(P.fade)return;const c=AU.ctx;mzNodes();P.fade=c.createGain();P.fade.gain.value=0;P.lvlG=c.createGain();P.lvlG.gain.value=1;P.fade.connect(P.lvlG);P.lvlG.connect(MZ.bus);}
function mzDecode(P,i){const T=MZ_TR[P.k],n=T.segs[i][0];if(P.buf[i])return Promise.resolve(P.buf[i]);if(P.dec[i])return P.dec[i];
  const b64=mzRaw(n);if(!b64||!AU.ctx)return Promise.reject(new Error('no '+n));
  const bin=atob(b64),u=new Uint8Array(bin.length);for(let j=0;j<bin.length;j++)u[j]=bin.charCodeAt(j);
  const p=new Promise((res,rej)=>{try{const r=AU.ctx.decodeAudioData(u.buffer,res,rej);if(r&&r.then)r.then(res,rej);}catch(e){rej(e);}})
    .then(b=>{P.buf[i]=b;delete P.dec[i];return b;}).catch(e=>{delete P.dec[i];P.fail++;MZ.fail++;throw e;});
  P.dec[i]=p;return p;}
function mzNext(P,i){const T=MZ_TR[P.k];return i+1<T.segs.length?i+1:T.intro;}
function mzKeep(P){const keep=new Set();if(P.cur){keep.add(P.cur.i);keep.add(mzNext(P,P.cur.i));}if(P.nxt)keep.add(P.nxt.i);for(const k in P.buf)if(!keep.has(+k))delete P.buf[k];}
function mzStart(P,i,off){const c=AU.ctx,b=P.buf[i];if(!b)return false;mzPlayerNodes(P);const when=c.currentTime+.05;
  const s=c.createBufferSource();s.buffer=b;const g=c.createGain();s.connect(g);g.connect(P.fade);s.start(when,MZ.pre+off);P.cur={i,src:s,g,t0:when-off,d:MZ_TR[P.k].segs[i][1]};return true;}
function mzChain(P){const c=AU.ctx,C=P.cur;if(!C)return;const now=c.currentTime,end=C.t0+C.d,ni=mzNext(P,C.i);
  if(!P.nxt&&end-now<8&&!P.buf[ni])mzDecode(P,ni).catch(()=>{});
  if(!P.nxt&&end-now<2){const b=P.buf[ni];
    if(b){const s=c.createBufferSource();s.buffer=b;const g=c.createGain();g.gain.setValueAtTime(0,end-MZ.xf/2);g.gain.linearRampToValueAtTime(1,end+MZ.xf/2);s.connect(g);g.connect(P.fade);
      s.start(end-MZ.xf/2,MZ.pre-MZ.xf/2);C.g.gain.setValueAtTime(1,end-MZ.xf/2);C.g.gain.linearRampToValueAtTime(0,end+MZ.xf/2);try{C.src.stop(end+MZ.tail);}catch(e){}
      P.nxt={i:ni,src:s,g,t0:end,d:MZ_TR[P.k].segs[ni][1]};}
    else if(now>end-.05){try{C.g.gain.setTargetAtTime(0,end,.08);C.src.stop(end+MZ.tail);}catch(e){}P.cur=null;const gen=P.gen;
      mzDecode(P,ni).then(()=>{if(P.on&&!P.cur&&gen===P.gen)mzStart(P,ni,0);}).catch(()=>{});return;}}
  if(P.nxt&&now>=P.nxt.t0){P.cur=P.nxt;P.nxt=null;mzKeep(P);}}
/* плавные равномощные кривые: из текущего значения, без щелчков */
function mzCurve(param,to,dur){const c=AU.ctx,t=c.currentTime+.01,v=param.value,N=64,a=new Float32Array(N);
  for(let j=0;j<N;j++){const x=j/(N-1);a[j]=to>v?v+(to-v)*Math.sin(x*Math.PI/2):to+(v-to)*Math.cos(x*Math.PI/2);}
  param.cancelScheduledValues(t-.01);param.setValueAtTime(v,t-.005);try{param.setValueCurveAtTime(a,t,Math.max(.05,dur));}catch(e){param.setTargetAtTime(to,t,dur/3);}}
function mzOn(P,i,off,fi){P.on=true;const gen=++P.gen;mzDecode(P,i).then(()=>{if(!P.on||gen!==P.gen)return;if(!P.cur)mzStart(P,i,off);mzCurve(P.fade.gain,1,fi);}).catch(()=>{});}
function mzOff(P,fo){if(!P.on)return;P.on=false;P.gen++;const c=AU.ctx;const C=P.cur;
  if(C){P.pos={i:C.i,off:clamp(c.currentTime-C.t0,0,C.d-.01),t:performance.now()};}
  if(P.fade){mzCurve(P.fade.gain,0,fo);const stopAt=c.currentTime+fo+.1;for(const X of [P.cur,P.nxt])if(X)try{X.src.stop(stopAt);}catch(e){}}P.cur=P.nxt=null;}
/* что должно звучать */
function mzWant(){if(!SET.amb||!AU.ctx||MZ.fail>6)return null;const st=G.state;
  if(G.mode!=='endless'&&!G.world&&G.m>=1&&G.m<=10&&!G.post&&(G.mode==='world'||G.mode==='dev')&&['intro','play','levelup','pause','codex'].includes(st)){
    const bossOn=G.m===6&&G.boss&&G.boss.alive,jamOn=G.m===10&&G.jam&&G.jam.alive;
    if(st==='intro')MZ.lastBoss=false;
    if(bossOn||jamOn){MZ.lastBoss=G.m===6?'s0':'s10';MZ.since=0;}
    /* после гибели босса трек держится ещё 3 с — финальный удар не обрывается */
    if(MZ.lastBoss&&MZ.since<3&&MZ.lastBoss===(G.m===6?'s0':G.m===10?'s10':''))return MZ.lastBoss;
    return 'm10';}
  MZ.lastBoss=false;
  let id=null;try{id=musTarget().id;}catch(e){}
  if(id==='menu'&&!G.world&&!(G.m&&['play','levelup','intro'].includes(st)))return 'menu';
  return null;}
const MZ_FADE={'m10>s0':[2.5,2],'m10>s10':[2.5,2],'s0>m10':[4,4],'s10>m10':[4,4],'menu>m10':[2,3],'m10>menu':[2.5,3.5],'s0>menu':[2.5,3.5],'s10>menu':[2.5,3.5],'>menu':[0,3.5],'menu>':[3,0],'m10>':[3,0],'s0>':[3,0],'s10>':[3,0],'>m10':[0,3]};
function mzEntry(k){const P=mzP(k),T=MZ_TR[k],pos=P.pos;
  if(k==='menu'){if(pos&&performance.now()-pos.t<120000)return {i:pos.i,off:pos.off};if(!MZ.menuIntro){MZ.menuIntro=true;return {i:0,off:0};}return {i:T.intro,off:0};}
  if(k==='m10'&&MZ.prev&&MZ.prev[0]==='s'&&pos&&performance.now()-pos.t<60000)return {i:pos.i,off:pos.off};
  return {i:0,off:0};}
function mzTick(dt){if(!AU.ctx||AU.ctx.state!=='running')return;{const now=performance.now();if(G.state==='play'&&MZ.lastNow)MZ.since=(MZ.since||0)+Math.min(.25,(now-MZ.lastNow)/1000);MZ.lastNow=now;}let w=mzWant();
  /* конец миссии и гибель: музыка уходит плавно, стингеры звучат сами */
  const ending=w&&!G.world&&(G.state==='done'||G.state==='over');if(ending)w=null;
  if(w!==MZ.want){const from=MZ.want||'',to=w||'',f=MZ_FADE[from+'>'+to]||[3,3.5];
    if(from)mzOff(mzP(from),G.state==='over'?2.5:G.state==='done'?4:f[0]);
    if(to){const E=mzEntry(to);mzOn(mzP(to),E.i,E.off,f[1]);}
    MZ.prev=MZ.want;MZ.want=w;}
  let any=false;for(const k in MZ.pl){const P=MZ.pl[k];if(P.on&&P.cur)mzChain(P);if(P.on||P.cur||P.nxt)any=any||!!P.cur;}
  MZ.anyLive=!!(MZ.want&&mzP(MZ.want).cur);
  if(MZ.bus){const t=AU.ctx.currentTime;
    /* уровень по состоянию: брифинг −3 дБ, выбор улучшения −5 дБ и глуше */
    for(const k in MZ.pl){const P=MZ.pl[k];if(!P.lvlG)continue;let db=0;if(G.state==='intro')db=-3;else if(G.state==='levelup')db=-5;
      const g=MZ_TR[k].gain*(G.ff==='phone'?1.12:1)*Math.pow(10,db/20);if(Math.abs(g-P.lvl)>.002){P.lvl=g;P.lvlG.gain.setTargetAtTime(g,t,.6);}}
    let lp=AU.musLP?AU.musLP.frequency.value:18000;if(G.state==='levelup')lp=Math.min(lp,2600);if(G.state==='over')lp=Math.min(lp,350);
    if(Math.abs(lp-(MZ.lpv||0))>30){MZ.lpv=lp;MZ.lp.frequency.setTargetAtTime(lp,t,G.state==='over'?.8:.25);}
    const dk=AU.duckG?AU.duckG.gain.value:1;if(Math.abs(dk-(MZ.dk||1))>.01){MZ.dk=dk;MZ.duck.gain.setTargetAtTime(dk,t,.05);}}
  /* процедурная музыка молчит, пока звучит запись */
  if(AU.mus){const tg=MZ.anyLive?0:1;if(tg!==MZ.musT){MZ.musT=tg;AU.mus.gain.setTargetAtTime(tg,AU.ctx.currentTime,tg?1.0:.6);}}
  if(MZ.anyLive)MUS.lastName=MZ_TR[MZ.want].name;}
/* стингеры и звук убийства — в тональности звучащего трека */
{const _as=ambSting;ambSting=function(kind){const P=MUS.cur;if(MZ.anyLive&&P){const T=MZ_TR[MZ.want],s0=P.semi;let d=((T.root-P.sc.root)%12+12)%12;if(d>6)d-=12;P.semi=d;try{return _as(kind);}finally{P.semi=s0;}}return _as(kind);};}
function mzPenta(){const src=MZ.anyLive?MZ_TR[MZ.want].penta:(typeof V12!=='undefined'&&V12.live?PENTA_F:PENTA0);if(PENTA[0]!==src[0]||PENTA[1]!==src[1]||PENTA[2]!==src[2])PENTA.splice(0,5,...src);}
/* пауза: вся музыка плавно −90 % (≈ −20 дБ), обратно — быстрее */
function pauseMusTick(){if(!AU.ctx||!AU.amb)return;
  if(!AU.pauseG){try{const c=AU.ctx;AU.pauseG=c.createGain();AU.pauseG.gain.value=1;AU.pauseG.connect(c.destination);AU.amb.connect(AU.pauseG);AU.amb.disconnect(c.destination);}catch(e){}}const p=G.state==='pause',t=AU.ctx.currentTime;if(p!==MZ.paused){MZ.paused=p;const g=AU.pauseG.gain;g.cancelScheduledValues(t);g.setValueAtTime(g.value,t);g.setTargetAtTime(p?.1:1,t,p?.9:.3);}}
{const _mt2=musicTick;musicTick=function(dt){_mt2(dt);try{mzTick(dt);mzPenta();pauseMusTick();}catch(e){console.error(e);}};}

/* ===== 1.2.7 α «Первый вылет»: обучение внутри игры (секторы I–II) и надпись запрета прыжка =====
   Обучение только смотрит и подсказывает: ни одна игровая величина здесь не меняется. */

/* ---------- 1. Запрет прыжка: причина, надпись по центру карты, красные точки ---------- */
const JUMP_DENY={
  rift:{msg:'ПРЫЖОК НЕВОЗМОЖЕН · ПОМЕХИ РАЗЛОМА',l1:'ПОМЕХИ РАЗЛОМА',l2:'ПРЫЖОК НЕДОСТУПЕН',sub:'УЙДИТЕ ОТ РАЗЛОМА'},
  patrol:{msg:'ПРЫЖОК НЕВОЗМОЖЕН · РЯДОМ ВРАГИ',l1:'ВО ВРЕМЯ ПАТРУЛЯ',l2:'ПЕРЕМЕЩЕНИЕ НЕДОСТУПНО',sub:'РАЗБЕЙТЕ ПАТРУЛЬ ИЛИ УЙДИТЕ ДАЛЬШЕ'},
  enemies:{msg:'ПРЫЖОК НЕВОЗМОЖЕН · РЯДОМ ВРАГИ',l1:'РЯДОМ ВРАГИ',l2:'ПРЫЖОК НЕДОСТУПЕН',sub:'ОТОЙДИТЕ ИЛИ ЗАЧИСТИТЕ РАЙОН'},
  anom:{msg:'ПРЫЖОК НЕВОЗМОЖЕН · ИДЁТ АНОМАЛИЯ',l1:'ИДЁТ АНОМАЛИЯ',l2:'ПРЫЖОК НЕДОСТУПЕН',sub:'ДОЖДИТЕСЬ ЕЁ КОНЦА'},
  zero:{msg:'ПРЫЖОК НЕВОЗМОЖЕН · ВОРОТА НУЛЕВОЙ ТОЧКИ',l1:'ВОРОТА НУЛЕВОЙ ТОЧКИ',l2:'ПРЫЖОК НЕДОСТУПЕН',sub:''},
  zb:{msg:'ПРЫЖОК НЕВОЗМОЖЕН · ТОЧКА НЕВОЗВРАТА',l1:'ТОЧКА НЕВОЗВРАТА',l2:'ПРЫЖОК НЕДОСТУПЕН',sub:''}};
/* те же проверки и в том же порядке, что были в mapJumpAt; best=null — общий запрет без привязки к точке */
function jumpDenyReason(best){const p=G.player;if(!p)return null;
  if(!ALPHA_OPEN/* ВРЕМЕННО (альфа 0.5.9): в альфе прыжок из Разлома разрешён */&&(G.riftI||0)>=.2)return 'rift';
  if(!ALPHA_OPEN/* ВРЕМЕННО (альфа 0.5.9): в альфе прыжок рядом с врагами разрешён */&&G.enemies.some(o=>o.alive&&o.type!=='mine'&&o.type!=='lock'&&Math.hypot(o.x-p.x,o.y-p.y)<900))
    return (G.event==='zone'||G.enemies.some(o=>o.alive&&o.zone&&Math.hypot(o.x-p.x,o.y-p.y)<900))?'patrol':'enemies';
  if(G.anom)return 'anom';
  if(best&&zeroJumpDeny110(best))return 'zero';
  if(zbOn())return 'zb';
  return null;}
let mapDenyT=0;
function mapDenyFit(el){const L=el.querySelectorAll('.md-l');if(!L.length)return;el.style.removeProperty('--md-fs');
  const box=el.clientWidth||1;let fs=parseFloat(getComputedStyle(L[0]).fontSize)||22;
  for(let i=0;i<24;i++){let over=false;L.forEach(l=>{if(l.scrollWidth>l.clientWidth+1||l.scrollWidth>box*.92)over=true;});if(!over)break;fs-=1;el.style.setProperty('--md-fs',fs+'px');if(fs<=15)break;}}
function mapDenyShow(r,soft){const D=JUMP_DENY[r];if(!D)return;const box=document.querySelector('#sMap .mapbox');if(!box)return;
  let el=$('#mapDeny');if(!el){el=document.createElement('div');el.id='mapDeny';el.setAttribute('role','alert');box.appendChild(el);}
  const key=r+'|'+(soft?1:0);if(el.dataset.k!==key){el.dataset.k=key;
    el.innerHTML=`<div class="md-band"><span class="md-l">${D.l1}</span><span class="md-l">${D.l2}</span><span class="md-s">${D.sub}</span></div>`;
    el.setAttribute('aria-label',D.l1+' — '+D.l2.toLowerCase()+(D.sub?'. '+D.sub.toLowerCase():''));}
  el.classList.remove('on');void el.offsetWidth;el.classList.toggle('soft',!!soft);el.classList.add('on');mapDenyFit(el);
  clearTimeout(mapDenyT);mapDenyT=setTimeout(()=>{el.classList.remove('on');},soft?1400:1960);}
function mapDenyHide(){const el=$('#mapDeny');if(el){clearTimeout(mapDenyT);el.classList.remove('on');}}
/* цвет колец точек прыжка: белые, при запрете — тускло-красные (переход 300 мс) */
function mapJpCol(hv){const k=clamp(G.mapBlkK||0,0,1),r=255,g=Math.round(255-176*k),b=Math.round(255-145*k),a=hv?.9-.15*k:.3+.08*k;return `rgba(${r},${g},${b},${a.toFixed(3)})`;}
{const _dm=drawMap;drawMap=function(){const now=performance.now();
  if(G.state==='map'&&(!G.mapBlkAt||now-G.mapBlkAt>250)){G.mapBlkAt=now;const r=jumpDenyReason(null);G.mapBlk=r;}
  const dt=Math.min(.1,(now-(G.mapBlkLast||now))/1000);G.mapBlkLast=now;const tgt=G.mapBlk?1:0;G.mapBlkK=(G.mapBlkK||0)+clamp(tgt-(G.mapBlkK||0),-dt/.3,dt/.3);
  const r=_dm.apply(this,arguments);try{tutMapDraw(now);}catch(e){console.error(e);}return r;};}
{const _om=openMap;openMap=function(){const was=G.state;const r=_om.apply(this,arguments);if(was!=='map'&&G.state==='map'){G.mapBlkAt=0;G.mapBlk=jumpDenyReason(null);G.mapBlkK=G.mapBlk?1:0;mapDenyHide();
    if(G.mapBlk&&G.mapBlk!=='zero')setTimeout(()=>{if(G.state==='map')mapDenyShow(G.mapBlk,true);},120);tutEmit('map');}return r;};}
{const _cm=closeMap;closeMap=function(){const was=G.state==='map';const r=_cm.apply(this,arguments);if(was&&G.state!=='map'){mapDenyHide();tutEmit('mapClose');}return r;};}

/* ---------- 2. Обучение ---------- */
const TUT_KEYS_ALL=['calib','move','lom','stash','act','fire','dash','energy','pulse','cell','line','map','jump','patrol'];
const TUT={cur:null,hideAt:-1e9,gap:0,hist:[],last:0,mv:0,lpx:null,lpy:null,worldT:0,calmT:0,kills:null,carry:null,lom:null,lomAt:0,patrolEv:null,jumpPt:null,el:null,chip:null,rings:[],chk:0,fx:{}};
function tutClean(t,cleared){
  if(!t||typeof t!=='object'||Array.isArray(t))return cleared>=1?{v:1,off:1,vet:1,done:{},seen:{}}:{v:1,done:{},seen:{}};
  const o={v:1,done:{},seen:{}};if(t.off)o.off=1;if(t.vet)o.vet=1;
  for(const k of TUT_KEYS_ALL){if(t.done&&t.done[k])o.done[k]=1;const n=t.seen?+t.seen[k]:0;if(n>0&&Number.isFinite(n))o.seen[k]=Math.min(3,Math.round(n));if(t.ok&&t.ok[k]){(o.ok||(o.ok={}))[k]=1;}}
  return o;}
{const _ms=migrateSave;migrateSave=function(S){const had=!!(S&&typeof S==='object'&&S.tut&&typeof S.tut==='object'&&!Array.isArray(S.tut));
  const r=_ms.apply(this,arguments);if(r)r.tut=tutClean(had?r.tut:null,+r.cleared||0);return r;};}
/* облако: пройденный где-то урок пройден везде */
{const _ca=cloudApply;cloudApply=function(body){let loc=null;try{const v=store('void_world');loc=v&&v.tut;}catch(e){}
  const r=_ca.apply(this,arguments);
  try{const S=G.save;if(S&&loc&&typeof loc==='object'){const c=tutClean(loc,0),T=S.tut||(S.tut={v:1,done:{},seen:{}});T.done=T.done||{};T.seen=T.seen||{};
    for(const k in c.done)T.done[k]=1;if(c.off)T.off=1;store(saveKey(),S);}}catch(e){}
  return r;};}
function tutT(){const S=G.save;if(!S)return null;if(!S.tut||typeof S.tut!=='object')S.tut=tutClean(null,+S.cleared||0);const T=S.tut;if(!T.done)T.done={};if(!T.seen)T.seen={};return T;}
function tutSave(){const S=G.save;if(!S)return;try{if(G.world&&G.player)saveWorld();else store(saveKey(),S);}catch(e){}}
function tutOn(){const S=G.save;if(!S||!S.tut||S.tut.off)return false;
  if(G.mode!=='world'||G.devRun||G.fromAbyss||(window.DEVW&&DEVW.on&&DEVW.on()))return false;return true;}
function tutInput(){return G.input==='pad'?'pad':touchMode?'touch':'kbm';}
function tutDoneQ(k){const T=tutT();return !!(T&&T.done[k]);}
function tutDone(k,how){const T=tutT();if(!T||T.done[k])return;if(!tutOn()&&how!=='skip')return;T.done[k]=1;
  if(TUT.cur&&TUT.cur.k===k)tutEnd(how==='skip'?'skip':'ok');tutSave();}
/* события игры → уроки (только чтение) */
function tutEmit(ev,a){if(!G.save)return;
  if(ev==='dash')tutDone('dash');else if(ev==='pulse')tutDone('pulse');else if(ev==='act')tutDone('act');else if(ev==='map')tutDone('map');
  else if(ev==='jump')tutDone('jump');else if(ev==='cell')tutDone('cell');else if(ev==='line')tutDone('line');
  else if(ev==='patrolBroken')tutDone('patrol');
  else if(ev==='patrol'){if(!TUT.patrolEv||performance.now()-TUT.patrolEv.t>20000)TUT.patrolEv={x:a&&a.x,y:a&&a.y,t:performance.now()};}
  else if(ev==='mapClose'){const C=TUT.cur;if(C&&C.k==='jump')tutEnd('miss');}}
{const _td=tryDash;tryDash=function(){const p=G.player,cd=p?p.dashCd:0,dt=p?p.dashT:0;const r=_td.apply(this,arguments);
  if(p&&G.player===p&&(p.dashCd>cd||p.dashT>dt))tutEmit('dash');return r;};}
{const _tp=tryPulse;tryPulse=function(){const p=G.player,en=p?p.en:0;const r=_tp.apply(this,arguments);if(p&&en>=100&&p.en<en)tutEmit('pulse');return r;};}
{const _ca2=cardAct;cardAct=function(){const had=!!G.card&&G.state==='world';const r=_ca2.apply(this,arguments);if(had)tutEmit('act');return r;};}
{const _bn=banner;banner=function(b){if(b==='ПРЫЖОК')tutEmit('jump');return _bn.apply(this,arguments);};}
{const _fl=floater;floater=function(x,y,text){if(typeof text==='string'){
    if(text==='+ЗАРЯД')tutEmit('cell');else if(text==='ЛИНИЯ ВОССТАНОВЛЕНА')tutEmit('line');
    else if(/^ПАТРУЛЬ РАЗБИТ/.test(text))tutEmit('patrolBroken');else if(/^(ПАТРУЛЬ( ·|$)|ЗАСЛОН ГВАРДИИ)/.test(text))tutEmit('patrol',{x,y});}
  return _fl.apply(this,arguments);};}
/* новичку текстовая справка о секторе больше не нужна — её показывает обучение */
{const _to=toast;toast=function(title){if(title==='ОТКРЫТЫЙ СЕКТОР'&&G.save&&G.save.tut&&!G.save.tut.off&&!G.save.tut.vet)return;return _to.apply(this,arguments);};}
/* старая подсказка 0.6.0 заменена */
tutTick=function(){};

/* ---------- вспомогательное ---------- */
function tutSP(x,y){const Z=G.world?(G.wz95||1):1;return [SC*(Z*(x-CX)+W/2*(1-Z)),SC*(Z*(y-CY)+H/2*(1-Z))];}
function tutHostile(e){return e&&e.alive&&!(e.spawnT>0)&&!e.ghost&&e.type!=='mine'&&e.type!=='lock'&&e.type!=='rangedummy'&&!e.peace&&!(EDEF[e.type]&&EDEF[e.type].passive);}
function tutNearFoes(R){const p=G.player;if(!p)return 0;let n=0;for(const e of G.enemies)if(tutHostile(e)&&Math.hypot(e.x-p.x,e.y-p.y)<R)n++;return n;}
function tutCalm(){const p=G.player;if(!p||p.hp<=0)return false;if(p.hp<(G.st&&G.st.maxHp||100)*.35)return false;
  if(G.boss||G.jam||G.sb||G.anom||G.prologue||banT>0)return false;if(G.radio&&G.radio.cur)return false;
  if(tutNearFoes(600))return false;const t=$('#toast');if(t&&!t.hidden)return false;return true;}
function tutVis(el){if(!el||el.hidden)return false;const r=el.getBoundingClientRect();if(r.width<2||r.height<2)return false;const cs=getComputedStyle(el);return cs.display!=='none'&&cs.visibility!=='hidden'&&+cs.opacity>.05;}
function tutCardBtn(){const W_=$('#wcard');if(!W_||W_.hidden)return null;const b=W_.querySelector('[data-act]:not([disabled])');return b&&tutVis(b)?b:null;}
function tutShopPt(){const p=G.player;let best=null,bd=1e12,bestR=null,bdR=1e12;
  for(const s of WORLD.shops){const d=Math.hypot(s.x-p.x,s.y-p.y);if(sectorIdx(s.x,s.y)>1)continue;if(revealedAt(s.x,s.y)&&d<bdR){bdR=d;bestR=s;}if(d<bd){bd=d;best=s;}}
  return bestR||best;}
function tutKeyHTML(a){const I=tutInput();
  const kb=s=>`<kbd>${s}</kbd>`,pd=s=>`<kbd class="pad">${s}</kbd>`;
  const mouse='<svg class="tut-mouse" viewBox="0 0 14 20" aria-hidden="true"><rect x="1" y="1" width="12" height="18" rx="6" fill="none" stroke="#8fe9ff" stroke-width="1.2"/><path d="M7 1v7M1.4 8h11.2" stroke="#8fe9ff" stroke-width="1"/><path d="M7 1.2a5.8 5.8 0 0 0-5.6 5.8V8H7z" fill="#8fe9ff" opacity=".85"/></svg>';
  if(I==='pad')return {move:'<kbd>Л. СТИК</kbd>',dash:pd('A'),pulse:pd('X'),act:pd('B'),map:pd('Y'),jump:'',fire:''}[a]||'';
  if(I==='touch')return '';
  return {move:'<span class="tut-wasd"><kbd data-kk="KeyW">W</kbd><kbd data-kk="KeyA">A</kbd><kbd data-kk="KeyS">S</kbd><kbd data-kk="KeyD">D</kbd></span>',
    dash:kb('ПРОБЕЛ'),pulse:kb('E'),act:kb('F'),map:kb('M'),jump:mouse,fire:SET.manual?mouse:''}[a]||'';}

/* ---------- уроки ---------- */
/* ctx: где живёт урок; fight: можно показывать в бою; dur: сколько держится; info: закрывается показом */
const TUT_L={
  move:{ctx:'world',dur:10,
    when(){return TUT.worldT>1.5&&!G.prologue;},
    view(){const I=tutInput();return {keys:tutKeyHTML('move'),text:'ЛЕТИ',at:I==='touch'?'stick':'ship'};}},
  lom:{ctx:'world',dur:4.6,info:true,
    when(){return (G.save.carry||0)>0;},
    view(){return {keys:'',text:'<i></i>СКЛАД <span class="sep">·</span> <i class="a"></i>С СОБОЙ',at:'el',el:$('#wLom'),ring:[$('#wLom')],ringCls:'amber sq'};}},
  stash:{ctx:'world',dur:45,
    when(){const S=G.save;if(!tutDoneQ('lom')||!(S.carry>0))return false;return S.carry>=25||performance.now()-TUT.lomAt>90000;},
    view(){const s=tutShopPt(),p=G.player;return {keys:'',text:'<i class="a"></i>ЛОМ <b>НА СКЛАД</b>',at:'ship',draw:'stash',avoid:s?Math.atan2(s.y-p.y,s.x-p.x):undefined};}},
  act:{ctx:'world',dur:10,
    when(){return !!tutCardBtn();},
    view(){const I=tutInput(),b=tutCardBtn();const lab=b?(b.textContent||'').trim().split(/\s+/)[0]:'ОТКРЫТЬ';
      if(I==='touch'){const ta=$('#tAct');if(tutVis(ta))return {keys:'',text:'НАЖМИ',at:'el',el:ta,ring:[ta]};return {keys:'',text:'НАЖМИ',at:'el',el:b,ring:[b],ringCls:'sq'};}
      return {keys:tutKeyHTML('act'),text:lab,at:'el',el:$('#wcard'),ring:[b],ringCls:'sq',side:'up'};}},
  fire:{ctx:'any',dur:6,fight:true,info:true,
    when(){return tutNearFoes(600)>0;},
    view(){const man=SET.manual&&tutInput()==='kbm';return {keys:man?tutKeyHTML('fire'):'',text:man?'ОГОНЬ':'ОГОНЬ <b>САМ</b>',at:'ship',draw:'fire'};}},
  dash:{ctx:'any',dur:6,fight:true,minShow:3.5,
    when(){const p=G.player;if(p.dashCd>0||dashBlocked())return false;return tutThreat();},
    view(){const I=tutInput();if(I==='touch'){const d=$('#tDash');return {keys:'',text:'УВОРОТ',at:'el',el:d,ring:[d],draw:'dash'};}
      return {keys:tutKeyHTML('dash'),text:'УВОРОТ',at:'ship',draw:'dash'};}},
  pulse:{ctx:'any',dur:7,fight:true,
    when(){const p=G.player;return p.en>=100&&tutNearFoes((G.st.pR||150)*1.1)>=2;},
    view(){const I=tutInput();if(I==='touch'){const d=$('#tPulse');return {keys:'',text:'УДАР ВОКРУГ',at:'el',el:d,ring:[d],ringCls:'amber',draw:'pulse'};}
      return {keys:tutKeyHTML('pulse'),text:'УДАР <b>ВОКРУГ</b>',at:'ship',draw:'pulse'};}},
  cell:{ctx:'mission',dur:25,fight:true,
    when(){const p=G.player;if(!G.bc||G.bc.done)return false;if(p.cargo>0)return true;return !!tutCell();},
    view(){const p=G.player,q=p.cargo>0?G.bc:tutCell(),av=q?Math.atan2(q.y-p.y,q.x-p.x):undefined;return p.cargo>0?{keys:'',text:'<i class="a"></i>СДАЙ <b>В КОЛЬЦО</b>',at:'ship',draw:'ring',avoid:av}:{keys:'',text:'<i class="a"></i>СОБЕРИ <b>ЯЧЕЙКУ</b>',at:'ship',draw:'cell',avoid:av};}},
  line:{ctx:'mission',dur:25,fight:true,
    when(){return !!tutRelay();},
    view(){return {keys:'',text:'ДЕРЖИСЬ <b>НА ЛИНИИ</b>',at:'line',draw:'line'};}},
  map:{ctx:'world',dur:10,
    when(){const S=G.save,p=G.player;if((S.cleared||0)<1||TUT.worldT<30||jumpDenyReason(null))return false;return jumpPoints().some(q=>Math.hypot(q.x-p.x,q.y-p.y)>1500);},
    view(){const I=tutInput();if(I==='touch'){const ta=$('#tAct');if(tutVis(ta)&&ta.dataset.act==='map')return {keys:'',text:'КАРТА',at:'el',el:ta,ring:[ta]};const mi=$('#mini');return {keys:'',text:'КАРТА',at:'el',el:mi,ring:[mi]};}
      const bm=$('#btnMap');if(I==='kbm'&&tutVis(bm))return {keys:tutKeyHTML('map'),text:'КАРТА',at:'el',el:bm,ring:[bm],ringCls:'sq'};
      return {keys:tutKeyHTML('map'),text:'КАРТА',at:'ship'};}},
  jump:{ctx:'map',dur:0,
    when(){if(tutInput()==='pad'||G.mapTab!=='map'||!G.mapPts||!G.mapPts.length)return false;if(jumpDenyReason(null))return false;return !!tutJumpPick();},
    view(){const tip=$('#mapTip'),b=tip&&!tip.hidden?tip.querySelector('[data-mjump]'):null;
      if(b&&tutVis(b))return {keys:'',text:'',at:'none',ring:[b],ringCls:'sq amber'};return {at:'none'};}},
  patrol:{ctx:'world',dur:7,fight:true,info:true,
    when(){const E=TUT.patrolEv;return !!E&&performance.now()-E.t<6000&&(!!tutZone()||G.enemies.some(e=>e.alive&&e.zone));},
    view(){const z=tutZone(),p=G.player;return {keys:'',text:'<b>ПАТРУЛЬ</b> <span class="sep">·</span> РАЗБЕЙ ИЛИ УЛЕТИ',at:'ship',draw:'patrol',hostile:true,avoid:z?Math.atan2(p.y-z.y,p.x-z.x):undefined};}}};
function tutZone(){const p=G.player;let best=null,bd=1e12;for(const z of (G.zones||[]).concat(typeof W58!=='undefined'&&W58.zones||[])){if(!z||!z.active)continue;const d=Math.hypot(z.x-p.x,z.y-p.y);if(d<bd){bd=d;best=z;}}return best;}
const TUT_PRI=['patrol','dash','pulse','fire','cell','line','calib','move','act','energy','lom','stash','map','jump'];
/* угроза для рывка: снаряд дойдёт меньше чем за 0,6 с или таран вплотную */
function tutThreat(){const p=G.player;
  for(const b of G.eb||[]){const dx=p.x-b.x,dy=p.y-b.y,v=Math.hypot(b.vx||0,b.vy||0);if(v<40)continue;const d=Math.hypot(dx,dy);if(d>520)continue;
    const along=(dx*(b.vx||0)+dy*(b.vy||0))/v;if(along<=0)continue;const tti=along/v;if(tti>.6||tti<.06)continue;
    const miss=Math.abs(dx*(b.vy||0)-dy*(b.vx||0))/v;if(miss<(p.r||13)+(b.r||4)+14){TUT.threat={x:b.x,y:b.y,vx:b.vx,vy:b.vy};return true;}}
  for(const e of G.enemies){if(!tutHostile(e))continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(d>(e.r||14)+(p.r||13)+70)continue;const cl=((e.vx||0)*(p.x-e.x)+(e.vy||0)*(p.y-e.y))/(d||1);
    if(cl>60){TUT.threat={x:e.x,y:e.y,vx:e.vx,vy:e.vy};return true;}}
  return false;}
function tutCell(){const p=G.player;let best=null,bd=1e9;for(const k of G.pick||[]){if(k.k!=='cell'||k.stab>0)continue;const d=Math.hypot(k.x-p.x,k.y-p.y);if(d<bd){bd=d;best=k;}}return best;}
function tutRelay(){const p=G.player;if(!G.bc||!G.relays)return null;let best=null,bd=1e9;for(const r of G.relays){if(!r.cut)continue;const d=segDist(r.x,r.y,G.bc.x,G.bc.y,p.x,p.y);if(d<bd){bd=d;best=r;}}return best;}
function tutJumpPick(){const p=G.player,P=G.mapPts||[];if(!p||!P.length)return null;
  if(TUT.jumpPt){const q=P.find(z=>z.label===TUT.jumpPt);if(q)return q;}
  const far=P.filter(q=>Math.hypot(q.x-p.x,q.y-p.y)>800);if(!far.length)return null;
  const sh=far.filter(q=>q.label==='М').sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y));
  const q=sh[0]||far.slice().sort((a,b)=>Math.hypot(b.x-p.x,b.y-p.y)-Math.hypot(a.x-p.x,a.y-p.y))[0];return q;}
function tutCtxOk(c){const st=G.state;
  if(c==='world')return st==='world'&&G.world&&!!G.player&&!G.prologue;
  if(c==='mission')return st==='play'&&!G.world&&G.m>=1&&G.m<=10&&!!G.player;
  if(c==='map')return st==='map';
  if(c==='any')return ((st==='world'&&G.world&&!G.prologue)||(st==='play'&&!G.world&&G.m>=1&&G.m<=10))&&!!G.player;
  return false;}

/* ---------- режиссёр ---------- */
function tutStart(k){const L=TUT_L[k];TUT.cur={k,L,t:0,shown:0,step:null};TUT.hist.push(performance.now());(TUT.log||(TUT.log=[])).push(k);if(TUT.log.length>64)TUT.log.shift();if(k==='jump')TUT.jumpPt=null;
  if(k==='jump'){const q=tutJumpPick();if(q){TUT.jumpPt=q.label;const M=G.mapXY,V_=G.mapView;if(M&&V_&&(q.px<48||q.px>M.w-48||q.py<48||q.py>M.h-48)){V_.cx=q.x;V_.cy=q.y-150;V_.vx=V_.vy=0;}}}}
function tutEnd(how){const C=TUT.cur;if(!C)return;TUT.cur=null;const T=tutT();
  if(how==='ok'){if(T&&!T.done[C.k]){T.done[C.k]=1;tutSave();}if(!C.L.info)tutFxOk(C.k);TUT.gap=C.k==='map'?.4:4;}
  else if(how==='abort'){TUT.gap=1.5;}
  else{TUT.gap=4;if(T&&how!=='skip'){if(C.L.info){T.done[C.k]=1;}else if(C.t>1){T.seen[C.k]=(T.seen[C.k]||0)+1;if(T.seen[C.k]>=3)T.done[C.k]=1;}tutSave();}}
  if(C.k==='lom'&&how!=='abort')TUT.lomAt=performance.now();
  tutDomHide(how==='ok'?'ok':'out');}
function tutTick2(dt,now){
  const S=G.save;if(!S||!S.tut)return;const T=tutT();
  /* обучение кончается вместе с секторами I–II */
  if(!T.off&&G.mode==='world'&&((S.cleared||0)>=10||(G.world&&G.player&&sectorIdx(G.player.x,G.player.y)>=2))){T.off=1;tutEnd('abort');tutSave();}
  if(!tutOn()){if(TUT.cur)tutEnd('abort');tutDomHide('out');return;}
  const p=G.player;
  /* наблюдения: путь, лом, убийства */
  if(G.state==='world'&&G.world&&p&&!G.prologue){TUT.worldT+=dt;if(TUT.lpx!==null){const d=Math.hypot(p.x-TUT.lpx,p.y-TUT.lpy);if(d<60)TUT.mv+=d;}TUT.lpx=p.x;TUT.lpy=p.y;
    if(TUT.mv>=250)tutDone('move');}
  else{TUT.lpx=null;if(G.state!=='map'&&G.state!=='world')TUT.worldT=G.state==='play'?0:TUT.worldT;}
  if(TUT.carry!==null&&TUT.carry>0&&(S.carry||0)===0&&(S.lom||0)>=TUT.lom+TUT.carry-1&&(G.state==='world'||G.state==='shop')){tutFly(TUT.carry);tutDone('stash');}
  TUT.carry=S.carry||0;TUT.lom=S.lom||0;
  if(TUT.kills===null||G.kills<TUT.kills)TUT.kills=G.kills;if(G.kills>TUT.kills){TUT.kills=G.kills;tutDone('fire');}
  if(G.state==='levelup'||G.state==='pause'||G.state==='settings'){if(TUT.cur)tutDomHide('out');return;}
  if(TUT.gap>0)TUT.gap-=dt;
  /* текущий урок */
  const C=TUT.cur;
  if(C){if(T.done[C.k]){tutEnd('ok');return;}
    if(!tutCtxOk(C.L.ctx)){tutEnd(C.k==='jump'?'miss':'abort');return;}
    if(!C.L.fight&&!tutCalm()&&C.L.ctx!=='map'){tutEnd('abort');return;}
    /* склад уступает карточке объекта, карта — ничему */
    if(C.k==='stash'&&!tutDoneQ('act')&&TUT_L.act.when()&&tutCalm()){tutEnd('abort');tutStart('act');tutDraw(now);return;}
    C.t+=dt;if(C.L.step){C.L.step(dt,now);if(TUT.cur!==C)return;}
    const keep=C.L.minShow&&C.t<C.L.minShow;
    if(!keep&&C.L.dur&&C.t>C.L.dur){tutEnd(C.L.info?'ok':'miss');return;}
    if(C.k==='patrol'&&TUT.patrolEv&&C.t>1&&!G.zones.some(z=>z.active)&&!G.enemies.some(e=>e.alive&&e.zone)){tutEnd('ok');T.done.patrol=1;tutSave();return;}
    if(!keep&&!C.L.fight&&C.L.ctx!=='map'&&!C.L.info&&C.k!=='stash'&&C.k!=='move'&&C.k!=='calib'&&!C.L.when())C.idle=(C.idle||0)+dt;else C.idle=0;
    if(C.idle>1.2){tutEnd(C.t>3?'miss':'abort');return;}
    tutDraw(now);return;}
  /* выбор следующего */
  if(TUT.gap>0)return;
  if((TUT.chk+=dt)<.1)return;TUT.chk=0;
  const t0=performance.now();TUT.hist=TUT.hist.filter(h=>t0-h<600000);if(TUT.hist.length>=6)return;
  const calm=tutCalm();
  for(const k of TUT_PRI){if(T.done[k])continue;const L=TUT_L[k];if(!tutCtxOk(L.ctx))continue;if(!L.fight&&L.ctx!=='map'&&!calm)continue;
    if(k==='dash'||k==='pulse'||k==='fire'||k==='patrol'){}else if(k!=='move'&&k!=='jump'&&k!=='calib'&&!tutDoneQ('move')&&G.world)continue;
    if(k==='move'&&TUT_L.calib&&!T.done.calib&&TUT_L.calib.when())continue;
    let ok=false;try{ok=L.when();}catch(e){ok=false;}
    if(ok){tutStart(k);tutDraw(now);return;}}
}

/* ---------- отрисовка: DOM (подпись, кольца) ---------- */
function tutDom(){if(TUT.el)return TUT.el;const el=document.createElement('div');el.id='tut';el.hidden=true;
  el.innerHTML='<div class="tut-ring"></div><div class="tut-ring"></div><div class="tut-chip" role="status" aria-live="polite"><span class="tut-keys"></span><span class="tut-txt"></span><button class="tut-x" type="button" aria-label="Скрыть подсказку">✕</button></div>';
  document.body.appendChild(el);TUT.el=el;TUT.chip=el.querySelector('.tut-chip');TUT.rings=[...el.querySelectorAll('.tut-ring')];
  el.querySelector('.tut-x').addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const C=TUT.cur;if(C)tutDone(C.k,'skip');});
  el.querySelector('.tut-x').addEventListener('pointerdown',e=>{e.stopPropagation();});
  return el;}
function tutDomHide(mode){const el=TUT.el;if(!el||el.hidden)return;const ch=TUT.chip;ch.classList.remove('on');ch.classList.add(mode==='ok'?'ok':'out');
  TUT.rings.forEach(r=>{if(mode==='ok'&&r.classList.contains('on')){const m=r.style.transform||'';r.style.transform=m+' scale(.2)';}r.classList.remove('on');if(mode==='ok')r.classList.add('ok');});
  TUT.domKey=null;clearTimeout(TUT.hideT);TUT.hideT=setTimeout(()=>{if(!TUT.cur){el.hidden=true;}},650);}
function tutRect(el){if(!el)return null;const r=el.getBoundingClientRect();return r.width>1?r:null;}
function tutInter(a,b){return a[0]<b[2]&&a[2]>b[0]&&a[1]<b[3]&&a[3]>b[1];}
function tutBlockers(){const now=performance.now();if(TUT.blk&&now-TUT.blkAt<250)return TUT.blk;const out=[],add=el=>{if(!el||!tutVis(el))return;const r=el.getBoundingClientRect();out.push([r.left-6,r.top-6,r.right+6,r.bottom+6]);};
  document.querySelectorAll('#touch .tbtn').forEach(add);['mini','btnPause','btnMap','toast','radio','wcard','joyIdle','banner'].forEach(id=>add(document.getElementById(id)));document.querySelectorAll('#hud .hud-tl,#hud .hud-w .bar-l,#hud .hud-b .chips').forEach(add);TUT.blk=out;TUT.blkAt=now;return out;}
function tutPlace(cw,ch,cands,extra){const blk=tutBlockers().concat(extra||[]);
  const sl=(SAFE.l||0)+8,sr=CW-(SAFE.r||0)-8,st=(SAFE.t||0)+8,sb=CH-(SAFE.b||0)-8;let first=null;
  for(const [x,y] of cands){const L=clamp(x-cw/2,sl,sr-cw),Tp=clamp(y,st,sb-ch),box=[L,Tp,L+cw,Tp+ch];if(!first)first=[L,Tp];if(!blk.some(b=>tutInter(box,b)))return [L,Tp];}
  return first||[sl,st];}
function tutDraw(now){const C=TUT.cur;if(!C)return;const el=tutDom();const V=C.L.view()||{};C.v=V;
  if(el.hidden){el.hidden=false;}clearTimeout(TUT.hideT);
  const ch=TUT.chip,key=C.k+'|'+(V.keys||'')+'|'+(V.text||'')+'|'+(V.hostile?1:0);
  if(TUT.domKey!==key){TUT.domKey=key;ch.querySelector('.tut-keys').innerHTML=V.keys||'';ch.querySelector('.tut-txt').innerHTML=V.text||'';ch.classList.toggle('hostile',!!V.hostile);ch.classList.remove('ok','out');}
  /* нажатые клавиши подсвечиваются — подсказка отвечает на руки игрока */
  ch.querySelectorAll('kbd[data-kk]').forEach(k=>{const c=k.dataset.kk,alt={KeyW:'ArrowUp',KeyA:'ArrowLeft',KeyS:'ArrowDown',KeyD:'ArrowRight'}[c];k.classList.toggle('lit',!!(KEYS[c]||KEYS[alt]));});
  const showChip=V.at&&V.at!=='none'&&(V.text||V.keys);
  if(showChip){const cw=ch.offsetWidth||120,chh=ch.offsetHeight||30,u=UI||1,p=G.player;let cands=[];
    if(V.at==='ship'&&p){const [X,Y]=tutSP(p.x,p.y),off=(p.r||13)*SC+18*u;cands=[[X,Y+off,0,1],[X,Y-off-chh,0,-1],[X+off+cw/2,Y-chh/2,1,0],[X-off-cw/2,Y-chh/2,-1,0]];
      if(V.avoid!==undefined){const ax=Math.cos(V.avoid),ay=Math.sin(V.avoid);cands.sort((a,b)=>(a[2]*ax+a[3]*ay)-(b[2]*ax+b[3]*ay));}}
    else if(V.at==='stick'){const f=tutStickPt(),y0=f.y-f.R-chh-18;cands=[[f.x,y0],[f.x,y0-16],[f.x-cw*.4,y0],[f.x+cw*.4,y0],[f.x,y0-36],[f.x,f.y+f.R+10]];}
    else if(V.at==='line'){const r=tutRelay();if(r&&G.bc){const [X,Y]=tutSP((r.x+G.bc.x)/2,(r.y+G.bc.y)/2);cands=[[X,Y-chh-28*u],[X,Y+28*u]];}else if(p){const [X,Y]=tutSP(p.x,p.y);cands=[[X,Y+40*u]];}}
    else if(V.at==='el'){const r=tutRect(V.el);if(r){const cx=(r.left+r.right)/2,cy=(r.top+r.bottom)/2,g=12*u;
      const up=[cx,r.top-g-chh],dn=[cx,r.bottom+g],lf=[r.left-g-cw/2,cy-chh/2],rt=[r.right+g+cw/2,cy-chh/2],ul=[r.left-cw/2,r.top-g-chh];
      cands=V.side==='up'?[up,dn,lf,rt]:(cy>CH*.55?[up,lf,rt,ul,dn]:[dn,up,lf,rt]);}}
    let extra=[];if(p&&(V.at==='ship'||V.at==='line')){const [X,Y]=tutSP(p.x,p.y),s_=(p.r||13)*SC+8;extra.push([X-s_,Y-s_,X+s_,Y+s_]);}
    if(cands.length){const [L,Tp]=tutPlace(cw,chh,cands,extra);ch.style.transform=`translate3d(${L.toFixed(1)}px,${Tp.toFixed(1)}px,0)`;ch.classList.add('on');}else ch.classList.remove('on');}
  else ch.classList.remove('on');
  const rings=V.ring||[];TUT.rings.forEach((rg,i)=>{const r=tutRect(rings[i]);if(!r){rg.classList.remove('on');return;}
    const pad=10*(UI||1),sq=/\bsq\b/.test(V.ringCls||''),w=sq?r.width+pad*2:Math.max(r.width,r.height)+pad*2,h=sq?r.height+pad*2:w;
    rg.className='tut-ring on '+(V.ringCls||'');rg.style.width=w+'px';rg.style.height=h+'px';rg.style.transform=`translate3d(${((r.left+r.right)/2-w/2).toFixed(1)}px,${((r.top+r.bottom)/2-h/2).toFixed(1)}px,0)`;});}
function tutStickPt(){const R=(typeof joyR==='function'?joyR():48),I=$('#joyIdle');if(I&&tutVis(I)){const r=I.getBoundingClientRect();return {x:(r.left+r.right)/2,y:(r.top+r.bottom)/2,R:r.width/2-5};}
  if(SET.stick==='fixed'&&typeof joyFixed==='function')return joyFixed();const left=SET.hand==='l';return {x:left?CW-SAFE.r-24-R*2.3:SAFE.l+24+R*2.3,y:CH-SAFE.b-24-R*2.3,R};}
function tutFly(n){try{const w=$('#wLom');if(!w||!tutVis(w))return;w.classList.remove('tut-flash');void w.offsetWidth;w.classList.add('tut-flash');const r=w.getBoundingClientRect();
  const f=document.createElement('div');f.className='tut-fly';f.textContent='+'+fmtN(n)+' НА СКЛАД';f.style.left=((r.left+r.right)/2)+'px';f.style.top=(r.bottom+6)+'px';document.body.appendChild(f);setTimeout(()=>f.remove(),1200);}catch(e){}}
function tutFxOk(k){try{buzz('tap');}catch(e){}
  try{if(!AU.ctx||!SET.sfx||!AU.sfx)return;const c=AU.ctx,t=c.currentTime,f=(typeof PENTA!=='undefined'?PENTA[2]:698.46);
    for(const [m,d,v] of [[1,0,.05],[1.5,.07,.035]]){const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=f*m;g.gain.setValueAtTime(0,t+d);g.gain.linearRampToValueAtTime(v,t+d+.01);g.gain.exponentialRampToValueAtTime(.0005,t+d+.22);o.connect(g);g.connect(AU.sfx);o.start(t+d);o.stop(t+d+.25);}}catch(e){}}

/* ---------- отрисовка: мир (канва) ---------- */
function tutWorldDraw(now){const C=TUT.cur;if(!C||!C.v||!C.v.draw||!G.player)return;if(!tutCtxOk(C.L.ctx==='map'?'map':C.L.ctx==='mission'?'mission':'any'))return;
  const t=now/1000,p=G.player,u=UI||1,c=ctx;c.save();c.setTransform(DPR,0,0,DPR,0,0);c.globalCompositeOperation='source-over';
  const [PX,PY]=tutSP(p.x,p.y);const ice='#8fe9ff',amber='#ffb84d',red='#ff4f6e';
  const ringAt=(x,y,R,col,lab)=>{const [X,Y]=tutSP(x,y),q=(t*0.85)%1;c.globalAlpha=.9;c.strokeStyle=col;c.lineWidth=2;c.setLineDash([]);c.beginPath();c.arc(X,Y,R,0,TAU);c.stroke();
    c.globalAlpha=(1-q)*.7;c.beginPath();c.arc(X,Y,R+q*R*.6,0,TAU);c.stroke();c.globalAlpha=1;
    if(lab){c.font='700 11px "JetBrains Mono",monospace';c.textAlign='center';c.fillStyle=col;c.fillText(lab,X,Y-R-10*u);}return [X,Y];};
  const onScr=(X,Y,m)=>X>m&&X<CW-m&&Y>m&&Y<CH-m;
  const edge=(x,y,col,lab)=>{const [X,Y]=tutSP(x,y);if(onScr(X,Y,20))return false;if(arw61Dup(x,y))return true;const cx=CW/2,cy=CH/2,a=Math.atan2(Y-cy,X-cx),m=46*u,sl=(typeof stageL==='function'?stageL():0);
    const [ex,ey]=edgeAvoid133(clamp(cx+Math.cos(a)*CW,sl+m,CW-sl-m),clamp(cy+Math.sin(a)*CH,m+(isMob()?150:170*u),CH-m-(isMob()?150:80*u)));
    c.save();c.translate(ex,ey);c.rotate(a);c.scale(u,u);c.fillStyle=col;c.globalAlpha=.85+.15*Math.sin(t*5);c.beginPath();c.moveTo(12,0);c.lineTo(-6,-8);c.lineTo(-2,0);c.lineTo(-6,8);c.closePath();c.fill();c.restore();
    c.globalAlpha=1;c.font='700 10px "JetBrains Mono",monospace';c.textAlign='center';c.fillStyle=col;{const tl=lab+' · '+fmtAU(Math.hypot(x-p.x,y-p.y)),tx=clamp(ex-Math.cos(a)*34*u,sl+70*u,CW-sl-70*u),ty=lab61Place(tx,ey-(Math.sin(a)*22-4)*u,c.measureText(tl).width/2+4,10*u);c.lineJoin='round';c.lineWidth=4*u;c.strokeStyle='rgba(4,6,12,.92)';c.strokeText(tl,tx,ty);c.fillText(tl,tx,ty);}return true;};
  const guide=(x,y,col)=>{const a=Math.atan2(y-p.y,x-p.x),d=Math.min(300,Math.hypot(x-p.x,y-p.y)-60);if(d<40)return;const [X1,Y1]=tutSP(p.x+Math.cos(a)*36,p.y+Math.sin(a)*36),[X2,Y2]=tutSP(p.x+Math.cos(a)*d,p.y+Math.sin(a)*d);
    const g=c.createLinearGradient(X1,Y1,X2,Y2);g.addColorStop(0,col);g.addColorStop(1,'rgba(0,0,0,0)');c.strokeStyle=g;c.globalAlpha=.75;c.lineWidth=2;c.setLineDash([6,8]);c.lineDashOffset=-t*28;c.beginPath();c.moveTo(X1,Y1);c.lineTo(X2,Y2);c.stroke();c.setLineDash([]);c.globalAlpha=1;};
  const k=C.v.draw;
  if(k==='stash'){const s=tutShopPt();if(s){guide(s.x,s.y,amber);if(!edge(s.x,s.y,amber,'СКЛАД'))ringAt(s.x,s.y,Math.max(30,70*SC),amber,'СКЛАД');}}
  else if(k==='fire'){let tg=null,bd=1e9;for(const e of G.enemies){if(!tutHostile(e))continue;const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<bd){bd=d;tg=e;}}
    if(tg){const [X,Y]=tutSP(tg.x,tg.y),R=((tg.r||14)+10)*SC,L=R*.45;c.strokeStyle=ice;c.lineWidth=2;c.globalAlpha=.75+.25*Math.sin(t*6);c.beginPath();
      for(const [sx,sy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){c.moveTo(X+sx*R,Y+sy*(R-L));c.lineTo(X+sx*R,Y+sy*R);c.lineTo(X+sx*(R-L),Y+sy*R);}c.stroke();c.globalAlpha=1;}}
  else if(k==='dash'){const T_=TUT.threat;if(T_&&T_.vx!==undefined){const a=Math.atan2(T_.vy||0,T_.vx||0)+Math.PI/2,s=Math.sin(t*6)*.5+.5;
      for(const sg of [1,-1]){const ax=Math.cos(a)*sg,ay=Math.sin(a)*sg,d0=(p.r||13)*SC+10+6*s;c.save();c.translate(PX+ax*d0,PY+ay*d0);c.rotate(Math.atan2(ay,ax));c.globalAlpha=sg>0?.85:.35;c.fillStyle=ice;c.beginPath();c.moveTo(10,0);c.lineTo(-4,-6);c.lineTo(-1,0);c.lineTo(-4,6);c.closePath();c.fill();c.restore();}c.globalAlpha=1;}}
  else if(k==='pulse'){const R=(G.st.pR||150)*SC;c.strokeStyle=amber;c.lineWidth=1.5;c.globalAlpha=.55+.25*Math.sin(t*4);c.setLineDash([8,7]);c.lineDashOffset=-t*20;c.beginPath();c.arc(PX,PY,R,0,TAU);c.stroke();c.setLineDash([]);c.globalAlpha=1;}
  else if(k==='cell'){const q=tutCell();if(q){guide(q.x,q.y,amber);if(!edge(q.x,q.y,amber,'ЯЧЕЙКА'))ringAt(q.x,q.y,16*SC+6,amber,'');}}
  else if(k==='ring'){const bc=G.bc;if(bc){const [X,Y]=tutSP(bc.x,bc.y),R=bcRing()*SC;c.strokeStyle=amber;c.lineWidth=2.5;c.globalAlpha=.55+.35*Math.sin(t*4);c.setLineDash([10,8]);c.lineDashOffset=-t*30;c.beginPath();c.arc(X,Y,R,0,TAU);c.stroke();c.setLineDash([]);c.globalAlpha=1;guide(bc.x,bc.y,amber);
      if(!edge(bc.x,bc.y,amber,'МАЯК')){c.font='700 11px "JetBrains Mono",monospace';c.textAlign='center';c.fillStyle=amber;c.fillText('КОЛЬЦО МАЯКА',X,Y-R-10*u);}}}
  else if(k==='line'){const r=tutRelay(),bc=G.bc;if(r&&bc){const [X1,Y1]=tutSP(r.x,r.y),[X2,Y2]=tutSP(bc.x,bc.y);c.strokeStyle=ice;c.lineWidth=6;c.globalAlpha=.16;c.beginPath();c.moveTo(X1,Y1);c.lineTo(X2,Y2);c.stroke();
      c.lineWidth=2;c.globalAlpha=.85;c.setLineDash([10,9]);c.lineDashOffset=-t*40;c.beginPath();c.moveTo(X1,Y1);c.lineTo(X2,Y2);c.stroke();c.setLineDash([]);
      const mx=(X1+X2)/2,my=(Y1+Y2)/2,a=Math.atan2(Y2-Y1,X2-X1),s=(p.r||13)*SC;c.save();c.translate(mx,my);c.rotate(a);c.globalAlpha=.32+.12*Math.sin(t*3);c.strokeStyle='#e6edf5';c.lineWidth=1.5;c.beginPath();c.moveTo(s*1.2,0);c.lineTo(-s*.8,-s*.75);c.lineTo(-s*.4,0);c.lineTo(-s*.8,s*.75);c.closePath();c.stroke();c.restore();
      if((r.rep||0)>0){c.globalAlpha=.9;c.strokeStyle=ice;c.lineWidth=3;c.beginPath();c.arc(PX,PY,(p.r||13)*SC+12,-Math.PI/2,-Math.PI/2+TAU*clamp(r.rep/2,0,1));c.stroke();}c.globalAlpha=1;
      edge((r.x+bc.x)/2,(r.y+bc.y)/2,ice,'ЛИНИЯ');}}
  else if(k==='patrol'){const E=TUT.patrolEv;const q=Math.sin(t*5)*.5+.5,a0=.12+.08*q;const g=c.createRadialGradient(CW/2,CH/2,Math.min(CW,CH)*.35,CW/2,CH/2,Math.hypot(CW,CH)*.6);g.addColorStop(0,'rgba(255,79,110,0)');g.addColorStop(1,`rgba(255,79,110,${a0.toFixed(3)})`);c.fillStyle=g;c.fillRect(0,0,CW,CH);
    let zx,zy;const z=tutZone();if(z){zx=z.x;zy=z.y;}
    if(zx!==undefined){let a=Math.atan2(p.y-zy,p.x-zx);if(Math.hypot(p.x-zx,p.y-zy)<30)a=-Math.PI/2;for(let i=0;i<3;i++){const ph=((t*1.4+i/3)%1),d=(p.r||13)*SC+16+ph*46;c.save();c.translate(PX+Math.cos(a)*d,PY+Math.sin(a)*d);c.rotate(a);c.globalAlpha=(1-ph)*.9;c.fillStyle=red;c.beginPath();c.moveTo(8,0);c.lineTo(-4,-6);c.lineTo(-1,0);c.lineTo(-4,6);c.closePath();c.fill();c.restore();}c.globalAlpha=1;}}
  c.restore();}
/* призрак пальца на сенсорном экране: ведёт стик по кругу */
function tutGhostDraw(now){const C=TUT.cur;if(!C||C.k!=='move'||tutInput()!=='touch'||!tutCtxOk('world'))return;const t=now/1000,f=tutStickPt(),c=ctx;c.save();c.setTransform(DPR,0,0,DPR,0,0);
  const a=t*2.2,rr=f.R*.55,x=f.x+Math.cos(a)*rr,y=f.y+Math.sin(a)*rr;c.globalAlpha=.22;c.strokeStyle='#e6edf5';c.lineWidth=1.5;c.beginPath();c.arc(f.x,f.y,f.R,0,TAU);c.stroke();
  for(let i=6;i>=0;i--){const b=a-i*.12;c.globalAlpha=.06*(7-i);c.fillStyle='#e6edf5';c.beginPath();c.arc(f.x+Math.cos(b)*rr,f.y+Math.sin(b)*rr,10-i*.6,0,TAU);c.fill();}
  c.globalAlpha=.55;c.fillStyle='#ffffff';c.beginPath();c.arc(x,y,14,0,TAU);c.fill();c.restore();}
/* карта: прожектор на точке прыжка */
function tutMapDraw(now){const C=TUT.cur;if(!C||C.k!=='jump'||G.state!=='map'||G.mapTab!=='map')return;const q=tutJumpPick();if(!q)return;const cv_=$('#mapC'),M=G.mapXY;if(!cv_||!M)return;
  const g=cv_.getContext('2d');g.save();g.setTransform(DPR,0,0,DPR,0,0);const t=now/1000,X=q.px,Y=q.py,tip=$('#mapTip'),pinned=tip&&!tip.hidden&&tip.querySelector('[data-mjump]');
  g.fillStyle='rgba(4,6,12,.35)';g.beginPath();g.rect(0,0,M.w,M.h);g.arc(X,Y,36,0,TAU,true);g.fill('evenodd');
  const ph=(t*.85)%1;g.strokeStyle='#8fe9ff';g.lineWidth=2;g.globalAlpha=.95;g.beginPath();g.arc(X,Y,15,0,TAU);g.stroke();g.globalAlpha=(1-ph)*.8;g.beginPath();g.arc(X,Y,15+ph*20,0,TAU);g.stroke();g.globalAlpha=1;
  const I=tutInput(),lab=pinned?'НАЖМИ «ПРЫЖОК»':'НАЖМИ НА ТОЧКУ',sub=I==='touch'?'ЩИПОК — МАСШТАБ':'КОЛЕСО — МАСШТАБ';
  g.font='700 12px "JetBrains Mono",monospace';g.textAlign='center';g.textBaseline='alphabetic';const below=Y<M.h-80,ly=below?Y+50:Y-58;
  const w1=g.measureText(lab).width;g.font='600 10px "JetBrains Mono",monospace';const w2=g.measureText(sub).width;const bw=Math.max(w1,w2)+28,bx=clamp(X,bw/2+6,M.w-bw/2-6);
  g.fillStyle='rgba(7,12,23,.88)';g.strokeStyle='rgba(143,233,255,.35)';g.lineWidth=1;const by=ly-17,bh=34;if(g.roundRect){g.beginPath();g.roundRect(bx-bw/2,by,bw,bh,8);g.fill();g.stroke();}else{g.fillRect(bx-bw/2,by,bw,bh);g.strokeRect(bx-bw/2,by,bw,bh);}
  g.font='700 12px "JetBrains Mono",monospace';g.fillStyle='#e6edf5';g.fillText(lab,bx,ly-1);g.font='600 10px "JetBrains Mono",monospace';g.fillStyle='#7a8ea5';g.fillText(sub,bx,ly+12);
  if(I==='touch'&&!pinned){const s=(Math.sin(t*4)*.5+.5);g.globalAlpha=.25+.3*(1-s);g.fillStyle='#ffffff';g.beginPath();g.arc(X+10,Y+12,9+s*5,0,TAU);g.fill();g.globalAlpha=1;}
  else if(I==='kbm'&&!pinned){g.save();g.translate(X+14,Y+10);g.rotate(-.35);g.fillStyle='#ffffff';g.strokeStyle='#04060c';g.lineWidth=1;g.beginPath();g.moveTo(0,0);g.lineTo(0,16);g.lineTo(4,12);g.lineTo(7,18);g.lineTo(9.5,17);g.lineTo(6.5,11);g.lineTo(11.5,11);g.closePath();g.fill();g.stroke();g.restore();}
  g.restore();}
/* кадр: после мира и HUD-канвы */
{const _mo2=mobOverlay;mobOverlay=function(now){const r=_mo2.apply(this,arguments);
  try{const dt=Math.min(.5,Math.max(0,(now-(TUT.last||now))/1000));TUT.last=now;tutTick2(dt,now);if(TUT.cur){tutWorldDraw(now);tutGhostDraw(now);}}catch(e){console.error(e);}
  return r;};}
/* при каждом входе в мир счётчик «спокойного полёта» начинается заново */
{const _ew=enterWorldAt;enterWorldAt=function(){TUT.worldT=0;TUT.lpx=null;if(TUT.cur)tutEnd('abort');return _ew.apply(this,arguments);};}

/* ---------- настройки: переключатель и «пройти заново» ---------- */
{const _rss=renderSetScreen;renderSetScreen=function(){const r=_rss.apply(this,arguments);try{const B=$('#setBody');const S=G.save;if(!B||!S)return r;const T=tutT();
  const grp=[...B.querySelectorAll('.setgrp')].pop();if(!grp)return r;const h=grp.querySelector('.cx-h2');const on=!T.off;
  const html=`<button class="tog ${on?'on':''}" data-tutk="off" role="switch" aria-checked="${on}"><span>ПОДСКАЗКИ ОБУЧЕНИЯ</span><span class="sw"><span class="sr">${on?'ВКЛ':'ВЫКЛ'}</span></span></button><div class="tutrow"><button class="wbtn" data-tutreset>ПРОЙТИ ОБУЧЕНИЕ ЗАНОВО</button></div>`;
  if(h)h.insertAdjacentHTML('afterend',html);else grp.insertAdjacentHTML('afterbegin',html);}catch(e){console.error(e);}return r;};}
document.addEventListener('click',e=>{const tg=e.target.closest('[data-tutk],[data-tutreset]');if(!tg||!G.save)return;const T=tutT();
  if(tg.dataset.tutk){const was=!T.off;T.off=was?1:0;if(!was){T.vet=0;}store(saveKey(),G.save);renderSetScreen();const b=$('[data-tutk]');if(b){b.classList.toggle('on',was);void b.offsetWidth;b.classList.toggle('on',!was);try{b.focus({preventScroll:true});}catch(er){}}}
  else{T.done={};T.seen={};T.off=0;T.vet=0;store(saveKey(),G.save);TUT.hist=[];TUT.mv=0;tg.textContent='ОБУЧЕНИЕ НАЧНЁТСЯ В ПОЛЁТЕ';tg.disabled=true;
    const b=$('[data-tutk]');if(b){b.classList.add('on');b.setAttribute('aria-checked','true');const sr=b.querySelector('.sr');if(sr)sr.textContent='ВКЛ';}}
  try{buzz('tap');}catch(er){}});
document.addEventListener('keydown',e=>{if((e.code==='ArrowLeft'||e.code==='ArrowRight')&&e.target&&e.target.matches&&e.target.matches('[data-tutk]')){e.preventDefault();e.stopPropagation();e.target.click();}},true);

/* ===== 1.2.8 α: обучение 2.0 — калибровка, допуск пилота, живые показы, карточка управления =====
   Всё по-прежнему только смотрит и рисует: ни одной игровой величины здесь не меняется. */

/* ---------- навыки пилота: что освоено руками ---------- */
const TUT_SK=[
  {k:'flight',n:'ПОЛЁТ',of:['move'],ic:'<path d="M12 3l6 16-6-4-6 4z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>'},
  {k:'dash',n:'РЫВОК',of:['dash'],ic:'<path d="M4 12h9M4 7h6M4 17h6M14 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>'},
  {k:'pulse',n:'ИМПУЛЬС',of:['pulse'],ic:'<circle cx="12" cy="12" r="2.5" fill="currentColor"/><circle cx="12" cy="12" r="6" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" stroke-width="1.2" opacity=".6"/>'},
  {k:'act',n:'ДЕЙСТВИЕ',of:['act'],ic:'<rect x="4" y="5" width="16" height="14" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M9 9v6M9 9h5M9 12h4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>'},
  {k:'stash',n:'СКЛАД',of:['stash'],ic:'<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z M12 12l8-4.5M12 12v9M12 12L4 7.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>'},
  {k:'map',n:'КАРТА',of:['map'],ic:'<path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z M9 4v14M15 6v14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>'},
  {k:'jump',n:'ПРЫЖОК',of:['jump'],ic:'<circle cx="17" cy="7" r="3.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4 20c3-8 7-11 10-12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-dasharray="2 2.5" stroke-linecap="round"/>'},
  {k:'beacon',n:'МАЯК',of:['cell','line'],ic:'<path d="M12 4l7 4v8l-7 4-7-4V8z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><circle cx="12" cy="12" r="2.4" fill="currentColor"/>'}];
function tutOkMap(){const T=tutT();if(!T)return {};if(!T.ok)T.ok={};return T.ok;}
function tutSkillOk(s){const T=tutT();if(!T)return false;if(T.vet)return true;const ok=T.ok||{};return s.of.some(k=>ok[k]);}
function tutSkillN(){return TUT_SK.filter(tutSkillOk).length;}
function tutOk(k){const T=tutT();if(!T)return;const ok=tutOkMap();if(ok[k])return;const before=TUT_SK.filter(tutSkillOk).map(s=>s.k);ok[k]=1;tutSave();
  const now=TUT_SK.filter(tutSkillOk).map(s=>s.k),fresh=now.filter(x=>!before.includes(x));if(fresh.length&&tutOn())tutSkillPop(fresh);}
/* освоено = сделано руками: пропуск «✕» и три показа без успеха навык не засчитывают */
{const _d=tutDone;tutDone=function(k,how){const T=tutT();const was=!!(T&&T.done[k]);const r=_d.apply(this,arguments);if(T&&!was&&T.done[k]&&how!=='skip')tutOk(k);return r;};}
{const _e=tutEnd;tutEnd=function(how){const C=TUT.cur;const r=_e.apply(this,arguments);if(C&&how==='ok')tutOk(C.k);return r;};}

/* ---------- панель «ДОПУСК ПИЛОТА»: всплывает, когда освоен новый навык ---------- */
function tutSkDom(){let el=$('#tutSk');if(el)return el;el=document.createElement('div');el.id='tutSk';el.setAttribute('aria-live','polite');el.hidden=true;document.body.appendChild(el);return el;}
function tutSkillPop(fresh,final){const el=tutSkDom(),n=tutSkillN(),all=n===TUT_SK.length,now=performance.now();if(TUT.skFresh&&now-TUT.skAt<800)fresh=[...new Set(TUT.skFresh.concat(fresh))];TUT.skFresh=fresh;TUT.skAt=now;
  el.innerHTML=`<div class="tsk-h"><span>ДОПУСК ПИЛОТА</span><b>${n}/${TUT_SK.length}</b></div><div class="tsk-l">${TUT_SK.map(s=>{const ok=tutSkillOk(s),nw=fresh.includes(s.k);
    return `<div class="tsk-r${ok?' ok':''}${nw?' new':''}"><svg viewBox="0 0 24 24" aria-hidden="true">${s.ic}</svg><span>${s.n}</span><i>${ok?'✓':''}</i></div>`;}).join('')}</div>${all?'<div class="tsk-f">ДОПУСК ПОЛУЧЕН</div>':''}`;
  el.classList.toggle('all',all);el.hidden=false;el.classList.remove('on');void el.offsetWidth;el.classList.add('on');
  clearTimeout(TUT.skT);TUT.skT=setTimeout(()=>{el.classList.remove('on');setTimeout(()=>{if(!el.classList.contains('on'))el.hidden=true;},450);},all?4200:3200);
  tutChord(all?5:fresh.length+1);}
function tutChord(n){try{if(!AU.ctx||!SET.sfx||!AU.sfx)return;const c=AU.ctx,t=c.currentTime,P_=typeof PENTA!=='undefined'?PENTA:[523.25,622.25,698.46,830.61,932.33];
  for(let i=0;i<Math.min(5,n);i++){const o=c.createOscillator(),g=c.createGain(),d=i*.07;o.type='sine';o.frequency.value=P_[i%5]*(i>=5?2:1);g.gain.setValueAtTime(0,t+d);g.gain.linearRampToValueAtTime(.04,t+d+.012);g.gain.exponentialRampToValueAtTime(.0004,t+d+.35);o.connect(g);g.connect(AU.sfx);o.start(t+d);o.stop(t+d+.4);}}catch(e){}}
function tutNote(i){try{if(!AU.ctx||!SET.sfx||!AU.sfx)return;const c=AU.ctx,t=c.currentTime,P_=typeof PENTA!=='undefined'?PENTA:[523.25,622.25,698.46,830.61,932.33];
  const o=c.createOscillator(),g=c.createGain();o.type='triangle';o.frequency.value=P_[i%5]*(i>=5?2:1);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.05,t+.01);g.gain.exponentialRampToValueAtTime(.0004,t+.28);o.connect(g);g.connect(AU.sfx);o.start(t);o.stop(t+.3);}catch(e){}}

/* ---------- «КАЛИБРОВКА»: голографическая трасса сразу после пробуждения ----------
   три кольца — рулить, ворота — рывок сквозь луч. Только картинка: ни столкновений, ни наград. */
function tutCalNew(){const p=G.player;let dx=Math.cos(p.ang||-Math.PI/2),dy=Math.sin(p.ang||-Math.PI/2);
  try{const nt=nextTarget();if(nt){const d=Math.hypot(nt.x-p.x,nt.y-p.y);if(d>400){dx=(nt.x-p.x)/d;dy=(nt.y-p.y)/d;}}}catch(e){}
  const ok=(x,y)=>inSectors(x,y)&&sectorIdx(x,y)===0;if(!ok(p.x+dx*1050,p.y+dy*1050)){dx=-dx;dy=-dy;}
  const nx=-dy,ny=dx,at=(a,b)=>{let x=p.x+dx*a+nx*b,y=p.y+dy*a+ny*b;for(const r of G.rocks||[]){if(!r.alive)continue;const d=Math.hypot(r.x-x,r.y-y),need=(r.r||20)+70;if(d<need){x+=nx*(need-d+10)*(b>=0?1:-1);y+=ny*(need-d+10)*(b>=0?1:-1);}}return {x,y};};
  const pts=[at(270,0),at(500,120),at(730,-120)].map(q=>({...q,done:0}));const g=at(1000,0);
  return {pts,i:0,gate:{x:g.x,y:g.y,nx,ny,h:92,done:0,fail:0,fails:0},px:p.x,py:p.y,far:0,dx,dy,t0:performance.now()};}
function tutSegX(ax,ay,bx,by,cx,cy,dx_,dy_){const r=(bx-ax)*(dy_-cy)-(by-ay)*(dx_-cx);if(Math.abs(r)<1e-9)return false;const t=((cx-ax)*(dy_-cy)-(cy-ay)*(dx_-cx))/r,u=((cx-ax)*(by-ay)-(cy-ay)*(bx-ax))/r;return t>=0&&t<=1&&u>=0&&u<=1;}
TUT_L.calib={ctx:'world',dur:0,
  when(){const S=G.save,T=tutT(),p=G.player;if(!T||T.done.calib||T.vet||(S.cleared||0)>0||G.prologue||TUT.worldT<1.2||!p)return false;return sectorIdx(p.x,p.y)===0;},
  step(dt,now){const p=G.player,T=tutT();let K=TUT.cal;if(!K||Math.hypot(K.px-p.x,K.py-p.y)>2600){K=TUT.cal=tutCalNew();}
    const tgt=K.i<3?K.pts[K.i]:K.gate;
    if(K.i<3){if(Math.hypot(p.x-tgt.x,p.y-tgt.y)<56){tgt.done=now;K.i++;tutNote(K.i-1);try{for(let j=0;j<14;j++){const a=j/14*TAU;part(tgt.x,tgt.y,Math.cos(a)*160,Math.sin(a)*160,.45,'#8fe9ff',2);}}catch(e){}
        if(K.i===3){K.gateOn=now;}}}
    else{const G_=K.gate,x1=G_.x+G_.nx*G_.h,y1=G_.y+G_.ny*G_.h,x2=G_.x-G_.nx*G_.h,y2=G_.y-G_.ny*G_.h;
      if(tutSegX(K.px,K.py,p.x,p.y,x1,y1,x2,y2)){if((p.dashT||0)>0||now-(TUT.lastDashAt||-1e9)<450){G_.done=now;tutNote(4);
          try{for(let j=0;j<22;j++){const a=j/22*TAU;part(G_.x,G_.y,Math.cos(a)*220,Math.sin(a)*220,.55,'#ffb84d',2.4);}}catch(e){}
          T.done.calib=1;tutOkMap().calib=1;tutDone('move');tutDone('dash');TUT.calDone=now;tutEnd('ok');return;}
        else{G_.fail=now;G_.fails++;tutNote(0);}}}
    if(Math.hypot(p.x-tgt.x,p.y-tgt.y)>1800){K.far+=dt;if(K.far>12){T.done.calib=1;tutSave();TUT.cal=null;tutEnd('abort');return;}}else K.far=0;
    K.px=p.x;K.py=p.y;},
  view(){const K=TUT.cal,I=tutInput(),p=G.player;if(!K)return {at:'none'};const tgt=K.i<3?K.pts[K.i]:K.gate,av=Math.atan2(tgt.y-p.y,tgt.x-p.x);
    if(K.i<3){const txt=`ЧЕРЕЗ КОЛЬЦА <b>${K.i+1}/3</b>`;if(I==='touch')return {keys:'',text:txt,at:'stick',draw:'calib'};return {keys:tutKeyHTML('move'),text:txt,at:'ship',draw:'calib',avoid:av};}
    const failNow=performance.now()-K.gate.fail<1400,txt=failNow?'<b>С РЫВКОМ</b> · ЕЩЁ РАЗ':'РЫВОК <b>СКВОЗЬ ЛУЧ</b>';
    if(I==='touch'){const d=$('#tDash');return {keys:'',text:txt,at:'el',el:d,ring:[d],draw:'calib',hostile:failNow};}
    return {keys:tutKeyHTML('dash'),text:txt,at:'ship',draw:'calib',avoid:av,hostile:failNow};}};
/* ARCH·86 · слой tutEmit 1 из 2 (строка 14365 в 1.5.25) перенесён в объединённый слой ниже */

/* ---------- «ИМПУЛЬС ГОТОВ»: накопитель впервые полон — показать, где он и что делает ---------- */
TUT_L.energy={ctx:'any',dur:4.8,info:true,
  when(){const p=G.player;return p.en>=100&&!tutDoneQ('pulse');},
  view(){const I=tutInput();if(I==='touch'){const d=$('#tPulse');return {keys:'',text:'<b>ИМПУЛЬС</b> ГОТОВ',at:'el',el:d,ring:[d],ringCls:'amber',draw:'pulsedemo'};}
    const eb=$('#enBar');return {keys:tutKeyHTML('pulse'),text:'<b>ИМПУЛЬС</b> ГОТОВ · ДЛЯ БОЯ',at:'el',el:eb&&tutVis(eb)?eb:null,ring:eb&&tutVis(eb)?[eb]:[],ringCls:'amber sq',draw:'pulsedemo'};}};

/* ---------- живые показы поверх уроков ---------- */
{const _wd=tutWorldDraw;tutWorldDraw=function(now){_wd.apply(this,arguments);const C=TUT.cur;if(!C||!C.v||!G.player)return;try{tutDemo(C,now);}catch(e){console.error(e);}};}
function tutDemo(C,now){if(!tutCtxOk(C.L.ctx==='mission'?'mission':'any'))return;const t=now/1000,p=G.player,c=ctx,k=C.v.draw,u=UI||1;const [PX,PY]=tutSP(p.x,p.y),s=(p.r||13)*SC;
  c.save();c.setTransform(DPR,0,0,DPR,0,0);
  const ghostShip=(x,y,a,al)=>{c.save();c.translate(x,y);c.rotate(a);c.globalAlpha=al;c.strokeStyle='#cfeeff';c.lineWidth=1.4;c.beginPath();c.moveTo(s*1.25,0);c.lineTo(-s*.8,-s*.78);c.lineTo(-s*.4,0);c.lineTo(-s*.8,s*.78);c.closePath();c.stroke();c.restore();};
  if(k==='pulse'||k==='pulsedemo'){const R=(G.st.pR||150)*SC,q=(t%1.3)/1.3;c.strokeStyle='#ffb84d';c.lineWidth=3*(1-q)+1;c.globalAlpha=(1-q)*.55;c.beginPath();c.arc(PX,PY,R*q,0,TAU);c.stroke();
    if(k==='pulsedemo'){c.globalAlpha=.35;c.lineWidth=1.2;c.setLineDash([6,8]);c.lineDashOffset=-t*18;c.beginPath();c.arc(PX,PY,R,0,TAU);c.stroke();c.setLineDash([]);}}
  if(k==='dash'){const T_=TUT.threat;let a=(p.ang||0)+Math.PI/2;if(T_&&T_.vx!==undefined)a=Math.atan2(T_.vy||0,T_.vx||0)+Math.PI/2;const q=(t%.9)/.9,e=1-Math.pow(1-q,3);
    for(let i=0;i<3;i++){const f=Math.max(0,e-i*.12);ghostShip(PX+Math.cos(a)*f*64,PY+Math.sin(a)*f*64,p.ang||0,(1-q)*(.45-i*.12));}}
  if(k==='stash'){const sh=tutShopPt();if(sh){const a=Math.atan2(sh.y-p.y,sh.x-p.x),L=Math.min(300,Math.hypot(sh.x-p.x,sh.y-p.y)-60);if(L>60)for(let i=0;i<4;i++){const q=((t*.7+i/4)%1),d=36+q*(L-36);const [X,Y]=tutSP(p.x+Math.cos(a)*d,p.y+Math.sin(a)*d);
      c.globalAlpha=Math.sin(q*Math.PI)*.9;c.fillStyle='#ffb84d';c.beginPath();c.arc(X,Y,2.6+1.2*Math.sin(q*Math.PI),0,TAU);c.fill();}}}
  if(k==='calib')tutCalDraw(now);
  c.restore();}
function tutCalDraw(now){const K=TUT.cal;if(!K)return;const t=now/1000,c=ctx,u=UI||1,p=G.player,ice='#8fe9ff',amb='#ffb84d',red='#ff4f6e';
  const R=56*SC;
  K.pts.forEach((q,i)=>{const [X,Y]=tutSP(q.x,q.y);
    if(q.done){const e=(now-q.done)/450;if(e<1){c.globalAlpha=(1-e)*.9;c.strokeStyle=ice;c.lineWidth=3;c.beginPath();c.arc(X,Y,R*(1+e*.8),0,TAU);c.stroke();}return;}
    const act=i===K.i;c.globalAlpha=act?1:.22;c.strokeStyle=ice;c.lineWidth=act?2.2:1.4;c.beginPath();c.arc(X,Y,R,0,TAU);c.stroke();
    if(act){c.save();c.translate(X,Y);c.rotate(t*.9);c.lineWidth=3;c.globalAlpha=.8;for(let j=0;j<4;j++){c.beginPath();c.arc(0,0,R+7,j*Math.PI/2,j*Math.PI/2+.5);c.stroke();}c.restore();
      const q2=(t*.9)%1;c.globalAlpha=(1-q2)*.5;c.lineWidth=1.5;c.beginPath();c.arc(X,Y,R*(1+q2*.5),0,TAU);c.stroke();
      const g=c.createRadialGradient(X,Y,0,X,Y,R);g.addColorStop(0,'rgba(143,233,255,.16)');g.addColorStop(1,'rgba(143,233,255,0)');c.globalAlpha=1;c.fillStyle=g;c.beginPath();c.arc(X,Y,R,0,TAU);c.fill();}
    c.globalAlpha=act?.95:.3;c.font='700 11px "JetBrains Mono",monospace';c.textAlign='center';c.fillStyle=ice;c.fillText(String(i+1),X,Y+4);});
  /* ворота: два пилона и луч */
  const G_=K.gate,on=K.i>=3,ax=G_.x+G_.nx*G_.h,ay=G_.y+G_.ny*G_.h,bx=G_.x-G_.nx*G_.h,by=G_.y-G_.ny*G_.h,[X1,Y1]=tutSP(ax,ay),[X2,Y2]=tutSP(bx,by),[GX,GY]=tutSP(G_.x,G_.y);
  const fail=now-G_.fail<600,col=fail?red:amb;c.globalAlpha=on?1:.25;
  for(const [X,Y] of [[X1,Y1],[X2,Y2]]){c.save();c.translate(X,Y);c.rotate(Math.PI/4);c.fillStyle='#0a1220';c.strokeStyle=col;c.lineWidth=2;c.fillRect(-7*u,-7*u,14*u,14*u);c.strokeRect(-7*u,-7*u,14*u,14*u);c.restore();}
  c.strokeStyle=col;c.lineWidth=on?3:1.5;c.setLineDash([9,7]);c.lineDashOffset=-t*40;c.globalAlpha=on?(.65+.35*Math.sin(t*8)):.2;c.beginPath();c.moveTo(X1,Y1);c.lineTo(X2,Y2);c.stroke();c.setLineDash([]);
  if(on){c.globalAlpha=.18;c.lineWidth=10;c.beginPath();c.moveTo(X1,Y1);c.lineTo(X2,Y2);c.stroke();
    /* призрак показывает рывок сквозь луч */
    const q=(t%1.6)/1.6;if(q<.7){const dx=K.dx,dy=K.dy,f=q/.7,e=f<.45?f/.45*.55:.55+(f-.45)/.55*.45*1.0;const sx=G_.x-dx*120+dx*240*e,sy=G_.y-dy*120+dy*240*e,[SX,SY]=tutSP(sx,sy),s=(p.r||13)*SC;
      c.save();c.translate(SX,SY);c.rotate(Math.atan2(dy,dx));c.globalAlpha=.35*(1-f*.6);c.strokeStyle='#cfeeff';c.lineWidth=1.4;c.beginPath();c.moveTo(s*1.25,0);c.lineTo(-s*.8,-s*.78);c.lineTo(-s*.4,0);c.lineTo(-s*.8,s*.78);c.closePath();c.stroke();
      if(f>.45){c.globalAlpha=.25*(1-f);c.beginPath();c.moveTo(-s*.4,0);c.lineTo(-s*3.2,0);c.stroke();}c.restore();}
    c.globalAlpha=1;c.font='700 11px "JetBrains Mono",monospace';c.textAlign='center';c.fillStyle=col;c.fillText('РЫВОК',GX,Math.min(Y1,Y2)-14);}
  /* путь к активной цели и стрелка у края, если цель за кадром */
  const tg=K.i<3?K.pts[K.i]:G_,[TX,TY]=tutSP(tg.x,tg.y);
  if(TX<20||TX>CW-20||TY<20||TY>CH-20){const cx=CW/2,cy=CH/2,a=Math.atan2(TY-cy,TX-cx),m=46*u,ex=clamp(cx+Math.cos(a)*CW,m,CW-m),ey=clamp(cy+Math.sin(a)*CH,m+(isMob()?150:120*u),CH-m-(isMob()?160:80*u));
    c.save();c.translate(ex,ey);c.rotate(a);c.scale(u,u);c.fillStyle=K.i<3?ice:amb;c.globalAlpha=.85+.15*Math.sin(t*5);c.beginPath();c.moveTo(12,0);c.lineTo(-6,-8);c.lineTo(-2,0);c.lineTo(-6,8);c.closePath();c.fill();c.restore();}
  else{const a=Math.atan2(tg.y-p.y,tg.x-p.x),d=Math.min(260,Math.hypot(tg.x-p.x,tg.y-p.y)-70);if(d>30){const [A1,B1]=tutSP(p.x+Math.cos(a)*34,p.y+Math.sin(a)*34),[A2,B2]=tutSP(p.x+Math.cos(a)*d,p.y+Math.sin(a)*d);
    c.strokeStyle=K.i<3?ice:amb;c.globalAlpha=.5;c.lineWidth=1.6;c.setLineDash([5,8]);c.lineDashOffset=-t*30;c.beginPath();c.moveTo(A1,B1);c.lineTo(A2,B2);c.stroke();c.setLineDash([]);}}
  c.globalAlpha=1;}
/* призрак пальца — и для колец калибровки */
{const _gd=tutGhostDraw;tutGhostDraw=function(now){const C=TUT.cur;if(C&&C.k==='calib'&&TUT.cal&&TUT.cal.i<3&&tutInput()==='touch'){const k=C.k;C.k='move';try{_gd.apply(this,arguments);}finally{C.k=k;}return;}return _gd.apply(this,arguments);};}
/* карта: путь от корабля к выбранной точке прыжка */
/* ARCH·86 · слой tutMapDraw 1 из 2 (строка 14416 в 1.5.25) перенесён в объединённый слой ниже */

/* ---------- карточка «ДОПУСК ПИЛОТА» в паузе: управление под ваше устройство ---------- */
const TUT_CTL={flight:{kbm:'W A S D · СТРЕЛКИ',touch:'СТИК СЛЕВА',pad:'ЛЕВЫЙ СТИК'},dash:{kbm:'ПРОБЕЛ',touch:'КНОПКА «РЫВОК» · СВАЙП',pad:'A'},pulse:{kbm:'E · SHIFT',touch:'КНОПКА «ИМП»',pad:'X'},
  act:{kbm:'F · ENTER',touch:'КНОПКА НАД РЫВКОМ',pad:'B'},stash:{kbm:'ЛОМ → МАСТЕРСКАЯ',touch:'ЛОМ → МАСТЕРСКАЯ',pad:'ЛОМ → МАСТЕРСКАЯ'},map:{kbm:'M · TAB',touch:'«КАРТА» · МИНИКАРТА',pad:'Y'},
  jump:{kbm:'КЛИК ПО КОЛЬЦУ НА КАРТЕ',touch:'ТОЧКА → «ПРЫЖОК»',pad:'С МЫШЬЮ ИЛИ КАСАНИЕМ'},beacon:{kbm:'ЯЧЕЙКИ В КОЛЬЦО',touch:'ЯЧЕЙКИ В КОЛЬЦО',pad:'ЯЧЕЙКИ В КОЛЬЦО'}};
function tutCardHTML(){const I=tutInput(),n=tutSkillN();
  return `<summary><span>ДОПУСК ПИЛОТА</span><b>${n}/${TUT_SK.length}</b></summary><div class="tcard-l">${TUT_SK.map(s=>{const ok=tutSkillOk(s);
    return `<div class="tcard-r${ok?' ok':''}"><svg viewBox="0 0 24 24" aria-hidden="true">${s.ic}</svg><span class="nm">${s.n}</span><span class="tck">${TUT_CTL[s.k][I]}</span><i aria-label="${ok?'освоено':'ещё нет'}">${ok?'✓':''}</i></div>`;}).join('')}</div>`;}
{const _pz=pause;pause=function(){const r=_pz.apply(this,arguments);try{if(G.state==='pause'&&G.save&&G.mode==='world'){const pnl=document.querySelector('#sPause .panel');if(pnl){let d=$('#tutCard');if(!d){d=document.createElement('details');d.id='tutCard';const st=$('#pauseStat');(st||pnl.firstElementChild).insertAdjacentElement('afterend',d);}
    const T=tutT(),done=tutSkillN()>=TUT_SK.length;d.innerHTML=tutCardHTML();d.open=!done&&!!T&&!T.off&&!T.vet;d.hidden=false;}}else{const d=$('#tutCard');if(d)d.hidden=true;}}catch(e){console.error(e);}return r;};}

/* ===== 1.2.8 α: музыка меню сразу, громкость звуков, кнопки меню на телефоне ===== */
/* громкость звуков: свой множитель поверх прежних 0,32 */
SET_DEF.sfxVol=.7;if(typeof SET.sfxVol!=='number'||!Number.isFinite(SET.sfxVol))SET.sfxVol=.7;SET.sfxVol=clamp(SET.sfxVol,0,1);
function sfxVolApply(){if(!AU.ctx||!AU.sfx)return;const t=AU.ctx.currentTime;AU.sfx.gain.cancelScheduledValues(t);AU.sfx.gain.setTargetAtTime(.32*SET.sfxVol,t,.03);}
{const _aa=applyAudio;applyAudio=function(){const r=_aa.apply(this,arguments);sfxVolApply();return r;};}
function sfxVolRow(id){return `<label class="vol"><span>ГРОМКОСТЬ ЗВУКОВ</span><input type="range" min="0" max="1" step="0.05" value="${SET.sfxVol}" data-svol id="${id}" aria-label="Громкость звуков"></label>`;}
function sfxVolInject(root,id){if(!root)return;root.querySelectorAll('.tog[data-k="sfx"]').forEach((b,i)=>{const nx=b.nextElementSibling;if(nx&&nx.querySelector&&nx.querySelector('[data-svol]'))return;b.insertAdjacentHTML('afterend',sfxVolRow(id+(i?'-'+i:'')));});}
/* ARCH·86 · слой renderSetScreen 1 из 3 (строка 14438 в 1.5.25) перенесён в объединённый слой ниже */
/* ARCH·86 · слой renderSettings 2 из 3 (строка 14439 в 1.5.25) перенесён в объединённый слой ниже */
let sfxPrevT=0;
document.addEventListener('input',e=>{if(!e.target.matches||!e.target.matches('[data-svol]'))return;SET.sfxVol=clamp(+e.target.value,0,1);saveSet();audioInit();sfxVolApply();
  const now=performance.now();if(SET.sfx&&now-sfxPrevT>140){sfxPrevT=now;try{sfx('cell');}catch(er){}}});

/* музыка меню: через 0,5 с после загрузки. Если браузер не пускает звук без касания —
   трек уже декодирован и начнётся с первого же касания, клика или клавиши в любом месте */
function audioWake(){try{if(!AU.ctx)audioInit();else if(AU.ctx.state!=='running'&&AU.ctx.state!=='closed')AU.ctx.resume();}catch(e){}}
setTimeout(()=>{audioWake();try{if(AU.ctx&&typeof mzP==='function'&&typeof MZ_TR!=='undefined'){const P_=mzP('menu');mzDecode(P_,0).catch(()=>{});mzDecode(P_,MZ_TR.menu.intro).catch(()=>{});}}catch(e){}},500);
{const ev=['pointerdown','pointerup','touchend','mousedown','keydown','click'],h=()=>{audioWake();if(AU.ctx&&AU.ctx.state==='running')ev.forEach(n=>removeEventListener(n,h,true));};ev.forEach(n=>addEventListener(n,h,{capture:true,passive:true}));}

/* ===== 1.2.9 α: миссии 15–24 — враги прочнее и бьют больнее в 1,5 раза (скорость и темп атак без изменений) ===== */
const X129={from:15,to:24,hp:1.5,dmg:1.5};
function hpX129(){return inMission()&&G.m>=X129.from&&G.m<=X129.to?X129.hp:1;}
/* урон по игроку и по маяку: через уже существующий множитель миссий (damagePlayer, dmgBeacon) */
for(let m=X129.from;m<=X129.to;m++){MISSION_K[m]=Object.assign({},MISSION_K[m]);MISSION_K[m].dmg=(MISSION_K[m].dmg||1)*X129.dmg;}
/* боссы секторов и их части задают прочность сами — через sbRank() */
{const _sbR=sbRank;sbRank=function(){return _sbR()*hpX129();};}

/* ===== 1.3.1 α: меню, «Допуск пилота», прозрачность, музыка ===== */
const VN131={
  alpha:'игра в разработке, всё ещё меняется',
  upd:'небо первого сектора: Маяк Ядра стоит на месте, а камни заднего плана закрывают его — с затмением и светом по краю.'
};
function vnRender(){const el=$('#verNote');if(!el)return;
  el.innerHTML=`<div class="vn-h"><span class="vn-v">VØID ${VER_TAG}</span><span class="vn-a">АЛЬФА</span><span class="vn-p">${VN131.alpha}</span></div>`+
    `<p class="vn-u"><b>НОВОЕ В ${VER_TAG.replace(' α','')}</b>— ${VN131.upd}</p>`+
    `<div class="vn-s" role="status"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M2 6h3l4-3v10L5 10H2z"/><path d="M11.5 5.5c1 1.4 1 3.6 0 5"/></svg><span>${touchMode||isMob()?'МУЗЫКА — С ПЕРВОГО КАСАНИЯ':'МУЗЫКА — С ПЕРВОГО НАЖАТИЯ'}</span></div>`;}
function vnFresh(){const el=$('#verNote');if(el)el.classList.add('fresh');}
(function(){const rl=$('#recLine');if(rl&&!$('#verNote')){const d=document.createElement('div');d.id='verNote';d.setAttribute('aria-label','Версия игры');rl.insertAdjacentElement('afterend',d);}vnRender();})();
/* свежая версия: пометка «НОВОЕ» держится, пока игрок не уйдёт из меню */
{const _tm=toMenu;toMenu=function(){const r=_tm.apply(this,arguments);try{vnRender();vnMute();}catch(e){}return r;};}

/* «Допуск пилота» в паузе: по умолчанию свёрнут; когда освоены все навыки — карточки нет */
{const _pz=pause;pause=function(){const r=_pz.apply(this,arguments);try{const d=$('#tutCard');if(d&&!d.hidden){if(tutSkillN()>=TUT_SK.length)d.hidden=true;else d.open=false;}}catch(e){}return r;};}

/* прозрачность кнопок: «СИЛЬНАЯ» — действительно сильная */
SET_OPT.btnAlpha=[.2,.7,1];SEGS.btnAlpha=[['ПРОЗРАЧНОСТЬ КНОПОК',[[.2,'СИЛЬНАЯ'],[.7,'СРЕДНЯЯ'],[1,'НЕТ']]]];
if(SET.btnAlpha===.45||!SET_OPT.btnAlpha.includes(SET.btnAlpha)){SET.btnAlpha=SET.btnAlpha<.6?.2:SET.btnAlpha<.85?.7:1;try{saveSet();}catch(e){}}
/* прозрачность стика — отдельная настройка */
SET_DEF.stickAlpha=1;SET_OPT.stickAlpha=[.05,.5,1];SEGS.stickAlpha=[['ПРОЗРАЧНОСТЬ СТИКА',[[.05,'СИЛЬНАЯ'],[.5,'СРЕДНЯЯ'],[1,'НЕТ']]]];
if(!SET_OPT.stickAlpha.includes(SET.stickAlpha))SET.stickAlpha=1;
function opApply(){const T=$('#touch');if(!T)return;const mob=isMob();T.style.setProperty('--sa',mob?SET.stickAlpha:1);}
{const _lt=layoutTouch;layoutTouch=function(){const r=_lt.apply(this,arguments);try{opApply();}catch(e){}return r;};}
{const _as=applySettings;applySettings=function(){const r=_as.apply(this,arguments);try{opApply();}catch(e){}return r;};}
const OPIC={btnAlpha:'<svg class="opic" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><circle cx="8" cy="8" r="6"/><circle cx="8" cy="8" r="2.4" stroke-dasharray="1.6 1.4"/></svg>',
  stickAlpha:'<svg class="opic" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><circle cx="8" cy="8" r="6.2" stroke-dasharray="2 1.6"/><circle cx="10" cy="6.4" r="2.6" fill="currentColor" fill-opacity=".35"/></svg>'};
function opInject(root){if(!root)return;const b=root.querySelector('[data-seg="btnAlpha"]');if(!b)return;const row=b.closest('.setrow');
  if(row&&!root.querySelector('[data-seg="stickAlpha"]'))row.insertAdjacentHTML('afterend',segHTML('stickAlpha'));
  for(const k of ['btnAlpha','stickAlpha']){const s=root.querySelector(`[data-seg="${k}"]`);const eb=s&&s.closest('.setrow')&&s.closest('.setrow').querySelector('.eyebrow');if(eb&&!eb.querySelector('.opic'))eb.insertAdjacentHTML('afterbegin',OPIC[k]);}}
/* ARCH·86 · слой renderSetScreen 2 из 3 (строка 14489 в 1.5.25) перенесён в объединённый слой ниже */
/* ARCH·86 · объединённый слой renderSettings: 3 слоя (строки 1.5.25: 13689, 14439, 14490) в исходном порядке исполнения */
{const _p86=renderSettings;renderSettings=function(){const was_861={};let foc_861=null;
  document.querySelectorAll('.tog[data-k]').forEach(b=>{was_861[b.dataset.k]=b.classList.contains('on');if(document.activeElement===b)foc_861=b.dataset.k;});
  const r86=_p86.apply(this,arguments);
  document.querySelectorAll('.tog[data-k]').forEach(b=>{const k=b.dataset.k;if(!(k in was_861))return;const on=b.classList.contains('on');
    if(was_861[k]!==on){b.classList.toggle('on',was_861[k]);void b.offsetWidth;b.classList.toggle('on',on);}
    if(foc_861===k)try{b.focus({preventScroll:true});}catch(e){}});
  try{document.querySelectorAll('[data-settings]').forEach((b,i)=>sfxVolInject(b,'svol-'+i));}catch(e){}
  try{document.querySelectorAll('[data-settings]').forEach(opInject);}catch(e){}return r86;};}
try{opApply();}catch(e){}

/* музыка меню. Браузеры не дают странице включить звук до первого настоящего касания или нажатия,
   а искусственный клик из кода (isTrusted=false) такого права не даёт. Поэтому: пробуем сами при загрузке
   и потом каждые 1,5 с (если браузер разрешит — например, сайт уже «знаком» ему), и любое первое касание
   в любом месте включает музыку. Пока браузер держит звук — внизу меню тихая строка-подсказка. */
function vnMute(){const el=$('#verNote');if(!el)return;const blocked=SET.amb&&G.state==='menu'&&(!AU.ctx||AU.ctx.state!=='running');el.classList.toggle('mute',!!blocked&&performance.now()>1400);}
{let n=0;const iv=setInterval(()=>{n++;try{if(AU.ctx&&AU.ctx.state==='running'){vnMute();clearInterval(iv);return;}if(typeof audioWake==='function')audioWake();vnMute();}catch(e){}if(n>80)clearInterval(iv);},1500);}
{const ev=['pointerdown','pointerup','touchend','mousedown','keydown','click'],h=()=>setTimeout(()=>{try{vnMute();}catch(e){}},60);ev.forEach(n=>addEventListener(n,h,{capture:true,passive:true}));}
setTimeout(()=>{try{vnMute();}catch(e){}},1500);

/* ===== 1.3.2 α «Проверка»: исправления по 5000 прогонам сектора I ===== */
/* Баг №1: музыка меню — автоматический клик в свободную точку экрана вместо игрока.
   Важно: браузеры (Chrome, Safari, Firefox) не считают клик из кода настоящим (isTrusted=false) и звук по нему
   не разрешают. Поэтому клик делается, но вместе с ним остаются попытки раз в 1,5 с и включение с первого
   настоящего касания. Клик посылается только событиями мыши (не pointer — их слушает полноэкранный режим)
   и только туда, где нет кнопок, полей и холста. */
function autoClick132(){try{if(!SET.amb||G.state!=='menu')return false;if(AU.ctx&&AU.ctx.state==='running')return false;
  const pts=[[innerWidth*.78,innerHeight*.5],[innerWidth*.5,innerHeight*.08],[innerWidth-6,innerHeight*.5],[6,innerHeight-6]];
  for(const [x,y] of pts){const el=document.elementFromPoint(x,y);if(!el)continue;if(el.closest('button,a,input,select,textarea,label,summary,[data-seg],[data-act],[data-v],.btn,.tog,#touch,canvas,kbd,[role=button],[role=switch]'))continue;
    const o={bubbles:true,cancelable:true,clientX:x,clientY:y,view:window,button:0};el.dispatchEvent(new MouseEvent('mousedown',o));el.dispatchEvent(new MouseEvent('mouseup',o));el.dispatchEvent(new MouseEvent('click',o));G.autoClick132=(G.autoClick132||0)+1;break;}
  if(typeof audioWake==='function')audioWake();return true;}catch(e){return false;}}
setTimeout(autoClick132,500);setTimeout(autoClick132,1500);
{let n=0;const iv=setInterval(()=>{n++;if(AU.ctx&&AU.ctx.state==='running'||n>40){clearInterval(iv);return;}autoClick132();},1500);}

/* карточка объекта на телефоне в альбомной ориентации закрывала кнопки справа («ИМП») —
   теперь карточка встаёт в свободный промежуток между стиком и кнопками, без своей кнопки (её дублирует «ДЕЙСТВИЕ») */
function wcardFit132(){const c=$('#wcard'),T=$('#touch');if(!c||!T)return;c.style.removeProperty('left');c.style.removeProperty('width');c.style.removeProperty('transform');c.style.removeProperty('max-width');c.classList.remove('fit132');
  if(!isMob()||G.ff==='phone-p'||c.hidden)return;const bs=[...T.querySelectorAll('.tbtn')].filter(b=>!b.hidden&&getComputedStyle(b).display!=='none').map(b=>b.getBoundingClientRect()).filter(r=>r.width>0);if(!bs.length)return;
  const left=SET.hand==='l';const cr=c.getBoundingClientRect();let ok=true;for(const b of bs){if(!(cr.right<=b.left-8||cr.left>=b.right+8||cr.bottom<=b.top-8||cr.top>=b.bottom+8)){ok=false;break;}}if(ok)return;
  const edge=left?Math.max(...bs.map(r=>r.right))+12:Math.min(...bs.map(r=>r.left))-12;const J=typeof joyFixed==='function'?joyFixed():null;
  const jEdge=J?(left?J.x-J.R-12:J.x+J.R+12):(left?CW-12:12);const a=left?edge:Math.max(12,jEdge),z=left?Math.min(CW-12,jEdge):edge;const w=Math.max(150,Math.min(300,z-a));
  const zf=(c.offsetWidth?cr.width/c.offsetWidth:1)||1;/* на планшете карточка увеличена через zoom — пересчитываем в её единицы */
  c.classList.add('fit132');c.style.width=(w/zf)+'px';c.style.maxWidth=(w/zf)+'px';c.style.left=Math.round(((a+z)/2-w/2)/zf)+'px';c.style.transform='none';}
{const _wh=updateWorldHUD;updateWorldHUD=function(){const r=_wh.apply(this,arguments);try{const c=$('#wcard');if(c&&!c.hidden){const k=G.cardKey+'|'+CW+'x'+CH+'|'+SET.hand+'|'+SET.btnSize;if(c.dataset.fit!==k){c.dataset.fit=k;wcardFit132();}}}catch(e){}return r;};}

/* «Допуск пилота» (всплывающая панель) не должен накрывать кнопки на экране — у левшей в альбомной он ложился на «ЗАРЯД» */
function tutSkFit132(){const el=$('#tutSk');if(!el||el.hidden||!isMob())return;el.style.removeProperty('left');el.style.removeProperty('right');el.style.removeProperty('top');
  const hit=()=>{const r=el.getBoundingClientRect();return [...document.querySelectorAll('#touch .tbtn,#mini,#btnPause')].filter(b=>!b.hidden&&getComputedStyle(b).display!=='none').some(b=>{const q=b.getBoundingClientRect();return q.width>0&&!(r.right<=q.left||r.left>=q.right||r.bottom<=q.top||r.top>=q.bottom);});};
  if(!hit())return;el.style.left='auto';el.style.right='max(12px,var(--sar,0px))';if(!hit())return;el.style.removeProperty('right');el.style.removeProperty('left');
  const hud=document.querySelector('#hud .hud-tl');const top=hud?hud.getBoundingClientRect().bottom+8:52;el.style.top=top+'px';}
{const _sp=tutSkillPop;tutSkillPop=function(){const r=_sp.apply(this,arguments);try{TUT.blk=null;tutSkFit132();requestAnimationFrame(()=>{try{tutSkFit132();}catch(e){}});}catch(e){}return r;};}
/* подсказки обучения обходят и всплывающий «Допуск пилота», и карточку объекта — раньше могли лечь под них */
{const _tb=tutBlockers;tutBlockers=function(){const out=_tb.apply(this,arguments).slice();try{for(const id of ['tutSk','wcard']){const el=document.getElementById(id);if(!el||el.hidden)continue;const cs=getComputedStyle(el);if(cs.display==='none'||+cs.opacity<.05)continue;const r=el.getBoundingClientRect();if(r.width>0)out.push([r.left-6,r.top-6,r.right+6,r.bottom+6]);}}catch(e){}return out;};}
/* на телефоне «Допуск пилота» встаёт под радио, тост и карточку объекта, а не поверх них (раньше в книжной ориентации всё слипалось вверху) */
function tutSkSidePC132(el){const p=G.player;if(!p)return;const r=el.getBoundingClientRect();const obs=[];try{const [X,Y]=tutSP(p.x,p.y),q=Math.max(30,(p.r||13)*SC+20);obs.push([X-q,Y-q,X+q,Y+q]);}catch(e){}
  const ch=document.querySelector('#tut .tut-chip.on');if(ch&&!$('#tut').hidden){const c=ch.getBoundingClientRect();obs.push([c.left,c.top,c.right,c.bottom]);}
  const fixedObs=[...document.querySelectorAll('#mini,#btnMap,#btnPause,#hud .hud-tl,#toast,#radio')].filter(o=>!o.hidden&&getComputedStyle(o).display!=='none'&&o.getBoundingClientRect().width>1).map(o=>{const q=o.getBoundingClientRect();return [q.left,q.top,q.right,q.bottom];});
  const hitAt=(l)=>obs.concat(fixedObs).some(o=>!(l+r.width<=o[0]||l>=o[2]||r.bottom<=o[1]||r.top>=o[3]));const onRight=el.classList.contains('r132');const lL=16,lR=CW-r.width-16;
  /* справа можно опустить панель под мини-карту, если по центру ей мешает только она */
  const top0=CH/2-r.height/2;const lowT=Math.max(top0,...fixedObs.filter(o=>o[2]>lR&&o[1]<CH/2).map(o=>o[3]+8));const hitAtT=(l,t)=>obs.concat(fixedObs).some(o=>!(l+r.width<=o[0]||l>=o[2]||t+r.height<=o[1]||t>=o[3]));
  const rightOk=t=>t+r.height<=CH-8&&!hitAtT(lR,t);
  if(!onRight&&hitAt(lL)){const t=rightOk(top0)?top0:(rightOk(lowT)?lowT:null);if(t!==null){el.classList.add('r132');el.style.top=(t+r.height/2)+'px';}}
  else if(onRight&&!hitAt(lL)){el.classList.remove('r132');el.style.removeProperty('top');}}
function tutSkStack132(){const el=$('#tutSk');if(!el||el.hidden)return;if(!isMob()){tutSkSidePC132(el);return;}
  const vis=o=>o&&!o.hidden&&getComputedStyle(o).display!=='none'&&+getComputedStyle(o).opacity>.05&&o.getBoundingClientRect().width>1;
  const pops=['radio','toast','wcard','banner'].map(id=>document.getElementById(id)).filter(vis).map(o=>o.getBoundingClientRect()).filter(q=>q.width<CW*.9||q.height>0);{const ch=document.querySelector('#tut .tut-chip.on');if(ch&&!$('#tut').hidden&&vis(ch))pops.push(ch.getBoundingClientRect());}
  const btns=[...document.querySelectorAll('#touch .tbtn,#mini,#btnPause,#joyIdle')].filter(vis).map(o=>o.getBoundingClientRect());
  try{const p=G.player;if(p){const [X,Y]=tutSP(p.x,p.y),q=Math.max(36,(p.r||13)*SC+24);btns.push({left:X-q,top:Y-q,right:X+q,bottom:Y+q});}}catch(e){}/* и не закрывает сам корабль */
  const w=el.offsetWidth,h=el.offsetHeight,hud=document.querySelector('#hud .hud-tl'),min=hud?hud.getBoundingClientRect().bottom+8:52;
  const free=(l,t)=>t+h<=CH-8&&l>=0&&l+w<=CW&&![...pops,...btns].some(q=>!(l+w<=q.left||l>=q.right||t+h<=q.top||t>=q.bottom));
  const L0=Math.max(12,SAFE.l||0),Lc=Math.round((CW-w)/2),ts=[min,...pops.map(q=>q.bottom+8)].filter(t=>t>=min).sort((a,b)=>a-b);
  const mi=document.getElementById('mini'),mb=vis(mi)?mi.getBoundingClientRect().bottom+8:min;const Lr=CW-w-Math.max(12,SAFE.r||0);
  let pk=null;for(const l of [L0,Lc])for(const t of ts){if(!pk&&free(l,t))pk=[l,t];}if(!pk&&free(Lr,mb))pk=[Lr,mb];
  if(!pk){el.style.transition='none';el.style.opacity='0';return;}if(el.style.opacity==='0'){el.style.transition='';el.style.opacity='';}el.style.right='auto';el.style.left=pk[0]+'px';el.style.top=pk[1]+'px';}
{for(const fn of ['updateWorldHUD','updateHUD']){const f=window[fn];if(typeof f!=='function')continue;window[fn]=function(){const r=f.apply(this,arguments);try{tutSkStack132();}catch(e){}return r;};}}

/* стик на узких телефонах заходил на кнопки «КАРТА»/«ИМП» (и у правшей, и у левшей) — отодвигаем к краю, а если мало — выше */
{const _jf=joyFixed;joyFixed=function(){const J=_jf.apply(this,arguments);try{if(!isMob()||!TBR)return J;const bs=Object.values(TBR).filter(b=>b&&b.r>0);const hit=()=>bs.some(b=>Math.hypot(J.x-b.x,J.y-b.y)<J.R+b.r+10);
  if(!hit())return J;const left=SET.hand==='l';J.x=left?CW-SAFE.r-J.R-14:SAFE.l+J.R+14;for(let k=0;k<16&&hit();k++)J.y-=12;}catch(e){}return J;};}
/* подсказка плавающего стика («ДВИЖЕНИЕ») тоже не должна ложиться на кнопки */
{const _lt=layoutTouch;layoutTouch=function(){const r=_lt.apply(this,arguments);try{const I=$('#joyIdle');if(!I||!isMob()||SET.stick==='fixed'||!TBR)return r;const R=joyR();let x=parseFloat(I.style.left)+R+5,y=parseFloat(I.style.top)+R+5;if(!isFinite(x)||!isFinite(y))return r;
  const bs=Object.values(TBR).filter(b=>b&&b.r>0);const hit=()=>bs.some(b=>Math.hypot(x-b.x,y-b.y)<R+b.r+8);if(!hit())return r;const left=SET.hand==='l';x=left?CW-SAFE.r-R-14:SAFE.l+R+14;for(let k=0;k<16&&hit();k++)y-=12;
  I.style.left=(x-R-5)+'px';I.style.top=(y-R-5)+'px';}catch(e){}return r;};}
/* телефон, книжная: карточка объекта сдвигается под тост/радио, если они вверху (раньше тост «ИНЕЙ-4 · ЗАПИСЬ» ложился на карточку) */
function wcardStack132(){const c=$('#wcard');if(!c||c.hidden||G.ff!=='phone-p')return;const base=parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--sat'))||0;
  let want=null;for(const id of ['toast','radio']){const o=document.getElementById(id);if(!o||o.hidden||getComputedStyle(o).display==='none'||+getComputedStyle(o).opacity<.05)continue;const q=o.getBoundingClientRect();if(q.width<2||q.top>CH*.4)continue;want=Math.max(want||0,q.bottom+8);}
  if(want&&want+c.offsetHeight<CH*.55){c.style.top=want+'px';}else c.style.removeProperty('top');}
{const f=window.updateWorldHUD;window.updateWorldHUD=function(){const r=f.apply(this,arguments);try{wcardStack132();}catch(e){}return r;};}

/* подсказка стика («ДВИЖЕНИЕ») не уезжает за край экрана, где бы ни было последнее касание */
function joyIdleClamp132(){const I=$('#joyIdle');if(!I||!isMob())return;const R=joyR();let x=parseFloat(I.style.left)+R+5,y=parseFloat(I.style.top)+R+5;if(!isFinite(x)||!isFinite(y))return;
  const lw=Math.max(R+5,(I.firstElementChild?I.firstElementChild.offsetWidth/2:0)+4);const nx=clamp(x,SAFE.l+lw+6,CW-SAFE.r-lw-6),ny=clamp(y,SAFE.t+R+60,CH-SAFE.b-R-8);if(nx!==x||ny!==y){I.style.left=(nx-R-5)+'px';I.style.top=(ny-R-5)+'px';}}
{for(const fn of ['updateWorldHUD','updateHUD']){const f=window[fn];if(typeof f!=='function')continue;window[fn]=function(){const r=f.apply(this,arguments);try{joyIdleClamp132();}catch(e){}return r;};}}
/* подсказка обучения: если все обычные места заняты (кнопки, панели), ищем ближайшее свободное по вертикали, а не ложимся поверх кнопки */
{const _tp=tutPlace;tutPlace=function(cw,ch,cands,extra){const res=_tp.apply(this,arguments);try{const blk=tutBlockers().concat(extra||[]);const free=(l,t)=>!blk.some(b=>tutInter([l,t,l+cw,t+ch],b));if(free(res[0],res[1]))return res;
  const top=(SAFE.t||0)+8,bot=CH-(SAFE.b||0)-8;for(let d=12;d<=300;d+=12)for(const sg of [-1,1]){const t=res[1]+sg*d;if(t<top||t+ch>bot)continue;if(free(res[0],t))return [res[0],t];}}catch(e){}return res;};}

/* «Допуск пилота» пересчитывает место и вне полёта (карта, вступление к миссии), а на экранах-меню не висит поверх */
setInterval(()=>{try{const el=$('#tutSk');if(!el||el.hidden)return;if(G.state!=='world'&&G.state!=='play'){el.style.transition='none';el.style.opacity='0';return;}tutSkStack132();}catch(e){}},100);

/* ===== 1.3.3 α «Курс без тупиков» =====
   1) ворота калибровки держатся до рывка сквозь луч: радио, бой, уход в миссию, удаление и перезагрузка их больше не снимают;
   2) «лом» и путь к складу — сразу после миссии 01, а не по дороге ко второй;
   3) у миссии 02 карта молчит; после победы в ней — подсветка кнопки карты и подпись в самой карте на 5 с.
   Обучение по-прежнему только смотрит и рисует: ни одна игровая величина не меняется. */

/* ---------- сохранение: прогресс калибровки и флаг подписи в карте переживают перезагрузку ---------- */
{const _tc=tutClean;tutClean=function(t,cleared){const o=_tc.apply(this,arguments);
  try{if(o&&t&&typeof t==='object'&&!Array.isArray(t)){if(t.calS)o.calS=1;const i=Math.round(+t.calI||0);if(i>0&&Number.isFinite(i))o.calI=Math.min(3,i);if(t.jh)o.jh=1;}}catch(e){}
  return o;};}

/* окна «после миссии»: пока открыто одно из них, калибровка ждёт */
function tut133Window(){const T=tutT();if(!T)return false;
  for(const k of ['lom','stash','map']){if(T.done[k])continue;try{if(TUT_L[k].when())return true;}catch(e){}}return false;}

/* ---------- 1. калибровка: повтор до успеха ---------- */
{const _cn=tutCalNew;tutCalNew=function(){const K=_cn.apply(this,arguments);const T=tutT(),p=G.player;const i0=Math.min(3,Math.round(+(T&&T.calI)||0));
  if(i0>0&&K&&p){for(let j=0;j<i0;j++)K.pts[j].done=1;K.i=i0;
    if(i0>=3){/* кольца уже пройдены — ворота ставим поближе, по курсу */let gx=p.x+K.dx*460,gy=p.y+K.dy*460;
      for(const r of G.rocks||[]){if(!r.alive)continue;const d=Math.hypot(r.x-gx,r.y-gy),need=(r.r||20)+80;if(d<need){gx+=-K.dy*(need-d+10);gy+=K.dx*(need-d+10);}}
      K.gate.x=gx;K.gate.y=gy;K.gateOn=performance.now();}}
  return K;};}
{const L=TUT_L.calib,_s=L.step,_v=L.view;
  L.when=function(){const S=G.save,T=tutT(),p=G.player;if(!T||T.done.calib||T.vet||G.prologue||TUT.worldT<1.2||!p)return false;
    if((S.cleared||0)>0&&!T.calS)return false;/* после миссии — только тем, кто её уже начинал */
    if(sectorIdx(p.x,p.y)>1)return false;if(tut133Window())return false;return true;};
  L.step=function(dt,now){const T=tutT(),p=G.player;
    if(T&&!T.calS){T.calS=1;tutSave();}
    const K=TUT.cal;
    if(K&&p){const tgt=K.i<3?K.pts[K.i]:K.gate,d=Math.hypot(p.x-tgt.x,p.y-tgt.y);
      if(d>1800){K.far133=(K.far133||0)+dt;K.far=0;
        if(K.far133>8){/* улетел — трасса едет к игроку, пройденное сохраняется */TUT.cal=tutCalNew();TUT.cal.far133=0;}}
      else K.far133=0;
      K.far=0;}
    const r=_s.apply(this,arguments);
    const K2=TUT.cal;if(T&&K2&&K2.i>(T.calI||0)){T.calI=Math.min(3,K2.i);tutSave();}
    return r;};
  L.view=function(){const K=TUT.cal;const V=_v.apply(this,arguments)||{};if(!K)return V;
    if(K.i>=3&&performance.now()-K.gate.fail<1800){V.text='<b>БЕЗ РЫВКА</b> · ЕЩЁ РАЗ';V.hostile=true;}
    return V;};}
/* перезапуски калибровки не съедают лимит «6 подсказок за 10 минут» */
{const _ts=tutStart;tutStart=function(k){const r=_ts.apply(this,arguments);if(k==='calib'){if(TUT.calSeen133&&TUT.hist.length)TUT.hist.pop();TUT.calSeen133=1;}return r;};}
/* призрак рывка показывает проход со стороны игрока: ворота проходятся в обе стороны */
{const _cd=tutCalDraw;tutCalDraw=function(now){const K=TUT.cal,p=G.player;let flip=false;
  if(K&&p&&K.i>=3){const s=(p.x-K.gate.x)*K.dx+(p.y-K.gate.y)*K.dy;if(s>0){flip=true;K.dx=-K.dx;K.dy=-K.dy;}}
  try{return _cd.apply(this,arguments);}finally{if(flip){K.dx=-K.dx;K.dy=-K.dy;}}};}

/* ---------- 2. «лом» и «склад» — сразу после миссии 01 ---------- */
const TUT133={win:90};
/* 1.3.3 α (вторая правка): эти уроки идут по событию «вернулся из миссии» и не ждут тишины, паузы между подсказками
   и лимита «6 за 10 минут» — в миссии 01 обучение успевает показать 5–7 подсказок, и раньше лом ждал по 10 минут */
{const L=TUT_L.lom,_v=L.view;L.fight=true;
  L.when=function(){const S=G.save;return (S.cleared||0)===1&&TUT.worldT>.8;};
  L.view=function(){const S=G.save;if((S.carry||0)>0)return _v.apply(this,arguments);const el=$('#wLom');
    return {keys:'',text:'<i></i>НАГРАДА <span class="sep">—</span> <b>НА СКЛАДЕ</b>',at:'el',el,ring:[el],ringCls:'amber sq'};};}
{const L=TUT_L.stash,_v=L.view;L.dur=0;L.fight=true;/* дорожка горит, пока игрок не долетит до склада (или не закроет её «✕») */
  L.when=function(){const S=G.save,p=G.player;if((S.cleared||0)!==1||!tutDoneQ('lom'))return false;
    const s=tutShopPt();if(!s||!p)return false;return Math.hypot(s.x-p.x,s.y-p.y)>240;};
  L.view=function(){const S=G.save,V=_v.apply(this,arguments)||{};if(!((S.carry||0)>0))V.text='<i class="a"></i>НА СКЛАД <span class="sep">·</span> <b>УЛУЧШЕНИЯ</b>';return V;};}
/* приоритет: окна «после миссии» идут раньше калибровки и карточки объекта */
{const order=['patrol','dash','pulse','fire','cell','line','lom','stash','map','calib','move','act','energy','jump'];
  const rest=TUT_PRI.filter(k=>!order.includes(k));TUT_PRI.length=0;order.concat(rest).forEach(k=>TUT_PRI.push(k));}
/* склад засчитан: долетел до мастерской, пока горит дорожка, или открыл её */
{const _os=openShop;openShop=function(){const r=_os.apply(this,arguments);try{if(G.state==='shop'&&(G.save.cleared||0)>=1)tutDone('stash');}catch(e){}return r;};}
/* не навязываться: дорожку проигнорировали — больше не показываем, но и галочку не ставим */
{const _e=tutEnd;tutEnd=function(how){const C=TUT.cur,T=tutT();
  if(C&&T&&C.k==='stash'&&how==='miss'&&!T.done.stash){TUT.cur=null;T.done.stash=1;tutSave();TUT.gap=4;tutDomHide('out');return;}
  const r=_e.apply(this,arguments);
  /* «лом» → «склад» идут одной фразой: дорожка появляется сразу за кольцом на счётчике */
  if(C&&C.k==='lom'&&how==='ok'&&T&&(G.save.cleared||0)===1&&!T.done.stash)TUT.gap=.6;
  return r;};}

/* ---------- 3. карта — после миссии 02; прожектор прыжка убран ---------- */
{const L=TUT_L.map;L.dur=14;L.fight=true;L.when=function(){const S=G.save;return (S.cleared||0)===2&&TUT.worldT>.8&&TUT.worldT<TUT133.win;};}
TUT_L.jump.when=function(){return false;};

/* наблюдения: склад рядом, калибровка уступает окнам «после миссии» */
{const _t=tutTick2;tutTick2=function(dt,now){
  try{const S=G.save,T=tutT(),p=G.player;
    /* «лом» → «склад» → «карта»: стартуют сразу, вытесняя любую другую подсказку (кроме кнопки «действие» у самой мастерской) */
    if(T&&tutOn()&&G.state==='world'&&G.world&&p&&!G.prologue&&!(TUT.cur&&(['lom','stash','map'].includes(TUT.cur.k)||TUT.cur.k==='act'&&T.done.lom))){
      for(const k of ['lom','stash','map']){if(T.done[k])continue;if(k==='stash'&&TUT.gap>0)continue;let ok=false;try{ok=TUT_L[k].when();}catch(e){}
        if(ok){if(TUT.cur)tutEnd('abort');TUT.gap=0;tutStart(k);if(TUT.hist.length)TUT.hist.pop();break;}}}
    const C=TUT.cur;
    if(T&&tutOn()&&C&&C.k==='stash'&&G.state==='world'&&p){const s=tutShopPt();if(s&&Math.hypot(s.x-p.x,s.y-p.y)<240)tutDone('stash');}
    if(T&&tutOn()&&C&&C.k==='calib'&&G.state==='world'&&tutCalm()&&tut133Window())tutEnd('abort');
    /* трасса живёт сама: пока подпись спрятана (радио, бой, другой урок), кольца и ворота засчитываются и рисуются */
    if(tut133CalLive()&&!(TUT.cur&&TUT.cur.k==='calib')){const keep=TUT.cur;TUT.cur={k:'calib',L:TUT_L.calib,t:0,shown:0,step:null,ghost:1};
      try{TUT_L.calib.step(dt,now);}finally{if(TUT.cur&&TUT.cur.ghost)TUT.cur=keep;else if(TUT.cur===null)TUT.cur=keep&&!T.done[keep.k]?keep:null;}}}catch(e){}
  return _t.apply(this,arguments);};}

function tut133CalLive(){const T=tutT(),p=G.player;if(!T||!tutOn()||T.done.calib||T.vet||!T.calS||!TUT.cal||!p)return false;
  return G.state==='world'&&G.world&&!G.prologue&&sectorIdx(p.x,p.y)<=1;}
{const _mo=mobOverlay;mobOverlay=function(now){const r=_mo.apply(this,arguments);
  try{const C=TUT.cur;if(tut133CalLive()&&!(C&&(C.k==='calib'||C.k==='lom'||C.k==='stash'))){const c=ctx;c.save();c.setTransform(DPR,0,0,DPR,0,0);try{tutCalDraw(now);}finally{c.restore();}}}catch(e){console.error(e);}
  return r;};}

/* ---------- подпись в карте: одно правило, без цели ---------- */
const JH133={on:false,at:0,t1:0,t2:0,dur:5000};
function jh133Dom(){const box=document.querySelector('#sMap .mapbox');if(!box)return null;let el=$('#mapHint');
  if(!el){el=document.createElement('div');el.id='mapHint';el.setAttribute('role','status');el.setAttribute('aria-live','polite');
    el.innerHTML='<div class="mh-band"><span class="mh-l">НАЖМИ НА ТОЧКУ — ПРЫЖОК</span><span class="mh-s"><i aria-hidden="true"></i>БЕЛЫЕ КОЛЬЦА — ТОЧКИ ПРЫЖКА</span><span class="mh-t" aria-hidden="true"></span></div>';}
  if(el.parentNode!==box)box.appendChild(el);return el;}
function jh133Want(){const S=G.save,T=tutT();if(!S||!T||T.jh||T.vet||!tutOn())return false;if((S.cleared||0)<2)return false;
  if(G.state!=='map'||G.mapTab!=='map'||tutInput()==='pad')return false;if(jumpDenyReason(null))return false;return !!(G.mapPts&&G.mapPts.length);}
function jh133Show(){const el=jh133Dom();if(!el)return;JH133.on=true;JH133.at=performance.now();el.style.setProperty('--mh-d',JH133.dur+'ms');
  el.classList.remove('on','out');void el.offsetWidth;el.classList.add('on');clearTimeout(JH133.t2);JH133.t2=setTimeout(()=>jh133Hide(true),JH133.dur);}
function jh133Hide(full){const el=$('#mapHint');clearTimeout(JH133.t1);clearTimeout(JH133.t2);if(!JH133.on){if(el)el.classList.remove('on');return;}
  const seen=full||performance.now()-JH133.at>=2500;JH133.on=false;if(el){el.classList.remove('on');el.classList.add('out');}
  if(seen){const T=tutT();if(T&&!T.jh){T.jh=1;tutSave();}}}
{const _om=openMap;openMap=function(){const was=G.state;const r=_om.apply(this,arguments);
  try{if(was!=='map'&&G.state==='map'){clearTimeout(JH133.t1);JH133.t1=setTimeout(()=>{try{if(jh133Want())jh133Show();}catch(e){}},650);}}catch(e){}return r;};}
{const _cm=closeMap;closeMap=function(){const was=G.state==='map';const r=_cm.apply(this,arguments);try{if(was&&G.state!=='map')jh133Hide(false);}catch(e){}return r;};}
{const _mt=mapTab;mapTab=function(t){const r=_mt.apply(this,arguments);try{if(t!=='map'&&JH133.on)jh133Hide(false);}catch(e){}return r;};}
/* прыжок совершён — подпись больше не нужна */
/* ARCH·86 · объединённый слой tutEmit: 2 слоя (строки 1.5.25: 14365, 14697) в исходном порядке исполнения */
{const _p86=tutEmit;tutEmit=function(ev_862){const ev_861=arguments[0];if(ev_862==='jump'){try{const T=tutT();if(T&&!T.jh){T.jh=1;tutSave();}if(JH133.on)jh133Hide(true);}catch(e){}}
  if(ev_861==='dash')TUT.lastDashAt=performance.now();
  const r86=_p86.apply(this,arguments);return r86;};}
/* пока подпись на экране — все белые кольца пульсируют одинаково: ни одно не выделено */
/* ARCH·86 · объединённый слой tutMapDraw: 2 слоя (строки 1.5.25: 14416, 14699) в исходном порядке исполнения */
{const _p86=tutMapDraw;tutMapDraw=function(now_862){const now_861=arguments[0];const C_861=TUT.cur;if(C_861&&C_861.k==='jump'&&G.state==='map'&&G.mapTab==='map'&&G.mapXY&&G.player){try{const q=tutJumpPick();const M=G.mapXY,g=$('#mapC').getContext('2d');if(q){g.save();g.setTransform(DPR,0,0,DPR,0,0);
    const sx=M.X(G.player.x),sy=M.Y(G.player.y),t=now_861/1000;g.strokeStyle='rgba(143,233,255,.55)';g.lineWidth=1.5;g.setLineDash([4,6]);g.lineDashOffset=-t*24;g.beginPath();g.moveTo(sx,sy);g.lineTo(q.px,q.py);g.stroke();g.setLineDash([]);
    const f=(t*.6)%1;g.fillStyle='#8fe9ff';g.globalAlpha=.9;g.beginPath();g.arc(sx+(q.px-sx)*f,sy+(q.py-sy)*f,2.5,0,TAU);g.fill();g.restore();}}catch(e){}}
  const r86=_p86.apply(this,arguments);
  try{if(JH133.on&&G.state==='map'&&G.mapTab==='map'&&G.mapPts){const cv=$('#mapC');if(cv){const g=cv.getContext('2d'),t=now_862/1000,q=(t*.9)%1,w=cv.clientWidth,h=cv.clientHeight;
    g.save();g.setTransform(DPR,0,0,DPR,0,0);g.strokeStyle='#ffffff';
    for(const p of G.mapPts){if(p.px<-20||p.px>w+20||p.py<-20||p.py>h+20)continue;g.globalAlpha=(1-q)*.55;g.lineWidth=1.5;g.beginPath();g.arc(p.px,p.py,13+q*16,0,TAU);g.stroke();}
    g.restore();}}}catch(e){}return r86;};}

/* стрелки обучения у края экрана (например «СКЛАД · 4 а.е.») на телефоне обходят кнопки «ЗАРЯД», «КАРТА», «РЫВОК» */
const EA133={at:0,r:[]};
function edgeAvoid133(x,y){if(!isMob())return [x,y];const now=performance.now();
  if(now-EA133.at>250){EA133.at=now;EA133.r=[...document.querySelectorAll('#touch .tbtn')].filter(tutVis).map(b=>{const q=b.getBoundingClientRect();return [q.left-70,q.top-30,q.right+70,q.bottom+24];});}
  for(let n=0;n<4;n++){const hit=EA133.r.find(q=>x>q[0]&&x<q[2]&&y>q[1]&&y<q[3]);if(!hit)break;
    if(hit[0]-6>CW*.55)x=hit[0]-6;else y=hit[1]-6;}
  return [clamp(x,46,CW-46),clamp(y,46,CH-46)];}

/* пока склад не посещён, стрелка «МИССИЯ 02» у края экрана не зовёт дальше: сначала склад, потом — путь ко второй миссии */
function tut133HoldNext(){try{const S=G.save,T=tutT();return !!(S&&T&&tutOn()&&!T.vet&&(S.cleared||0)===1&&!T.done.stash);}catch(e){return false;}}

/* ===== 1.3.4 α «Дорога домой» =====
   1) после миссии 01 через секунду — склад: кольцо на счётчике лома, дорожка и кольцо на самом складе, стрелка «СКЛАД» вместо «МИССИЯ 02».
      Подсказка держится, пока игрок не долетит до склада; радио, баннер и тосты её не гасят. Только потом путь ведёт ко второй миссии;
   2) импульс предлагается только в бою миссии 02 и дальше, когда враги рядом — не в секторе и не у склада;
   3) склад и «Хранилище корпусов» всегда на карте, даже под туманом. */

/* ---------- 1. дом после миссии 01 ---------- */
function tut134Pending(){try{const S=G.save,T=tutT();return !!(S&&T&&tutOn()&&!T.vet&&!T.off&&(S.cleared||0)===1&&!T.done.stash);}catch(e){return false;}}
/* стрелка у края экрана: пока склад не посещён — «СКЛАД», не «МИССИЯ 02» (когда горит дорожка, стрелку рисует сам урок) */
function tut134Home(){if(TUT.cur&&TUT.cur.k==='stash')return null;const s=tutShopPt();return s?{x:s.x,y:s.y,label:'СКЛАД',col:'#ffb84d'}:null;}
TUT_L.lom.when=function(){return false;};/* «лом» теперь часть одного шага «домой» — кольцо на счётчике загорается вместе с дорожкой */
{const L=TUT_L.stash,_v=L.view;L.dur=0;L.fight=true;/* радио, баннер, тост её не снимают */
  L.when=function(){const p=G.player;if(!tut134Pending()||!p||TUT.worldT<.9)return false;if(tutNearFoes(600)>0||p.hp<(G.st&&G.st.maxHp||100)*.35)return false;/* бой свят: стартуем в тишине, радио и баннер не мешают */const s=tutShopPt();if(!s)return false;return Math.hypot(s.x-p.x,s.y-p.y)>240;};
  L.view=function(){const S=G.save,V=_v.apply(this,arguments)||{},el=$('#wLom');
    V.text=(S.carry||0)>0?'<i class="a"></i>ЛОМ <b>НА СКЛАД</b>':'<i class="a"></i>НАГРАДА <span class="sep">—</span> <b>НА СКЛАДЕ</b>';
    if(el&&tutVis(el)){V.ring=[el];V.ringCls='amber sq';}return V;};}
/* «склад» — первый в очереди после боевых: карточка объекта у миссии 01 его не перебивает */
{const order=['patrol','dash','pulse','fire','cell','line','stash','lom','map','calib','move','act','energy','jump'];
  const rest=TUT_PRI.filter(k=>!order.includes(k));TUT_PRI.length=0;order.concat(rest).forEach(k=>TUT_PRI.push(k));}
{const L=TUT_L.act,_w=L.when;L.when=function(){if(tut134Pending()&&!(G.card&&G.card.kind==='shop'))return false;return _w.apply(this,arguments);};}
{const _t=tutTick2;tutTick2=function(dt,now){
  try{const C=TUT.cur,T=tutT();
    if(C&&C.k==='stash'&&T){
      /* ушёл в миссию 02, не заходя на склад, — дорога домой закрыта без галочки */
      if(!tut134Pending()&&!T.done.stash&&(G.save.cleared||0)>=2){TUT.cur=null;tutDomHide('out');T.done.stash=1;tutSave();}
      /* патруль важнее: уступаем, после боя дорожка вернётся */
      else if(G.state==='world'&&!T.done.patrol&&TUT_L.patrol.when())tutEnd('abort');}
    /* долетел до склада — визит засчитан, даже если дорожку в этот момент перебил патруль или карта */
    if(tut134Pending()&&G.state==='world'&&G.player){const s=tutShopPt(),p=G.player;if(s&&Math.hypot(s.x-p.x,s.y-p.y)<240)tutDone('stash');}
    /* дорожка гаснет ровно в момент визита: так «ЛОМ» тоже засчитан */
    if(T&&T.done.stash&&!T.done.lom&&(G.save.cleared||0)>=1){T.done.lom=1;tutSave();}}catch(e){}
  return _t.apply(this,arguments);};}
/* в 1.3.3 игнор дорожки 45 с закрывал урок — теперь он держится до визита */
{const _e=tutEnd;tutEnd=function(how){const C=TUT.cur;if(C&&C.k==='stash'&&how==='miss'&&tut134Pending()){TUT.cur=null;TUT.gap=4;tutDomHide('out');return;}return _e.apply(this,arguments);};}

/* ---------- 2. импульс — только в бою миссии 02+ ---------- */
function tut134PulseOk(R){const p=G.player;return !!p&&G.state==='play'&&!G.world&&(G.m||0)>=2&&tutNearFoes(R)>=1;}
{const L=TUT_L.energy,_w=L.when;L.ctx='mission';L.fight=true;/* показывается именно в бою */L.when=function(){if(!tut134PulseOk(420))return false;return _w.apply(this,arguments);};}
{const L=TUT_L.pulse,_w=L.when;L.ctx='mission';L.when=function(){if(!tut134PulseOk(420))return false;return _w.apply(this,arguments);};}

/* ===== 1.3.5 α «Один курс»: стрелки у края экрана =====
   1) одна цель — одна стрелка: курс, проложенный на карте, и обычная стрелка к следующей миссии больше не рисуются друг на друге;
   2) подписи разных стрелок не наслаиваются — встают одна под другой;
   3) на телефоне тёмная обводка подписи переезжает вместе с текстом (раньше оставалась на старом месте чёрной кляксой). */
const L61={a:[],r:[]};
function l61(){return L61;}
function l61Reset(){L61.a.length=0;L61.r.length=0;}
/* новый проход стрелок: каждый кадр мира начинается с чистого листа; в миссиях — с кадра оверлея */
{const _rw=renderWorld;renderWorld=function(){l61Reset();return _rw.apply(this,arguments);};}
{const _mo=mobOverlay;mobOverlay=function(){if(!G.world)l61Reset();return _mo.apply(this,arguments);};}
/* та же цель уже показана в этом кадре? (ближе 160 ед.) — тогда вторую стрелку не рисуем */
function arw61Dup(x,y){const L=l61();if(L.a.some(q=>Math.hypot(q[0]-x,q[1]-y)<160))return true;L.a.push([x,y]);return false;}
/* место для подписи: если занято другой подписью — сдвиг вниз/вверх */
function lab61Free(cx,cy,hw,h){return !l61().r.some(q=>cx+hw>q[0]&&cx-hw<q[2]&&cy+3>q[1]&&cy-h<q[3]);}
function lab61Add(cx,cy,hw,h){l61().r.push([cx-hw,cy-h-2,cx+hw,cy+5]);}
function lab61Place(cx,cy,hw,h){let y=cy;for(const d of [0,h+6,-(h+6),2*(h+6),-2*(h+6),3*(h+6),-3*(h+6)]){if(lab61Free(cx,cy+d,hw,h)){y=cy+d;break;}}lab61Add(cx,y,hw,h);return y;}

/* ===== 1.4.0 α «Живые корпуса»: 16 поздних корпусов — 8 живых слоёв и свой рывок у каждого =====
   Силуэт не меняется (лор: это копии VØID-013). Меняется поведение: покой, двигатель, след, рывок (старт → полёт → финиш),
   импульс и витрина в «Хранилище корпусов». Только отрисовка: ни одна игровая величина не трогается. */
const SK62={marks:[],dashOn:false,from:null,endT:0,now:0,lastT:0,acc:0,cur:null,prev:false,key:'',buf:[],st:{}};
const SK62_LATE=['archive','rime','izmo','unborn','glyph','argument','shard85','serial013','silence85','callsign013','carrier85','ark90','dawn90','typo100','tidemark100','shore100s'];
/* свой генератор случайных чисел для эффектов: игровой Math.random не тратится, симуляция не меняется */
let VR62=0x9e3779b9;function vr62(){VR62=(VR62*1664525+1013904223)>>>0;return VR62/4294967296;}function vr62r(a,b){return a+vr62()*(b-a);}
function fx62(){return !!SET.fx&&!SET.lessFx&&!G.lowFx;}
function mark62(x,y,life,draw,o){const M=SK62.marks;if(M.length>=40)M.shift();M.push(Object.assign({x,y,t0:SK62.now,life:life*(fx62()?1:.5),draw},o||{}));}
function hull62(s){s=s||1;ctx.beginPath();ctx.moveTo(19*s,0);ctx.lineTo(-11*s,-12*s);ctx.lineTo(-5*s,0);ctx.lineTo(-11*s,12*s);ctx.closePath();}
function ghost62(x,y,a,col,al,lw,fill){ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.globalAlpha=al;hull62();if(fill){ctx.fillStyle=fill;ctx.fill();}ctx.strokeStyle=col;ctx.lineWidth=lw||1.4;ctx.stroke();ctx.restore();}
function ring62(x,y,r,col,al,lw){if(r<=0)return;ctx.globalAlpha=al;ctx.strokeStyle=col;ctx.lineWidth=lw||2;ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.stroke();}
function emit62(dt,rate,fn){if(!fx62())return;SK62.acc+=dt*rate;let n=0;while(SK62.acc>=1&&n<4){SK62.acc-=1;n++;try{fn();}catch(e){}}}
function lerp62(a,b,q){return a+(b-a)*q;}
function path62(m,q){return [lerp62(m.x,m.x2,q),lerp62(m.y,m.y2,q)];}
/* пять чужих букв «Глифа» — короткие штрихи 6×6 */
const GLY62=[g=>{g.beginPath();g.arc(0,0,2.6,.3,4.6);g.moveTo(-3,3);g.lineTo(3,3);g.stroke();},g=>{g.beginPath();g.moveTo(-3,3);g.lineTo(0,-3);g.lineTo(3,3);g.moveTo(-1.5,1);g.lineTo(1.5,1);g.stroke();},
  g=>{g.beginPath();g.moveTo(-3,-3);g.lineTo(3,-3);g.moveTo(0,-3);g.lineTo(0,3);g.moveTo(-2,3);g.lineTo(2,1);g.stroke();},g=>{g.beginPath();for(let i=0;i<=12;i++){const a=i*.6,r=.3*i;g.lineTo(Math.cos(a)*r,Math.sin(a)*r);}g.stroke();},
  g=>{g.beginPath();g.moveTo(-3,-2);g.lineTo(3,-2);g.moveTo(-3,2);g.lineTo(3,2);g.moveTo(-1,-3.5);g.lineTo(1,3.5);g.stroke();}];
function glyph62(i,x,y,s,col,al,rot){ctx.save();ctx.translate(x,y);ctx.rotate(rot||0);ctx.scale(s,s);ctx.globalAlpha=al;ctx.strokeStyle=col;ctx.lineWidth=1.2/s;ctx.lineCap='round';GLY62[((i%5)+5)%5](ctx);ctx.restore();}
/* позывной: «· · ·  — — —  · · ·» настоящим ритмом (точка 0,12 с) */
const MORSE62=(()=>{const u=.12,a=[];const L=(s)=>{for(let i=0;i<s.length;i++){a.push([1,s[i]==='.'?u:3*u]);if(i<s.length-1)a.push([0,u]);}};L('...');a.push([0,3*u]);L('---');a.push([0,3*u]);L('...');a.push([0,7*u]);let T=0;for(const q of a)T+=q[1];return {a,T};})();
function morse62(t){let x=((t%MORSE62.T)+MORSE62.T)%MORSE62.T;for(const [on,d] of MORSE62.a){if(x<d)return on;x-=d;}return 0;}
function beat62(t){return typeof beat90==='function'?beat90(t):Math.pow(Math.max(0,1-((t*50/60)%1)*3.2),2);}

/* ---------- описатели корпусов ---------- */
const SKFX={
archive:{c:'#9fd8ff',
  under(t,sp,k,e){for(let i=2;i>=1;i--){ctx.save();ctx.translate(-i*3-k*i*5,i*1.2*Math.sin(t*1.3+i));ctx.globalAlpha=(.16+.18*k)/i;ctx.strokeStyle='#bfe8ff';ctx.lineWidth=1;ctx.strokeRect(-16,-8,34,16);ctx.restore();}},
  over(t,sp,k,e){const x=-16+((t*.45)%1)*34;const g=ctx.createLinearGradient(x-5,0,x+1,0);g.addColorStop(0,'rgba(191,232,255,0)');g.addColorStop(1,'rgba(223,246,255,.75)');ctx.fillStyle=g;ctx.fillRect(x-5,-8,6,16);
    for(let i=-3;i<=3;i++){const on=((Math.floor(t*6)+i*3)%5)===0;ctx.fillStyle=on?'#ffffff':'rgba(159,216,255,.35)';ctx.fillRect(i*4-.6,-6,1.2,3);ctx.fillRect(i*4-.6,3,1.2,3);}
    if(Math.sin(t*3.1)>.6||e>0){ctx.globalAlpha=.55+.45*Math.max(e,Math.sin(t*9));ctx.fillStyle='#ffffff';ctx.font='700 5px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText('013',2,2);}},
  move(p,t,sp,dt){if(sp>60)emit62(dt,sp/160,()=>{const a=p.ang+Math.PI+vr62r(-.4,.4),r0=vr62r(0,TAU);mark62(p.x-Math.cos(p.ang)*16,p.y-Math.sin(p.ang)*16,.9,(m,q)=>{ctx.save();ctx.translate(m.x+Math.cos(a)*q*30,m.y+Math.sin(a)*q*30);ctx.rotate(r0+q*2.5);ctx.globalAlpha=(1-q)*.7;ctx.strokeStyle='#bfe8ff';ctx.lineWidth=1;ctx.strokeRect(-4,-2.5,8,5);ctx.restore();});});},
  dashStart(p){const x=p.x,y=p.y;mark62(x,y,.6,(m,q)=>{ring62(m.x,m.y,10+q*26,'#dff6ff',(1-q)*.8,2);ctx.globalAlpha=(1-q);ctx.fillStyle='#dff6ff';ctx.font='700 10px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText('013',m.x,m.y-16-q*8);});},
  dash(p,t,k){},
  dashEnd(p,f){const a=f.a;mark62(f.x,f.y,1.3,(m,q)=>{for(let i=0;i<5;i++){const u=i/4,[x,y]=path62(m,u),qq=Math.max(0,q*1.3-u*.3);if(qq>=1)continue;ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.globalAlpha=(1-qq)*.55;ctx.strokeStyle='#bfe8ff';ctx.lineWidth=1.2;ctx.strokeRect(-16,-8,34,16);
      ctx.fillStyle='#dff6ff';ctx.font='700 5px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText(String(13+i).padStart(3,'0'),2,2);ctx.restore();}
    ctx.globalAlpha=Math.max(0,1-q*1.4);ctx.fillStyle='#dff6ff';ctx.font='700 8px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText('ЗАПИСАНО',m.x2,m.y2-22);},{x2:p.x,y2:p.y});},
  pulse(p,R){const x=p.x,y=p.y;mark62(x,y,.7,(m,q)=>{for(let i=0;i<14;i++){const a=i/14*TAU+q;ctx.save();ctx.translate(m.x+Math.cos(a)*R*q,m.y+Math.sin(a)*R*q);ctx.rotate(a+q*4);ctx.globalAlpha=(1-q)*.8;ctx.fillStyle='#dff6ff';ctx.fillRect(-3,-2,6,4);ctx.restore();}});}},

rime:{c:'#e6f6ff',
  under(t,sp,k,e){glow(0,0,26,'#dff6ff',.18+.12*Math.sin(t*1.7));},
  over(t,sp,k,e){const P=SK62.cur;const st=SK62.st.rime||(SK62.st.rime={f:.5});const tgt=P?(sp<40?1:0):.6;st.f+= (tgt-st.f)*.03;const f=st.f;
    ctx.strokeStyle='#ffffff';ctx.lineWidth=1;ctx.globalAlpha=.4+.5*f;for(const s of [-1,1])for(let i=0;i<3;i++){const x=-9+i*7,y=s*(5.5-i*1.5);ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-2-f*4,y+s*(2+f*5));ctx.moveTo(x-1,y+s*1.5);ctx.lineTo(x+1+f*2,y+s*(1+f*3));ctx.stroke();}
    if(f<.5){ctx.globalAlpha=(.5-f)*1.4;ctx.strokeStyle='#9fd8ff';ctx.beginPath();ctx.moveTo(12,-1);ctx.lineTo(4,2);ctx.lineTo(-2,-2);ctx.lineTo(-7,1);ctx.stroke();}
    const tw=(t*2.3)%1;ctx.globalAlpha=Math.sin(tw*Math.PI);ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(-4+tw*10,-3+tw*2,.9,0,TAU);ctx.fill();},
  move(p,t,sp,dt){if(sp>50)emit62(dt,sp/90,()=>part(p.x-Math.cos(p.ang)*14+vr62r(-5,5),p.y-Math.sin(p.ang)*14+vr62r(-5,5),-Math.cos(p.ang)*vr62r(20,60)+vr62r(-15,15),-Math.sin(p.ang)*vr62r(20,60)+vr62r(-15,15),.7,'#ffffff',vr62r(1,2)));},
  dashStart(p){for(let i=0;i<8&&fx62();i++){const a=i/8*TAU;part(p.x,p.y,Math.cos(a)*120,Math.sin(a)*120,.35,'#dff6ff',2);}mark62(p.x,p.y,.4,(m,q)=>ring62(m.x,m.y,6+q*22,'#ffffff',(1-q)*.9,1.5));},
  dashEnd(p,f){const segs=7,seed=vr62()*9;mark62(f.x,f.y,1.4,(m,q)=>{const L=Math.hypot(m.x2-m.x,m.y2-m.y),a=Math.atan2(m.y2-m.y,m.x2-m.x),nx=-Math.sin(a),ny=Math.cos(a);
      for(let i=0;i<segs;i++){const u0=i/segs,u1=(i+1)/segs,crack=Math.max(0,q-.45)/.55,gap=crack*.35,dr=crack*(4+((i*7+seed)%5));const [x0,y0]=path62(m,u0+gap/segs),[x1,y1]=path62(m,u1-gap/segs);const off=(i%2?1:-1)*dr;
        ctx.globalAlpha=(1-q)*.85;ctx.strokeStyle='#e6f6ff';ctx.lineWidth=4*(1-crack*.5);ctx.beginPath();ctx.moveTo(x0+nx*off,y0+ny*off);ctx.lineTo(x1+nx*off,y1+ny*off);ctx.stroke();
        ctx.globalAlpha=(1-q)*.9;ctx.strokeStyle='#ffffff';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x0+nx*(off+1.5),y0+ny*(off+1.5));ctx.lineTo(x1+nx*(off+1.5),y1+ny*(off+1.5));ctx.stroke();}
      if(L<1)return;},{x2:p.x,y2:p.y});},
  pulse(p,R){mark62(p.x,p.y,.8,(m,q)=>{ctx.globalAlpha=(1-q)*.85;ctx.strokeStyle='#ffffff';ctx.lineWidth=1.6;const r=R*q;for(let i=0;i<6;i++){const a=i/6*TAU+q*.6,cx=Math.cos(a),cy=Math.sin(a);ctx.beginPath();ctx.moveTo(m.x,m.y);ctx.lineTo(m.x+cx*r,m.y+cy*r);
      for(const b of [.45,.7]){const bx=m.x+cx*r*b,by=m.y+cy*r*b,l=r*.18;ctx.moveTo(bx,by);ctx.lineTo(bx+Math.cos(a+.6)*l,by+Math.sin(a+.6)*l);ctx.moveTo(bx,by);ctx.lineTo(bx+Math.cos(a-.6)*l,by+Math.sin(a-.6)*l);}ctx.stroke();}});}},

izmo:{c:'#cfefff',
  under(t,sp,k,e){for(let i=0;i<3;i++){const q=((t*.9+i/3)%1);ctx.globalAlpha=(1-q)*.28;ctx.fillStyle='#dff6ff';ctx.beginPath();ctx.arc(-12-q*14,Math.sin(t*2+i)*2,2+q*5,0,TAU);ctx.fill();}},
  over(t,sp,k,e){const g=.5+.5*Math.sin(t*.6);ctx.strokeStyle='rgba(223,246,255,.85)';ctx.lineWidth=.9;for(const s of [-1,1]){ctx.globalAlpha=.5+.4*g;ctx.beginPath();ctx.moveTo(-6,s*4);ctx.lineTo(-6-4*g,s*(6+3*g));ctx.moveTo(-8,s*7);ctx.lineTo(-10-2*g,s*(9+2*g));ctx.moveTo(0,s*3);ctx.lineTo(-2-3*g,s*(5+2*g));ctx.stroke();}
    for(let i=0;i<4;i++){const ph=(t*1.3+i*.37)%1;ctx.globalAlpha=Math.max(0,Math.sin(ph*Math.PI))*.9;ctx.fillStyle='#ffffff';const x=[8,-3,-8,2][i],y=[-2,5,-6,-1][i];ctx.fillRect(x-.5,y-1.5,1,3);ctx.fillRect(x-1.5,y-.5,3,1);}
    if(k>0){ctx.globalAlpha=k*.7;ctx.fillStyle='rgba(230,246,255,.5)';hull62(1.15);ctx.fill();}},
  move(p,t,sp,dt){if(sp>40)emit62(dt,sp/120,()=>part(p.x-Math.cos(p.ang)*12,p.y-Math.sin(p.ang)*12,vr62r(-25,25),vr62r(-25,25),1.1,'#cfefff',vr62r(2,3.5)));},
  dashStart(p){mark62(p.x,p.y,.45,(m,q)=>{glow(m.x,m.y,30*(1-q*.4),'#dff6ff',(1-q)*.9);});},
  dashEnd(p,f){const a=f.a;mark62(f.x,f.y,1.25,(m,q)=>{for(const u of [.25,.55,.85]){const [x,y]=path62(m,u),qq=Math.min(1,q*1.15);ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.globalAlpha=(1-qq)*.7;hull62();ctx.fillStyle='rgba(207,239,255,.35)';ctx.fill();ctx.strokeStyle='#ffffff';ctx.lineWidth=1.2;ctx.stroke();
      if(qq>.45){const c=(qq-.45)/.55;ctx.strokeStyle='#9fd8ff';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(14,0);ctx.lineTo(4,-3*c-1);ctx.lineTo(-2,2);ctx.lineTo(-8,-5*c);ctx.moveTo(4,-3*c-1);ctx.lineTo(0,-8*c);ctx.stroke();
        ctx.fillStyle='#ffffff';for(let j=0;j<4;j++){ctx.globalAlpha=(1-qq)*.8;ctx.fillRect(-6+j*5+c*j*3,(j%2?1:-1)*c*10,1.5,1.5);}}ctx.restore();}},{x2:p.x,y2:p.y});},
  pulse(p,R){mark62(p.x,p.y,.75,(m,q)=>{ring62(m.x,m.y,R*q,'#dff6ff',(1-q)*.8,2);ctx.lineWidth=1.2;ctx.beginPath();for(let i=0;i<24;i++){const a=i/24*TAU,r=R*q;ctx.moveTo(m.x+Math.cos(a)*r,m.y+Math.sin(a)*r);ctx.lineTo(m.x+Math.cos(a)*(r+8+4*(i%2)),m.y+Math.sin(a)*(r+8+4*(i%2)));}ctx.stroke();});}},

unborn:{c:'#ffc2d4',
  under(t,sp,k,e){ctx.strokeStyle='rgba(255,159,184,.45)';ctx.lineWidth=1;ctx.beginPath();for(let i=0;i<=36;i++){const a=i/36*TAU,r=17+1.6*Math.sin(a*5+t*3)+k*6*Math.max(0,-Math.cos(a));ctx.lineTo(Math.cos(a)*r*1.1-k*4,Math.sin(a)*r*.75);}ctx.closePath();ctx.globalAlpha=.6;ctx.stroke();},
  over(t,sp,k,e){const b=beat62(t*1.4);ctx.strokeStyle='#ff6b8a';ctx.lineWidth=.8;ctx.globalAlpha=.35+.55*b;ctx.beginPath();ctx.moveTo(2,0);ctx.quadraticCurveTo(-4,-4,-10,-7);ctx.moveTo(2,0);ctx.quadraticCurveTo(-4,4,-10,7);ctx.moveTo(2,0);ctx.quadraticCurveTo(10,-2,16,0);ctx.stroke();
    for(let i=0;i<3;i++){const q=(t*.5+i/3)%1;ctx.globalAlpha=Math.sin(q*Math.PI)*.8;ctx.fillStyle='#ffe0ea';ctx.beginPath();ctx.arc(-8+q*18,Math.sin(t+i*2)*5,.9,0,TAU);ctx.fill();}
    if(k>0){ctx.globalAlpha=1;glow(2+k*12,0,10,'#ff9fb8',.9);ctx.fillStyle='#ff6b8a';ctx.beginPath();ctx.arc(2+k*12,0,3.4,0,TAU);ctx.fill();}},
  move(p,t,sp,dt){if(sp>50)emit62(dt,sp/200,()=>{const x=p.x-Math.cos(p.ang)*12,y=p.y-Math.sin(p.ang)*12,r=vr62r(2,4),vx=vr62r(-12,12),vy=vr62r(-12,12);mark62(x,y,1.1,(m,q)=>{ctx.globalAlpha=(1-q)*.6;ctx.strokeStyle='#ffc2d4';ctx.lineWidth=.9;ctx.beginPath();ctx.arc(m.x+vx*q,m.y+vy*q-q*8,r*(1+q*.5),0,TAU);ctx.stroke();});});},
  dashStart(p){mark62(p.x,p.y,.5,(m,q)=>{ctx.globalAlpha=(1-q)*.5;ctx.fillStyle='#ffc2d4';ctx.beginPath();ctx.ellipse(m.x,m.y,16*(1-q*.5),11*(1-q*.5),0,0,TAU);ctx.fill();});},
  dashEnd(p,f){mark62(p.x,p.y,.7,(m,q)=>{ring62(m.x,m.y,8+q*30,'#ff9fb8',(1-q)*.8,1.6);for(let i=0;i<6;i++){const a=i/6*TAU+.3;ctx.globalAlpha=(1-q);ctx.fillStyle='#ffe0ea';ctx.beginPath();ctx.arc(m.x+Math.cos(a)*(10+q*36),m.y+Math.sin(a)*(10+q*36),1.8*(1-q)+.4,0,TAU);ctx.fill();}});
    mark62(f.x,f.y,1,(m,q)=>{for(let i=1;i<=4;i++){const [x,y]=path62(m,i/5);ctx.globalAlpha=(1-q)*.55;ctx.strokeStyle='#ffc2d4';ctx.lineWidth=1;ctx.beginPath();ctx.arc(x,y-q*10,3+i+q*3,0,TAU);ctx.stroke();}},{x2:p.x,y2:p.y});},
  pulse(p,R){mark62(p.x,p.y,.9,(m,q)=>{for(let j=0;j<3;j++){const qq=Math.max(0,q-j*.15);if(qq<=0)continue;ctx.globalAlpha=(1-q)*.6;ctx.strokeStyle='#ff9fb8';ctx.lineWidth=2.4-j*.6;ctx.beginPath();for(let i=0;i<=48;i++){const a=i/48*TAU,r=R*qq+3*Math.sin(a*8+q*10);ctx.lineTo(m.x+Math.cos(a)*r,m.y+Math.sin(a)*r);}ctx.closePath();ctx.stroke();}});}},

glyph:{c:'#ff9fb8',
  under(t,sp,k,e){const f=1+Math.sin(t*20)*.15;glyph62(Math.floor(t*4),-15-sp/60,0,.9*f,'#ff6b8a',.75);},
  over(t,sp,k,e){const cur=Math.floor(t/.42)%5;const P=[[10,0],[3,-4],[3,4],[-4,-6],[-4,6]];for(let i=0;i<5;i++){const on=i===cur||k>0||e>.3;glyph62(i,P[i][0],P[i][1],.42,on?'#ffffff':'#ff9fb8',on?1:.22);if(on&&fx62())glow(P[i][0],P[i][1],5,'#ff9fb8',.5);}},
  move(p,t,sp,dt){if(sp>60)emit62(dt,sp/170,()=>{const g=Math.floor(vr62()*5),a=p.ang+Math.PI+vr62r(-.5,.5),r0=vr62r(-1,1);mark62(p.x-Math.cos(p.ang)*14,p.y-Math.sin(p.ang)*14,1,(m,q)=>glyph62(g,m.x+Math.cos(a)*q*26,m.y+Math.sin(a)*q*26,1.2,'#ffd0e0',(1-q)*.75,r0+q*2));});},
  dashStart(p){mark62(p.x,p.y,.45,(m,q)=>{ring62(m.x,m.y,12+q*16,'#ffd0e0',(1-q)*.8,1.4);for(let i=0;i<5;i++){const a=i/5*TAU;glyph62(i,m.x+Math.cos(a)*(14+q*14),m.y+Math.sin(a)*(14+q*14),1.1,'#ffffff',1-q,a);}});},
  dashEnd(p,f){mark62(f.x,f.y,1.5,(m,q)=>{const a=Math.atan2(m.y2-m.y,m.x2-m.x);for(let i=0;i<5;i++){const u=(i+.5)/5,[x,y]=path62(m,u),born=i*.06,die=.5+i*.09,al=q<born?0:q<die?1:Math.max(0,1-(q-die)/.3);glyph62(i,x,y,1.8,'#ffffff',al*.9,a+Math.PI/2);}},{x2:p.x,y2:p.y});},
  pulse(p,R){mark62(p.x,p.y,.9,(m,q)=>{for(let i=0;i<5;i++){const a=i/5*TAU+q*2;glyph62(i,m.x+Math.cos(a)*R*q,m.y+Math.sin(a)*R*q,2.2,'#ffd0e0',1-q,a+q*3);}});}},

argument:{c:'#d6dee8',
  under(t,sp,k,e){const L=10+sp/24+Math.sin(t*40)*1.5;for(const s of [-1,1]){glow(-19,s*5,L,'#b8c4d6',.65);ctx.fillStyle='rgba(230,240,255,.8)';ctx.beginPath();ctx.moveTo(-17,s*5-2);ctx.lineTo(-17-L*.9,s*5);ctx.lineTo(-17,s*5+2);ctx.closePath();ctx.fill();}},
  over(t,sp,k,e){const x=-12+((t*.7)%1)*30;const g=ctx.createLinearGradient(x-6,0,x+6,0);g.addColorStop(0,'rgba(143,233,255,0)');g.addColorStop(.5,'rgba(143,233,255,.95)');g.addColorStop(1,'rgba(143,233,255,0)');ctx.fillStyle=g;ctx.fillRect(Math.max(-12,x-6),-1.5,Math.min(12,26-(x-6)),3);
    const bl=Math.sin(t*5)>.4;ctx.fillStyle=bl?'#ffffff':'#5a6678';ctx.fillRect(9,-9.5,2,2);ctx.fillRect(9,7.5,2,2);ctx.fillStyle=Math.sin(t*5+Math.PI)>.4?'#9fe3ff':'#3a4a5a';ctx.fillRect(-13,-9.5,2,2);ctx.fillRect(-13,7.5,2,2);
    if(k>0){ctx.globalAlpha=k;ctx.strokeStyle='#ffffff';ctx.lineWidth=2.4;ctx.beginPath();ctx.moveTo(22,-12);ctx.lineTo(29,0);ctx.lineTo(22,12);ctx.stroke();glow(26,0,16,'#d6dee8',k*.9);
      ctx.lineWidth=1;for(let i=0;i<4;i++){ctx.globalAlpha=k*.7;ctx.beginPath();ctx.moveTo(-20-i*6,(i-1.5)*6);ctx.lineTo(-34-i*8,(i-1.5)*6);ctx.stroke();}}},
  move(p,t,sp,dt){if(sp>80)emit62(dt,sp/110,()=>{for(const s of [-1,1]){const c=Math.cos(p.ang),si=Math.sin(p.ang);part(p.x-c*20-si*s*5,p.y-si*20+c*s*5,-c*40+vr62r(-10,10),-si*40+vr62r(-10,10),.6,'#b8c4d6',2.4);}});},
  dashStart(p){const a=Math.atan2(p.dy,p.dx);mark62(p.x,p.y,.5,(m,q)=>{ctx.globalAlpha=(1-q)*.8;ctx.strokeStyle='#ffffff';ctx.lineWidth=1.4;ctx.beginPath();for(let i=-3;i<=3;i++){const b=a+Math.PI+i*.22;ctx.moveTo(m.x+Math.cos(b)*(14+q*10),m.y+Math.sin(b)*(14+q*10));ctx.lineTo(m.x+Math.cos(b)*(30+q*30),m.y+Math.sin(b)*(30+q*30));}ctx.stroke();});},
  dashEnd(p,f){const a=f.a;mark62(p.x,p.y,.7,(m,q)=>{ring62(m.x-Math.cos(a)*10,m.y-Math.sin(a)*10,12+q*34,'#d6dee8',(1-q)*.85,2.6-q*1.6);ctx.save();ctx.translate(m.x+Math.cos(a)*18,m.y+Math.sin(a)*18);ctx.rotate(a);ctx.globalAlpha=(1-q)*.8;ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-4-q*6,-12);ctx.lineTo(4+q*4,0);ctx.lineTo(-4-q*6,12);ctx.stroke();ctx.restore();});},
  pulse(p,R){mark62(p.x,p.y,.8,(m,q)=>{ctx.save();ctx.translate(m.x,m.y);ctx.rotate(q*.5);ctx.globalAlpha=(1-q)*.85;ctx.strokeStyle='#ffffff';ctx.lineWidth=2.4;poly(6,Math.max(24,R*q),0);ctx.stroke();ctx.globalAlpha=(1-q)*.25;ctx.fillStyle='#d6dee8';poly(6,Math.max(24,R*q),0);ctx.fill();ctx.restore();});}},

shard85:{c:'#e8d27a',
  under(t,sp,k,e){glow(0,0,22,'#ffd36b',.15+.1*Math.sin(t*7));for(let i=0;i<2;i++){const a=t*(1.6+i*.5)+i*Math.PI;ctx.save();ctx.translate(Math.cos(a)*22,Math.sin(a)*15);ctx.rotate(a*2);ctx.fillStyle='#e8d27a';ctx.globalAlpha=.8;ctx.beginPath();ctx.moveTo(3,0);ctx.lineTo(-2,-2);ctx.lineTo(-1,2);ctx.closePath();ctx.fill();ctx.restore();}},
  alpha(k){return 1-.85*k;},
  over(t,sp,k,e){const pu=.5+.5*Math.sin(t*4);ctx.strokeStyle='#ffd36b';ctx.lineWidth=1.3;ctx.globalAlpha=.3+.7*pu;ctx.shadowColor='#ffd36b';ctx.shadowBlur=4;ctx.beginPath();ctx.moveTo(8,-2);ctx.lineTo(0,3);ctx.lineTo(-6,-4);ctx.moveTo(2,5);ctx.lineTo(-4,8);ctx.stroke();ctx.shadowBlur=0;
    const s=k>0?k:e*e;if(s>0){const d=7*s;ctx.globalAlpha=1;ctx.fillStyle='#14120a';ctx.strokeStyle='#e8d27a';ctx.lineWidth=2;
      ctx.beginPath();ctx.moveTo(19+d,0);ctx.lineTo(4+d,-5);ctx.lineTo(4+d,5);ctx.closePath();ctx.fill();ctx.stroke();
      for(const g of [-1,1]){ctx.beginPath();ctx.moveTo(2,g*(5+d));ctx.lineTo(-11-d*.6,g*(12+d));ctx.lineTo(-5-d*.6,g*(1+d));ctx.closePath();ctx.fill();ctx.stroke();}
      if(k>0){ctx.globalAlpha=k;ctx.strokeStyle='#ffffff';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(4+d,-5);ctx.lineTo(2,-5-d);ctx.moveTo(4+d,5);ctx.lineTo(2,5+d);ctx.stroke();}}},
  move(p,t,sp,dt){if(sp>60)emit62(dt,sp/140,()=>part(p.x-Math.cos(p.ang)*10+vr62r(-6,6),p.y-Math.sin(p.ang)*10+vr62r(-6,6),vr62r(-30,30),vr62r(-30,30),.6,'#e8d27a',vr62r(1.5,2.5)));},
  dashStart(p){for(let i=0;i<10&&fx62();i++)part(p.x,p.y,vr62r(-160,160),vr62r(-160,160),.35,i%2?'#ffffff':'#ffd36b',2);mark62(p.x,p.y,.3,(m,q)=>glow(m.x,m.y,24,'#ffd36b',(1-q)));},
  dashEnd(p,f){const a=f.a;mark62(f.x,f.y,1,(m,q)=>{for(let i=0;i<3;i++){const [x,y]=path62(m,.2+i*.3);ctx.save();ctx.translate(x,y);ctx.rotate(a+(i-1)*.4*q);ctx.globalAlpha=(1-q)*.6;ctx.strokeStyle='#e8d27a';ctx.lineWidth=1.3;ctx.beginPath();if(i===1){ctx.moveTo(10,0);ctx.lineTo(-4,-5);ctx.lineTo(-4,5);}else{ctx.moveTo(2,0);ctx.lineTo(-10,(i-1)*-9);ctx.lineTo(-5,0);}ctx.closePath();ctx.stroke();ctx.restore();}},{x2:p.x,y2:p.y});
    mark62(p.x,p.y,.4,(m,q)=>{ctx.globalAlpha=1-q;ctx.strokeStyle='#ffffff';ctx.lineWidth=1.5;ctx.beginPath();for(let i=0;i<4;i++){const b=i/4*TAU+.4;ctx.moveTo(m.x+Math.cos(b)*4,m.y+Math.sin(b)*4);ctx.lineTo(m.x+Math.cos(b)*(10+q*14),m.y+Math.sin(b)*(10+q*14));}ctx.stroke();});},
  pulse(p,R){const sp=[...Array(12)].map(()=>vr62r(-3,3));mark62(p.x,p.y,.8,(m,q)=>{for(let i=0;i<12;i++){const a=i/12*TAU;ctx.save();ctx.translate(m.x+Math.cos(a)*R*q,m.y+Math.sin(a)*R*q);ctx.rotate(a+q*sp[i]*3);ctx.globalAlpha=(1-q);ctx.fillStyle='#e8d27a';ctx.beginPath();ctx.moveTo(6,0);ctx.lineTo(-3,-3);ctx.lineTo(-2,3);ctx.closePath();ctx.fill();ctx.restore();}});}},

serial013:{c:'#8fe9ff',
  under(t,sp,k,e){ctx.save();ctx.rotate(t*.4);ctx.setLineDash([3,4]);ctx.strokeStyle='rgba(232,210,122,.35)';ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,23,0,TAU);ctx.stroke();ctx.setLineDash([]);for(let i=0;i<8;i++){const a=i/8*TAU;ctx.beginPath();ctx.moveTo(Math.cos(a)*21,Math.sin(a)*21);ctx.lineTo(Math.cos(a)*25,Math.sin(a)*25);ctx.stroke();}ctx.restore();},
  over(t,sp,k,e){ctx.save();hull62();ctx.clip();ctx.strokeStyle='rgba(143,233,255,.22)';ctx.lineWidth=.6;for(let x=-12;x<=20;x+=4){ctx.beginPath();ctx.moveTo(x,-13);ctx.lineTo(x,13);ctx.stroke();}for(let y=-12;y<=12;y+=4){ctx.beginPath();ctx.moveTo(-12,y);ctx.lineTo(20,y);ctx.stroke();}ctx.restore();
    const q=(t*.5)%1;ctx.fillStyle='#e8d27a';for(let i=0;i<5;i++){const u=(q+i/5)%1;ctx.globalAlpha=.9;ctx.fillRect(19-u*30-.6,-u*12-1.5,1.2,3);ctx.fillRect(19-u*30-.6,u*12-1.5,1.2,3);}
    if(k>0||e>0){ctx.globalAlpha=Math.max(k,e);ctx.setLineDash([2,2]);ctx.strokeStyle='#e8d27a';ctx.lineWidth=1;hull62(1.25);ctx.stroke();ctx.setLineDash([]);}},
  move(p,t,sp,dt){if(sp>70)emit62(dt,sp/220,()=>{const a=p.ang;mark62(p.x,p.y,.6,(m,q)=>{ctx.save();ctx.translate(m.x,m.y);ctx.rotate(a);ctx.globalAlpha=(1-q)*.45;ctx.setLineDash([2,3]);ctx.strokeStyle='#8fe9ff';ctx.lineWidth=1;hull62();ctx.stroke();ctx.setLineDash([]);ctx.restore();});});},
  dashStart(p){const a=Math.atan2(p.dy,p.dx);mark62(p.x,p.y,.6,(m,q)=>{ctx.globalAlpha=(1-q)*.85;ctx.strokeStyle='#e8d27a';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(m.x,m.y,26,a+Math.PI-1.2*Math.min(1,q*3),a+Math.PI+1.2*Math.min(1,q*3));ctx.stroke();ctx.fillStyle='#e8d27a';ctx.beginPath();ctx.arc(m.x,m.y,1.6,0,TAU);ctx.fill();});},
  dashEnd(p,f){const a=f.a,d=Math.hypot(p.x-f.x,p.y-f.y),lab=(typeof AUNIT!=='undefined'&&AUNIT>0?(d/AUNIT).toFixed(2).replace('.',',')+' а.е.':Math.round(d)+' ед.');mark62(f.x,f.y,1.4,(m,q)=>{const nx=-Math.sin(a)*22,ny=Math.cos(a)*22;ctx.globalAlpha=(1-q)*.85;ctx.strokeStyle='#e8d27a';ctx.lineWidth=1;
      ctx.beginPath();ctx.moveTo(m.x,m.y);ctx.lineTo(m.x+nx*1.2,m.y+ny*1.2);ctx.moveTo(m.x2,m.y2);ctx.lineTo(m.x2+nx*1.2,m.y2+ny*1.2);ctx.moveTo(m.x+nx,m.y+ny);ctx.lineTo(m.x2+nx,m.y2+ny);ctx.stroke();
      for(const [x,y,s] of [[m.x+nx,m.y+ny,1],[m.x2+nx,m.y2+ny,-1]]){ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(a+s*.4)*6*s,y+Math.sin(a+s*.4)*6*s);ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(a-s*.4)*6*s,y+Math.sin(a-s*.4)*6*s);ctx.stroke();}
      ctx.fillStyle='#e8d27a';ctx.font='700 8px "JetBrains Mono",monospace';ctx.textAlign='center';ctx.fillText(lab,(m.x+m.x2)/2+nx*1.5,(m.y+m.y2)/2+ny*1.5+3);
      for(const u of [.33,.66]){const [x,y]=path62(m,u);ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.globalAlpha=(1-q)*.5;ctx.strokeStyle='#8fe9ff';ctx.lineWidth=.8;hull62();ctx.stroke();ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(-5,0);ctx.stroke();ctx.restore();}},{x2:p.x,y2:p.y});},
  pulse(p,R){mark62(p.x,p.y,.9,(m,q)=>{ctx.setLineDash([4,4]);for(let j=0;j<3;j++){const r=R*q*(.5+j*.25);ring62(m.x,m.y,r,'#e8d27a',(1-q)*.7,1);}ctx.setLineDash([]);ctx.beginPath();for(let i=0;i<36;i++){const a=i/36*TAU,r=R*q;ctx.moveTo(m.x+Math.cos(a)*r,m.y+Math.sin(a)*r);ctx.lineTo(m.x+Math.cos(a)*(r-(i%3?3:7)),m.y+Math.sin(a)*(r-(i%3?3:7)));}ctx.stroke();});}},

silence85:{c:'#3a4258',
  under(t,sp,k,e){const g=ctx.createRadialGradient(0,0,4,0,0,34);g.addColorStop(0,'rgba(0,0,0,.55)');g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,34,0,TAU);ctx.fill();
    /* звёздный свет огибает корпус: три дуги линзы */ctx.strokeStyle='#9fb0c4';ctx.lineWidth=.8;for(let i=0;i<3;i++){const a=t*.5+i*TAU/3;ctx.globalAlpha=.18+.1*Math.sin(t*1.7+i);ctx.beginPath();ctx.arc(0,0,27+1.5*Math.sin(t+i),a,a+1.1);ctx.stroke();}},
  alpha(k){return 1-.7*k;},
  over(t,sp,k,e){ctx.globalAlpha=.3+.25*Math.sin(t*2.3)+.4*k;ctx.strokeStyle='#9fb0c4';ctx.lineWidth=1;hull62();ctx.stroke();
    const u=(t*.6)%1,pts=[[19,0],[-11,-12],[-5,0],[-11,12],[19,0]],seg=u*4,i=Math.floor(seg),f=seg-i,a=pts[i],b=pts[i+1];ctx.globalAlpha=.9;ctx.fillStyle='#cfe0ff';ctx.beginPath();ctx.arc(a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f,1.1,0,TAU);ctx.fill();},
  move(p,t,sp,dt){if(sp>60)emit62(dt,sp/120,()=>{const x=p.x-Math.cos(p.ang)*10,y=p.y-Math.sin(p.ang)*10;mark62(x,y,.9,(m,q)=>{const g=ctx.createRadialGradient(m.x,m.y,0,m.x,m.y,16);g.addColorStop(0,`rgba(0,0,0,${(.45*(1-q)).toFixed(3)})`);g.addColorStop(1,'rgba(0,0,0,0)');ctx.globalAlpha=1;ctx.fillStyle=g;ctx.beginPath();ctx.arc(m.x,m.y,16,0,TAU);ctx.fill();});});},
  dashStart(p){mark62(p.x,p.y,.4,(m,q)=>{ring62(m.x,m.y,30*(1-q),'#9fb0c4',(1-q)*.8,1.2);ctx.globalAlpha=(1-q)*.6;ctx.fillStyle='#000';ctx.beginPath();ctx.arc(m.x,m.y,22*(1-q),0,TAU);ctx.fill();});},
  dashEnd(p,f){mark62(f.x,f.y,.9,(m,q)=>{ctx.globalAlpha=(1-q)*.35;ctx.strokeStyle='#9fb0c4';ctx.lineWidth=1;ctx.setLineDash([1,6]);ctx.beginPath();ctx.moveTo(m.x,m.y);ctx.lineTo(m.x2,m.y2);ctx.stroke();ctx.setLineDash([]);},{x2:p.x,y2:p.y});
    mark62(p.x,p.y,.55,(m,q)=>{const r=34*(1-q);ctx.globalAlpha=(1-q)*.55;ctx.fillStyle='#000';ctx.beginPath();ctx.arc(m.x,m.y,r,0,TAU);ctx.fill();ring62(m.x,m.y,r,'#cfe0ff',(1-q)*.9,1.4);});},
  pulse(p,R){mark62(p.x,p.y,.8,(m,q)=>{ctx.globalAlpha=(1-q)*.5;ctx.strokeStyle='#000';ctx.lineWidth=10;ctx.beginPath();ctx.arc(m.x,m.y,R*q,0,TAU);ctx.stroke();ring62(m.x,m.y,R*q+5,'#9fb0c4',(1-q)*.85,1.2);});}},

callsign013:{c:'#6b8cff',
  under(t,sp,k,e){const on=morse62(t);glow(0,0,24,'#6b8cff',on?.45:.12);},
  over(t,sp,k,e){const on=morse62(t);ctx.fillStyle=on?'#cfe0ff':'rgba(107,140,255,.35)';for(const [x,y] of [[-9,-9],[-9,9],[6,0]]){ctx.beginPath();ctx.arc(x,y,on?2.4:1.6,0,TAU);ctx.fill();if(on)glow(x,y,7,'#9fb8ff',.8);}
    if(on){for(let i=0;i<2;i++){const q=((t*2.2+i*.5)%1);ctx.globalAlpha=(1-q)*.8;ctx.strokeStyle='#cfe0ff';ctx.lineWidth=1;ctx.beginPath();ctx.arc(19,0,3+q*9,-.7,.7);ctx.stroke();}}
    if(k>0){for(let i=0;i<3;i++){ctx.globalAlpha=k*(1-i*.25);ctx.strokeStyle='#cfe0ff';ctx.lineWidth=1.4;ctx.beginPath();ctx.arc(19,0,8+i*7+(1-k)*10,-.6,.6);ctx.stroke();}}},
  move(p,t,sp,dt){const on=morse62(t);const st=SK62.st.cs||(SK62.st.cs={last:0});if(sp>40&&on&&!st.last&&fx62()){const x=p.x-Math.cos(p.ang)*14,y=p.y-Math.sin(p.ang)*14;mark62(x,y,1.1,(m,q)=>{ctx.globalAlpha=(1-q)*.85;ctx.fillStyle='#9fb8ff';ctx.beginPath();ctx.arc(m.x,m.y,2.2,0,TAU);ctx.fill();ring62(m.x,m.y,2+q*10,'#6b8cff',(1-q)*.5,1);});}st.last=on;},
  dashStart(p){const a=Math.atan2(p.dy,p.dx);mark62(p.x,p.y,.5,(m,q)=>{for(let i=0;i<3;i++){const r=14+i*10+q*30;ctx.globalAlpha=(1-q)*(1-i*.25);ctx.strokeStyle='#cfe0ff';ctx.lineWidth=1.6;ctx.beginPath();ctx.arc(m.x,m.y,r,a-.5,a+.5);ctx.stroke();}});},
  dashEnd(p,f){mark62(f.x,f.y,1.3,(m,q)=>{const code=[1,1,1,0,3,3,3,0,1,1,1];const n=code.length;ctx.lineCap='round';for(let i=0;i<n;i++){if(!code[i])continue;const u0=i/n,u1=u0+(code[i]===3?.07:.02),[x0,y0]=path62(m,u0),[x1,y1]=path62(m,Math.min(1,u1)),al=Math.max(0,Math.min(1,(q*3-u0))*(1-q));
      ctx.globalAlpha=Math.min(1,al*1.5);ctx.strokeStyle='#cfe0ff';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x1+.01,y1);ctx.stroke();}ctx.lineCap='butt';},{x2:p.x,y2:p.y});
    mark62(p.x,p.y,.8,(m,q)=>{for(let i=0;i<3;i++){const qq=q-i*.12;if(qq>0)ring62(m.x,m.y,6+qq*32,'#9fb8ff',(1-q)*.8,1.4);}});},
  pulse(p,R){mark62(p.x,p.y,1,(m,q)=>{const d=[0,.06,.12,.28,.4,.52];for(let i=0;i<6;i++){const qq=q-d[i];if(qq<=0)continue;ring62(m.x,m.y,R*Math.min(1,qq*1.3),i<3?'#cfe0ff':'#6b8cff',(1-q)*.8,i<3?1.2:3);}});}},

carrier85:{c:'#ffffff',
  under(t,sp,k,e){glow(0,0,24,'#ffffff',.14+.08*Math.sin(t*1.2));},
  over(t,sp,k,e){ctx.strokeStyle='rgba(107,140,255,.6)';ctx.lineWidth=.8;for(const s of [-1,1]){ctx.beginPath();for(let i=0;i<=14;i++){const u=i/14,x=19-u*30,y=s*u*12+Math.sin(u*14-t*9)*1.2;ctx.lineTo(x,y);}ctx.stroke();}
    for(let i=0;i<5;i++){const h=2+3*Math.abs(Math.sin(t*7+i*1.3));ctx.fillStyle=i===2?'#ffffff':'#9fb8ff';ctx.globalAlpha=.85;ctx.fillRect(-16-i*0,(-2+i)*2.2-1,-h,1.6);}
    if(k>0){ctx.globalAlpha=k;ctx.strokeStyle='#ffffff';ctx.lineWidth=1.6;ctx.beginPath();for(let i=0;i<=30;i++){const x=-10-i*1.6;ctx.lineTo(x,Math.sin(i*.9-t*20)*8*k*(1-i/34));}ctx.stroke();}},
  move(p,t,sp,dt){},
  trail:true,
  dashStart(p){const a=Math.atan2(p.dy,p.dx);mark62(p.x,p.y,.4,(m,q)=>{for(let i=0;i<3;i++){ctx.globalAlpha=(1-q)*(1-i*.3);ctx.strokeStyle='#ffffff';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(m.x,m.y,8+i*6+q*14,a+Math.PI-.8,a+Math.PI+.8);ctx.stroke();}});},
  dashEnd(p,f){mark62(f.x,f.y,1.1,(m,q)=>{const a=Math.atan2(m.y2-m.y,m.x2-m.x),nx=-Math.sin(a),ny=Math.cos(a);ctx.lineWidth=1.8;ctx.strokeStyle='#ffffff';ctx.beginPath();const N=40;for(let i=0;i<=N;i++){const u=i/N;if(u<q*1.1-.1)continue;const [x,y]=path62(m,u),A=10*(1-q)*Math.sin(u*Math.PI),w=Math.sin(u*28-q*14)*A;ctx.lineTo(x+nx*w,y+ny*w);}ctx.globalAlpha=(1-q)*.9;ctx.stroke();},{x2:p.x,y2:p.y});},
  pulse(p,R){mark62(p.x,p.y,.9,(m,q)=>{ctx.globalAlpha=(1-q)*.85;ctx.strokeStyle='#ffffff';ctx.lineWidth=1.6;ctx.beginPath();for(let i=0;i<=72;i++){const a=i/72*TAU,r=R*q+6*(1-q)*Math.sin(a*12+q*20);ctx.lineTo(m.x+Math.cos(a)*r,m.y+Math.sin(a)*r);}ctx.closePath();ctx.stroke();ring62(m.x,m.y,R*q*.8,'#6b8cff',(1-q)*.5,1);});}},

ark90:{c:'#ffd36b',
  under(t,sp,k,e){const b=beat62(t);glow(0,0,20+8*b,'#d8364a',.25+.35*b);},
  over(t,sp,k,e){const b=beat62(t);ctx.strokeStyle='#d8364a';ctx.lineWidth=1;ctx.globalAlpha=.35+.6*b;ctx.beginPath();ctx.moveTo(2,0);ctx.lineTo(-9,-9);ctx.moveTo(2,0);ctx.lineTo(-9,9);ctx.moveTo(2,0);ctx.lineTo(16,0);ctx.moveTo(-2,0);ctx.lineTo(-6,0);ctx.stroke();
    ctx.globalAlpha=1;for(let i=0;i<6;i++){const x=-7+(i%3)*5,y=i<3?-4:4,on=Math.sin(t*.8+i*2.1)>-.3;ctx.fillStyle=on?'#ffe9b0':'#5a2a1a';ctx.fillRect(x-.7,y-.7,1.4,1.4);}
    if(k>0){ctx.globalAlpha=k;glow(2,0,18,'#ffd36b',k);}},
  move(p,t,sp,dt){if(sp>50)emit62(dt,sp/130,()=>part(p.x-Math.cos(p.ang)*12+vr62r(-4,4),p.y-Math.sin(p.ang)*12+vr62r(-4,4),vr62r(-20,20),vr62r(-20,20),.8,vr62()<.6?'#d8364a':'#ffd36b',vr62r(1.6,2.6)));},
  dashStart(p){mark62(p.x,p.y,.45,(m,q)=>{ring62(m.x,m.y,8+q*28,'#d8364a',(1-q)*.9,3*(1-q)+.5);});},
  dashEnd(p,f){mark62(f.x,f.y,1.3,(m,q)=>{const a=Math.atan2(m.y2-m.y,m.x2-m.x),nx=-Math.sin(a),ny=Math.cos(a);ctx.globalAlpha=(1-q)*.95;ctx.strokeStyle='#ffd36b';ctx.lineWidth=1.6;ctx.lineJoin='round';ctx.beginPath();
      const ecg=u=>{const z=(u*2)%1;return z<.38?0:z<.42?-3:z<.46?14:z<.5?-9:z<.54?2:z<.7?Math.sin((z-.54)/.16*Math.PI)*3:0;};const N=50;for(let i=0;i<=N;i++){const u=i/N;if(u>Math.min(1,q*4))break;const [x,y]=path62(m,u),w=ecg(u);ctx.lineTo(x+nx*w,y+ny*w);}ctx.stroke();},{x2:p.x,y2:p.y});
    mark62(p.x,p.y,.8,(m,q)=>{ring62(m.x,m.y,6+q*30,'#d8364a',(1-q)*.8,2);const q2=q-.3;if(q2>0)ring62(m.x,m.y,6+q2*30,'#ffd36b',(1-q)*.8,1.6);});},
  pulse(p,R){mark62(p.x,p.y,1,(m,q)=>{ring62(m.x,m.y,R*Math.min(1,q*1.4),'#d8364a',(1-q)*.85,4*(1-q)+1);const q2=q-.22;if(q2>0)ring62(m.x,m.y,R*Math.min(1,q2*1.4),'#ffd36b',(1-q)*.85,3*(1-q)+1);});}},

dawn90:{c:'#ffe9b0',
  under(t,sp,k,e){glow(0,0,24,'#ffd36b',.22+.1*Math.sin(t));const gl=Math.max(0,Math.sin(t*1.3))**8;if(gl>.05){ctx.globalAlpha=gl;ctx.strokeStyle='#fff6d8';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(19-7,0);ctx.lineTo(19+7,0);ctx.moveTo(19,-7);ctx.lineTo(19,7);ctx.stroke();}},
  over(t,sp,k,e){ctx.save();hull62();ctx.clip();const x=-14+((t*.25)%1)*40;const g=ctx.createLinearGradient(x-14,0,x+14,0);g.addColorStop(0,'rgba(255,211,107,0)');g.addColorStop(.5,'rgba(255,233,176,.55)');g.addColorStop(1,'rgba(255,211,107,0)');ctx.fillStyle=g;ctx.fillRect(-12,-13,32,26);ctx.restore();
    const n=Math.floor(t*1.5)%6;for(let i=0;i<4;i++){const on=i<n||n>4;ctx.globalAlpha=on?1:.3;ctx.fillStyle='#fff6d8';ctx.fillRect(-6+i*5,-1.5,2.5,3);if(on&&fx62())glow(-5+i*5,0,4,'#ffe9b0',.6);}
    if(k>0){ctx.globalAlpha=k;const g2=ctx.createLinearGradient(-60,0,24,0);g2.addColorStop(0,'rgba(255,211,107,0)');g2.addColorStop(1,'rgba(255,246,216,.95)');ctx.fillStyle=g2;ctx.fillRect(-60,-1.5,84,3);glow(19,0,14,'#fff6d8',k);}},
  move(p,t,sp,dt){if(sp>50)emit62(dt,sp/150,()=>part(p.x-Math.cos(p.ang)*12+vr62r(-6,6),p.y-Math.sin(p.ang)*12+vr62r(-6,6),vr62r(-14,14),vr62r(-24,-4),1.1,'#ffe9b0',vr62r(1.2,2.2)));},
  dashStart(p){mark62(p.x,p.y,.35,(m,q)=>{glow(m.x,m.y,30,'#fff6d8',(1-q)*.9);});},
  dashEnd(p,f){mark62(f.x,f.y,1,(m,q)=>{const g=ctx.createLinearGradient(m.x,m.y,m.x2,m.y2);g.addColorStop(0,'rgba(255,211,107,0)');g.addColorStop(1,`rgba(255,246,216,${(.85*(1-q)).toFixed(3)})`);ctx.globalAlpha=1;ctx.strokeStyle=g;ctx.lineWidth=5*(1-q)+1;ctx.beginPath();ctx.moveTo(m.x,m.y);ctx.lineTo(m.x2,m.y2);ctx.stroke();},{x2:p.x,y2:p.y});
    const a=f.a;mark62(p.x,p.y,.8,(m,q)=>{ctx.globalAlpha=(1-q)*.8;ctx.strokeStyle='#ffe9b0';ctx.lineWidth=1.4;ctx.beginPath();for(let i=-3;i<=3;i++){const b=a+i*.28;ctx.moveTo(m.x+Math.cos(b)*10,m.y+Math.sin(b)*10);ctx.lineTo(m.x+Math.cos(b)*(24+q*30),m.y+Math.sin(b)*(24+q*30));}ctx.stroke();});},
  pulse(p,R){mark62(p.x,p.y,.9,(m,q)=>{ctx.globalAlpha=(1-q)*.85;ctx.strokeStyle='#ffe9b0';ctx.lineWidth=2;ctx.beginPath();for(let i=0;i<12;i++){const a=i/12*TAU+q*.4,r0=R*q*.5,r1=R*q*(i%2?.8:1.05);ctx.moveTo(m.x+Math.cos(a)*r0,m.y+Math.sin(a)*r0);ctx.lineTo(m.x+Math.cos(a)*r1,m.y+Math.sin(a)*r1);}ctx.stroke();glow(m.x,m.y,30*(1-q),'#fff6d8',(1-q)*.7);});}},

typo100:{c:'#b8ffe0',
  under(t,sp,k,e){glow(0,0,20,'#7affc9',.18);},
  over(t,sp,k,e){ctx.strokeStyle='#ffffff';ctx.lineWidth=.8;ctx.setLineDash([1.2,1.2]);ctx.globalAlpha=.7;ctx.beginPath();ctx.moveTo(8,-6);ctx.lineTo(8,6);ctx.moveTo(-3,-9);ctx.lineTo(-3,9);ctx.stroke();ctx.setLineDash([]);
    const j=i=>Math.sin(t*(13+i*5))>.93?(i%2?1.5:-1.5):0;ctx.save();ctx.translate(j(0),0);ctx.globalAlpha=.55;ctx.strokeStyle='#7affc9';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(19,0);ctx.lineTo(8,-4);ctx.moveTo(19,0);ctx.lineTo(8,4);ctx.stroke();ctx.restore();
    ctx.save();ctx.translate(0,j(1));ctx.globalAlpha=.55;ctx.strokeStyle='#e0fff4';ctx.beginPath();ctx.moveTo(-3,-9);ctx.lineTo(-11,-12);ctx.moveTo(-3,9);ctx.lineTo(-11,12);ctx.stroke();ctx.restore();
    if(Math.sin(t*7.3)>.85){ctx.globalAlpha=.9;ctx.fillStyle=Math.sin(t*31)>0?'#7affc9':'#ffffff';for(let i=0;i<3;i++)ctx.fillRect(-8+((t*97+i*13)%24),((t*61+i*7)%20)-10,2,2);}
    if(k>0){const d=6*k;for(const [c,dy] of [['#7affc9',-d],['#ffffff',0],['#6bf0ff',d]]){ctx.save();ctx.translate(-d*.6,dy);ctx.globalAlpha=k*.7;ctx.strokeStyle=c;ctx.lineWidth=1.2;hull62();ctx.stroke();ctx.restore();}}},
  move(p,t,sp,dt){if(sp>60)emit62(dt,sp/120,()=>{const x=p.x-Math.cos(p.ang)*12+vr62r(-8,8),y=p.y-Math.sin(p.ang)*12+vr62r(-8,8),c=vr62()<.5?'#7affc9':'#ffffff',s=vr62r(1.5,3);mark62(x,y,.5,(m,q)=>{if(Math.sin(q*40)>0)return;ctx.globalAlpha=(1-q);ctx.fillStyle=c;ctx.fillRect(m.x+(q>.5?2:0),m.y,s,s);});});},
  dashStart(p){const a=Math.atan2(p.dy,p.dx);mark62(p.x,p.y,.35,(m,q)=>{ctx.save();ctx.translate(m.x,m.y);ctx.rotate(a);ctx.globalAlpha=(1-q)*.8;for(let i=-3;i<=3;i++){ctx.fillStyle=i%2?'#7affc9':'#ffffff';ctx.fillRect(-14+(i*7%5)*q*6,i*4,22,1.5);}ctx.restore();});},
  dashEnd(p,f){const a=f.a,offs=[[-10,-8,'#7affc9'],[-6,0,'#ffffff'],[-10,8,'#6bf0ff']];mark62(p.x,p.y,.45,(m,q)=>{const s=1-Math.min(1,q*2.2);for(const [ox,oy,c] of offs){ctx.save();ctx.translate(m.x,m.y);ctx.rotate(a);ctx.translate(ox*s,oy*s);ctx.globalAlpha=(1-q)*.8;ctx.strokeStyle=c;ctx.lineWidth=1.3;hull62();ctx.stroke();ctx.restore();}if(q>.45&&q<.6)ring62(m.x,m.y,16,'#ffffff',.9,1);});
    mark62(f.x,f.y,.7,(m,q)=>{for(let i=0;i<6;i++){const [x,y]=path62(m,i/6);if((i+Math.floor(q*10))%2)continue;ctx.globalAlpha=(1-q)*.7;ctx.fillStyle=i%2?'#7affc9':'#ffffff';ctx.fillRect(x-3,y-1,6,2);}},{x2:p.x,y2:p.y});},
  pulse(p,R){const jit=[...Array(16)].map(()=>vr62r(-8,8));mark62(p.x,p.y,.8,(m,q)=>{ctx.globalAlpha=(1-q)*.85;ctx.strokeStyle='#7affc9';ctx.lineWidth=2;const r=R*q;ctx.beginPath();for(let i=0;i<16;i++){const s=i%4,u=(i%4)/4,side=Math.floor(i/4);const pts=[[-r,-r],[r,-r],[r,r],[-r,r]],A=pts[side],B=pts[(side+1)%4];ctx.lineTo(A[0]+(B[0]-A[0])*u+m.x+jit[i]*(1-q),A[1]+(B[1]-A[1])*u+m.y);}ctx.closePath();ctx.stroke();});}},

tidemark100:{c:'#7affc9',
  under(t,sp,k,e){glow(0,0,22,'#7affc9',.16+.08*Math.sin(t*1.2));},
  over(t,sp,k,e){const lv=Math.sin(t*1.2)*4+(k>0?-4*k:0);ctx.save();hull62();ctx.clip();ctx.fillStyle='rgba(122,255,201,.32)';ctx.beginPath();ctx.moveTo(-14,14);for(let x=-14;x<=20;x+=2)ctx.lineTo(x,lv+Math.sin(x*.5+t*3)*1.1);ctx.lineTo(20,14);ctx.closePath();ctx.fill();
    ctx.strokeStyle='#d8fff0';ctx.lineWidth=.9;ctx.beginPath();for(let x=-14;x<=20;x+=2)ctx.lineTo(x,lv+Math.sin(x*.5+t*3)*1.1);ctx.stroke();ctx.restore();
    const dq=(t*1.1)%1;ctx.globalAlpha=Math.sin(dq*Math.PI);ctx.fillStyle='#d8fff0';ctx.beginPath();ctx.arc(-11-dq*6,12+dq*3,1,0,TAU);ctx.fill();},
  trail:true,
  move(p,t,sp,dt){},
  dashStart(p){for(let i=0;i<10&&fx62();i++){const a=Math.atan2(p.dy,p.dx)+Math.PI+vr62r(-1.1,1.1);part(p.x,p.y,Math.cos(a)*vr62r(60,150),Math.sin(a)*vr62r(60,150),.45,i%3?'#d8fff0':'#7affc9',vr62r(1.5,2.5));}},
  dashEnd(p,f){mark62(f.x,f.y,1.2,(m,q)=>{const a=Math.atan2(m.y2-m.y,m.x2-m.x),nx=-Math.sin(a),ny=Math.cos(a);for(const s of [-1,1]){ctx.globalAlpha=(1-q)*.8;ctx.strokeStyle='#d8fff0';ctx.lineWidth=1.6;ctx.beginPath();const N=16;for(let i=0;i<=N;i++){const u=i/N,[x,y]=path62(m,u),w=s*(2+(1-u)*(18+q*16))+Math.sin(u*12+q*8)*1.5;ctx.lineTo(x+nx*w,y+ny*w);}ctx.stroke();
      ctx.fillStyle='#ffffff';for(let i=0;i<6;i++){const u=i/6,[x,y]=path62(m,u),w=s*(2+(1-u)*(18+q*16));ctx.globalAlpha=(1-q)*.7;ctx.fillRect(x+nx*w-1,y+ny*w-1,2,2);}}},{x2:p.x,y2:p.y});
    mark62(p.x,p.y,.6,(m,q)=>{for(let i=0;i<7;i++){const a=i/7*TAU,r=6+q*22;ctx.globalAlpha=(1-q);ctx.fillStyle='#d8fff0';ctx.beginPath();ctx.arc(m.x+Math.cos(a)*r,m.y+Math.sin(a)*r-q*q*10,1.6,0,TAU);ctx.fill();}});},
  pulse(p,R){mark62(p.x,p.y,1,(m,q)=>{ctx.globalAlpha=(1-q)*.8;ctx.strokeStyle='#7affc9';ctx.lineWidth=3;ctx.beginPath();for(let i=0;i<=64;i++){const a=i/64*TAU,r=R*q+4*Math.sin(a*6-q*12);ctx.lineTo(m.x+Math.cos(a)*r,m.y+Math.sin(a)*r);}ctx.closePath();ctx.stroke();ring62(m.x,m.y,R*q-6,'#d8fff0',(1-q)*.6,1);});}},

shore100s:{c:'#f4fff9',
  under(t,sp,k,e){glow(0,0,22,'#ffffff',.14);for(let i=0;i<8;i++){const a=t*.35+i*.785,r=20+3*Math.sin(t+i);ctx.globalAlpha=.55;ctx.fillStyle='#f4fff9';ctx.fillRect(Math.cos(a)*r-.6,Math.sin(a)*r*.8-.6,1.2,1.2);}},
  alpha(k){return 1-.75*k;},
  over(t,sp,k,e){ctx.save();ctx.strokeStyle='#070c16';ctx.lineWidth=2.6;ctx.setLineDash([3,9]);ctx.lineDashOffset=-t*12;ctx.globalAlpha=.85;hull62();ctx.stroke();ctx.restore();
    const s=k>0?k:e*.6;if(s>0){ctx.fillStyle='#ffffff';for(let i=0;i<22;i++){const a=i*2.4,r=(i%7)*2.4,x=Math.cos(a)*r*1.3+2,y=Math.sin(a)*r*.9;ctx.globalAlpha=s;ctx.fillRect(x-s*(8+i%5)*1.4-.7,y+Math.sin(i)*s*6-.7,1.4,1.4);}}},
  move(p,t,sp,dt){if(sp>50)emit62(dt,sp/140,()=>part(p.x-Math.cos(p.ang)*12+vr62r(-5,5),p.y-Math.sin(p.ang)*12+vr62r(-5,5),vr62r(-8,8),vr62r(-8,8),1.3,'#f4fff9',vr62r(1,1.8)));},
  dashStart(p){mark62(p.x,p.y,.5,(m,q)=>{ctx.globalAlpha=(1-q)*.6;ctx.fillStyle='#f4fff9';for(let i=0;i<16;i++){const a=i/16*TAU;ctx.fillRect(m.x+Math.cos(a)*(6+q*20)-1,m.y+Math.sin(a)*(6+q*20)-1,2,2);}});},
  dashEnd(p,f){const a=f.a;mark62(f.x,f.y,1.5,(m,q)=>{const L=Math.hypot(m.x2-m.x,m.y2-m.y),n=Math.max(2,Math.floor(L/16));for(let i=0;i<n;i++){const u=(i+.5)/n,[x,y]=path62(m,u),s=i%2?1:-1;ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.globalAlpha=(1-q)*.55;ctx.fillStyle='#f4fff9';ctx.beginPath();ctx.ellipse(0,s*5,3,1.7,0,0,TAU);ctx.fill();ctx.restore();}},{x2:p.x,y2:p.y});},
  pulse(p,R){mark62(p.x,p.y,.9,(m,q)=>{ctx.globalAlpha=(1-q)*.7;ctx.strokeStyle='#ffffff';ctx.lineWidth=9*(1-q)+1;ctx.beginPath();ctx.arc(m.x,m.y,R*q,0,TAU);ctx.stroke();ctx.globalAlpha=(1-q)*.35;ctx.strokeStyle='#04060c';ctx.lineWidth=2;ctx.beginPath();ctx.arc(m.x,m.y,R*q-6,0,TAU);ctx.stroke();});}}
};
/* общая заглушка «dash» (полёт) — у всех есть: свечение по ходу рывка в цвете корпуса */
for(const id of SK62_LATE){const F=SKFX[id];if(!F.dash)F.dash=function(p,t,k){glow(p.x,p.y,22+10*k,SKINS[id].trail,.35*k);};if(!F.move)F.move=function(){};}

/* ---------- след движения у «Несущей» и «Линии прилива»: история позиций ---------- */
function trail62(id,p,t,sp){const B=SK62.buf;if(!B.length||Math.hypot(B[B.length-1].x-p.x,B[B.length-1].y-p.y)>4)B.push({x:p.x,y:p.y,t});while(B.length&&(t-B[0].t>.7||B.length>60))B.shift();if(B.length<3||sp<20)return;
  if(id==='carrier85'){ctx.strokeStyle='#ffffff';ctx.lineWidth=1.2;ctx.beginPath();for(let i=1;i<B.length;i++){const a=B[i-1],b=B[i],dx=b.x-a.x,dy=b.y-a.y,l=Math.hypot(dx,dy)||1,age=(t-b.t)/.7,w=Math.sin(i*.9-t*12)*5*(1-age);ctx.lineTo(b.x-dy/l*w,b.y+dx/l*w);}ctx.globalAlpha=.55;ctx.stroke();}
  if(id==='tidemark100'){for(const s of [-1,1]){ctx.strokeStyle='#d8fff0';ctx.lineWidth=1.2;ctx.beginPath();for(let i=1;i<B.length;i++){const a=B[i-1],b=B[i],dx=b.x-a.x,dy=b.y-a.y,l=Math.hypot(dx,dy)||1,age=(t-b.t)/.7,w=s*(6+age*22);ctx.lineTo(b.x-dy/l*w,b.y+dx/l*w);}ctx.globalAlpha=.45;ctx.stroke();}}}

/* ---------- метки ---------- */
function drawMarks62(t){const M=SK62.marks;if(!M.length)return;const A=ctx.globalAlpha;for(let i=M.length-1;i>=0;i--){const m=M[i],q=(t-m.t0)/m.life;if(q>=1||q<-.5){M.splice(i,1);continue;}ctx.save();try{m.draw(m,Math.max(0,q),t);}catch(e){M.splice(i,1);}ctx.restore();}ctx.globalAlpha=A;}
function sk62Key(){return (G.world?'w':'m'+(G.m||0))+'|'+(G.runId||'')+'|'+(G.state==='menu'?'menu':'');}

/* ---------- обёртки ---------- */
{const _ds=drawShip;drawShip=function(id,t,sp,o){const F=SKFX[id];if(!F)return _ds.apply(this,arguments);
  let k=0,e=0;if(SK62.cur){k=SK62.cur.k;e=SK62.cur.e;}else if(SK62.prev){const ph=((t%3)+3)%3;k=ph<.3?1-ph/.3:0;e=ph>=.3&&ph<.8?1-(ph-.3)/.5:0;}
  const A=ctx.globalAlpha;sp=sp||0;
  if(F.under){ctx.save();try{F.under(t,sp,k,e);}catch(err){}ctx.restore();ctx.globalAlpha=A;}
  if(F.alpha){try{ctx.globalAlpha=A*Math.max(.3,F.alpha(k,t));}catch(err){}}
  const r=_ds.apply(this,arguments);ctx.globalAlpha=A;
  if(F.over){ctx.save();try{F.over(t,sp,k,e);}catch(err){}ctx.restore();ctx.globalAlpha=A;}
  /* финиш рывка на самом корпусе: короткое «оседание» — кольцо в цвет следа сжимается к корпусу */
  if(e>0){ctx.save();try{if(F.settle)F.settle(t,e);else{ctx.globalAlpha=A*e*.6;ctx.strokeStyle=(SKINS[id]||SKINS.base).trail;ctx.lineWidth=1.4;ctx.beginPath();ctx.arc(2,0,16+12*e,0,TAU);ctx.stroke();}}catch(err){}ctx.restore();ctx.globalAlpha=A;}
  return r;};}
{const _dp=drawPlayer;drawPlayer=function(p,t){SK62.now=t;const key=sk62Key();if(key!==SK62.key){SK62.key=key;SK62.marks.length=0;SK62.buf.length=0;SK62.dashOn=false;SK62.endT=0;}
  const id=curSkin(),F=SKFX[id];if(!F||!p||p.hp<=0){SK62.lastT=t;return _dp.apply(this,arguments);}
  const dt=clamp(t-(SK62.lastT||t),0,.05);SK62.lastT=t;
  const dash=p.dashT>0,k=dash?clamp(p.dashT/.15,0,1):0;
  if(!dash&&SK62.dashOn){SK62.dashOn=false;SK62.endT=t;try{F.dashEnd&&F.dashEnd(p,SK62.from||{x:p.x,y:p.y,a:p.ang},t);}catch(err){}}
  const e=SK62.endT?clamp(1-(t-SK62.endT)/.5,0,1):0;const sp=Math.hypot(p.vx||0,p.vy||0);
  const A=ctx.globalAlpha;
  ctx.save();try{drawMarks62(t);if(F.trail)trail62(id,p,t,sp);F.move(p,t,sp,dt);if(dash)F.dash(p,t,k);}catch(err){}ctx.restore();ctx.globalAlpha=A;
  SK62.cur={k,e};try{return _dp.apply(this,arguments);}finally{SK62.cur=null;}};}
{const _td=tryDash;tryDash=function(dir){const p=G.player,before=p?p.dashCd:0;const r=_td.apply(this,arguments);
  try{if(p&&p.dashT>=.149&&p.dashCd>0&&p.dashCd!==before){const F=SKFX[curSkin()];if(F){SK62.dashOn=true;SK62.from={x:p.x,y:p.y,a:Math.atan2(p.dy||0,p.dx||1)};if(F.dashStart)F.dashStart(p);}}}catch(e){}return r;};}
{const _tp=tryPulse;tryPulse=function(){const p=G.player,en=p?p.en:0;const r=_tp.apply(this,arguments);
  try{if(p&&en>=100&&p.en<100){const F=SKFX[curSkin()];if(F&&F.pulse)F.pulse(p,(G.st&&G.st.pR)||150);}}catch(e){}return r;};}
{const _hp=drawHangarPreviews;drawHangarPreviews=function(){SK62.prev=true;try{return _hp.apply(this,arguments);}finally{SK62.prev=false;}};}

/* ===== 1.4.1 α «Пульт»: настройки и пауза =====
   Настройки: пять вкладок, закреплённая шапка с «ГОТОВО», пояснение под каждой строкой, мёртвые на ПК настройки скрыты,
   зависимые строки приглушаются, прицел «МЫШЬ / АВТО», справка «КЛАВИШИ», сброс настроек к стандартным.
   Пауза: сводка партии на ПК и телефоне (сектор или миссия, цифры, цель или мастерство) и быстрые «МУЗЫКА» / «ЗВУКИ». */
const TABS63=[['snd','ЗВУК'],['ctl','УПРАВЛЕНИЕ'],['scr','ЭКРАН'],['acc','ДОСТУПНОСТЬ'],['game','ИГРА']];
const S63={tab:null,rsT:0};
function tab63(){const t=S63.tab||SET.setTab;return TABS63.some(x=>x[0]===t)?t:'snd';}
const NOTE63={
  amb:'Фоновая музыка сектора, миссий и меню.',sfx:'Рывок, импульс, попадания и щелчки интерфейса.',
  vol:'',svol:'',
  btnSize:'Размер кнопок «РЫВОК», «ИМП» и «ДЕЙСТВИЕ».',btnAlpha:'Насколько кнопки просвечивают поверх боя.',stickAlpha:'Насколько просвечивает стик.',
  hand:'Кнопки — под большой палец этой руки, стик — под другой.',stick:'Плавающий появляется там, где коснулись; закреплённый всегда на одном месте.',
  dashSwipe:'Быстрый свайп по экрану — рывок в ту сторону.',oneHand:'Резкий взмах стиком — рывок: можно лететь и уворачиваться одним пальцем.',haptics:'Короткая вибрация на рывок, импульс и попадания.',
  fsMode:'«При полёте» — полный экран включается, когда вы в секторе или миссии.',orient:'Повернуть игру можно и без поворота телефона.',
  zoom:'«Крупнее» — камера ближе, «Дальше» — видно больше поля боя.',uiSize:'Размер полос, кнопок и подписей HUD.',
  quality:'«Авто» сама снижает частицы и чёткость, если телефон не успевает.',fps:ARCH.fc27?'30 — дольше держит батарея. 60 — ровно 60 кадров. Без ограничения — сколько успевает экран (прежний режим «60»). Скорость игры одинаковая.':'30 кадров — дольше держит батарея, 60 — плавнее.',
  textScale:'Размер всех надписей: меню, подсказки, радио.',fxl:'Частицы, свечение, следы корпусов. «Меньше» — вдвое тише, «Выкл» — без них.',
  shake:'Тряска камеры от взрывов и ударов.',softInv:'Некоторые враги на 2 с меняют управление местами. Вместо этого — короткое замедление.',
  noErase:'Поздние враги «стирают» части интерфейса. Вместо исчезновения — полупрозрачность.',
  tutk:'Короткие подсказки в полёте для тех, кто только начинает.',radio:'Сюжетные переговоры в полёте. Выключите — и они не будут прерывать бой, но часть истории пропадёт.'};
const KEYS63=[['W A S D · стрелки','полёт'],['ПРОБЕЛ','рывок'],['E · SHIFT','импульс'],['Q · держать','заряд'],['F','действие у объекта'],['M · TAB','карта'],['J','журналы на карте'],['T','прицел: мышь ↔ авто'],['ESC · P','пауза']];
function keys63(){return `<div class="setrow keys63"><div class="eyebrow">КЛАВИШИ</div><div class="kgrid63">${KEYS63.map(([k,a])=>`<span class="k63">${k.split(' · ').map(x=>`<kbd>${x}</kbd>`).join('<i>·</i>')}</span><span class="a63">${a}</span>`).join('')}</div></div>`;}
function aim63(){return `<div class="setrow" id="aim63"><div class="eyebrow">ПРИЦЕЛ</div><div class="seg"><button data-aim63="1" class="${SET.manual?'on':''}">МЫШЬ</button><button data-aim63="0" class="${SET.manual?'':'on'}">АВТО</button></div></div>`;}
function rset63(){const arm=S63.rsT&&performance.now()-S63.rsT<4000;return `<div class="setrow rset63"><div class="eyebrow">СТАНДАРТНЫЕ НАСТРОЙКИ</div><div><button class="wbtn${arm?' arm63':''}" data-rset63>${arm?'НАЖМИТЕ ЕЩЁ РАЗ — ВЕРНУТЬ':'ВЕРНУТЬ СТАНДАРТНЫЕ'}</button></div><p class="snote">Звук, управление и экран — как при первом запуске. Прогресс, скины и обучение не меняются.</p></div>`;}
/* шапка и вкладки — один раз, вне тела настроек (оно перерисовывается при каждом щелчке) */
function head63(){const sec=$('#sSet');if(!sec)return;const wrap=sec.querySelector('.wrap');if(!wrap||wrap.querySelector('.sethead63'))return;const h2=wrap.querySelector('h2');
  const hd=document.createElement('div');hd.className='sethead63';hd.innerHTML=`<div class="sh-top"></div><div class="maptabs settabs63" role="tablist">${TABS63.map(([k,n])=>`<button data-tab63="${k}" role="tab">${n}</button>`).join('')}</div>`;
  wrap.insertBefore(hd,wrap.firstChild);const top=hd.querySelector('.sh-top');if(h2)top.appendChild(h2);top.insertAdjacentHTML('beforeend','<button class="btn primary" id="bSetDone63">ГОТОВО <kbd>ESC</kbd></button>');}
function layout63(){const B=$('#setBody');if(!B||G.state!=='settings')return;head63();$('#sSet').classList.add('tabs63');
  const tch=touchMode||isMob(),desk=!tch;const used=new Set(),T={snd:[],ctl:[],scr:[],acc:[],game:[]};
  const rowOf=el=>el?(el.closest('.setrow')||el.closest('.tutrow')||el.closest('label.vol')||el):null;/* ползунок едет вместе со своей подписью */
  const put=(tab,sel,nk,opt)=>{const el=typeof sel==='string'?B.querySelector(sel):sel;if(!el)return null;const r=rowOf(el);if(used.has(r))return null;used.add(r);const w=document.createElement('div');w.className='srow63'+(opt&&opt.cls?' '+opt.cls:'');if(nk)w.dataset.n63=nk;
    w.appendChild(r);const n=opt&&opt.note!==undefined?opt.note:NOTE63[nk];if(n)w.insertAdjacentHTML('beforeend',`<p class="snote">${n}</p>`);T[tab].push(w);return w;};
  /* ЗВУК */
  put('snd','.tog[data-k="amb"]','amb');const vA=put('snd','[data-vol]','vol');put('snd','.tog[data-k="sfx"]','sfx');const vS=put('snd','[data-svol]','svol');
  B.querySelectorAll('p.note').forEach(p=>{if(/беззвучн/i.test(p.textContent))put('snd',p,'',{note:''});});
  if(vA&&!SET.amb){vA.classList.add('dis63');vA.insertAdjacentHTML('beforeend','<p class="snote why63">МУЗЫКА ВЫКЛЮЧЕНА</p>');}
  if(vS&&!SET.sfx){vS.classList.add('dis63');vS.insertAdjacentHTML('beforeend','<p class="snote why63">ЗВУКИ ВЫКЛЮЧЕНЫ</p>');}
  /* УПРАВЛЕНИЕ */
  const man=B.querySelector('.tog[data-k="manual"]');if(man){used.add(man);man.remove();}
  if(desk){const d=document.createElement('div');d.innerHTML=aim63();put('ctl',d.firstElementChild,'aim',{note:'Мышь — корабль стреляет туда, где курсор. Авто — сам целится в ближайшего врага. В полёте переключает клавиша T.'});
    const k=document.createElement('div');k.innerHTML=keys63();put('ctl',k.firstElementChild,'keys',{note:''});}
  for(const s of ['btnSize','btnAlpha','stickAlpha','hand','stick'])put('ctl',`[data-seg="${s}"]`,s);
  for(const s of ['dashSwipe','oneHand','haptics'])put('ctl',`.tog[data-k="${s}"]`,s);
  /* ЭКРАН */
  put('scr','[data-seg="fsMode"]','fsMode');put('scr','#fsNote','',{note:''});put('scr','[data-fshint]','',{note:''});put('scr','[data-seg="orient"]','orient');
  for(const s of ['zoom','quality','fps']){const el=B.querySelector(`[data-seg="${s}"]`);if(!el)continue;if(desk&&!(s==='fps'&&ARCH.fc27)){const r=rowOf(el);used.add(r);r.remove();}else put('scr',el,s);}/* ARCH·90b: «КАДРЫ» — и на ПК */
  put('scr','[data-seg="uiSize"]','uiSize');
  /* ДОСТУПНОСТЬ */
  put('acc','[data-seg="textScale"]','textScale');put('acc','[data-fxl]','fxl');const sh=put('acc','[data-seg="shake"]','shake');
  if(sh&&!SET.fx){sh.classList.add('dis63');sh.insertAdjacentHTML('beforeend','<p class="snote why63">РАБОТАЕТ ПРИ ВКЛЮЧЁННЫХ ЭФФЕКТАХ</p>');}
  put('acc','.tog[data-k="softInv"]','softInv');put('acc','.tog[data-k="noErase"]','noErase');
  /* ИГРА */
  put('game','[data-tutk]','tutk');put('game','[data-tutreset]','',{note:''});put('game','.tog[data-k="radio"]','radio');
  {const d=document.createElement('div');d.innerHTML=rset63();put('game',d.firstElementChild,'rset',{note:''});}
  /* всё, что не разложено (сброс прогресса, код сохранения, отладка) — в «ИГРУ», ничего не теряем */
  [...B.querySelectorAll('.setgrp')].forEach(g=>{[...g.children].forEach(ch=>{if(ch.classList.contains('cx-h2')||used.has(ch))return;if(ch.querySelector&&[...used].some(u=>ch.contains(u)))return;put('game',ch,'',{note:''});});});
  /* сборка */
  const cur=tab63();B.innerHTML='';for(const [k,n] of TABS63){const g=document.createElement('div');g.className='setgrp tab63';g.dataset.tab63=k;g.hidden=k!==cur;T[k].forEach(w=>g.appendChild(w));B.appendChild(g);}
  document.querySelectorAll('#sSet [data-tab63]').forEach(b=>{if(b.tagName==='BUTTON'){const on=b.dataset.tab63===cur;b.classList.toggle('on',on);b.setAttribute('aria-selected',on);}});}
function tabGo63(k){S63.tab=k;SET.setTab=k;try{saveSet();}catch(e){}const B=$('#setBody');if(!B)return;B.querySelectorAll('.tab63').forEach(g=>g.hidden=g.dataset.tab63!==k);
  document.querySelectorAll('#sSet button[data-tab63]').forEach(b=>{const on=b.dataset.tab63===k;b.classList.toggle('on',on);b.setAttribute('aria-selected',on);if(on)try{b.scrollIntoView({block:'nearest',inline:'nearest'});}catch(e){}});
  const sc=$('#sSet');if(sc)sc.scrollTop=0;}
/* ARCH·86 · объединённый слой renderSetScreen: 3 слоя (строки 1.5.25: 14438, 14489, 15095) в исходном порядке исполнения */
{const _p86=renderSetScreen;renderSetScreen=function(){const r86=_p86.apply(this,arguments);
  try{sfxVolInject($('#setBody'),'svol-sSet');}catch(e){}
  try{opInject($('#setBody'));}catch(e){}
  try{layout63();}catch(e){console.error(e);}return r86;};}
document.addEventListener('click',e=>{const t=e.target.closest&&e.target.closest('button[data-tab63]');if(t){tabGo63(t.dataset.tab63);try{buzz('tap');}catch(er){}return;}
  const a=e.target.closest&&e.target.closest('[data-aim63]');if(a){SET.manual=a.dataset.aim63==='1';saveSet();updateCursor();renderSetScreen();try{buzz('tap');}catch(er){}return;}
  const d=e.target.closest&&e.target.closest('#bSetDone63');if(d){closeSettings();return;}
  const rs=e.target.closest&&e.target.closest('[data-rset63]');if(rs){const now=performance.now();if(!(S63.rsT&&now-S63.rsT<4000)){S63.rsT=now;renderSetScreen();setTimeout(()=>{if(G.state==='settings')renderSetScreen();},4100);return;}
    S63.rsT=0;const keep={fsHintShown:SET.fsHintShown,setTab:SET.setTab};for(const k in SET_DEF)SET[k]=SET_DEF[k];Object.assign(SET,keep);saveSet();try{audioInit();applyAudio();}catch(er){}try{if(typeof sfxVolApply==='function')sfxVolApply();}catch(er){}
    applySettings();try{opApply();}catch(er){}updateCursor();renderSettings();try{banner('НАСТРОЙКИ','СТАНДАРТНЫЕ');}catch(er){}}});
document.addEventListener('keydown',e=>{const t=e.target;if(!(t&&t.matches&&t.matches('button[data-tab63]')))return;if(e.code!=='ArrowLeft'&&e.code!=='ArrowRight')return;e.preventDefault();e.stopPropagation();
  const i=TABS63.findIndex(x=>x[0]===t.dataset.tab63),j=(i+(e.code==='ArrowRight'?1:-1)+TABS63.length)%TABS63.length;tabGo63(TABS63[j][0]);const nb=$(`#sSet button[data-tab63="${TABS63[j][0]}"]`);if(nb)nb.focus();},true);

/* ---------- пауза: сводка и быстрый звук ---------- */
const QIC63={amb:'<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6 12V3.5l7-1.5V10" fill="none" stroke="currentColor" stroke-width="1.4"/><circle cx="4.5" cy="12" r="1.8" fill="currentColor"/><circle cx="11.5" cy="10.5" r="1.8" fill="currentColor"/></svg>',
  sfx:'<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2 6h3l4-3v10L5 10H2z" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M11.5 5.5c1 1.4 1 3.6 0 5" fill="none" stroke="currentColor" stroke-width="1.4"/></svg>'};
function quick63(){return ['amb','sfx'].map(k=>`<button class="q63${SET[k]?' on':''}" data-q63="${k}" aria-pressed="${!!SET[k]}">${QIC63[k]}<span>${k==='amb'?'МУЗЫКА':'ЗВУКИ'}</span><b>${SET[k]?'ВКЛ':'ВЫКЛ'}</b></button>`).join('');}
function mast63(){const M=typeof MASTERY!=='undefined'&&MASTERY[G.m-1];if(!M||!G.mc)return '';let ok=false;try{ok=!!M.ok();}catch(e){}
  return `<div class="pz-m${ok?' ok':''}"><span>МАСТЕРСТВО</span>${M.t}<b>${ok?'✓ ВЫПОЛНЯЕТСЯ':'· ПОКА НЕТ'}</b></div>`;}
function info63(){const S=G.save,p=G.player;const sep='<i>·</i>';
  if(G.pausedWorld&&S&&p){let tg=null;try{tg=G.course?{x:G.course.x,y:G.course.y,label:'КУРС · '+G.course.label}:(typeof tut133HoldNext==='function'&&tut133HoldNext()&&typeof tutShopPt==='function'&&tutShopPt()?Object.assign({label:'СКЛАД'},tutShopPt()):nextTarget());}catch(e){}
    const lom=fmtN(S.lom||0)+(S.carry?` <em>+${fmtN(S.carry)}</em>`:''),lv=S.pilot&&S.pilot.lvl||1;
    return `<div class="pz-t">${sectorName(p.x,p.y)}</div><div class="pz-n"><span>МИССИИ <b>${doneCount()}/${NM}</b></span>${sep}<span>ЛОМ <b>${lom}</b></span>${sep}<span>ПИЛОТ <b>УР. ${lv}</b></span></div>`+
      (tg?`<div class="pz-g"><span>ЦЕЛЬ</span>${tg.label} <b>${fmtAU(Math.hypot(tg.x-p.x,tg.y-p.y))}</b></div>`:'');}
  const tm=mmss(G.mT||0);
  if(G.mode==='endless')return `<div class="pz-t">БЕСКОНЕЧНОСТЬ</div><div class="pz-n"><span>СТУПЕНЬ <b>${G.end?G.end.step:1}</b></span>${sep}<span>ВРЕМЯ <b>${tm}</b></span>${sep}<span>УБИТО <b>${G.kills||0}</b></span></div>`;
  const M=MISSIONS[G.m-1];if(!M)return '';const df=(G.mode==='world'||G.mode==='dev')&&DIFF[G.diff]?DIFF[G.diff].name:'';
  return `<div class="pz-t">${pad2(G.m)} · ${mName(M)}${df?`<em>${df}</em>`:''}</div><div class="pz-n"><span>ВРЕМЯ <b>${tm}</b></span>${sep}<span>УРОВЕНЬ <b>${G.lvl||1}</b></span>${sep}<span>УБИТО <b>${G.kills||0}</b></span></div>`+((G.mode==='world'||G.mode==='dev')?mast63():'');}
function pzRender63(){const box=$('#sPause .wrap');if(!box)return;let I=$('#pzInfo');if(!I){I=document.createElement('div');I.id='pzInfo';I.setAttribute('role','status');const st=$('#pauseStat');(st||box.querySelector('.eyebrow')).insertAdjacentElement('afterend',I);}
  I.innerHTML=info63();let Q=$('#pzQuick');if(!Q){Q=document.createElement('div');Q.id='pzQuick';I.insertAdjacentElement('afterend',Q);}Q.innerHTML=quick63();const st=$('#pauseStat');if(st)st.hidden=true;}
{const _pz=pause;pause=function(){const r=_pz.apply(this,arguments);try{if(G.state==='pause')pzRender63();}catch(e){console.error(e);}return r;};}
{const _cs=closeSettings;closeSettings=function(){const r=_cs.apply(this,arguments);try{if(G.state==='pause')pzRender63();}catch(e){}return r;};}
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-q63]');if(!b)return;const k=b.dataset.q63;SET[k]=!SET[k];saveSet();try{audioInit();applyAudio();}catch(er){}renderSettings();try{pzRender63();}catch(er){}try{buzz('tap');}catch(er){}});

/* звуки и музыка со своим генератором случайных чисел: со звуком и без бой идёт одинаково (шум, высота нот, музыкальные шаги не трогают Math.random игры) */
const SFXR63=(()=>{let s=0x2545F491;return ()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return (s>>>0)/4294967296;};})();
function iso63(f){const w=function(){const mr=Math.random;Math.random=SFXR63;try{return f.apply(this,arguments);}finally{Math.random=mr;}};w.toString=()=>f.toString();return w;}
/* все звуковые функции: шум, ноты, музыкальные шаги, радиопомехи */
if(typeof sfx==='function')sfx=iso63(sfx);if(typeof noiseBuf==='function')noiseBuf=iso63(noiseBuf);if(typeof scapeStep==='function')scapeStep=iso63(scapeStep);if(typeof musicTick==='function')musicTick=iso63(musicTick);if(typeof radioSay==='function')radioSay=iso63(radioSay);if(typeof snd85==='function')snd85=iso63(snd85);if(typeof snd90==='function')snd90=iso63(snd90);if(typeof step90==='function')step90=iso63(step90);if(typeof snd95==='function')snd95=iso63(snd95);if(typeof snd110==='function')snd110=iso63(snd110);if(typeof step110==='function')step110=iso63(step110);if(typeof snd120==='function')snd120=iso63(snd120);if(typeof postSnd==='function')postSnd=iso63(postSnd);if(typeof postAudio==='function')postAudio=iso63(postAudio);if(typeof thump==='function')thump=iso63(thump);if(typeof tutChord==='function')tutChord=iso63(tutChord);if(typeof tutNote==='function')tutNote=iso63(tutNote);

/* ===== 1.4.2 α «Пульт»: одна кнопка «Готово», вкладки без прокрутки =====
   1) верхняя «ГОТОВО» из 1.4.1 убрана: на телефоне нижняя и так всегда на экране, на ПК — Esc и нижняя (с подсказкой ESC);
   2) на телефоне вкладки — плитка 3 + 2 со значками, видны все пять сразу, ничего не листается вбок. */
const TIC64={snd:'<path d="M3 7.5h3l4-3v11l-4-3H3z"/><path d="M13.5 7c1.1 1.6 1.1 4.4 0 6M15.8 5c2 2.7 2 7.3 0 10"/>',
  ctl:'<circle cx="10" cy="10" r="7"/><circle cx="10" cy="10" r="2.6"/>',
  scr:'<rect x="2.5" y="3.5" width="15" height="10" rx="1.5"/><path d="M7 17h6M10 13.5V17"/>',
  acc:'<path d="M1.8 10S5 4.5 10 4.5 18.2 10 18.2 10 15 15.5 10 15.5 1.8 10 1.8 10z"/><circle cx="10" cy="10" r="2.6"/>',
  game:'<path d="M10 2.5l6 14-6-3.2-6 3.2z"/>'};
function tabIco64(k){return `<svg class="tic64" viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round">${TIC64[k]||''}</svg>`;}
{const _h=head63;head63=function(){const r=_h.apply(this,arguments);try{
  const d=$('#bSetDone63');if(d)d.remove();
  document.querySelectorAll('#sSet button[data-tab63]').forEach(b=>{if(b.querySelector('.tic64'))return;const n=b.textContent;b.innerHTML=tabIco64(b.dataset.tab63)+`<span>${n}</span>`;b.setAttribute('aria-label',n);});
  const bk=$('#bSetBack');if(bk&&!bk.querySelector('kbd'))bk.insertAdjacentHTML('beforeend',' <kbd class="pconly64">ESC</kbd>');}catch(e){console.error(e);}return r;};}

/* ===== 1.4.5 α «Верстак»: режим разработчика =====
   1) в песочнице открыто всё: ворота XII к боссу 50, арсенал, сторожевик «Изморозь» на своём месте;
   2) сторожевик и босс 50 в сетке выбора миссий запускаются через песочницу — по настоящей дороге и без записи в игру;
   3) одна панель #dvx (Ё / ` / кнопка DEV) на 7 вкладок: прыжок, корабль, бой, мир, прогресс, обучение, отладка;
   4) бессмертие в три ступени, телепорт сеткой, по карте, назад, закладки, снимки, сид, журнал событий, отчёт.
   Всё работает только при devAny(): без ?dev в адресе ничего из этого не видно и не слушается. */
const DVX={open:false,tab:null,ctx:'',hist:[],near:{},errs:[],log:[],step:0,mr:null,seeded:false,live:null,arm:{},lastWarn:0,pressT:0};
function dvOn(){try{return !!(window.DEVW&&DEVW.on&&DEVW.on());}catch(e){return false;}}
function devOpen(){return dvOn()||G.mode==='dev';}
function devGod(){if(!devAny())return 0;return G.dev.god?2:G.dev.god1?1:0;}
function dvSave(){try{store('void_dev',G.dev);}catch(e){}}
function devLog(kind,text){DVX.log.push({t:Date.now(),gt:G.t||0,kind,text:String(text).slice(0,160)});if(DVX.log.length>200)DVX.log.shift();if(DVX.open&&DVX.tab==='dbg')dvxLive();}
G.dev=Object.assign({god1:false,en:false,nocd:false,ohk:false,noclip:false,freeze:false,tscale:1,tpause:false,seed:4417,seedOn:false,tut:false,dvTab:'jump',bm:[null,null,null],zbCalm:false,postCold:false,postLight:false},G.dev||{});
if(!Array.isArray(G.dev.bm))G.dev.bm=[null,null,null];

/* ---------- ошибки — всегда пишем, показываем только в деве ---------- */
addEventListener('error',e=>{DVX.errs.push({t:Date.now(),m:String(e.message||e.error||'ошибка').slice(0,200),s:(e.error&&e.error.stack||'').split('\n').slice(0,4).join(' | ').slice(0,400),seen:0});if(DVX.errs.length>40)DVX.errs.shift();try{if(devAny())dvxBar();}catch(er){}});
addEventListener('unhandledrejection',e=>{DVX.errs.push({t:Date.now(),m:'promise: '+String(e.reason&&e.reason.message||e.reason).slice(0,200),s:'',seen:0});if(DVX.errs.length>40)DVX.errs.shift();});

/* ---------- 1. доступ: в песочнице открыто всё ---------- */
{const _z=zeroOpen110;zeroOpen110=function(){if(dvOn())return true;return _z.apply(this,arguments);};}
{const _a=arsOpen;arsOpen=function(){if(dvOn())return true;return _a.apply(this,arguments);};}
/* сторожевик в песочнице — на своём месте (раньше «всё открыто» прятало его, чтобы он не перегораживал III) */
{const _p=postAvail;postAvail=function(){if(dvOn())return !!G.save&&progDone(CORE)&&!G.post;return _p.apply(this,arguments);};}

/* ---------- прогресс песочницы: «пройдено до N» и точная копия моего прогресса ---------- */
{const _pr=DEVW.prep;DEVW.prep=function(S){const r=_pr.apply(this,arguments);try{if(S&&S.devExact&&S.devOrig){Object.assign(S,JSON.parse(JSON.stringify(S.devOrig)));}
  else if(S&&Number.isInteger(S.devProg))S.cleared=Math.min(S.devProg,CORE);}catch(e){}return r||S;};}
function dvSetProg(N){const S=G.save;if(!S)return;N=clamp(N|0,0,50);delete S.devExact;delete S.devOrig;S.devProg=N;S.cleared=Math.min(N,CORE);S.medals=S.medals||{};
  for(let m=1;m<=50;m++){if(m<=N){const md=S.medals[m]||(S.medals[m]={});md.clear=1;}else if(S.medals[m]){delete S.medals[m].clear;delete S.medals[m].clean;delete S.medals[m].master;}}
  S.story=S.story||{};if(N>=49)S.story.zero49=1;else delete S.story.zero49;if(N<50){delete S.story.zero50;delete S.story.zbJ;}
  if(N<CORE){const T=tutT();if(T&&G.dev.tut)T.off=0;}
  try{MAPC.fog=null;MAPC.fogVer=null;}catch(e){}saveWorld();devLog('prog','пройдено до '+N);}

/* ---------- 2. сетка выбора миссий: сторожевик и босс 50 — через песочницу ---------- */
function devGo(kind){if(!window.DEVW)return;const diff=G.dev.diff||'easy';DEVW.enter();const S=G.save;if(!S||!G.player)return;S.diff=diff;G.diff=diff;
  if(kind==='post'){devJump(POST_HATCH.x,POST_HATCH.y-150,'сторожевик',{exact:1,quiet:1});postEnter();devLog('go','сторожевик из сетки · '+diff);}
  if(kind==='zb'){const n=WORLD.nodes[49];devJump(n.x,n.y+100,'босс 50',{exact:1,quiet:1});G.zbCool=0;setTimeout(()=>{try{if(G.state==='world'&&!G.zb)zbStart();devLog('go','босс 50 из сетки · '+diff);}catch(e){console.error(e);}},60);}}
{const _ds=devStart;devStart=function(m){if(m===50){devGo('zb');return;}if(m===POST_I+1){devGo('post');return;}/* сид — до сборки модулей: «типичная» сборка тоже случайна */dvSeedOff();dvSeedOn(true);return _ds.apply(this,arguments);};}
{const _od=openDev;openDev=function(){dvSeedOff();const r=_od.apply(this,arguments);try{dvxClose();const g=$('#devGrid');if(g&&!g.querySelector('[data-m="post"]')){const t10=g.querySelector('[data-m="10"]');
    const b=document.createElement('button');b.className='devm post65';b.dataset.m='post';b.innerHTML='<b>❄</b><span>Сторожевик «Изморозь»</span><small>ГРАНИЦА II–III · ХОРРОР</small>';if(t10)t10.insertAdjacentElement('afterend',b);else g.appendChild(b);
    const t50=g.querySelector('[data-m="50"] small');if(t50)t50.textContent='БОСС · ОТКРЫТЫЙ МИР · СЕКТОР XII';}}catch(e){console.error(e);}return r;};}
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('#devGrid .devm');if(!b)return;if(b.dataset.m==='post'){e.stopImmediatePropagation();devGo('post');}else if(b.dataset.m==='50'){e.stopImmediatePropagation();devGo('zb');}},true);

/* ---------- 3. бессмертие: 0 — выкл, 1 — держать 1 HP, 2 — полное ---------- */
{const _l=lc95;lc95=function(p){if(devGod()===1&&p){p.hp=1;p.inv=Math.max(p.inv||0,.75);return true;}return _l.apply(this,arguments);};}
{const _rk=riftKill;riftKill=function(){if(devGod()>=1){const p=G.player;if(p&&devGod()===1)p.hp=Math.max(1,p.hp);return;}return _rk.apply(this,arguments);};}
{const _ai=addIce;addIce=function(){if(devGod()===2)return;return _ai.apply(this,arguments);};}
{const _aw=addWear;addWear=function(v){if(devGod()===2&&v>0)return;return _aw.apply(this,arguments);};}
/* «полное»: удар проходит как в игре (окно неуязвимости, отброс, вспышка), но здоровье и счётчик урона возвращаются —
   так бой с бессмертием идёт точно так же, как без него */
{const _dp=damagePlayer;damagePlayer=function(d){if(devGod()!==2)return _dp.apply(this,arguments);const p=G.player;if(!p)return;const hp=p.hp,tk=G.taken;
  G.dev.god=false;G.dev.god1=true;try{return _dp.apply(this,arguments);}finally{G.dev.god=true;G.dev.god1=false;p.hp=hp;G.taken=tk;}};}
/* с одного попадания — кроме боссов, их фазы должны идти честно */
function dvBossy(e){return !!(e&&(e.zb||e===G.sb||['boss','jam','lock'].includes(e.type)||(EDEF[e.type]&&(EDEF[e.type].sbp||EDEF[e.type].boss))));}
{const _h=hurt;hurt=function(e,dmg,src){if(devAny()&&G.dev.ohk&&e&&e.alive&&!dvBossy(e))dmg=Math.max(dmg,(e.hp||0)+1);return _h.call(this,e,dmg,src);};}
{const _ue=updateEnemies;updateEnemies=function(dt){if(devAny()&&G.dev.freeze)return;return _ue.apply(this,arguments);};}
{const _ub=updateBullets;updateBullets=function(dt){if(devAny()&&G.dev.freeze)return;return _ub.apply(this,arguments);};}
function dvShipTick(){const p=G.player;if(!p||!devAny())return;if(G.dev.en)p.en=Math.max(p.en||0,100);if(G.dev.nocd)p.dashCd=0;
  if(G.zb&&G.dev.zbCalm){G.zb.atkT=Math.max(G.zb.atkT||0,9);}
  if(G.post&&G.post.O&&G.dev.postFreeze){const O=G.post.O;O.cd=Math.max(O.cd,5);if(O.st!=='off'){O.st='off';O.x=-999;O.y=-999;}}}
/* скорость времени, пауза и шаг кадра; на телефоне при открытом листе мир стоит */
function dvRun(orig,self,args){if(!devAny())return orig.apply(self,args);const dt=args[0];
  if((DVX.open&&touchMode)||G.dev.tpause){if(DVX.step>0&&!(DVX.open&&touchMode)){DVX.step--;dvShipTick();return orig.call(self,1/60);}return;}
  const k=+G.dev.tscale||1;let r;if(k===1){r=orig.apply(self,args);}else if(k<1){r=orig.call(self,dt*k);}else{for(let i=0;i<k;i++)r=orig.call(self,dt);}dvShipTick();return r;}
{const _u=update;update=function(){return dvRun(_u,this,arguments);};}
/* сквозь скалы: позиция после полёта сохраняется, выталкивание скалами отменяется */
{const _mv=DEVW.move;DEVW.move=function(dt){const r=_mv.apply(this,arguments);const p=G.player;DVX.nc=p&&G.dev.noclip&&!G.zb?{x:p.x,y:p.y}:null;return r;};}
{const _w=worldUpdate;worldUpdate=function(dt){DVX.nc=null;const r=dvRun(_w,this,arguments);const p=G.player,q=DVX.nc;if(q&&p&&dvOn()&&G.dev.noclip&&G.world&&!G.zb){p.x=q.x;p.y=q.y;}return r;};}
/* сторожевик: холод и свет */
{const _pk=postDK;postDK=function(){const D=_pk.apply(this,arguments);if(!devAny())return D;if(G.dev.postCold||G.dev.postLight)return Object.assign({},D,G.dev.postCold?{cold:0}:{},G.dev.postLight?{dark:0}:{});return D;};}

/* ---------- сид ---------- */
function dvSeedOn(force,salt){if(!(force||devAny())||!G.dev.seedOn||DVX.seeded)return;DVX.mr=Math.random;let s=((G.dev.seed>>>0)+(salt||0)*7919)%2147483648||1;Math.random=()=>{s=(s*1103515245+12345)%2147483648;return s/2147483648;};DVX.seeded=true;devLog('seed','сид '+G.dev.seed+' включён');}
function dvSeedOff(){if(!DVX.seeded)return;if(DVX.mr)Math.random=DVX.mr;DVX.seeded=false;DVX.mr=null;}
/* сид: брифинг (раскладка, стартовый набор) — от сида, а с «В БОЙ» — от сида+1, так что время на брифинге повтор не сбивает */
{const _oi2=openIntro;openIntro=function(){dvSeedOff();dvSeedOn();return _oi2.apply(this,arguments);};}
{const _sm=startMission;startMission=function(){const was=G.state==='intro';if(was){dvSeedOff();dvSeedOn(false,1);}const r=_sm.apply(this,arguments);
  /* с сидом бой начинается с одинакового корабля: энергия, наводка и огонь не тянутся из сектора */
  if(was&&DVX.seeded&&G.player){const p=G.player;p.en=0;p.fireT=0;p.ang=-Math.PI/2;p.droneA=0;G.calm=0;G.rdt90=1/60;if(typeof G.lastFire90==='number')G.lastFire90=G.t-999;}return r;};}

/* визуальные случайности (частицы, взрывы, дрожание отрисовки) — свой генератор, как звук в 1.4.1:
   время на брифинге, «Эффекты» и частота кадров больше не сдвигают случайности боя */
const VFXR65=(()=>{let s=0x51ED27;return ()=>{s^=s<<13;s^=s>>>17;s^=s<<5;return (s>>>0)/4294967296;};})();
/* ARCH·71 A-14…A-18 */arch71Boot();
function iso65(f){const w=function(){const mr=Math.random;Math.random=VFXR65;try{return f.apply(this,arguments);}finally{Math.random=mr;}};w.toString=()=>f.toString();return w;}
if(typeof part==='function')part=iso65(part);if(typeof explode==='function')explode=iso65(explode);
if(typeof render==='function')render=iso65(render);if(typeof renderWorld==='function')renderWorld=iso65(renderWorld);if(typeof mobOverlay==='function')mobOverlay=iso65(mobOverlay);

/* ---------- журнал событий ---------- */
{const _b=banner;banner=function(b,s){try{if(devAny())devLog('banner',b+(s?' · '+s:''));}catch(e){}return _b.apply(this,arguments);};}
{const _t=toast;toast=function(a,b){try{if(devAny())devLog('toast',a+' · '+b);}catch(e){}return _t.apply(this,arguments);};}
{const _ts=tutStart;tutStart=function(k){try{if(devAny())devLog('tut','урок «'+k+'» начат');}catch(e){}return _ts.apply(this,arguments);};}
{const _te=tutEnd;tutEnd=function(how){try{if(devAny()&&TUT.cur)devLog('tut','урок «'+TUT.cur.k+'» → '+how);}catch(e){}return _te.apply(this,arguments);};}
{const _en=enterNode;enterNode=function(m){try{if(devAny()){devLog('go','вход в узел '+pad2(m));dvSeedOff();dvSeedOn(false,2);}}catch(e){}return _en.apply(this,arguments);};}
{const _rw=returnToWorld;returnToWorld=function(){dvSeedOff();try{if(devAny())devLog('go','возврат в мир');}catch(e){}return _rw.apply(this,arguments);};}
{const _go=gameOver;gameOver=function(){try{if(devAny())devLog('death','гибель · '+(G.post?'сторожевик':G.mode==='endless'?'бесконечность':'миссия '+pad2(G.m)));}catch(e){}return _go.apply(this,arguments);};}
{const _tm=toMenu;toMenu=function(){dvSeedOff();dvxClose();return _tm.apply(this,arguments);};}
{const _za=zbAbort;zbAbort=function(w){try{if(devAny()&&G.zb)devLog('death','босс 50 · гибель на стадии '+G.zb.stage);}catch(e){}return _za.apply(this,arguments);};}

/* ---------- телепорт ---------- */
function dvFree(x,y){const rr=G.rocks||[];const bad=(qx,qy)=>rr.some(r=>r.alive!==false&&Math.hypot(qx-r.x,qy-r.y)<r.r+40);if(!bad(x,y))return [x,y];
  for(let i=1;i<40;i++){const a=i*2.4,d=40+i*22,qx=x+Math.cos(a)*d,qy=y+Math.sin(a)*d;if(!bad(qx,qy))return [qx,qy];}return [x,y];}
function dvLeave(){/* из любого состояния — чисто в мир */
  if(G.state==='levelup'&&typeof pickMode!=='undefined'&&pickMode==='zbChoice'){pickMode='ship';scr6('world');show('');}
  if(G.zb&&G.state==='levelup'){runQClear6();if(typeof pickMode!=='undefined')pickMode='ship';scr6('world');show('');}
  if(G.zb){try{zbLeave();}catch(e){G.zb=null;}}
  if(G.state==='map')closeMap();
  if(G.state==='pause'&&G.pausedWorld)resume();
  if(G.post||inMission()&&['intro','play','levelup','pause','done','over','codex'].includes(G.state)){try{if(G.runStart)restoreRun();}catch(e){}returnToWorld();}
  if(G.state==='shop'||G.state==='hangar'||G.state==='arsenal'){try{if(G.state==='shop'&&typeof closeShop==='function')closeShop();else if(G.state==='hangar'&&typeof closeHangar==='function')closeHangar();else if(G.state==='arsenal'&&typeof closeArsenal==='function')closeArsenal();}catch(e){}}}
function devJump(x,y,why,o){o=o||{};if(!dvOn()){toast('ТОЛЬКО В ПЕСОЧНИЦЕ','Откройте «Открытый мир» в режиме разработчика.');return false;}
  dvLeave();if(G.state!=='world'||!G.player)return false;const p=G.player;
  if(!o.back){DVX.hist.push({x:p.x,y:p.y,why:sectorName(p.x,p.y)});if(DVX.hist.length>8)DVX.hist.shift();}
  enterWorldAt(x,y);if(!o.exact){const q=dvFree(p.x,p.y);p.x=q[0];p.y=q[1];}p.px=p.x;p.py=p.y;p.vx=p.vy=0;p.dashT=0;camSnap();G.card=null;G.cardKey=null;$('#wcard').hidden=true;
  try{saveWorld();}catch(e){}devLog('jump',(why||'точка')+' · '+Math.round(p.x)+' '+Math.round(p.y));if(!o.quiet)floater(p.x,p.y-46,'ПРЫЖОК · '+(why||'ТОЧКА').toUpperCase(),'#00ff88');
  if(DVX.open)dvxRender();return true;}
function dvBack(){const h=DVX.hist.pop();if(!h){toast('НАЗАД','История прыжков пуста.');return;}devJump(h.x,h.y,'назад',{back:1,exact:1});}
function dvNode(m){if(m==='post')return {x:POST_HATCH.x,y:POST_HATCH.y-150,label:'сторожевик'};const n=WORLD.nodes[m-1];return n?{x:n.x,y:n.y+(m===50?100:160),label:'миссия '+pad2(m)}:null;}
function dvGoNode(m,enter){const q=dvNode(m);if(!q)return;if(!devJump(q.x,q.y,q.label,{exact:m===50||m==='post'}))return;if(!enter)return;
  if(m==='post'){postEnter();return;}if(m===50){G.zbCool=0;setTimeout(()=>{try{if(G.state==='world'&&!G.zb)zbStart();}catch(e){console.error(e);}},60);return;}
  enterNode(m);}
const DV_PLACES=[['shop','СКЛАД',()=>WORLD.shops[0]],['hangar','ХРАНИЛИЩЕ',()=>WORLD.hangar],['arsenal','АРСЕНАЛ',()=>WORLD.arsenal],['abyss','БЕЗДНА',()=>WORLD.abyss&&{x:WORLD.abyss.x,y:WORLD.abyss.y+260}],
  ['gate','ВОРОТА II',()=>WORLD.gate&&{x:WORLD.gate.x-250,y:WORLD.gate.y}],['post','СТОРОЖЕВИК',()=>({x:POST_HATCH.x,y:POST_HATCH.y-150})],['zero','ВОРОТА XII',()=>WORLD.zero110&&{x:WORLD.zero110.x,y:WORLD.zero110.y-260}]];
const DV_NEAR=[['journals','ЖУРНАЛ',()=>WORLD.journals],['caches','ТАЙНИК',()=>WORLD.caches],['relays','РЕТРАНСЛЯТОР',()=>WORLD.relays],['anomalies','АНОМАЛИЯ',()=>WORLD.anomalies],['locks','ЗАМОК',()=>(WORLD.locks||[]).map(l=>Array.isArray(l)?{x:l[0],y:l[1]}:l)],['shops','МАСТЕРСКАЯ',()=>WORLD.shops]];
function dvNear(k){const D=DV_NEAR.find(x=>x[0]===k);if(!D||!G.player)return;const L=(D[2]()||[]).filter(q=>q&&Number.isFinite(q.x));if(!L.length)return;let st=DVX.near[k];
  if(!st){const p=G.player;st=DVX.near[k]={i:-1,L:L.slice().sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))};}
  st.i=(st.i+1)%st.L.length;const q=st.L[st.i];devJump(q.x,q.y+130,D[1].toLowerCase()+' '+(st.i+1)+'/'+st.L.length);}
function dvSecC(i){const s=WORLD.sectors[i];if(!s)return null;return {x:s.bx||(s.box[0]+s.box[2])/2,y:(s.by||(s.box[1]+s.box[3])/2)+150};}

/* ---------- снимки ---------- */
function dvSnapSave(i){const S=G.save,p=G.player;if(!dvOn()||!S||!p)return;try{saveWorld();}catch(e){}
  const v={v:1,t:Date.now(),ver:VER_TAG,pos:{x:Math.round(p.x),y:Math.round(p.y)},sec:sectorName(p.x,p.y),save:JSON.parse(JSON.stringify(S))};v.save.pos={...v.pos};v.save.last={...v.pos};
  try{LS.setItem('void_devsnap'+i,JSON.stringify(v));toast('СНИМОК '+i+' СОХРАНЁН',v.sec+' · '+v.pos.x+' '+v.pos.y);devLog('snap','снимок '+i+' сохранён');}catch(e){toast('СНИМОК НЕ ЗАПИСАН','Не хватает места в браузере. Старый снимок не тронут.');}
  if(DVX.open)dvxRender();}
function dvSnapGet(i){try{const v=JSON.parse(LS.getItem('void_devsnap'+i)||'null');return v&&v.save?v:null;}catch(e){return null;}}
function dvSnapLoad(i){const v=dvSnapGet(i);if(!v){toast('СНИМОК '+i,'Слот пуст.');return;}dvLeave();try{LS.setItem(DEVW.KEY,JSON.stringify(v.save));}catch(e){return;}saveSet6(null,'dev');DEVW.enter();devLog('snap','снимок '+i+' загружен');if(DVX.open)dvxRender();}
function dvCopyMine(){const real=migrateSave(store('void_world'));if(!real){toast('НЕТ СОХРАНЕНИЯ','Настоящая игра ещё не начата.');return;}dvLeave();
  const S=JSON.parse(JSON.stringify(real));S.devw=1;S.devExact=1;S.devOrig={cleared:S.cleared,gate:S.gate,pilot:S.pilot,ownSkins:S.ownSkins,skins:S.skins,relays:S.relays,reveal:S.reveal,intro:S.intro};
  try{LS.setItem(DEVW.KEY,JSON.stringify(S));}catch(e){return;}saveSet6(null,'dev');DEVW.enter();toast('КОПИЯ ВАШЕГО ПРОГРЕССА','Песочница теперь — точная копия настоящей игры. Настоящее сохранение не изменится.');devLog('snap','копия настоящего прогресса');}

/* ---------- отчёт ---------- */
function dvReport(){const p=G.player,S=G.save;const L=[];
  L.push('VØID '+VER_TAG+' · отчёт разработчика · '+new Date().toISOString());
  L.push('устройство: '+innerWidth+'×'+innerHeight+' · dpr '+devicePixelRatio+' · '+(touchMode?'сенсор':'мышь')+' · '+(isMob()?'моб':'ПК')+' · '+(innerWidth>innerHeight?'альбомная':'книжная'));
  L.push('режим: '+(dvOn()?'песочница':G.mode)+' · состояние: '+G.state+(G.m?' · миссия '+pad2(G.m):'')+(G.zb?' · босс 50 '+G.zb.k+' ст.'+G.zb.stage:'')+(G.post?' · сторожевик акт '+(G.post.act+1):''));
  if(p)L.push('корабль: '+Math.round(p.x)+' '+Math.round(p.y)+' · '+sectorName(p.x,p.y)+' · HP '+Math.round(p.hp)+'/'+Math.round(G.st&&G.st.maxHp||0)+' · EN '+Math.round(p.en||0));
  if(S)L.push('прогресс: миссии '+doneCount()+'/'+NM+' · лом '+Math.round(S.lom||0)+' · пилот '+((S.pilot&&S.pilot.lvl)||1)+' · цикл '+(S.cycle||1)+' · сложность '+(S.diff||G.diff));
  L.push('дев: бессмертие '+devGod()+' · время ×'+G.dev.tscale+(G.dev.tpause?' (пауза)':'')+' · сид '+(G.dev.seedOn?G.dev.seed:'случайный')+' · полёт ×'+(DEVW.spd?DEVW.spd():1));
  L.push('настройки: '+JSON.stringify({fx:SET.fx,lessFx:SET.lessFx,quality:SET.quality,fps:SET.fps,uiSize:SET.uiSize,textScale:SET.textScale,hand:SET.hand}));
  const W=DEVW.stats?DEVW.stats():{};L.push('сторож: заблокировано '+JSON.stringify(W.blocked||{})+' · попыток void_world '+((W.warn||[]).length));
  L.push('ошибки ('+DVX.errs.length+'):');DVX.errs.slice(-5).forEach(e=>L.push('  '+e.m+(e.s?' @ '+e.s:'')));
  L.push('журнал:');DVX.log.slice(-20).forEach(e=>L.push('  '+new Date(e.t).toTimeString().slice(0,8)+' '+e.kind+' · '+e.text));
  return L.join('\n');}
function dvCopy(t,okMsg){const done=()=>toast('СКОПИРОВАНО',okMsg||'Текст в буфере обмена.');
  try{navigator.clipboard.writeText(t).then(done,()=>dvCopyFb(t,done));}catch(e){dvCopyFb(t,done);}}
function dvCopyFb(t,done){try{const a=document.createElement('textarea');a.value=t;a.style.cssText='position:fixed;left:-9999px;top:0';document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();done();}catch(e){toast('НЕ СКОПИРОВАНО','Браузер не дал доступ к буферу.');}}

/* ---------- обучение ---------- */
{const _to=tutOn;tutOn=function(){if(dvOn()&&G.dev.tut){const S=G.save;if(!S||!S.tut||S.tut.off)return false;return G.mode==='world'&&!G.fromAbyss;}return _to.apply(this,arguments);};}
function dvTutBlock(){const S=G.save,p=G.player;if(!S)return 'Нет сохранения.';if((S.cleared||0)>=CORE)return 'Пройдено '+(S.cleared||0)+' миссий — обучение кончается после десятой.';if(p&&sectorIdx(p.x,p.y)>=2)return 'Корабль в секторе '+roman(sectorIdx(p.x,p.y)+1)+' — обучение живёт только в I–II.';return '';}
/* «▶ показать сейчас»: урок держится минимум 5 с, даже если повода (враг, пуля, карта) нет — чтобы его можно было рассмотреть */
const dvForced=()=>!!(TUT.cur&&TUT.cur.forced&&TUT.cur.t<5);
{const _c=tutCtxOk;tutCtxOk=function(){if(dvForced())return true;return _c.apply(this,arguments);};}
{const _c=tutCalm;tutCalm=function(){if(dvForced())return true;return _c.apply(this,arguments);};}
{const _e=tutEnd;tutEnd=function(how){if(dvForced()&&(how==='abort'||how==='miss'))return;return _e.apply(this,arguments);};}
{const _t=tutTick2;tutTick2=function(){if(dvForced())TUT.cur.idle=0;return _t.apply(this,arguments);};}
{const _s=tutStart;tutStart=function(k){if(dvForced()&&TUT.cur.k!==k)return;return _s.apply(this,arguments);};}
const TUT_NM65={move:'Полёт',dash:'Рывок',pulse:'Импульс',fire:'Огонь',cell:'Ячейка',line:'Линия',calib:'Калибровка',act:'Действие',energy:'Энергия',lom:'Лом',stash:'Склад',map:'Карта',jump:'Прыжок',patrol:'Патруль'};
function dvTutWhy(k){const r=[],T=tutT(),L=TUT_L[k];if(!L)return ['нет такого урока'];
  if(!G.dev.tut)r.push('обучение в песочнице выключено (переключатель выше)');
  if(!T)r.push('нет сохранения');else{if(T.off)r.push('обучение закончено: пройдено ≥10 миссий или корабль в секторе III+ («Прогресс» → пройдено до N < 10)');if(T.done[k])r.push('урок уже сделан');}
  if(TUT.cur&&TUT.cur.k!==k)r.push('сейчас идёт урок «'+(TUT_NM65[TUT.cur.k]||TUT.cur.k)+'»');
  if(TUT.gap>0)r.push('пауза между уроками ещё '+TUT.gap.toFixed(1).replace('.',',')+' с');
  let ctx=true;try{ctx=tutCtxOk(L.ctx);}catch(e){}if(!ctx)r.push('не тот экран: нужен '+({world:'сектор',mission:'бой в миссии',map:'карта'}[L.ctx]||L.ctx));
  let calm=true;try{calm=tutCalm();}catch(e){}if(!L.fight&&L.ctx!=='map'&&!calm)r.push('не спокойно: рядом враги или мало здоровья');
  if(!['dash','pulse','fire','patrol','move','jump','calib'].includes(k)&&T&&!T.done.move&&G.world)r.push('сначала урок «Полёт»');
  let ok;try{ok=L.when();}catch(e){ok='ошибка: '+e.message;}if(ok!==true)r.push('условие урока не выполнено (when = '+ok+')');
  if(T)for(const kk of TUT_PRI){if(kk===k)break;if(T.done[kk])continue;const LL=TUT_L[kk];let w=false;try{w=tutCtxOk(LL.ctx)&&LL.when();}catch(e){}if(w){r.push('раньше в очереди «'+(TUT_NM65[kk]||kk)+'»');break;}}
  if(TUT.hist&&TUT.hist.filter(h=>performance.now()-h<600000).length>=6)r.push('лимит: не больше 6 уроков за 10 минут');
  return r.length?r:['ничего не мешает — урок начнётся в ближайшие 0,1 с'];}

/* ---------- значки вкладок ---------- */
const DVX_TABS=[['jump','ПРЫЖОК','<circle cx="10" cy="10" r="6.5"/><circle cx="10" cy="10" r="1.8"/><path d="M10 1.5v3M10 15.5v3M1.5 10h3M15.5 10h3"/>'],
  ['ship','КОРАБЛЬ','<path d="M10 2.5l6 14-6-3.2-6 3.2z"/>'],
  ['fight','БОЙ','<path d="M4 16L14.5 5.5M11.5 3.5l5 5M3 13l4 4"/>'],
  ['world','МИР','<circle cx="10" cy="10" r="7.5"/><path d="M2.5 10h15M10 2.5c2.6 2.4 2.6 12.6 0 15M10 2.5c-2.6 2.4-2.6 12.6 0 15"/>'],
  ['prog','ПРОГРЕСС','<path d="M4 17V3M4 3.5h10l-2 3 2 3H4"/>'],
  ['tut','ОБУЧЕНИЕ','<circle cx="10" cy="10" r="7.5"/><path d="M7.6 7.6a2.5 2.5 0 1 1 3.4 2.3c-.7.3-1 .8-1 1.6M10 14.2v.3"/>'],
  ['dbg','ОТЛАДКА','<rect x="2.5" y="3.5" width="15" height="13" rx="1.5"/><path d="M5.5 8l2.5 2-2.5 2M10 12.5h4"/>']];
const dvIco=p=>`<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;

/* ---------- панель ---------- */
function dvCtx(){return dvOn()?(G.zb?'zb':G.post?'post':inMission()?'mis':'world'):G.devRun?(G.mode==='endless'?'end':'mis'):'none';}
function dvCtxKey(){const c=dvCtx();return c==='zb'?'zb:'+(['fight','race'].includes(G.zb.k)?'f':G.zb.k):c+':'+G.state;}
function dvxEl(){let P=document.getElementById('dvx');if(!P){P=document.createElement('div');P.id='dvx';P.hidden=true;P.setAttribute('role','dialog');P.setAttribute('aria-label','Панель разработчика');P.setAttribute('lang','ru');document.body.appendChild(P);
    ['pointerdown','mousedown','touchstart','wheel','click','contextmenu'].forEach(ev=>P.addEventListener(ev,e=>e.stopPropagation(),{passive:ev!=='click'&&ev!=='contextmenu'}));
    P.addEventListener('click',dvxClick);P.addEventListener('change',dvxChange);P.addEventListener('keydown',e=>{if(e.target.tagName==='INPUT'){e.stopPropagation();if(e.code==='Enter'){const b=e.target.closest('.r65')&&e.target.closest('.r65').querySelector('[data-a]');if(b)b.click();}if(e.code==='Escape')e.target.blur();}});}
  return P;}
function dvxOpen(force){if(!devAny())return;const P=dvxEl();const on=force!==undefined?!!force:P.hidden;if(!on){dvxClose();return;}
  ['dwPanel','devPanel'].forEach(id=>{const e=document.getElementById(id);if(e)e.hidden=true;});
  DVX.open=true;P.hidden=false;document.documentElement.classList.add('dvx-on');dvxRender();clearInterval(DVX.live);DVX.live=setInterval(()=>{if(!DVX.open||!devAny()){dvxClose();return;}if(dvCtxKey()!==DVX.ctx)dvxRender();else dvxLive();},250);dvxBar();}
function dvxClose(){DVX.open=false;const P=document.getElementById('dvx');if(P)P.hidden=true;document.documentElement.classList.remove('dvx-on');clearInterval(DVX.live);DVX.live=null;try{dvxBar();}catch(e){}}
toggleDevPanel=function(force){if(!devAny())return;dvxOpen(force);};
{const _k=DEVW.key;DEVW.key=function(e){if(e.code==='Backquote'&&(G.state==='world'||G.state==='play')){dvxOpen();return true;}
  if(G.state==='pause'&&G.pausedWorld&&e.code==='Escape'){DEVW.exit();return true;}return _k.apply(this,arguments);};}
{const _pu=DEVW.pauseUI;DEVW.pauseUI=function(){const r=_pu.apply(this,arguments);const b=document.getElementById('bDevExit');if(b)b.onclick=()=>DEVW.exit();return r;};}
{const _p=DEVW.panel;DEVW.panel=function(force){dvxOpen(force);};}
/* выход из режима посреди боя с боссом 50, сторожевика или миссии — сначала чисто в мир песочницы, иначе бой «висит» */
{const _ex=DEVW.exit;DEVW.exit=function(){try{if(dvOn()){dvxClose();dvLeave();}}catch(e){console.error(e);}dvSeedOff();return _ex.apply(this,arguments);};}

const seg=(a,cur,opts)=>`<div class="seg65">${opts.map(([v,n])=>`<button data-a="${a}" data-v="${v}" class="${String(v)===String(cur)?'on':''}">${n}</button>`).join('')}</div>`;
const tog=(k,n,dis)=>`<button class="tg65${G.dev[k]?' on':''}" data-a="tog" data-v="${k}"${dis?` disabled title="${dis}"`:''} aria-pressed="${!!G.dev[k]}"><i></i><span>${n}</span>${dis?`<em>${dis}</em>`:''}</button>`;
const btn=(a,v,n,cls,dis)=>`<button class="b65${cls?' '+cls:''}" data-a="${a}" data-v="${v}"${dis?` disabled title="${dis}"`:''}>${n}${dis?`<em>${dis}</em>`:''}</button>`;
const grp=(h,body,note)=>`<section class="g65"><h4>${h}</h4>${body}${note?`<p class="n65">${note}</p>`:''}</section>`;
function dvxRender(){const P=dvxEl();if(!DVX.open)return;DVX.ctx=dvCtxKey();let tab=G.dev.dvTab||'jump';if(!DVX_TABS.some(t=>t[0]===tab))tab='jump';DVX.tab=tab;
  const sb=dvOn();const title=DVX_TABS.find(t=>t[0]===tab)[1];
  const head=`<div class="h65"><b>РАЗРАБОТКА</b><span>${sb?'ПЕСОЧНИЦА':'СЕТКА МИССИЙ'} · ${title}</span><button class="x65" data-a="close" aria-label="Закрыть панель">✕</button></div>`;
  const tabs=`<div class="t65" role="tablist">${DVX_TABS.map(([k,n,ic])=>`<button role="tab" data-a="tab" data-v="${k}" class="${k===tab?'on':''}" aria-selected="${k===tab}" title="${n}">${dvIco(ic)}<span>${n}</span></button>`).join('')}</div>`;
  let body='';try{body=DVX_R[tab]();}catch(e){console.error(e);body=`<p class="n65">Ошибка вкладки: ${e.message}</p>`;}
  const foot=`<button class="ex65" data-a="exit">${sb?'ВЫЙТИ ИЗ РЕЖИМА РАЗРАБОТЧИКА':'К ВЫБОРУ МИССИЙ'}</button>`;
  const sc=P.querySelector('.bd65');const top=sc?sc.scrollTop:0;const keepTab=P.dataset.tab===tab;
  P.innerHTML=head+tabs+`<div class="bd65">${body}</div>`+foot;P.dataset.tab=tab;if(keepTab){const s2=P.querySelector('.bd65');if(s2)s2.scrollTop=top;}dvxLive();}
function dvxLive(){const P=document.getElementById('dvx');if(!P||P.hidden)return;const p=G.player;
  P.querySelectorAll('[data-live]').forEach(el=>{let t='';try{t=DVX_LIVE[el.dataset.live]();}catch(e){t='—';}if(el.textContent!==t)el.textContent=t;});
  if(DVX.tab==='dbg'){const L=P.querySelector('#log65');if(L){const h=DVX.log.slice(-60).reverse().map(e=>`<div><b>${new Date(e.t).toTimeString().slice(0,8)}</b> <i>${e.kind}</i> ${kh?kh(e.text):e.text}</div>`).join('')||'<div>пусто</div>';if(L.dataset.n!==String(DVX.log.length)){L.innerHTML=h;L.dataset.n=DVX.log.length;}}}}
const DVX_LIVE={
  pos:()=>{const p=G.player;return p?Math.round(p.x)+' '+Math.round(p.y)+' · '+sectorName(p.x,p.y):'—';},
  hp:()=>{const p=G.player;return p?'HP '+Math.round(p.hp)+' / '+Math.round(G.st&&G.st.maxHp||0)+' · EN '+Math.round(p.en||0)+(G.taken?' · получено урона '+Math.round(G.taken):''):'—';},
  zb:()=>{const Z=G.zb;if(!Z)return '—';return ({silence:'ТИШИНА',walls:'СТЕНЫ',expand:'РАСШИРЕНИЕ',pick:'ВЫБОР КОМПЛЕКТА',spawn:'ПОЯВЛЕНИЕ',fight:'БОЙ',race:'ГОНКА',choice:'ВЫБОР',end:'ФИНАЛ',seg:'СЕГМЕНТ'}[Z.k]||Z.k.toUpperCase())+' · СТАДИЯ '+Z.stage+'/4 · СЕГМЕНТ '+(Z.segMax?Math.round(Z.hp/Z.segMax*100):0)+'% · СБОЙ '+Math.round(Z.stg||0);},
  post:()=>{const P_=G.post;if(!P_)return '—';const O=P_.O;return 'АКТ '+(P_.act+1)+'/'+POST_ACTS.length+' · '+POST_ACTS[P_.act].name+' · ХОЛОД '+Math.round((P_.cold||0)*100)+'% · СУЩЕСТВО '+(!O||O.st==='off'?'НЕ ВИДНО':'РЯДОМ')+(P_.escape>0?' · ПОБЕГ '+Math.max(0,P_.escT||0).toFixed(0)+' С':'');},
  mast:()=>{const M=typeof MASTERY!=='undefined'&&MASTERY[G.m-1];if(!M||!G.mc)return '—';let ok=false;try{ok=!!M.ok();}catch(e){}return (ok?'✓ ':'· ')+M.t;},
  mis:()=>{if(!inMission())return '—';return pad2(G.m)+' · '+(MISSIONS[G.m-1]?mName(MISSIONS[G.m-1]):'')+' · ВОЛНА '+((G.waveIdx||0)+1)+'/'+((G.waves||[]).length||'—')+' · ВРАГОВ '+G.enemies.filter(e=>e.alive).length;},
  perf:()=>'FPS '+Math.round(typeof fpsAvg!=='undefined'?fpsAvg:0)+' · ВРАГОВ '+(G.enemies||[]).filter(e=>e.alive).length+' · ПУЛЬ '+((G.eb||[]).length+(G.pb||[]).length)+' · ЧАСТИЦ '+(G.parts||[]).length,
  guard:()=>{const W=DEVW.stats?DEVW.stats():{blocked:{},warn:[]};const n=Object.values(W.blocked||{}).reduce((a,b)=>a+b,0)+(W.warn||[]).length;return 'ЗАБЛОКИРОВАНО ЗАПИСЕЙ В ИГРУ: '+n+((W.warn||[]).length?' · последняя: '+W.warn[W.warn.length-1].slice(0,80):'');},
  errs:()=>DVX.errs.length?DVX.errs.length+' · последняя: '+DVX.errs[DVX.errs.length-1].m:'нет'};

const DVX_R={
 jump(){if(!dvOn())return grp('ТОЛЬКО В ПЕСОЧНИЦЕ',btn('sandbox',1,'ОТКРЫТЬ ОТКРЫТЫЙ МИР','wide'),'Прыжки работают в открытом мире разработчика. Отсюда — его карта, все 50 миссий, сторожевик и босс 50.');
  const S=G.save;const secs={};for(let m=1;m<=50;m++){const n=WORLD.nodes[m-1];if(!n)continue;const si=sectorIdx(n.x,n.y);(secs[si]||(secs[si]=[])).push(m);if(m===CORE)secs[si].push('post');}
  const tile=m=>{if(m==='post'){const d=postDone();return `<div class="m65 post${d?' done':''}"><button class="mj" data-a="node" data-v="post" title="К шлюзу"><b>❄</b><span>Сторожевик</span></button><button class="me" data-a="enter" data-v="post" title="Войти сразу" aria-label="Войти в сторожевик">▶</button></div>`;}
    const md=S.medals&&S.medals[m]||{},done=progDone(m),boss=BOSS_LV.has(m),M=MISSIONS[m-1];
    return `<div class="m65${done?' done':''}${boss?' boss':''}${md.master?' master':''}"><button class="mj" data-a="node" data-v="${m}" title="К узлу ${pad2(m)}"><b>${pad2(m)}</b><span>${M?mName(M):''}</span></button><button class="me" data-a="enter" data-v="${m}" title="Войти сразу" aria-label="Войти в миссию ${m}">▶</button></div>`;};
  const grid=Object.keys(secs).sort((a,b)=>a-b).map(si=>{const s=WORLD.sectors[si];return `<div class="sh65" style="--sc:${s&&s.col||'#00ff88'}">${roman(+si+1)} · ${s?s.name:''}</div><div class="mg65">${secs[si].map(tile).join('')}</div>`;}).join('');
  const bm=G.dev.bm.map((q,i)=>`<div class="bm65">${btn('bmgo',i,q?`★${i+1} ${q.label}`:`★${i+1} ПУСТО`,'',q?'':'')}${btn('bmset',i,'ЗАПОМНИТЬ')}</div>`).join('');
  return grp('СЕЙЧАС','<p class="lv65" data-live="pos"></p>'+`<div class="r65">${btn('back',0,'← НАЗАД','',DVX.hist.length?'':'история пуста')}${btn('copypos',0,'КОПИРОВАТЬ МОИ')}</div>`)+
   grp('МИССИИ',grid,'Нажатие — к узлу, ▶ — сразу в брифинг. Shift+клик — тоже сразу. Цифры с клавиатуры: «27» → Enter.')+
   grp('МЕСТА',`<div class="r65 wr">${DV_PLACES.map(([k,n])=>btn('place',k,n)).join('')}</div><div class="r65 wr">${WORLD.sectors.map((s,i)=>btn('sec',i,roman(i+1))).join('')}</div>`,'Римские — центры секторов I–XII.')+
   grp('БЛИЖАЙШЕЕ',`<div class="r65 wr">${DV_NEAR.map(([k,n,f])=>btn('near',k,n+' →')).join('')}</div>`,'Повторное нажатие — следующий по дальности. Так можно обойти все '+WORLD.journals.length+' журналов подряд.')+
   grp('ЗАКЛАДКИ',bm,'Ctrl+1/2/3 — запомнить, Alt+1/2/3 — прыжок.')+
   grp('КООРДИНАТЫ',`<div class="r65"><input id="xy65" inputmode="numeric" placeholder="X Y" aria-label="Координаты X Y">${btn('xy',0,'ПРЫЖОК')}</div>`,'Alt+клик или долгое нажатие на карте (M) — прыжок в точку.');},
 ship(){const g=devGod();const sb=dvOn();
  return grp('БЕССМЕРТИЕ · G',seg('god',g,[[0,'ВЫКЛ'],[1,'ДЕРЖАТЬ 1 HP'],[2,'ПОЛНОЕ']])+'<p class="lv65" data-live="hp"></p>','«1 HP» — урон, вспышки и счётчик урона как в игре, но корабль не погибает. «Полное» — удар проходит как в игре (отброс, вспышка), но здоровье сразу возвращается; лёд и износ не копятся. Бой с бессмертием идёт так же, как без него.')+
   grp('КОРАБЛЬ',`<div class="tg65w">${tog('bcGod','НЕУЯЗВИМЫЙ МАЯК')}${tog('en','БЕСКОНЕЧНАЯ ЭНЕРГИЯ')}${tog('nocd','РЫВОК БЕЗ ПЕРЕЗАРЯДКИ')}${tog('ohk','С ОДНОГО ПОПАДАНИЯ')}${tog('noclip','СКВОЗЬ СКАЛЫ',!sb?'только в песочнице':G.zb?'не в бою с боссом 50':'')}</div>`+`<div class="r65">${btn('heal',0,'ПОЛНОЕ ЗДОРОВЬЕ · H')}</div>`,'«С одного попадания» не действует на боссов — их фазы идут честно. Ворота и стены секторов в песочнице и так открыты.')+
   (sb?grp('СКОРОСТЬ ПОЛЁТА · [ ]',seg('wspd',DEVW.spd(),[[.5,'×0,5'],[1,'×1'],[2,'×2'],[4,'×4'],[8,'×8']]),'Только перемещение корабля. Скорость всей игры — во вкладке «Бой».'):'')+
   grp('КОРПУС',`<div class="r65">${btn('skin',-1,'←')}<span class="lv65 c65">${(SKINS[G.save&&G.save.skin||'base']||{}).name||G.save&&G.save.skin||'—'}</span>${btn('skin',1,'→')}</div>`+(sb?`<div class="r65">${btn('skins','all','ВСЕ КОРПУСА')}${btn('skins','base','ТОЛЬКО БАЗОВЫЙ')}</div>`:''),'Смена корпуса на лету — видно все 16 живых корпусов 1.4.0 в бою.');},
 fight(){const c=dvCtx();let ctxh='';
  if(c==='zb'&&!['fight','race'].includes(G.zb.k)){const Z=G.zb,intro=['silence','walls','expand','spawn'].includes(Z.k);
    ctxh=grp('БОСС 50 · НУЛЕВОЙ МИГ','<p class="lv65" data-live="zb"></p>'+(intro?`<div class="r65">${btn('zbskip',0,'ПРОПУСТИТЬ ВХОД · ДО ВЫБОРА КОМПЛЕКТА','wide')}</div>`:'')+`<div class="r65 wr">${btn('zbleave',0,'ПОКИНУТЬ БОЙ')}${btn('zbagain',0,'СНОВА С НАЧАЛА')}</div>`,
      intro?'Тишина → стены → расширение → выбор комплекта. Стадии, атаки и сегменты появятся, когда начнётся бой.':Z.k==='pick'?'Выберите стартовый комплект — дальше бой, и здесь появятся стадии, атаки и сегменты.':'Финал: выбор и кинематограф. «Снова с начала» — новый заход.');}
  else if(c==='zb'){const Z=G.zb;ctxh=grp('БОСС 50 · НУЛЕВОЙ МИГ','<p class="lv65" data-live="zb"></p>'+
     `<div class="r65">${[1,2,3,4].map(n=>btn('zbst',n,'СТАДИЯ '+n,Z.stage===n?'on':'',Z.boss?'':'ещё нет босса')).join('')}</div>`+
     `<div class="r65 wr">${[100,50,30,20,5].map(v=>btn('zbhp',v,'СЕГМЕНТ '+v+'%','',Z.k==='fight'?'':'только в бою')).join('')}${btn('zbstun',0,'СБОЙ СЕЙЧАС','',Z.k==='fight'?'':'только в бою')}</div>`+
     `<div class="r65 wr">${[['blink','ВСПЫШКА'],['tridash','ТРОЙНОЙ БРОСОК'],['grid','РЕШЁТКА'],['star','ЗВЕЗДА'],['burst','ОЧЕРЕДЬ'],['mines','НУЛИ'],['dash','БРОСОК'],['fan','ВЕЕР'],['beam','ЛУЧ'],['pulse','ИМПУЛЬС'],['clone','ОТРАЖЕНИЕ']].map(([k,n])=>btn('zbatk',k,n,'',Z.k==='fight'&&Z.boss?'':'только в бою')).join('')}</div>`+
     `<div class="tg65w">${tog('zbCalm','ДИРИЖЁР ВЫКЛ · БОСС НЕ АТАКУЕТ САМ')}</div>`+
     `<div class="r65 wr">${btn('zbchoice',0,'ФИНАЛ · ВЫБОР','',Z.boss?'':'ещё нет босса')}${btn('zbleave',0,'ПОКИНУТЬ БОЙ')}${btn('zbagain',0,'СНОВА С НАЧАЛА')}</div>`,'Атаки по имени — через зацепку игры zbAtk, телеграфы и урон настоящие.');}
  else if(c==='post'){const P_=G.post;ctxh=grp('СТОРОЖЕВИК «ИЗМОРОЗЬ»','<p class="lv65" data-live="post"></p>'+`<div class="r65 wr">${POST_ACTS.map((A,i)=>btn('pact',i,(i+1)+' · '+A.name,P_.act===i?'on':'')).join('')}</div>`+
     `<div class="r65 wr">${btn('ptask',0,'ВСЕ ЗАДАЧИ АКТА')}${btn('pdoor',0,'ОТКРЫТЬ ДВЕРЬ')}${btn('pwin',0,'ПРОЙТИ ЦЕЛИКОМ')}</div>`+
     `<div class="tg65w">${tog('postFreeze','СУЩЕСТВО НЕ ПРИХОДИТ')}${tog('postLight','ВСЁ ВИДНО · ТЕМНОТА 0')}${tog('postCold','ХОЛОД ВЫКЛ')}</div>`+
     `<div class="r65 wr">${btn('pcall',0,'ВЫЗВАТЬ СУЩЕСТВО')}${btn('pscare',0,'СТУК')}${btn('pscare',1,'ПУГАЛКА 2')}${btn('pscare',2,'ПУГАЛКА 3')}${btn('pstrobe',0,'СТРОБОСКОП')}${btn('pfig',0,'ФИГУРА')}${btn('proll',0,'ПОВЕРКА',P_.trig?'':'не в этом акте')}</div>`,'Акт загружается со своей контрольной точкой. «Пройти целиком» — итоги, тост и курс на 11, как в игре, но только в песочнице.');}
  else if(c==='mis'||c==='end'){const M=c==='end'?null:MISSIONS[G.m-1];const pl=G.state==='play'?'':'только в бою';
   ctxh=grp(c==='end'?'БЕСКОНЕЧНОСТЬ':'МИССИЯ','<p class="lv65" data-live="mis"></p>'+(c==='mis'?'<p class="lv65" data-live="mast"></p>':'')+
     `<div class="r65 wr">${btn('dv','kill','УБИТЬ ВСЕХ · K','',pl)}${M&&!M.beacon&&!M.boss?btn('dv','wave','СЛЕДУЮЩАЯ ВОЛНА · N','',pl):''}${M&&(M.boss||M.transmit||M.sboss)?btn('dv','boss',G.boss||G.jam||G.sb?'ФАЗА БОССА · N':'К БОССУ · N','',pl):''}${G.bc?btn('dv','charge','МАЯК +25%','',pl):''}${c==='end'?btn('dv','step','СЛЕДУЮЩАЯ СТУПЕНЬ','',pl):''}${btn('dv','lvl','УРОВЕНЬ МОДУЛЕЙ +1','',pl)}</div>`+
     (dvOn()?`<div class="r65">${btn('leave',0,'ПОКИНУТЬ МИССИЮ')}</div>`:''));}
  else ctxh=grp('КОНТЕКСТ','<p class="n65">Сейчас вы в секторе. Здесь появятся инструменты миссии, босса 50 или сторожевика, когда вы туда войдёте.</p>');
  const types=CODEX_ORDER.filter(k=>EDEF[k]&&!['boss','jam','lock','obheart','obseg','invcell','invcore','cpart'].includes(k));
  return ctxh+grp('ПРИЗВАТЬ',`<div class="r65"><select id="sp65" aria-label="Враг">${types.map(k=>`<option value="${k}">${EDEF[k].name}</option>`).join('')}</select></div><div class="r65">${[1,5,20].map(n=>btn('spawn',n,'×'+n,'',G.player&&(G.state==='world'||G.state==='play')?'':'нужен полёт')).join('')}${btn('killr',0,'УБИТЬ РЯДОМ')}</div>`,'В секторе — рядом с кораблем, в миссии — от края арены.')+
   grp('ВРЕМЯ · Shift+[ ]',seg('ts',G.dev.tpause?0:G.dev.tscale,[[0,'ПАУЗА'],[.25,'×¼'],[.5,'×½'],[1,'×1'],[2,'×2'],[4,'×4']])+`<div class="r65">${btn('stepf',0,'ОДИН КАДР · .','',G.dev.tpause?'':'сначала пауза')}</div>`+`<div class="tg65w">${tog('freeze','ЗАМОРОЗИТЬ ВРАГОВ И ПУЛИ')}</div>`,'Влияет на весь бой: врагов, пули, босса. На телефоне при открытой панели игра стоит сама.');},
 world(){if(!dvOn())return grp('ТОЛЬКО В ПЕСОЧНИЦЕ',btn('sandbox',1,'ОТКРЫТЬ ОТКРЫТЫЙ МИР','wide'));const S=G.save;const fogAll=S.reveal&&S.reveal.indexOf('0')<0;
  return grp('СОБЫТИЯ',`<div class="r65 wr">${btn('w58','storm','БУРЯ ЗДЕСЬ')}${btn('w58','pack','СТАЯ РЯДОМ')}${btn('w58','tug','БУКСИР')}${btn('w58','wander','СБРОС СТРАННИКА')}${btn('w58','reset','СБРОС СОБЫТИЙ')}</div>`,'Через игровую зацепку w58Dev: событие запускается так же, как в игре.')+
   grp('ТУМАН',`<div class="r65">${btn('fog',1,'ОТКРЫТЬ ВСЁ',fogAll?'on':'')}${btn('fog',0,'ЗАКРЫТЬ ВСЁ',!fogAll?'on':'')}</div>`,'Закрытый туман — чтобы проверить, как его видит новичок. Ворота от тумана не зависят.')+
   grp('СЛОИ',`<div class="tg65w">${tog('hit','ХИТБОКСЫ')}${tog('fps','FPS И ЧИСЛО ОБЪЕКТОВ')}</div>`);},
 prog(){if(!dvOn())return grp('ТОЛЬКО В ПЕСОЧНИЦЕ',btn('sandbox',1,'ОТКРЫТЬ ОТКРЫТЫЙ МИР','wide'));const S=G.save;const N=Number.isInteger(S.devProg)?S.devProg:doneCount();
  const flags=Object.keys(S.story||{}).filter(k=>['number','boolean'].includes(typeof S.story[k])).sort();
  const snaps=[1,2,3].map(i=>{const v=dvSnapGet(i);return `<div class="bm65"><span class="lv65">${i} · ${v?v.sec+' · '+new Date(v.t).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'пусто'}</span>${btn('snapS',i,'СОХРАНИТЬ')}${btn('snapL',i,'ЗАГРУЗИТЬ','',v?'':'пусто')}</div>`;}).join('');
  return grp('КАМПАНИЯ',`<div class="r65"><input id="prog65" type="range" min="0" max="50" step="1" value="${N}" aria-label="Пройдено до"><b class="c65" id="progv65">${N}</b>${btn('prog',0,'ПРИМЕНИТЬ')}</div>`+`<div class="r65 wr">${[0,2,6,10,14,27,49,50].map(n=>btn('progq',n,String(n))).join('')}</div>`,'Пройдено до N: миссии, медали прохождения, ворота и флаг «Миг». До 10 — обучение снова живое (вкладка «Обучение»).')+
   grp('РЕСУРСЫ',`<div class="r65 wr">${btn('lom',500,'ЛОМ +500')}${btn('lom',5000,'+5 000')}${btn('lom0',0,'ЛОМ 0')}${btn('carry',100,'ГРУЗ +100')}</div><div class="r65">${btn('plvl',-1,'ПИЛОТ −')}<b class="c65">УР. ${S.pilot&&S.pilot.lvl||1}</b>${btn('plvl',1,'ПИЛОТ +')}${btn('plvl',10,'+10')}</div>`)+
   grp('СЮЖЕТ · ЦИКЛ '+roman(S.cycle||1),`<div class="r65 wr">${btn('read',0,'ВСЕ ЗАПИСИ')}${btn('frag',0,'ФРАГМ. 0')}${btn('frag',6,'6')}${btn('frag',15,'15')}${btn('ero',0,'ЭРОЗИЯ 0')}${btn('ero',.5,'0,5')}${btn('ero',1,'1')}${btn('cyc',-1,'ЦИКЛ −')}${btn('cyc',1,'ЦИКЛ +')}</div>`+
     (flags.length?`<div class="fl65">${flags.map(k=>`<button data-a="flag" data-v="${k}" class="${S.story[k]?'on':''}"><span>${k}</span><b>${String(S.story[k])}</b></button>`).join('')}</div>`:''),'Флаги сюжета: нажатие — следующее значение (0 → 1 → 2 → 3 → 0).')+
   grp('СНИМКИ · F5 / F9',snaps,'Снимок — вся песочница с позицией. F5 — в слот 1, F9 — из слота 1.')+
   grp('ИСТОЧНИК',`<div class="r65 wr">${btn('mine',0,DVX.arm.mine?'ТОЧНО? НАЖМИТЕ ЕЩЁ РАЗ':'КОПИЯ МОЕГО ПРОГРЕССА',DVX.arm.mine?'arm':'')}${btn('reset',0,DVX.arm.reset?'ТОЧНО? НАЖМИТЕ ЕЩЁ РАЗ':'СБРОСИТЬ ПЕСОЧНИЦУ',DVX.arm.reset?'arm':'')}</div>`,'Копия читает настоящее сохранение и больше его не трогает — обратного пути нет ни в одной кнопке.');},
 tut(){if(!dvOn())return grp('ТОЛЬКО В ПЕСОЧНИЦЕ',btn('sandbox',1,'ОТКРЫТЬ ОТКРЫТЫЙ МИР','wide'));const T=tutT()||{done:{},seen:{}};const cur=TUT.cur&&TUT.cur.k;
  const rows=TUT_PRI.filter(k=>TUT_L[k]).map(k=>{const st=cur===k?'ИДЁТ':T.done[k]?(T.ok&&T.ok[k]?'ЗАСЧИТАН':'СДЕЛАН'):'ЖДЁТ';const why=DVX.why===k;
    return `<div class="tu65${cur===k?' cur':''}${T.done[k]?' done':''}"><b>${TUT_NM65[k]||k}</b><span>${st}</span>${btn('tutgo',k,'▶')}${btn('tutrs',k,'↺','',T.done[k]||T.seen&&T.seen[k]?'':'')}${btn('tutwhy',k,'?',why?'on':'')}${why?`<ul>${dvTutWhy(k).map(x=>`<li>${x}</li>`).join('')}</ul>`:''}</div>`;}).join('');
  const blk=dvTutBlock();return grp('ОБУЧЕНИЕ',`<p class="lv65">${blk?'⚠ ВЫКЛЮЧЕНО ИГРОЙ: '+blk:G.dev.tut?(TUT.cur?'ИДЁТ УРОК «'+(TUT_NM65[TUT.cur.k]||TUT.cur.k)+'»':'АКТИВНО · ЖДЁТ ПОВОДА'):'ВЫКЛЮЧЕНО ПЕРЕКЛЮЧАТЕЛЕМ'}</p>`+(blk?`<div class="r65">${btn('tutprep',2,'ПРОЙДЕНО ДО 2 · КОРАБЛЬ К МИССИИ 03','wide')}</div>`:'')+`<div class="tg65w">${tog('tut','ПОДСКАЗКИ ОБУЧЕНИЯ В ПЕСОЧНИЦЕ')}</div><div class="r65 wr">${btn('tutall',1,'ВСЕ СДЕЛАНЫ')}${btn('tutall',0,'СБРОСИТЬ ВСЁ')}</div>`,'Подсказки ведут себя как у нового пилота. Обучение само кончается после миссии 10 и в секторе III — для проверки поставьте «пройдено до» меньше 10.')+
   grp('УРОКИ · ПОРЯДОК ОЧЕРЕДИ',rows,'▶ — показать сейчас, ↺ — сбросить один, ? — почему урок не начинается.');},
 dbg(){return grp('СИД БОЯ',`<div class="r65"><input id="seed65" inputmode="numeric" value="${G.dev.seed}" aria-label="Сид">${btn('seed',0,'ПРИМЕНИТЬ')}${btn('seedrnd',0,'НОВЫЙ')}</div>`+seg('seedOn',G.dev.seedOn?1:0,[[0,'СЛУЧАЙНЫЙ'],[1,'ФИКСИРОВАННЫЙ']]),'Фиксированный сид действует со следующего входа в миссию: раскладка, брифинг и бой повторяются один в один — сколько бы вы ни читали брифинг. Звук (1.4.1), взрывы и отрисовка (1.4.5) на бой не влияют; держите одинаковые «Эффекты». Для повтора удобно: снимок в тихом месте → бой → тот же снимок. Стычка в секторе перед входом тоже меняет начало миссии.')+
   grp('СОСТОЯНИЕ','<p class="lv65" data-live="perf"></p><p class="lv65" data-live="guard"></p><p class="lv65" data-live="errs"></p>'+`<div class="r65 wr">${btn('report',0,'КОПИРОВАТЬ ОТЧЁТ')}${btn('errsee',0,'ОШИБКИ ПОДРОБНО','',DVX.errs.length?'':'ошибок нет')}${btn('logclr',0,'ОЧИСТИТЬ ЖУРНАЛ')}</div>`+(DVX.errOpen?`<div class="er65">${DVX.errs.slice().reverse().map(e=>`<p><b>${new Date(e.t).toTimeString().slice(0,8)}</b> ${e.m}<br><i>${e.s||''}</i></p>`).join('')}</div>`:''))+
   grp('ЖУРНАЛ СОБЫТИЙ','<div id="log65" class="lg65"></div>','200 последних: прыжки, входы и выходы, гибели, уроки, баннеры, снимки.')+
   grp('КЛАВИШИ',`<div class="kg65">${[['Ё / `','панель'],['G','бессмертие по кругу'],['H','полное здоровье'],['[ ]','скорость полёта'],['Shift+[ ]','скорость времени'],['.','пауза / один кадр'],['0–9, Enter','к миссии · Shift+Enter — войти'],['I · O','сторожевик · босс 50'],['Backspace','назад'],['Ctrl+1/2/3 · Alt+1/2/3','закладка: запомнить · прыжок'],['F5 · F9','снимок: сохранить · загрузить'],['K · N','убить всех · дальше'],['Alt+клик на карте','прыжок в точку'],['ESC дважды','выход из режима']].map(([k,v])=>`<kbd>${k}</kbd><span>${v}</span>`).join('')}</div>`,'Клавиши работают только в режиме разработчика и не пересекаются с игровыми.');}};

/* ---------- действия ---------- */
function dvxChange(e){const t=e.target;if(t.id==='prog65'){const v=$('#progv65');if(v)v.textContent=t.value;}}
document.addEventListener('input',e=>{if(e.target&&e.target.id==='prog65'){const v=$('#progv65');if(v)v.textContent=e.target.value;}});
function dvxClick(e){const b=e.target.closest('[data-a]');if(!b||b.disabled)return;/* мышью — снимаем фокус: иначе Пробел (рывок) нажмёт эту кнопку ещё раз */if(e.detail>0&&b.blur)b.blur();const a=b.dataset.a,v=b.dataset.v;try{dvAct(a,v,e);}catch(er){console.error(er);devLog('err','действие '+a+': '+er.message);}try{buzz('tap');}catch(er){}}
function dvAct(a,v,e){const S=G.save,p=G.player;let rr=true;
  switch(a){
  case 'close':dvxClose();return;
  case 'tab':G.dev.dvTab=v;dvSave();DVX.why=null;DVX.errOpen=false;break;
  case 'exit':dvxClose();if(dvOn())DEVW.exit();else openDev();return;
  case 'sandbox':dvxClose();DEVW.enter();return;
  case 'god':G.dev.god=+v===2;G.dev.god1=+v===1;dvSave();devLog('dev','бессмертие '+v);break;
  case 'tog':G.dev[v]=!G.dev[v];dvSave();devLog('dev',v+' '+(G.dev[v]?'вкл':'выкл'));if(v==='tut'&&G.dev.tut){const T=tutT();if(T&&(S.cleared||0)<CORE&&!(G.player&&sectorIdx(G.player.x,G.player.y)>=2))T.off=0;}break;
  case 'heal':if(p){p.hp=G.st.maxHp;p.en=100;floater(p.x,p.y-40,'ЗДОРОВЬЕ · ПОЛНОЕ','#00ff88');}break;
  case 'wspd':G.dev.wspeed=+v;dvSave();try{DEVW.ui();}catch(er){}break;
  case 'skin':{if(!S)break;const L=(S.ownSkins&&S.ownSkins.length?S.ownSkins:Object.keys(SKINS)).filter(k=>SKINS[k]);const i=L.indexOf(S.skin||'base');S.skin=L[(i+(+v)+L.length)%L.length];if(p)floater(p.x,p.y-40,'КОРПУС · '+((SKINS[S.skin]||{}).name||S.skin),'#00ff88');if(dvOn())saveWorld();break;}
  case 'skins':if(!S)break;S.ownSkins=v==='all'?Object.keys(SKINS):['base'];S.skins=S.ownSkins.slice();if(v!=='all')S.skin='base';saveWorld();break;
  case 'node':if(e&&e.shiftKey){dvGoNode(v==='post'?'post':+v,true);return;}dvGoNode(v==='post'?'post':+v,false);return;
  case 'enter':dvxClose();dvGoNode(v==='post'?'post':+v,true);return;
  case 'place':{const P_=DV_PLACES.find(x=>x[0]===v);const q=P_&&P_[2]();if(q)devJump(q.x,q.y+(v==='abyss'||v==='zero'||v==='post'||v==='gate'?0:150),P_[1].toLowerCase(),{exact:v==='zero'||v==='post'});return;}
  case 'sec':{const q=dvSecC(+v);if(q)devJump(q.x,q.y,'сектор '+roman(+v+1));return;}
  case 'near':dvNear(v);return;
  case 'back':dvBack();return;
  case 'copypos':if(p)dvCopy(Math.round(p.x)+' '+Math.round(p.y),'Координаты корабля в буфере.');return;
  case 'bmset':if(p){G.dev.bm[+v]={x:Math.round(p.x),y:Math.round(p.y),label:sectorName(p.x,p.y)};dvSave();toast('ЗАКЛАДКА '+(+v+1),G.dev.bm[+v].label);}break;
  case 'bmgo':{const q=G.dev.bm[+v];if(q)devJump(q.x,q.y,'закладка '+(+v+1),{exact:1});else toast('ЗАКЛАДКА '+(+v+1),'Пусто. Ctrl+'+(+v+1)+' — запомнить место.');return;}
  case 'xy':{const t=($('#xy65')||{}).value||'';const m=t.match(/-?\d+(?:[.,]\d+)?/g);if(m&&m.length>=2)devJump(+m[0].replace(',','.'),+m[1].replace(',','.'),'координаты',{exact:1});else toast('КООРДИНАТЫ','Введите два числа: X Y');return;}
  case 'zbskip':{const Z=G.zb;let n=0;while(G.zb&&['silence','walls','expand','spawn'].includes(G.zb.k)&&n++<900){if(G.player)G.player.hp=Math.max(G.player.hp,1);worldUpdate(1/60);}devLog('zb','вход пропущен → '+(G.zb?G.zb.k:'—'));break;}
  case 'zbst':{const Z=G.zb;if(!Z||!Z.boss)break;for(const q of G.enemies)if(q.alive&&q.zb===2)q.alive=false;Z.clones=[];Z.k='fight';Z.t=0;Z.stall=0;Z.lunge=0;G.wtg95=[];G.eb=[];Z.boss.ghost=false;Z.boss.zbHide=0;zbStageInit(Z,+v);devLog('zb','стадия '+v);break;}
  case 'zbhp':{const Z=G.zb;if(Z&&Z.k==='fight'){Z.hp=Math.max(1,Math.round(Z.segMax*(+v)/100));devLog('zb','сегмент '+v+'%');}break;}
  case 'zbstun':{const Z=G.zb;if(Z&&Z.k==='fight'){Z.stun=0;Z.stgLock=0;zbStg(Z,100);}break;}
  case 'zbatk':{const Z=G.zb;if(Z&&Z.k==='fight'&&Z.boss){Z.cool=0;Z.wind=0;zbAtk(Z,v);devLog('zb','атака '+v);}break;}
  case 'zbchoice':{const Z=G.zb;if(Z&&Z.boss){Z.k='choice';Z.t=0;dvxClose();zbOpenChoice(Z);return;}break;}
  case 'zbleave':dvLeave();break;
  case 'zbagain':{dvLeave();G.zbCool=0;const n=WORLD.nodes[49];devJump(n.x,n.y+100,'босс 50',{exact:1,quiet:1});setTimeout(()=>{try{G.zbCool=0;zbStart();if(DVX.open)dvxRender();}catch(er){console.error(er);}},60);return;}
  case 'pact':if(G.post){postLoadAct(+v,G.player.hp);devLog('post','акт '+(+v+1));}break;
  case 'ptask':{const P_=G.post;if(!P_)break;P_.panels.forEach(q=>{q.on=true;q.h=9;});P_.cells.forEach(q=>q.got=true);P_.gens.forEach(q=>{q.on=true;q.h=9;});if(P_.core&&!P_.core.on)P_.core.h=4;devLog('post','задачи акта выполнены');break;}
  case 'pdoor':if(G.post&&G.post.door){G.post.door.open=true;G.post.door.k=1;}break;
  case 'pwin':if(G.post){dvxClose();postWin();return;}break;
  case 'pcall':if(G.post&&G.post.O){G.dev.postFreeze=false;G.post.O.cd=0;}break;
  case 'pscare':if(G.post){G.post.events['sc'+v]=0;G.post.scDone['sc'+v]=0;G.post.scares=Math.min(G.post.scares,3);postScare(+v);}break;
  case 'pstrobe':if(G.post)postStrobe(true);break;
  case 'pfig':if(G.post&&p){const a=G.post.aim||0;postFig('crew',p.x+Math.cos(a)*160,p.y+Math.sin(a)*160,1.2);}break;
  case 'proll':if(G.post&&G.post.trig)postRollCall();break;
  case 'leave':dvLeave();break;
  case 'dv':devAct(v);break;
  case 'spawn':{const t=($('#sp65')||{}).value;if(!t||!p||!EDEF[t])break;const n=+v;for(let i=0;i<n;i++){if(G.world&&G.state==='world'){const ang=Math.random()*TAU,d=380+Math.random()*220;spawnEnemy(t,p.x+Math.cos(ang)*d,p.y+Math.sin(ang)*d);}else if(G.state==='play'){if(t==='twin')directorSpawn('twin');else edgeSpawn(t);}}devLog('spawn',t+' ×'+n);break;}
  case 'killr':{if(!p)break;let n=0;for(const q of G.enemies.slice())if(q.alive&&!dvBossy(q)&&Math.hypot(q.x-p.x,q.y-p.y)<1100){kill(q,false);n++;}devLog('kill','убито рядом: '+n);break;}
  case 'ts':if(+v===0){G.dev.tpause=true;}else{G.dev.tpause=false;G.dev.tscale=+v;}dvSave();devLog('dev','время '+(G.dev.tpause?'пауза':'×'+G.dev.tscale));break;
  case 'stepf':DVX.step=1;break;
  case 'w58':if(typeof W58DEV==='function'){W58DEV(v);devLog('world','событие '+v);}break;
  case 'fog':if(S){S.reveal=(+v?'1':'0').repeat(FGW*FGH);try{MAPC.fog=null;MAPC.fogVer=null;if(typeof FOGC!=='undefined')FOGC.k=null;}catch(er){}saveWorld();}break;
  case 'prog':{const el=$('#prog65');if(el)dvSetProg(+el.value);break;}
  case 'progq':dvSetProg(+v);break;
  case 'tutprep':{dvSetProg(+v);G.dev.tut=true;dvSave();const T=tutT();if(T){T.off=0;}const n=WORLD.nodes[+v];devJump(n.x,n.y+400,'обучение');break;}
  case 'lom':if(S){S.lom+=+v;G.lomPrev=undefined;saveWorld();}break;
  case 'lom0':if(S){S.lom=0;S.carry=0;G.lomPrev=undefined;saveWorld();}break;
  case 'carry':if(S){S.carry=(S.carry||0)+(+v);G.lomPrev=undefined;saveWorld();}break;
  case 'plvl':if(S){S.pilot=S.pilot||{lvl:1,xp:0};S.pilot.lvl=clamp((S.pilot.lvl||1)+(+v),1,60);S.pilot.xp=0;try{computeStats();}catch(er){}saveWorld();}break;
  case 'read':VOID_DBG.readAll();saveWorld();break;
  case 'frag':VOID_DBG.frags(+v);saveWorld();break;
  case 'ero':VOID_DBG.erosion(+v);saveWorld();break;
  case 'cyc':if(S){S.cycle=clamp((S.cycle||1)+(+v),1,9);saveWorld();}break;
  case 'flag':if(S&&S.story){const c=S.story[v];S.story[v]=typeof c==='boolean'?!c:((+c||0)+1)%4;saveWorld();devLog('flag',v+' = '+S.story[v]);}break;
  case 'snapS':dvSnapSave(+v);return;
  case 'snapL':dvxClose();dvSnapLoad(+v);return;
  case 'mine':if(!DVX.arm.mine){DVX.arm.mine=1;setTimeout(()=>{DVX.arm.mine=0;if(DVX.open)dvxRender();},4000);break;}DVX.arm.mine=0;dvxClose();dvCopyMine();return;
  case 'reset':if(!DVX.arm.reset){DVX.arm.reset=1;setTimeout(()=>{DVX.arm.reset=0;if(DVX.open)dvxRender();},4000);break;}DVX.arm.reset=0;dvxClose();dvLeave();try{LS.removeItem(DEVW.KEY);}catch(er){}saveSet6(null,'dev');DEVW.enter();toast('ПЕСОЧНИЦА СБРОШЕНА','Открытый мир разработчика начат заново.');return;
  case 'tutgo':{if(dvTutBlock()){toast('ОБУЧЕНИЕ ВЫКЛЮЧЕНО ИГРОЙ',dvTutBlock()+' «Прогресс» → «пройдено до» меньше 10 и полёт в секторах I–II.');break;}if(!G.dev.tut){G.dev.tut=true;dvSave();}const T=tutT();if(T){T.off=0;delete T.done[v];}if(TUT.cur)tutEnd('abort');TUT.gap=0;tutStart(v);if(TUT.cur)TUT.cur.forced=1;try{tutDraw(performance.now());}catch(er){}break;}
  case 'tutrs':{const T=tutT();if(T){delete T.done[v];if(T.seen)delete T.seen[v];if(T.ok)delete T.ok[v];tutSave();}break;}
  case 'tutwhy':DVX.why=DVX.why===v?null:v;break;
  case 'tutall':{const T=tutT();if(!T)break;if(+v){for(const k of Object.keys(TUT_L))T.done[k]=1;if(TUT.cur)tutEnd('abort');}else{T.done={};T.seen={};T.ok={};T.off=0;TUT.hist=[];TUT.gap=0;}tutSave();break;}
  case 'seed':{const n=parseInt((($('#seed65')||{}).value||'').replace(/\D/g,''),10);if(n>0){G.dev.seed=n;G.dev.seedOn=true;dvSave();toast('СИД '+n,'Со следующего входа в миссию.');}break;}
  case 'seedrnd':G.dev.seed=1+Math.floor((DVX.mr||Math.random)()*99999);G.dev.seedOn=true;dvSave();break;
  case 'seedOn':G.dev.seedOn=+v===1;dvSave();break;
  case 'report':dvCopy(dvReport(),'Отчёт в буфере — вставьте его в сообщение о баге.');DVX.errs.forEach(x=>x.seen=1);break;
  case 'errsee':DVX.errOpen=!DVX.errOpen;DVX.errs.forEach(x=>x.seen=1);break;
  case 'logclr':DVX.log.length=0;break;
  default:rr=false;}
  if(rr&&DVX.open)dvxRender();dvxBar();}

/* ---------- дев-полоса: состояние чипами ---------- */
function dvxBar(){const bar=$('#devBar');if(!bar||!devAny()){return;}const sb=dvOn();const chips=[];
  chips.push(`<span class="c0">РАЗРАБОТКА · ${sb?'ПЕСОЧНИЦА':G.mode==='endless'?'БЕСКОНЕЧНОСТЬ':'МИССИИ'}</span>`);
  const g=devGod();if(g)chips.push(`<button data-b="god" class="on">${g===2?'БЕССМЕРТИЕ':'1 HP'}</button>`);
  if(sb&&DEVW.spd&&DEVW.spd()!==1)chips.push(`<button data-b="wspd" class="on">ПОЛЁТ ×${String(DEVW.spd()).replace('.',',')}</button>`);
  if(G.dev.tpause)chips.push('<button data-b="ts" class="on">ПАУЗА</button>');else if(G.dev.tscale!==1)chips.push(`<button data-b="ts" class="on">ВРЕМЯ ×${G.dev.tscale===.25?'¼':G.dev.tscale===.5?'½':G.dev.tscale}</button>`);
  if(G.dev.seedOn)chips.push(`<button data-b="seed" class="on">СИД ${G.dev.seed}</button>`);
  const ne=DVX.errs.filter(x=>!x.seen).length;if(ne)chips.push(`<button data-b="err" class="er">⚠ ${ne}</button>`);
  chips.push(`<button data-b="panel">${touchMode?'ПАНЕЛЬ':'Ё ПАНЕЛЬ'}</button>`);
  const h=chips.join('');if(bar.dataset.h!==h||!bar.querySelector('.c0')){bar.innerHTML=h;bar.dataset.h=h;}bar.classList.add('chips65');
  /* на телефоне при выборе модуля полоса не ложится на карточки */if(isMob()&&G.state==='levelup')bar.hidden=true;}
{const _u=DEVW.ui;DEVW.ui=function(){const r=_u.apply(this,arguments);try{if(devAny())dvxBar();}catch(e){}return r;};}
{const _s=show;show=function(){const r=_s.apply(this,arguments);try{if(devAny())dvxBar();if(DVX.open&&!['world','play','levelup','pause','map'].includes(G.state))dvxClose();}catch(e){}return r;};}
$('#devBar').addEventListener('click',e=>{const b=e.target.closest('[data-b]');if(!b)return;e.stopPropagation();const k=b.dataset.b;
  if(k==='panel')dvxOpen();if(k==='god'){G.dev.dvTab='ship';dvSave();dvxOpen(true);}if(k==='ts'||k==='seed'||k==='err'){G.dev.dvTab=k==='ts'?'fight':'dbg';if(k==='err')DVX.errOpen=true;dvSave();dvxOpen(true);}if(k==='wspd'){G.dev.dvTab='ship';dvSave();dvxOpen(true);}});
setInterval(()=>{try{if(devAny()){const W=DEVW.stats?DEVW.stats():null;const n=W?(W.warn||[]).length:0;if(n>DVX.lastWarn){devLog('guard','запись в настоящее сохранение заблокирована');DVX.lastWarn=n;}dvxBar();}}catch(e){}},1000);

/* ---------- клавиши (только в деве) ---------- */
const DVK={buf:'',t:0};
addEventListener('keydown',e=>{if(!devAny())return;const t=e.target;if(t&&t.tagName&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))return;const st=G.state;if(!['world','play','map','levelup'].includes(st))return;const c=e.code;let used=true;
  const fly=st==='world'||st==='play';
  if(c==='KeyG'&&fly&&!e.ctrlKey&&!e.metaKey){const g=(devGod()+1)%3;G.dev.god=g===2;G.dev.god1=g===1;dvSave();if(G.player)floater(G.player.x,G.player.y-40,['БЕССМЕРТИЕ ВЫКЛ','ДЕРЖАТЬ 1 HP','БЕССМЕРТИЕ ПОЛНОЕ'][g],'#00ff88');}
  else if(c==='KeyH'&&fly)dvAct('heal');
  else if((c==='BracketLeft'||c==='BracketRight')&&e.shiftKey&&fly){const L=[.25,.5,1,2,4];let i=G.dev.tpause?-1:L.indexOf(G.dev.tscale);if(i<0&&!G.dev.tpause)i=2;if(G.dev.tpause){G.dev.tpause=false;G.dev.tscale=c==='BracketRight'?.25:.25;}else{i=clamp(i+(c==='BracketRight'?1:-1),0,L.length-1);G.dev.tscale=L[i];}dvSave();if(G.player)floater(G.player.x,G.player.y-40,'ВРЕМЯ ×'+String(G.dev.tscale).replace('.',','),'#00ff88');}
  else if(c==='Period'&&fly){if(!G.dev.tpause){G.dev.tpause=true;}else DVX.step=1;dvSave();}
  else if(c==='KeyK'&&st==='play'){devAct('kill');}
  else if(c==='KeyK'&&st==='world'&&dvOn())dvAct('killr');
  else if(c==='KeyN'&&(st==='play'||G.zb||G.post)){if(G.zb&&G.zb.boss){dvAct('zbst',String(Math.min(4,(G.zb.stage||1)+1)));}else if(G.post){if(G.post.act<POST_ACTS.length-1)dvAct('pact',String(G.post.act+1));}else{const M=MISSIONS[G.m-1];devAct(M&&(M.boss||M.transmit||M.sboss)?'boss':'wave');}}
  else if(dvOn()&&st==='world'&&c==='Backspace')dvBack();
  else if(dvOn()&&/^Digit[1-3]$/.test(c)&&(e.ctrlKey||e.altKey)){const i=+c.slice(5)-1;if(e.ctrlKey)dvAct('bmset',String(i));else dvAct('bmgo',String(i));}
  else if(dvOn()&&(c==='F5'||c==='F9')&&st==='world'){if(c==='F5')dvSnapSave(1);else dvSnapLoad(1);}
  else if(dvOn()&&DVX.open&&st==='world'&&/^(Digit|Numpad)[0-9]$/.test(c)){const d=c.slice(-1);DVK.buf=(performance.now()-DVK.t<1500?DVK.buf:'')+d;DVK.buf=DVK.buf.slice(-2);DVK.t=performance.now();const P=$('#dvx');P&&P.querySelectorAll('.m65').forEach(x=>x.classList.toggle('hl',(x.querySelector('.mj b')||{}).textContent===pad2(+DVK.buf)));}
  else if(dvOn()&&DVX.open&&st==='world'&&(c==='Enter'||c==='NumpadEnter')&&DVK.buf&&performance.now()-DVK.t<4000){const m=+DVK.buf;DVK.buf='';if(m>=1&&m<=50)dvGoNode(m,e.shiftKey);}
  else if(dvOn()&&DVX.open&&st==='world'&&(c==='KeyI'||c==='KeyO')){dvGoNode(c==='KeyI'?'post':50,e.shiftKey);}
  else used=false;
  if(used){e.preventDefault();e.stopImmediatePropagation();dvxBar();if(DVX.open)setTimeout(dvxRender,0);}},true);

/* ---------- прыжок по карте: Alt+клик, долгое нажатие ---------- */
{const cv=$('#mapC');if(cv){const P0={};cv.addEventListener('pointerdown',e=>{P0[e.pointerId]={x:e.clientX,y:e.clientY,t:performance.now()};},true);
  cv.addEventListener('pointerup',e=>{const q=P0[e.pointerId];delete P0[e.pointerId];if(!dvOn()||G.state!=='map'||!q||!G.mapXY)return;const moved=Math.hypot(e.clientX-q.x,e.clientY-q.y),held=performance.now()-q.t;
    if(!(e.altKey&&moved<6)&&!(e.pointerType!=='mouse'&&held>600&&moved<10))return;const r=cv.getBoundingClientRect(),M=G.mapXY;const wx=M.ox+(e.clientX-r.left)/M.k,wy=M.oy+(e.clientY-r.top)/M.k;
    e.stopImmediatePropagation();e.preventDefault();closeMap();devJump(wx,wy,'карта');},true);}}

/* ---------- мелочи ---------- */
/* сторожевик из сетки миссий (devStart) больше не запускается в режиме dev — только через песочницу */
{const _oi=openIntro;openIntro=function(i){if(G.mode==='dev'&&(i===POST_I||i===49)){devGo(i===POST_I?'post':'zb');return;}return _oi.apply(this,arguments);};}

